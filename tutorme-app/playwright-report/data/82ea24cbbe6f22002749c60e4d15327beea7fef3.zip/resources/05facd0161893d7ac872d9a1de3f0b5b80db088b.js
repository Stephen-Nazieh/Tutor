;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="fc797bda-55a9-33fd-09ff-6396cb3bbf3d")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/selectHelpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasRichText",
    ()=>hasRichText,
    "startEditingShapeWithRichText",
    ()=>startEditingShapeWithRichText
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
;
function hasRichText(shape) {
    return "richText" in shape.props && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"].isValid(shape.props.richText);
}
function startEditingShapeWithRichText(editor, shapeOrId, options = {}) {
    const shape = typeof shapeOrId === "string" ? editor.getShape(shapeOrId) : shapeOrId;
    if (!shape) return;
    if (!editor.canEditShape(shape)) return;
    if (!hasRichText(shape)) {
        throw new Error("Shape does not have rich text");
    }
    editor.setEditingShape(shape);
    editor.setCurrentTool("select.editing_shape", {
        ...options.info,
        target: "shape",
        shape
    });
    if (options.selectAll) {
        editor.emit("select-all-text", {
            shapeId: shape.id
        });
    }
}
;
 //# sourceMappingURL=selectHelpers.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/updateHoveredShapeId.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateHoveredShapeId",
    ()=>updateHoveredShapeId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
const hoverLockedEditors = /* @__PURE__ */ new WeakMap();
function getShapeToHover(editor) {
    const hitShape = editor.getShapeAtPoint(editor.inputs.getCurrentPagePoint(), {
        hitInside: false,
        hitLabels: false,
        margin: editor.options.hitTestMargin / editor.getZoomLevel(),
        renderingOnly: true
    });
    if (!hitShape) return null;
    let shapeToHover = void 0;
    const outermostShape = editor.getOutermostSelectableShape(hitShape);
    if (outermostShape === hitShape) {
        shapeToHover = hitShape;
    } else {
        if (outermostShape.id === editor.getFocusedGroupId() || editor.getSelectedShapeIds().includes(outermostShape.id)) {
            shapeToHover = hitShape;
        } else {
            shapeToHover = outermostShape;
        }
    }
    return shapeToHover.id;
}
function _updateHoveredShapeId(editor) {
    const cameraMoving = editor.getCameraState() === "moving";
    if (!cameraMoving) {
        hoverLockedEditors.set(editor, false);
        const nextHoveredId2 = getShapeToHover(editor);
        return editor.setHoveredShape(nextHoveredId2);
    }
    if (hoverLockedEditors.get(editor)) {
        return;
    }
    const currentHoveredId = editor.getHoveredShapeId();
    if (!currentHoveredId) {
        hoverLockedEditors.set(editor, true);
        return;
    }
    const nextHoveredId = getShapeToHover(editor);
    if (nextHoveredId === currentHoveredId) {
        return;
    }
    editor.setHoveredShape(null);
    hoverLockedEditors.set(editor, true);
}
const updateHoveredShapeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throttle"])(_updateHoveredShapeId, ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 32);
;
 //# sourceMappingURL=updateHoveredShapeId.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Erasing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Erasing",
    ()=>Erasing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/keyboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
;
class Erasing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "erasing";
    info = {};
    scribbleId = "id";
    markId = "";
    excludedShapeIds = /* @__PURE__ */ new Set();
    _isHoldingAccelKey = false;
    _firstErasingShapeId = null;
    _erasingShapeIds = [];
    onEnter(info) {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
        this._firstErasingShapeId = this.editor.getErasingShapeIds()[0];
        this._erasingShapeIds = this.editor.getErasingShapeIds();
        this.markId = this.editor.markHistoryStoppingPoint("erase scribble begin");
        this.info = info;
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        this.excludedShapeIds = new Set(this.editor.getCurrentPageShapes().filter((shape)=>{
            if (this.editor.isShapeOrAncestorLocked(shape)) return true;
            if (this.editor.isShapeOfType(shape, "group") || this.editor.isShapeOfType(shape, "frame")) {
                const pointInShapeShape = this.editor.getPointInShapeSpace(shape, originPagePoint);
                const geometry = this.editor.getShapeGeometry(shape);
                return geometry.bounds.containsPoint(pointInShapeShape);
            }
            return false;
        }).map((shape)=>shape.id));
        const scribble = this.editor.scribbles.addScribble({
            color: "muted-1",
            size: 12
        });
        this.scribbleId = scribble.id;
        this.update();
    }
    pushPointToScribble() {
        const { x, y } = this.editor.inputs.getCurrentPagePoint();
        this.editor.scribbles.addPoint(this.scribbleId, x, y);
    }
    onExit() {
        this.editor.setErasingShapes([]);
        this.editor.scribbles.stop(this.scribbleId);
    }
    onPointerMove() {
        this.update();
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.complete();
    }
    onKeyUp() {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
        this.update();
    }
    onKeyDown() {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
        this.update();
    }
    update() {
        const { editor, excludedShapeIds } = this;
        const erasingShapeIds = editor.getErasingShapeIds();
        const zoomLevel = editor.getZoomLevel();
        const currentPagePoint = editor.inputs.getCurrentPagePoint();
        const previousPagePoint = editor.inputs.getPreviousPagePoint();
        this.pushPointToScribble();
        const erasing = new Set(erasingShapeIds);
        const minDist = this.editor.options.hitTestMargin / zoomLevel;
        const lineBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints([
            previousPagePoint,
            currentPagePoint
        ]).expandBy(minDist);
        const candidateIds = editor.getShapeIdsInsideBounds(lineBounds);
        if (candidateIds.size === 0) {
            editor.setErasingShapes(Array.from(erasing));
            return;
        }
        const allShapes = editor.getCurrentPageRenderingShapesSorted();
        const currentPageShapes = allShapes.filter((shape)=>candidateIds.has(shape.id));
        for (const shape of currentPageShapes){
            if (editor.isShapeOfType(shape, "group")) continue;
            const pageMask = editor.getShapeMask(shape.id);
            if (pageMask && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(currentPagePoint, pageMask)) {
                continue;
            }
            const geometry = editor.getShapeGeometry(shape);
            const pageTransform = editor.getShapePageTransform(shape);
            if (!geometry || !pageTransform) continue;
            const pt = pageTransform.clone().invert();
            const A = pt.applyToPoint(previousPagePoint);
            const B = pt.applyToPoint(currentPagePoint);
            const { bounds } = geometry;
            if (bounds.minX - minDist > Math.max(A.x, B.x) || bounds.minY - minDist > Math.max(A.y, B.y) || bounds.maxX + minDist < Math.min(A.x, B.x) || bounds.maxY + minDist < Math.min(A.y, B.y)) {
                continue;
            }
            if (geometry.hitTestLineSegment(A, B, minDist)) {
                erasing.add(editor.getOutermostSelectableShape(shape).id);
            }
            this._erasingShapeIds = [
                ...erasing
            ];
        }
        if (this._isHoldingAccelKey && this._firstErasingShapeId) {
            const erasingShapeId = this._firstErasingShapeId;
            if (erasingShapeId && this.editor.getShape(erasingShapeId)) {
                editor.setErasingShapes([
                    erasingShapeId
                ]);
            }
            return;
        }
        this.editor.setErasingShapes(this._erasingShapeIds.filter((id)=>!excludedShapeIds.has(id)));
    }
    complete() {
        const { editor } = this;
        editor.deleteShapes(editor.getCurrentPageState().erasingShapeIds);
        this.parent.transition("idle");
        this._erasingShapeIds = [];
        this._firstErasingShapeId = null;
    }
    cancel() {
        const { editor } = this;
        editor.bailToMark(this.markId);
        this.parent.transition("idle", this.info);
    }
}
;
 //# sourceMappingURL=Erasing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    onPointerDown(info) {
        this.parent.transition("pointing", info);
    }
    onCancel() {
        this.editor.setCurrentTool("select");
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Pointing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pointing",
    ()=>Pointing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/keyboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Pointing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing";
    _isHoldingAccelKey = false;
    onEnter() {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
        const zoomLevel = this.editor.getZoomLevel();
        const currentPageShapesSorted = this.editor.getCurrentPageRenderingShapesSorted();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const erasing = /* @__PURE__ */ new Set();
        const initialSize = erasing.size;
        for(let n = currentPageShapesSorted.length, i = n - 1; i >= 0; i--){
            const shape = currentPageShapesSorted[i];
            if (this.editor.isShapeOrAncestorLocked(shape) || this.editor.isShapeOfType(shape, "group")) {
                continue;
            }
            if (this.editor.isPointInShape(shape, currentPagePoint, {
                hitInside: false,
                margin: this.editor.options.hitTestMargin / zoomLevel
            })) {
                const hitShape = this.editor.getOutermostSelectableShape(shape);
                if (this.editor.isShapeOfType(hitShape, "frame") && erasing.size > initialSize) {
                    break;
                }
                erasing.add(hitShape.id);
                if (this._isHoldingAccelKey) {
                    break;
                }
            }
        }
        this.editor.setErasingShapes([
            ...erasing
        ]);
    }
    onKeyUp() {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
    }
    onKeyDown() {
        this._isHoldingAccelKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
    }
    onLongPress(info) {
        this.startErasing(info);
    }
    onExit(_info, to) {
        if (to !== "erasing") {
            this.editor.setErasingShapes([]);
        }
    }
    onPointerMove(info) {
        if (this._isHoldingAccelKey) return;
        if (this.editor.inputs.getIsDragging()) {
            this.startErasing(info);
        }
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.complete();
    }
    onInterrupt() {
        this.cancel();
    }
    startErasing(info) {
        this.parent.transition("erasing", info);
    }
    complete() {
        const erasingShapeIds = this.editor.getErasingShapeIds();
        if (erasingShapeIds.length) {
            this.editor.markHistoryStoppingPoint("erase end");
            this.editor.deleteShapes(erasingShapeIds);
        }
        this.parent.transition("idle");
    }
    cancel() {
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=Pointing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/EraserTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EraserTool",
    ()=>EraserTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Erasing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Erasing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/childStates/Pointing.mjs [app-client] (ecmascript)");
;
;
;
;
class EraserTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "eraser";
    static initial = "idle";
    static isLockable = false;
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pointing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$childStates$2f$Erasing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Erasing"]
        ];
    }
    onEnter() {
        this.editor.setCursor({
            type: "cross",
            rotation: 0
        });
    }
}
;
 //# sourceMappingURL=EraserTool.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Dragging.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dragging",
    ()=>Dragging
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
class Dragging extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "dragging";
    initialCamera = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
    onEnter() {
        this.initialCamera = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(this.editor.getCamera());
        this.update();
    }
    onPointerMove() {
        this.update();
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.parent.transition("idle");
    }
    onComplete() {
        this.complete();
    }
    update() {
        const { initialCamera, editor } = this;
        const currentScreenPoint = editor.inputs.getCurrentScreenPoint();
        const originScreenPoint = editor.inputs.getOriginScreenPoint();
        const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentScreenPoint, originScreenPoint).div(editor.getZoomLevel());
        if (delta.len2() === 0) return;
        editor.setCamera(initialCamera.clone().add(delta));
    }
    complete() {
        const { editor } = this;
        const pointerVelocity = editor.inputs.getPointerVelocity();
        const velocityAtPointerUp = Math.min(pointerVelocity.len(), 2);
        if (velocityAtPointerUp > 0.1) {
            this.editor.slideCamera({
                speed: velocityAtPointerUp,
                direction: pointerVelocity
            });
        }
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=Dragging.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    onEnter() {
        this.editor.setCursor({
            type: "grab",
            rotation: 0
        });
    }
    onPointerDown(info) {
        this.parent.transition("pointing", info);
    }
    onCancel() {
        this.editor.setCurrentTool("select");
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Pointing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pointing",
    ()=>Pointing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Pointing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing";
    onEnter() {
        this.editor.stopCameraAnimation();
        this.editor.setCursor({
            type: "grabbing",
            rotation: 0
        });
    }
    onLongPress() {
        this.startDragging();
    }
    onPointerMove() {
        if (this.editor.inputs.getIsDragging()) {
            this.startDragging();
        }
    }
    startDragging() {
        this.parent.transition("dragging");
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onInterrupt() {
        this.complete();
    }
    complete() {
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=Pointing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/HandTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HandTool",
    ()=>HandTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Dragging$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Dragging.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/childStates/Pointing.mjs [app-client] (ecmascript)");
;
;
;
;
class HandTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "hand";
    static initial = "idle";
    static isLockable = false;
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pointing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$childStates$2f$Dragging$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dragging"]
        ];
    }
    onDoubleClick(info) {
        if (info.phase === "settle") {
            const currentScreenPoint = this.editor.inputs.getCurrentScreenPoint();
            this.editor.zoomIn(currentScreenPoint, {
                animation: {
                    duration: 220,
                    easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeOutQuint
                }
            });
        }
    }
    onTripleClick(info) {
        if (info.phase === "settle") {
            const currentScreenPoint = this.editor.inputs.getCurrentScreenPoint();
            this.editor.zoomOut(currentScreenPoint, {
                animation: {
                    duration: 320,
                    easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeOutQuint
                }
            });
        }
    }
    onQuadrupleClick(info) {
        if (info.phase === "settle") {
            const zoomLevel = this.editor.getZoomLevel();
            const currentScreenPoint = this.editor.inputs.getCurrentScreenPoint();
            if (zoomLevel === 1) {
                this.editor.zoomToFit({
                    animation: {
                        duration: 400,
                        easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeOutQuint
                    }
                });
            } else {
                this.editor.resetZoom(currentScreenPoint, {
                    animation: {
                        duration: 320,
                        easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeOutQuint
                    }
                });
            }
        }
    }
}
;
 //# sourceMappingURL=HandTool.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/childStates/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    onPointerDown() {
        const sessionId = this.parent.getSessionId();
        const scribble = this.editor.scribbles.addScribbleToSession(sessionId, {
            color: "laser",
            opacity: 0.7,
            size: 4,
            taper: false
        });
        this.parent.transition("lasering", {
            sessionId,
            scribbleId: scribble.id
        });
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/childStates/Lasering.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Lasering",
    ()=>Lasering
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Lasering extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "lasering";
    scribbleId = "";
    sessionId = "";
    onEnter(info) {
        this.sessionId = info.sessionId;
        this.scribbleId = info.scribbleId;
        this.pushPointToScribble();
    }
    onPointerMove() {
        this.pushPointToScribble();
    }
    pushPointToScribble() {
        const { x, y } = this.editor.inputs.getCurrentPagePoint();
        this.editor.scribbles.addPointToSession(this.sessionId, this.scribbleId, x, y);
    }
    onTick() {
        this.editor.scribbles.extendSession(this.sessionId);
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.onComplete();
    }
    onComplete() {
        this.complete();
    }
    complete() {
        this.editor.scribbles.complete(this.scribbleId);
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=Lasering.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/LaserTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LaserTool",
    ()=>LaserTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/childStates/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$childStates$2f$Lasering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/childStates/Lasering.mjs [app-client] (ecmascript)");
;
;
;
class LaserTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "laser";
    static initial = "idle";
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$childStates$2f$Lasering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Lasering"]
        ];
    }
    static isLockable = false;
    sessionId = null;
    onEnter() {
        this.editor.setCursor({
            type: "cross",
            rotation: 0
        });
    }
    onExit() {
        this.sessionId = null;
    }
    onCancel() {
        if (this.sessionId && this.editor.scribbles.isSessionActive(this.sessionId)) {
            this.editor.scribbles.clearSession(this.sessionId);
            this.sessionId = null;
            this.transition("idle");
        } else {
            this.editor.setCurrentTool("select");
        }
    }
    /**
   * Get the current laser session ID, or create a new one if none exists or the current one is fading.
   */ getSessionId() {
        if (this.sessionId && this.editor.scribbles.isSessionActive(this.sessionId)) {
            return this.sessionId;
        }
        this.sessionId = this.editor.scribbles.startSession({
            selfConsume: false,
            idleTimeoutMs: this.editor.options.laserDelayMs,
            fadeMode: "grouped",
            fadeEasing: "ease-in"
        });
        return this.sessionId;
    }
}
;
 //# sourceMappingURL=LaserTool.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Brushing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Brushing",
    ()=>Brushing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript)");
;
class Brushing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "brushing";
    info = {};
    initialSelectedShapeIds = [];
    excludedShapeIds = /* @__PURE__ */ new Set();
    isWrapMode = false;
    viewportDidChange = false;
    cleanupViewportChangeReactor() {}
    // cleanup function for the viewport reactor
    onEnter(info) {
        const { editor } = this;
        const altKey = editor.inputs.getAltKey();
        this.isWrapMode = editor.user.getIsWrapMode();
        this.viewportDidChange = false;
        let isInitialCheck = true;
        this.cleanupViewportChangeReactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("viewport change while brushing", ()=>{
            editor.getViewportPageBounds();
            if (!isInitialCheck && !this.viewportDidChange) {
                this.viewportDidChange = true;
            }
        });
        if (altKey) {
            this.parent.transition("scribble_brushing", info);
            return;
        }
        this.excludedShapeIds = new Set(editor.getCurrentPageShapes().filter((shape)=>editor.isShapeOfType(shape, "group") || editor.isShapeOrAncestorLocked(shape)).map((shape)=>shape.id));
        this.info = info;
        this.initialSelectedShapeIds = editor.getSelectedShapeIds().slice();
        this.hitTestShapes();
        isInitialCheck = false;
    }
    onExit() {
        this.initialSelectedShapeIds = [];
        this.editor.updateInstanceState({
            brush: null
        });
        this.cleanupViewportChangeReactor();
    }
    onTick({ elapsed }) {
        const { editor } = this;
        if (!editor.inputs.getIsDragging() || editor.inputs.getIsPanning()) return;
        editor.edgeScrollManager.updateEdgeScrolling(elapsed);
    }
    onPointerMove() {
        this.hitTestShapes();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel(info) {
        this.editor.setSelectedShapes(this.initialSelectedShapeIds);
        this.parent.transition("idle", info);
    }
    onKeyDown(info) {
        if (this.editor.inputs.getAltKey()) {
            this.parent.transition("scribble_brushing", info);
        } else {
            this.hitTestShapes();
        }
    }
    onKeyUp() {
        this.hitTestShapes();
    }
    complete() {
        this.hitTestShapes();
        this.parent.transition("idle");
    }
    hitTestShapes() {
        const { editor, excludedShapeIds, isWrapMode } = this;
        const originPagePoint = editor.inputs.getOriginPagePoint();
        const currentPagePoint = editor.inputs.getCurrentPagePoint();
        const shiftKey = editor.inputs.getShiftKey();
        const ctrlKey = editor.inputs.getCtrlKey();
        const results = new Set(shiftKey ? this.initialSelectedShapeIds : []);
        const isWrapping = isWrapMode ? !ctrlKey : ctrlKey;
        const brush = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints([
            originPagePoint,
            currentPagePoint
        ]);
        const { corners } = brush;
        let A, B, shape, pageBounds, pageTransform, localCorners;
        const brushBoxIsInsideViewport = editor.getViewportPageBounds().contains(brush);
        const currentPageId = editor.getCurrentPageId();
        const candidateIds = editor.getShapeIdsInsideBounds(brush);
        if (candidateIds.size === 0) {
            const currentBrush2 = editor.getInstanceState().brush;
            if (!currentBrush2 || !brush.equals(currentBrush2)) {
                editor.updateInstanceState({
                    brush: {
                        ...brush.toJson()
                    }
                });
            }
            const current2 = editor.getSelectedShapeIds();
            if (current2.length !== results.size || current2.some((id)=>!results.has(id))) {
                editor.setSelectedShapes(Array.from(results));
            }
            return;
        }
        const allShapes = brushBoxIsInsideViewport && !this.viewportDidChange ? editor.getCurrentPageRenderingShapesSorted() : editor.getCurrentPageShapesSorted();
        const shapesToHitTest = allShapes.filter((shape2)=>candidateIds.has(shape2.id));
        testAllShapes: for(let i = 0, n = shapesToHitTest.length; i < n; i++){
            shape = shapesToHitTest[i];
            if (excludedShapeIds.has(shape.id) || results.has(shape.id)) continue testAllShapes;
            pageBounds = editor.getShapePageBounds(shape);
            if (!pageBounds) continue testAllShapes;
            if (brush.contains(pageBounds)) {
                this.handleHit(shape, currentPagePoint, currentPageId, results, corners);
                continue testAllShapes;
            }
            if (isWrapping || editor.isShapeOfType(shape, "frame")) {
                continue testAllShapes;
            }
            if (brush.collides(pageBounds)) {
                pageTransform = editor.getShapePageTransform(shape);
                if (!pageTransform) continue testAllShapes;
                localCorners = pageTransform.clone().invert().applyToPoints(corners);
                const geometry = editor.getShapeGeometry(shape);
                hitTestBrushEdges: for(let i2 = 0; i2 < 4; i2++){
                    A = localCorners[i2];
                    B = localCorners[(i2 + 1) % 4];
                    if (geometry.hitTestLineSegment(A, B, 0)) {
                        this.handleHit(shape, currentPagePoint, currentPageId, results, corners);
                        break hitTestBrushEdges;
                    }
                }
            }
        }
        const currentBrush = editor.getInstanceState().brush;
        if (!currentBrush || !brush.equals(currentBrush)) {
            editor.updateInstanceState({
                brush: {
                    ...brush.toJson()
                }
            });
        }
        const current = editor.getSelectedShapeIds();
        if (current.length !== results.size || current.some((id)=>!results.has(id))) {
            editor.setSelectedShapes(Array.from(results));
        }
    }
    onInterrupt() {
        this.editor.updateInstanceState({
            brush: null
        });
    }
    handleHit(shape, currentPagePoint, currentPageId, results, corners) {
        if (shape.parentId === currentPageId) {
            results.add(shape.id);
            return;
        }
        const selectedShape = this.editor.getOutermostSelectableShape(shape);
        const pageMask = this.editor.getShapeMask(selectedShape.id);
        if (pageMask && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polygonsIntersect"])(pageMask, corners) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(currentPagePoint, pageMask)) {
            return;
        }
        results.add(selectedShape.id);
    }
}
;
 //# sourceMappingURL=Brushing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CursorTypeMap",
    ()=>CursorTypeMap,
    "PointingResizeHandle",
    ()=>PointingResizeHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
const CursorTypeMap = {
    bottom: "ns-resize",
    top: "ns-resize",
    left: "ew-resize",
    right: "ew-resize",
    bottom_left: "nesw-resize",
    bottom_right: "nwse-resize",
    top_left: "nwse-resize",
    top_right: "nesw-resize",
    bottom_left_rotate: "swne-rotate",
    bottom_right_rotate: "senw-rotate",
    top_left_rotate: "nwse-rotate",
    top_right_rotate: "nesw-rotate",
    mobile_rotate: "grabbing"
};
class PointingResizeHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_resize_handle";
    info = {};
    updateCursor() {
        const selected = this.editor.getSelectedShapes();
        const cursorType = CursorTypeMap[this.info.handle];
        this.editor.setCursor({
            type: cursorType,
            rotation: selected.length === 1 ? this.editor.getSelectionRotation() : 0
        });
    }
    onEnter(info) {
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.updateCursor();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
    }
    onPointerMove() {
        if (this.editor.inputs.getIsDragging()) {
            this.startResizing();
        }
    }
    onLongPress() {
        this.startResizing();
    }
    startResizing() {
        if (this.editor.getIsReadonly()) return;
        this.parent.transition("resizing", this.info);
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    complete() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
    cancel() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingResizeHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/Cropping.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Cropping",
    ()=>Cropping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/crop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)");
;
;
;
class Cropping extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "cropping";
    info = {};
    markId = "";
    snapshot = {};
    onEnter(info) {
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.markId = this.editor.markHistoryStoppingPoint("cropping");
        this.snapshot = this.createSnapshot();
        this.updateShapes();
    }
    onPointerMove() {
        this.updateShapes();
    }
    onKeyDown() {
        this.updateShapes();
    }
    onKeyUp() {
        this.updateShapes();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
    }
    updateCursor() {
        const selectedShape = this.editor.getSelectedShapes()[0];
        if (!selectedShape) return;
        const cursorType = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorTypeMap"][this.info.handle];
        this.editor.setCursor({
            type: cursorType,
            rotation: this.editor.getSelectionRotation()
        });
    }
    updateShapes() {
        const { shape, cursorHandleOffset } = this.snapshot;
        if (!shape) return;
        const util = this.editor.getShapeUtil(shape.type);
        if (!util) return;
        const shiftKey = this.editor.inputs.getShiftKey();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint().clone().sub(cursorHandleOffset);
        const originPagePoint = this.editor.inputs.getOriginPagePoint().clone().sub(cursorHandleOffset);
        const change = currentPagePoint.clone().sub(originPagePoint).rot(-shape.rotation);
        const crop = shape.props.crop ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCrop"])();
        const uncroppedSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUncroppedSize"])(shape.props, crop);
        const cropFn = util.onCrop?.bind(util) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCropBox"];
        const partial = cropFn(shape, {
            handle: this.info.handle,
            change,
            crop,
            uncroppedSize,
            initialShape: this.snapshot.shape,
            aspectRatioLocked: shiftKey
        });
        if (!partial) return;
        this.editor.updateShapes([
            {
                id: shape.id,
                type: shape.type,
                ...partial
            }
        ]);
        this.updateCursor();
    }
    complete() {
        this.updateShapes();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, [
            this.snapshot.shape.id
        ]);
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
        } else {
            this.editor.setCroppingShape(null);
            this.editor.setCurrentTool("select.idle");
        }
    }
    cancel() {
        this.editor.bailToMark(this.markId);
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
        } else {
            this.editor.setCroppingShape(null);
            this.editor.setCurrentTool("select.idle");
        }
    }
    createSnapshot() {
        const selectionRotation = this.editor.getSelectionRotation();
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        const shape = this.editor.getOnlySelectedShape();
        const selectionBounds = this.editor.getSelectionRotatedPageBounds();
        const dragHandlePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(selectionBounds.getHandlePoint(this.info.handle), selectionBounds.point, selectionRotation);
        const cursorHandleOffset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(originPagePoint, dragHandlePoint);
        return {
            shape,
            cursorHandleOffset
        };
    }
}
;
 //# sourceMappingURL=Cropping.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/getHitShapeOnCanvasPointerDown.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getHitShapeOnCanvasPointerDown",
    ()=>getHitShapeOnCanvasPointerDown
]);
function getHitShapeOnCanvasPointerDown(editor, hitLabels = false) {
    const zoomLevel = editor.getZoomLevel();
    const currentPagePoint = editor.inputs.getCurrentPagePoint();
    return editor.getShapeAtPoint(currentPagePoint, {
        hitInside: false,
        hitLabels,
        margin: editor.options.hitTestMargin / zoomLevel,
        renderingOnly: true
    }) ?? editor.getSelectedShapeAtPoint(currentPagePoint);
}
;
 //# sourceMappingURL=getHitShapeOnCanvasPointerDown.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/crop_helpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTranslateCroppedImageChange",
    ()=>getTranslateCroppedImageChange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/crop.mjs [app-client] (ecmascript)");
;
;
function getTranslateCroppedImageChange(editor, shape, delta) {
    if (!shape) {
        throw Error("Needs to translate a cropped shape!");
    }
    const { crop: oldCrop } = shape.props;
    if (!oldCrop) {
        return;
    }
    const flatten = editor.inputs.getShiftKey() ? Math.abs(delta.x) < Math.abs(delta.y) ? "x" : "y" : null;
    if (flatten === "x") {
        delta.x = 0;
    } else if (flatten === "y") {
        delta.y = 0;
    }
    delta.rot(-shape.rotation);
    const { w, h } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUncroppedSize"])(shape.props, oldCrop);
    const xCropSize = oldCrop.bottomRight.x - oldCrop.topLeft.x;
    const yCropSize = oldCrop.bottomRight.y - oldCrop.topLeft.y;
    const newCrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(oldCrop);
    const xMinWithCrop = 1 - xCropSize;
    const yMinWithCrop = 1 - yCropSize;
    newCrop.topLeft.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(newCrop.topLeft.x - delta.x / w, 0, xMinWithCrop);
    newCrop.topLeft.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(newCrop.topLeft.y - delta.y / h, 0, yMinWithCrop);
    newCrop.bottomRight.x = newCrop.topLeft.x + xCropSize;
    newCrop.bottomRight.y = newCrop.topLeft.y + yCropSize;
    const partial = {
        id: shape.id,
        type: shape.type,
        props: {
            crop: newCrop
        }
    };
    return partial;
}
;
 //# sourceMappingURL=crop_helpers.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/getHitShapeOnCanvasPointerDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$crop_helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/crop_helpers.mjs [app-client] (ecmascript)");
;
;
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    onEnter() {
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
        const onlySelectedShape = this.editor.getOnlySelectedShape();
        if (onlySelectedShape) {
            this.editor.setCroppingShape(onlySelectedShape.id);
        }
    }
    onExit() {
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    onCancel() {
        this.editor.setCroppingShape(null);
        this.editor.setCurrentTool("select.idle", {});
    }
    onPointerDown(info) {
        if (info.accelKey) {
            this.cancel();
            this.editor.root.handleEvent(info);
            return;
        }
        switch(info.target){
            case "canvas":
                {
                    const hitShape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHitShapeOnCanvasPointerDown"])(this.editor);
                    if (hitShape && !this.editor.isShapeOfType(hitShape, "group")) {
                        this.onPointerDown({
                            ...info,
                            shape: hitShape,
                            target: "shape"
                        });
                        return;
                    }
                    this.cancel();
                    this.editor.root.handleEvent(info);
                    break;
                }
            case "shape":
                {
                    if (info.shape.id === this.editor.getCroppingShapeId()) {
                        this.editor.setCurrentTool("select.crop.pointing_crop", info);
                        return;
                    } else {
                        if (this.editor.getShapeUtil(info.shape)?.canCrop(info.shape)) {
                            this.editor.setCroppingShape(info.shape.id);
                            this.editor.setSelectedShapes([
                                info.shape.id
                            ]);
                            this.editor.setCurrentTool("select.crop.pointing_crop", info);
                        } else {
                            this.cancel();
                            this.editor.root.handleEvent(info);
                        }
                    }
                    break;
                }
            case "selection":
                {
                    switch(info.handle){
                        case "mobile_rotate":
                        case "top_left_rotate":
                        case "top_right_rotate":
                        case "bottom_left_rotate":
                        case "bottom_right_rotate":
                            {
                                this.editor.setCurrentTool("select.pointing_rotate_handle", {
                                    ...info,
                                    onInteractionEnd: "select.crop.idle"
                                });
                                break;
                            }
                        case "top":
                        case "right":
                        case "bottom":
                        case "left":
                        case "top_left":
                        case "top_right":
                        case "bottom_left":
                        case "bottom_right":
                            {
                                this.editor.setCurrentTool("select.crop.pointing_crop_handle", {
                                    ...info,
                                    onInteractionEnd: "select.crop.idle"
                                });
                                break;
                            }
                        default:
                            {
                                this.cancel();
                            }
                    }
                    break;
                }
        }
    }
    onDoubleClick(info) {
        if (this.editor.inputs.getShiftKey() || info.phase !== "up") return;
        const croppingShapeId = this.editor.getCroppingShapeId();
        if (!croppingShapeId) return;
        const shape = this.editor.getShape(croppingShapeId);
        if (!shape) return;
        const util = this.editor.getShapeUtil(shape);
        if (!util) return;
        if (info.target === "selection") {
            util.onDoubleClickEdge?.(shape, info);
            return;
        }
        this.cancel();
        this.editor.root.handleEvent(info);
    }
    onKeyDown() {
        this.nudgeCroppingImage(false);
    }
    onKeyRepeat() {
        this.nudgeCroppingImage(true);
    }
    onKeyUp(info) {
        switch(info.key){
            case "Enter":
                {
                    this.editor.setCroppingShape(null);
                    this.editor.setCurrentTool("select.idle", {});
                    break;
                }
        }
    }
    cancel() {
        this.editor.setCroppingShape(null);
        this.editor.setCurrentTool("select.idle", {});
    }
    nudgeCroppingImage(ephemeral = false) {
        const { editor: { inputs: { keys } } } = this;
        const shiftKey = keys.has("ShiftLeft");
        const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
        if (keys.has("ArrowLeft")) delta.x += 1;
        if (keys.has("ArrowRight")) delta.x -= 1;
        if (keys.has("ArrowUp")) delta.y += 1;
        if (keys.has("ArrowDown")) delta.y -= 1;
        if (delta.equals(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0))) return;
        if (shiftKey) delta.mul(10);
        const shape = this.editor.getShape(this.editor.getCroppingShapeId());
        if (!shape) return;
        const partial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$crop_helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslateCroppedImageChange"])(this.editor, shape, delta);
        if (partial) {
            if (!ephemeral) {
                this.editor.markHistoryStoppingPoint("translate crop");
            }
            this.editor.updateShapes([
                partial
            ]);
        }
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/PointingCrop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingCrop",
    ()=>PointingCrop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class PointingCrop extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_crop";
    onCancel() {
        this.editor.setCurrentTool("select.crop.idle", {});
    }
    onPointerMove(info) {
        if (this.editor.inputs.getIsDragging()) {
            this.startDragging(info);
        }
    }
    onLongPress(info) {
        this.startDragging(info);
    }
    onPointerUp(info) {
        this.editor.setCurrentTool("select.crop.idle", info);
    }
    startDragging(info) {
        this.editor.setCurrentTool("select.crop.translating_crop", info);
    }
}
;
 //# sourceMappingURL=PointingCrop.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/PointingCropHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingCropHandle",
    ()=>PointingCropHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)");
;
;
class PointingCropHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_crop_handle";
    info = {};
    onEnter(info) {
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        const selectedShape = this.editor.getSelectedShapes()[0];
        if (!selectedShape) return;
        const cursorType = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorTypeMap"][this.info.handle];
        this.editor.setCursor({
            type: cursorType,
            rotation: this.editor.getSelectionRotation()
        });
        this.editor.setCroppingShape(selectedShape.id);
    }
    onExit() {
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
        this.parent.setCurrentToolIdMask(void 0);
    }
    onPointerMove() {
        if (this.editor.inputs.getIsDragging()) {
            this.startCropping();
        }
    }
    onLongPress() {
        this.startCropping();
    }
    startCropping() {
        if (this.editor.getIsReadonly()) return;
        this.parent.transition("cropping", {
            ...this.info,
            onInteractionEnd: this.info.onInteractionEnd
        });
    }
    onPointerUp() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.editor.setCroppingShape(null);
        this.editor.setCurrentTool("select.idle");
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    cancel() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.editor.setCroppingShape(null);
        this.editor.setCurrentTool("select.idle");
    }
}
;
 //# sourceMappingURL=PointingCropHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/TranslatingCrop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TranslatingCrop",
    ()=>TranslatingCrop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$crop_helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/crop_helpers.mjs [app-client] (ecmascript)");
;
;
class TranslatingCrop extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "translating_crop";
    info = {};
    markId = "";
    snapshot = {};
    onEnter(info) {
        this.info = info;
        this.snapshot = this.createSnapshot();
        this.markId = this.editor.markHistoryStoppingPoint("translating_crop");
        this.editor.setCursor({
            type: "move",
            rotation: 0
        });
        this.updateShapes();
    }
    onExit() {
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    onPointerMove() {
        this.updateShapes();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onKeyDown(info) {
        switch(info.key){
            case "Alt":
            case "Shift":
                {
                    this.updateShapes();
                    return;
                }
        }
    }
    onKeyUp(info) {
        switch(info.key){
            case "Enter":
                {
                    this.complete();
                    return;
                }
            case "Alt":
            case "Shift":
                {
                    this.updateShapes();
                }
        }
    }
    complete() {
        this.updateShapes();
        this.editor.setCurrentTool("select.crop.idle", this.info);
    }
    cancel() {
        this.editor.bailToMark(this.markId);
        this.editor.setCurrentTool("select.crop.idle", this.info);
    }
    createSnapshot() {
        const shape = this.editor.getOnlySelectedShape();
        return {
            shape
        };
    }
    updateShapes() {
        const shape = this.snapshot.shape;
        if (!shape) return;
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const delta = currentPagePoint.clone().sub(originPagePoint);
        const partial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$crop_helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslateCroppedImageChange"])(this.editor, shape, delta);
        if (partial) {
            this.editor.updateShapes([
                partial
            ]);
        }
    }
}
;
 //# sourceMappingURL=TranslatingCrop.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/Crop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Crop",
    ()=>Crop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Cropping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/Cropping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/PointingCrop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCropHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/PointingCropHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$TranslatingCrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/TranslatingCrop.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
class Crop extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "crop";
    static initial = "idle";
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$TranslatingCrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TranslatingCrop"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingCrop"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCropHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingCropHandle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Cropping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cropping"]
        ];
    }
    markId = "";
    onEnter() {
        this.didExit = false;
        this.markId = this.editor.markHistoryStoppingPoint("crop");
    }
    didExit = false;
    onExit() {
        if (!this.didExit) {
            this.didExit = true;
            this.editor.squashToMark(this.markId);
        }
    }
    onCancel() {
        if (!this.didExit) {
            this.didExit = true;
            this.editor.bailToMark(this.markId);
        }
    }
}
;
 //# sourceMappingURL=Crop.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/DraggingHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DraggingHandle",
    ()=>DraggingHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowTargetState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/shared.mjs [app-client] (ecmascript)");
;
;
;
class DraggingHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "dragging_handle";
    shapeId;
    initialHandle;
    initialAdjacentHandle;
    initialPagePoint;
    markId;
    initialPageTransform;
    initialPageRotation;
    info;
    isPrecise = false;
    isPreciseId = null;
    pointingId = null;
    onEnter(info) {
        const { shape, isCreating, creatingMarkId, handle } = info;
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.shapeId = shape.id;
        this.markId = "";
        if (isCreating) {
            if (creatingMarkId) {
                this.markId = creatingMarkId;
            } else {
                const markId = this.editor.getMarkIdMatching(`creating:${this.editor.getOnlySelectedShapeId()}`);
                if (markId) {
                    this.markId = markId;
                }
            }
        } else {
            this.markId = this.editor.markHistoryStoppingPoint("dragging handle");
        }
        this.initialHandle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(handle);
        this.initialPageTransform = this.editor.getShapePageTransform(shape);
        this.initialPageRotation = this.initialPageTransform.rotation();
        this.initialPagePoint = this.editor.inputs.getOriginPagePoint().clone();
        this.editor.setCursor({
            type: isCreating ? "cross" : "grabbing",
            rotation: 0
        });
        const handles = this.editor.getShapeHandles(shape).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
        const index = handles.findIndex((h)=>h.id === info.handle.id);
        this.initialAdjacentHandle = null;
        if (info.handle.snapReferenceHandleId) {
            const customHandle = handles.find((h)=>h.id === info.handle.snapReferenceHandleId);
            if (customHandle) {
                this.initialAdjacentHandle = customHandle;
            }
        }
        if (!this.initialAdjacentHandle) {
            for(let i = index + 1; i < handles.length; i++){
                const handle2 = handles[i];
                if (handle2.type === "vertex" && handle2.id !== "middle" && handle2.id !== info.handle.id) {
                    this.initialAdjacentHandle = handle2;
                    break;
                }
            }
            if (!this.initialAdjacentHandle) {
                for(let i = handles.length - 1; i >= 0; i--){
                    const handle2 = handles[i];
                    if (handle2.type === "vertex" && handle2.id !== "middle" && handle2.id !== info.handle.id) {
                        this.initialAdjacentHandle = handle2;
                        break;
                    }
                }
            }
        }
        if (this.editor.isShapeOfType(shape, "arrow")) {
            const initialBinding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(this.editor, shape)[info.handle.id];
            this.isPrecise = false;
            if (initialBinding) {
                this.isPrecise = initialBinding.props.isPrecise;
                if (this.isPrecise) {
                    this.isPreciseId = initialBinding.toId;
                } else {
                    this.resetExactTimeout();
                }
            }
        }
        const handleDragInfo = {
            handle: this.initialHandle,
            isPrecise: this.isPrecise,
            isCreatingShape: !!this.info.isCreating,
            initial: shape
        };
        const util = this.editor.getShapeUtil(shape);
        const startChanges = util.onHandleDragStart?.(shape, handleDragInfo);
        if (startChanges) {
            this.editor.updateShapes([
                {
                    ...startChanges,
                    id: shape.id,
                    type: shape.type
                }
            ]);
        }
        this.update();
        this.editor.select(this.shapeId);
    }
    // Only relevant to arrows
    exactTimeout = -1;
    // Only relevant to arrows
    resetExactTimeout() {
        const arrowUtil = this.editor.getShapeUtil("arrow");
        const timeoutValue = arrowUtil.options.pointingPreciseTimeout;
        if (this.exactTimeout !== -1) {
            this.clearExactTimeout();
        }
        this.exactTimeout = this.editor.timers.setTimeout(()=>{
            if (this.getIsActive() && !this.isPrecise) {
                this.isPrecise = true;
                this.isPreciseId = this.pointingId;
                this.update();
            }
            this.exactTimeout = -1;
        }, timeoutValue);
    }
    // Only relevant to arrows
    clearExactTimeout() {
        if (this.exactTimeout !== -1) {
            clearTimeout(this.exactTimeout);
            this.exactTimeout = -1;
        }
    }
    onPointerMove() {
        this.update();
    }
    onKeyDown() {
        this.update();
    }
    onKeyUp() {
        this.update();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.update();
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearArrowTargetState"])(this.editor);
        this.editor.snaps.clearIndicators();
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    complete() {
        this.editor.snaps.clearIndicators();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, [
            this.shapeId
        ]);
        const shape = this.editor.getShape(this.shapeId);
        if (shape) {
            const util = this.editor.getShapeUtil(shape);
            const handleDragInfo = {
                handle: this.initialHandle,
                isPrecise: this.isPrecise,
                isCreatingShape: !!this.info.isCreating,
                initial: this.info.shape
            };
            const endChanges = util.onHandleDragEnd?.(shape, handleDragInfo);
            if (endChanges) {
                this.editor.updateShapes([
                    {
                        ...endChanges,
                        id: shape.id
                    }
                ]);
            }
        }
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                if (this.editor.getInstanceState().isToolLocked && onInteractionEnd) {
                    this.editor.setCurrentTool(onInteractionEnd, {
                        shapeId: this.shapeId
                    });
                    return;
                }
            } else {
                onInteractionEnd?.();
                return;
            }
        }
        this.parent.transition("idle");
    }
    cancel() {
        const shape = this.editor.getShape(this.shapeId);
        if (shape) {
            const util = this.editor.getShapeUtil(shape);
            const handleDragInfo = {
                handle: this.initialHandle,
                isPrecise: this.isPrecise,
                isCreatingShape: !!this.info.isCreating,
                initial: this.info.shape
            };
            util.onHandleDragCancel?.(shape, handleDragInfo);
        }
        this.editor.bailToMark(this.markId);
        this.editor.snaps.clearIndicators();
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {
                    shapeId: this.shapeId
                });
            } else {
                onInteractionEnd?.();
            }
            return;
        }
        this.parent.transition("idle");
    }
    update() {
        const { editor, shapeId, initialPagePoint } = this;
        const { initialHandle, initialPageRotation, initialAdjacentHandle } = this;
        const isSnapMode = this.editor.user.getIsSnapMode();
        const { snaps } = editor;
        const currentPagePoint = editor.inputs.getCurrentPagePoint();
        const shiftKey = editor.inputs.getShiftKey();
        const ctrlKey = editor.inputs.getCtrlKey();
        const altKey = editor.inputs.getAltKey();
        const pointerVelocity = editor.inputs.getPointerVelocity();
        const initial = this.info.shape;
        const shape = editor.getShape(shapeId);
        if (!shape) return;
        const util = editor.getShapeUtil(shape);
        const initialBinding = editor.isShapeOfType(shape, "arrow") ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, shape)[initialHandle.id] : void 0;
        let point = currentPagePoint.clone().sub(initialPagePoint).rot(-initialPageRotation).add(initialHandle);
        if (shiftKey && initialAdjacentHandle && initialHandle.id !== "middle") {
            const angle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(initialAdjacentHandle, point);
            const snappedAngle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapAngle"])(angle, 24);
            const angleDifference = snappedAngle - angle;
            point = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(point, initialAdjacentHandle, angleDifference);
        }
        editor.snaps.clearIndicators();
        let nextHandle = {
            ...initialHandle,
            x: point.x,
            y: point.y
        };
        let canSnap = false;
        if (initialHandle.canSnap && initialHandle.snapType) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warnOnce"])("canSnap is deprecated. Cannot use both canSnap and snapType together - snapping disabled. Please use only snapType.");
        } else {
            canSnap = initialHandle.canSnap || initialHandle.snapType !== void 0;
        }
        if (canSnap && (isSnapMode ? !ctrlKey : ctrlKey)) {
            const pageTransform = editor.getShapePageTransform(shape.id);
            if (!pageTransform) throw Error("Expected a page transform");
            const snap = snaps.handles.snapHandle({
                currentShapeId: shapeId,
                handle: nextHandle
            });
            if (snap) {
                snap.nudge.rot(-editor.getShapeParentTransform(shape).rotation());
                point.add(snap.nudge);
                nextHandle = {
                    ...initialHandle,
                    x: point.x,
                    y: point.y
                };
            }
        }
        const changes = util.onHandleDrag?.(shape, {
            handle: nextHandle,
            isPrecise: this.isPrecise || altKey,
            isCreatingShape: !!this.info.isCreating,
            initial
        });
        const next = {
            id: shape.id,
            type: shape.type,
            ...changes
        };
        if (initialHandle.type === "vertex" && this.editor.isShapeOfType(shape, "arrow")) {
            const bindingAfter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, shape)[initialHandle.id];
            if (bindingAfter) {
                if (initialBinding?.toId !== bindingAfter.toId) {
                    this.pointingId = bindingAfter.toId;
                    this.isPrecise = pointerVelocity.len() < 0.5 || altKey;
                    this.isPreciseId = this.isPrecise ? bindingAfter.toId : null;
                    this.resetExactTimeout();
                }
            } else {
                if (initialBinding) {
                    this.pointingId = null;
                    this.isPrecise = false;
                    this.isPreciseId = null;
                    this.resetExactTimeout();
                }
            }
        }
        if (changes) {
            editor.updateShapes([
                next
            ]);
        }
    }
}
;
 //# sourceMappingURL=DraggingHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/EditingShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EditingShape",
    ()=>EditingShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$shapes$2f$shapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/shapes/shapes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/richText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/getHitShapeOnCanvasPointerDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/updateHoveredShapeId.mjs [app-client] (ecmascript)");
;
;
;
;
;
class EditingShape extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "editing_shape";
    hitLabelOnShapeForPointerUp = null;
    info = {};
    didPointerDownOnEditingShape = false;
    isTextInputFocused() {
        const container = this.editor.getContainer();
        return container.contains(document.activeElement) && (document.activeElement?.nodeName === "INPUT" || document.activeElement?.nodeName === "TEXTAREA" || document.activeElement?.isContentEditable);
    }
    onEnter(info) {
        const editingShape = this.editor.getEditingShape();
        if (!editingShape) throw Error("Entered editing state without an editing shape");
        this.hitLabelOnShapeForPointerUp = null;
        this.didPointerDownOnEditingShape = false;
        this.info = info;
        if (info.isCreatingTextWhileToolLocked) {
            this.parent.setCurrentToolIdMask("text");
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(this.editor);
        this.editor.select(editingShape);
    }
    onExit() {
        const { editingShapeId } = this.editor.getCurrentPageState();
        if (!editingShapeId) return;
        this.editor.setEditingShape(null);
        __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"].cancel();
        if (this.info.isCreatingTextWhileToolLocked) {
            this.parent.setCurrentToolIdMask(void 0);
            this.editor.setCurrentTool("text", {});
        }
    }
    onPointerMove(info) {
        if (this.hitLabelOnShapeForPointerUp && this.editor.inputs.getIsDragging()) {
            if (this.editor.getIsReadonly()) return;
            if (this.hitLabelOnShapeForPointerUp.isLocked) return;
            this.editor.select(this.hitLabelOnShapeForPointerUp);
            this.parent.transition("translating", info);
            this.hitLabelOnShapeForPointerUp = null;
            return;
        }
        if (this.didPointerDownOnEditingShape && this.editor.inputs.isDragging) {
            if (this.editor.getIsReadonly()) return;
            const editingShape = this.editor.getEditingShape();
            if (!editingShape || editingShape.isLocked) return;
            if (!this.isTextInputFocused()) {
                this.editor.select(editingShape);
                this.parent.transition("translating", info);
                this.didPointerDownOnEditingShape = false;
                return;
            }
            this.didPointerDownOnEditingShape = false;
        }
        switch(info.target){
            case "shape":
            case "canvas":
                {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(this.editor);
                    return;
                }
        }
    }
    onPointerDown(info) {
        this.hitLabelOnShapeForPointerUp = null;
        this.didPointerDownOnEditingShape = false;
        switch(info.target){
            // N.B. This bit of logic has a bit of history to it.
            // There was a PR that got rid of this logic: https://github.com/tldraw/tldraw/pull/4237
            // But here we bring it back to help support the new rich text world.
            // The original issue which is visible in the video attachments in the PR now seem
            // to have been resolved anyway via some other layer.
            case "canvas":
                {
                    const hitShape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHitShapeOnCanvasPointerDown"])(this.editor, true);
                    if (hitShape) {
                        this.onPointerDown({
                            ...info,
                            shape: hitShape,
                            target: "shape"
                        });
                        return;
                    }
                    break;
                }
            case "shape":
                {
                    const { shape: selectingShape } = info;
                    const editingShape = this.editor.getEditingShape();
                    if (!editingShape) {
                        throw Error("Expected an editing shape!");
                    }
                    const geometry = this.editor.getShapeUtil(selectingShape).getGeometry(selectingShape);
                    const textLabels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$shapes$2f$shapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTextLabels"])(geometry);
                    const textLabel = textLabels.length === 1 ? textLabels[0] : void 0;
                    const isEmptyTextShape = this.editor.isShapeOfType(editingShape, "text") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderPlaintextFromRichText"])(this.editor, editingShape.props.richText).trim() === "";
                    if (textLabel && !isEmptyTextShape) {
                        const pointInShapeSpace = this.editor.getPointInShapeSpace(selectingShape, this.editor.inputs.getCurrentPagePoint());
                        if (textLabel.bounds.containsPoint(pointInShapeSpace, 0) && textLabel.hitTestPoint(pointInShapeSpace)) {
                            if (selectingShape.id === editingShape.id) {
                                this.didPointerDownOnEditingShape = true;
                                return;
                            } else {
                                this.hitLabelOnShapeForPointerUp = selectingShape;
                                this.editor.markHistoryStoppingPoint("editing on pointer up");
                                this.editor.select(selectingShape.id);
                                return;
                            }
                        }
                    } else {
                        if (selectingShape.id === editingShape.id) {
                            if (this.editor.isShapeOfType(selectingShape, "frame")) {
                                this.editor.setEditingShape(null);
                                this.parent.transition("idle", info);
                            }
                        } else {
                            this.parent.transition("pointing_shape", info);
                            return;
                        }
                        return;
                    }
                    break;
                }
        }
        this.parent.transition("idle", info);
        this.editor.root.handleEvent(info);
    }
    onPointerUp(info) {
        if (this.didPointerDownOnEditingShape) {
            this.didPointerDownOnEditingShape = false;
            if (!this.isTextInputFocused()) {
                this.editor.getRichTextEditor()?.commands.focus("all");
                return;
            }
        }
        const hitShape = this.hitLabelOnShapeForPointerUp;
        if (!hitShape) return;
        this.hitLabelOnShapeForPointerUp = null;
        const util = this.editor.getShapeUtil(hitShape);
        if (hitShape.isLocked) return;
        if (this.editor.getIsReadonly()) {
            if (!util.canEditInReadonly(hitShape)) {
                this.parent.transition("pointing_shape", info);
                return;
            }
        }
        this.editor.select(hitShape.id);
        const currentEditingShape = this.editor.getEditingShape();
        const isEditToEditAction = currentEditingShape && currentEditingShape.id !== hitShape.id;
        this.editor.setEditingShape(hitShape.id);
        const isMobile = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isIos || __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isAndroid;
        if (!isMobile || !isEditToEditAction) {
            this.editor.emit("place-caret", {
                shapeId: hitShape.id,
                point: info.point
            });
        } else if (isMobile && isEditToEditAction) {
            this.editor.emit("select-all-text", {
                shapeId: hitShape.id
            });
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(this.editor);
    }
    onComplete(info) {
        this.editor.getContainer().focus();
        this.parent.transition("idle", info);
    }
    onCancel(info) {
        this.editor.getContainer().focus();
        this.parent.transition("idle", info);
    }
}
;
 //# sourceMappingURL=EditingShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/selectOnCanvasPointerUp.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectOnCanvasPointerUp",
    ()=>selectOnCanvasPointerUp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
;
function selectOnCanvasPointerUp(editor, info) {
    const selectedShapeIds = editor.getSelectedShapeIds();
    const currentPagePoint = editor.inputs.getCurrentPagePoint();
    const { shiftKey, altKey, accelKey } = info;
    const additiveSelectionKey = shiftKey || accelKey;
    const hitShape = editor.getShapeAtPoint(currentPagePoint, {
        hitInside: false,
        margin: editor.options.hitTestMargin / editor.getZoomLevel(),
        hitLabels: true,
        renderingOnly: true,
        filter: (shape)=>!shape.isLocked
    });
    if (hitShape) {
        const outermostSelectableShape = editor.getOutermostSelectableShape(hitShape);
        if (additiveSelectionKey && !altKey) {
            editor.cancelDoubleClick();
            if (selectedShapeIds.includes(outermostSelectableShape.id)) {
                editor.markHistoryStoppingPoint("deselecting shape");
                editor.deselect(outermostSelectableShape);
            } else {
                editor.markHistoryStoppingPoint("shift selecting shape");
                editor.setSelectedShapes([
                    ...selectedShapeIds,
                    outermostSelectableShape.id
                ]);
            }
        } else {
            let shapeToSelect = void 0;
            if (outermostSelectableShape === hitShape) {
                shapeToSelect = hitShape;
            } else {
                if (outermostSelectableShape.id === editor.getFocusedGroupId() || selectedShapeIds.includes(outermostSelectableShape.id)) {
                    shapeToSelect = hitShape;
                } else {
                    shapeToSelect = outermostSelectableShape;
                }
            }
            if (shapeToSelect && !selectedShapeIds.includes(shapeToSelect.id)) {
                editor.markHistoryStoppingPoint("selecting shape");
                editor.select(shapeToSelect.id);
            }
        }
    } else {
        if (additiveSelectionKey) {
            return;
        } else {
            if (selectedShapeIds.length > 0) {
                editor.markHistoryStoppingPoint("selecting none");
                editor.selectNone();
            }
            const focusedGroupId = editor.getFocusedGroupId();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(focusedGroupId)) {
                const groupShape = editor.getShape(focusedGroupId);
                if (!editor.isPointInShape(groupShape, currentPagePoint, {
                    margin: 0,
                    hitInside: true
                })) {
                    editor.setFocusedGroup(null);
                }
            }
        }
    }
}
;
 //# sourceMappingURL=selectOnCanvasPointerUp.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_INCREMENT",
    ()=>GRID_INCREMENT,
    "Idle",
    ()=>Idle,
    "MAJOR_NUDGE_FACTOR",
    ()=>MAJOR_NUDGE_FACTOR,
    "MINOR_NUDGE_FACTOR",
    ()=>MINOR_NUDGE_FACTOR
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/debug-flags.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/getHitShapeOnCanvasPointerDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/selectOnCanvasPointerUp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/updateHoveredShapeId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/selectHelpers.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const SKIPPED_KEYS_FOR_AUTO_EDITING = [
    "Delete",
    "Backspace",
    "[",
    "]",
    "Enter",
    " ",
    "Shift",
    "Tab"
];
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    selectedShapesOnKeyDown = [];
    onEnter() {
        this.parent.setCurrentToolIdMask(void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(this.editor);
        this.selectedShapesOnKeyDown = [];
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    onExit() {
        __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"].cancel();
    }
    onPointerMove() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(this.editor);
    }
    onPointerDown(info) {
        switch(info.target){
            case "canvas":
                {
                    const hitShape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$getHitShapeOnCanvasPointerDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHitShapeOnCanvasPointerDown"])(this.editor);
                    if (hitShape && !hitShape.isLocked) {
                        this.onPointerDown({
                            ...info,
                            shape: hitShape,
                            target: "shape"
                        });
                        return;
                    }
                    const selectedShapeIds = this.editor.getSelectedShapeIds();
                    const onlySelectedShape = this.editor.getOnlySelectedShape();
                    const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
                    if (selectedShapeIds.length > 1 || onlySelectedShape && !this.editor.getShapeUtil(onlySelectedShape).hideSelectionBoundsBg(onlySelectedShape)) {
                        if (isPointInRotatedSelectionBounds(this.editor, currentPagePoint)) {
                            this.onPointerDown({
                                ...info,
                                target: "selection"
                            });
                            return;
                        }
                    }
                    this.parent.transition("pointing_canvas", info);
                    break;
                }
            case "shape":
                {
                    const { shape } = info;
                    if (this.editor.isShapeOrAncestorLocked(shape)) {
                        this.parent.transition("pointing_canvas", info);
                        break;
                    }
                    this.parent.transition("pointing_shape", info);
                    break;
                }
            case "handle":
                {
                    if (this.editor.getIsReadonly()) break;
                    if (this.editor.inputs.getAltKey()) {
                        this.parent.transition("pointing_shape", info);
                    } else {
                        this.parent.transition("pointing_handle", info);
                    }
                    break;
                }
            case "selection":
                {
                    switch(info.handle){
                        case "mobile_rotate":
                        case "top_left_rotate":
                        case "top_right_rotate":
                        case "bottom_left_rotate":
                        case "bottom_right_rotate":
                            {
                                if (info.accelKey) {
                                    this.parent.transition("brushing", info);
                                    break;
                                }
                                this.parent.transition("pointing_rotate_handle", info);
                                break;
                            }
                        case "top":
                        case "right":
                        case "bottom":
                        case "left":
                        case "top_left":
                        case "top_right":
                        case "bottom_left":
                        case "bottom_right":
                            {
                                const onlySelectedShape = this.editor.getOnlySelectedShape();
                                if (info.ctrlKey && this.editor.canCropShape(onlySelectedShape)) {
                                    this.parent.transition("crop.pointing_crop_handle", info);
                                } else {
                                    if (info.accelKey) {
                                        this.parent.transition("brushing", info);
                                        break;
                                    }
                                    this.parent.transition("pointing_resize_handle", info);
                                }
                                break;
                            }
                        default:
                            {
                                const hoveredShape = this.editor.getHoveredShape();
                                if (hoveredShape && !this.editor.getSelectedShapeIds().includes(hoveredShape.id) && !hoveredShape.isLocked) {
                                    this.onPointerDown({
                                        ...info,
                                        shape: hoveredShape,
                                        target: "shape"
                                    });
                                    return;
                                }
                                this.parent.transition("pointing_selection", info);
                            }
                    }
                    break;
                }
        }
    }
    onDoubleClick(info) {
        if (this.editor.inputs.getShiftKey() || info.phase !== "up") return;
        if (info.ctrlKey || info.shiftKey) return;
        switch(info.target){
            case "canvas":
                {
                    const hoveredShape = this.editor.getHoveredShape();
                    const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
                    const hitShape = hoveredShape && !this.editor.isShapeOfType(hoveredShape, "group") ? hoveredShape : this.editor.getSelectedShapeAtPoint(currentPagePoint) ?? this.editor.getShapeAtPoint(currentPagePoint, {
                        margin: this.editor.options.hitTestMargin / this.editor.getZoomLevel(),
                        hitInside: false
                    });
                    const focusedGroupId = this.editor.getFocusedGroupId();
                    if (hitShape) {
                        if (this.editor.isShapeOfType(hitShape, "group")) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectOnCanvasPointerUp"])(this.editor, info);
                            return;
                        } else {
                            const parent = this.editor.getShape(hitShape.parentId);
                            if (parent && this.editor.isShapeOfType(parent, "group")) {
                                if (focusedGroupId && parent.id === focusedGroupId) {} else {
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectOnCanvasPointerUp"])(this.editor, info);
                                    return;
                                }
                            }
                        }
                        this.onDoubleClick({
                            ...info,
                            shape: hitShape,
                            target: "shape"
                        });
                        return;
                    }
                    if (!this.editor.inputs.getShiftKey()) {
                        this.handleDoubleClickOnCanvas(info);
                    }
                    break;
                }
            case "selection":
                {
                    const onlySelectedShape = this.editor.getOnlySelectedShape();
                    if (onlySelectedShape) {
                        const util = this.editor.getShapeUtil(onlySelectedShape);
                        const isEdge = info.handle === "right" || info.handle === "left" || info.handle === "top" || info.handle === "bottom";
                        const isCorner = info.handle === "top_left" || info.handle === "top_right" || info.handle === "bottom_right" || info.handle === "bottom_left";
                        if (this.editor.getIsReadonly()) {
                            if (this.editor.canEditShape(onlySelectedShape, {
                                type: isCorner ? "double-click-corner" : isEdge ? "double-click-edge" : "double-click"
                            })) {
                                this.startEditingShape(onlySelectedShape, info, true);
                            }
                            break;
                        }
                        if (isEdge) {
                            const change = util.onDoubleClickEdge?.(onlySelectedShape, info);
                            if (change) {
                                this.editor.markHistoryStoppingPoint("double click edge");
                                this.editor.updateShapes([
                                    change
                                ]);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, [
                                    onlySelectedShape.id
                                ]);
                                return;
                            }
                        }
                        if (isCorner) {
                            const change = util.onDoubleClickCorner?.(onlySelectedShape, info);
                            if (change) {
                                this.editor.markHistoryStoppingPoint("double click corner");
                                this.editor.updateShapes([
                                    change
                                ]);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, [
                                    onlySelectedShape.id
                                ]);
                                return;
                            }
                        }
                        if (this.editor.canCropShape(onlySelectedShape)) {
                            this.parent.transition("crop", info);
                            return;
                        }
                        if (this.editor.canEditShape(onlySelectedShape)) {
                            this.startEditingShape(onlySelectedShape, info, true);
                        }
                    }
                    break;
                }
            case "shape":
                {
                    const { shape } = info;
                    const util = this.editor.getShapeUtil(shape);
                    if (shape.type !== "video" && shape.type !== "embed" && this.editor.getIsReadonly()) break;
                    if (util.onDoubleClick) {
                        const change = util.onDoubleClick?.(shape);
                        if (change) {
                            this.editor.updateShapes([
                                change
                            ]);
                            return;
                        }
                    }
                    if (util.canCrop(shape) && !this.editor.isShapeOrAncestorLocked(shape)) {
                        this.editor.markHistoryStoppingPoint("select and crop");
                        this.editor.select(info.shape?.id);
                        this.parent.transition("crop", info);
                        return;
                    }
                    if (this.editor.canEditShape(shape)) {
                        this.startEditingShape(shape, info, true);
                    } else {
                        this.handleDoubleClickOnCanvas(info);
                    }
                    break;
                }
            case "handle":
                {
                    if (this.editor.getIsReadonly()) break;
                    const { shape, handle } = info;
                    const util = this.editor.getShapeUtil(shape);
                    const changes = util.onDoubleClickHandle?.(shape, handle);
                    if (changes) {
                        this.editor.updateShapes([
                            changes
                        ]);
                    } else {
                        if (this.editor.canEditShape(shape)) {
                            this.startEditingShape(shape, info, true);
                        }
                    }
                }
        }
    }
    onRightClick(info) {
        switch(info.target){
            case "canvas":
                {
                    const hoveredShape = this.editor.getHoveredShape();
                    const hitShape = hoveredShape && !this.editor.isShapeOfType(hoveredShape, "group") ? hoveredShape : this.editor.getShapeAtPoint(this.editor.inputs.getCurrentPagePoint(), {
                        margin: this.editor.options.hitTestMargin / this.editor.getZoomLevel(),
                        hitInside: false,
                        hitLabels: true,
                        hitLocked: true,
                        hitFrameInside: true,
                        renderingOnly: true
                    });
                    if (hitShape) {
                        this.onRightClick({
                            ...info,
                            shape: hitShape,
                            target: "shape"
                        });
                        return;
                    }
                    const selectedShapeIds = this.editor.getSelectedShapeIds();
                    const onlySelectedShape = this.editor.getOnlySelectedShape();
                    const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
                    if (selectedShapeIds.length > 1 || onlySelectedShape && !this.editor.getShapeUtil(onlySelectedShape).hideSelectionBoundsBg(onlySelectedShape)) {
                        if (isPointInRotatedSelectionBounds(this.editor, currentPagePoint)) {
                            this.onRightClick({
                                ...info,
                                target: "selection"
                            });
                            return;
                        }
                    }
                    this.editor.selectNone();
                    break;
                }
            case "shape":
                {
                    const { selectedShapeIds } = this.editor.getCurrentPageState();
                    const { shape } = info;
                    const targetShape = this.editor.getOutermostSelectableShape(shape, (parent)=>!selectedShapeIds.includes(parent.id));
                    if (!selectedShapeIds.includes(targetShape.id) && !this.editor.findShapeAncestor(targetShape, (shape2)=>selectedShapeIds.includes(shape2.id))) {
                        this.editor.markHistoryStoppingPoint("selecting shape");
                        this.editor.setSelectedShapes([
                            targetShape.id
                        ]);
                    }
                    break;
                }
        }
    }
    onCancel() {
        if (this.editor.getFocusedGroupId() !== this.editor.getCurrentPageId() && this.editor.getSelectedShapeIds().length > 0) {
            this.editor.popFocusedGroupId();
        } else {
            this.editor.markHistoryStoppingPoint("clearing selection");
            this.editor.selectNone();
        }
    }
    onKeyDown(info) {
        this.selectedShapesOnKeyDown = this.editor.getSelectedShapes();
        switch(info.code){
            case "ArrowLeft":
            case "ArrowRight":
            case "ArrowUp":
            case "ArrowDown":
                {
                    if (info.accelKey) {
                        if (info.shiftKey) {
                            if (info.code === "ArrowDown") {
                                this.editor.selectFirstChildShape();
                            } else if (info.code === "ArrowUp") {
                                this.editor.selectParentShape();
                            }
                        } else {
                            this.editor.selectAdjacentShape(info.code.replace("Arrow", "").toLowerCase());
                        }
                        return;
                    }
                    this.nudgeSelectedShapes(false);
                    return;
                }
        }
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugFlags"]["editOnType"].get()) {
            if (!SKIPPED_KEYS_FOR_AUTO_EDITING.includes(info.key) && !info.altKey && !info.ctrlKey) {
                const onlySelectedShape = this.editor.getOnlySelectedShape();
                if (onlySelectedShape && // If it's a note shape, then edit on type
                this.editor.isShapeOfType(onlySelectedShape, "note") && // If it's not locked or anything
                this.editor.canEditShape(onlySelectedShape)) {
                    this.startEditingShape(onlySelectedShape, {
                        ...info,
                        target: "shape",
                        shape: onlySelectedShape
                    }, true);
                    return;
                }
            }
        }
    }
    onKeyRepeat(info) {
        switch(info.code){
            case "ArrowLeft":
            case "ArrowRight":
            case "ArrowUp":
            case "ArrowDown":
                {
                    if (info.accelKey) {
                        this.editor.selectAdjacentShape(info.code.replace("Arrow", "").toLowerCase());
                        return;
                    }
                    this.nudgeSelectedShapes(true);
                    break;
                }
            case "Tab":
                {
                    const selectedShapes = this.editor.getSelectedShapes();
                    if (selectedShapes.length && !info.altKey) {
                        this.editor.selectAdjacentShape(info.shiftKey ? "prev" : "next");
                    }
                    break;
                }
        }
    }
    onKeyUp(info) {
        switch(info.key){
            case "Enter":
                {
                    if (!this.selectedShapesOnKeyDown.length) return;
                    const selectedShapes = this.editor.getSelectedShapes();
                    if (selectedShapes.every((shape)=>this.editor.isShapeOfType(shape, "group"))) {
                        this.editor.setSelectedShapes(selectedShapes.flatMap((shape)=>this.editor.getSortedChildIdsForParent(shape.id)));
                        return;
                    }
                    const onlySelectedShape = this.editor.getOnlySelectedShape();
                    if (onlySelectedShape && this.editor.canEditShape(onlySelectedShape, {
                        type: "press_enter"
                    })) {
                        this.startEditingShape(onlySelectedShape, {
                            ...info,
                            target: "shape",
                            shape: onlySelectedShape
                        }, true);
                        return;
                    }
                    if (this.editor.canCropShape(onlySelectedShape)) {
                        this.parent.transition("crop", info);
                    }
                    break;
                }
            case "Tab":
                {
                    const selectedShapes = this.editor.getSelectedShapes();
                    if (selectedShapes.length && !info.altKey) {
                        this.editor.selectAdjacentShape(info.shiftKey ? "prev" : "next");
                    }
                    break;
                }
        }
    }
    startEditingShape(shape, info, shouldSelectAll) {
        const { editor } = this;
        this.editor.markHistoryStoppingPoint("editing shape");
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasRichText"])(shape)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(editor, shape, {
                selectAll: shouldSelectAll
            });
        } else {
            editor.setEditingShape(shape);
        }
        this.parent.transition("editing_shape", info);
    }
    isOverArrowLabelTest(shape) {
        if (!shape) return false;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOverArrowLabel"])(this.editor, shape);
    }
    handleDoubleClickOnCanvas(info) {
        if (this.editor.getIsReadonly()) return;
        if (!this.editor.options.createTextOnCanvasDoubleClick) return;
        this.editor.markHistoryStoppingPoint("creating text shape");
        const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
        const { x, y } = this.editor.inputs.getCurrentPagePoint();
        this.editor.createShapes([
            {
                id,
                type: "text",
                x,
                y,
                props: {
                    richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(""),
                    autoSize: true
                }
            }
        ]);
        const shape = this.editor.getShape(id);
        if (!shape) return;
        if (!this.editor.canEditShape(shape)) return;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(this.editor, id, {
            info
        });
    }
    nudgeSelectedShapes(ephemeral = false) {
        const { editor: { inputs: { keys } } } = this;
        const shiftKey = keys.has("ShiftLeft");
        const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
        if (keys.has("ArrowLeft")) delta.x -= 1;
        if (keys.has("ArrowRight")) delta.x += 1;
        if (keys.has("ArrowUp")) delta.y -= 1;
        if (keys.has("ArrowDown")) delta.y += 1;
        if (delta.equals(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0))) return;
        if (!ephemeral) this.editor.markHistoryStoppingPoint("nudge shapes");
        const { gridSize } = this.editor.getDocumentSettings();
        const step = this.editor.getInstanceState().isGridMode ? shiftKey ? gridSize * GRID_INCREMENT : gridSize : shiftKey ? MAJOR_NUDGE_FACTOR : MINOR_NUDGE_FACTOR;
        const selectedShapeIds = this.editor.getSelectedShapeIds();
        this.editor.nudgeShapes(selectedShapeIds, delta.mul(step));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, selectedShapeIds);
    }
}
const MAJOR_NUDGE_FACTOR = 10;
const MINOR_NUDGE_FACTOR = 1;
const GRID_INCREMENT = 5;
function isPointInRotatedSelectionBounds(editor, point) {
    const selectionBounds = editor.getSelectionRotatedPageBounds();
    if (!selectionBounds) return false;
    const selectionRotation = editor.getSelectionRotation();
    if (!selectionRotation) return selectionBounds.containsPoint(point);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(point, selectionBounds.corners.map((c)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(c, selectionBounds.point, selectionRotation)));
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingArrowLabel.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingArrowLabel",
    ()=>PointingArrowLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/selectHelpers.mjs [app-client] (ecmascript)");
;
;
;
class PointingArrowLabel extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_arrow_label";
    shapeId = "";
    markId = "";
    wasAlreadySelected = false;
    didDrag = false;
    didCtrlOnEnter = false;
    info = {};
    updateCursor() {
        this.editor.setCursor({
            type: "grabbing",
            rotation: 0
        });
    }
    onEnter(info) {
        const { shape } = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.info = info;
        this.shapeId = shape.id;
        this.didDrag = false;
        this.didCtrlOnEnter = info.accelKey;
        this.wasAlreadySelected = this.editor.getOnlySelectedShapeId() === shape.id;
        this.updateCursor();
        const geometry = this.editor.getShapeGeometry(shape);
        const labelGeometry = geometry.children[1];
        if (!labelGeometry) {
            throw Error(`Expected to find an arrow label geometry for shape: ${shape.id}`);
        }
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const pointInShapeSpace = this.editor.getPointInShapeSpace(shape, currentPagePoint);
        this._labelDragOffset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(labelGeometry.center, pointInShapeSpace);
        this.markId = this.editor.markHistoryStoppingPoint("label-drag start");
        const additiveSelectionKey = info.shiftKey || info.accelKey;
        if (additiveSelectionKey) {
            const selectedShapeIds = this.editor.getSelectedShapeIds();
            this.editor.setSelectedShapes([
                ...selectedShapeIds,
                this.shapeId
            ]);
            return;
        }
        this.editor.setSelectedShapes([
            this.shapeId
        ]);
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    _labelDragOffset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
    onPointerMove() {
        const isDragging = this.editor.inputs.getIsDragging();
        if (!isDragging) return;
        if (this.didCtrlOnEnter) {
            this.parent.transition("brushing", this.info);
            return;
        }
        const shape = this.editor.getShape(this.shapeId);
        if (!shape) return;
        const options = this.editor.getShapeUtil("arrow").options;
        const geometry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBodyGeometry"])(this.editor, shape);
        const transform = this.editor.getShapePageTransform(shape.id);
        const pointInShapeSpace = this.editor.getPointInShapeSpace(shape, this.editor.inputs.getCurrentPagePoint()).add(this._labelDragOffset);
        const defaultLabelPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowLabelDefaultPosition"])(this.editor, shape);
        let nextLabelPosition = geometry.uninterpolateAlongEdge(pointInShapeSpace);
        if (isNaN(nextLabelPosition)) {
            nextLabelPosition = defaultLabelPosition;
        }
        const nextLabelPoint = transform.applyToPoint(geometry.interpolateAlongEdge(nextLabelPosition));
        const labelDefaultPoint = transform.applyToPoint(geometry.interpolateAlongEdge(defaultLabelPosition));
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].DistMin(nextLabelPoint, labelDefaultPoint, options.labelCenterSnapDistance / this.editor.getZoomLevel())) {
            nextLabelPosition = defaultLabelPosition;
        }
        this.didDrag = true;
        this.editor.updateShape({
            id: shape.id,
            type: shape.type,
            props: {
                labelPosition: nextLabelPosition
            }
        });
    }
    onPointerUp() {
        const shape = this.editor.getShape(this.shapeId);
        if (!shape) return;
        if (this.didDrag || !this.wasAlreadySelected) {
            this.complete();
        } else if (this.editor.canEditShape(shape)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(this.editor, shape.id);
        }
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    complete() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
    cancel() {
        this.editor.bailToMark(this.markId);
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingArrowLabel.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingCanvas.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingCanvas",
    ()=>PointingCanvas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/selectOnCanvasPointerUp.mjs [app-client] (ecmascript)");
;
;
class PointingCanvas extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_canvas";
    onEnter(info) {
        const additiveSelectionKey = info.shiftKey || info.accelKey;
        if (!additiveSelectionKey) {
            if (this.editor.getSelectedShapeIds().length > 0) {
                this.editor.markHistoryStoppingPoint("selecting none");
                this.editor.selectNone();
            }
        }
    }
    onPointerMove(info) {
        if (this.editor.inputs.getIsDragging()) {
            this.parent.transition("brushing", info);
        }
    }
    onPointerUp(info) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectOnCanvasPointerUp"])(this.editor, info);
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onInterrupt() {
        this.parent.transition("idle");
    }
    complete() {
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingCanvas.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingHandle",
    ()=>PointingHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowTargetState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/shared.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/note/noteHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/selectHelpers.mjs [app-client] (ecmascript)");
;
;
;
;
;
class PointingHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_handle";
    didCtrlOnEnter = false;
    info = {};
    onEnter(info) {
        this.info = info;
        this.didCtrlOnEnter = info.accelKey;
        const { shape } = info;
        if (this.editor.isShapeOfType(shape, "arrow")) {
            const initialBindings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(this.editor, shape);
            const currentBinding = initialBindings[info.handle.id];
            const oppositeBinding = initialBindings[info.handle.id === "start" ? "end" : "start"];
            const arrowTransform = this.editor.getShapePageTransform(shape.id);
            if (currentBinding) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateArrowTargetState"])({
                    editor: this.editor,
                    pointInPageSpace: arrowTransform.applyToPoint(info.handle),
                    arrow: shape,
                    isPrecise: currentBinding.props.isPrecise,
                    currentBinding,
                    oppositeBinding
                });
            }
        }
        this.editor.setCursor({
            type: "grabbing",
            rotation: 0
        });
    }
    onExit() {
        this.editor.setHintingShapes([]);
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    onPointerUp() {
        const { shape, handle } = this.info;
        if (this.editor.isShapeOfType(shape, "note")) {
            const { editor } = this;
            const nextNote = getNoteForAdjacentPosition(editor, shape, handle, false);
            if (nextNote) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(editor, nextNote, {
                    selectAll: true
                });
                return;
            }
        }
        this.parent.transition("idle", this.info);
    }
    onPointerMove(info) {
        const { editor } = this;
        if (editor.inputs.getIsDragging()) {
            if (this.didCtrlOnEnter) {
                this.parent.transition("brushing", info);
            } else {
                this.startDraggingHandle();
            }
        }
    }
    onLongPress() {
        this.startDraggingHandle();
    }
    startDraggingHandle() {
        const { editor } = this;
        if (editor.getIsReadonly()) return;
        const { shape, handle } = this.info;
        if (editor.isShapeOfType(shape, "note")) {
            const nextNote = getNoteForAdjacentPosition(editor, shape, handle, true);
            if (nextNote) {
                const centeredOnPointer = editor.getPointInParentSpace(nextNote, editor.inputs.getOriginPagePoint()).sub(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Rot(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOTE_CENTER_OFFSET"].clone().mul(shape.props.scale), nextNote.rotation));
                editor.updateShape({
                    ...nextNote,
                    x: centeredOnPointer.x,
                    y: centeredOnPointer.y
                });
                editor.setHoveredShape(nextNote.id).select(nextNote.id).setCurrentTool("select.translating", {
                    ...this.info,
                    target: "shape",
                    shape: editor.getShape(nextNote),
                    onInteractionEnd: "note",
                    isCreating: true,
                    onCreate: ()=>{
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(editor, nextNote, {
                            selectAll: true
                        });
                    }
                });
                return;
            }
        }
        this.parent.transition("dragging_handle", this.info);
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    cancel() {
        this.parent.transition("idle");
    }
}
function getNoteForAdjacentPosition(editor, shape, handle, forceNew) {
    const pageTransform = editor.getShapePageTransform(shape.id);
    const pagePoint = pageTransform.point();
    const pageRotation = pageTransform.rotation();
    const positions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNoteAdjacentPositions"])(editor, pagePoint, pageRotation, shape.props.growY * shape.props.scale, 0, shape.props.scale);
    const position = positions[handle.index];
    if (position) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNoteShapeForAdjacentPosition"])(editor, shape, position, pageRotation, forceNew);
    }
}
;
 //# sourceMappingURL=PointingHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingRotateHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingRotateHandle",
    ()=>PointingRotateHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)");
;
;
class PointingRotateHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_rotate_handle";
    info = {};
    updateCursor() {
        this.editor.setCursor({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorTypeMap"][this.info.handle],
            rotation: this.editor.getSelectionRotation()
        });
    }
    onEnter(info) {
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.updateCursor();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
    }
    onPointerMove() {
        if (this.editor.inputs.getIsDragging()) {
            this.startRotating();
        }
    }
    onLongPress() {
        this.startRotating();
    }
    startRotating() {
        if (this.editor.getIsReadonly()) return;
        this.parent.transition("rotating", this.info);
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    complete() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd?.();
            }
            return;
        }
        this.parent.transition("idle");
    }
    cancel() {
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingRotateHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingSelection.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingSelection",
    ()=>PointingSelection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/selectOnCanvasPointerUp.mjs [app-client] (ecmascript)");
;
;
class PointingSelection extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_selection";
    info = {};
    onEnter(info) {
        this.info = info;
    }
    onPointerUp(info) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$selectOnCanvasPointerUp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectOnCanvasPointerUp"])(this.editor, info);
        this.parent.transition("idle", info);
    }
    onPointerMove(info) {
        if (this.editor.inputs.getIsDragging()) {
            this.startTranslating(info);
        }
    }
    onLongPress(info) {
        this.startTranslating(info);
    }
    startTranslating(info) {
        if (this.editor.getIsReadonly()) return;
        this.parent.transition("translating", info);
    }
    onDoubleClick(info) {
        const hoveredShape = this.editor.getHoveredShape();
        const hitShape = hoveredShape && !this.editor.isShapeOfType(hoveredShape, "group") ? hoveredShape : this.editor.getShapeAtPoint(this.editor.inputs.getCurrentPagePoint(), {
            hitInside: true,
            margin: 0,
            renderingOnly: true
        });
        if (hitShape) {
            this.parent.transition("idle");
            this.parent.onDoubleClick?.({
                ...info,
                target: "shape",
                shape: this.editor.getShape(hitShape)
            });
            return;
        }
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    cancel() {
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingSelection.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointingShape",
    ()=>PointingShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$shapes$2f$shapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/shapes/shapes.mjs [app-client] (ecmascript)");
;
;
;
class PointingShape extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing_shape";
    hitShape = {};
    hitShapeForPointerUp = {};
    isDoubleClick = false;
    didCtrlOnEnter = false;
    didSelectOnEnter = false;
    onEnter(info) {
        const selectedShapeIds = this.editor.getSelectedShapeIds();
        const selectionBounds = this.editor.getSelectionRotatedPageBounds();
        const focusedGroupId = this.editor.getFocusedGroupId();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const { shiftKey, altKey, accelKey } = info;
        this.hitShape = info.shape;
        this.isDoubleClick = false;
        this.didCtrlOnEnter = accelKey;
        const outermostSelectingShape = this.editor.getOutermostSelectableShape(info.shape);
        const selectedAncestor = this.editor.findShapeAncestor(outermostSelectingShape, (parent)=>selectedShapeIds.includes(parent.id));
        if (this.didCtrlOnEnter || // If the shape has an onClick handler
        this.editor.getShapeUtil(info.shape).onClick || // ...or if the shape is the focused layer (e.g. group)
        outermostSelectingShape.id === focusedGroupId || // ...or if the shape is within the selection
        selectedShapeIds.includes(outermostSelectingShape.id) || // ...or if an ancestor of the shape is selected
        selectedAncestor || // ...or if the current point is NOT within the selection bounds
        selectedShapeIds.length > 1 && selectionBounds?.containsPoint(currentPagePoint)) {
            this.didSelectOnEnter = false;
            this.hitShapeForPointerUp = outermostSelectingShape;
            return;
        }
        this.didSelectOnEnter = true;
        if (shiftKey && !altKey) {
            this.editor.cancelDoubleClick();
            if (!selectedShapeIds.includes(outermostSelectingShape.id)) {
                this.editor.markHistoryStoppingPoint("shift selecting shape");
                this.editor.setSelectedShapes([
                    ...selectedShapeIds,
                    outermostSelectingShape.id
                ]);
            }
        } else {
            this.editor.markHistoryStoppingPoint("selecting shape");
            this.editor.setSelectedShapes([
                outermostSelectingShape.id
            ]);
        }
    }
    onPointerUp(info) {
        const selectedShapeIds = this.editor.getSelectedShapeIds();
        const focusedGroupId = this.editor.getFocusedGroupId();
        const zoomLevel = this.editor.getZoomLevel();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const additiveSelectionKey = info.shiftKey || info.accelKey;
        const hitShape = this.editor.getShapeAtPoint(currentPagePoint, {
            margin: this.editor.options.hitTestMargin / zoomLevel,
            hitInside: true,
            renderingOnly: true
        }) ?? this.hitShape;
        const selectingShape = hitShape ? this.editor.getOutermostSelectableShape(hitShape) : this.hitShapeForPointerUp;
        if (selectingShape) {
            const util = this.editor.getShapeUtil(selectingShape);
            if (util.onClick) {
                const change = util.onClick?.(selectingShape);
                if (change) {
                    this.editor.markHistoryStoppingPoint("shape on click");
                    this.editor.updateShapes([
                        change
                    ]);
                    this.parent.transition("idle", info);
                    return;
                }
            }
            if (selectingShape.id === focusedGroupId) {
                if (selectedShapeIds.length > 0) {
                    this.editor.markHistoryStoppingPoint("clearing shape ids");
                    this.editor.setSelectedShapes([]);
                } else {
                    this.editor.popFocusedGroupId();
                }
                this.parent.transition("idle", info);
                return;
            }
        }
        if (!this.didSelectOnEnter) {
            const outermostSelectableShape = this.editor.getOutermostSelectableShape(hitShape, // if a group is selected, we want to stop before reaching that group
            // so we can drill down into the group
            (parent)=>!selectedShapeIds.includes(parent.id));
            if (selectedShapeIds.includes(outermostSelectableShape.id)) {
                if (additiveSelectionKey) {
                    this.editor.markHistoryStoppingPoint("deselecting on pointer up");
                    this.editor.deselect(selectingShape);
                } else {
                    if (selectedShapeIds.includes(selectingShape.id)) {
                        if (selectedShapeIds.length === 1) {
                            const geometry = this.editor.getShapeUtil(selectingShape).getGeometry(selectingShape);
                            const textLabels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$shapes$2f$shapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTextLabels"])(geometry);
                            const textLabel = textLabels.length === 1 ? textLabels[0] : void 0;
                            if (textLabel) {
                                const pointInShapeSpace = this.editor.getPointInShapeSpace(selectingShape, currentPagePoint);
                                if (textLabel.bounds.containsPoint(pointInShapeSpace, 0) && textLabel.hitTestPoint(pointInShapeSpace)) {
                                    this.editor.run(()=>{
                                        this.editor.markHistoryStoppingPoint("editing on pointer up");
                                        this.editor.select(selectingShape.id);
                                        if (!this.editor.canEditShape(selectingShape)) return;
                                        this.editor.setEditingShape(selectingShape.id);
                                        this.editor.setCurrentTool("select.editing_shape");
                                        if (this.isDoubleClick) {
                                            this.editor.emit("select-all-text", {
                                                shapeId: selectingShape.id
                                            });
                                        } else {
                                            this.editor.emit("place-caret", {
                                                shapeId: selectingShape.id,
                                                point: info.point
                                            });
                                        }
                                    });
                                    return;
                                }
                            }
                        }
                        this.editor.markHistoryStoppingPoint("selecting on pointer up");
                        this.editor.select(selectingShape.id);
                    } else {
                        this.editor.markHistoryStoppingPoint("selecting on pointer up");
                        this.editor.select(selectingShape);
                    }
                }
            } else if (additiveSelectionKey) {
                const ancestors = this.editor.getShapeAncestors(outermostSelectableShape);
                this.editor.markHistoryStoppingPoint("shift deselecting on pointer up");
                this.editor.setSelectedShapes([
                    ...this.editor.getSelectedShapeIds().filter((id)=>!ancestors.find((a)=>a.id === id)),
                    outermostSelectableShape.id
                ]);
            } else {
                this.editor.markHistoryStoppingPoint("selecting on pointer up");
                this.editor.setSelectedShapes([
                    outermostSelectableShape.id
                ]);
            }
        }
        this.parent.transition("idle", info);
    }
    onDoubleClick() {
        this.isDoubleClick = true;
    }
    onPointerMove(info) {
        if (this.editor.inputs.getIsDragging()) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOverArrowLabel"])(this.editor, this.hitShape)) {
                this.parent.transition("pointing_arrow_label", {
                    ...info,
                    shape: this.hitShape
                });
                return;
            }
            if (this.didCtrlOnEnter) {
                this.parent.transition("brushing", info);
            } else {
                this.startTranslating(info);
            }
        }
    }
    onLongPress(info) {
        this.startTranslating(info);
    }
    startTranslating(info) {
        if (this.editor.getIsReadonly()) return;
        this.editor.focus();
        this.parent.transition("translating", info);
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.cancel();
    }
    onInterrupt() {
        this.cancel();
    }
    cancel() {
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=PointingShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Resizing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Resizing",
    ()=>Resizing,
    "rotateSelectionHandle",
    ()=>rotateSelectionHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/keyboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
;
class Resizing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "resizing";
    info = {};
    markId = "";
    // A switch to detect when the user is holding ctrl
    didHoldCommand = false;
    // we transition into the resizing state from the geo pointing state, which starts with a shape of size w: 1, h: 1,
    // so if the user drags x: +50, y: +50 after mouseDown, the shape will be w: 51, h: 51, which is too many pixels, alas
    // so we allow passing a further offset into this state to negate such issues
    creationCursorOffset = {
        x: 0,
        y: 0
    };
    snapshot = {};
    onEnter(info) {
        const { isCreating = false, creatingMarkId, creationCursorOffset = {
            x: 0,
            y: 0
        } } = info;
        this.info = info;
        this.didHoldCommand = false;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.creationCursorOffset = creationCursorOffset;
        try {
            this.snapshot = this._createSnapshot();
        } catch (e) {
            console.error(e);
            this.cancel();
            return;
        }
        this.markId = "";
        if (isCreating) {
            if (creatingMarkId) {
                this.markId = creatingMarkId;
            } else {
                const markId = this.editor.getMarkIdMatching(`creating:${this.editor.getOnlySelectedShapeId()}`);
                if (markId) {
                    this.markId = markId;
                }
            }
        } else {
            this.markId = this.editor.markHistoryStoppingPoint("starting resizing");
        }
        if (isCreating) {
            this.editor.setCursor({
                type: "cross",
                rotation: 0
            });
        }
        this.handleResizeStart();
        this.updateShapes();
    }
    onTick({ elapsed }) {
        const { editor } = this;
        if (!editor.inputs.getIsDragging() || editor.inputs.getIsPanning()) return;
        editor.edgeScrollManager.updateEdgeScrolling(elapsed);
    }
    onPointerMove() {
        this.updateShapes();
    }
    onKeyDown() {
        this.updateShapes();
    }
    onKeyUp() {
        this.updateShapes();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    cancel() {
        const { shapeSnapshots } = this.snapshot;
        shapeSnapshots.forEach(({ shape })=>{
            const current = this.editor.getShape(shape.id);
            if (current) {
                const util = this.editor.getShapeUtil(shape);
                util.onResizeCancel?.(shape, current);
            }
        });
        this.editor.bailToMark(this.markId);
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, {});
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle");
    }
    complete() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, this.snapshot.selectedShapeIds);
        this.handleResizeEnd();
        if (this.info.isCreating && this.info.onCreate) {
            this.info.onCreate?.(this.editor.getOnlySelectedShape());
            return;
        }
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                if (this.editor.getInstanceState().isToolLocked) {
                    this.editor.setCurrentTool(onInteractionEnd, {});
                    return;
                }
            } else {
                onInteractionEnd();
                return;
            }
        }
        this.parent.transition("idle");
    }
    handleResizeStart() {
        const { shapeSnapshots } = this.snapshot;
        const changes = [];
        shapeSnapshots.forEach(({ shape })=>{
            const util = this.editor.getShapeUtil(shape);
            const change = util.onResizeStart?.(shape);
            if (change) {
                changes.push(change);
            }
        });
        if (changes.length > 0) {
            this.editor.updateShapes(changes);
        }
    }
    handleResizeEnd() {
        const { shapeSnapshots } = this.snapshot;
        const changes = [];
        shapeSnapshots.forEach(({ shape })=>{
            const current = this.editor.getShape(shape.id);
            const util = this.editor.getShapeUtil(shape);
            const change = util.onResizeEnd?.(shape, current);
            if (change) {
                changes.push(change);
            }
        });
        if (changes.length > 0) {
            this.editor.updateShapes(changes);
        }
    }
    updateShapes() {
        const altKey = this.editor.inputs.getAltKey();
        const shiftKey = this.editor.inputs.getShiftKey();
        const { frames, shapeSnapshots, selectionBounds, cursorHandleOffset, selectedShapeIds, selectionRotation, canShapesDeform } = this.snapshot;
        let isAspectRatioLocked = shiftKey || !canShapesDeform;
        if (shapeSnapshots.size === 1) {
            const onlySnapshot = [
                ...shapeSnapshots.values()
            ][0];
            if (this.editor.isShapeOfType(onlySnapshot.shape, "text")) {
                isAspectRatioLocked = !(this.info.handle === "left" || this.info.handle === "right");
            }
        }
        const isHoldingAccel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(this.editor.inputs);
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint().clone().sub(cursorHandleOffset).sub(this.creationCursorOffset);
        const originPagePoint = this.editor.inputs.getOriginPagePoint().clone().sub(cursorHandleOffset);
        if (this.editor.getInstanceState().isGridMode && !isHoldingAccel) {
            const { gridSize } = this.editor.getDocumentSettings();
            currentPagePoint.snapToGrid(gridSize);
        }
        const dragHandle = this.info.handle;
        const scaleOriginHandle = rotateSelectionHandle(dragHandle, Math.PI);
        this.editor.snaps.clearIndicators();
        const shouldSnap = this.editor.user.getIsSnapMode() ? !isHoldingAccel : isHoldingAccel;
        if (shouldSnap && selectionRotation % __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] === 0) {
            const { nudge } = this.editor.snaps.shapeBounds.snapResizeShapes({
                dragDelta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentPagePoint, originPagePoint),
                initialSelectionPageBounds: this.snapshot.initialSelectionPageBounds,
                handle: rotateSelectionHandle(dragHandle, selectionRotation),
                isAspectRatioLocked,
                isResizingFromCenter: altKey
            });
            currentPagePoint.add(nudge);
        }
        const scaleOriginPage = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(altKey ? selectionBounds.center : selectionBounds.getHandlePoint(scaleOriginHandle), selectionBounds.point, selectionRotation);
        const distanceFromScaleOriginNow = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentPagePoint, scaleOriginPage).rot(-selectionRotation);
        const distanceFromScaleOriginAtStart = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(originPagePoint, scaleOriginPage).rot(-selectionRotation);
        const scale = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].DivV(distanceFromScaleOriginNow, distanceFromScaleOriginAtStart);
        if (!Number.isFinite(scale.x)) scale.x = 1;
        if (!Number.isFinite(scale.y)) scale.y = 1;
        const isXLocked = dragHandle === "top" || dragHandle === "bottom";
        const isYLocked = dragHandle === "left" || dragHandle === "right";
        if (isAspectRatioLocked) {
            if (isYLocked) {
                scale.y = Math.abs(scale.x);
            } else if (isXLocked) {
                scale.x = Math.abs(scale.y);
            } else if (Math.abs(scale.x) > Math.abs(scale.y)) {
                scale.y = Math.abs(scale.x) * (scale.y < 0 ? -1 : 1);
            } else {
                scale.x = Math.abs(scale.y) * (scale.x < 0 ? -1 : 1);
            }
        } else {
            if (isXLocked) {
                scale.x = 1;
            }
            if (isYLocked) {
                scale.y = 1;
            }
        }
        if (!this.info.isCreating) {
            this.updateCursor({
                dragHandle,
                isFlippedX: scale.x < 0,
                isFlippedY: scale.y < 0,
                rotation: selectionRotation
            });
        }
        for (const id of shapeSnapshots.keys()){
            const snapshot = shapeSnapshots.get(id);
            this.editor.resizeShape(id, scale, {
                initialShape: snapshot.shape,
                initialBounds: snapshot.bounds,
                initialPageTransform: snapshot.pageTransform,
                dragHandle,
                mode: selectedShapeIds.length === 1 && id === selectedShapeIds[0] ? "resize_bounds" : "scale_shape",
                scaleOrigin: scaleOriginPage,
                isAspectRatioLocked,
                scaleAxisRotation: selectionRotation,
                skipStartAndEndCallbacks: true
            });
        }
        if (isHoldingAccel) {
            this.didHoldCommand = true;
            for (const { id, children } of frames){
                if (!children.length) continue;
                const initial = shapeSnapshots.get(id).shape;
                const current = this.editor.getShape(id);
                if (!(initial && current)) continue;
                const dx = current.x - initial.x;
                const dy = current.y - initial.y;
                const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](dx, dy).rot(-initial.rotation);
                if (delta.x !== 0 || delta.y !== 0) {
                    for (const child of children){
                        this.editor.updateShape({
                            id: child.id,
                            type: child.type,
                            x: child.x - delta.x,
                            y: child.y - delta.y
                        });
                    }
                }
            }
        } else if (this.didHoldCommand) {
            this.didHoldCommand = false;
            for (const { children } of frames){
                if (!children.length) continue;
                for (const child of children){
                    this.editor.updateShape({
                        id: child.id,
                        type: child.type,
                        x: child.x,
                        y: child.y
                    });
                }
            }
        }
    }
    // ---
    updateCursor({ dragHandle, isFlippedX, isFlippedY, rotation }) {
        const nextCursor = {
            ...this.editor.getInstanceState().cursor
        };
        switch(dragHandle){
            case "top_left":
            case "bottom_right":
                {
                    nextCursor.type = "nwse-resize";
                    if (isFlippedX !== isFlippedY) {
                        nextCursor.type = "nesw-resize";
                    }
                    break;
                }
            case "top_right":
            case "bottom_left":
                {
                    nextCursor.type = "nesw-resize";
                    if (isFlippedX !== isFlippedY) {
                        nextCursor.type = "nwse-resize";
                    }
                    break;
                }
        }
        nextCursor.rotation = rotation;
        this.editor.setCursor(nextCursor);
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
        this.editor.snaps.clearIndicators();
    }
    _createSnapshot() {
        const { editor } = this;
        const selectedShapeIds = editor.getSelectedShapeIds();
        const selectionRotation = editor.getSelectionRotation();
        const originPagePoint = editor.inputs.getOriginPagePoint();
        const selectionBounds = editor.getSelectionRotatedPageBounds();
        if (!selectionBounds) throw Error("Resizing but nothing is selected");
        const dragHandlePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(selectionBounds.getHandlePoint(this.info.handle), selectionBounds.point, selectionRotation);
        const cursorHandleOffset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(originPagePoint, dragHandlePoint);
        const shapeSnapshots = /* @__PURE__ */ new Map();
        const frames = [];
        const populateResizingShapes = (shapeId)=>{
            const shape = editor.getShape(shapeId);
            if (!shape) return false;
            const util = editor.getShapeUtil(shape);
            if (util.canResize(shape)) {
                const pageTransform = editor.getShapePageTransform(shape);
                shapeSnapshots.set(shape.id, {
                    shape,
                    bounds: editor.getShapeGeometry(shape).bounds,
                    pageTransform,
                    pageRotation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Decompose(pageTransform).rotation,
                    isAspectRatioLocked: util.isAspectRatioLocked(shape)
                });
            }
            if (editor.isShapeOfType(shape, "frame")) {
                frames.push({
                    id: shape.id,
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(editor.getSortedChildIdsForParent(shape).map((id)=>editor.getShape(id)))
                });
            }
            if (!util.canResizeChildren(shape)) return false;
        };
        selectedShapeIds.forEach((shapeId)=>{
            const keepDescending = populateResizingShapes(shapeId);
            if (keepDescending === false) return;
            editor.visitDescendants(shapeId, populateResizingShapes);
        });
        const canShapesDeform = ![
            ...shapeSnapshots.values()
        ].some((shape)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areAnglesCompatible"])(shape.pageRotation, selectionRotation) || shape.isAspectRatioLocked);
        return {
            shapeSnapshots,
            selectionBounds,
            cursorHandleOffset,
            selectionRotation,
            selectedShapeIds,
            canShapesDeform,
            initialSelectionPageBounds: this.editor.getSelectionPageBounds(),
            frames
        };
    }
}
const ORDERED_SELECTION_HANDLES = [
    "top",
    "top_right",
    "right",
    "bottom_right",
    "bottom",
    "bottom_left",
    "left",
    "top_left"
];
function rotateSelectionHandle(handle, rotation) {
    rotation = rotation % __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI2"];
    const numSteps = Math.round(rotation / (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] / 4));
    const currentIndex = ORDERED_SELECTION_HANDLES.indexOf(handle);
    return ORDERED_SELECTION_HANDLES[(currentIndex + numSteps) % ORDERED_SELECTION_HANDLES.length];
}
;
 //# sourceMappingURL=Resizing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Rotating.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Rotating",
    ()=>Rotating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/rotation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)");
;
;
const ONE_DEGREE = Math.PI / 180;
class Rotating extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "rotating";
    snapshot = {};
    info = {};
    markId = "";
    onEnter(info) {
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.markId = this.editor.markHistoryStoppingPoint("rotate start");
        const snapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRotationSnapshot"])({
            editor: this.editor,
            ids: this.editor.getSelectedShapeIds()
        });
        if (!snapshot) return this.parent.transition("idle", this.info);
        this.snapshot = snapshot;
        const newSelectionRotation = this._getRotationFromPointerPosition({
            snapToNearestDegree: false
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyRotationToSnapshotShapes"])({
            editor: this.editor,
            delta: this._getRotationFromPointerPosition({
                snapToNearestDegree: false
            }),
            snapshot: this.snapshot,
            stage: "start"
        });
        this.editor.setCursor({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorTypeMap"][this.info.handle],
            rotation: newSelectionRotation + this.snapshot.initialShapesRotation
        });
    }
    onExit() {
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
        this.parent.setCurrentToolIdMask(void 0);
        this.snapshot = {};
    }
    onPointerMove() {
        this.update();
    }
    onKeyDown() {
        this.update();
    }
    onKeyUp() {
        this.update();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    // ---
    update() {
        const newSelectionRotation = this._getRotationFromPointerPosition({
            snapToNearestDegree: false
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyRotationToSnapshotShapes"])({
            editor: this.editor,
            delta: newSelectionRotation,
            snapshot: this.snapshot,
            stage: "update"
        });
        this.editor.setCursor({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorTypeMap"][this.info.handle],
            rotation: newSelectionRotation + this.snapshot.initialShapesRotation
        });
    }
    cancel() {
        const { shapeSnapshots } = this.snapshot;
        shapeSnapshots.forEach(({ shape })=>{
            const current = this.editor.getShape(shape.id);
            if (current) {
                const util = this.editor.getShapeUtil(shape);
                util.onRotateCancel?.(shape, current);
            }
        });
        this.editor.bailToMark(this.markId);
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle", this.info);
    }
    complete() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyRotationToSnapshotShapes"])({
            editor: this.editor,
            delta: this._getRotationFromPointerPosition({
                snapToNearestDegree: true
            }),
            snapshot: this.snapshot,
            stage: "end"
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, this.snapshot.shapeSnapshots.map((s)=>s.shape.id));
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd, this.info);
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle", this.info);
    }
    _getRotationFromPointerPosition({ snapToNearestDegree }) {
        const shiftKey = this.editor.inputs.getShiftKey();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const { initialCursorAngle, initialShapesRotation, initialPageCenter } = this.snapshot;
        const preSnapRotationDelta = initialPageCenter.angle(currentPagePoint) - initialCursorAngle;
        let newSelectionRotation = initialShapesRotation + preSnapRotationDelta;
        if (shiftKey) {
            newSelectionRotation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapAngle"])(newSelectionRotation, 24);
        } else if (snapToNearestDegree) {
            newSelectionRotation = Math.round(newSelectionRotation / ONE_DEGREE) * ONE_DEGREE;
            if (this.editor.getInstanceState().isCoarsePointer) {
                const snappedToRightAngle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapAngle"])(newSelectionRotation, 4);
                const angleToRightAngle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortAngleDist"])(newSelectionRotation, snappedToRightAngle);
                if (Math.abs(angleToRightAngle) < (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degreesToRadians"])(5)) {
                    newSelectionRotation = snappedToRightAngle;
                }
            }
        }
        return newSelectionRotation - initialShapesRotation;
    }
}
;
 //# sourceMappingURL=Rotating.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/ScribbleBrushing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ScribbleBrushing",
    ()=>ScribbleBrushing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
;
class ScribbleBrushing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "scribble_brushing";
    hits = /* @__PURE__ */ new Set();
    size = 0;
    scribbleId = "id";
    initialSelectedShapeIds = /* @__PURE__ */ new Set();
    newlySelectedShapeIds = /* @__PURE__ */ new Set();
    onEnter() {
        this.initialSelectedShapeIds = new Set(this.editor.inputs.getShiftKey() ? this.editor.getSelectedShapeIds() : []);
        this.newlySelectedShapeIds = /* @__PURE__ */ new Set();
        this.size = 0;
        this.hits.clear();
        const scribbleItem = this.editor.scribbles.addScribble({
            color: "selection-stroke",
            opacity: 0.32,
            size: 12
        });
        this.scribbleId = scribbleItem.id;
        this.updateScribbleSelection(true);
        this.editor.updateInstanceState({
            brush: null
        });
    }
    onExit() {
        this.editor.scribbles.stop(this.scribbleId);
    }
    onPointerMove() {
        this.updateScribbleSelection(true);
    }
    onPointerUp() {
        this.complete();
    }
    onKeyDown() {
        this.updateScribbleSelection(false);
    }
    onKeyUp() {
        if (!this.editor.inputs.getAltKey()) {
            this.parent.transition("brushing");
        } else {
            this.updateScribbleSelection(false);
        }
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.complete();
    }
    pushPointToScribble() {
        const { x, y } = this.editor.inputs.getCurrentPagePoint();
        this.editor.scribbles.addPoint(this.scribbleId, x, y);
    }
    updateScribbleSelection(addPoint) {
        const { editor } = this;
        const shiftKey = this.editor.inputs.getShiftKey();
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        const previousPagePoint = this.editor.inputs.getPreviousPagePoint();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        const { newlySelectedShapeIds, initialSelectedShapeIds } = this;
        if (addPoint) {
            this.pushPointToScribble();
        }
        const minDist = 0;
        const lineBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints([
            previousPagePoint,
            currentPagePoint
        ]).expandBy(minDist);
        const candidateIds = editor.getShapeIdsInsideBounds(lineBounds);
        if (candidateIds.size === 0) {
            const current2 = editor.getSelectedShapeIds();
            const next2 = new Set(shiftKey ? [
                ...newlySelectedShapeIds,
                ...initialSelectedShapeIds
            ] : [
                ...newlySelectedShapeIds
            ]);
            if (current2.length !== next2.size || current2.some((id)=>!next2.has(id))) {
                this.editor.setSelectedShapes(Array.from(next2));
            }
            return;
        }
        const allShapes = this.editor.getCurrentPageRenderingShapesSorted();
        const currentPageShapes = allShapes.filter((shape2)=>candidateIds.has(shape2.id));
        const shapes = currentPageShapes;
        let shape, geometry, A, B;
        for(let i = 0, n = shapes.length; i < n; i++){
            shape = shapes[i];
            if (editor.isShapeOfType(shape, "group") || newlySelectedShapeIds.has(shape.id) || editor.isShapeOrAncestorLocked(shape)) {
                continue;
            }
            geometry = editor.getShapeGeometry(shape);
            if (editor.isShapeOfType(shape, "frame") && geometry.bounds.containsPoint(editor.getPointInShapeSpace(shape, originPagePoint))) {
                continue;
            }
            const pageTransform = editor.getShapePageTransform(shape);
            if (!geometry || !pageTransform) continue;
            const pt = pageTransform.clone().invert();
            A = pt.applyToPoint(previousPagePoint);
            B = pt.applyToPoint(currentPagePoint);
            const { bounds } = geometry;
            if (bounds.minX - minDist > Math.max(A.x, B.x) || bounds.minY - minDist > Math.max(A.y, B.y) || bounds.maxX + minDist < Math.min(A.x, B.x) || bounds.maxY + minDist < Math.min(A.y, B.y)) {
                continue;
            }
            if (geometry.hitTestLineSegment(A, B, minDist)) {
                const outermostShape = this.editor.getOutermostSelectableShape(shape);
                const pageMask = this.editor.getShapeMask(outermostShape.id);
                if (pageMask) {
                    const intersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentPolygon"])(previousPagePoint, currentPagePoint, pageMask);
                    if (intersection !== null) {
                        const isInMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(currentPagePoint, pageMask);
                        if (!isInMask) continue;
                    }
                }
                newlySelectedShapeIds.add(outermostShape.id);
            }
        }
        const current = editor.getSelectedShapeIds();
        const next = new Set(shiftKey ? [
            ...newlySelectedShapeIds,
            ...initialSelectedShapeIds
        ] : [
            ...newlySelectedShapeIds
        ]);
        if (current.length !== next.size || current.some((id)=>!next.has(id))) {
            this.editor.setSelectedShapes(Array.from(next));
        }
    }
    complete() {
        this.updateScribbleSelection(true);
        this.parent.transition("idle");
    }
    cancel() {
        this.editor.setSelectedShapes([
            ...this.initialSelectedShapeIds
        ]);
        this.parent.transition("idle");
    }
}
;
 //# sourceMappingURL=ScribbleBrushing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/DragAndDropManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DragAndDropManager",
    ()=>DragAndDropManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _dispose_dec, _init;
;
const SLOW_POINTER_LAG_DURATION = 320;
const FAST_POINTER_LAG_DURATION = 60;
_dispose_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
];
class DragAndDropManager {
    constructor(editor){
        this.editor = editor;
        __runInitializers(_init, 5, this);
        __publicField(this, "shapesToActuallyMove", []);
        __publicField(this, "draggedOverShapeIds", /* @__PURE__ */ new Set());
        __publicField(this, "initialGroupIds", /* @__PURE__ */ new Map());
        __publicField(this, "initialParentIds", /* @__PURE__ */ new Map());
        __publicField(this, "initialIndices", /* @__PURE__ */ new Map());
        __publicField(this, "initialDraggingOverShape");
        __publicField(this, "prevDraggingOverShape");
        __publicField(this, "prevPagePoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]());
        __publicField(this, "intervalTimerId", -1);
        editor.disposables.add(this.dispose);
    }
    startDraggingShapes(movingShapes, point, cb) {
        const { editor } = this;
        if (this.intervalTimerId !== -1) return;
        const shapesToActuallyMove = new Set(movingShapes);
        const movingGroups = /* @__PURE__ */ new Set();
        for (const shape of shapesToActuallyMove){
            const parent = editor.getShapeParent(shape);
            if (parent && editor.isShapeOfType(parent, "group")) {
                if (!movingGroups.has(parent)) {
                    movingGroups.add(parent);
                }
            }
        }
        for (const movingGroup of movingGroups){
            const children = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(editor.getSortedChildIdsForParent(movingGroup).map((id)=>editor.getShape(id)));
            shapesToActuallyMove.add(movingGroup);
            for (const child of children){
                shapesToActuallyMove.delete(child);
            }
        }
        this.initialParentIds.clear();
        for (const shape of shapesToActuallyMove){
            const parent = editor.getShapeParent(shape);
            if (parent) {
                this.initialParentIds.set(shape.id, parent.id);
            }
            this.initialIndices.set(shape.id, shape.index);
            const group = editor.findShapeAncestor(shape, (s)=>editor.isShapeOfType(s, "group"));
            if (group) {
                this.initialGroupIds.set(shape.id, group.id);
            }
        }
        const allShapes = editor.getCurrentPageShapesSorted();
        this.shapesToActuallyMove = Array.from(shapesToActuallyMove).filter((s)=>!s.isLocked).sort((a, b)=>allShapes.indexOf(a) - allShapes.indexOf(b));
        this.initialDraggingOverShape = editor.getDraggingOverShape(point, this.shapesToActuallyMove);
        this.prevDraggingOverShape = this.initialDraggingOverShape;
        this.updateDraggingShapes(point, cb);
        let skip2of3FramesWhileMovingFast = 0;
        this.intervalTimerId = this.editor.timers.setInterval(()=>{
            skip2of3FramesWhileMovingFast++;
            if (skip2of3FramesWhileMovingFast % 3 && this.editor.inputs.getPointerVelocity().len() > 0.5) {
                return;
            }
            this.updateDraggingShapes(editor.inputs.getCurrentPagePoint(), cb);
        }, movingShapes.length > 10 ? SLOW_POINTER_LAG_DURATION : FAST_POINTER_LAG_DURATION);
    }
    dropShapes(shapes) {
        const { editor } = this;
        const currentPagePoint = editor.inputs.getCurrentPagePoint();
        this.updateDraggingShapes(currentPagePoint);
        const draggingOverShape = editor.getDraggingOverShape(currentPagePoint, shapes);
        if (draggingOverShape) {
            const util = editor.getShapeUtil(draggingOverShape);
            util.onDropShapesOver?.(draggingOverShape, shapes, {
                initialDraggingOverShapeId: this.initialDraggingOverShape?.id ?? null,
                initialParentIds: this.initialParentIds,
                initialIndices: this.initialIndices
            });
        }
        this.dispose();
    }
    clear() {
        clearInterval(this.intervalTimerId);
        this.intervalTimerId = -1;
        this.initialParentIds.clear();
        this.initialIndices.clear();
        this.shapesToActuallyMove = [];
        this.initialDraggingOverShape = void 0;
        this.prevDraggingOverShape = void 0;
        this.editor.setHintingShapes([]);
    }
    dispose() {
        this.clear();
    }
    updateDraggingShapes(point, cb) {
        const { editor } = this;
        const draggingShapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.shapesToActuallyMove.map((s)=>editor.getShape(s)));
        if (!draggingShapes.length) return;
        const nextDraggingOverShape = editor.getDraggingOverShape(point, this.shapesToActuallyMove);
        const currentPagePoint = editor.inputs.getCurrentPagePoint();
        const cursorDidMove = !this.prevPagePoint.equals(currentPagePoint);
        this.prevPagePoint.setTo(currentPagePoint);
        editor.run(()=>{
            if (this.prevDraggingOverShape?.id === nextDraggingOverShape?.id) {
                if (cursorDidMove && nextDraggingOverShape && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(nextDraggingOverShape.id) && !editor.inputs.getPreviousPagePoint().equals(currentPagePoint)) {
                    const util = editor.getShapeUtil(nextDraggingOverShape);
                    util.onDragShapesOver?.(nextDraggingOverShape, draggingShapes, {
                        initialDraggingOverShapeId: this.initialDraggingOverShape?.id ?? null,
                        initialParentIds: this.initialParentIds,
                        initialIndices: this.initialIndices
                    });
                }
                return;
            }
            if (this.prevDraggingOverShape) {
                const util = editor.getShapeUtil(this.prevDraggingOverShape);
                util.onDragShapesOut?.(this.editor.getShape(this.prevDraggingOverShape), draggingShapes, {
                    nextDraggingOverShapeId: nextDraggingOverShape?.id ?? null,
                    initialDraggingOverShapeId: this.initialDraggingOverShape?.id ?? null,
                    initialParentIds: this.initialParentIds,
                    initialIndices: this.initialIndices
                });
            }
            if (nextDraggingOverShape) {
                const util = editor.getShapeUtil(nextDraggingOverShape);
                util.onDragShapesIn?.(nextDraggingOverShape, draggingShapes, {
                    initialDraggingOverShapeId: this.initialDraggingOverShape?.id ?? null,
                    prevDraggingOverShapeId: this.prevDraggingOverShape?.id ?? null,
                    initialParentIds: this.initialParentIds,
                    initialIndices: this.initialIndices
                });
                editor.setHintingShapes([
                    nextDraggingOverShape.id
                ]);
            } else if (this.prevDraggingOverShape) {
                editor.setHintingShapes([]);
            }
            cb?.();
        });
        this.prevDraggingOverShape = nextDraggingOverShape;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "dispose", _dispose_dec, DragAndDropManager);
__decoratorMetadata(_init, DragAndDropManager);
;
 //# sourceMappingURL=DragAndDropManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Translating.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Translating",
    ()=>Translating,
    "moveShapesToPoint",
    ()=>moveShapesToPoint
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/note/noteHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$DragAndDropManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/DragAndDropManager.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _updateParentTransforms_dec, _a, _init;
;
;
;
class Translating extends (_a = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"], _updateParentTransforms_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], _a) {
    constructor(){
        super(...arguments);
        __runInitializers(_init, 5, this);
        __publicField(this, "info", {});
        __publicField(this, "selectionSnapshot", {});
        __publicField(this, "snapshot", {});
        __publicField(this, "markId", "");
        __publicField(this, "isCloning", false);
        __publicField(this, "isCreating", false);
        __publicField(this, "dragAndDropManager", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$DragAndDropManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragAndDropManager"](this.editor));
    }
    onCreate(_shape) {
        return;
    }
    onEnter(info) {
        const { isCreating = false, creatingMarkId, onCreate = ()=>void 0 } = info;
        if (!this.editor.getSelectedShapeIds()?.length) {
            this.parent.transition("idle");
            return;
        }
        this.info = info;
        if (typeof info.onInteractionEnd === "string") {
            this.parent.setCurrentToolIdMask(info.onInteractionEnd);
        }
        this.isCreating = isCreating;
        this.markId = "";
        if (isCreating) {
            if (creatingMarkId) {
                this.markId = creatingMarkId;
            } else {
                const markId = this.editor.getMarkIdMatching(`creating:${this.editor.getOnlySelectedShapeId()}`);
                if (markId) {
                    this.markId = markId;
                }
            }
        } else {
            this.markId = this.editor.markHistoryStoppingPoint("translating");
        }
        this.onCreate = onCreate;
        this.isCloning = false;
        this.info = info;
        this.editor.setCursor({
            type: "move",
            rotation: 0
        });
        this.selectionSnapshot = getTranslatingSnapshot(this.editor);
        if (!this.isCreating) {
            if (this.editor.inputs.getAltKey()) {
                this.startCloning();
                if (this.isCloning) return;
            }
        }
        this.snapshot = this.selectionSnapshot;
        this.handleStart();
        this.updateShapes();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        this.selectionSnapshot = {};
        this.snapshot = {};
        this.editor.snaps.clearIndicators();
        this.editor.setCursor({
            type: "default",
            rotation: 0
        });
        this.dragAndDropManager.clear();
    }
    onTick({ elapsed }) {
        const { editor } = this;
        if (!editor.inputs.getIsDragging() || editor.inputs.getIsPanning()) return;
        editor.edgeScrollManager.updateEdgeScrolling(elapsed);
    }
    onPointerMove() {
        this.updateShapes();
    }
    onKeyDown() {
        if (this.editor.inputs.getAltKey() && !this.isCloning) {
            this.startCloning();
            if (this.isCloning) return;
        }
        this.updateShapes();
    }
    onKeyUp() {
        if (!this.editor.inputs.getAltKey() && this.isCloning) {
            this.stopCloning();
            return;
        }
        this.updateShapes();
    }
    onPointerUp() {
        this.complete();
    }
    onComplete() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    startCloning() {
        if (this.isCreating) return;
        const shapeIds = Array.from(this.editor.getSelectedShapeIds());
        if (!this.editor.canCreateShapes(shapeIds)) return;
        this.isCloning = true;
        this.reset();
        this.markId = this.editor.markHistoryStoppingPoint("translate cloning");
        this.editor.duplicateShapes(Array.from(this.editor.getSelectedShapeIds()));
        this.snapshot = getTranslatingSnapshot(this.editor);
        this.handleStart();
        this.updateShapes();
    }
    stopCloning() {
        this.isCloning = false;
        this.snapshot = this.selectionSnapshot;
        this.reset();
        this.markId = this.editor.markHistoryStoppingPoint("translate");
        this.updateShapes();
    }
    reset() {
        this.editor.bailToMark(this.markId);
    }
    complete() {
        this.updateShapes();
        this.dragAndDropManager.dropShapes(this.snapshot.movingShapes);
        this.handleEnd();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(this.editor, this.snapshot.movingShapes.map((s)=>s.id));
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                if (this.editor.getInstanceState().isToolLocked) {
                    this.editor.setCurrentTool(onInteractionEnd);
                    return;
                }
            } else {
                onInteractionEnd();
                return;
            }
        }
        if (this.isCreating) {
            this.onCreate?.(this.editor.getOnlySelectedShape());
        } else {
            this.parent.transition("idle");
        }
    }
    cancel() {
        const { movingShapes } = this.snapshot;
        movingShapes.forEach((shape)=>{
            const current = this.editor.getShape(shape.id);
            if (current) {
                const util = this.editor.getShapeUtil(shape);
                util.onTranslateCancel?.(shape, current);
            }
        });
        this.reset();
        const { onInteractionEnd } = this.info;
        if (onInteractionEnd) {
            if (typeof onInteractionEnd === "string") {
                this.editor.setCurrentTool(onInteractionEnd);
            } else {
                onInteractionEnd();
            }
            return;
        }
        this.parent.transition("idle", this.info);
    }
    handleStart() {
        const { movingShapes } = this.snapshot;
        const changes = [];
        movingShapes.forEach((shape)=>{
            const util = this.editor.getShapeUtil(shape);
            const change = util.onTranslateStart?.(shape);
            if (change) {
                changes.push(change);
            }
        });
        if (changes.length > 0) {
            this.editor.updateShapes(changes);
        }
        this.dragAndDropManager.startDraggingShapes(// Get fresh shapes from the snapshot, in case onTranslateStart mutates the shape
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.snapshot.movingShapes.map((s)=>this.editor.getShape(s.id))), // Start from the place where the user started dragging
        this.editor.inputs.getOriginPagePoint(), this.updateParentTransforms);
        this.editor.setHoveredShape(null);
    }
    handleEnd() {
        const { movingShapes } = this.snapshot;
        if (this.isCloning && movingShapes.length > 0) {
            const currentAveragePagePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Average(movingShapes.map((s)=>this.editor.getShapePageTransform(s.id).point()));
            const offset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentAveragePagePoint, this.selectionSnapshot.averagePagePoint);
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].IsNaN(offset)) {
                this.editor.updateInstanceState({
                    duplicateProps: {
                        shapeIds: movingShapes.map((s)=>s.id),
                        offset: {
                            x: offset.x,
                            y: offset.y
                        }
                    }
                });
            }
        }
        const changes = [];
        movingShapes.forEach((shape)=>{
            const current = this.editor.getShape(shape.id);
            const util = this.editor.getShapeUtil(shape);
            const change = util.onTranslateEnd?.(shape, current);
            if (change) {
                changes.push(change);
            }
        });
        if (changes.length > 0) {
            this.editor.updateShapes(changes);
        }
    }
    updateShapes() {
        const { snapshot } = this;
        this.dragAndDropManager.startDraggingShapes(snapshot.movingShapes, this.editor.inputs.getOriginPagePoint(), this.updateParentTransforms);
        moveShapesToPoint({
            editor: this.editor,
            snapshot
        });
        const { movingShapes } = snapshot;
        const changes = [];
        movingShapes.forEach((shape)=>{
            const current = this.editor.getShape(shape.id);
            const util = this.editor.getShapeUtil(shape);
            const change = util.onTranslate?.(shape, current);
            if (change) {
                changes.push(change);
            }
        });
        if (changes.length > 0) {
            this.editor.updateShapes(changes);
        }
    }
    updateParentTransforms() {
        const { editor, snapshot: { shapeSnapshots } } = this;
        const movingShapes = [];
        shapeSnapshots.forEach((shapeSnapshot)=>{
            const shape = editor.getShape(shapeSnapshot.shape.id);
            if (!shape) return null;
            movingShapes.push(shape);
            const parentTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape.parentId) ? null : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Inverse(editor.getShapePageTransform(shape.parentId));
            shapeSnapshot.parentTransform = parentTransform;
        });
    }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 1, "updateParentTransforms", _updateParentTransforms_dec, Translating);
__decoratorMetadata(_init, Translating);
__publicField(Translating, "id", "translating");
function getTranslatingSnapshot(editor) {
    const movingShapes = [];
    const pagePoints = [];
    const selectedShapeIds = editor.getSelectedShapeIds();
    const shapeSnapshots = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(selectedShapeIds.map((id)=>{
        const shape = editor.getShape(id);
        if (!shape) return null;
        movingShapes.push(shape);
        const pageTransform = editor.getShapePageTransform(id);
        const pagePoint = pageTransform.point();
        const pageRotation = pageTransform.rotation();
        pagePoints.push(pagePoint);
        const parentTransform = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].isId(shape.parentId) ? null : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Inverse(editor.getShapePageTransform(shape.parentId));
        return {
            shape,
            pagePoint,
            pageRotation,
            parentTransform
        };
    }));
    const onlySelectedShape = editor.getOnlySelectedShape();
    let initialSnapPoints = [];
    if (onlySelectedShape) {
        initialSnapPoints = editor.snaps.shapeBounds.getSnapPoints(onlySelectedShape.id);
    } else {
        const selectionPageBounds = editor.getSelectionPageBounds();
        if (selectionPageBounds) {
            initialSnapPoints = selectionPageBounds.cornersAndCenter.map((p, i)=>({
                    id: "selection:" + i,
                    x: p.x,
                    y: p.y
                }));
        }
    }
    let noteAdjacentPositions;
    let noteSnapshot;
    const originPagePoint = editor.inputs.getOriginPagePoint();
    const allHoveredNotes = shapeSnapshots.filter((s)=>editor.isShapeOfType(s.shape, "note") && editor.isPointInShape(s.shape, originPagePoint));
    if (allHoveredNotes.length === 0) {} else if (allHoveredNotes.length === 1) {
        noteSnapshot = allHoveredNotes[0];
    } else {
        const allShapesSorted = editor.getCurrentPageShapesSorted();
        noteSnapshot = allHoveredNotes.map((s)=>({
                snapshot: s,
                index: allShapesSorted.findIndex((shape)=>shape.id === s.shape.id)
            })).sort((a, b)=>b.index - a.index)[0]?.snapshot;
    }
    if (noteSnapshot) {
        noteAdjacentPositions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAvailableNoteAdjacentPositions"])(editor, noteSnapshot.pageRotation, noteSnapshot.shape.props.scale, noteSnapshot.shape.props.growY ?? 0);
    }
    return {
        averagePagePoint: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Average(pagePoints),
        movingShapes,
        shapeSnapshots,
        initialPageBounds: editor.getSelectionPageBounds(),
        initialSnapPoints,
        noteAdjacentPositions,
        noteSnapshot
    };
}
function moveShapesToPoint({ editor, snapshot }) {
    const { inputs } = editor;
    const { noteSnapshot, noteAdjacentPositions, initialPageBounds, initialSnapPoints, shapeSnapshots, averagePagePoint } = snapshot;
    const shiftKey = editor.inputs.getShiftKey();
    const accelKey = editor.inputs.getAccelKey();
    const isGridMode = editor.getInstanceState().isGridMode;
    const gridSize = editor.getDocumentSettings().gridSize;
    const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(inputs.getCurrentPagePoint(), inputs.getOriginPagePoint());
    const flatten = shiftKey ? Math.abs(delta.x) < Math.abs(delta.y) ? "x" : "y" : null;
    if (flatten === "x") {
        delta.x = 0;
    } else if (flatten === "y") {
        delta.y = 0;
    }
    editor.snaps.clearIndicators();
    const isSnapping = editor.user.getIsSnapMode() ? !accelKey : accelKey;
    let snappedToPit = false;
    if (isSnapping && editor.inputs.getPointerVelocity().len() < 0.5) {
        const { nudge } = editor.snaps.shapeBounds.snapTranslateShapes({
            dragDelta: delta,
            initialSelectionPageBounds: initialPageBounds,
            lockedAxis: flatten,
            initialSelectionSnapPoints: initialSnapPoints
        });
        delta.add(nudge);
    } else {
        if (noteSnapshot && noteAdjacentPositions) {
            const { scale } = noteSnapshot.shape.props;
            const pageCenter = noteSnapshot.pagePoint.clone().add(delta).add(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOTE_CENTER_OFFSET"].clone().mul(scale).rot(noteSnapshot.pageRotation));
            let min = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$noteHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOTE_ADJACENT_POSITION_SNAP_RADIUS"] / editor.getZoomLevel();
            let offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
            for (const pit of noteAdjacentPositions){
                const deltaToPit = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(pageCenter, pit);
                const dist = deltaToPit.len();
                if (dist < min) {
                    snappedToPit = true;
                    min = dist;
                    offset = deltaToPit;
                }
            }
            delta.sub(offset);
        }
    }
    const averageSnappedPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(averagePagePoint, delta);
    const snapIndicators = editor.snaps.getIndicators();
    if (isGridMode && !accelKey && !snappedToPit && snapIndicators.length === 0) {
        averageSnappedPoint.snapToGrid(gridSize);
    }
    const averageSnap = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(averageSnappedPoint, averagePagePoint);
    editor.updateShapes((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(shapeSnapshots.map(({ shape, pagePoint, parentTransform })=>{
        const newPagePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(pagePoint, averageSnap);
        const newLocalPoint = parentTransform ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(parentTransform, newPagePoint) : newPagePoint;
        return {
            id: shape.id,
            type: shape.type,
            x: newLocalPoint.x,
            y: newLocalPoint.y
        };
    })));
}
;
 //# sourceMappingURL=Translating.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/SelectTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SelectTool",
    ()=>SelectTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Brushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Brushing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$Crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/Crop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Cropping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/Cropping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCropHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Crop/children/PointingCropHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$DraggingHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/DraggingHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$EditingShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/EditingShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingArrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingArrowLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingCanvas$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingCanvas.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingResizeHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingRotateHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingRotateHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingSelection$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingSelection.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/PointingShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Resizing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Resizing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Rotating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Rotating.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$ScribbleBrushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/ScribbleBrushing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Translating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/childStates/Translating.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class SelectTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "select";
    static initial = "idle";
    static isLockable = false;
    reactor = void 0;
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$Crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Crop"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$Cropping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cropping"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingCanvas$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingCanvas"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingShape"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Translating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Translating"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Brushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Brushing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$ScribbleBrushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScribbleBrushing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Crop$2f$children$2f$PointingCropHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingCropHandle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingSelection$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingSelection"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingResizeHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingResizeHandle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$EditingShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditingShape"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Resizing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Resizing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$Rotating$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Rotating"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingRotateHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingRotateHandle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingArrowLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingArrowLabel"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$PointingHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointingHandle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$childStates$2f$DraggingHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DraggingHandle"]
        ];
    }
    // We want to clean up the duplicate props when the selection changes
    cleanUpDuplicateProps() {
        const selectedShapeIds = this.editor.getSelectedShapeIds();
        const instance = this.editor.getInstanceState();
        if (!instance.duplicateProps) return;
        const duplicatedShapes = new Set(instance.duplicateProps.shapeIds);
        if (selectedShapeIds.length === duplicatedShapes.size && selectedShapeIds.every((shapeId)=>duplicatedShapes.has(shapeId))) {
            return;
        }
        this.editor.updateInstanceState({
            duplicateProps: null
        });
    }
    onEnter() {
        this.reactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("clean duplicate props", ()=>{
            try {
                this.cleanUpDuplicateProps();
            } catch (e) {
                if ("TURBOPACK compile-time falsy", 0) {} else {
                    console.error(e);
                }
            }
        });
    }
    onExit() {
        this.reactor?.();
        if (this.editor.getCurrentPageState().editingShapeId) {
            this.editor.setEditingShape(null);
        }
    }
}
;
 //# sourceMappingURL=SelectTool.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    info = {};
    onEnter(info) {
        this.info = info;
    }
    onPointerDown() {
        this.parent.transition("pointing", this.info);
    }
    onKeyDown(info) {
        if (info.key === "Shift") {
            this.parent.transition("zoom_quick", this.info);
        }
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/Pointing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pointing",
    ()=>Pointing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Pointing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing";
    info = {};
    onEnter(info) {
        this.info = info;
    }
    onPointerUp() {
        this.complete();
    }
    onPointerMove() {
        if (this.editor.inputs.getIsDragging()) {
            this.parent.transition("zoom_brushing", this.info);
        }
    }
    onCancel() {
        this.cancel();
    }
    complete() {
        const currentScreenPoint = this.editor.inputs.getCurrentScreenPoint();
        if (this.editor.inputs.getAltKey()) {
            this.editor.zoomOut(currentScreenPoint, {
                animation: {
                    duration: 220
                }
            });
        } else {
            this.editor.zoomIn(currentScreenPoint, {
                animation: {
                    duration: 220
                }
            });
        }
        this.parent.transition("idle", this.info);
    }
    cancel() {
        this.parent.transition("idle", this.info);
    }
}
;
 //# sourceMappingURL=Pointing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/ZoomBrushing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZoomBrushing",
    ()=>ZoomBrushing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class ZoomBrushing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "zoom_brushing";
    info = {};
    zoomBrush = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]();
    onEnter(info) {
        this.info = info;
        this.update();
    }
    onExit() {
        this.editor.updateInstanceState({
            zoomBrush: null
        });
    }
    onPointerMove() {
        this.update();
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    update() {
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        const currentPagePoint = this.editor.inputs.getCurrentPagePoint();
        this.zoomBrush.setTo(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints([
            originPagePoint,
            currentPagePoint
        ]));
        this.editor.updateInstanceState({
            zoomBrush: this.zoomBrush.toJson()
        });
    }
    cancel() {
        this.parent.transition("idle", this.info);
    }
    complete() {
        const { zoomBrush } = this;
        const threshold = 8 / this.editor.getZoomLevel();
        if (zoomBrush.width < threshold && zoomBrush.height < threshold) {
            const point = this.editor.inputs.getCurrentScreenPoint();
            if (this.editor.inputs.getAltKey()) {
                this.editor.zoomOut(point, {
                    animation: {
                        duration: 220
                    }
                });
            } else {
                this.editor.zoomIn(point, {
                    animation: {
                        duration: 220
                    }
                });
            }
        } else {
            const targetZoom = this.editor.inputs.getAltKey() ? this.editor.getZoomLevel() / 2 : void 0;
            this.editor.zoomToBounds(zoomBrush, {
                targetZoom,
                animation: {
                    duration: 220
                }
            });
        }
        this.parent.transition("idle", this.info);
    }
}
;
 //# sourceMappingURL=ZoomBrushing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/ZoomQuick.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZoomQuick",
    ()=>ZoomQuick
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript)");
;
class ZoomQuick extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "zoom_quick";
    info = {};
    qzState = "idle";
    initialVpb = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]();
    initialPp = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
    /** The camera zoom right after the overview zoom-out in onEnter. */ overviewZoom = 1;
    cleanupZoomReactor() {}
    nextVpb = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]();
    onEnter(info) {
        const { editor } = this;
        this.info = info;
        this.qzState = "idle";
        this.initialVpb = editor.getViewportPageBounds();
        this.initialPp = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(editor.inputs.getCurrentPagePoint());
        editor.setCursor({
            type: "zoom-in",
            rotation: 0
        });
        const vpb = this.initialVpb;
        const pageBounds = editor.getCurrentPageBounds();
        const commonBounds = pageBounds ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Expand(vpb, pageBounds) : vpb.clone();
        const vsb = editor.getViewportScreenBounds();
        const sp = editor.inputs.getCurrentScreenPoint();
        const sx = sp.x - vsb.x;
        const sy = sp.y - vsb.y;
        const { x: px, y: py } = this.initialPp;
        const dLeft = px - commonBounds.minX;
        const dRight = commonBounds.maxX - px;
        const dTop = py - commonBounds.minY;
        const dBottom = commonBounds.maxY - py;
        let targetZoom = editor.getCamera().z;
        if (dLeft > 0) targetZoom = Math.min(targetZoom, sx / dLeft);
        if (dRight > 0) targetZoom = Math.min(targetZoom, (vsb.w - sx) / dRight);
        if (dTop > 0) targetZoom = Math.min(targetZoom, sy / dTop);
        if (dBottom > 0) targetZoom = Math.min(targetZoom, (vsb.h - sy) / dBottom);
        targetZoom *= 0.85;
        targetZoom = Math.max(editor.getCameraOptions().zoomSteps[0], targetZoom);
        this.overviewZoom = targetZoom;
        if (editor.options.quickZoomPreservesScreenBounds) {
            this.cleanupZoomReactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("zoom change in quick zoom", ()=>{
                editor.getZoomLevel();
                this.updateBrush();
            });
        }
        const { x: cx, y: cy, z: cz } = editor.getCamera();
        const ratio = cz / targetZoom;
        editor.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((cx + px) * ratio - px, (cy + py) * ratio - py, targetZoom));
        if (!editor.options.quickZoomPreservesScreenBounds) {
            this.updateBrush();
        }
    }
    onExit() {
        this.cleanupZoomReactor();
        this.zoomToNewViewport();
        this.editor.updateInstanceState({
            zoomBrush: null
        });
    }
    onPointerUp() {
        const toolId = this.info.onInteractionEnd?.split(".")[0] ?? "select";
        this.editor.setCurrentTool(toolId);
    }
    onCancel() {
        this.qzState = "idle";
        const toolId = this.info.onInteractionEnd?.split(".")[0] ?? "select";
        this.editor.setCurrentTool(toolId);
    }
    onKeyUp(info) {
        if (info.key === "Shift") {
            this.parent.transition("idle", this.info);
        }
    }
    updateBrush() {
        const { editor } = this;
        const nextVpb = this.getNextVpb();
        this.nextVpb.setTo(nextVpb);
        editor.updateInstanceState({
            zoomBrush: nextVpb.toJson()
        });
    }
    zoomToNewViewport() {
        const { editor } = this;
        switch(this.qzState){
            case "idle":
                editor.zoomToBounds(this.initialVpb, {
                    inset: 0
                });
                break;
            case "moving":
                editor.zoomToBounds(this.nextVpb, {
                    inset: 0
                });
                break;
        }
    }
    onPointerMove() {
        if (this.qzState !== "moving") return;
        this.updateBrush();
    }
    onTick() {
        const { editor } = this;
        switch(this.qzState){
            case "idle":
                {
                    const zoomLevel = editor.getZoomLevel();
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(editor.inputs.getCurrentPagePoint(), this.initialPp) * zoomLevel > editor.options.dragDistanceSquared / zoomLevel) {
                        this.qzState = "moving";
                        this.updateBrush();
                    }
                    break;
                }
            case "moving":
                break;
        }
    }
    getNextVpb() {
        const { editor } = this;
        let w;
        let h;
        if (editor.options.quickZoomPreservesScreenBounds) {
            const zoomRatio = this.overviewZoom / editor.getCamera().z;
            w = this.initialVpb.w * zoomRatio;
            h = this.initialVpb.h * zoomRatio;
        } else {
            w = this.initialVpb.w;
            h = this.initialVpb.h;
        }
        const { x, y } = editor.inputs.getCurrentPagePoint();
        const vsb = editor.getViewportScreenBounds();
        const vsp = editor.inputs.getCurrentScreenPoint();
        const { x: nx, y: ny } = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((vsp.x - vsb.x) / vsb.w, (vsp.y - vsb.y) / vsb.h);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](x - nx * w, y - ny * h, w, h);
    }
}
;
 //# sourceMappingURL=ZoomQuick.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/ZoomTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZoomTool",
    ()=>ZoomTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/Pointing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$ZoomBrushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/ZoomBrushing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$ZoomQuick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/childStates/ZoomQuick.mjs [app-client] (ecmascript)");
;
;
;
;
;
class ZoomTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "zoom";
    static initial = "idle";
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pointing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$ZoomBrushing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZoomBrushing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$childStates$2f$ZoomQuick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZoomQuick"]
        ];
    }
    static isLockable = false;
    info = {};
    onEnter(info) {
        this.info = info;
        const toolId = info.onInteractionEnd?.split(".")[0];
        this.parent.setCurrentToolIdMask(toolId);
        this.updateCursor();
    }
    onExit() {
        this.parent.setCurrentToolIdMask(void 0);
        this.editor.updateInstanceState({
            zoomBrush: null,
            cursor: {
                type: "default",
                rotation: 0
            }
        });
    }
    onKeyDown() {
        this.updateCursor();
    }
    onKeyUp(info) {
        this.updateCursor();
        if (info.key.toLowerCase() === "z") {
            this.complete();
        }
    }
    onInterrupt() {
        this.complete();
    }
    complete() {
        const toolId = this.info.onInteractionEnd?.split(".")[0] ?? "select";
        this.editor.setCurrentTool(toolId);
    }
    updateCursor() {
        if (this.editor.inputs.getAltKey() && !this.editor.isIn("zoom.zoom_quick")) {
            this.editor.setCursor({
                type: "zoom-out",
                rotation: 0
            });
        } else {
            this.editor.setCursor({
                type: "zoom-in",
                rotation: 0
            });
        }
    }
}
;
 //# sourceMappingURL=ZoomTool.mjs.map
}),
]);

//# debugId=fc797bda-55a9-33fd-09ff-6396cb3bbf3d
//# sourceMappingURL=c427b_tldraw_dist-esm_lib_tools_d1a17406._.js.map