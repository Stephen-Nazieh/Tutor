(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/c427b_351cdf24._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_0d64cefe._.js"
],
    source: "dynamic"
});
