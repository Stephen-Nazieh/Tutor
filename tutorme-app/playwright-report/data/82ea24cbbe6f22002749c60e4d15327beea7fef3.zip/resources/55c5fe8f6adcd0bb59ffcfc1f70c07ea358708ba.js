;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="4d65853e-c4c1-6bcb-cf84-f29a7f297ccc")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@daily-co/daily-js/dist/daily-esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DAILY_ACCESS_LEVEL_FULL",
    ()=>vi,
    "DAILY_ACCESS_LEVEL_LOBBY",
    ()=>gi,
    "DAILY_ACCESS_LEVEL_NONE",
    ()=>mi,
    "DAILY_ACCESS_UNKNOWN",
    ()=>fi,
    "DAILY_CAMERA_ERROR_CAM_AND_MIC_IN_USE",
    ()=>Ii,
    "DAILY_CAMERA_ERROR_CAM_IN_USE",
    ()=>Ai,
    "DAILY_CAMERA_ERROR_CONSTRAINTS",
    ()=>Ni,
    "DAILY_CAMERA_ERROR_MIC_IN_USE",
    ()=>ji,
    "DAILY_CAMERA_ERROR_NOT_FOUND",
    ()=>Di,
    "DAILY_CAMERA_ERROR_PERMISSIONS",
    ()=>xi,
    "DAILY_CAMERA_ERROR_UNDEF_MEDIADEVICES",
    ()=>Li,
    "DAILY_CAMERA_ERROR_UNKNOWN",
    ()=>Ri,
    "DAILY_EVENT_ACCESS_STATE_UPDATED",
    ()=>Zi,
    "DAILY_EVENT_ACTIVE_SPEAKER_CHANGE",
    ()=>Eo,
    "DAILY_EVENT_ACTIVE_SPEAKER_MODE_CHANGE",
    ()=>To,
    "DAILY_EVENT_APP_MSG",
    ()=>yo,
    "DAILY_EVENT_CAMERA_ERROR",
    ()=>zi,
    "DAILY_EVENT_CPU_LOAD_CHANGE",
    ()=>Ao,
    "DAILY_EVENT_ERROR",
    ()=>Jo,
    "DAILY_EVENT_EXIT_FULLSCREEN",
    ()=>xo,
    "DAILY_EVENT_FACE_COUNTS_UPDATED",
    ()=>jo,
    "DAILY_EVENT_FULLSCREEN",
    ()=>Io,
    "DAILY_EVENT_IFRAME_LAUNCH_CONFIG",
    ()=>Bi,
    "DAILY_EVENT_IFRAME_READY_FOR_LAUNCH_CONFIG",
    ()=>Fi,
    "DAILY_EVENT_INPUT_SETTINGS_UPDATED",
    ()=>Uo,
    "DAILY_EVENT_JOINED_MEETING",
    ()=>Hi,
    "DAILY_EVENT_JOINING_MEETING",
    ()=>Wi,
    "DAILY_EVENT_LANG_UPDATED",
    ()=>Fo,
    "DAILY_EVENT_LEFT_MEETING",
    ()=>Gi,
    "DAILY_EVENT_LIVE_STREAMING_ERROR",
    ()=>Ro,
    "DAILY_EVENT_LIVE_STREAMING_STARTED",
    ()=>Lo,
    "DAILY_EVENT_LIVE_STREAMING_STOPPED",
    ()=>No,
    "DAILY_EVENT_LIVE_STREAMING_UPDATED",
    ()=>Do,
    "DAILY_EVENT_LOADED",
    ()=>$i,
    "DAILY_EVENT_LOADING",
    ()=>Vi,
    "DAILY_EVENT_LOAD_ATTEMPT_FAILED",
    ()=>Ji,
    "DAILY_EVENT_LOCAL_SCREEN_SHARE_CANCELED",
    ()=>Co,
    "DAILY_EVENT_LOCAL_SCREEN_SHARE_STARTED",
    ()=>ko,
    "DAILY_EVENT_LOCAL_SCREEN_SHARE_STOPPED",
    ()=>Mo,
    "DAILY_EVENT_MEETING_SESSION_DATA_ERROR",
    ()=>no,
    "DAILY_EVENT_MEETING_SESSION_STATE_UPDATED",
    ()=>to,
    "DAILY_EVENT_MEETING_SESSION_SUMMARY_UPDATED",
    ()=>eo,
    "DAILY_EVENT_NETWORK_CONNECTION",
    ()=>Po,
    "DAILY_EVENT_NETWORK_QUALITY_CHANGE",
    ()=>Oo,
    "DAILY_EVENT_NONFATAL_ERROR",
    ()=>Vo,
    "DAILY_EVENT_PARTICIPANT_COUNTS_UPDATED",
    ()=>Xi,
    "DAILY_EVENT_PARTICIPANT_JOINED",
    ()=>Qi,
    "DAILY_EVENT_PARTICIPANT_LEFT",
    ()=>Yi,
    "DAILY_EVENT_PARTICIPANT_UPDATED",
    ()=>Ki,
    "DAILY_EVENT_RECEIVE_SETTINGS_UPDATED",
    ()=>Bo,
    "DAILY_EVENT_RECORDING_DATA",
    ()=>mo,
    "DAILY_EVENT_RECORDING_ERROR",
    ()=>vo,
    "DAILY_EVENT_RECORDING_STARTED",
    ()=>po,
    "DAILY_EVENT_RECORDING_STATS",
    ()=>fo,
    "DAILY_EVENT_RECORDING_STOPPED",
    ()=>ho,
    "DAILY_EVENT_RECORDING_UPLOAD_COMPLETED",
    ()=>go,
    "DAILY_EVENT_REMOTE_MEDIA_PLAYER_STARTED",
    ()=>_o,
    "DAILY_EVENT_REMOTE_MEDIA_PLAYER_STOPPED",
    ()=>So,
    "DAILY_EVENT_REMOTE_MEDIA_PLAYER_UPDATED",
    ()=>wo,
    "DAILY_EVENT_STARTED_CAMERA",
    ()=>qi,
    "DAILY_EVENT_THEME_UPDATED",
    ()=>Ui,
    "DAILY_EVENT_TRACK_STARTED",
    ()=>so,
    "DAILY_EVENT_TRACK_STOPPED",
    ()=>ao,
    "DAILY_EVENT_TRANSCRIPTION_ERROR",
    ()=>uo,
    "DAILY_EVENT_TRANSCRIPTION_MSG",
    ()=>bo,
    "DAILY_EVENT_TRANSCRIPTION_STARTED",
    ()=>co,
    "DAILY_EVENT_TRANSCRIPTION_STOPPED",
    ()=>lo,
    "DAILY_EVENT_WAITING_PARTICIPANT_ADDED",
    ()=>ro,
    "DAILY_EVENT_WAITING_PARTICIPANT_REMOVED",
    ()=>oo,
    "DAILY_EVENT_WAITING_PARTICIPANT_UPDATED",
    ()=>io,
    "DAILY_FATAL_ERROR_CONNECTION",
    ()=>Pi,
    "DAILY_FATAL_ERROR_EJECTED",
    ()=>_i,
    "DAILY_FATAL_ERROR_EOL",
    ()=>Ti,
    "DAILY_FATAL_ERROR_EXP_ROOM",
    ()=>ki,
    "DAILY_FATAL_ERROR_EXP_TOKEN",
    ()=>Mi,
    "DAILY_FATAL_ERROR_MEETING_FULL",
    ()=>Ei,
    "DAILY_FATAL_ERROR_NBF_ROOM",
    ()=>wi,
    "DAILY_FATAL_ERROR_NBF_TOKEN",
    ()=>Si,
    "DAILY_FATAL_ERROR_NOT_ALLOWED",
    ()=>Oi,
    "DAILY_FATAL_ERROR_NO_ROOM",
    ()=>Ci,
    "DAILY_RECEIVE_SETTINGS_ALL_PARTICIPANTS_KEY",
    ()=>bi,
    "DAILY_RECEIVE_SETTINGS_BASE_KEY",
    ()=>yi,
    "DAILY_STATE_ERROR",
    ()=>ai,
    "DAILY_STATE_JOINED",
    ()=>oi,
    "DAILY_STATE_JOINING",
    ()=>ii,
    "DAILY_STATE_LEFT",
    ()=>si,
    "DAILY_STATE_NEW",
    ()=>ti,
    "DAILY_TRACK_STATE_BLOCKED",
    ()=>ci,
    "DAILY_TRACK_STATE_INTERRUPTED",
    ()=>pi,
    "DAILY_TRACK_STATE_LOADING",
    ()=>di,
    "DAILY_TRACK_STATE_OFF",
    ()=>li,
    "DAILY_TRACK_STATE_PLAYABLE",
    ()=>hi,
    "DAILY_TRACK_STATE_SENDABLE",
    ()=>ui,
    "default",
    ()=>Ha
]);
function e(e, t) {
    if (null == e) return {};
    var n, r, i = function(e, t) {
        if (null == e) return {};
        var n = {};
        for(var r in e)if (({}).hasOwnProperty.call(e, r)) {
            if (-1 !== t.indexOf(r)) continue;
            n[r] = e[r];
        }
        return n;
    }(e, t);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for(r = 0; r < o.length; r++)n = o[r], -1 === t.indexOf(n) && ({}).propertyIsEnumerable.call(e, n) && (i[n] = e[n]);
    }
    return i;
}
function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}
function n(e) {
    return n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e;
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, n(e);
}
function r(e) {
    var t = function(e, t) {
        if ("object" != n(e) || !e) return e;
        var r = e[Symbol.toPrimitive];
        if (void 0 !== r) {
            var i = r.call(e, t || "default");
            if ("object" != n(i)) return i;
            throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return (("TURBOPACK compile-time truthy", 1) ? String : "TURBOPACK unreachable")(e);
    }(e, "string");
    return "symbol" == n(t) ? t : t + "";
}
function i(e, t) {
    for(var n = 0; n < t.length; n++){
        var i = t[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, r(i.key), i);
    }
}
function o(e, t, n) {
    return t && i(e.prototype, t), n && i(e, n), Object.defineProperty(e, "prototype", {
        writable: !1
    }), e;
}
function s(e, t) {
    if (t && ("object" == n(t) || "function" == typeof t)) return t;
    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
    return function(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e;
    }(e);
}
function a(e) {
    return a = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
        return e.__proto__ || Object.getPrototypeOf(e);
    }, a(e);
}
function c(e, t) {
    return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
        return e.__proto__ = t, e;
    }, c(e, t);
}
function l(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(e, "prototype", {
        writable: !1
    }), t && c(e, t);
}
function u(e, t, n) {
    return (t = r(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}
function d(e, t, n, r, i, o, s) {
    try {
        var a = e[o](s), c = a.value;
    } catch (e) {
        return void n(e);
    }
    a.done ? t(c) : Promise.resolve(c).then(r, i);
}
function p(e) {
    return function() {
        var t = this, n = arguments;
        return new Promise(function(r, i) {
            var o = e.apply(t, n);
            function s(e) {
                d(o, r, i, s, a, "next", e);
            }
            function a(e) {
                d(o, r, i, s, a, "throw", e);
            }
            s(void 0);
        });
    };
}
function h(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for(var n = 0, r = Array(t); n < t; n++)r[n] = e[n];
    return r;
}
function f(e, t) {
    return function(e) {
        if (Array.isArray(e)) return e;
    }(e) || function(e, t) {
        var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (null != n) {
            var r, i, o, s, a = [], c = !0, l = !1;
            try {
                if (o = (n = n.call(e)).next, 0 === t) {
                    if (Object(n) !== n) return;
                    c = !1;
                } else for(; !(c = (r = o.call(n)).done) && (a.push(r.value), a.length !== t); c = !0);
            } catch (e) {
                l = !0, i = e;
            } finally{
                try {
                    if (!c && null != n.return && (s = n.return(), Object(s) !== s)) return;
                } finally{
                    if (l) throw i;
                }
            }
            return a;
        }
    }(e, t) || function(e, t) {
        if (e) {
            if ("string" == typeof e) return h(e, t);
            var n = ({}).toString.call(e).slice(8, -1);
            return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? h(e, t) : void 0;
        }
    }(e, t) || function() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
}
function v(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var g, m = {
    exports: {}
};
var y = function() {
    if (g) return m.exports;
    g = 1;
    var e, t = "object" == typeof Reflect ? Reflect : null, n = t && "function" == typeof t.apply ? t.apply : function(e, t, n) {
        return Function.prototype.apply.call(e, t, n);
    };
    e = t && "function" == typeof t.ownKeys ? t.ownKeys : Object.getOwnPropertySymbols ? function(e) {
        return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
    } : function(e) {
        return Object.getOwnPropertyNames(e);
    };
    var r = Number.isNaN || function(e) {
        return e != e;
    };
    function i() {
        i.init.call(this);
    }
    m.exports = i, m.exports.once = function(e, t) {
        return new Promise(function(n, r) {
            function i(n) {
                e.removeListener(t, o), r(n);
            }
            function o() {
                "function" == typeof e.removeListener && e.removeListener("error", i), n([].slice.call(arguments));
            }
            f(e, t, o, {
                once: !0
            }), "error" !== t && function(e, t, n) {
                "function" == typeof e.on && f(e, "error", t, n);
            }(e, i, {
                once: !0
            });
        });
    }, i.EventEmitter = i, i.prototype._events = void 0, i.prototype._eventsCount = 0, i.prototype._maxListeners = void 0;
    var o = 10;
    function s(e) {
        if ("function" != typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e);
    }
    function a(e) {
        return void 0 === e._maxListeners ? i.defaultMaxListeners : e._maxListeners;
    }
    function c(e, t, n, r) {
        var i, o, c, l;
        if (s(n), void 0 === (o = e._events) ? (o = e._events = Object.create(null), e._eventsCount = 0) : (void 0 !== o.newListener && (e.emit("newListener", t, n.listener ? n.listener : n), o = e._events), c = o[t]), void 0 === c) c = o[t] = n, ++e._eventsCount;
        else if ("function" == typeof c ? c = o[t] = r ? [
            n,
            c
        ] : [
            c,
            n
        ] : r ? c.unshift(n) : c.push(n), (i = a(e)) > 0 && c.length > i && !c.warned) {
            c.warned = !0;
            var u = new Error("Possible EventEmitter memory leak detected. " + c.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
            u.name = "MaxListenersExceededWarning", u.emitter = e, u.type = t, u.count = c.length, l = u, console && console.warn && console.warn(l);
        }
        return e;
    }
    function l() {
        if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, 0 === arguments.length ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
    }
    function u(e, t, n) {
        var r = {
            fired: !1,
            wrapFn: void 0,
            target: e,
            type: t,
            listener: n
        }, i = l.bind(r);
        return i.listener = n, r.wrapFn = i, i;
    }
    function d(e, t, n) {
        var r = e._events;
        if (void 0 === r) return [];
        var i = r[t];
        return void 0 === i ? [] : "function" == typeof i ? n ? [
            i.listener || i
        ] : [
            i
        ] : n ? function(e) {
            for(var t = new Array(e.length), n = 0; n < t.length; ++n)t[n] = e[n].listener || e[n];
            return t;
        }(i) : h(i, i.length);
    }
    function p(e) {
        var t = this._events;
        if (void 0 !== t) {
            var n = t[e];
            if ("function" == typeof n) return 1;
            if (void 0 !== n) return n.length;
        }
        return 0;
    }
    function h(e, t) {
        for(var n = new Array(t), r = 0; r < t; ++r)n[r] = e[r];
        return n;
    }
    function f(e, t, n, r) {
        if ("function" == typeof e.on) r.once ? e.once(t, n) : e.on(t, n);
        else {
            if ("function" != typeof e.addEventListener) throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e);
            e.addEventListener(t, function i(o) {
                r.once && e.removeEventListener(t, i), n(o);
            });
        }
    }
    return Object.defineProperty(i, "defaultMaxListeners", {
        enumerable: !0,
        get: function() {
            return o;
        },
        set: function(e) {
            if ("number" != typeof e || e < 0 || r(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
            o = e;
        }
    }), i.init = function() {
        void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
    }, i.prototype.setMaxListeners = function(e) {
        if ("number" != typeof e || e < 0 || r(e)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
        return this._maxListeners = e, this;
    }, i.prototype.getMaxListeners = function() {
        return a(this);
    }, i.prototype.emit = function(e) {
        for(var t = [], r = 1; r < arguments.length; r++)t.push(arguments[r]);
        var i = "error" === e, o = this._events;
        if (void 0 !== o) i = i && void 0 === o.error;
        else if (!i) return !1;
        if (i) {
            var s;
            if (t.length > 0 && (s = t[0]), s instanceof Error) throw s;
            var a = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
            throw a.context = s, a;
        }
        var c = o[e];
        if (void 0 === c) return !1;
        if ("function" == typeof c) n(c, this, t);
        else {
            var l = c.length, u = h(c, l);
            for(r = 0; r < l; ++r)n(u[r], this, t);
        }
        return !0;
    }, i.prototype.addListener = function(e, t) {
        return c(this, e, t, !1);
    }, i.prototype.on = i.prototype.addListener, i.prototype.prependListener = function(e, t) {
        return c(this, e, t, !0);
    }, i.prototype.once = function(e, t) {
        return s(t), this.on(e, u(this, e, t)), this;
    }, i.prototype.prependOnceListener = function(e, t) {
        return s(t), this.prependListener(e, u(this, e, t)), this;
    }, i.prototype.removeListener = function(e, t) {
        var n, r, i, o, a;
        if (s(t), void 0 === (r = this._events)) return this;
        if (void 0 === (n = r[e])) return this;
        if (n === t || n.listener === t) 0 == --this._eventsCount ? this._events = Object.create(null) : (delete r[e], r.removeListener && this.emit("removeListener", e, n.listener || t));
        else if ("function" != typeof n) {
            for(i = -1, o = n.length - 1; o >= 0; o--)if (n[o] === t || n[o].listener === t) {
                a = n[o].listener, i = o;
                break;
            }
            if (i < 0) return this;
            0 === i ? n.shift() : function(e, t) {
                for(; t + 1 < e.length; t++)e[t] = e[t + 1];
                e.pop();
            }(n, i), 1 === n.length && (r[e] = n[0]), void 0 !== r.removeListener && this.emit("removeListener", e, a || t);
        }
        return this;
    }, i.prototype.off = i.prototype.removeListener, i.prototype.removeAllListeners = function(e) {
        var t, n, r;
        if (void 0 === (n = this._events)) return this;
        if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), this._eventsCount = 0) : void 0 !== n[e] && (0 == --this._eventsCount ? this._events = Object.create(null) : delete n[e]), this;
        if (0 === arguments.length) {
            var i, o = Object.keys(n);
            for(r = 0; r < o.length; ++r)"removeListener" !== (i = o[r]) && this.removeAllListeners(i);
            return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this;
        }
        if ("function" == typeof (t = n[e])) this.removeListener(e, t);
        else if (void 0 !== t) for(r = t.length - 1; r >= 0; r--)this.removeListener(e, t[r]);
        return this;
    }, i.prototype.listeners = function(e) {
        return d(this, e, !0);
    }, i.prototype.rawListeners = function(e) {
        return d(this, e, !1);
    }, i.listenerCount = function(e, t) {
        return "function" == typeof e.listenerCount ? e.listenerCount(t) : p.call(e, t);
    }, i.prototype.listenerCount = p, i.prototype.eventNames = function() {
        return this._eventsCount > 0 ? e(this._events) : [];
    }, m.exports;
}(), b = v(y), _ = Object.prototype.hasOwnProperty;
function w(e, t, n) {
    for (n of e.keys())if (S(n, t)) return n;
}
function S(e, t) {
    var n, r, i;
    if (e === t) return !0;
    if (e && t && (n = e.constructor) === t.constructor) {
        if (n === Date) return e.getTime() === t.getTime();
        if (n === RegExp) return e.toString() === t.toString();
        if (n === Array) {
            if ((r = e.length) === t.length) for(; r-- && S(e[r], t[r]););
            return -1 === r;
        }
        if (n === Set) {
            if (e.size !== t.size) return !1;
            for (r of e){
                if ((i = r) && "object" == typeof i && !(i = w(t, i))) return !1;
                if (!t.has(i)) return !1;
            }
            return !0;
        }
        if (n === Map) {
            if (e.size !== t.size) return !1;
            for (r of e){
                if ((i = r[0]) && "object" == typeof i && !(i = w(t, i))) return !1;
                if (!S(r[1], t.get(i))) return !1;
            }
            return !0;
        }
        if (n === ArrayBuffer) e = new Uint8Array(e), t = new Uint8Array(t);
        else if (n === DataView) {
            if ((r = e.byteLength) === t.byteLength) for(; r-- && e.getInt8(r) === t.getInt8(r););
            return -1 === r;
        }
        if (ArrayBuffer.isView(e)) {
            if ((r = e.byteLength) === t.byteLength) for(; r-- && e[r] === t[r];);
            return -1 === r;
        }
        if (!n || "object" == typeof e) {
            for(n in r = 0, e){
                if (_.call(e, n) && ++r && !_.call(t, n)) return !1;
                if (!(n in t) || !S(e[n], t[n])) return !1;
            }
            return Object.keys(t).length === r;
        }
    }
    return e != e && t != t;
}
const k = {
    "Amazon Silk": "amazon_silk",
    "Android Browser": "android",
    Bada: "bada",
    BlackBerry: "blackberry",
    Chrome: "chrome",
    Chromium: "chromium",
    Electron: "electron",
    Epiphany: "epiphany",
    Firefox: "firefox",
    Focus: "focus",
    Generic: "generic",
    "Google Search": "google_search",
    Googlebot: "googlebot",
    "Internet Explorer": "ie",
    "K-Meleon": "k_meleon",
    Maxthon: "maxthon",
    "Microsoft Edge": "edge",
    "MZ Browser": "mz",
    "NAVER Whale Browser": "naver",
    Opera: "opera",
    "Opera Coast": "opera_coast",
    PhantomJS: "phantomjs",
    Puffin: "puffin",
    QupZilla: "qupzilla",
    QQ: "qq",
    QQLite: "qqlite",
    Safari: "safari",
    Sailfish: "sailfish",
    "Samsung Internet for Android": "samsung_internet",
    SeaMonkey: "seamonkey",
    Sleipnir: "sleipnir",
    Swing: "swing",
    Tizen: "tizen",
    "UC Browser": "uc",
    Vivaldi: "vivaldi",
    "WebOS Browser": "webos",
    WeChat: "wechat",
    "Yandex Browser": "yandex",
    Roku: "roku"
}, M = {
    amazon_silk: "Amazon Silk",
    android: "Android Browser",
    bada: "Bada",
    blackberry: "BlackBerry",
    chrome: "Chrome",
    chromium: "Chromium",
    electron: "Electron",
    epiphany: "Epiphany",
    firefox: "Firefox",
    focus: "Focus",
    generic: "Generic",
    googlebot: "Googlebot",
    google_search: "Google Search",
    ie: "Internet Explorer",
    k_meleon: "K-Meleon",
    maxthon: "Maxthon",
    edge: "Microsoft Edge",
    mz: "MZ Browser",
    naver: "NAVER Whale Browser",
    opera: "Opera",
    opera_coast: "Opera Coast",
    phantomjs: "PhantomJS",
    puffin: "Puffin",
    qupzilla: "QupZilla",
    qq: "QQ Browser",
    qqlite: "QQ Browser Lite",
    safari: "Safari",
    sailfish: "Sailfish",
    samsung_internet: "Samsung Internet for Android",
    seamonkey: "SeaMonkey",
    sleipnir: "Sleipnir",
    swing: "Swing",
    tizen: "Tizen",
    uc: "UC Browser",
    vivaldi: "Vivaldi",
    webos: "WebOS Browser",
    wechat: "WeChat",
    yandex: "Yandex Browser"
}, C = {
    tablet: "tablet",
    mobile: "mobile",
    desktop: "desktop",
    tv: "tv"
}, E = {
    WindowsPhone: "Windows Phone",
    Windows: "Windows",
    MacOS: "macOS",
    iOS: "iOS",
    Android: "Android",
    WebOS: "WebOS",
    BlackBerry: "BlackBerry",
    Bada: "Bada",
    Tizen: "Tizen",
    Linux: "Linux",
    ChromeOS: "Chrome OS",
    PlayStation4: "PlayStation 4",
    Roku: "Roku"
}, T = {
    EdgeHTML: "EdgeHTML",
    Blink: "Blink",
    Trident: "Trident",
    Presto: "Presto",
    Gecko: "Gecko",
    WebKit: "WebKit"
};
class O {
    static getFirstMatch(e, t) {
        const n = t.match(e);
        return n && n.length > 0 && n[1] || "";
    }
    static getSecondMatch(e, t) {
        const n = t.match(e);
        return n && n.length > 1 && n[2] || "";
    }
    static matchAndReturnConst(e, t, n) {
        if (e.test(t)) return n;
    }
    static getWindowsVersionName(e) {
        switch(e){
            case "NT":
                return "NT";
            case "XP":
            case "NT 5.1":
                return "XP";
            case "NT 5.0":
                return "2000";
            case "NT 5.2":
                return "2003";
            case "NT 6.0":
                return "Vista";
            case "NT 6.1":
                return "7";
            case "NT 6.2":
                return "8";
            case "NT 6.3":
                return "8.1";
            case "NT 10.0":
                return "10";
            default:
                return;
        }
    }
    static getMacOSVersionName(e) {
        const t = e.split(".").splice(0, 2).map((e)=>parseInt(e, 10) || 0);
        if (t.push(0), 10 === t[0]) switch(t[1]){
            case 5:
                return "Leopard";
            case 6:
                return "Snow Leopard";
            case 7:
                return "Lion";
            case 8:
                return "Mountain Lion";
            case 9:
                return "Mavericks";
            case 10:
                return "Yosemite";
            case 11:
                return "El Capitan";
            case 12:
                return "Sierra";
            case 13:
                return "High Sierra";
            case 14:
                return "Mojave";
            case 15:
                return "Catalina";
            default:
                return;
        }
    }
    static getAndroidVersionName(e) {
        const t = e.split(".").splice(0, 2).map((e)=>parseInt(e, 10) || 0);
        if (t.push(0), !(1 === t[0] && t[1] < 5)) return 1 === t[0] && t[1] < 6 ? "Cupcake" : 1 === t[0] && t[1] >= 6 ? "Donut" : 2 === t[0] && t[1] < 2 ? "Eclair" : 2 === t[0] && 2 === t[1] ? "Froyo" : 2 === t[0] && t[1] > 2 ? "Gingerbread" : 3 === t[0] ? "Honeycomb" : 4 === t[0] && t[1] < 1 ? "Ice Cream Sandwich" : 4 === t[0] && t[1] < 4 ? "Jelly Bean" : 4 === t[0] && t[1] >= 4 ? "KitKat" : 5 === t[0] ? "Lollipop" : 6 === t[0] ? "Marshmallow" : 7 === t[0] ? "Nougat" : 8 === t[0] ? "Oreo" : 9 === t[0] ? "Pie" : void 0;
    }
    static getVersionPrecision(e) {
        return e.split(".").length;
    }
    static compareVersions(e, t, n = !1) {
        const r = O.getVersionPrecision(e), i = O.getVersionPrecision(t);
        let o = Math.max(r, i), s = 0;
        const a = O.map([
            e,
            t
        ], (e)=>{
            const t = o - O.getVersionPrecision(e), n = e + new Array(t + 1).join(".0");
            return O.map(n.split("."), (e)=>new Array(20 - e.length).join("0") + e).reverse();
        });
        for(n && (s = o - Math.min(r, i)), o -= 1; o >= s;){
            if (a[0][o] > a[1][o]) return 1;
            if (a[0][o] === a[1][o]) {
                if (o === s) return 0;
                o -= 1;
            } else if (a[0][o] < a[1][o]) return -1;
        }
    }
    static map(e, t) {
        const n = [];
        let r;
        if (Array.prototype.map) return Array.prototype.map.call(e, t);
        for(r = 0; r < e.length; r += 1)n.push(t(e[r]));
        return n;
    }
    static find(e, t) {
        let n, r;
        if (Array.prototype.find) return Array.prototype.find.call(e, t);
        for(n = 0, r = e.length; n < r; n += 1){
            const r = e[n];
            if (t(r, n)) return r;
        }
    }
    static assign(e, ...t) {
        const n = e;
        let r, i;
        if ("TURBOPACK compile-time truthy", 1) return Object.assign(e, ...t);
        //TURBOPACK unreachable
        ;
    }
    static getBrowserAlias(e) {
        return k[e];
    }
    static getBrowserTypeByAlias(e) {
        return M[e] || "";
    }
}
const P = /version\/(\d+(\.?_?\d+)+)/i, A = [
    {
        test: [
            /googlebot/i
        ],
        describe (e) {
            const t = {
                name: "Googlebot"
            }, n = O.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /opera/i
        ],
        describe (e) {
            const t = {
                name: "Opera"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /opr\/|opios/i
        ],
        describe (e) {
            const t = {
                name: "Opera"
            }, n = O.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /SamsungBrowser/i
        ],
        describe (e) {
            const t = {
                name: "Samsung Internet for Android"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /Whale/i
        ],
        describe (e) {
            const t = {
                name: "NAVER Whale Browser"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /MZBrowser/i
        ],
        describe (e) {
            const t = {
                name: "MZ Browser"
            }, n = O.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /focus/i
        ],
        describe (e) {
            const t = {
                name: "Focus"
            }, n = O.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /swing/i
        ],
        describe (e) {
            const t = {
                name: "Swing"
            }, n = O.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /coast/i
        ],
        describe (e) {
            const t = {
                name: "Opera Coast"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /opt\/\d+(?:.?_?\d+)+/i
        ],
        describe (e) {
            const t = {
                name: "Opera Touch"
            }, n = O.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /yabrowser/i
        ],
        describe (e) {
            const t = {
                name: "Yandex Browser"
            }, n = O.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /ucbrowser/i
        ],
        describe (e) {
            const t = {
                name: "UC Browser"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /Maxthon|mxios/i
        ],
        describe (e) {
            const t = {
                name: "Maxthon"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /epiphany/i
        ],
        describe (e) {
            const t = {
                name: "Epiphany"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /puffin/i
        ],
        describe (e) {
            const t = {
                name: "Puffin"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /sleipnir/i
        ],
        describe (e) {
            const t = {
                name: "Sleipnir"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /k-meleon/i
        ],
        describe (e) {
            const t = {
                name: "K-Meleon"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /micromessenger/i
        ],
        describe (e) {
            const t = {
                name: "WeChat"
            }, n = O.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /qqbrowser/i
        ],
        describe (e) {
            const t = {
                name: /qqbrowserlite/i.test(e) ? "QQ Browser Lite" : "QQ Browser"
            }, n = O.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /msie|trident/i
        ],
        describe (e) {
            const t = {
                name: "Internet Explorer"
            }, n = O.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /\sedg\//i
        ],
        describe (e) {
            const t = {
                name: "Microsoft Edge"
            }, n = O.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /edg([ea]|ios)/i
        ],
        describe (e) {
            const t = {
                name: "Microsoft Edge"
            }, n = O.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /vivaldi/i
        ],
        describe (e) {
            const t = {
                name: "Vivaldi"
            }, n = O.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /seamonkey/i
        ],
        describe (e) {
            const t = {
                name: "SeaMonkey"
            }, n = O.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /sailfish/i
        ],
        describe (e) {
            const t = {
                name: "Sailfish"
            }, n = O.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /silk/i
        ],
        describe (e) {
            const t = {
                name: "Amazon Silk"
            }, n = O.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /phantom/i
        ],
        describe (e) {
            const t = {
                name: "PhantomJS"
            }, n = O.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /slimerjs/i
        ],
        describe (e) {
            const t = {
                name: "SlimerJS"
            }, n = O.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /blackberry|\bbb\d+/i,
            /rim\stablet/i
        ],
        describe (e) {
            const t = {
                name: "BlackBerry"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /(web|hpw)[o0]s/i
        ],
        describe (e) {
            const t = {
                name: "WebOS Browser"
            }, n = O.getFirstMatch(P, e) || O.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /bada/i
        ],
        describe (e) {
            const t = {
                name: "Bada"
            }, n = O.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /tizen/i
        ],
        describe (e) {
            const t = {
                name: "Tizen"
            }, n = O.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /qupzilla/i
        ],
        describe (e) {
            const t = {
                name: "QupZilla"
            }, n = O.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /firefox|iceweasel|fxios/i
        ],
        describe (e) {
            const t = {
                name: "Firefox"
            }, n = O.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /electron/i
        ],
        describe (e) {
            const t = {
                name: "Electron"
            }, n = O.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /MiuiBrowser/i
        ],
        describe (e) {
            const t = {
                name: "Miui"
            }, n = O.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /chromium/i
        ],
        describe (e) {
            const t = {
                name: "Chromium"
            }, n = O.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, e) || O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /chrome|crios|crmo/i
        ],
        describe (e) {
            const t = {
                name: "Chrome"
            }, n = O.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /GSA/i
        ],
        describe (e) {
            const t = {
                name: "Google Search"
            }, n = O.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test (e) {
            const t = !e.test(/like android/i), n = e.test(/android/i);
            return t && n;
        },
        describe (e) {
            const t = {
                name: "Android Browser"
            }, n = O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /playstation 4/i
        ],
        describe (e) {
            const t = {
                name: "PlayStation 4"
            }, n = O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /safari|applewebkit/i
        ],
        describe (e) {
            const t = {
                name: "Safari"
            }, n = O.getFirstMatch(P, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /.*/i
        ],
        describe (e) {
            const t = -1 !== e.search("\\(") ? /^(.*)\/(.*)[ \t]\((.*)/ : /^(.*)\/(.*) /;
            return {
                name: O.getFirstMatch(t, e),
                version: O.getSecondMatch(t, e)
            };
        }
    }
];
var j = [
    {
        test: [
            /Roku\/DVP/
        ],
        describe (e) {
            const t = O.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, e);
            return {
                name: E.Roku,
                version: t
            };
        }
    },
    {
        test: [
            /windows phone/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, e);
            return {
                name: E.WindowsPhone,
                version: t
            };
        }
    },
    {
        test: [
            /windows /i
        ],
        describe (e) {
            const t = O.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, e), n = O.getWindowsVersionName(t);
            return {
                name: E.Windows,
                version: t,
                versionName: n
            };
        }
    },
    {
        test: [
            /Macintosh(.*?) FxiOS(.*?)\//
        ],
        describe (e) {
            const t = {
                name: E.iOS
            }, n = O.getSecondMatch(/(Version\/)(\d[\d.]+)/, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /macintosh/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, e).replace(/[_\s]/g, "."), n = O.getMacOSVersionName(t), r = {
                name: E.MacOS,
                version: t
            };
            return n && (r.versionName = n), r;
        }
    },
    {
        test: [
            /(ipod|iphone|ipad)/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, e).replace(/[_\s]/g, ".");
            return {
                name: E.iOS,
                version: t
            };
        }
    },
    {
        test (e) {
            const t = !e.test(/like android/i), n = e.test(/android/i);
            return t && n;
        },
        describe (e) {
            const t = O.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, e), n = O.getAndroidVersionName(t), r = {
                name: E.Android,
                version: t
            };
            return n && (r.versionName = n), r;
        }
    },
    {
        test: [
            /(web|hpw)[o0]s/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, e), n = {
                name: E.WebOS
            };
            return t && t.length && (n.version = t), n;
        }
    },
    {
        test: [
            /blackberry|\bbb\d+/i,
            /rim\stablet/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, e) || O.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, e) || O.getFirstMatch(/\bbb(\d+)/i, e);
            return {
                name: E.BlackBerry,
                version: t
            };
        }
    },
    {
        test: [
            /bada/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, e);
            return {
                name: E.Bada,
                version: t
            };
        }
    },
    {
        test: [
            /tizen/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, e);
            return {
                name: E.Tizen,
                version: t
            };
        }
    },
    {
        test: [
            /linux/i
        ],
        describe: ()=>({
                name: E.Linux
            })
    },
    {
        test: [
            /CrOS/
        ],
        describe: ()=>({
                name: E.ChromeOS
            })
    },
    {
        test: [
            /PlayStation 4/
        ],
        describe (e) {
            const t = O.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, e);
            return {
                name: E.PlayStation4,
                version: t
            };
        }
    }
], I = [
    {
        test: [
            /googlebot/i
        ],
        describe: ()=>({
                type: "bot",
                vendor: "Google"
            })
    },
    {
        test: [
            /huawei/i
        ],
        describe (e) {
            const t = O.getFirstMatch(/(can-l01)/i, e) && "Nova", n = {
                type: C.mobile,
                vendor: "Huawei"
            };
            return t && (n.model = t), n;
        }
    },
    {
        test: [
            /nexus\s*(?:7|8|9|10).*/i
        ],
        describe: ()=>({
                type: C.tablet,
                vendor: "Nexus"
            })
    },
    {
        test: [
            /ipad/i
        ],
        describe: ()=>({
                type: C.tablet,
                vendor: "Apple",
                model: "iPad"
            })
    },
    {
        test: [
            /Macintosh(.*?) FxiOS(.*?)\//
        ],
        describe: ()=>({
                type: C.tablet,
                vendor: "Apple",
                model: "iPad"
            })
    },
    {
        test: [
            /kftt build/i
        ],
        describe: ()=>({
                type: C.tablet,
                vendor: "Amazon",
                model: "Kindle Fire HD 7"
            })
    },
    {
        test: [
            /silk/i
        ],
        describe: ()=>({
                type: C.tablet,
                vendor: "Amazon"
            })
    },
    {
        test: [
            /tablet(?! pc)/i
        ],
        describe: ()=>({
                type: C.tablet
            })
    },
    {
        test (e) {
            const t = e.test(/ipod|iphone/i), n = e.test(/like (ipod|iphone)/i);
            return t && !n;
        },
        describe (e) {
            const t = O.getFirstMatch(/(ipod|iphone)/i, e);
            return {
                type: C.mobile,
                vendor: "Apple",
                model: t
            };
        }
    },
    {
        test: [
            /nexus\s*[0-6].*/i,
            /galaxy nexus/i
        ],
        describe: ()=>({
                type: C.mobile,
                vendor: "Nexus"
            })
    },
    {
        test: [
            /[^-]mobi/i
        ],
        describe: ()=>({
                type: C.mobile
            })
    },
    {
        test: (e)=>"blackberry" === e.getBrowserName(!0),
        describe: ()=>({
                type: C.mobile,
                vendor: "BlackBerry"
            })
    },
    {
        test: (e)=>"bada" === e.getBrowserName(!0),
        describe: ()=>({
                type: C.mobile
            })
    },
    {
        test: (e)=>"windows phone" === e.getBrowserName(),
        describe: ()=>({
                type: C.mobile,
                vendor: "Microsoft"
            })
    },
    {
        test (e) {
            const t = Number(String(e.getOSVersion()).split(".")[0]);
            return "android" === e.getOSName(!0) && t >= 3;
        },
        describe: ()=>({
                type: C.tablet
            })
    },
    {
        test: (e)=>"android" === e.getOSName(!0),
        describe: ()=>({
                type: C.mobile
            })
    },
    {
        test: (e)=>"macos" === e.getOSName(!0),
        describe: ()=>({
                type: C.desktop,
                vendor: "Apple"
            })
    },
    {
        test: (e)=>"windows" === e.getOSName(!0),
        describe: ()=>({
                type: C.desktop
            })
    },
    {
        test: (e)=>"linux" === e.getOSName(!0),
        describe: ()=>({
                type: C.desktop
            })
    },
    {
        test: (e)=>"playstation 4" === e.getOSName(!0),
        describe: ()=>({
                type: C.tv
            })
    },
    {
        test: (e)=>"roku" === e.getOSName(!0),
        describe: ()=>({
                type: C.tv
            })
    }
], x = [
    {
        test: (e)=>"microsoft edge" === e.getBrowserName(!0),
        describe (e) {
            if (/\sedg\//i.test(e)) return {
                name: T.Blink
            };
            const t = O.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, e);
            return {
                name: T.EdgeHTML,
                version: t
            };
        }
    },
    {
        test: [
            /trident/i
        ],
        describe (e) {
            const t = {
                name: T.Trident
            }, n = O.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: (e)=>e.test(/presto/i),
        describe (e) {
            const t = {
                name: T.Presto
            }, n = O.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test (e) {
            const t = e.test(/gecko/i), n = e.test(/like gecko/i);
            return t && !n;
        },
        describe (e) {
            const t = {
                name: T.Gecko
            }, n = O.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    },
    {
        test: [
            /(apple)?webkit\/537\.36/i
        ],
        describe: ()=>({
                name: T.Blink
            })
    },
    {
        test: [
            /(apple)?webkit/i
        ],
        describe (e) {
            const t = {
                name: T.WebKit
            }, n = O.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, e);
            return n && (t.version = n), t;
        }
    }
];
class L {
    constructor(e, t = !1){
        if (null == e || "" === e) throw new Error("UserAgent parameter can't be empty");
        this._ua = e, this.parsedResult = {}, !0 !== t && this.parse();
    }
    getUA() {
        return this._ua;
    }
    test(e) {
        return e.test(this._ua);
    }
    parseBrowser() {
        this.parsedResult.browser = {};
        const e = O.find(A, (e)=>{
            if ("function" == typeof e.test) return e.test(this);
            if (e.test instanceof Array) return e.test.some((e)=>this.test(e));
            throw new Error("Browser's test function is not valid");
        });
        return e && (this.parsedResult.browser = e.describe(this.getUA())), this.parsedResult.browser;
    }
    getBrowser() {
        return this.parsedResult.browser ? this.parsedResult.browser : this.parseBrowser();
    }
    getBrowserName(e) {
        return e ? String(this.getBrowser().name).toLowerCase() || "" : this.getBrowser().name || "";
    }
    getBrowserVersion() {
        return this.getBrowser().version;
    }
    getOS() {
        return this.parsedResult.os ? this.parsedResult.os : this.parseOS();
    }
    parseOS() {
        this.parsedResult.os = {};
        const e = O.find(j, (e)=>{
            if ("function" == typeof e.test) return e.test(this);
            if (e.test instanceof Array) return e.test.some((e)=>this.test(e));
            throw new Error("Browser's test function is not valid");
        });
        return e && (this.parsedResult.os = e.describe(this.getUA())), this.parsedResult.os;
    }
    getOSName(e) {
        const { name: t } = this.getOS();
        return e ? String(t).toLowerCase() || "" : t || "";
    }
    getOSVersion() {
        return this.getOS().version;
    }
    getPlatform() {
        return this.parsedResult.platform ? this.parsedResult.platform : this.parsePlatform();
    }
    getPlatformType(e = !1) {
        const { type: t } = this.getPlatform();
        return e ? String(t).toLowerCase() || "" : t || "";
    }
    parsePlatform() {
        this.parsedResult.platform = {};
        const e = O.find(I, (e)=>{
            if ("function" == typeof e.test) return e.test(this);
            if (e.test instanceof Array) return e.test.some((e)=>this.test(e));
            throw new Error("Browser's test function is not valid");
        });
        return e && (this.parsedResult.platform = e.describe(this.getUA())), this.parsedResult.platform;
    }
    getEngine() {
        return this.parsedResult.engine ? this.parsedResult.engine : this.parseEngine();
    }
    getEngineName(e) {
        return e ? String(this.getEngine().name).toLowerCase() || "" : this.getEngine().name || "";
    }
    parseEngine() {
        this.parsedResult.engine = {};
        const e = O.find(x, (e)=>{
            if ("function" == typeof e.test) return e.test(this);
            if (e.test instanceof Array) return e.test.some((e)=>this.test(e));
            throw new Error("Browser's test function is not valid");
        });
        return e && (this.parsedResult.engine = e.describe(this.getUA())), this.parsedResult.engine;
    }
    parse() {
        return this.parseBrowser(), this.parseOS(), this.parsePlatform(), this.parseEngine(), this;
    }
    getResult() {
        return O.assign({}, this.parsedResult);
    }
    satisfies(e) {
        const t = {};
        let n = 0;
        const r = {};
        let i = 0;
        if (Object.keys(e).forEach((o)=>{
            const s = e[o];
            "string" == typeof s ? (r[o] = s, i += 1) : "object" == typeof s && (t[o] = s, n += 1);
        }), n > 0) {
            const e = Object.keys(t), n = O.find(e, (e)=>this.isOS(e));
            if (n) {
                const e = this.satisfies(t[n]);
                if (void 0 !== e) return e;
            }
            const r = O.find(e, (e)=>this.isPlatform(e));
            if (r) {
                const e = this.satisfies(t[r]);
                if (void 0 !== e) return e;
            }
        }
        if (i > 0) {
            const e = Object.keys(r), t = O.find(e, (e)=>this.isBrowser(e, !0));
            if (void 0 !== t) return this.compareVersion(r[t]);
        }
    }
    isBrowser(e, t = !1) {
        const n = this.getBrowserName().toLowerCase();
        let r = e.toLowerCase();
        const i = O.getBrowserTypeByAlias(r);
        return t && i && (r = i.toLowerCase()), r === n;
    }
    compareVersion(e) {
        let t = [
            0
        ], n = e, r = !1;
        const i = this.getBrowserVersion();
        if ("string" == typeof i) return ">" === e[0] || "<" === e[0] ? (n = e.substr(1), "=" === e[1] ? (r = !0, n = e.substr(2)) : t = [], ">" === e[0] ? t.push(1) : t.push(-1)) : "=" === e[0] ? n = e.substr(1) : "~" === e[0] && (r = !0, n = e.substr(1)), t.indexOf(O.compareVersions(i, n, r)) > -1;
    }
    isOS(e) {
        return this.getOSName(!0) === String(e).toLowerCase();
    }
    isPlatform(e) {
        return this.getPlatformType(!0) === String(e).toLowerCase();
    }
    isEngine(e) {
        return this.getEngineName(!0) === String(e).toLowerCase();
    }
    is(e, t = !1) {
        return this.isBrowser(e, t) || this.isOS(e) || this.isPlatform(e);
    }
    some(e = []) {
        return e.some((e)=>this.is(e));
    }
}
/*!
 * Bowser - a browser detector
 * https://github.com/lancedikson/bowser
 * MIT License | (c) Dustin Diaz 2012-2015
 * MIT License | (c) Denis Demchenko 2015-2019
 */ class D {
    static getParser(e, t = !1) {
        if ("string" != typeof e) throw new Error("UserAgent should be a string");
        return new L(e, t);
    }
    static parse(e) {
        return new L(e).getResult();
    }
    static get BROWSER_MAP() {
        return M;
    }
    static get ENGINE_MAP() {
        return T;
    }
    static get OS_MAP() {
        return E;
    }
    static get PLATFORMS_MAP() {
        return C;
    }
}
function N() {
    return Date.now() + Math.random().toString();
}
function R() {
    throw new Error("Method must be implemented in subclass");
}
function F(e, t) {
    return null != t && t.proxyUrl ? t.proxyUrl + ("/" === t.proxyUrl.slice(-1) ? "" : "/") + e.substring(8) : e;
}
function B(e) {
    return null != e && e.callObjectBundleUrlOverride ? e.callObjectBundleUrlOverride : F("https://c.daily.co/call-machine/versioned/".concat("0.87.0", "/static/call-machine-object-bundle.js"), e);
}
function U(e) {
    try {
        new URL(e);
    } catch (e) {
        return !1;
    }
    return !0;
}
const V = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__, J = "8.55.0", $ = globalThis;
function q(e, t, n) {
    const r = n || $, i = r.__SENTRY__ = r.__SENTRY__ || {}, o = i[J] = i[J] || {};
    return o[e] || (o[e] = t());
}
const z = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__, W = [
    "debug",
    "info",
    "warn",
    "error",
    "log",
    "assert",
    "trace"
], H = {};
function G(e) {
    if (!("console" in $)) return e();
    const t = $.console, n = {}, r = Object.keys(H);
    r.forEach((e)=>{
        const r = H[e];
        n[e] = t[e], t[e] = r;
    });
    try {
        return e();
    } finally{
        r.forEach((e)=>{
            t[e] = n[e];
        });
    }
}
const Q = q("logger", function() {
    let e = !1;
    const t = {
        enable: ()=>{
            e = !0;
        },
        disable: ()=>{
            e = !1;
        },
        isEnabled: ()=>e
    };
    return z ? W.forEach((n)=>{
        t[n] = (...t)=>{
            e && G(()=>{
                $.console[n](`Sentry Logger [${n}]:`, ...t);
            });
        };
    }) : W.forEach((e)=>{
        t[e] = ()=>{};
    }), t;
}), K = "?", Y = /\(error: (.*)\)/, X = /captureMessage|captureException/;
function Z(e) {
    return e[e.length - 1] || {};
}
const ee = "<anonymous>";
function te(e) {
    try {
        return e && "function" == typeof e && e.name || ee;
    } catch (e) {
        return ee;
    }
}
function ne(e) {
    const t = e.exception;
    if (t) {
        const e = [];
        try {
            return t.values.forEach((t)=>{
                t.stacktrace.frames && e.push(...t.stacktrace.frames);
            }), e;
        } catch (e) {
            return;
        }
    }
}
const re = {}, ie = {};
function oe(e, t) {
    re[e] = re[e] || [], re[e].push(t);
}
function se(e, t) {
    if (!ie[e]) {
        ie[e] = !0;
        try {
            t();
        } catch (t) {
            z && Q.error(`Error while instrumenting ${e}`, t);
        }
    }
}
function ae(e, t) {
    const n = e && re[e];
    if (n) for (const r of n)try {
        r(t);
    } catch (t) {
        z && Q.error(`Error while triggering instrumentation handler.\nType: ${e}\nName: ${te(r)}\nError:`, t);
    }
}
let ce = null;
function le() {
    ce = $.onerror, $.onerror = function(e, t, n, r, i) {
        return ae("error", {
            column: r,
            error: i,
            line: n,
            msg: e,
            url: t
        }), !!ce && ce.apply(this, arguments);
    }, $.onerror.__SENTRY_INSTRUMENTED__ = !0;
}
let ue = null;
function de() {
    ue = $.onunhandledrejection, $.onunhandledrejection = function(e) {
        return ae("unhandledrejection", e), !ue || ue.apply(this, arguments);
    }, $.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0;
}
function pe() {
    return he($), $;
}
function he(e) {
    const t = e.__SENTRY__ = e.__SENTRY__ || {};
    return t.version = t.version || J, t[J] = t[J] || {};
}
const fe = Object.prototype.toString;
function ve(e) {
    switch(fe.call(e)){
        case "[object Error]":
        case "[object Exception]":
        case "[object DOMException]":
        case "[object WebAssembly.Exception]":
            return !0;
        default:
            return Ce(e, Error);
    }
}
function ge(e, t) {
    return fe.call(e) === `[object ${t}]`;
}
function me(e) {
    return ge(e, "ErrorEvent");
}
function ye(e) {
    return ge(e, "DOMError");
}
function be(e) {
    return ge(e, "String");
}
function _e(e) {
    return "object" == typeof e && null !== e && "__sentry_template_string__" in e && "__sentry_template_values__" in e;
}
function we(e) {
    return null === e || _e(e) || "object" != typeof e && "function" != typeof e;
}
function Se(e) {
    return ge(e, "Object");
}
function ke(e) {
    return "undefined" != typeof Event && Ce(e, Event);
}
function Me(e) {
    return Boolean(e && e.then && "function" == typeof e.then);
}
function Ce(e, t) {
    try {
        return e instanceof t;
    } catch (e) {
        return !1;
    }
}
function Ee(e) {
    return !("object" != typeof e || null === e || !e.__isVue && !e._isVue);
}
const Te = $;
function Oe(e, t = {}) {
    if (!e) return "<unknown>";
    try {
        let n = e;
        const r = 5, i = [];
        let o = 0, s = 0;
        const a = " > ", c = a.length;
        let l;
        const u = Array.isArray(t) ? t : t.keyAttrs, d = !Array.isArray(t) && t.maxStringLength || 80;
        for(; n && o++ < r && (l = Pe(n, u), !("html" === l || o > 1 && s + i.length * c + l.length >= d));)i.push(l), s += l.length, n = n.parentNode;
        return i.reverse().join(a);
    } catch (e) {
        return "<unknown>";
    }
}
function Pe(e, t) {
    const n = e, r = [];
    if (!n || !n.tagName) return "";
    if (Te.HTMLElement && n instanceof HTMLElement && n.dataset) {
        if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
        if (n.dataset.sentryElement) return n.dataset.sentryElement;
    }
    r.push(n.tagName.toLowerCase());
    const i = t && t.length ? t.filter((e)=>n.getAttribute(e)).map((e)=>[
            e,
            n.getAttribute(e)
        ]) : null;
    if (i && i.length) i.forEach((e)=>{
        r.push(`[${e[0]}="${e[1]}"]`);
    });
    else {
        n.id && r.push(`#${n.id}`);
        const e = n.className;
        if (e && be(e)) {
            const t = e.split(/\s+/);
            for (const e of t)r.push(`.${e}`);
        }
    }
    const o = [
        "aria-label",
        "type",
        "name",
        "title",
        "alt"
    ];
    for (const e of o){
        const t = n.getAttribute(e);
        t && r.push(`[${e}="${t}"]`);
    }
    return r.join("");
}
function Ae(e, t = 0) {
    return "string" != typeof e || 0 === t || e.length <= t ? e : `${e.slice(0, t)}...`;
}
function je(e, t) {
    if (!Array.isArray(e)) return "";
    const n = [];
    for(let t = 0; t < e.length; t++){
        const r = e[t];
        try {
            Ee(r) ? n.push("[VueViewModel]") : n.push(String(r));
        } catch (e) {
            n.push("[value cannot be serialized]");
        }
    }
    return n.join(t);
}
function Ie(e, t, n = !1) {
    return !!be(e) && (ge(t, "RegExp") ? t.test(e) : !!be(t) && (n ? e === t : e.includes(t)));
}
function xe(e, t = [], n = !1) {
    return t.some((t)=>Ie(e, t, n));
}
function Le(e, t, n) {
    if (!(t in e)) return;
    const r = e[t], i = n(r);
    "function" == typeof i && Ne(i, r);
    try {
        e[t] = i;
    } catch (n) {
        z && Q.log(`Failed to replace method "${t}" in object`, e);
    }
}
function De(e, t, n) {
    try {
        Object.defineProperty(e, t, {
            value: n,
            writable: !0,
            configurable: !0
        });
    } catch (n) {
        z && Q.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
}
function Ne(e, t) {
    try {
        const n = t.prototype || {};
        e.prototype = t.prototype = n, De(e, "__sentry_original__", t);
    } catch (e) {}
}
function Re(e) {
    return e.__sentry_original__;
}
function Fe(e) {
    if (ve(e)) return {
        message: e.message,
        name: e.name,
        stack: e.stack,
        ...Ue(e)
    };
    if (ke(e)) {
        const t = {
            type: e.type,
            target: Be(e.target),
            currentTarget: Be(e.currentTarget),
            ...Ue(e)
        };
        return "undefined" != typeof CustomEvent && Ce(e, CustomEvent) && (t.detail = e.detail), t;
    }
    return e;
}
function Be(e) {
    try {
        return t = e, "undefined" != typeof Element && Ce(t, Element) ? Oe(e) : Object.prototype.toString.call(e);
    } catch (e) {
        return "<unknown>";
    }
    var t;
}
function Ue(e) {
    if ("object" == typeof e && null !== e) {
        const t = {};
        for(const n in e)Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    }
    return {};
}
function Ve(e) {
    return Je(e, new Map);
}
function Je(e, t) {
    if (function(e) {
        if (!Se(e)) return !1;
        try {
            const t = Object.getPrototypeOf(e).constructor.name;
            return !t || "Object" === t;
        } catch (e) {
            return !0;
        }
    }(e)) {
        const n = t.get(e);
        if (void 0 !== n) return n;
        const r = {};
        t.set(e, r);
        for (const n of Object.getOwnPropertyNames(e))void 0 !== e[n] && (r[n] = Je(e[n], t));
        return r;
    }
    if (Array.isArray(e)) {
        const n = t.get(e);
        if (void 0 !== n) return n;
        const r = [];
        return t.set(e, r), e.forEach((e)=>{
            r.push(Je(e, t));
        }), r;
    }
    return e;
}
function $e() {
    return Date.now() / 1e3;
}
const qe = function() {
    const { performance: e } = $;
    if (!e || !e.now) return $e;
    const t = Date.now() - e.now(), n = null == e.timeOrigin ? t : e.timeOrigin;
    return ()=>(n + e.now()) / 1e3;
}();
function ze() {
    const e = $, t = e.crypto || e.msCrypto;
    let n = ()=>16 * Math.random();
    try {
        if (t && t.randomUUID) return t.randomUUID().replace(/-/g, "");
        t && t.getRandomValues && (n = ()=>{
            const e = new Uint8Array(1);
            return t.getRandomValues(e), e[0];
        });
    } catch (e) {}
    return ([
        1e7
    ] + 1e3 + 4e3 + 8e3 + 1e11).replace(/[018]/g, (e)=>(e ^ (15 & n()) >> e / 4).toString(16));
}
function We(e) {
    return e.exception && e.exception.values ? e.exception.values[0] : void 0;
}
function He(e) {
    const { message: t, event_id: n } = e;
    if (t) return t;
    const r = We(e);
    return r ? r.type && r.value ? `${r.type}: ${r.value}` : r.type || r.value || n || "<unknown>" : n || "<unknown>";
}
function Ge(e, t, n) {
    const r = e.exception = e.exception || {}, i = r.values = r.values || [], o = i[0] = i[0] || {};
    o.value || (o.value = t || ""), o.type || (o.type = n || "Error");
}
function Qe(e, t) {
    const n = We(e);
    if (!n) return;
    const r = n.mechanism;
    if (n.mechanism = {
        type: "generic",
        handled: !0,
        ...r,
        ...t
    }, t && "data" in t) {
        const e = {
            ...r && r.data,
            ...t.data
        };
        n.mechanism.data = e;
    }
}
function Ke(e) {
    if (function(e) {
        try {
            return e.__sentry_captured__;
        } catch (e) {}
    }(e)) return !0;
    try {
        De(e, "__sentry_captured__", !0);
    } catch (e) {}
    return !1;
}
var Ye;
function Xe(e) {
    return new et((t)=>{
        t(e);
    });
}
function Ze(e) {
    return new et((t, n)=>{
        n(e);
    });
}
(()=>{
    const { performance: e } = $;
    if (!e || !e.now) return;
    const t = 36e5, n = e.now(), r = Date.now(), i = e.timeOrigin ? Math.abs(e.timeOrigin + n - r) : t, o = i < t, s = e.timing && e.timing.navigationStart, a = "number" == typeof s ? Math.abs(s + n - r) : t;
    (o || a < t) && i <= a && e.timeOrigin;
})(), function(e) {
    e[e.PENDING = 0] = "PENDING";
    e[e.RESOLVED = 1] = "RESOLVED";
    e[e.REJECTED = 2] = "REJECTED";
}(Ye || (Ye = {}));
class et {
    constructor(e){
        et.prototype.__init.call(this), et.prototype.__init2.call(this), et.prototype.__init3.call(this), et.prototype.__init4.call(this), this._state = Ye.PENDING, this._handlers = [];
        try {
            e(this._resolve, this._reject);
        } catch (e) {
            this._reject(e);
        }
    }
    then(e, t) {
        return new et((n, r)=>{
            this._handlers.push([
                !1,
                (t)=>{
                    if (e) try {
                        n(e(t));
                    } catch (e) {
                        r(e);
                    }
                    else n(t);
                },
                (e)=>{
                    if (t) try {
                        n(t(e));
                    } catch (e) {
                        r(e);
                    }
                    else r(e);
                }
            ]), this._executeHandlers();
        });
    }
    catch(e) {
        return this.then((e)=>e, e);
    }
    finally(e) {
        return new et((t, n)=>{
            let r, i;
            return this.then((t)=>{
                i = !1, r = t, e && e();
            }, (t)=>{
                i = !0, r = t, e && e();
            }).then(()=>{
                i ? n(r) : t(r);
            });
        });
    }
    __init() {
        this._resolve = (e)=>{
            this._setResult(Ye.RESOLVED, e);
        };
    }
    __init2() {
        this._reject = (e)=>{
            this._setResult(Ye.REJECTED, e);
        };
    }
    __init3() {
        this._setResult = (e, t)=>{
            this._state === Ye.PENDING && (Me(t) ? t.then(this._resolve, this._reject) : (this._state = e, this._value = t, this._executeHandlers()));
        };
    }
    __init4() {
        this._executeHandlers = ()=>{
            if (this._state === Ye.PENDING) return;
            const e = this._handlers.slice();
            this._handlers = [], e.forEach((e)=>{
                e[0] || (this._state === Ye.RESOLVED && e[1](this._value), this._state === Ye.REJECTED && e[2](this._value), e[0] = !0);
            });
        };
    }
}
function tt(e) {
    const t = qe(), n = {
        sid: ze(),
        init: !0,
        timestamp: t,
        started: t,
        duration: 0,
        status: "ok",
        errors: 0,
        ignoreDuration: !1,
        toJSON: ()=>(function(e) {
                return Ve({
                    sid: `${e.sid}`,
                    init: e.init,
                    started: new Date(1e3 * e.started).toISOString(),
                    timestamp: new Date(1e3 * e.timestamp).toISOString(),
                    status: e.status,
                    errors: e.errors,
                    did: "number" == typeof e.did || "string" == typeof e.did ? `${e.did}` : void 0,
                    duration: e.duration,
                    abnormal_mechanism: e.abnormal_mechanism,
                    attrs: {
                        release: e.release,
                        environment: e.environment,
                        ip_address: e.ipAddress,
                        user_agent: e.userAgent
                    }
                });
            })(n)
    };
    return e && nt(n, e), n;
}
function nt(e, t = {}) {
    if (t.user && (!e.ipAddress && t.user.ip_address && (e.ipAddress = t.user.ip_address), e.did || t.did || (e.did = t.user.id || t.user.email || t.user.username)), e.timestamp = t.timestamp || qe(), t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism), t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration), t.sid && (e.sid = 32 === t.sid.length ? t.sid : ze()), void 0 !== t.init && (e.init = t.init), !e.did && t.did && (e.did = `${t.did}`), "number" == typeof t.started && (e.started = t.started), e.ignoreDuration) e.duration = void 0;
    else if ("number" == typeof t.duration) e.duration = t.duration;
    else {
        const t = e.timestamp - e.started;
        e.duration = t >= 0 ? t : 0;
    }
    t.release && (e.release = t.release), t.environment && (e.environment = t.environment), !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress), !e.userAgent && t.userAgent && (e.userAgent = t.userAgent), "number" == typeof t.errors && (e.errors = t.errors), t.status && (e.status = t.status);
}
function rt() {
    return ze();
}
function it() {
    return ze().substring(16);
}
function ot(e, t, n = 2) {
    if (!t || "object" != typeof t || n <= 0) return t;
    if (e && t && 0 === Object.keys(t).length) return e;
    const r = {
        ...e
    };
    for(const e in t)Object.prototype.hasOwnProperty.call(t, e) && (r[e] = ot(r[e], t[e], n - 1));
    return r;
}
const st = "_sentrySpan";
function at(e, t) {
    t ? De(e, st, t) : delete e[st];
}
function ct(e) {
    return e[st];
}
class lt {
    constructor(){
        this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = {
            traceId: rt(),
            spanId: it()
        };
    }
    clone() {
        const e = new lt;
        return e._breadcrumbs = [
            ...this._breadcrumbs
        ], e._tags = {
            ...this._tags
        }, e._extra = {
            ...this._extra
        }, e._contexts = {
            ...this._contexts
        }, this._contexts.flags && (e._contexts.flags = {
            values: [
                ...this._contexts.flags.values
            ]
        }), e._user = this._user, e._level = this._level, e._session = this._session, e._transactionName = this._transactionName, e._fingerprint = this._fingerprint, e._eventProcessors = [
            ...this._eventProcessors
        ], e._requestSession = this._requestSession, e._attachments = [
            ...this._attachments
        ], e._sdkProcessingMetadata = {
            ...this._sdkProcessingMetadata
        }, e._propagationContext = {
            ...this._propagationContext
        }, e._client = this._client, e._lastEventId = this._lastEventId, at(e, ct(this)), e;
    }
    setClient(e) {
        this._client = e;
    }
    setLastEventId(e) {
        this._lastEventId = e;
    }
    getClient() {
        return this._client;
    }
    lastEventId() {
        return this._lastEventId;
    }
    addScopeListener(e) {
        this._scopeListeners.push(e);
    }
    addEventProcessor(e) {
        return this._eventProcessors.push(e), this;
    }
    setUser(e) {
        return this._user = e || {
            email: void 0,
            id: void 0,
            ip_address: void 0,
            username: void 0
        }, this._session && nt(this._session, {
            user: e
        }), this._notifyScopeListeners(), this;
    }
    getUser() {
        return this._user;
    }
    getRequestSession() {
        return this._requestSession;
    }
    setRequestSession(e) {
        return this._requestSession = e, this;
    }
    setTags(e) {
        return this._tags = {
            ...this._tags,
            ...e
        }, this._notifyScopeListeners(), this;
    }
    setTag(e, t) {
        return this._tags = {
            ...this._tags,
            [e]: t
        }, this._notifyScopeListeners(), this;
    }
    setExtras(e) {
        return this._extra = {
            ...this._extra,
            ...e
        }, this._notifyScopeListeners(), this;
    }
    setExtra(e, t) {
        return this._extra = {
            ...this._extra,
            [e]: t
        }, this._notifyScopeListeners(), this;
    }
    setFingerprint(e) {
        return this._fingerprint = e, this._notifyScopeListeners(), this;
    }
    setLevel(e) {
        return this._level = e, this._notifyScopeListeners(), this;
    }
    setTransactionName(e) {
        return this._transactionName = e, this._notifyScopeListeners(), this;
    }
    setContext(e, t) {
        return null === t ? delete this._contexts[e] : this._contexts[e] = t, this._notifyScopeListeners(), this;
    }
    setSession(e) {
        return e ? this._session = e : delete this._session, this._notifyScopeListeners(), this;
    }
    getSession() {
        return this._session;
    }
    update(e) {
        if (!e) return this;
        const t = "function" == typeof e ? e(this) : e, [n, r] = t instanceof ut ? [
            t.getScopeData(),
            t.getRequestSession()
        ] : Se(t) ? [
            e,
            e.requestSession
        ] : [], { tags: i, extra: o, user: s, contexts: a, level: c, fingerprint: l = [], propagationContext: u } = n || {};
        return this._tags = {
            ...this._tags,
            ...i
        }, this._extra = {
            ...this._extra,
            ...o
        }, this._contexts = {
            ...this._contexts,
            ...a
        }, s && Object.keys(s).length && (this._user = s), c && (this._level = c), l.length && (this._fingerprint = l), u && (this._propagationContext = u), r && (this._requestSession = r), this;
    }
    clear() {
        return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._requestSession = void 0, this._session = void 0, at(this, void 0), this._attachments = [], this.setPropagationContext({
            traceId: rt()
        }), this._notifyScopeListeners(), this;
    }
    addBreadcrumb(e, t) {
        const n = "number" == typeof t ? t : 100;
        if (n <= 0) return this;
        const r = {
            timestamp: $e(),
            ...e
        };
        return this._breadcrumbs.push(r), this._breadcrumbs.length > n && (this._breadcrumbs = this._breadcrumbs.slice(-n), this._client && this._client.recordDroppedEvent("buffer_overflow", "log_item")), this._notifyScopeListeners(), this;
    }
    getLastBreadcrumb() {
        return this._breadcrumbs[this._breadcrumbs.length - 1];
    }
    clearBreadcrumbs() {
        return this._breadcrumbs = [], this._notifyScopeListeners(), this;
    }
    addAttachment(e) {
        return this._attachments.push(e), this;
    }
    clearAttachments() {
        return this._attachments = [], this;
    }
    getScopeData() {
        return {
            breadcrumbs: this._breadcrumbs,
            attachments: this._attachments,
            contexts: this._contexts,
            tags: this._tags,
            extra: this._extra,
            user: this._user,
            level: this._level,
            fingerprint: this._fingerprint || [],
            eventProcessors: this._eventProcessors,
            propagationContext: this._propagationContext,
            sdkProcessingMetadata: this._sdkProcessingMetadata,
            transactionName: this._transactionName,
            span: ct(this)
        };
    }
    setSDKProcessingMetadata(e) {
        return this._sdkProcessingMetadata = ot(this._sdkProcessingMetadata, e, 2), this;
    }
    setPropagationContext(e) {
        return this._propagationContext = {
            spanId: it(),
            ...e
        }, this;
    }
    getPropagationContext() {
        return this._propagationContext;
    }
    captureException(e, t) {
        const n = t && t.event_id ? t.event_id : ze();
        if (!this._client) return Q.warn("No client configured on scope - will not capture exception!"), n;
        const r = new Error("Sentry syntheticException");
        return this._client.captureException(e, {
            originalException: e,
            syntheticException: r,
            ...t,
            event_id: n
        }, this), n;
    }
    captureMessage(e, t, n) {
        const r = n && n.event_id ? n.event_id : ze();
        if (!this._client) return Q.warn("No client configured on scope - will not capture message!"), r;
        const i = new Error(e);
        return this._client.captureMessage(e, t, {
            originalException: e,
            syntheticException: i,
            ...n,
            event_id: r
        }, this), r;
    }
    captureEvent(e, t) {
        const n = t && t.event_id ? t.event_id : ze();
        return this._client ? (this._client.captureEvent(e, {
            ...t,
            event_id: n
        }, this), n) : (Q.warn("No client configured on scope - will not capture event!"), n);
    }
    _notifyScopeListeners() {
        this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach((e)=>{
            e(this);
        }), this._notifyingListeners = !1);
    }
}
const ut = lt;
class dt {
    constructor(e, t){
        let n, r;
        n = e || new ut, r = t || new ut, this._stack = [
            {
                scope: n
            }
        ], this._isolationScope = r;
    }
    withScope(e) {
        const t = this._pushScope();
        let n;
        try {
            n = e(t);
        } catch (e) {
            throw this._popScope(), e;
        }
        return Me(n) ? n.then((e)=>(this._popScope(), e), (e)=>{
            throw this._popScope(), e;
        }) : (this._popScope(), n);
    }
    getClient() {
        return this.getStackTop().client;
    }
    getScope() {
        return this.getStackTop().scope;
    }
    getIsolationScope() {
        return this._isolationScope;
    }
    getStackTop() {
        return this._stack[this._stack.length - 1];
    }
    _pushScope() {
        const e = this.getScope().clone();
        return this._stack.push({
            client: this.getClient(),
            scope: e
        }), e;
    }
    _popScope() {
        return !(this._stack.length <= 1) && !!this._stack.pop();
    }
}
function pt() {
    const e = he(pe());
    return e.stack = e.stack || new dt(q("defaultCurrentScope", ()=>new ut), q("defaultIsolationScope", ()=>new ut));
}
function ht(e) {
    return pt().withScope(e);
}
function ft(e, t) {
    const n = pt();
    return n.withScope(()=>(n.getStackTop().scope = e, t(e)));
}
function vt(e) {
    return pt().withScope(()=>e(pt().getIsolationScope()));
}
function gt(e) {
    const t = he(e);
    return t.acs ? t.acs : {
        withIsolationScope: vt,
        withScope: ht,
        withSetScope: ft,
        withSetIsolationScope: (e, t)=>vt(t),
        getCurrentScope: ()=>pt().getScope(),
        getIsolationScope: ()=>pt().getIsolationScope()
    };
}
function mt() {
    return gt(pe()).getCurrentScope();
}
function yt() {
    return gt(pe()).getIsolationScope();
}
function bt() {
    return mt().getClient();
}
function _t(e) {
    const t = e.getPropagationContext(), { traceId: n, spanId: r, parentSpanId: i } = t;
    return Ve({
        trace_id: n,
        span_id: r,
        parent_span_id: i
    });
}
function wt(e) {
    const t = e._sentryMetrics;
    if (!t) return;
    const n = {};
    for (const [, [e, r]] of t){
        (n[e] || (n[e] = [])).push(Ve(r));
    }
    return n;
}
const St = /^sentry-/;
function kt(e) {
    const t = function(e) {
        if (!e || !be(e) && !Array.isArray(e)) return;
        if (Array.isArray(e)) return e.reduce((e, t)=>{
            const n = Mt(t);
            return Object.entries(n).forEach(([t, n])=>{
                e[t] = n;
            }), e;
        }, {});
        return Mt(e);
    }(e);
    if (!t) return;
    const n = Object.entries(t).reduce((e, [t, n])=>{
        if (t.match(St)) {
            e[t.slice(7)] = n;
        }
        return e;
    }, {});
    return Object.keys(n).length > 0 ? n : void 0;
}
function Mt(e) {
    return e.split(",").map((e)=>e.split("=").map((e)=>decodeURIComponent(e.trim()))).reduce((e, [t, n])=>(t && n && (e[t] = n), e), {});
}
let Ct = !1;
function Et(e) {
    const { spanId: t, traceId: n, isRemote: r } = e.spanContext();
    return Ve({
        parent_span_id: r ? t : Pt(e).parent_span_id,
        span_id: r ? it() : t,
        trace_id: n
    });
}
function Tt(e) {
    return "number" == typeof e ? Ot(e) : Array.isArray(e) ? e[0] + e[1] / 1e9 : e instanceof Date ? Ot(e.getTime()) : qe();
}
function Ot(e) {
    return e > 9999999999 ? e / 1e3 : e;
}
function Pt(e) {
    if (function(e) {
        return "function" == typeof e.getSpanJSON;
    }(e)) return e.getSpanJSON();
    try {
        const { spanId: t, traceId: n } = e.spanContext();
        if (function(e) {
            const t = e;
            return !!(t.attributes && t.startTime && t.name && t.endTime && t.status);
        }(e)) {
            const { attributes: r, startTime: i, name: o, endTime: s, parentSpanId: a, status: c } = e;
            return Ve({
                span_id: t,
                trace_id: n,
                data: r,
                description: o,
                parent_span_id: a,
                start_timestamp: Tt(i),
                timestamp: Tt(s) || void 0,
                status: At(c),
                op: r["sentry.op"],
                origin: r["sentry.origin"],
                _metrics_summary: wt(e)
            });
        }
        return {
            span_id: t,
            trace_id: n
        };
    } catch (e) {
        return {};
    }
}
function At(e) {
    if (e && 0 !== e.code) return 1 === e.code ? "ok" : e.message || "unknown_error";
}
function jt(e) {
    return e._sentryRootSpan || e;
}
function It() {
    Ct || (G(()=>{
        console.warn("[Sentry] Deprecation warning: Returning null from `beforeSendSpan` will be disallowed from SDK version 9.0.0 onwards. The callback will only support mutating spans. To drop certain spans, configure the respective integrations directly.");
    }), Ct = !0);
}
const xt = "production";
function Lt(e, t) {
    const n = t.getOptions(), { publicKey: r } = t.getDsn() || {}, i = Ve({
        environment: n.environment || xt,
        release: n.release,
        public_key: r,
        trace_id: e
    });
    return t.emit("createDsc", i), i;
}
function Dt(e) {
    const t = bt();
    if (!t) return {};
    const n = jt(e), r = n._frozenDsc;
    if (r) return r;
    const i = n.spanContext().traceState, o = i && i.get("sentry.dsc"), s = o && kt(o);
    if (s) return s;
    const a = Lt(e.spanContext().traceId, t), c = Pt(n), l = c.data || {}, u = l["sentry.sample_rate"];
    null != u && (a.sample_rate = `${u}`);
    const d = l["sentry.source"], p = c.description;
    return "url" !== d && p && (a.transaction = p), function(e) {
        if ("boolean" == typeof __SENTRY_TRACING__ && !__SENTRY_TRACING__) return !1;
        const t = bt(), n = e || t && t.getOptions();
        return !!n && (n.enableTracing || "tracesSampleRate" in n || "tracesSampler" in n);
    }() && (a.sampled = String(function(e) {
        const { traceFlags: t } = e.spanContext();
        return 1 === t;
    }(n))), t.emit("createDsc", a, n), a;
}
const Nt = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
function Rt(e, t = !1) {
    const { host: n, path: r, pass: i, port: o, projectId: s, protocol: a, publicKey: c } = e;
    return `${a}://${c}${t && i ? `:${i}` : ""}@${n}${o ? `:${o}` : ""}/${r ? `${r}/` : r}${s}`;
}
function Ft(e) {
    return {
        protocol: e.protocol,
        publicKey: e.publicKey || "",
        pass: e.pass || "",
        host: e.host,
        port: e.port || "",
        path: e.path || "",
        projectId: e.projectId
    };
}
function Bt(e) {
    const t = "string" == typeof e ? function(e) {
        const t = Nt.exec(e);
        if (!t) return void G(()=>{
            console.error(`Invalid Sentry Dsn: ${e}`);
        });
        const [n, r, i = "", o = "", s = "", a = ""] = t.slice(1);
        let c = "", l = a;
        const u = l.split("/");
        if (u.length > 1 && (c = u.slice(0, -1).join("/"), l = u.pop()), l) {
            const e = l.match(/^\d+/);
            e && (l = e[0]);
        }
        return Ft({
            host: o,
            pass: i,
            path: c,
            projectId: l,
            port: s,
            protocol: n,
            publicKey: r
        });
    }(e) : Ft(e);
    if (t && function(e) {
        if (!z) return !0;
        const { port: t, projectId: n, protocol: r } = e;
        return !([
            "protocol",
            "publicKey",
            "host",
            "projectId"
        ].find((t)=>!e[t] && (Q.error(`Invalid Sentry Dsn: ${t} missing`), !0)) || (n.match(/^\d+$/) ? function(e) {
            return "http" === e || "https" === e;
        }(r) ? t && isNaN(parseInt(t, 10)) && (Q.error(`Invalid Sentry Dsn: Invalid port ${t}`), 1) : (Q.error(`Invalid Sentry Dsn: Invalid protocol ${r}`), 1) : (Q.error(`Invalid Sentry Dsn: Invalid projectId ${n}`), 1)));
    }(t)) return t;
}
function Ut(e, t = 100, n = 1 / 0) {
    try {
        return Jt("", e, t, n);
    } catch (e) {
        return {
            ERROR: `**non-serializable** (${e})`
        };
    }
}
function Vt(e, t = 3, n = 102400) {
    const r = Ut(e, t);
    return i = r, function(e) {
        return ~-encodeURI(e).split(/%..|./).length;
    }(JSON.stringify(i)) > n ? Vt(e, t - 1, n) : r;
    //TURBOPACK unreachable
    ;
    var i;
}
function Jt(e, t, n = 1 / 0, r = 1 / 0, i = function() {
    const e = "function" == typeof WeakSet, t = e ? new WeakSet : [];
    return [
        function(n) {
            if (e) return !!t.has(n) || (t.add(n), !1);
            for(let e = 0; e < t.length; e++)if (t[e] === n) return !0;
            return t.push(n), !1;
        },
        function(n) {
            if (e) t.delete(n);
            else for(let e = 0; e < t.length; e++)if (t[e] === n) {
                t.splice(e, 1);
                break;
            }
        }
    ];
}()) {
    const [o, s] = i;
    if (null == t || [
        "boolean",
        "string"
    ].includes(typeof t) || "number" == typeof t && Number.isFinite(t)) return t;
    const a = function(e, t) {
        try {
            if ("domain" === e && t && "object" == typeof t && t._events) return "[Domain]";
            if ("domainEmitter" === e) return "[DomainEmitter]";
            if ("undefined" != ("TURBOPACK compile-time value", "object") && t === /*TURBOPACK member replacement*/ __turbopack_context__.g) return "[Global]";
            if ("undefined" != typeof window && t === window) return "[Window]";
            if ("undefined" != typeof document && t === document) return "[Document]";
            if (Ee(t)) return "[VueViewModel]";
            if (Se(n = t) && "nativeEvent" in n && "preventDefault" in n && "stopPropagation" in n) return "[SyntheticEvent]";
            if ("number" == typeof t && !Number.isFinite(t)) return `[${t}]`;
            if ("function" == typeof t) return `[Function: ${te(t)}]`;
            if ("symbol" == typeof t) return `[${String(t)}]`;
            if ("bigint" == typeof t) return `[BigInt: ${String(t)}]`;
            const r = function(e) {
                const t = Object.getPrototypeOf(e);
                return t ? t.constructor.name : "null prototype";
            }(t);
            return /^HTML(\w*)Element$/.test(r) ? `[HTMLElement: ${r}]` : `[object ${r}]`;
        } catch (e) {
            return `**non-serializable** (${e})`;
        }
        var n;
    }(e, t);
    if (!a.startsWith("[object ")) return a;
    if (t.__sentry_skip_normalization__) return t;
    const c = "number" == typeof t.__sentry_override_normalization_depth__ ? t.__sentry_override_normalization_depth__ : n;
    if (0 === c) return a.replace("object ", "");
    if (o(t)) return "[Circular ~]";
    const l = t;
    if (l && "function" == typeof l.toJSON) try {
        return Jt("", l.toJSON(), c - 1, r, i);
    } catch (e) {}
    const u = Array.isArray(t) ? [] : {};
    let d = 0;
    const p = Fe(t);
    for(const e in p){
        if (!Object.prototype.hasOwnProperty.call(p, e)) continue;
        if (d >= r) {
            u[e] = "[MaxProperties ~]";
            break;
        }
        const t = p[e];
        u[e] = Jt(e, t, c - 1, r, i), d++;
    }
    return s(t), u;
}
function $t(e, t = []) {
    return [
        e,
        t
    ];
}
function qt(e, t) {
    const [n, r] = e;
    return [
        n,
        [
            ...r,
            t
        ]
    ];
}
function zt(e, t) {
    const n = e[1];
    for (const e of n){
        if (t(e, e[0].type)) return !0;
    }
    return !1;
}
function Wt(e) {
    return $.__SENTRY__ && $.__SENTRY__.encodePolyfill ? $.__SENTRY__.encodePolyfill(e) : (new TextEncoder).encode(e);
}
function Ht(e) {
    const [t, n] = e;
    let r = JSON.stringify(t);
    function i(e) {
        "string" == typeof r ? r = "string" == typeof e ? r + e : [
            Wt(r),
            e
        ] : r.push("string" == typeof e ? Wt(e) : e);
    }
    for (const e of n){
        const [t, n] = e;
        if (i(`\n${JSON.stringify(t)}\n`), "string" == typeof n || n instanceof Uint8Array) i(n);
        else {
            let e;
            try {
                e = JSON.stringify(n);
            } catch (t) {
                e = JSON.stringify(Ut(n));
            }
            i(e);
        }
    }
    return "string" == typeof r ? r : function(e) {
        const t = e.reduce((e, t)=>e + t.length, 0), n = new Uint8Array(t);
        let r = 0;
        for (const t of e)n.set(t, r), r += t.length;
        return n;
    }(r);
}
function Gt(e) {
    const t = "string" == typeof e.data ? Wt(e.data) : e.data;
    return [
        Ve({
            type: "attachment",
            length: t.length,
            filename: e.filename,
            content_type: e.contentType,
            attachment_type: e.attachmentType
        }),
        t
    ];
}
const Qt = {
    session: "session",
    sessions: "session",
    attachment: "attachment",
    transaction: "transaction",
    event: "error",
    client_report: "internal",
    user_report: "default",
    profile: "profile",
    profile_chunk: "profile",
    replay_event: "replay",
    replay_recording: "replay",
    check_in: "monitor",
    feedback: "feedback",
    span: "span",
    statsd: "metric_bucket",
    raw_security: "security"
};
function Kt(e) {
    return Qt[e];
}
function Yt(e) {
    if (!e || !e.sdk) return;
    const { name: t, version: n } = e.sdk;
    return {
        name: t,
        version: n
    };
}
function Xt(e, t, n, r) {
    const i = Yt(n), o = e.type && "replay_event" !== e.type ? e.type : "event";
    !function(e, t) {
        t && (e.sdk = e.sdk || {}, e.sdk.name = e.sdk.name || t.name, e.sdk.version = e.sdk.version || t.version, e.sdk.integrations = [
            ...e.sdk.integrations || [],
            ...t.integrations || []
        ], e.sdk.packages = [
            ...e.sdk.packages || [],
            ...t.packages || []
        ]);
    }(e, n && n.sdk);
    const s = function(e, t, n, r) {
        const i = e.sdkProcessingMetadata && e.sdkProcessingMetadata.dynamicSamplingContext;
        return {
            event_id: e.event_id,
            sent_at: (new Date).toISOString(),
            ...t && {
                sdk: t
            },
            ...!!n && r && {
                dsn: Rt(r)
            },
            ...i && {
                trace: Ve({
                    ...i
                })
            }
        };
    }(e, i, r, t);
    delete e.sdkProcessingMetadata;
    return $t(s, [
        [
            {
                type: o
            },
            e
        ]
    ]);
}
function Zt(e, t, n, r = 0) {
    return new et((i, o)=>{
        const s = e[r];
        if (null === t || "function" != typeof s) i(t);
        else {
            const a = s({
                ...t
            }, n);
            V && s.id && null === a && Q.log(`Event processor "${s.id}" dropped event`), Me(a) ? a.then((t)=>Zt(e, t, n, r + 1).then(i)).then(null, o) : Zt(e, a, n, r + 1).then(i).then(null, o);
        }
    });
}
let en, tn, nn;
function rn(e, t) {
    const { fingerprint: n, span: r, breadcrumbs: i, sdkProcessingMetadata: o } = t;
    !function(e, t) {
        const { extra: n, tags: r, user: i, contexts: o, level: s, transactionName: a } = t, c = Ve(n);
        c && Object.keys(c).length && (e.extra = {
            ...c,
            ...e.extra
        });
        const l = Ve(r);
        l && Object.keys(l).length && (e.tags = {
            ...l,
            ...e.tags
        });
        const u = Ve(i);
        u && Object.keys(u).length && (e.user = {
            ...u,
            ...e.user
        });
        const d = Ve(o);
        d && Object.keys(d).length && (e.contexts = {
            ...d,
            ...e.contexts
        });
        s && (e.level = s);
        a && "transaction" !== e.type && (e.transaction = a);
    }(e, t), r && function(e, t) {
        e.contexts = {
            trace: Et(t),
            ...e.contexts
        }, e.sdkProcessingMetadata = {
            dynamicSamplingContext: Dt(t),
            ...e.sdkProcessingMetadata
        };
        const n = jt(t), r = Pt(n).description;
        r && !e.transaction && "transaction" === e.type && (e.transaction = r);
    }(e, r), function(e, t) {
        e.fingerprint = e.fingerprint ? Array.isArray(e.fingerprint) ? e.fingerprint : [
            e.fingerprint
        ] : [], t && (e.fingerprint = e.fingerprint.concat(t));
        e.fingerprint && !e.fingerprint.length && delete e.fingerprint;
    }(e, n), function(e, t) {
        const n = [
            ...e.breadcrumbs || [],
            ...t
        ];
        e.breadcrumbs = n.length ? n : void 0;
    }(e, i), function(e, t) {
        e.sdkProcessingMetadata = {
            ...e.sdkProcessingMetadata,
            ...t
        };
    }(e, o);
}
function on(e, t) {
    const { extra: n, tags: r, user: i, contexts: o, level: s, sdkProcessingMetadata: a, breadcrumbs: c, fingerprint: l, eventProcessors: u, attachments: d, propagationContext: p, transactionName: h, span: f } = t;
    sn(e, "extra", n), sn(e, "tags", r), sn(e, "user", i), sn(e, "contexts", o), e.sdkProcessingMetadata = ot(e.sdkProcessingMetadata, a, 2), s && (e.level = s), h && (e.transactionName = h), f && (e.span = f), c.length && (e.breadcrumbs = [
        ...e.breadcrumbs,
        ...c
    ]), l.length && (e.fingerprint = [
        ...e.fingerprint,
        ...l
    ]), u.length && (e.eventProcessors = [
        ...e.eventProcessors,
        ...u
    ]), d.length && (e.attachments = [
        ...e.attachments,
        ...d
    ]), e.propagationContext = {
        ...e.propagationContext,
        ...p
    };
}
function sn(e, t, n) {
    e[t] = ot(e[t], n, 1);
}
function an(e, t, n, r, i, o) {
    const { normalizeDepth: s = 3, normalizeMaxBreadth: a = 1e3 } = e, c = {
        ...t,
        event_id: t.event_id || n.event_id || ze(),
        timestamp: t.timestamp || $e()
    }, l = n.integrations || e.integrations.map((e)=>e.name);
    !function(e, t) {
        const { environment: n, release: r, dist: i, maxValueLength: o = 250 } = t;
        e.environment = e.environment || n || xt, !e.release && r && (e.release = r);
        !e.dist && i && (e.dist = i);
        e.message && (e.message = Ae(e.message, o));
        const s = e.exception && e.exception.values && e.exception.values[0];
        s && s.value && (s.value = Ae(s.value, o));
        const a = e.request;
        a && a.url && (a.url = Ae(a.url, o));
    }(c, e), function(e, t) {
        t.length > 0 && (e.sdk = e.sdk || {}, e.sdk.integrations = [
            ...e.sdk.integrations || [],
            ...t
        ]);
    }(c, l), i && i.emit("applyFrameMetadata", t), void 0 === t.type && function(e, t) {
        const n = function(e) {
            const t = $._sentryDebugIds;
            if (!t) return {};
            const n = Object.keys(t);
            return nn && n.length === tn || (tn = n.length, nn = n.reduce((n, r)=>{
                en || (en = {});
                const i = en[r];
                if (i) n[i[0]] = i[1];
                else {
                    const i = e(r);
                    for(let e = i.length - 1; e >= 0; e--){
                        const o = i[e], s = o && o.filename, a = t[r];
                        if (s && a) {
                            n[s] = a, en[r] = [
                                s,
                                a
                            ];
                            break;
                        }
                    }
                }
                return n;
            }, {})), nn;
        }(t);
        try {
            e.exception.values.forEach((e)=>{
                e.stacktrace.frames.forEach((e)=>{
                    n && e.filename && (e.debug_id = n[e.filename]);
                });
            });
        } catch (e) {}
    }(c, e.stackParser);
    const u = function(e, t) {
        if (!t) return e;
        const n = e ? e.clone() : new ut;
        return n.update(t), n;
    }(r, n.captureContext);
    n.mechanism && Qe(c, n.mechanism);
    const d = i ? i.getEventProcessors() : [], p = q("globalScope", ()=>new ut).getScopeData();
    if (o) {
        on(p, o.getScopeData());
    }
    if (u) {
        on(p, u.getScopeData());
    }
    const h = [
        ...n.attachments || [],
        ...p.attachments
    ];
    h.length && (n.attachments = h), rn(c, p);
    return Zt([
        ...d,
        ...p.eventProcessors
    ], c, n).then((e)=>(e && function(e) {
            const t = {};
            try {
                e.exception.values.forEach((e)=>{
                    e.stacktrace.frames.forEach((e)=>{
                        e.debug_id && (e.abs_path ? t[e.abs_path] = e.debug_id : e.filename && (t[e.filename] = e.debug_id), delete e.debug_id);
                    });
                });
            } catch (e) {}
            if (0 === Object.keys(t).length) return;
            e.debug_meta = e.debug_meta || {}, e.debug_meta.images = e.debug_meta.images || [];
            const n = e.debug_meta.images;
            Object.entries(t).forEach(([e, t])=>{
                n.push({
                    type: "sourcemap",
                    code_file: e,
                    debug_id: t
                });
            });
        }(e), "number" == typeof s && s > 0 ? function(e, t, n) {
            if (!e) return null;
            const r = {
                ...e,
                ...e.breadcrumbs && {
                    breadcrumbs: e.breadcrumbs.map((e)=>({
                            ...e,
                            ...e.data && {
                                data: Ut(e.data, t, n)
                            }
                        }))
                },
                ...e.user && {
                    user: Ut(e.user, t, n)
                },
                ...e.contexts && {
                    contexts: Ut(e.contexts, t, n)
                },
                ...e.extra && {
                    extra: Ut(e.extra, t, n)
                }
            };
            e.contexts && e.contexts.trace && r.contexts && (r.contexts.trace = e.contexts.trace, e.contexts.trace.data && (r.contexts.trace.data = Ut(e.contexts.trace.data, t, n)));
            e.spans && (r.spans = e.spans.map((e)=>({
                    ...e,
                    ...e.data && {
                        data: Ut(e.data, t, n)
                    }
                })));
            e.contexts && e.contexts.flags && r.contexts && (r.contexts.flags = Ut(e.contexts.flags, 3, n));
            return r;
        }(e, s, a) : e));
}
function cn(e) {
    if (e) return function(e) {
        return e instanceof ut || "function" == typeof e;
    }(e) || function(e) {
        return Object.keys(e).some((e)=>ln.includes(e));
    }(e) ? {
        captureContext: e
    } : e;
}
const ln = [
    "user",
    "level",
    "extra",
    "contexts",
    "tags",
    "fingerprint",
    "requestSession",
    "propagationContext"
];
function un(e, t) {
    return mt().captureEvent(e, t);
}
function dn(e) {
    const t = bt(), n = yt(), r = mt(), { release: i, environment: o = xt } = t && t.getOptions() || {}, { userAgent: s } = $.navigator || {}, a = tt({
        release: i,
        environment: o,
        user: r.getUser() || n.getUser(),
        ...s && {
            userAgent: s
        },
        ...e
    }), c = n.getSession();
    return c && "ok" === c.status && nt(c, {
        status: "exited"
    }), pn(), n.setSession(a), r.setSession(a), a;
}
function pn() {
    const e = yt(), t = mt(), n = t.getSession() || e.getSession();
    n && function(e, t) {
        let n = {};
        t ? n = {
            status: t
        } : "ok" === e.status && (n = {
            status: "exited"
        }), nt(e, n);
    }(n), hn(), e.setSession(), t.setSession();
}
function hn() {
    const e = yt(), t = mt(), n = bt(), r = t.getSession() || e.getSession();
    r && n && n.captureSession(r);
}
function fn(e = !1) {
    e ? pn() : hn();
}
function vn(e, t, n) {
    return t || `${function(e) {
        return `${function(e) {
            const t = e.protocol ? `${e.protocol}:` : "", n = e.port ? `:${e.port}` : "";
            return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
        }(e)}${e.projectId}/envelope/`;
    }(e)}?${function(e, t) {
        const n = {
            sentry_version: "7"
        };
        return e.publicKey && (n.sentry_key = e.publicKey), t && (n.sentry_client = `${t.name}/${t.version}`), new URLSearchParams(n).toString();
    }(e, n)}`;
}
const gn = [];
function mn(e, t) {
    for (const n of t)n && n.afterAllSetup && n.afterAllSetup(e);
}
function yn(e, t, n) {
    if (n[t.name]) V && Q.log(`Integration skipped because it was already installed: ${t.name}`);
    else {
        if (n[t.name] = t, -1 === gn.indexOf(t.name) && "function" == typeof t.setupOnce && (t.setupOnce(), gn.push(t.name)), t.setup && "function" == typeof t.setup && t.setup(e), "function" == typeof t.preprocessEvent) {
            const n = t.preprocessEvent.bind(t);
            e.on("preprocessEvent", (t, r)=>n(t, r, e));
        }
        if ("function" == typeof t.processEvent) {
            const n = t.processEvent.bind(t), r = Object.assign((t, r)=>n(t, r, e), {
                id: t.name
            });
            e.addEventProcessor(r);
        }
        V && Q.log(`Integration installed: ${t.name}`);
    }
}
class bn extends Error {
    constructor(e, t = "warn"){
        super(e), this.message = e, this.logLevel = t;
    }
}
const _n = "Not capturing exception because it's already been captured.";
class wn {
    constructor(e){
        if (this._options = e, this._integrations = {}, this._numProcessing = 0, this._outcomes = {}, this._hooks = {}, this._eventProcessors = [], e.dsn ? this._dsn = Bt(e.dsn) : V && Q.warn("No DSN provided, client will not send events."), this._dsn) {
            const t = vn(this._dsn, e.tunnel, e._metadata ? e._metadata.sdk : void 0);
            this._transport = e.transport({
                tunnel: this._options.tunnel,
                recordDroppedEvent: this.recordDroppedEvent.bind(this),
                ...e.transportOptions,
                url: t
            });
        }
        const t = [
            "enableTracing",
            "tracesSampleRate",
            "tracesSampler"
        ].find((t)=>t in e && null == e[t]);
        t && G(()=>{
            console.warn(`[Sentry] Deprecation warning: \`${t}\` is set to undefined, which leads to tracing being enabled. In v9, a value of \`undefined\` will result in tracing being disabled.`);
        });
    }
    captureException(e, t, n) {
        const r = ze();
        if (Ke(e)) return V && Q.log(_n), r;
        const i = {
            event_id: r,
            ...t
        };
        return this._process(this.eventFromException(e, i).then((e)=>this._captureEvent(e, i, n))), i.event_id;
    }
    captureMessage(e, t, n, r) {
        const i = {
            event_id: ze(),
            ...n
        }, o = _e(e) ? e : String(e), s = we(e) ? this.eventFromMessage(o, t, i) : this.eventFromException(e, i);
        return this._process(s.then((e)=>this._captureEvent(e, i, r))), i.event_id;
    }
    captureEvent(e, t, n) {
        const r = ze();
        if (t && t.originalException && Ke(t.originalException)) return V && Q.log(_n), r;
        const i = {
            event_id: r,
            ...t
        }, o = (e.sdkProcessingMetadata || {}).capturedSpanScope;
        return this._process(this._captureEvent(e, i, o || n)), i.event_id;
    }
    captureSession(e) {
        "string" != typeof e.release ? V && Q.warn("Discarded session because of missing or non-string release") : (this.sendSession(e), nt(e, {
            init: !1
        }));
    }
    getDsn() {
        return this._dsn;
    }
    getOptions() {
        return this._options;
    }
    getSdkMetadata() {
        return this._options._metadata;
    }
    getTransport() {
        return this._transport;
    }
    flush(e) {
        const t = this._transport;
        return t ? (this.emit("flush"), this._isClientDoneProcessing(e).then((n)=>t.flush(e).then((e)=>n && e))) : Xe(!0);
    }
    close(e) {
        return this.flush(e).then((e)=>(this.getOptions().enabled = !1, this.emit("close"), e));
    }
    getEventProcessors() {
        return this._eventProcessors;
    }
    addEventProcessor(e) {
        this._eventProcessors.push(e);
    }
    init() {
        (this._isEnabled() || this._options.integrations.some(({ name: e })=>e.startsWith("Spotlight"))) && this._setupIntegrations();
    }
    getIntegrationByName(e) {
        return this._integrations[e];
    }
    addIntegration(e) {
        const t = this._integrations[e.name];
        yn(this, e, this._integrations), t || mn(this, [
            e
        ]);
    }
    sendEvent(e, t = {}) {
        this.emit("beforeSendEvent", e, t);
        let n = Xt(e, this._dsn, this._options._metadata, this._options.tunnel);
        for (const e of t.attachments || [])n = qt(n, Gt(e));
        const r = this.sendEnvelope(n);
        r && r.then((t)=>this.emit("afterSendEvent", e, t), null);
    }
    sendSession(e) {
        const t = function(e, t, n, r) {
            const i = Yt(n);
            return $t({
                sent_at: (new Date).toISOString(),
                ...i && {
                    sdk: i
                },
                ...!!r && t && {
                    dsn: Rt(t)
                }
            }, [
                "aggregates" in e ? [
                    {
                        type: "sessions"
                    },
                    e
                ] : [
                    {
                        type: "session"
                    },
                    e.toJSON()
                ]
            ]);
        }(e, this._dsn, this._options._metadata, this._options.tunnel);
        this.sendEnvelope(t);
    }
    recordDroppedEvent(e, t, n) {
        if (this._options.sendClientReports) {
            const r = "number" == typeof n ? n : 1, i = `${e}:${t}`;
            V && Q.log(`Recording outcome: "${i}"${r > 1 ? ` (${r} times)` : ""}`), this._outcomes[i] = (this._outcomes[i] || 0) + r;
        }
    }
    on(e, t) {
        const n = this._hooks[e] = this._hooks[e] || [];
        return n.push(t), ()=>{
            const e = n.indexOf(t);
            e > -1 && n.splice(e, 1);
        };
    }
    emit(e, ...t) {
        const n = this._hooks[e];
        n && n.forEach((e)=>e(...t));
    }
    sendEnvelope(e) {
        return this.emit("beforeEnvelope", e), this._isEnabled() && this._transport ? this._transport.send(e).then(null, (e)=>(V && Q.error("Error while sending envelope:", e), e)) : (V && Q.error("Transport disabled"), Xe({}));
    }
    _setupIntegrations() {
        const { integrations: e } = this._options;
        this._integrations = function(e, t) {
            const n = {};
            return t.forEach((t)=>{
                t && yn(e, t, n);
            }), n;
        }(this, e), mn(this, e);
    }
    _updateSessionFromEvent(e, t) {
        let n = "fatal" === t.level, r = !1;
        const i = t.exception && t.exception.values;
        if (i) {
            r = !0;
            for (const e of i){
                const t = e.mechanism;
                if (t && !1 === t.handled) {
                    n = !0;
                    break;
                }
            }
        }
        const o = "ok" === e.status;
        (o && 0 === e.errors || o && n) && (nt(e, {
            ...n && {
                status: "crashed"
            },
            errors: e.errors || Number(r || n)
        }), this.captureSession(e));
    }
    _isClientDoneProcessing(e) {
        return new et((t)=>{
            let n = 0;
            const r = setInterval(()=>{
                0 == this._numProcessing ? (clearInterval(r), t(!0)) : (n += 1, e && n >= e && (clearInterval(r), t(!1)));
            }, 1);
        });
    }
    _isEnabled() {
        return !1 !== this.getOptions().enabled && void 0 !== this._transport;
    }
    _prepareEvent(e, t, n = mt(), r = yt()) {
        const i = this.getOptions(), o = Object.keys(this._integrations);
        return !t.integrations && o.length > 0 && (t.integrations = o), this.emit("preprocessEvent", e, t), e.type || r.setLastEventId(e.event_id || t.event_id), an(i, e, t, n, this, r).then((e)=>{
            if (null === e) return e;
            e.contexts = {
                trace: _t(n),
                ...e.contexts
            };
            const t = function(e, t) {
                const n = t.getPropagationContext();
                return n.dsc || Lt(n.traceId, e);
            }(this, n);
            return e.sdkProcessingMetadata = {
                dynamicSamplingContext: t,
                ...e.sdkProcessingMetadata
            }, e;
        });
    }
    _captureEvent(e, t = {}, n) {
        return this._processEvent(e, t, n).then((e)=>e.event_id, (e)=>{
            V && (e instanceof bn && "log" === e.logLevel ? Q.log(e.message) : Q.warn(e));
        });
    }
    _processEvent(e, t, n) {
        const r = this.getOptions(), { sampleRate: i } = r, o = kn(e), s = Sn(e), a = e.type || "error", c = `before send for type \`${a}\``, l = void 0 === i ? void 0 : function(e) {
            if ("boolean" == typeof e) return Number(e);
            const t = "string" == typeof e ? parseFloat(e) : e;
            if (!("number" != typeof t || isNaN(t) || t < 0 || t > 1)) return t;
            V && Q.warn(`[Tracing] Given sample rate is invalid. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(e)} of type ${JSON.stringify(typeof e)}.`);
        }(i);
        if (s && "number" == typeof l && Math.random() > l) return this.recordDroppedEvent("sample_rate", "error", e), Ze(new bn(`Discarding event because it's not included in the random sample (sampling rate = ${i})`, "log"));
        const u = "replay_event" === a ? "replay" : a, d = (e.sdkProcessingMetadata || {}).capturedSpanIsolationScope;
        return this._prepareEvent(e, t, n, d).then((n)=>{
            if (null === n) throw this.recordDroppedEvent("event_processor", u, e), new bn("An event processor returned `null`, will not send event.", "log");
            if (t.data && !0 === t.data.__sentry__) return n;
            const i = function(e, t, n, r) {
                const { beforeSend: i, beforeSendTransaction: o, beforeSendSpan: s } = t;
                if (Sn(n) && i) return i(n, r);
                if (kn(n)) {
                    if (n.spans && s) {
                        const t = [];
                        for (const r of n.spans){
                            const n = s(r);
                            n ? t.push(n) : (It(), e.recordDroppedEvent("before_send", "span"));
                        }
                        n.spans = t;
                    }
                    if (o) {
                        if (n.spans) {
                            const e = n.spans.length;
                            n.sdkProcessingMetadata = {
                                ...n.sdkProcessingMetadata,
                                spanCountBeforeProcessing: e
                            };
                        }
                        return o(n, r);
                    }
                }
                return n;
            }(this, r, n, t);
            return function(e, t) {
                const n = `${t} must return \`null\` or a valid event.`;
                if (Me(e)) return e.then((e)=>{
                    if (!Se(e) && null !== e) throw new bn(n);
                    return e;
                }, (e)=>{
                    throw new bn(`${t} rejected with ${e}`);
                });
                if (!Se(e) && null !== e) throw new bn(n);
                return e;
            }(i, c);
        }).then((r)=>{
            if (null === r) {
                if (this.recordDroppedEvent("before_send", u, e), o) {
                    const t = 1 + (e.spans || []).length;
                    this.recordDroppedEvent("before_send", "span", t);
                }
                throw new bn(`${c} returned \`null\`, will not send event.`, "log");
            }
            const i = n && n.getSession();
            if (!o && i && this._updateSessionFromEvent(i, r), o) {
                const e = (r.sdkProcessingMetadata && r.sdkProcessingMetadata.spanCountBeforeProcessing || 0) - (r.spans ? r.spans.length : 0);
                e > 0 && this.recordDroppedEvent("before_send", "span", e);
            }
            const s = r.transaction_info;
            if (o && s && r.transaction !== e.transaction) {
                const e = "custom";
                r.transaction_info = {
                    ...s,
                    source: e
                };
            }
            return this.sendEvent(r, t), r;
        }).then(null, (e)=>{
            if (e instanceof bn) throw e;
            throw this.captureException(e, {
                data: {
                    __sentry__: !0
                },
                originalException: e
            }), new bn(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: ${e}`);
        });
    }
    _process(e) {
        this._numProcessing++, e.then((e)=>(this._numProcessing--, e), (e)=>(this._numProcessing--, e));
    }
    _clearOutcomes() {
        const e = this._outcomes;
        return this._outcomes = {}, Object.entries(e).map(([e, t])=>{
            const [n, r] = e.split(":");
            return {
                reason: n,
                category: r,
                quantity: t
            };
        });
    }
    _flushOutcomes() {
        V && Q.log("Flushing outcomes...");
        const e = this._clearOutcomes();
        if (0 === e.length) return void (V && Q.log("No outcomes to send"));
        if (!this._dsn) return void (V && Q.log("No dsn provided, will not send outcomes"));
        V && Q.log("Sending outcomes:", e);
        const t = (n = e, $t((r = this._options.tunnel && Rt(this._dsn)) ? {
            dsn: r
        } : {}, [
            [
                {
                    type: "client_report"
                },
                {
                    timestamp: i || $e(),
                    discarded_events: n
                }
            ]
        ]));
        var n, r, i;
        this.sendEnvelope(t);
    }
}
function Sn(e) {
    return void 0 === e.type;
}
function kn(e) {
    return "transaction" === e.type;
}
function Mn(e) {
    const t = [];
    function n(e) {
        return t.splice(t.indexOf(e), 1)[0] || Promise.resolve(void 0);
    }
    return {
        $: t,
        add: function(r) {
            if (!(void 0 === e || t.length < e)) return Ze(new bn("Not adding Promise because buffer limit was reached."));
            const i = r();
            return -1 === t.indexOf(i) && t.push(i), i.then(()=>n(i)).then(null, ()=>n(i).then(null, ()=>{})), i;
        },
        drain: function(e) {
            return new et((n, r)=>{
                let i = t.length;
                if (!i) return n(!0);
                const o = setTimeout(()=>{
                    e && e > 0 && n(!1);
                }, e);
                t.forEach((e)=>{
                    Xe(e).then(()=>{
                        --i || (clearTimeout(o), n(!0));
                    }, r);
                });
            });
        }
    };
}
function Cn(e, { statusCode: t, headers: n }, r = Date.now()) {
    const i = {
        ...e
    }, o = n && n["x-sentry-rate-limits"], s = n && n["retry-after"];
    if (o) for (const e of o.trim().split(",")){
        const [t, n, , , o] = e.split(":", 5), s = parseInt(t, 10), a = 1e3 * (isNaN(s) ? 60 : s);
        if (n) for (const e of n.split(";"))"metric_bucket" === e && o && !o.split(";").includes("custom") || (i[e] = r + a);
        else i.all = r + a;
    }
    else s ? i.all = r + function(e, t = Date.now()) {
        const n = parseInt(`${e}`, 10);
        if (!isNaN(n)) return 1e3 * n;
        const r = Date.parse(`${e}`);
        return isNaN(r) ? 6e4 : r - t;
    }(s, r) : 429 === t && (i.all = r + 6e4);
    return i;
}
function En(e, t, n = Mn(e.bufferSize || 64)) {
    let r = {};
    return {
        send: function(i) {
            const o = [];
            if (zt(i, (t, n)=>{
                const i = Kt(n);
                if (function(e, t, n = Date.now()) {
                    return function(e, t) {
                        return e[t] || e.all || 0;
                    }(e, t) > n;
                }(r, i)) {
                    const r = Tn(t, n);
                    e.recordDroppedEvent("ratelimit_backoff", i, r);
                } else o.push(t);
            }), 0 === o.length) return Xe({});
            const s = $t(i[0], o), a = (t)=>{
                zt(s, (n, r)=>{
                    const i = Tn(n, r);
                    e.recordDroppedEvent(t, Kt(r), i);
                });
            };
            return n.add(()=>t({
                    body: Ht(s)
                }).then((e)=>(void 0 !== e.statusCode && (e.statusCode < 200 || e.statusCode >= 300) && V && Q.warn(`Sentry responded with status code ${e.statusCode} to sent event.`), r = Cn(r, e), e), (e)=>{
                    throw a("network_error"), e;
                })).then((e)=>e, (e)=>{
                if (e instanceof bn) return V && Q.error("Skipped sending event because buffer is full."), a("queue_overflow"), Xe({});
                throw e;
            });
        },
        flush: (e)=>n.drain(e)
    };
}
function Tn(e, t) {
    if ("event" === t || "transaction" === t) return Array.isArray(e) ? e[1] : void 0;
}
const On = 100;
function Pn(e, t) {
    const n = bt(), r = yt();
    if (!n) return;
    const { beforeBreadcrumb: i = null, maxBreadcrumbs: o = On } = n.getOptions();
    if (o <= 0) return;
    const s = {
        timestamp: $e(),
        ...e
    }, a = i ? G(()=>i(s, t)) : s;
    null !== a && (n.emit && n.emit("beforeAddBreadcrumb", a, t), r.addBreadcrumb(a, o));
}
let An;
const jn = new WeakMap, In = ()=>({
        name: "FunctionToString",
        setupOnce () {
            An = Function.prototype.toString;
            try {
                Function.prototype.toString = function(...e) {
                    const t = Re(this), n = jn.has(bt()) && void 0 !== t ? t : this;
                    return An.apply(n, e);
                };
            } catch (e) {}
        },
        setup (e) {
            jn.set(e, !0);
        }
    }), xn = [
    /^Script error\.?$/,
    /^Javascript error: Script error\.? on line 0$/,
    /^ResizeObserver loop completed with undelivered notifications.$/,
    /^Cannot redefine property: googletag$/,
    "undefined is not an object (evaluating 'a.L')",
    'can\'t redefine non-configurable property "solana"',
    "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
    "Can't find variable: _AutofillCallbackHandler",
    /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/
], Ln = (e = {})=>({
        name: "InboundFilters",
        processEvent (t, n, r) {
            const i = r.getOptions(), o = function(e = {}, t = {}) {
                return {
                    allowUrls: [
                        ...e.allowUrls || [],
                        ...t.allowUrls || []
                    ],
                    denyUrls: [
                        ...e.denyUrls || [],
                        ...t.denyUrls || []
                    ],
                    ignoreErrors: [
                        ...e.ignoreErrors || [],
                        ...t.ignoreErrors || [],
                        ...e.disableErrorDefaults ? [] : xn
                    ],
                    ignoreTransactions: [
                        ...e.ignoreTransactions || [],
                        ...t.ignoreTransactions || []
                    ],
                    ignoreInternal: void 0 === e.ignoreInternal || e.ignoreInternal
                };
            }(e, i);
            return function(e, t) {
                if (t.ignoreInternal && function(e) {
                    try {
                        return "SentryError" === e.exception.values[0].type;
                    } catch (e) {}
                    return !1;
                }(e)) return V && Q.warn(`Event dropped due to being internal Sentry Error.\nEvent: ${He(e)}`), !0;
                if (function(e, t) {
                    if (e.type || !t || !t.length) return !1;
                    return (function(e) {
                        const t = [];
                        e.message && t.push(e.message);
                        let n;
                        try {
                            n = e.exception.values[e.exception.values.length - 1];
                        } catch (e) {}
                        n && n.value && (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`));
                        return t;
                    })(e).some((e)=>xe(e, t));
                }(e, t.ignoreErrors)) return V && Q.warn(`Event dropped due to being matched by \`ignoreErrors\` option.\nEvent: ${He(e)}`), !0;
                if (function(e) {
                    if (e.type) return !1;
                    if (!e.exception || !e.exception.values || 0 === e.exception.values.length) return !1;
                    return !e.message && !e.exception.values.some((e)=>e.stacktrace || e.type && "Error" !== e.type || e.value);
                }(e)) return V && Q.warn(`Event dropped due to not having an error message, error type or stacktrace.\nEvent: ${He(e)}`), !0;
                if (function(e, t) {
                    if ("transaction" !== e.type || !t || !t.length) return !1;
                    const n = e.transaction;
                    return !!n && xe(n, t);
                }(e, t.ignoreTransactions)) return V && Q.warn(`Event dropped due to being matched by \`ignoreTransactions\` option.\nEvent: ${He(e)}`), !0;
                if (function(e, t) {
                    if (!t || !t.length) return !1;
                    const n = Dn(e);
                    return !!n && xe(n, t);
                }(e, t.denyUrls)) return V && Q.warn(`Event dropped due to being matched by \`denyUrls\` option.\nEvent: ${He(e)}.\nUrl: ${Dn(e)}`), !0;
                if (!function(e, t) {
                    if (!t || !t.length) return !0;
                    const n = Dn(e);
                    return !n || xe(n, t);
                }(e, t.allowUrls)) return V && Q.warn(`Event dropped due to not being matched by \`allowUrls\` option.\nEvent: ${He(e)}.\nUrl: ${Dn(e)}`), !0;
                return !1;
            }(t, o) ? null : t;
        }
    });
function Dn(e) {
    try {
        let t;
        try {
            t = e.exception.values[0].stacktrace.frames;
        } catch (e) {}
        return t ? function(e = []) {
            for(let t = e.length - 1; t >= 0; t--){
                const n = e[t];
                if (n && "<anonymous>" !== n.filename && "[native code]" !== n.filename) return n.filename || null;
            }
            return null;
        }(t) : null;
    } catch (t) {
        return V && Q.error(`Cannot extract url for event ${He(e)}`), null;
    }
}
function Nn(e, t, n = 250, r, i, o, s) {
    if (!(o.exception && o.exception.values && s && Ce(s.originalException, Error))) return;
    const a = o.exception.values.length > 0 ? o.exception.values[o.exception.values.length - 1] : void 0;
    var c, l;
    a && (o.exception.values = (c = Rn(e, t, i, s.originalException, r, o.exception.values, a, 0), l = n, c.map((e)=>(e.value && (e.value = Ae(e.value, l)), e))));
}
function Rn(e, t, n, r, i, o, s, a) {
    if (o.length >= n + 1) return o;
    let c = [
        ...o
    ];
    if (Ce(r[i], Error)) {
        Fn(s, a);
        const o = e(t, r[i]), l = c.length;
        Bn(o, i, l, a), c = Rn(e, t, n, r[i], i, [
            o,
            ...c
        ], o, l);
    }
    return Array.isArray(r.errors) && r.errors.forEach((r, o)=>{
        if (Ce(r, Error)) {
            Fn(s, a);
            const l = e(t, r), u = c.length;
            Bn(l, `errors[${o}]`, u, a), c = Rn(e, t, n, r, i, [
                l,
                ...c
            ], l, u);
        }
    }), c;
}
function Fn(e, t) {
    e.mechanism = e.mechanism || {
        type: "generic",
        handled: !0
    }, e.mechanism = {
        ...e.mechanism,
        ..."AggregateError" === e.type && {
            is_exception_group: !0
        },
        exception_id: t
    };
}
function Bn(e, t, n, r) {
    e.mechanism = e.mechanism || {
        type: "generic",
        handled: !0
    }, e.mechanism = {
        ...e.mechanism,
        type: "chained",
        source: t,
        exception_id: n,
        parent_id: r
    };
}
function Un(e) {
    if (!e) return {};
    const t = e.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
    if (!t) return {};
    const n = t[6] || "", r = t[8] || "";
    return {
        host: t[4],
        path: t[5],
        protocol: t[2],
        search: n,
        hash: r,
        relative: t[5] + n + r
    };
}
function Vn() {
    "console" in $ && W.forEach(function(e) {
        e in $.console && Le($.console, e, function(t) {
            return H[e] = t, function(...t) {
                ae("console", {
                    args: t,
                    level: e
                });
                const n = H[e];
                n && n.apply($.console, t);
            };
        });
    });
}
function Jn(e) {
    return "warn" === e ? "warning" : [
        "fatal",
        "error",
        "warning",
        "log",
        "info",
        "debug"
    ].includes(e) ? e : "log";
}
const $n = ()=>{
    let e;
    return {
        name: "Dedupe",
        processEvent (t) {
            if (t.type) return t;
            try {
                if (function(e, t) {
                    if (!t) return !1;
                    if (function(e, t) {
                        const n = e.message, r = t.message;
                        if (!n && !r) return !1;
                        if (n && !r || !n && r) return !1;
                        if (n !== r) return !1;
                        if (!zn(e, t)) return !1;
                        if (!qn(e, t)) return !1;
                        return !0;
                    }(e, t)) return !0;
                    if (function(e, t) {
                        const n = Wn(t), r = Wn(e);
                        if (!n || !r) return !1;
                        if (n.type !== r.type || n.value !== r.value) return !1;
                        if (!zn(e, t)) return !1;
                        if (!qn(e, t)) return !1;
                        return !0;
                    }(e, t)) return !0;
                    return !1;
                }(t, e)) return V && Q.warn("Event dropped due to being a duplicate of previously captured event."), null;
            } catch (e) {}
            return e = t;
        }
    };
};
function qn(e, t) {
    let n = ne(e), r = ne(t);
    if (!n && !r) return !0;
    if (n && !r || !n && r) return !1;
    if (r.length !== n.length) return !1;
    for(let e = 0; e < r.length; e++){
        const t = r[e], i = n[e];
        if (t.filename !== i.filename || t.lineno !== i.lineno || t.colno !== i.colno || t.function !== i.function) return !1;
    }
    return !0;
}
function zn(e, t) {
    let n = e.fingerprint, r = t.fingerprint;
    if (!n && !r) return !0;
    if (n && !r || !n && r) return !1;
    try {
        return !(n.join("") !== r.join(""));
    } catch (e) {
        return !1;
    }
}
function Wn(e) {
    return e.exception && e.exception.values && e.exception.values[0];
}
function Hn(e) {
    return void 0 === e ? void 0 : e >= 400 && e < 500 ? "warning" : e >= 500 ? "error" : void 0;
}
const Gn = $;
function Qn(e) {
    return e && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString());
}
function Kn() {
    if ("string" == typeof EdgeRuntime) return !0;
    if (!function() {
        if (!("fetch" in Gn)) return !1;
        try {
            return new Headers, new Request("http://www.example.com"), new Response, !0;
        } catch (e) {
            return !1;
        }
    }()) return !1;
    if (Qn(Gn.fetch)) return !0;
    let e = !1;
    const t = Gn.document;
    if (t && "function" == typeof t.createElement) try {
        const n = t.createElement("iframe");
        n.hidden = !0, t.head.appendChild(n), n.contentWindow && n.contentWindow.fetch && (e = Qn(n.contentWindow.fetch)), t.head.removeChild(n);
    } catch (e) {
        z && Q.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", e);
    }
    return e;
}
function Yn(e, t) {
    const n = "fetch";
    oe(n, e), se(n, ()=>(function(e, t = !1) {
            if (t && !Kn()) return;
            Le($, "fetch", function(t) {
                return function(...n) {
                    const r = new Error, { method: i, url: o } = function(e) {
                        if (0 === e.length) return {
                            method: "GET",
                            url: ""
                        };
                        if (2 === e.length) {
                            const [t, n] = e;
                            return {
                                url: Zn(t),
                                method: Xn(n, "method") ? String(n.method).toUpperCase() : "GET"
                            };
                        }
                        const t = e[0];
                        return {
                            url: Zn(t),
                            method: Xn(t, "method") ? String(t.method).toUpperCase() : "GET"
                        };
                    }(n), s = {
                        args: n,
                        fetchData: {
                            method: i,
                            url: o
                        },
                        startTimestamp: 1e3 * qe(),
                        virtualError: r
                    };
                    return e || ae("fetch", {
                        ...s
                    }), t.apply($, n).then(async (t)=>(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : ae("fetch", {
                            ...s,
                            endTimestamp: 1e3 * qe(),
                            response: t
                        }), t), (e)=>{
                        throw ae("fetch", {
                            ...s,
                            endTimestamp: 1e3 * qe(),
                            error: e
                        }), ve(e) && void 0 === e.stack && (e.stack = r.stack, De(e, "framesToPop", 1)), e;
                    });
                };
            });
        })(void 0, t));
}
function Xn(e, t) {
    return !!e && "object" == typeof e && !!e[t];
}
function Zn(e) {
    return "string" == typeof e ? e : e ? Xn(e, "url") ? e.url : e.toString ? e.toString() : "" : "";
}
const er = $;
const tr = $;
let nr = 0;
function rr() {
    return nr > 0;
}
function ir(e, t = {}) {
    if (!function(e) {
        return "function" == typeof e;
    }(e)) return e;
    try {
        const t = e.__sentry_wrapped__;
        if (t) return "function" == typeof t ? t : e;
        if (Re(e)) return e;
    } catch (t) {
        return e;
    }
    const n = function(...n) {
        try {
            const r = n.map((e)=>ir(e, t));
            return e.apply(this, r);
        } catch (e) {
            throw nr++, setTimeout(()=>{
                nr--;
            }), function(...e) {
                const t = gt(pe());
                if (2 === e.length) {
                    const [n, r] = e;
                    return n ? t.withSetScope(n, r) : t.withScope(r);
                }
                t.withScope(e[0]);
            }((r)=>{
                var i, o;
                r.addEventProcessor((e)=>(t.mechanism && (Ge(e, void 0, void 0), Qe(e, t.mechanism)), e.extra = {
                        ...e.extra,
                        arguments: n
                    }, e)), i = e, mt().captureException(i, cn(o));
            }), e;
        }
    };
    try {
        for(const t in e)Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    } catch (e) {}
    Ne(n, e), De(e, "__sentry_wrapped__", n);
    try {
        Object.getOwnPropertyDescriptor(n, "name").configurable && Object.defineProperty(n, "name", {
            get: ()=>e.name
        });
    } catch (e) {}
    return n;
}
const or = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__;
function sr(e, t) {
    const n = lr(e, t), r = {
        type: pr(t),
        value: hr(t)
    };
    return n.length && (r.stacktrace = {
        frames: n
    }), void 0 === r.type && "" === r.value && (r.value = "Unrecoverable error caught"), r;
}
function ar(e, t, n, r) {
    const i = bt(), o = i && i.getOptions().normalizeDepth, s = function(e) {
        for(const t in e)if (Object.prototype.hasOwnProperty.call(e, t)) {
            const n = e[t];
            if (n instanceof Error) return n;
        }
        return;
    }(t), a = {
        __serialized__: Vt(t, o)
    };
    if (s) return {
        exception: {
            values: [
                sr(e, s)
            ]
        },
        extra: a
    };
    const c = {
        exception: {
            values: [
                {
                    type: ke(t) ? t.constructor.name : r ? "UnhandledRejection" : "Error",
                    value: gr(t, {
                        isUnhandledRejection: r
                    })
                }
            ]
        },
        extra: a
    };
    if (n) {
        const t = lr(e, n);
        t.length && (c.exception.values[0].stacktrace = {
            frames: t
        });
    }
    return c;
}
function cr(e, t) {
    return {
        exception: {
            values: [
                sr(e, t)
            ]
        }
    };
}
function lr(e, t) {
    const n = t.stacktrace || t.stack || "", r = function(e) {
        if (e && ur.test(e.message)) return 1;
        return 0;
    }(t), i = function(e) {
        if ("number" == typeof e.framesToPop) return e.framesToPop;
        return 0;
    }(t);
    try {
        return e(n, r, i);
    } catch (e) {}
    return [];
}
const ur = /Minified React error #\d+;/i;
function dr(e) {
    return "undefined" != typeof WebAssembly && void 0 !== WebAssembly.Exception && e instanceof WebAssembly.Exception;
}
function pr(e) {
    const t = e && e.name;
    if (!t && dr(e)) {
        return e.message && Array.isArray(e.message) && 2 == e.message.length ? e.message[0] : "WebAssembly.Exception";
    }
    return t;
}
function hr(e) {
    const t = e && e.message;
    return t ? t.error && "string" == typeof t.error.message ? t.error.message : dr(e) && Array.isArray(e.message) && 2 == e.message.length ? e.message[1] : t : "No error message";
}
function fr(e, t, n, r, i) {
    let o;
    if (me(t) && t.error) {
        return cr(e, t.error);
    }
    if (ye(t) || ge(t, "DOMException")) {
        const i = t;
        if ("stack" in t) o = cr(e, t);
        else {
            const t = i.name || (ye(i) ? "DOMError" : "DOMException"), s = i.message ? `${t}: ${i.message}` : t;
            o = vr(e, s, n, r), Ge(o, s);
        }
        return "code" in i && (o.tags = {
            ...o.tags,
            "DOMException.code": `${i.code}`
        }), o;
    }
    if (ve(t)) return cr(e, t);
    if (Se(t) || ke(t)) {
        return o = ar(e, t, n, i), Qe(o, {
            synthetic: !0
        }), o;
    }
    return o = vr(e, t, n, r), Ge(o, `${t}`, void 0), Qe(o, {
        synthetic: !0
    }), o;
}
function vr(e, t, n, r) {
    const i = {};
    if (r && n) {
        const r = lr(e, n);
        r.length && (i.exception = {
            values: [
                {
                    value: t,
                    stacktrace: {
                        frames: r
                    }
                }
            ]
        }), Qe(i, {
            synthetic: !0
        });
    }
    if (_e(t)) {
        const { __sentry_template_string__: e, __sentry_template_values__: n } = t;
        return i.logentry = {
            message: e,
            params: n
        }, i;
    }
    return i.message = t, i;
}
function gr(e, { isUnhandledRejection: t }) {
    const n = function(e, t = 40) {
        const n = Object.keys(Fe(e));
        n.sort();
        const r = n[0];
        if (!r) return "[object has no keys]";
        if (r.length >= t) return Ae(r, t);
        for(let e = n.length; e > 0; e--){
            const r = n.slice(0, e).join(", ");
            if (!(r.length > t)) return e === n.length ? r : Ae(r, t);
        }
        return "";
    }(e), r = t ? "promise rejection" : "exception";
    if (me(e)) return `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\``;
    if (ke(e)) {
        return `Event \`${function(e) {
            try {
                const t = Object.getPrototypeOf(e);
                return t ? t.constructor.name : void 0;
            } catch (e) {}
        }(e)}\` (type=${e.type}) captured as ${r}`;
    }
    return `Object captured as ${r} with keys: ${n}`;
}
class mr extends wn {
    constructor(e){
        const t = {
            parentSpanIsAlwaysRootSpan: !0,
            ...e
        };
        !function(e, t, n = [
            t
        ], r = "npm") {
            const i = e._metadata || {};
            i.sdk || (i.sdk = {
                name: `sentry.javascript.${t}`,
                packages: n.map((e)=>({
                        name: `${r}:@sentry/${e}`,
                        version: J
                    })),
                version: J
            }), e._metadata = i;
        }(t, "browser", [
            "browser"
        ], tr.SENTRY_SDK_SOURCE || "npm"), super(t), t.sendClientReports && tr.document && tr.document.addEventListener("visibilitychange", ()=>{
            "hidden" === tr.document.visibilityState && this._flushOutcomes();
        });
    }
    eventFromException(e, t) {
        return function(e, t, n, r) {
            const i = fr(e, t, n && n.syntheticException || void 0, r);
            return Qe(i), i.level = "error", n && n.event_id && (i.event_id = n.event_id), Xe(i);
        }(this._options.stackParser, e, t, this._options.attachStacktrace);
    }
    eventFromMessage(e, t = "info", n) {
        return function(e, t, n = "info", r, i) {
            const o = vr(e, t, r && r.syntheticException || void 0, i);
            return o.level = n, r && r.event_id && (o.event_id = r.event_id), Xe(o);
        }(this._options.stackParser, e, t, n, this._options.attachStacktrace);
    }
    captureUserFeedback(e) {
        if (!this._isEnabled()) return void (or && Q.warn("SDK not enabled, will not capture user feedback."));
        const t = function(e, { metadata: t, tunnel: n, dsn: r }) {
            const i = {
                event_id: e.event_id,
                sent_at: (new Date).toISOString(),
                ...t && t.sdk && {
                    sdk: {
                        name: t.sdk.name,
                        version: t.sdk.version
                    }
                },
                ...!!n && !!r && {
                    dsn: Rt(r)
                }
            }, o = function(e) {
                return [
                    {
                        type: "user_report"
                    },
                    e
                ];
            }(e);
            return $t(i, [
                o
            ]);
        }(e, {
            metadata: this.getSdkMetadata(),
            dsn: this.getDsn(),
            tunnel: this.getOptions().tunnel
        });
        this.sendEnvelope(t);
    }
    _prepareEvent(e, t, n) {
        return e.platform = e.platform || "javascript", super._prepareEvent(e, t, n);
    }
}
const yr = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__, br = $;
let _r, wr, Sr, kr;
function Mr() {
    if (!br.document) return;
    const e = ae.bind(null, "dom"), t = Cr(e, !0);
    br.document.addEventListener("click", t, !1), br.document.addEventListener("keypress", t, !1), [
        "EventTarget",
        "Node"
    ].forEach((t)=>{
        const n = br[t], r = n && n.prototype;
        r && r.hasOwnProperty && r.hasOwnProperty("addEventListener") && (Le(r, "addEventListener", function(t) {
            return function(n, r, i) {
                if ("click" === n || "keypress" == n) try {
                    const r = this.__sentry_instrumentation_handlers__ = this.__sentry_instrumentation_handlers__ || {}, o = r[n] = r[n] || {
                        refCount: 0
                    };
                    if (!o.handler) {
                        const r = Cr(e);
                        o.handler = r, t.call(this, n, r, i);
                    }
                    o.refCount++;
                } catch (e) {}
                return t.call(this, n, r, i);
            };
        }), Le(r, "removeEventListener", function(e) {
            return function(t, n, r) {
                if ("click" === t || "keypress" == t) try {
                    const n = this.__sentry_instrumentation_handlers__ || {}, i = n[t];
                    i && (i.refCount--, i.refCount <= 0 && (e.call(this, t, i.handler, r), i.handler = void 0, delete n[t]), 0 === Object.keys(n).length && delete this.__sentry_instrumentation_handlers__);
                } catch (e) {}
                return e.call(this, t, n, r);
            };
        }));
    });
}
function Cr(e, t = !1) {
    return (n)=>{
        if (!n || n._sentryCaptured) return;
        const r = function(e) {
            try {
                return e.target;
            } catch (e) {
                return null;
            }
        }(n);
        if (function(e, t) {
            return "keypress" === e && (!t || !t.tagName || "INPUT" !== t.tagName && "TEXTAREA" !== t.tagName && !t.isContentEditable);
        }(n.type, r)) return;
        De(n, "_sentryCaptured", !0), r && !r._sentryId && De(r, "_sentryId", ze());
        const i = "keypress" === n.type ? "input" : n.type;
        if (!function(e) {
            if (e.type !== wr) return !1;
            try {
                if (!e.target || e.target._sentryId !== Sr) return !1;
            } catch (e) {}
            return !0;
        }(n)) {
            e({
                event: n,
                name: i,
                global: t
            }), wr = n.type, Sr = r ? r._sentryId : void 0;
        }
        clearTimeout(_r), _r = br.setTimeout(()=>{
            Sr = void 0, wr = void 0;
        }, 1e3);
    };
}
function Er(e) {
    const t = "history";
    oe(t, e), se(t, Tr);
}
function Tr() {
    if (!function() {
        const e = er.chrome, t = e && e.app && e.app.runtime, n = "history" in er && !!er.history.pushState && !!er.history.replaceState;
        return !t && n;
    }()) return;
    const e = br.onpopstate;
    function t(e) {
        return function(...t) {
            const n = t.length > 2 ? t[2] : void 0;
            if (n) {
                const e = kr, t = String(n);
                kr = t;
                ae("history", {
                    from: e,
                    to: t
                });
            }
            return e.apply(this, t);
        };
    }
    br.onpopstate = function(...t) {
        const n = br.location.href, r = kr;
        kr = n;
        if (ae("history", {
            from: r,
            to: n
        }), e) try {
            return e.apply(this, t);
        } catch (e) {}
    }, Le(br.history, "pushState", t), Le(br.history, "replaceState", t);
}
const Or = {};
function Pr(e) {
    Or[e] = void 0;
}
const Ar = "__sentry_xhr_v3__";
function jr() {
    if (!br.XMLHttpRequest) return;
    const e = XMLHttpRequest.prototype;
    e.open = new Proxy(e.open, {
        apply (e, t, n) {
            const r = new Error, i = 1e3 * qe(), o = be(n[0]) ? n[0].toUpperCase() : void 0, s = function(e) {
                if (be(e)) return e;
                try {
                    return e.toString();
                } catch (e) {}
                return;
            }(n[1]);
            if (!o || !s) return e.apply(t, n);
            t[Ar] = {
                method: o,
                url: s,
                request_headers: {}
            }, "POST" === o && s.match(/sentry_key/) && (t.__sentry_own_request__ = !0);
            const a = ()=>{
                const e = t[Ar];
                if (e && 4 === t.readyState) {
                    try {
                        e.status_code = t.status;
                    } catch (e) {}
                    ae("xhr", {
                        endTimestamp: 1e3 * qe(),
                        startTimestamp: i,
                        xhr: t,
                        virtualError: r
                    });
                }
            };
            return "onreadystatechange" in t && "function" == typeof t.onreadystatechange ? t.onreadystatechange = new Proxy(t.onreadystatechange, {
                apply: (e, t, n)=>(a(), e.apply(t, n))
            }) : t.addEventListener("readystatechange", a), t.setRequestHeader = new Proxy(t.setRequestHeader, {
                apply (e, t, n) {
                    const [r, i] = n, o = t[Ar];
                    return o && be(r) && be(i) && (o.request_headers[r.toLowerCase()] = i), e.apply(t, n);
                }
            }), e.apply(t, n);
        }
    }), e.send = new Proxy(e.send, {
        apply (e, t, n) {
            const r = t[Ar];
            if (!r) return e.apply(t, n);
            void 0 !== n[0] && (r.body = n[0]);
            return ae("xhr", {
                startTimestamp: 1e3 * qe(),
                xhr: t
            }), e.apply(t, n);
        }
    });
}
function Ir(e, t = function(e) {
    const t = Or[e];
    if (t) return t;
    let n = br[e];
    if (Qn(n)) return Or[e] = n.bind(br);
    const r = br.document;
    if (r && "function" == typeof r.createElement) try {
        const t = r.createElement("iframe");
        t.hidden = !0, r.head.appendChild(t);
        const i = t.contentWindow;
        i && i[e] && (n = i[e]), r.head.removeChild(t);
    } catch (t) {
        yr && Q.warn(`Could not create sandbox iframe for ${e} check, bailing to window.${e}: `, t);
    }
    return n ? Or[e] = n.bind(br) : n;
}("fetch")) {
    let n = 0, r = 0;
    return En(e, function(i) {
        const o = i.body.length;
        n += o, r++;
        const s = {
            body: i.body,
            method: "POST",
            referrerPolicy: "origin",
            headers: e.headers,
            keepalive: n <= 6e4 && r < 15,
            ...e.fetchOptions
        };
        if (!t) return Pr("fetch"), Ze("No fetch implementation available");
        try {
            return t(e.url, s).then((e)=>(n -= o, r--, {
                    statusCode: e.status,
                    headers: {
                        "x-sentry-rate-limits": e.headers.get("X-Sentry-Rate-Limits"),
                        "retry-after": e.headers.get("Retry-After")
                    }
                }));
        } catch (e) {
            return Pr("fetch"), n -= o, r--, Ze(e);
        }
    });
}
function xr(e, t, n, r) {
    const i = {
        filename: e,
        function: "<anonymous>" === t ? K : t,
        in_app: !0
    };
    return void 0 !== n && (i.lineno = n), void 0 !== r && (i.colno = r), i;
}
const Lr = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, Dr = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, Nr = /\((\S*)(?::(\d+))(?::(\d+))\)/, Rr = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, Fr = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, Br = function(...e) {
    const t = e.sort((e, t)=>e[0] - t[0]).map((e)=>e[1]);
    return (e, n = 0, r = 0)=>{
        const i = [], o = e.split("\n");
        for(let e = n; e < o.length; e++){
            const n = o[e];
            if (n.length > 1024) continue;
            const s = Y.test(n) ? n.replace(Y, "$1") : n;
            if (!s.match(/\S*Error: /)) {
                for (const e of t){
                    const t = e(s);
                    if (t) {
                        i.push(t);
                        break;
                    }
                }
                if (i.length >= 50 + r) break;
            }
        }
        return function(e) {
            if (!e.length) return [];
            const t = Array.from(e);
            /sentryWrapped/.test(Z(t).function || "") && t.pop();
            t.reverse(), X.test(Z(t).function || "") && (t.pop(), X.test(Z(t).function || "") && t.pop());
            return t.slice(0, 50).map((e)=>({
                    ...e,
                    filename: e.filename || Z(t).filename,
                    function: e.function || K
                }));
        }(i.slice(r));
    };
}(...[
    [
        30,
        (e)=>{
            const t = Lr.exec(e);
            if (t) {
                const [, e, n, r] = t;
                return xr(e, K, +n, +r);
            }
            const n = Dr.exec(e);
            if (n) {
                if (n[2] && 0 === n[2].indexOf("eval")) {
                    const e = Nr.exec(n[2]);
                    e && (n[2] = e[1], n[3] = e[2], n[4] = e[3]);
                }
                const [e, t] = Ur(n[1] || K, n[2]);
                return xr(t, e, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
            }
        }
    ],
    [
        50,
        (e)=>{
            const t = Rr.exec(e);
            if (t) {
                if (t[3] && t[3].indexOf(" > eval") > -1) {
                    const e = Fr.exec(t[3]);
                    e && (t[1] = t[1] || "eval", t[3] = e[1], t[4] = e[2], t[5] = "");
                }
                let e = t[3], n = t[1] || K;
                return [n, e] = Ur(n, e), xr(e, n, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0);
            }
        }
    ]
]), Ur = (e, t)=>{
    const n = -1 !== e.indexOf("safari-extension"), r = -1 !== e.indexOf("safari-web-extension");
    return n || r ? [
        -1 !== e.indexOf("@") ? e.split("@")[0] : K,
        n ? `safari-extension:${t}` : `safari-web-extension:${t}`
    ] : [
        e,
        t
    ];
}, Vr = 1024, Jr = (e = {})=>{
    const t = {
        console: !0,
        dom: !0,
        fetch: !0,
        history: !0,
        sentry: !0,
        xhr: !0,
        ...e
    };
    return {
        name: "Breadcrumbs",
        setup (e) {
            var n;
            t.console && function(e) {
                const t = "console";
                oe(t, e), se(t, Vn);
            }(function(e) {
                return function(t) {
                    if (bt() !== e) return;
                    const n = {
                        category: "console",
                        data: {
                            arguments: t.args,
                            logger: "console"
                        },
                        level: Jn(t.level),
                        message: je(t.args, " ")
                    };
                    if ("assert" === t.level) {
                        if (!1 !== t.args[0]) return;
                        n.message = `Assertion failed: ${je(t.args.slice(1), " ") || "console.assert"}`, n.data.arguments = t.args.slice(1);
                    }
                    Pn(n, {
                        input: t.args,
                        level: t.level
                    });
                };
            }(e)), t.dom && (n = function(e, t) {
                return function(n) {
                    if (bt() !== e) return;
                    let r, i, o = "object" == typeof t ? t.serializeAttribute : void 0, s = "object" == typeof t && "number" == typeof t.maxStringLength ? t.maxStringLength : void 0;
                    s && s > Vr && (or && Q.warn(`\`dom.maxStringLength\` cannot exceed 1024, but a value of ${s} was configured. Sentry will use 1024 instead.`), s = Vr), "string" == typeof o && (o = [
                        o
                    ]);
                    try {
                        const e = n.event, t = function(e) {
                            return !!e && !!e.target;
                        }(e) ? e.target : e;
                        r = Oe(t, {
                            keyAttrs: o,
                            maxStringLength: s
                        }), i = function(e) {
                            if (!Te.HTMLElement) return null;
                            let t = e;
                            for(let e = 0; e < 5; e++){
                                if (!t) return null;
                                if (t instanceof HTMLElement) {
                                    if (t.dataset.sentryComponent) return t.dataset.sentryComponent;
                                    if (t.dataset.sentryElement) return t.dataset.sentryElement;
                                }
                                t = t.parentNode;
                            }
                            return null;
                        }(t);
                    } catch (e) {
                        r = "<unknown>";
                    }
                    if (0 === r.length) return;
                    const a = {
                        category: `ui.${n.name}`,
                        message: r
                    };
                    i && (a.data = {
                        "ui.component_name": i
                    }), Pn(a, {
                        event: n.event,
                        name: n.name,
                        global: n.global
                    });
                };
            }(e, t.dom), oe("dom", n), se("dom", Mr)), t.xhr && function(e) {
                oe("xhr", e), se("xhr", jr);
            }(function(e) {
                return function(t) {
                    if (bt() !== e) return;
                    const { startTimestamp: n, endTimestamp: r } = t, i = t.xhr[Ar];
                    if (!n || !r || !i) return;
                    const { method: o, url: s, status_code: a, body: c } = i, l = {
                        method: o,
                        url: s,
                        status_code: a
                    }, u = {
                        xhr: t.xhr,
                        input: c,
                        startTimestamp: n,
                        endTimestamp: r
                    };
                    Pn({
                        category: "xhr",
                        data: l,
                        type: "http",
                        level: Hn(a)
                    }, u);
                };
            }(e)), t.fetch && Yn(function(e) {
                return function(t) {
                    if (bt() !== e) return;
                    const { startTimestamp: n, endTimestamp: r } = t;
                    if (r && (!t.fetchData.url.match(/sentry_key/) || "POST" !== t.fetchData.method)) if (t.error) {
                        Pn({
                            category: "fetch",
                            data: t.fetchData,
                            level: "error",
                            type: "http"
                        }, {
                            data: t.error,
                            input: t.args,
                            startTimestamp: n,
                            endTimestamp: r
                        });
                    } else {
                        const e = t.response, i = {
                            ...t.fetchData,
                            status_code: e && e.status
                        }, o = {
                            input: t.args,
                            response: e,
                            startTimestamp: n,
                            endTimestamp: r
                        };
                        Pn({
                            category: "fetch",
                            data: i,
                            type: "http",
                            level: Hn(i.status_code)
                        }, o);
                    }
                };
            }(e)), t.history && Er(function(e) {
                return function(t) {
                    if (bt() !== e) return;
                    let n = t.from, r = t.to;
                    const i = Un(tr.location.href);
                    let o = n ? Un(n) : void 0;
                    const s = Un(r);
                    o && o.path || (o = i), i.protocol === s.protocol && i.host === s.host && (r = s.relative), i.protocol === o.protocol && i.host === o.host && (n = o.relative), Pn({
                        category: "navigation",
                        data: {
                            from: n,
                            to: r
                        }
                    });
                };
            }(e)), t.sentry && e.on("beforeSendEvent", function(e) {
                return function(t) {
                    bt() === e && Pn({
                        category: "sentry." + ("transaction" === t.type ? "transaction" : "event"),
                        event_id: t.event_id,
                        level: t.level,
                        message: He(t)
                    }, {
                        event: t
                    });
                };
            }(e));
        }
    };
};
const $r = [
    "EventTarget",
    "Window",
    "Node",
    "ApplicationCache",
    "AudioTrackList",
    "BroadcastChannel",
    "ChannelMergerNode",
    "CryptoOperation",
    "EventSource",
    "FileReader",
    "HTMLUnknownElement",
    "IDBDatabase",
    "IDBRequest",
    "IDBTransaction",
    "KeyOperation",
    "MediaController",
    "MessagePort",
    "ModalWindow",
    "Notification",
    "SVGElementInstance",
    "Screen",
    "SharedWorker",
    "TextTrack",
    "TextTrackCue",
    "TextTrackList",
    "WebSocket",
    "WebSocketWorker",
    "Worker",
    "XMLHttpRequest",
    "XMLHttpRequestEventTarget",
    "XMLHttpRequestUpload"
], qr = (e = {})=>{
    const t = {
        XMLHttpRequest: !0,
        eventTarget: !0,
        requestAnimationFrame: !0,
        setInterval: !0,
        setTimeout: !0,
        ...e
    };
    return {
        name: "BrowserApiErrors",
        setupOnce () {
            t.setTimeout && Le(tr, "setTimeout", zr), t.setInterval && Le(tr, "setInterval", zr), t.requestAnimationFrame && Le(tr, "requestAnimationFrame", Wr), t.XMLHttpRequest && "XMLHttpRequest" in tr && Le(XMLHttpRequest.prototype, "send", Hr);
            const e = t.eventTarget;
            if (e) {
                (Array.isArray(e) ? e : $r).forEach(Gr);
            }
        }
    };
};
function zr(e) {
    return function(...t) {
        const n = t[0];
        return t[0] = ir(n, {
            mechanism: {
                data: {
                    function: te(e)
                },
                handled: !1,
                type: "instrument"
            }
        }), e.apply(this, t);
    };
}
function Wr(e) {
    return function(t) {
        return e.apply(this, [
            ir(t, {
                mechanism: {
                    data: {
                        function: "requestAnimationFrame",
                        handler: te(e)
                    },
                    handled: !1,
                    type: "instrument"
                }
            })
        ]);
    };
}
function Hr(e) {
    return function(...t) {
        const n = this;
        return [
            "onload",
            "onerror",
            "onprogress",
            "onreadystatechange"
        ].forEach((e)=>{
            e in n && "function" == typeof n[e] && Le(n, e, function(t) {
                const n = {
                    mechanism: {
                        data: {
                            function: e,
                            handler: te(t)
                        },
                        handled: !1,
                        type: "instrument"
                    }
                }, r = Re(t);
                return r && (n.mechanism.data.handler = te(r)), ir(t, n);
            });
        }), e.apply(this, t);
    };
}
function Gr(e) {
    const t = tr[e], n = t && t.prototype;
    n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && (Le(n, "addEventListener", function(t) {
        return function(n, r, i) {
            try {
                "function" == typeof r.handleEvent && (r.handleEvent = ir(r.handleEvent, {
                    mechanism: {
                        data: {
                            function: "handleEvent",
                            handler: te(r),
                            target: e
                        },
                        handled: !1,
                        type: "instrument"
                    }
                }));
            } catch (e) {}
            return t.apply(this, [
                n,
                ir(r, {
                    mechanism: {
                        data: {
                            function: "addEventListener",
                            handler: te(r),
                            target: e
                        },
                        handled: !1,
                        type: "instrument"
                    }
                }),
                i
            ]);
        };
    }), Le(n, "removeEventListener", function(e) {
        return function(t, n, r) {
            try {
                const i = n.__sentry_wrapped__;
                i && e.call(this, t, i, r);
            } catch (e) {}
            return e.call(this, t, n, r);
        };
    }));
}
const Qr = ()=>({
        name: "BrowserSession",
        setupOnce () {
            void 0 !== tr.document ? (dn({
                ignoreDuration: !0
            }), fn(), Er(({ from: e, to: t })=>{
                void 0 !== e && e !== t && (dn({
                    ignoreDuration: !0
                }), fn());
            })) : or && Q.warn("Using the `browserSessionIntegration` in non-browser environments is not supported.");
        }
    }), Kr = (e = {})=>{
    const t = {
        onerror: !0,
        onunhandledrejection: !0,
        ...e
    };
    return {
        name: "GlobalHandlers",
        setupOnce () {
            Error.stackTraceLimit = 50;
        },
        setup (e) {
            t.onerror && (!function(e) {
                !function(e) {
                    const t = "error";
                    oe(t, e), se(t, le);
                }((t)=>{
                    const { stackParser: n, attachStacktrace: r } = Xr();
                    if (bt() !== e || rr()) return;
                    const { msg: i, url: o, line: s, column: a, error: c } = t, l = function(e, t, n, r) {
                        const i = e.exception = e.exception || {}, o = i.values = i.values || [], s = o[0] = o[0] || {}, a = s.stacktrace = s.stacktrace || {}, c = a.frames = a.frames || [], l = r, u = n, d = be(t) && t.length > 0 ? t : function() {
                            try {
                                return Te.document.location.href;
                            } catch (e) {
                                return "";
                            }
                        }();
                        0 === c.length && c.push({
                            colno: l,
                            filename: d,
                            function: K,
                            in_app: !0,
                            lineno: u
                        });
                        return e;
                    }(fr(n, c || i, void 0, r, !1), o, s, a);
                    l.level = "error", un(l, {
                        originalException: c,
                        mechanism: {
                            handled: !1,
                            type: "onerror"
                        }
                    });
                });
            }(e), Yr("onerror")), t.onunhandledrejection && (!function(e) {
                !function(e) {
                    const t = "unhandledrejection";
                    oe(t, e), se(t, de);
                }((t)=>{
                    const { stackParser: n, attachStacktrace: r } = Xr();
                    if (bt() !== e || rr()) return;
                    const i = function(e) {
                        if (we(e)) return e;
                        try {
                            if ("reason" in e) return e.reason;
                            if ("detail" in e && "reason" in e.detail) return e.detail.reason;
                        } catch (e) {}
                        return e;
                    }(t), o = we(i) ? {
                        exception: {
                            values: [
                                {
                                    type: "UnhandledRejection",
                                    value: `Non-Error promise rejection captured with value: ${String(i)}`
                                }
                            ]
                        }
                    } : fr(n, i, void 0, r, !0);
                    o.level = "error", un(o, {
                        originalException: i,
                        mechanism: {
                            handled: !1,
                            type: "onunhandledrejection"
                        }
                    });
                });
            }(e), Yr("onunhandledrejection"));
        }
    };
};
function Yr(e) {
    or && Q.log(`Global Handler attached: ${e}`);
}
function Xr() {
    const e = bt();
    return e && e.getOptions() || {
        stackParser: ()=>[],
        attachStacktrace: !1
    };
}
const Zr = ()=>({
        name: "HttpContext",
        preprocessEvent (e) {
            if (!tr.navigator && !tr.location && !tr.document) return;
            const t = e.request && e.request.url || tr.location && tr.location.href, { referrer: n } = tr.document || {}, { userAgent: r } = tr.navigator || {}, i = {
                ...e.request && e.request.headers,
                ...n && {
                    Referer: n
                },
                ...r && {
                    "User-Agent": r
                }
            }, o = {
                ...e.request,
                ...t && {
                    url: t
                },
                headers: i
            };
            e.request = o;
        }
    }), ei = (e = {})=>{
    const t = e.limit || 5, n = e.key || "cause";
    return {
        name: "LinkedErrors",
        preprocessEvent (e, r, i) {
            const o = i.getOptions();
            Nn(sr, o.stackParser, o.maxValueLength, n, t, e, r);
        }
    };
};
var ti = "new", ni = "loading", ri = "loaded", ii = "joining-meeting", oi = "joined-meeting", si = "left-meeting", ai = "error", ci = "blocked", li = "off", ui = "sendable", di = "loading", pi = "interrupted", hi = "playable", fi = "unknown", vi = "full", gi = "lobby", mi = "none", yi = "base", bi = "*", _i = "ejected", wi = "nbf-room", Si = "nbf-token", ki = "exp-room", Mi = "exp-token", Ci = "no-room", Ei = "meeting-full", Ti = "end-of-life", Oi = "not-allowed", Pi = "connection-error", Ai = "cam-in-use", ji = "mic-in-use", Ii = "cam-mic-in-use", xi = "permissions", Li = "undefined-mediadevices", Di = "not-found", Ni = "constraints", Ri = "unknown", Fi = "iframe-ready-for-launch-config", Bi = "iframe-launch-config", Ui = "theme-updated", Vi = "loading", Ji = "load-attempt-failed", $i = "loaded", qi = "started-camera", zi = "camera-error", Wi = "joining-meeting", Hi = "joined-meeting", Gi = "left-meeting", Qi = "participant-joined", Ki = "participant-updated", Yi = "participant-left", Xi = "participant-counts-updated", Zi = "access-state-updated", eo = "meeting-session-summary-updated", to = "meeting-session-state-updated", no = "meeting-session-data-error", ro = "waiting-participant-added", io = "waiting-participant-updated", oo = "waiting-participant-removed", so = "track-started", ao = "track-stopped", co = "transcription-started", lo = "transcription-stopped", uo = "transcription-error", po = "recording-started", ho = "recording-stopped", fo = "recording-stats", vo = "recording-error", go = "recording-upload-completed", mo = "recording-data", yo = "app-message", bo = "transcription-message", _o = "remote-media-player-started", wo = "remote-media-player-updated", So = "remote-media-player-stopped", ko = "local-screen-share-started", Mo = "local-screen-share-stopped", Co = "local-screen-share-canceled", Eo = "active-speaker-change", To = "active-speaker-mode-change", Oo = "network-quality-change", Po = "network-connection", Ao = "cpu-load-change", jo = "face-counts-updated", Io = "fullscreen", xo = "exited-fullscreen", Lo = "live-streaming-started", Do = "live-streaming-updated", No = "live-streaming-stopped", Ro = "live-streaming-error", Fo = "lang-updated", Bo = "receive-settings-updated", Uo = "input-settings-updated", Vo = "nonfatal-error", Jo = "error", $o = 4096, qo = 102400, zo = "iframe-call-message", Wo = "local-screen-start", Ho = "daily-method-update-live-streaming-endpoints", Go = "transmit-log", Qo = "daily-custom-track", Ko = {
    NONE: "none",
    BGBLUR: "background-blur",
    BGIMAGE: "background-image",
    FACE_DETECTION: "face-detection"
}, Yo = {
    NONE: "none",
    NOISE_CANCELLATION: "noise-cancellation"
}, Xo = {
    PLAY: "play",
    PAUSE: "pause"
}, Zo = [
    "jpg",
    "png",
    "jpeg"
], es = "add-endpoints", ts = "remove-endpoints", ns = "sip-call-transfer";
function rs() {
    return !is() && "undefined" != typeof window && window.navigator && window.navigator.userAgent ? window.navigator.userAgent : "";
}
function is() {
    return "undefined" != typeof navigator && navigator.product && "ReactNative" === navigator.product;
}
function os() {
    return navigator && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
}
function ss() {
    return !!(navigator && navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) && (function(e, t) {
        if (!e || !t) return !0;
        switch(e){
            case "Chrome":
                return t.major >= 75;
            case "Safari":
                return RTCRtpTransceiver.prototype.hasOwnProperty("currentDirection") && !(13 === t.major && 0 === t.minor && 0 === t.point);
            case "Firefox":
                return t.major >= 67;
        }
        return !0;
    }(ms(), ys()) || is());
}
function as() {
    if (is()) return !1;
    if (!document) return !1;
    var e = document.createElement("iframe");
    return !!e.requestFullscreen || !!e.webkitRequestFullscreen;
}
var cs = "none", ls = "software", us = "hardware";
var ds = function() {
    try {
        var e, t = document.createElement("canvas"), n = !1;
        (e = t.getContext("webgl2", {
            failIfMajorPerformanceCaveat: !0
        })) || (n = !0, e = t.getContext("webgl2"));
        var r = null != e;
        return t.remove(), r ? n ? ls : us : cs;
    } catch (e) {
        return cs;
    }
}();
function ps() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return !is() && ds !== cs && (e ? function() {
        if (gs()) return !1;
        return [
            "Chrome",
            "Firefox"
        ].includes(ms());
    }() : function() {
        if (gs()) return !1;
        var e = ms();
        if ("Safari" === e) {
            var t = Ss();
            if (t.major < 15 || 15 === t.major && t.minor < 4) return !1;
        }
        if ("Chrome" === e) {
            return bs().major >= 77;
        }
        if ("Firefox" === e) {
            return ks().major >= 97;
        }
        return [
            "Chrome",
            "Firefox",
            "Safari"
        ].includes(e);
    }());
}
function hs() {
    if (is()) return !1;
    if (vs()) return !1;
    if ("undefined" == typeof AudioWorkletNode) return !1;
    switch(ms()){
        case "Chrome":
        case "Firefox":
            return !0;
        case "Safari":
            var e = ys();
            return e.major > 17 || 17 === e.major && e.minor >= 4;
    }
    return !1;
}
function fs() {
    return os() && "undefined" != typeof MediaStreamTrack && !function() {
        var e, t = ms();
        if (!rs()) return !0;
        switch(t){
            case "Chrome":
                return (e = bs()).major && e.major > 0 && e.major < 75;
            case "Firefox":
                return (e = ks()).major < 91;
            case "Safari":
                return (e = Ss()).major < 13 || 13 === e.major && e.minor < 1;
            default:
                return !0;
        }
    }();
}
function vs() {
    return rs().match(/Linux; Android/);
}
function gs() {
    var e, t = rs(), n = t.match(/Mac/) && (!is() && "undefined" != typeof window && null !== (e = window) && void 0 !== e && null !== (e = e.navigator) && void 0 !== e && e.maxTouchPoints ? window.navigator.maxTouchPoints : 0) >= 5;
    return !!(t.match(/Mobi/) || t.match(/Android/) || n) || !!rs().match(/DailyAnd\//) || void 0;
}
function ms() {
    if ("undefined" != typeof window) {
        var e = rs();
        return _s() ? "Safari" : e.indexOf("Edge") > -1 ? "Edge" : e.match(/Chrome\//) ? "Chrome" : e.indexOf("Safari") > -1 || ws() ? "Safari" : e.indexOf("Firefox") > -1 ? "Firefox" : e.indexOf("MSIE") > -1 || e.indexOf(".NET") > -1 ? "IE" : "Unknown Browser";
    }
}
function ys() {
    switch(ms()){
        case "Chrome":
            return bs();
        case "Safari":
            return Ss();
        case "Firefox":
            return ks();
        case "Edge":
            return function() {
                var e = 0, t = 0;
                if ("undefined" != typeof window) {
                    var n = rs().match(/Edge\/(\d+).(\d+)/);
                    if (n) try {
                        e = parseInt(n[1]), t = parseInt(n[2]);
                    } catch (e) {}
                }
                return {
                    major: e,
                    minor: t
                };
            }();
    }
}
function bs() {
    var e = 0, t = 0, n = 0, r = 0, i = !1;
    if ("undefined" != typeof window) {
        var o = rs(), s = o.match(/Chrome\/(\d+).(\d+).(\d+).(\d+)/);
        if (s) try {
            e = parseInt(s[1]), t = parseInt(s[2]), n = parseInt(s[3]), r = parseInt(s[4]), i = o.indexOf("OPR/") > -1;
        } catch (e) {}
    }
    return {
        major: e,
        minor: t,
        build: n,
        patch: r,
        opera: i
    };
}
function _s() {
    return !!rs().match(/iPad|iPhone|iPod/i) && os();
}
function ws() {
    return rs().indexOf("AppleWebKit/605.1.15") > -1;
}
function Ss() {
    var e = 0, t = 0, n = 0;
    if ("undefined" != typeof window) {
        var r = rs().match(/Version\/(\d+).(\d+)(.(\d+))?/);
        if (r) try {
            e = parseInt(r[1]), t = parseInt(r[2]), n = parseInt(r[4]);
        } catch (e) {}
        else (_s() || ws()) && (e = 14, t = 0, n = 3);
    }
    return {
        major: e,
        minor: t,
        point: n
    };
}
function ks() {
    var e = 0, t = 0;
    if ("undefined" != typeof window) {
        var n = rs().match(/Firefox\/(\d+).(\d+)/);
        if (n) try {
            e = parseInt(n[1]), t = parseInt(n[2]);
        } catch (e) {}
    }
    return {
        major: e,
        minor: t
    };
}
var Ms = function() {
    return o(function e() {
        t(this, e);
    }, [
        {
            key: "addListenerForMessagesFromCallMachine",
            value: function(e, t, n) {
                R();
            }
        },
        {
            key: "addListenerForMessagesFromDailyJs",
            value: function(e, t, n) {
                R();
            }
        },
        {
            key: "sendMessageToCallMachine",
            value: function(e, t, n, r) {
                R();
            }
        },
        {
            key: "sendMessageToDailyJs",
            value: function(e, t) {
                R();
            }
        },
        {
            key: "removeListener",
            value: function(e) {
                R();
            }
        }
    ]);
}();
function Cs(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}
function Es(e) {
    for(var t = 1; t < arguments.length; t++){
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? Cs(Object(n), !0).forEach(function(t) {
            u(e, t, n[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Cs(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
    }
    return e;
}
function Ts() {
    try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (e) {}
    return (Ts = function() {
        return !!e;
    })();
}
var Os = function() {
    function e() {
        var n, r, i, o;
        return t(this, e), r = this, i = a(i = e), (n = s(r, Ts() ? Reflect.construct(i, o || [], a(r).constructor) : i.apply(r, o)))._wrappedListeners = {}, n._messageCallbacks = {}, n;
    }
    return l(e, Ms), o(e, [
        {
            key: "addListenerForMessagesFromCallMachine",
            value: function(e, t, n) {
                var r = this, i = function(i) {
                    if (i.data && "iframe-call-message" === i.data.what && (!i.data.callClientId || i.data.callClientId === t) && (!i.data.from || "module" !== i.data.from)) {
                        var o = Es({}, i.data);
                        if (delete o.from, o.callbackStamp && r._messageCallbacks[o.callbackStamp]) {
                            var s = o.callbackStamp;
                            r._messageCallbacks[s].call(n, o), delete r._messageCallbacks[s];
                        }
                        delete o.what, delete o.callbackStamp, e.call(n, o);
                    }
                };
                this._wrappedListeners[e] = i, window.addEventListener("message", i);
            }
        },
        {
            key: "addListenerForMessagesFromDailyJs",
            value: function(e, t, n) {
                var r = function(r) {
                    var i;
                    if (!(!r.data || r.data.what !== zo || !r.data.action || r.data.from && "module" !== r.data.from || r.data.callClientId && t && r.data.callClientId !== t || null != r && null !== (i = r.data) && void 0 !== i && i.callFrameId)) {
                        var o = r.data;
                        e.call(n, o);
                    }
                };
                this._wrappedListeners[e] = r, window.addEventListener("message", r);
            }
        },
        {
            key: "sendMessageToCallMachine",
            value: function(e, t, n, r) {
                if (!n) throw new Error("undefined callClientId. Are you trying to use a DailyCall instance previously destroyed?");
                var i = Es({}, e);
                if (i.what = zo, i.from = "module", i.callClientId = n, t) {
                    var o = N();
                    this._messageCallbacks[o] = t, i.callbackStamp = o;
                }
                var s = r ? r.contentWindow : window, a = this._callMachineTargetOrigin(r);
                a && s.postMessage(i, a);
            }
        },
        {
            key: "sendMessageToDailyJs",
            value: function(e, t) {
                e.what = zo, e.callClientId = t, e.from = "embedded", window.postMessage(e, this._targetOriginFromWindowLocation());
            }
        },
        {
            key: "removeListener",
            value: function(e) {
                var t = this._wrappedListeners[e];
                t && (window.removeEventListener("message", t), delete this._wrappedListeners[e]);
            }
        },
        {
            key: "forwardPackagedMessageToCallMachine",
            value: function(e, t, n) {
                var r = Es({}, e);
                r.callClientId = n;
                var i = t ? t.contentWindow : window, o = this._callMachineTargetOrigin(t);
                o && i.postMessage(r, o);
            }
        },
        {
            key: "addListenerForPackagedMessagesFromCallMachine",
            value: function(e, t) {
                var n = function(n) {
                    if (n.data && "iframe-call-message" === n.data.what && (!n.data.callClientId || n.data.callClientId === t) && (!n.data.from || "module" !== n.data.from)) {
                        var r = n.data;
                        e(r);
                    }
                };
                return this._wrappedListeners[e] = n, window.addEventListener("message", n), e;
            }
        },
        {
            key: "removeListenerForPackagedMessagesFromCallMachine",
            value: function(e) {
                var t = this._wrappedListeners[e];
                t && (window.removeEventListener("message", t), delete this._wrappedListeners[e]);
            }
        },
        {
            key: "_callMachineTargetOrigin",
            value: function(e) {
                return e ? e.src ? new URL(e.src).origin : void 0 : this._targetOriginFromWindowLocation();
            }
        },
        {
            key: "_targetOriginFromWindowLocation",
            value: function() {
                return "file:" === window.location.protocol ? "*" : window.location.origin;
            }
        }
    ]);
}();
function Ps(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}
function As() {
    try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (e) {}
    return (As = function() {
        return !!e;
    })();
}
var js = function() {
    function e() {
        var n, r, i, o;
        return t(this, e), r = this, i = a(i = e), n = s(r, As() ? Reflect.construct(i, o || [], a(r).constructor) : i.apply(r, o)), /*TURBOPACK member replacement*/ __turbopack_context__.g.callMachineToDailyJsEmitter = /*TURBOPACK member replacement*/ __turbopack_context__.g.callMachineToDailyJsEmitter || new y.EventEmitter, /*TURBOPACK member replacement*/ __turbopack_context__.g.dailyJsToCallMachineEmitter = /*TURBOPACK member replacement*/ __turbopack_context__.g.dailyJsToCallMachineEmitter || new y.EventEmitter, n._wrappedListeners = {}, n._messageCallbacks = {}, n;
    }
    return l(e, Ms), o(e, [
        {
            key: "addListenerForMessagesFromCallMachine",
            value: function(e, t, n) {
                this._addListener(e, /*TURBOPACK member replacement*/ __turbopack_context__.g.callMachineToDailyJsEmitter, t, n, "received call machine message");
            }
        },
        {
            key: "addListenerForMessagesFromDailyJs",
            value: function(e, t, n) {
                this._addListener(e, /*TURBOPACK member replacement*/ __turbopack_context__.g.dailyJsToCallMachineEmitter, t, n, "received daily-js message");
            }
        },
        {
            key: "sendMessageToCallMachine",
            value: function(e, t, n) {
                this._sendMessage(e, /*TURBOPACK member replacement*/ __turbopack_context__.g.dailyJsToCallMachineEmitter, n, t, "sending message to call machine");
            }
        },
        {
            key: "sendMessageToDailyJs",
            value: function(e, t) {
                this._sendMessage(e, /*TURBOPACK member replacement*/ __turbopack_context__.g.callMachineToDailyJsEmitter, t, null, "sending message to daily-js");
            }
        },
        {
            key: "removeListener",
            value: function(e) {
                var t = this._wrappedListeners[e];
                t && (/*TURBOPACK member replacement*/ __turbopack_context__.g.callMachineToDailyJsEmitter.removeListener("message", t), /*TURBOPACK member replacement*/ __turbopack_context__.g.dailyJsToCallMachineEmitter.removeListener("message", t), delete this._wrappedListeners[e]);
            }
        },
        {
            key: "_addListener",
            value: function(e, t, n, r, i) {
                var o = this, s = function(t) {
                    if (t.callClientId === n) {
                        if (t.callbackStamp && o._messageCallbacks[t.callbackStamp]) {
                            var i = t.callbackStamp;
                            o._messageCallbacks[i].call(r, t), delete o._messageCallbacks[i];
                        }
                        e.call(r, t);
                    }
                };
                this._wrappedListeners[e] = s, t.addListener("message", s);
            }
        },
        {
            key: "_sendMessage",
            value: function(e, t, n, r, i) {
                var o = function(e) {
                    for(var t = 1; t < arguments.length; t++){
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Ps(Object(n), !0).forEach(function(t) {
                            u(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ps(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, e);
                if (o.callClientId = n, r) {
                    var s = N();
                    this._messageCallbacks[s] = r, o.callbackStamp = s;
                }
                t.emit("message", o);
            }
        }
    ]);
}(), Is = "replace", xs = "shallow-merge", Ls = [
    Is,
    xs
];
var Ds = function() {
    function e() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = n.data, i = n.mergeStrategy, o = void 0 === i ? Is : i;
        t(this, e), e._validateMergeStrategy(o), e._validateData(r, o), this.mergeStrategy = o, this.data = r;
    }
    return o(e, [
        {
            key: "isNoOp",
            value: function() {
                return e.isNoOpUpdate(this.data, this.mergeStrategy);
            }
        }
    ], [
        {
            key: "isNoOpUpdate",
            value: function(e, t) {
                return 0 === Object.keys(e).length && t === xs;
            }
        },
        {
            key: "_validateMergeStrategy",
            value: function(e) {
                if (!Ls.includes(e)) throw Error("Unrecognized mergeStrategy provided. Options are: [".concat(Ls, "]"));
            }
        },
        {
            key: "_validateData",
            value: function(e, t) {
                if (!function(e) {
                    if (null == e || "object" !== n(e)) return !1;
                    var t = Object.getPrototypeOf(e);
                    return null == t || t === Object.prototype;
                }(e)) throw Error("Meeting session data must be a plain (map-like) object");
                var r;
                try {
                    if (r = JSON.stringify(e), t === Is) {
                        var i = JSON.parse(r);
                        S(i, e) || console.warn("The meeting session data provided will be modified when serialized.", i, e);
                    } else if (t === xs) {
                        for(var o in e)if (Object.hasOwnProperty.call(e, o) && void 0 !== e[o]) {
                            var s = JSON.parse(JSON.stringify(e[o]));
                            S(e[o], s) || console.warn("At least one key in the meeting session data provided will be modified when serialized.", s, e[o]);
                        }
                    }
                } catch (e) {
                    throw Error("Meeting session data must be serializable to JSON: ".concat(e));
                }
                if (r.length > qo) throw Error("Meeting session data is too large (".concat(r.length, " characters). Maximum size suppported is ").concat(qo, "."));
            }
        }
    ]);
}();
function Ns() {
    try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (e) {}
    return (Ns = function() {
        return !!e;
    })();
}
function Rs(e) {
    var t = "function" == typeof Map ? new Map : void 0;
    return Rs = function(e) {
        if (null === e || !function(e) {
            try {
                return -1 !== Function.toString.call(e).indexOf("[native code]");
            } catch (t) {
                return "function" == typeof e;
            }
        }(e)) return e;
        if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== t) {
            if (t.has(e)) return t.get(e);
            t.set(e, n);
        }
        function n() {
            return function(e, t, n) {
                if (Ns()) return Reflect.construct.apply(null, arguments);
                var r = [
                    null
                ];
                r.push.apply(r, t);
                var i = new (e.bind.apply(e, r));
                return n && c(i, n.prototype), i;
            }(e, arguments, a(this).constructor);
        }
        return n.prototype = Object.create(e.prototype, {
            constructor: {
                value: n,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), c(n, e);
    }, Rs(e);
}
function Fs() {
    try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (e) {}
    return (Fs = function() {
        return !!e;
    })();
}
function Bs(e) {
    var t, n = null === (t = window._daily) || void 0 === t ? void 0 : t.pendings;
    if (n) {
        var r = n.indexOf(e);
        -1 !== r && n.splice(r, 1);
    }
}
var Us = function() {
    return o(function e(n) {
        t(this, e), this._currentLoad = null, this._callClientId = n;
    }, [
        {
            key: "load",
            value: function() {
                var e, t = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0, i = arguments.length > 2 ? arguments[2] : void 0;
                if (this.loaded) return window._daily.instances[this._callClientId].callMachine.reset(), void r(!0);
                e = this._callClientId, window._daily.pendings.push(e), this._currentLoad && this._currentLoad.cancel(), this._currentLoad = new Vs(n, function() {
                    r(!1);
                }, function(e, n) {
                    n || Bs(t._callClientId), i(e, n);
                }), this._currentLoad.start();
            }
        },
        {
            key: "cancel",
            value: function() {
                this._currentLoad && this._currentLoad.cancel(), Bs(this._callClientId);
            }
        },
        {
            key: "loaded",
            get: function() {
                return this._currentLoad && this._currentLoad.succeeded;
            }
        }
    ]);
}(), Vs = function() {
    return o(function e() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0, i = arguments.length > 2 ? arguments[2] : void 0;
        t(this, e), this._attemptsRemaining = 3, this._currentAttempt = null, this._dailyConfig = n, this._successCallback = r, this._failureCallback = i;
    }, [
        {
            key: "start",
            value: function() {
                var e = this;
                if (!this._currentAttempt) {
                    var t = function(n) {
                        e._currentAttempt.cancelled || (e._attemptsRemaining--, e._failureCallback(n, e._attemptsRemaining > 0), e._attemptsRemaining <= 0 || setTimeout(function() {
                            e._currentAttempt.cancelled || (e._currentAttempt = new qs(e._dailyConfig, e._successCallback, t), e._currentAttempt.start());
                        }, 3e3));
                    };
                    this._currentAttempt = new qs(this._dailyConfig, this._successCallback, t), this._currentAttempt.start();
                }
            }
        },
        {
            key: "cancel",
            value: function() {
                this._currentAttempt && this._currentAttempt.cancel();
            }
        },
        {
            key: "cancelled",
            get: function() {
                return this._currentAttempt && this._currentAttempt.cancelled;
            }
        },
        {
            key: "succeeded",
            get: function() {
                return this._currentAttempt && this._currentAttempt.succeeded;
            }
        }
    ]);
}(), Js = function() {
    function e() {
        return t(this, e), n = this, i = arguments, r = a(r = e), s(n, Fs() ? Reflect.construct(r, i || [], a(n).constructor) : r.apply(n, i));
        //TURBOPACK unreachable
        ;
        var n, r, i;
    }
    return l(e, Rs(Error)), o(e);
}(), $s = 2e4, qs = function() {
    return o(function e(n, r, i) {
        t(this, e), this._loadAttemptImpl = is() || !n.avoidEval ? new zs(n, r, i) : new Ws(n, r, i);
    }, [
        {
            key: "start",
            value: (e = p(function*() {
                return this._loadAttemptImpl.start();
            }), function() {
                return e.apply(this, arguments);
            })
        },
        {
            key: "cancel",
            value: function() {
                this._loadAttemptImpl.cancel();
            }
        },
        {
            key: "cancelled",
            get: function() {
                return this._loadAttemptImpl.cancelled;
            }
        },
        {
            key: "succeeded",
            get: function() {
                return this._loadAttemptImpl.succeeded;
            }
        }
    ]);
    //TURBOPACK unreachable
    ;
    var e;
}(), zs = function() {
    return o(function e(n, r, i) {
        t(this, e), this.cancelled = !1, this.succeeded = !1, this._networkTimedOut = !1, this._networkTimeout = null, this._iosCache = "undefined" != typeof iOSCallObjectBundleCache && iOSCallObjectBundleCache, this._refetchHeaders = null, this._dailyConfig = n, this._successCallback = r, this._failureCallback = i;
    }, [
        {
            key: "start",
            value: (i = p(function*() {
                var e = B(this._dailyConfig);
                !(yield this._tryLoadFromIOSCache(e)) && this._loadFromNetwork(e);
            }), function() {
                return i.apply(this, arguments);
            })
        },
        {
            key: "cancel",
            value: function() {
                clearTimeout(this._networkTimeout), this.cancelled = !0;
            }
        },
        {
            key: "_tryLoadFromIOSCache",
            value: (r = p(function*(e) {
                if (!this._iosCache) return !1;
                try {
                    var t = yield this._iosCache.get(e);
                    return !!this.cancelled || !!t && (t.code ? (Function('"use strict";' + t.code)(), this.succeeded = !0, this._successCallback(), !0) : (this._refetchHeaders = t.refetchHeaders, !1));
                } catch (e) {
                    return !1;
                }
            }), function(e) {
                return r.apply(this, arguments);
            })
        },
        {
            key: "_loadFromNetwork",
            value: (n = p(function*(e) {
                var t = this;
                this._networkTimeout = setTimeout(function() {
                    t._networkTimedOut = !0, t._failureCallback({
                        msg: "Timed out (>".concat($s, " ms) when loading call object bundle ").concat(e),
                        type: "timeout"
                    });
                }, $s);
                try {
                    var n = this._refetchHeaders ? {
                        headers: this._refetchHeaders
                    } : {}, r = yield fetch(e, n);
                    if (clearTimeout(this._networkTimeout), this.cancelled || this._networkTimedOut) throw new Js;
                    var i = yield this._getBundleCodeFromResponse(e, r);
                    if (this.cancelled) throw new Js;
                    Function('"use strict";' + i)(), this._iosCache && this._iosCache.set(e, i, r.headers), this.succeeded = !0, this._successCallback();
                } catch (t) {
                    if (clearTimeout(this._networkTimeout), t instanceof Js || this.cancelled || this._networkTimedOut) return;
                    this._failureCallback({
                        msg: "Failed to load call object bundle ".concat(e, ": ").concat(t),
                        type: t.message
                    });
                }
            }), function(e) {
                return n.apply(this, arguments);
            })
        },
        {
            key: "_getBundleCodeFromResponse",
            value: (e = p(function*(e, t) {
                if (t.ok) return yield t.text();
                if (this._iosCache && 304 === t.status) return (yield this._iosCache.renew(e, t.headers)).code;
                throw new Error("Received ".concat(t.status, " response"));
            }), function(t, n) {
                return e.apply(this, arguments);
            })
        }
    ]);
    //TURBOPACK unreachable
    ;
    var e, n, r, i;
}(), Ws = function() {
    return o(function e(n, r, i) {
        t(this, e), this.cancelled = !1, this.succeeded = !1, this._dailyConfig = n, this._successCallback = r, this._failureCallback = i, this._attemptId = N(), this._networkTimeout = null, this._scriptElement = null;
    }, [
        {
            key: "start",
            value: function() {
                window._dailyCallMachineLoadWaitlist || (window._dailyCallMachineLoadWaitlist = new Set);
                var e = B(this._dailyConfig);
                "object" === ("undefined" == typeof document ? "undefined" : n(document)) ? this._startLoading(e) : this._failureCallback({
                    msg: "Call object bundle must be loaded in a DOM/web context",
                    type: "missing context"
                });
            }
        },
        {
            key: "cancel",
            value: function() {
                this._stopLoading(), this.cancelled = !0;
            }
        },
        {
            key: "_startLoading",
            value: function(e) {
                var t = this;
                this._signUpForCallMachineLoadWaitlist(), this._networkTimeout = setTimeout(function() {
                    t._stopLoading(), t._failureCallback({
                        msg: "Timed out (>".concat($s, " ms) when loading call object bundle ").concat(e),
                        type: "timeout"
                    });
                }, $s);
                var n = document.getElementsByTagName("head")[0], r = document.createElement("script");
                this._scriptElement = r, r.onload = function() {
                    t._stopLoading(), t.succeeded = !0, t._successCallback();
                }, r.onerror = function(e) {
                    t._stopLoading(), t._failureCallback({
                        msg: "Failed to load call object bundle ".concat(e.target.src),
                        type: e.message
                    });
                }, r.src = e, n.appendChild(r);
            }
        },
        {
            key: "_stopLoading",
            value: function() {
                this._withdrawFromCallMachineLoadWaitlist(), clearTimeout(this._networkTimeout), this._scriptElement && (this._scriptElement.onload = null, this._scriptElement.onerror = null);
            }
        },
        {
            key: "_signUpForCallMachineLoadWaitlist",
            value: function() {
                window._dailyCallMachineLoadWaitlist.add(this._attemptId);
            }
        },
        {
            key: "_withdrawFromCallMachineLoadWaitlist",
            value: function() {
                window._dailyCallMachineLoadWaitlist.delete(this._attemptId);
            }
        }
    ]);
}(), Hs = function(e, t, n) {
    return !0 === Ks(e.local, t, n);
}, Gs = function(e, t, n) {
    return e.local.streams && e.local.streams[t] && e.local.streams[t].stream && e.local.streams[t].stream["get".concat("video" === n ? "Video" : "Audio", "Tracks")]()[0];
}, Qs = function(e, t, n, r) {
    var i = Ys(e, t, n, r);
    return i && i.pendingTrack;
}, Ks = function(e, t, n) {
    if (!e) return !1;
    var r = function(e) {
        switch(e){
            case "avatar":
                return !0;
            case "staged":
                return e;
            default:
                return !!e;
        }
    }, i = e.public.subscribedTracks;
    return i && i[t] ? -1 === [
        "cam-audio",
        "cam-video",
        "screen-video",
        "screen-audio",
        "rmpAudio",
        "rmpVideo"
    ].indexOf(n) && i[t].custom ? [
        !0,
        "staged"
    ].includes(i[t].custom) ? r(i[t].custom) : r(i[t].custom[n]) : r(i[t][n]) : !i || r(i.ALL);
}, Ys = function(e, t, n, r) {
    var i = Object.values(e.streams || {}).filter(function(e) {
        return e.participantId === t && e.type === n && e.pendingTrack && e.pendingTrack.kind === r;
    }).sort(function(e, t) {
        return new Date(t.starttime) - new Date(e.starttime);
    });
    return i && i[0];
}, Xs = function(e, t) {
    var n = e.local.public.customTracks;
    if (n && n[t]) return n[t].track;
};
function Zs(e, t) {
    for(var n = t.getState(), r = 0, i = [
        "cam",
        "screen"
    ]; r < i.length; r++)for(var o = i[r], s = 0, a = [
        "video",
        "audio"
    ]; s < a.length; s++){
        var c = a[s], l = "cam" === o ? c : "screen".concat(c.charAt(0).toUpperCase() + c.slice(1)), u = e.tracks[l];
        if (u) {
            var d = e.local ? Gs(n, o, c) : Qs(n, e.session_id, o, c);
            "playable" === u.state && (u.track = d), u.persistentTrack = d;
        }
    }
}
function ea(e, t) {
    try {
        var n = t.getState();
        for(var r in e.tracks)if (!ta(r)) {
            var i = e.tracks[r].kind;
            if (i) {
                var o = e.tracks[r];
                if (o) {
                    var s = e.local ? Xs(n, r) : Qs(n, e.session_id, r, i);
                    "playable" === o.state && (e.tracks[r].track = s), o.persistentTrack = s;
                }
            } else console.error("unknown type for custom track");
        }
    } catch (e) {
        console.error(e);
    }
}
function ta(e) {
    return [
        "video",
        "audio",
        "screenVideo",
        "screenAudio"
    ].includes(e);
}
function na(e, t, n) {
    var r = n.getState();
    if (e.local) {
        if (e.audio) try {
            e.audioTrack = r.local.streams.cam.stream.getAudioTracks()[0], e.audioTrack || (e.audio = !1);
        } catch (e) {}
        if (e.video) try {
            e.videoTrack = r.local.streams.cam.stream.getVideoTracks()[0], e.videoTrack || (e.video = !1);
        } catch (e) {}
        if (e.screen) try {
            e.screenVideoTrack = r.local.streams.screen.stream.getVideoTracks()[0], e.screenAudioTrack = r.local.streams.screen.stream.getAudioTracks()[0], e.screenVideoTrack || e.screenAudioTrack || (e.screen = !1);
        } catch (e) {}
    } else {
        var i = !0;
        try {
            var o = r.participants[e.session_id];
            o && o.public && o.public.rtcType && "peer-to-peer" === o.public.rtcType.impl && o.private && ![
                "connected",
                "completed"
            ].includes(o.private.peeringState) && (i = !1);
        } catch (e) {
            console.error(e);
        }
        if (!i) return e.audio = !1, e.audioTrack = !1, e.video = !1, e.videoTrack = !1, e.screen = !1, void (e.screenTrack = !1);
        try {
            r.streams;
            if (e.audio && Hs(r, e.session_id, "cam-audio")) {
                var s = Qs(r, e.session_id, "cam", "audio");
                s && (t && t.audioTrack && t.audioTrack.id === s.id ? e.audioTrack = s : s.muted || (e.audioTrack = s)), e.audioTrack || (e.audio = !1);
            }
            if (e.video && Hs(r, e.session_id, "cam-video")) {
                var a = Qs(r, e.session_id, "cam", "video");
                a && (t && t.videoTrack && t.videoTrack.id === a.id ? e.videoTrack = a : a.muted || (e.videoTrack = a)), e.videoTrack || (e.video = !1);
            }
            if (e.screen && Hs(r, e.session_id, "screen-audio")) {
                var c = Qs(r, e.session_id, "screen", "audio");
                c && (t && t.screenAudioTrack && t.screenAudioTrack.id === c.id ? e.screenAudioTrack = c : c.muted || (e.screenAudioTrack = c));
            }
            if (e.screen && Hs(r, e.session_id, "screen-video")) {
                var l = Qs(r, e.session_id, "screen", "video");
                l && (t && t.screenVideoTrack && t.screenVideoTrack.id === l.id ? e.screenVideoTrack = l : l.muted || (e.screenVideoTrack = l));
            }
            e.screenVideoTrack || e.screenAudioTrack || (e.screen = !1);
        } catch (e) {
            console.error("unexpected error matching up tracks", e);
        }
    }
}
function ra(e, t) {
    var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (!n) {
        if (Array.isArray(e) || (n = function(e, t) {
            if (e) {
                if ("string" == typeof e) return ia(e, t);
                var n = ({}).toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? ia(e, t) : void 0;
            }
        }(e)) || t && e && "number" == typeof e.length) {
            n && (e = n);
            var r = 0, i = function() {};
            return {
                s: i,
                n: function() {
                    return r >= e.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: e[r++]
                    };
                },
                e: function(e) {
                    throw e;
                },
                f: i
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var o, s = !0, a = !1;
    return {
        s: function() {
            n = n.call(e);
        },
        n: function() {
            var e = n.next();
            return s = e.done, e;
        },
        e: function(e) {
            a = !0, o = e;
        },
        f: function() {
            try {
                s || null == n.return || n.return();
            } finally{
                if (a) throw o;
            }
        }
    };
}
function ia(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for(var n = 0, r = Array(t); n < t; n++)r[n] = e[n];
    return r;
}
var oa = new Map, sa = null;
function aa(e, t) {
    var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (!n) {
        if (Array.isArray(e) || (n = function(e, t) {
            if (e) {
                if ("string" == typeof e) return ca(e, t);
                var n = ({}).toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? ca(e, t) : void 0;
            }
        }(e)) || t && e && "number" == typeof e.length) {
            n && (e = n);
            var r = 0, i = function() {};
            return {
                s: i,
                n: function() {
                    return r >= e.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: e[r++]
                    };
                },
                e: function(e) {
                    throw e;
                },
                f: i
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var o, s = !0, a = !1;
    return {
        s: function() {
            n = n.call(e);
        },
        n: function() {
            var e = n.next();
            return s = e.done, e;
        },
        e: function(e) {
            a = !0, o = e;
        },
        f: function() {
            try {
                s || null == n.return || n.return();
            } finally{
                if (a) throw o;
            }
        }
    };
}
function ca(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for(var n = 0, r = Array(t); n < t; n++)r[n] = e[n];
    return r;
}
var la = new Map, ua = null;
function da(e) {
    ha() ? function(e) {
        oa.has(e) || (oa.set(e, {}), navigator.mediaDevices.enumerateDevices().then(function(t) {
            oa.has(e) && (oa.get(e).lastDevicesString = JSON.stringify(t), sa || (sa = function() {
                var e = p(function*() {
                    var e, t = yield navigator.mediaDevices.enumerateDevices(), n = ra(oa.keys());
                    try {
                        for(n.s(); !(e = n.n()).done;){
                            var r = e.value, i = JSON.stringify(t);
                            i !== oa.get(r).lastDevicesString && (oa.get(r).lastDevicesString = i, r(t));
                        }
                    } catch (e) {
                        n.e(e);
                    } finally{
                        n.f();
                    }
                });
                return function() {
                    return e.apply(this, arguments);
                };
            }(), navigator.mediaDevices.addEventListener("devicechange", sa)));
        }).catch(function() {}));
    }(e) : function(e) {
        la.has(e) || (la.set(e, {}), navigator.mediaDevices.enumerateDevices().then(function(t) {
            la.has(e) && (la.get(e).lastDevicesString = JSON.stringify(t), ua || (ua = setInterval(p(function*() {
                var e, t = yield navigator.mediaDevices.enumerateDevices(), n = aa(la.keys());
                try {
                    for(n.s(); !(e = n.n()).done;){
                        var r = e.value, i = JSON.stringify(t);
                        i !== la.get(r).lastDevicesString && (la.get(r).lastDevicesString = i, r(t));
                    }
                } catch (e) {
                    n.e(e);
                } finally{
                    n.f();
                }
            }), 3e3)));
        }));
    }(e);
}
function pa(e) {
    ha() ? function(e) {
        oa.has(e) && (oa.delete(e), 0 === oa.size && sa && (navigator.mediaDevices.removeEventListener("devicechange", sa), sa = null));
    }(e) : function(e) {
        la.has(e) && (la.delete(e), 0 === la.size && ua && (clearInterval(ua), ua = null));
    }(e);
}
function ha() {
    var e;
    return is() || void 0 !== (null === (e = navigator.mediaDevices) || void 0 === e ? void 0 : e.ondevicechange);
}
var fa = new Set;
function va(e, t) {
    var n = t.isLocalScreenVideo;
    return e && "live" === e.readyState && !function(e, t) {
        return (!t.isLocalScreenVideo || "Chrome" !== ms()) && e.muted && !fa.has(e.id);
    }(e, {
        isLocalScreenVideo: n
    });
}
function ga(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}
function ma(e) {
    for(var t = 1; t < arguments.length; t++){
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? ga(Object(n), !0).forEach(function(t) {
            u(e, t, n[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ga(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
    }
    return e;
}
var ya = Object.freeze({
    VIDEO: "video",
    AUDIO: "audio",
    SCREEN_VIDEO: "screenVideo",
    SCREEN_AUDIO: "screenAudio",
    CUSTOM_VIDEO: "customVideo",
    CUSTOM_AUDIO: "customAudio"
}), ba = Object.freeze({
    PARTICIPANTS: "participants",
    STREAMING: "streaming",
    TRANSCRIPTION: "transcription"
}), _a = Object.values(ya), wa = [
    "v",
    "a",
    "sv",
    "sa",
    "cv",
    "ca"
];
Object.freeze(_a.reduce(function(e, t, n) {
    return e[t] = wa[n], e;
}, {})), Object.freeze(wa.reduce(function(e, t, n) {
    return e[t] = _a[n], e;
}, {}));
var Sa = [
    ya.VIDEO,
    ya.AUDIO,
    ya.SCREEN_VIDEO,
    ya.SCREEN_AUDIO
], ka = Object.values(ba), Ma = [
    "p",
    "s",
    "t"
];
Object.freeze(ka.reduce(function(e, t, n) {
    return e[t] = Ma[n], e;
}, {})), Object.freeze(Ma.reduce(function(e, t, n) {
    return e[t] = ka[n], e;
}, {}));
var Ca = function() {
    function e() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = n.base, i = n.byUserId, o = n.byParticipantId;
        t(this, e), this.base = r, this.byUserId = i, this.byParticipantId = o;
    }
    return o(e, [
        {
            key: "clone",
            value: function() {
                var t = new e;
                if (this.base instanceof Ea ? t.base = this.base.clone() : t.base = this.base, void 0 !== this.byUserId) for(var n in t.byUserId = {}, this.byUserId){
                    var r = this.byUserId[n];
                    t.byUserId[n] = r instanceof Ea ? r.clone() : r;
                }
                if (void 0 !== this.byParticipantId) for(var i in t.byParticipantId = {}, this.byParticipantId){
                    var o = this.byParticipantId[i];
                    t.byParticipantId[i] = o instanceof Ea ? o.clone() : o;
                }
                return t;
            }
        },
        {
            key: "toJSONObject",
            value: function() {
                var e = {};
                if ("boolean" == typeof this.base ? e.base = this.base : this.base instanceof Ea && (e.base = this.base.toJSONObject()), void 0 !== this.byUserId) for(var t in e.byUserId = {}, this.byUserId){
                    var n = this.byUserId[t];
                    e.byUserId[t] = n instanceof Ea ? n.toJSONObject() : n;
                }
                if (void 0 !== this.byParticipantId) for(var r in e.byParticipantId = {}, this.byParticipantId){
                    var i = this.byParticipantId[r];
                    e.byParticipantId[r] = i instanceof Ea ? i.toJSONObject() : i;
                }
                return e;
            }
        },
        {
            key: "toMinifiedJSONObject",
            value: function() {
                var e = {};
                if (void 0 !== this.base && ("boolean" == typeof this.base ? e.b = this.base : e.b = this.base.toMinifiedJSONObject()), void 0 !== this.byUserId) for(var t in e.u = {}, this.byUserId){
                    var n = this.byUserId[t];
                    e.u[t] = "boolean" == typeof n ? n : n.toMinifiedJSONObject();
                }
                if (void 0 !== this.byParticipantId) for(var r in e.p = {}, this.byParticipantId){
                    var i = this.byParticipantId[r];
                    e.p[r] = "boolean" == typeof i ? i : i.toMinifiedJSONObject();
                }
                return e;
            }
        },
        {
            key: "normalize",
            value: function() {
                return this.base instanceof Ea && (this.base = this.base.normalize()), this.byUserId && (this.byUserId = Object.fromEntries(Object.entries(this.byUserId).map(function(e) {
                    var t = f(e, 2), n = t[0], r = t[1];
                    return [
                        n,
                        r instanceof Ea ? r.normalize() : r
                    ];
                }))), this.byParticipantId && (this.byParticipantId = Object.fromEntries(Object.entries(this.byParticipantId).map(function(e) {
                    var t = f(e, 2), n = t[0], r = t[1];
                    return [
                        n,
                        r instanceof Ea ? r.normalize() : r
                    ];
                }))), this;
            }
        }
    ], [
        {
            key: "fromJSONObject",
            value: function(t) {
                var n, r, i;
                if (void 0 !== t.base && (n = "boolean" == typeof t.base ? t.base : Ea.fromJSONObject(t.base)), void 0 !== t.byUserId) for(var o in r = {}, t.byUserId){
                    var s = t.byUserId[o];
                    r[o] = "boolean" == typeof s ? s : Ea.fromJSONObject(s);
                }
                if (void 0 !== t.byParticipantId) for(var a in i = {}, t.byParticipantId){
                    var c = t.byParticipantId[a];
                    i[a] = "boolean" == typeof c ? c : Ea.fromJSONObject(c);
                }
                return new e({
                    base: n,
                    byUserId: r,
                    byParticipantId: i
                });
            }
        },
        {
            key: "fromMinifiedJSONObject",
            value: function(t) {
                var n, r, i;
                if (void 0 !== t.b && (n = "boolean" == typeof t.b ? t.b : Ea.fromMinifiedJSONObject(t.b)), void 0 !== t.u) for(var o in r = {}, t.u){
                    var s = t.u[o];
                    r[o] = "boolean" == typeof s ? s : Ea.fromMinifiedJSONObject(s);
                }
                if (void 0 !== t.p) for(var a in i = {}, t.p){
                    var c = t.p[a];
                    i[a] = "boolean" == typeof c ? c : Ea.fromMinifiedJSONObject(c);
                }
                return new e({
                    base: n,
                    byUserId: r,
                    byParticipantId: i
                });
            }
        },
        {
            key: "validateJSONObject",
            value: function(e) {
                if ("object" !== n(e)) return [
                    !1,
                    "canReceive must be an object"
                ];
                for(var t = [
                    "base",
                    "byUserId",
                    "byParticipantId"
                ], r = 0, i = Object.keys(e); r < i.length; r++){
                    var o = i[r];
                    if (!t.includes(o)) return [
                        !1,
                        "canReceive can only contain keys (".concat(t.join(", "), ")")
                    ];
                    if ("base" === o) {
                        var s = f(Ea.validateJSONObject(e.base, !0), 2), a = s[0], c = s[1];
                        if (!a) return [
                            !1,
                            c
                        ];
                    } else {
                        if ("object" !== n(e[o])) return [
                            !1,
                            "invalid (non-object) value for field '".concat(o, "' in canReceive")
                        ];
                        for(var l = 0, u = Object.values(e[o]); l < u.length; l++){
                            var d = u[l], p = f(Ea.validateJSONObject(d), 2), h = p[0], v = p[1];
                            if (!h) return [
                                !1,
                                v
                            ];
                        }
                    }
                }
                return [
                    !0
                ];
            }
        }
    ]);
}(), Ea = function() {
    function e() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = n.video, i = n.audio, o = n.screenVideo, s = n.screenAudio, a = n.customVideo, c = n.customAudio;
        t(this, e), this.video = r, this.audio = i, this.screenVideo = o, this.screenAudio = s, this.customVideo = a, this.customAudio = c;
    }
    return o(e, [
        {
            key: "clone",
            value: function() {
                var t = new e;
                return void 0 !== this.video && (t.video = this.video), void 0 !== this.audio && (t.audio = this.audio), void 0 !== this.screenVideo && (t.screenVideo = this.screenVideo), void 0 !== this.screenAudio && (t.screenAudio = this.screenAudio), void 0 !== this.customVideo && (t.customVideo = ma({}, this.customVideo)), void 0 !== this.customAudio && (t.customAudio = ma({}, this.customAudio)), t;
            }
        },
        {
            key: "toJSONObject",
            value: function() {
                var e = {};
                return void 0 !== this.video && (e.video = this.video), void 0 !== this.audio && (e.audio = this.audio), void 0 !== this.screenVideo && (e.screenVideo = this.screenVideo), void 0 !== this.screenAudio && (e.screenAudio = this.screenAudio), void 0 !== this.customVideo && (e.customVideo = ma({}, this.customVideo)), void 0 !== this.customAudio && (e.customAudio = ma({}, this.customAudio)), e;
            }
        },
        {
            key: "toMinifiedJSONObject",
            value: function() {
                var e = {};
                return void 0 !== this.video && (e.v = this.video), void 0 !== this.audio && (e.a = this.audio), void 0 !== this.screenVideo && (e.sv = this.screenVideo), void 0 !== this.screenAudio && (e.sa = this.screenAudio), void 0 !== this.customVideo && (e.cv = ma({}, this.customVideo)), void 0 !== this.customAudio && (e.ca = ma({}, this.customAudio)), e;
            }
        },
        {
            key: "normalize",
            value: function() {
                function e(e, t) {
                    return e && 1 === Object.keys(e).length && e["*"] === t;
                }
                return !(!0 !== this.video || !0 !== this.audio || !0 !== this.screenVideo || !0 !== this.screenAudio || !e(this.customVideo, !0) || !e(this.customAudio, !0)) || (!1 !== this.video || !1 !== this.audio || !1 !== this.screenVideo || !1 !== this.screenAudio || !e(this.customVideo, !1) || !e(this.customAudio, !1)) && this;
            }
        }
    ], [
        {
            key: "fromBoolean",
            value: function(t) {
                return new e({
                    video: t,
                    audio: t,
                    screenVideo: t,
                    screenAudio: t,
                    customVideo: {
                        "*": t
                    },
                    customAudio: {
                        "*": t
                    }
                });
            }
        },
        {
            key: "fromJSONObject",
            value: function(t) {
                return new e({
                    video: t.video,
                    audio: t.audio,
                    screenVideo: t.screenVideo,
                    screenAudio: t.screenAudio,
                    customVideo: void 0 !== t.customVideo ? ma({}, t.customVideo) : void 0,
                    customAudio: void 0 !== t.customAudio ? ma({}, t.customAudio) : void 0
                });
            }
        },
        {
            key: "fromMinifiedJSONObject",
            value: function(t) {
                return new e({
                    video: t.v,
                    audio: t.a,
                    screenVideo: t.sv,
                    screenAudio: t.sa,
                    customVideo: t.cv,
                    customAudio: t.ca
                });
            }
        },
        {
            key: "validateJSONObject",
            value: function(e, t) {
                if ("boolean" == typeof e) return [
                    !0
                ];
                if ("object" !== n(e)) return [
                    !1,
                    "invalid (non-object, non-boolean) value in canReceive"
                ];
                for(var r = Object.keys(e), i = 0, o = r; i < o.length; i++){
                    var s = o[i];
                    if (!_a.includes(s)) return [
                        !1,
                        "invalid media type '".concat(s, "' in canReceive")
                    ];
                    if (Sa.includes(s)) {
                        if ("boolean" != typeof e[s]) return [
                            !1,
                            "invalid (non-boolean) value for media type '".concat(s, "' in canReceive")
                        ];
                    } else {
                        if ("object" !== n(e[s])) return [
                            !1,
                            "invalid (non-object) value for media type '".concat(s, "' in canReceive")
                        ];
                        for(var a = 0, c = Object.values(e[s]); a < c.length; a++){
                            if ("boolean" != typeof c[a]) return [
                                !1,
                                "invalid (non-boolean) value for entry within '".concat(s, "' in canReceive")
                            ];
                        }
                        if (t && void 0 === e[s]["*"]) return [
                            !1,
                            'canReceive "base" permission must specify "*" as an entry within \''.concat(s, "'")
                        ];
                    }
                }
                return t && r.length !== _a.length ? [
                    !1,
                    'canReceive "base" permission must specify all media types: '.concat(_a.join(", "), " (or be set to a boolean shorthand)")
                ] : [
                    !0
                ];
            }
        }
    ]);
}(), Ta = [
    "result"
], Oa = [
    "preserveIframe"
];
function Pa(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}
function Aa(e) {
    for(var t = 1; t < arguments.length; t++){
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? Pa(Object(n), !0).forEach(function(t) {
            u(e, t, n[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Pa(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
    }
    return e;
}
function ja() {
    try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (e) {}
    return (ja = function() {
        return !!e;
    })();
}
function Ia(e, t) {
    var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (!n) {
        if (Array.isArray(e) || (n = function(e, t) {
            if (e) {
                if ("string" == typeof e) return xa(e, t);
                var n = ({}).toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? xa(e, t) : void 0;
            }
        }(e)) || t && e && "number" == typeof e.length) {
            n && (e = n);
            var r = 0, i = function() {};
            return {
                s: i,
                n: function() {
                    return r >= e.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: e[r++]
                    };
                },
                e: function(e) {
                    throw e;
                },
                f: i
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var o, s = !0, a = !1;
    return {
        s: function() {
            n = n.call(e);
        },
        n: function() {
            var e = n.next();
            return s = e.done, e;
        },
        e: function(e) {
            a = !0, o = e;
        },
        f: function() {
            try {
                s || null == n.return || n.return();
            } finally{
                if (a) throw o;
            }
        }
    };
}
function xa(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for(var n = 0, r = Array(t); n < t; n++)r[n] = e[n];
    return r;
}
var La = {};
var Da = "video", Na = "voice", Ra = is() ? {
    data: {}
} : {
    data: {},
    topology: "none"
}, Fa = {
    present: 0,
    hidden: 0
}, Ba = {
    maxBitrate: {
        min: 1e5,
        max: 25e5
    },
    maxFramerate: {
        min: 1,
        max: 30
    },
    scaleResolutionDownBy: {
        min: 1,
        max: 8
    }
}, Ua = Object.keys(Ba), Va = [
    "state",
    "volume",
    "simulcastEncodings"
], Ja = {
    androidInCallNotification: {
        title: "string",
        subtitle: "string",
        iconName: "string",
        disableForCustomOverride: "boolean"
    },
    disableAutoDeviceManagement: {
        audio: "boolean",
        video: "boolean"
    }
}, $a = {
    id: {
        iconPath: "string",
        iconPathDarkMode: "string",
        label: "string",
        tooltip: "string",
        visualState: "'default' | 'sidebar-open' | 'active'"
    }
}, qa = {
    id: {
        allow: "string",
        controlledBy: "'*' | 'owners' | string[]",
        csp: "string",
        iconURL: "string",
        label: "string",
        loading: "'eager' | 'lazy'",
        location: "'main' | 'sidebar'",
        name: "string",
        referrerPolicy: "string",
        sandbox: "string",
        src: "string",
        srcdoc: "string",
        shared: "string[] | 'owners' | boolean"
    }
}, za = {
    customIntegrations: {
        validate: gc,
        help: fc()
    },
    customTrayButtons: {
        validate: vc,
        help: "customTrayButtons should be a dictionary of the type ".concat(JSON.stringify($a))
    },
    url: {
        validate: function(e) {
            return "string" == typeof e;
        },
        help: "url should be a string"
    },
    baseUrl: {
        validate: function(e) {
            return "string" == typeof e;
        },
        help: "baseUrl should be a string"
    },
    token: {
        validate: function(e) {
            return "string" == typeof e;
        },
        help: "token should be a string",
        queryString: "t"
    },
    dailyConfig: {
        validate: function(e, t) {
            try {
                return t.validateDailyConfig(e), !0;
            } catch (e) {
                console.error("Failed to validate dailyConfig", e);
            }
            return !1;
        },
        help: "Unsupported dailyConfig. Check error logs for detailed info."
    },
    reactNativeConfig: {
        validate: function(e) {
            return mc(e, Ja);
        },
        help: "reactNativeConfig should look like ".concat(JSON.stringify(Ja), ", all fields optional")
    },
    lang: {
        validate: function(e) {
            return [
                "da",
                "de",
                "en-us",
                "en",
                "es",
                "fi",
                "fr",
                "it",
                "jp",
                "ka",
                "nl",
                "no",
                "pl",
                "pt",
                "pt-BR",
                "ru",
                "sv",
                "tr",
                "user"
            ].includes(e);
        },
        help: "language not supported. Options are: da, de, en-us, en, es, fi, fr, it, jp, ka, nl, no, pl, pt, pt-BR, ru, sv, tr, user"
    },
    userName: !0,
    userData: {
        validate: function(e) {
            try {
                return oc(e), !0;
            } catch (e) {
                return console.error(e), !1;
            }
        },
        help: "invalid userData type provided"
    },
    startVideoOff: !0,
    startAudioOff: !0,
    allowLocalVideo: !0,
    allowLocalAudio: !0,
    activeSpeakerMode: !0,
    showLeaveButton: !0,
    showLocalVideo: !0,
    showParticipantsBar: !0,
    showFullscreenButton: !0,
    showUserNameChangeUI: !0,
    iframeStyle: !0,
    customLayout: !0,
    cssFile: !0,
    cssText: !0,
    bodyClass: !0,
    videoSource: {
        validate: function(e, t) {
            if ("boolean" == typeof e) return t._preloadCache.allowLocalVideo = e, !0;
            var n;
            if (e instanceof MediaStreamTrack) t._sharedTracks.videoTrack = e, n = {
                customTrack: Qo
            };
            else {
                if (delete t._sharedTracks.videoTrack, "string" != typeof e) return console.error("videoSource must be a MediaStreamTrack, boolean, or a string"), !1;
                n = {
                    deviceId: e
                };
            }
            return t._updatePreloadCacheInputSettings({
                video: {
                    settings: n
                }
            }, !1), !0;
        }
    },
    audioSource: {
        validate: function(e, t) {
            if ("boolean" == typeof e) return t._preloadCache.allowLocalAudio = e, !0;
            var n;
            if (e instanceof MediaStreamTrack) t._sharedTracks.audioTrack = e, n = {
                customTrack: Qo
            };
            else {
                if (delete t._sharedTracks.audioTrack, "string" != typeof e) return console.error("audioSource must be a MediaStreamTrack, boolean, or a string"), !1;
                n = {
                    deviceId: e
                };
            }
            return t._updatePreloadCacheInputSettings({
                audio: {
                    settings: n
                }
            }, !1), !0;
        }
    },
    subscribeToTracksAutomatically: {
        validate: function(e, t) {
            return t._preloadCache.subscribeToTracksAutomatically = e, !0;
        }
    },
    theme: {
        validate: function(e) {
            var t = [
                "accent",
                "accentText",
                "background",
                "backgroundAccent",
                "baseText",
                "border",
                "mainAreaBg",
                "mainAreaBgAccent",
                "mainAreaText",
                "supportiveText"
            ], r = function(e) {
                for(var n = 0, r = Object.keys(e); n < r.length; n++){
                    var i = r[n];
                    if (!t.includes(i)) return console.error('unsupported color "'.concat(i, '". Valid colors: ').concat(t.join(", "))), !1;
                    if (!e[i].match(/^#[0-9a-f]{6}|#[0-9a-f]{3}$/i)) return console.error("".concat(i, ' theme color should be provided in valid hex color format. Received: "').concat(e[i], '"')), !1;
                }
                return !0;
            };
            return "object" === n(e) && ("light" in e && "dark" in e || "colors" in e) ? "light" in e && "dark" in e ? "colors" in e.light ? "colors" in e.dark ? r(e.light.colors) && r(e.dark.colors) : (console.error('Dark theme is missing "colors" property.', e), !1) : (console.error('Light theme is missing "colors" property.', e), !1) : r(e.colors) : (console.error('Theme must contain either both "light" and "dark" properties, or "colors".', e), !1);
        },
        help: "unsupported theme configuration. Check error logs for detailed info."
    },
    layoutConfig: {
        validate: function(e) {
            if ("grid" in e) {
                var t = e.grid;
                if ("maxTilesPerPage" in t) {
                    if (!Number.isInteger(t.maxTilesPerPage)) return console.error("grid.maxTilesPerPage should be an integer. You passed ".concat(t.maxTilesPerPage, ".")), !1;
                    if (t.maxTilesPerPage > 49) return console.error("grid.maxTilesPerPage can't be larger than 49 without sacrificing browser performance. Please contact us at https://www.daily.co/contact to talk about your use case."), !1;
                }
                if ("minTilesPerPage" in t) {
                    if (!Number.isInteger(t.minTilesPerPage)) return console.error("grid.minTilesPerPage should be an integer. You passed ".concat(t.minTilesPerPage, ".")), !1;
                    if (t.minTilesPerPage < 1) return console.error("grid.minTilesPerPage can't be lower than 1."), !1;
                    if ("maxTilesPerPage" in t && t.minTilesPerPage > t.maxTilesPerPage) return console.error("grid.minTilesPerPage can't be higher than grid.maxTilesPerPage."), !1;
                }
            }
            return !0;
        },
        help: "unsupported layoutConfig. Check error logs for detailed info."
    },
    receiveSettings: {
        validate: function(e) {
            return sc(e, {
                allowAllParticipantsKey: !1
            });
        },
        help: hc({
            allowAllParticipantsKey: !1
        })
    },
    sendSettings: {
        validate: function(e, t) {
            return !!function(e, t) {
                try {
                    return t.validateUpdateSendSettings(e), !0;
                } catch (e) {
                    return console.error("Failed to validate send settings", e), !1;
                }
            }(e, t) && (t._preloadCache.sendSettings = e, !0);
        },
        help: "Invalid sendSettings provided. Check error logs for detailed info."
    },
    inputSettings: {
        validate: function(e, t) {
            var n;
            return !!ac(e) && (t._inputSettings || (t._inputSettings = {}), cc(e, null === (n = t.properties) || void 0 === n ? void 0 : n.dailyConfig, t._sharedTracks), t._updatePreloadCacheInputSettings(e, !0), !0);
        },
        help: pc()
    },
    layout: {
        validate: function(e) {
            return "custom-v1" === e || "browser" === e || "none" === e;
        },
        help: 'layout may only be set to "custom-v1"',
        queryString: "layout"
    },
    emb: {
        queryString: "emb"
    },
    embHref: {
        queryString: "embHref"
    },
    dailyJsVersion: {
        queryString: "dailyJsVersion"
    },
    proxy: {
        queryString: "proxy"
    },
    strictMode: !0,
    allowMultipleCallInstances: !0
}, Wa = {
    styles: {
        validate: function(e) {
            for(var t in e)if ("cam" !== t && "screen" !== t) return !1;
            if (e.cam) {
                for(var n in e.cam)if ("div" !== n && "video" !== n) return !1;
            }
            if (e.screen) {
                for(var r in e.screen)if ("div" !== r && "video" !== r) return !1;
            }
            return !0;
        },
        help: "styles format should be a subset of: { cam: {div: {}, video: {}}, screen: {div: {}, video: {}} }"
    },
    setSubscribedTracks: {
        validate: function(e, t) {
            if (t._preloadCache.subscribeToTracksAutomatically) return !1;
            var n = [
                !0,
                !1,
                "staged"
            ];
            if (n.includes(e) || !is() && "avatar" === e) return !0;
            var r = [
                "audio",
                "video",
                "screenAudio",
                "screenVideo",
                "rmpAudio",
                "rmpVideo"
            ], i = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                for(var o in e)if ("custom" === o) {
                    if (!n.includes(e[o]) && !i(e[o], !0)) return !1;
                } else {
                    var s = !t && !r.includes(o), a = !n.includes(e[o]);
                    if (s || a) return !1;
                }
                return !0;
            };
            return i(e);
        },
        help: "setSubscribedTracks cannot be used when setSubscribeToTracksAutomatically is enabled, and should be of the form: " + "true".concat(is() ? "" : " | 'avatar'", " | false | 'staged' | { [audio: true|false|'staged'], [video: true|false|'staged'], [screenAudio: true|false|'staged'], [screenVideo: true|false|'staged'] }")
    },
    setAudio: !0,
    setVideo: !0,
    setScreenShare: {
        validate: function(e) {
            return !1 === e;
        },
        help: "setScreenShare must be false, as it's only meant for stopping remote participants' screen shares"
    },
    eject: !0,
    updatePermissions: {
        validate: function(e) {
            for(var t = 0, n = Object.entries(e); t < n.length; t++){
                var r = f(n[t], 2), i = r[0], o = r[1];
                switch(i){
                    case "hasPresence":
                        if ("boolean" != typeof o) return !1;
                        break;
                    case "canSend":
                        if (o instanceof Set || o instanceof Array || Array.isArray(o)) {
                            var s, a = [
                                "video",
                                "audio",
                                "screenVideo",
                                "screenAudio",
                                "customVideo",
                                "customAudio"
                            ], c = Ia(o);
                            try {
                                for(c.s(); !(s = c.n()).done;){
                                    var l = s.value;
                                    if (!a.includes(l)) return !1;
                                }
                            } catch (e) {
                                c.e(e);
                            } finally{
                                c.f();
                            }
                        } else if ("boolean" != typeof o) return !1;
                        (o instanceof Array || Array.isArray(o)) && (e.canSend = new Set(o));
                        break;
                    case "canReceive":
                        var u = f(Ca.validateJSONObject(o), 2), d = u[0], p = u[1];
                        if (!d) return console.error(p), !1;
                        break;
                    case "canAdmin":
                        if (o instanceof Set || o instanceof Array || Array.isArray(o)) {
                            var h, v = [
                                "participants",
                                "streaming",
                                "transcription"
                            ], g = Ia(o);
                            try {
                                for(g.s(); !(h = g.n()).done;){
                                    var m = h.value;
                                    if (!v.includes(m)) return !1;
                                }
                            } catch (e) {
                                g.e(e);
                            } finally{
                                g.f();
                            }
                        } else if ("boolean" != typeof o) return !1;
                        (o instanceof Array || Array.isArray(o)) && (e.canAdmin = new Set(o));
                        break;
                    default:
                        return !1;
                }
            }
            return !0;
        },
        help: "updatePermissions can take hasPresence, canSend, canReceive, and canAdmin permissions. hasPresence must be a boolean. canSend can be a boolean or an Array or Set of media types (video, audio, screenVideo, screenAudio, customVideo, customAudio). canReceive must be an object specifying base, byUserId, and/or byParticipantId fields (see documentation for more details). canAdmin can be a boolean or an Array or Set of admin types (participants, streaming, transcription)."
    }
};
Promise.any || (Promise.any = function() {
    var e = p(function*(e) {
        return new Promise(function(t, n) {
            var r = [];
            e.forEach(function(i) {
                return Promise.resolve(i).then(function(e) {
                    t(e);
                }).catch(function(t) {
                    r.push(t), r.length === e.length && n(r);
                });
            });
        });
    });
    return function(t) {
        return e.apply(this, arguments);
    };
}());
var Ha = function() {
    function r(e) {
        var n, i, o, c, l, d, h = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (t(this, r), o = this, c = a(c = r), u(i = s(o, ja() ? Reflect.construct(c, l || [], a(o).constructor) : c.apply(o, l)), "startListeningForDeviceChanges", function() {
            da(i.handleDeviceChange);
        }), u(i, "stopListeningForDeviceChanges", function() {
            pa(i.handleDeviceChange);
        }), u(i, "handleDeviceChange", function(e) {
            e = e.map(function(e) {
                return JSON.parse(JSON.stringify(e));
            }), i.emitDailyJSEvent({
                action: "available-devices-updated",
                availableDevices: e
            });
        }), u(i, "handleNativeAppStateChange", function() {
            var e = p(function*(e) {
                if ("destroyed" === e) return console.warn("App has been destroyed before leaving the meeting. Cleaning up all the resources!"), void (yield i.destroy());
                var t = "active" === e;
                i.disableReactNativeAutoDeviceManagement("video") || (t ? i.camUnmutedBeforeLosingNativeActiveState && i.setLocalVideo(!0) : (i.camUnmutedBeforeLosingNativeActiveState = i.localVideo(), i.camUnmutedBeforeLosingNativeActiveState && i.setLocalVideo(!1)));
            });
            return function(t) {
                return e.apply(this, arguments);
            };
        }()), u(i, "handleNativeAudioFocusChange", function(e) {
            i.disableReactNativeAutoDeviceManagement("audio") || (i._hasNativeAudioFocus = e, i.toggleParticipantAudioBasedOnNativeAudioFocus(), i._hasNativeAudioFocus ? i.micUnmutedBeforeLosingNativeAudioFocus && i.setLocalAudio(!0) : (i.micUnmutedBeforeLosingNativeAudioFocus = i.localAudio(), i.setLocalAudio(!1)));
        }), u(i, "handleNativeSystemScreenCaptureStop", function() {
            i.stopScreenShare();
        }), !fs() && !is()) throw new Error("WebRTC not supported or suppressed");
        if (i.strictMode = void 0 === h.strictMode || h.strictMode, i.allowMultipleCallInstances = null !== (n = h.allowMultipleCallInstances) && void 0 !== n && n, Object.keys(La).length && (i._logDuplicateInstanceAttempt(), !i.allowMultipleCallInstances)) {
            if (i.strictMode) throw new Error("Duplicate DailyIframe instances are not allowed");
            console.warn("Using strictMode: false to allow multiple call instances is now deprecated. Set `allowMultipleCallInstances: true`");
        }
        if (window._daily || (window._daily = {
            pendings: [],
            instances: {}
        }), i.callClientId = N(), La[(d = i).callClientId] = d, window._daily.instances[i.callClientId] = {}, i._sharedTracks = {}, window._daily.instances[i.callClientId].tracks = i._sharedTracks, h.dailyJsVersion = r.version(), i._iframe = e, i._callObjectMode = "none" === h.layout && !i._iframe, i._preloadCache = {
            subscribeToTracksAutomatically: !0,
            outputDeviceId: null,
            inputSettings: null,
            sendSettings: null,
            videoTrackForNetworkConnectivityTest: null,
            videoTrackForConnectionQualityTest: null
        }, void 0 !== h.showLocalVideo ? i._callObjectMode ? console.error("showLocalVideo is not available in call object mode") : i._showLocalVideo = !!h.showLocalVideo : i._showLocalVideo = !0, void 0 !== h.showParticipantsBar ? i._callObjectMode ? console.error("showParticipantsBar is not available in call object mode") : i._showParticipantsBar = !!h.showParticipantsBar : i._showParticipantsBar = !0, void 0 !== h.customIntegrations ? i._callObjectMode ? console.error("customIntegrations is not available in call object mode") : i._customIntegrations = h.customIntegrations : i._customIntegrations = {}, void 0 !== h.customTrayButtons ? i._callObjectMode ? console.error("customTrayButtons is not available in call object mode") : i._customTrayButtons = h.customTrayButtons : i._customTrayButtons = {}, void 0 !== h.activeSpeakerMode ? i._callObjectMode ? console.error("activeSpeakerMode is not available in call object mode") : i._activeSpeakerMode = !!h.activeSpeakerMode : i._activeSpeakerMode = !1, h.receiveSettings ? i._callObjectMode ? i._receiveSettings = h.receiveSettings : console.error("receiveSettings is only available in call object mode") : i._receiveSettings = {}, i.validateProperties(h), i.properties = Aa({}, h), i._inputSettings || (i._inputSettings = {}), i._callObjectLoader = i._callObjectMode ? new Us(i.callClientId) : null, i._callState = ti, i._isPreparingToJoin = !1, i._accessState = {
            access: fi
        }, i._meetingSessionSummary = {}, i._finalSummaryOfPrevSession = {}, i._meetingSessionState = wc(Ra, i._callObjectMode), i._nativeInCallAudioMode = Da, i._participants = {}, i._isScreenSharing = !1, i._participantCounts = Fa, i._rmpPlayerState = {}, i._waitingParticipants = {}, i._network = {
            threshold: "good",
            quality: 100,
            networkState: "unknown",
            stats: {}
        }, i._activeSpeaker = {}, i._localAudioLevel = 0, i._isLocalAudioLevelObserverRunning = !1, i._remoteParticipantsAudioLevel = {}, i._isRemoteParticipantsAudioLevelObserverRunning = !1, i._maxAppMessageSize = $o, i._messageChannel = is() ? new js : new Os, i._iframe && (i._iframe.requestFullscreen ? i._iframe.addEventListener("fullscreenchange", function() {
            document.fullscreenElement === i._iframe ? (i.emitDailyJSEvent({
                action: Io
            }), i.sendMessageToCallMachine({
                action: Io
            })) : (i.emitDailyJSEvent({
                action: xo
            }), i.sendMessageToCallMachine({
                action: xo
            }));
        }) : i._iframe.webkitRequestFullscreen && i._iframe.addEventListener("webkitfullscreenchange", function() {
            document.webkitFullscreenElement === i._iframe ? (i.emitDailyJSEvent({
                action: Io
            }), i.sendMessageToCallMachine({
                action: Io
            })) : (i.emitDailyJSEvent({
                action: xo
            }), i.sendMessageToCallMachine({
                action: xo
            }));
        })), is()) {
            var f = i.nativeUtils();
            f.addAudioFocusChangeListener && f.removeAudioFocusChangeListener && f.addAppStateChangeListener && f.removeAppStateChangeListener && f.addSystemScreenCaptureStopListener && f.removeSystemScreenCaptureStopListener || console.warn("expected (add|remove)(AudioFocusChange|AppActiveStateChange|SystemScreenCaptureStop)Listener to be available in React Native"), i._hasNativeAudioFocus = !0, f.addAudioFocusChangeListener(i.handleNativeAudioFocusChange), f.addAppStateChangeListener(i.handleNativeAppStateChange), f.addSystemScreenCaptureStopListener(i.handleNativeSystemScreenCaptureStop);
        }
        return i._callObjectMode && i.startListeningForDeviceChanges(), i._messageChannel.addListenerForMessagesFromCallMachine(i.handleMessageFromCallMachine, i.callClientId, i), i;
    }
    return l(r, b), o(r, [
        {
            key: "destroy",
            value: (ee = p(function*() {
                var e;
                try {
                    yield this.leave();
                } catch (e) {}
                var t = this._iframe;
                if (t) {
                    var n = t.parentElement;
                    n && n.removeChild(t);
                }
                if (this._messageChannel.removeListener(this.handleMessageFromCallMachine), is()) {
                    var r = this.nativeUtils();
                    r.removeAudioFocusChangeListener(this.handleNativeAudioFocusChange), r.removeAppStateChangeListener(this.handleNativeAppStateChange), r.removeSystemScreenCaptureStopListener(this.handleNativeSystemScreenCaptureStop);
                }
                this._callObjectMode && this.stopListeningForDeviceChanges(), this.resetMeetingDependentVars(), this._destroyed = !0, this.emitDailyJSEvent({
                    action: "call-instance-destroyed"
                }), delete La[this.callClientId], (null === (e = window) || void 0 === e || null === (e = e._daily) || void 0 === e ? void 0 : e.instances) && delete window._daily.instances[this.callClientId], this.strictMode && (this.callClientId = void 0);
            }), function() {
                return ee.apply(this, arguments);
            })
        },
        {
            key: "isDestroyed",
            value: function() {
                return !!this._destroyed;
            }
        },
        {
            key: "loadCss",
            value: function(e) {
                var t = e.bodyClass, n = e.cssFile, r = e.cssText;
                return rc(), this.sendMessageToCallMachine({
                    action: "load-css",
                    cssFile: this.absoluteUrl(n),
                    bodyClass: t,
                    cssText: r
                }), this;
            }
        },
        {
            key: "iframe",
            value: function() {
                return rc(), this._iframe;
            }
        },
        {
            key: "meetingState",
            value: function() {
                return this._callState;
            }
        },
        {
            key: "accessState",
            value: function() {
                return tc(this._callObjectMode, "accessState()"), this._accessState;
            }
        },
        {
            key: "participants",
            value: function() {
                return this._participants;
            }
        },
        {
            key: "participantCounts",
            value: function() {
                return this._participantCounts;
            }
        },
        {
            key: "waitingParticipants",
            value: function() {
                return tc(this._callObjectMode, "waitingParticipants()"), this._waitingParticipants;
            }
        },
        {
            key: "validateParticipantProperties",
            value: function(e, t) {
                for(var n in t){
                    if (!Wa[n]) throw new Error("unrecognized updateParticipant property ".concat(n));
                    if (Wa[n].validate && !Wa[n].validate(t[n], this, this._participants[e])) throw new Error(Wa[n].help);
                }
            }
        },
        {
            key: "updateParticipant",
            value: function(e, t) {
                return this._participants.local && this._participants.local.session_id === e && (e = "local"), e && t && (this.validateParticipantProperties(e, t), this.sendMessageToCallMachine({
                    action: "update-participant",
                    id: e,
                    properties: t
                })), this;
            }
        },
        {
            key: "updateParticipants",
            value: function(e) {
                var t = this._participants.local && this._participants.local.session_id;
                for(var n in e)n === t && (n = "local"), n && e[n] && this.validateParticipantProperties(n, e[n]);
                return this.sendMessageToCallMachine({
                    action: "update-participants",
                    participants: e
                }), this;
            }
        },
        {
            key: "updateWaitingParticipant",
            value: (Z = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (tc(this._callObjectMode, "updateWaitingParticipant()"), Ka(this._callState, "updateWaitingParticipant()"), "string" != typeof t || "object" !== n(r)) throw new Error("updateWaitingParticipant() must take an id string and a updates object");
                return new Promise(function(n, i) {
                    e.sendMessageToCallMachine({
                        action: "daily-method-update-waiting-participant",
                        id: t,
                        updates: r
                    }, function(e) {
                        e.error && i(e.error), e.id || i(new Error("unknown error in updateWaitingParticipant()")), n({
                            id: e.id
                        });
                    });
                });
            }), function() {
                return Z.apply(this, arguments);
            })
        },
        {
            key: "updateWaitingParticipants",
            value: (X = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (tc(this._callObjectMode, "updateWaitingParticipants()"), Ka(this._callState, "updateWaitingParticipants()"), "object" !== n(t)) throw new Error("updateWaitingParticipants() must take a mapping between ids and update objects");
                return new Promise(function(n, r) {
                    e.sendMessageToCallMachine({
                        action: "daily-method-update-waiting-participants",
                        updatesById: t
                    }, function(e) {
                        e.error && r(e.error), e.ids || r(new Error("unknown error in updateWaitingParticipants()")), n({
                            ids: e.ids
                        });
                    });
                });
            }), function() {
                return X.apply(this, arguments);
            })
        },
        {
            key: "requestAccess",
            value: (Y = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.access, r = void 0 === n ? {
                    level: vi
                } : n, i = t.name, o = void 0 === i ? "" : i;
                return tc(this._callObjectMode, "requestAccess()"), Ka(this._callState, "requestAccess()"), new Promise(function(t, n) {
                    e.sendMessageToCallMachine({
                        action: "daily-method-request-access",
                        access: r,
                        name: o
                    }, function(e) {
                        e.error && n(e.error), e.access || n(new Error("unknown error in requestAccess()")), t({
                            access: e.access,
                            granted: e.granted
                        });
                    });
                });
            }), function() {
                return Y.apply(this, arguments);
            })
        },
        {
            key: "localAudio",
            value: function() {
                return this._participants.local ? ![
                    "blocked",
                    "off"
                ].includes(this._participants.local.tracks.audio.state) : null;
            }
        },
        {
            key: "localVideo",
            value: function() {
                return this._participants.local ? ![
                    "blocked",
                    "off"
                ].includes(this._participants.local.tracks.video.state) : null;
            }
        },
        {
            key: "setLocalAudio",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return "forceDiscardTrack" in t && (is() ? (console.warn("forceDiscardTrack option not supported in React Native; ignoring"), t = {}) : e && (console.warn("forceDiscardTrack option only supported when calling setLocalAudio(false); ignoring"), t = {})), this.sendMessageToCallMachine({
                    action: "local-audio",
                    state: e,
                    options: t
                }), this;
            }
        },
        {
            key: "localScreenAudio",
            value: function() {
                return this._participants.local ? ![
                    "blocked",
                    "off"
                ].includes(this._participants.local.tracks.screenAudio.state) : null;
            }
        },
        {
            key: "localScreenVideo",
            value: function() {
                return this._participants.local ? ![
                    "blocked",
                    "off"
                ].includes(this._participants.local.tracks.screenVideo.state) : null;
            }
        },
        {
            key: "updateScreenShare",
            value: function(e) {
                if (this._isScreenSharing) return this.sendMessageToCallMachine({
                    action: "local-screen-update",
                    options: e
                }), this;
                console.warn("There is no screen share in progress. Try calling startScreenShare first.");
            }
        },
        {
            key: "setLocalVideo",
            value: function(e) {
                return this.sendMessageToCallMachine({
                    action: "local-video",
                    state: e
                }), this;
            }
        },
        {
            key: "_setAllowLocalAudio",
            value: function(e) {
                if (this._preloadCache.allowLocalAudio = e, this._callMachineInitialized) return this.sendMessageToCallMachine({
                    action: "set-allow-local-audio",
                    state: e
                }), this;
            }
        },
        {
            key: "_setAllowLocalVideo",
            value: function(e) {
                if (this._preloadCache.allowLocalVideo = e, this._callMachineInitialized) return this.sendMessageToCallMachine({
                    action: "set-allow-local-video",
                    state: e
                }), this;
            }
        },
        {
            key: "getReceiveSettings",
            value: (K = p(function*(e) {
                var t = this, r = (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}).showInheritedValues, i = void 0 !== r && r;
                if (tc(this._callObjectMode, "getReceiveSettings()"), !this._callMachineInitialized) return this._receiveSettings;
                switch(n(e)){
                    case "string":
                        return new Promise(function(n) {
                            t.sendMessageToCallMachine({
                                action: "get-single-participant-receive-settings",
                                id: e,
                                showInheritedValues: i
                            }, function(e) {
                                n(e.receiveSettings);
                            });
                        });
                    case "undefined":
                        return this._receiveSettings;
                    default:
                        throw new Error('first argument to getReceiveSettings() must be a participant id (or "base"), or there should be no arguments');
                }
            }), function(e) {
                return K.apply(this, arguments);
            })
        },
        {
            key: "updateReceiveSettings",
            value: (Q = p(function*(e) {
                var t = this;
                if (tc(this._callObjectMode, "updateReceiveSettings()"), !sc(e, {
                    allowAllParticipantsKey: !0
                })) throw new Error(hc({
                    allowAllParticipantsKey: !0
                }));
                return Ka(this._callState, "updateReceiveSettings()", "To specify receive settings earlier, use the receiveSettings config property."), new Promise(function(n) {
                    t.sendMessageToCallMachine({
                        action: "update-receive-settings",
                        receiveSettings: e
                    }, function(e) {
                        n({
                            receiveSettings: e.receiveSettings
                        });
                    });
                });
            }), function(e) {
                return Q.apply(this, arguments);
            })
        },
        {
            key: "_prepInputSettingsForSharing",
            value: function(e, t) {
                if (e) {
                    var n = {};
                    if (e.audio) {
                        var r, i, o;
                        e.audio.settings && (!Object.keys(e.audio.settings).length && t || (n.audio = {
                            settings: Aa({}, e.audio.settings)
                        })), t && null !== (r = n.audio) && void 0 !== r && null !== (r = r.settings) && void 0 !== r && r.customTrack && (n.audio.settings = {
                            customTrack: this._sharedTracks.audioTrack
                        });
                        var s = "none" === (null === (i = e.audio.processor) || void 0 === i ? void 0 : i.type) && (null === (o = e.audio.processor) || void 0 === o ? void 0 : o._isDefaultWhenNone);
                        if (e.audio.processor && !s) {
                            var a = Aa({}, e.audio.processor);
                            delete a._isDefaultWhenNone, n.audio = Aa(Aa({}, n.audio), {}, {
                                processor: a
                            });
                        }
                    }
                    if (e.video) {
                        var c, l, u;
                        e.video.settings && (!Object.keys(e.video.settings).length && t || (n.video = {
                            settings: Aa({}, e.video.settings)
                        })), t && null !== (c = n.video) && void 0 !== c && null !== (c = c.settings) && void 0 !== c && c.customTrack && (n.video.settings = {
                            customTrack: this._sharedTracks.videoTrack
                        });
                        var d = "none" === (null === (l = e.video.processor) || void 0 === l ? void 0 : l.type) && (null === (u = e.video.processor) || void 0 === u ? void 0 : u._isDefaultWhenNone);
                        if (e.video.processor && !d) {
                            var p = Aa({}, e.video.processor);
                            delete p._isDefaultWhenNone, n.video = Aa(Aa({}, n.video), {}, {
                                processor: p
                            });
                        }
                    }
                    return n;
                }
            }
        },
        {
            key: "getInputSettings",
            value: function() {
                var e = this;
                return rc(), new Promise(function(t) {
                    t(e._getInputSettings());
                });
            }
        },
        {
            key: "_getInputSettings",
            value: function() {
                var e, t, n, r, i, o, s = {
                    processor: {
                        type: "none",
                        _isDefaultWhenNone: !0
                    }
                };
                this._inputSettings ? (e = (null === (n = this._inputSettings) || void 0 === n ? void 0 : n.video) || s, t = (null === (r = this._inputSettings) || void 0 === r ? void 0 : r.audio) || s) : (e = (null === (i = this._preloadCache) || void 0 === i || null === (i = i.inputSettings) || void 0 === i ? void 0 : i.video) || s, t = (null === (o = this._preloadCache) || void 0 === o || null === (o = o.inputSettings) || void 0 === o ? void 0 : o.audio) || s);
                var a = {
                    audio: t,
                    video: e
                };
                return this._prepInputSettingsForSharing(a, !0);
            }
        },
        {
            key: "_updatePreloadCacheInputSettings",
            value: function(e, t) {
                var n = this._inputSettings || {}, r = {};
                if (e.video) {
                    var i, o, s;
                    if (r.video = {}, e.video.settings) r.video.settings = {}, t || e.video.settings.customTrack || null === (s = n.video) || void 0 === s || !s.settings ? r.video.settings = e.video.settings : r.video.settings = Aa(Aa({}, n.video.settings), e.video.settings), Object.keys(r.video.settings).length || delete r.video.settings;
                    else null !== (i = n.video) && void 0 !== i && i.settings && (r.video.settings = n.video.settings);
                    e.video.processor ? r.video.processor = e.video.processor : null !== (o = n.video) && void 0 !== o && o.processor && (r.video.processor = n.video.processor);
                } else n.video && (r.video = n.video);
                if (e.audio) {
                    var a, c, l;
                    if (r.audio = {}, e.audio.settings) r.audio.settings = {}, t || e.audio.settings.customTrack || null === (l = n.audio) || void 0 === l || !l.settings ? r.audio.settings = e.audio.settings : r.audio.settings = Aa(Aa({}, n.audio.settings), e.audio.settings), Object.keys(r.audio.settings).length || delete r.audio.settings;
                    else null !== (a = n.audio) && void 0 !== a && a.settings && (r.audio.settings = n.audio.settings);
                    e.audio.processor ? r.audio.processor = e.audio.processor : null !== (c = n.audio) && void 0 !== c && c.processor && (r.audio.processor = n.audio.processor);
                } else n.audio && (r.audio = n.audio);
                this._maybeUpdateInputSettings(r);
            }
        },
        {
            key: "_devicesFromInputSettings",
            value: function(e) {
                var t, n, r = (null == e || null === (t = e.video) || void 0 === t || null === (t = t.settings) || void 0 === t ? void 0 : t.deviceId) || null, i = (null == e || null === (n = e.audio) || void 0 === n || null === (n = n.settings) || void 0 === n ? void 0 : n.deviceId) || null, o = this._preloadCache.outputDeviceId || null;
                return {
                    camera: r ? {
                        deviceId: r
                    } : {},
                    mic: i ? {
                        deviceId: i
                    } : {},
                    speaker: o ? {
                        deviceId: o
                    } : {}
                };
            }
        },
        {
            key: "updateInputSettings",
            value: (G = p(function*(e) {
                var t = this;
                return rc(), ac(e) ? e.video || e.audio ? (cc(e, this.properties.dailyConfig, this._sharedTracks), this._callObjectMode && !this._callMachineInitialized ? (this._updatePreloadCacheInputSettings(e, !0), this._getInputSettings()) : new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "update-input-settings",
                        inputSettings: e
                    }, function(i) {
                        if (i.error) r(i.error);
                        else {
                            if (i.returnPreloadCache) return t._updatePreloadCacheInputSettings(e, !0), void n(t._getInputSettings());
                            t._maybeUpdateInputSettings(i.inputSettings), n(t._prepInputSettingsForSharing(i.inputSettings, !0));
                        }
                    });
                })) : this._getInputSettings() : (console.error(pc()), Promise.reject(pc()));
            }), function(e) {
                return G.apply(this, arguments);
            })
        },
        {
            key: "setBandwidth",
            value: function(e) {
                var t = e.kbs, n = e.trackConstraints;
                if (rc(), this._callMachineInitialized) return this.sendMessageToCallMachine({
                    action: "set-bandwidth",
                    kbs: t,
                    trackConstraints: n
                }), this;
            }
        },
        {
            key: "getDailyLang",
            value: function() {
                var e = this;
                if (rc(), this._callMachineInitialized) return new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-daily-lang"
                    }, function(e) {
                        delete e.action, delete e.callbackStamp, t(e);
                    });
                });
            }
        },
        {
            key: "setDailyLang",
            value: function(e) {
                return rc(), this.sendMessageToCallMachine({
                    action: "set-daily-lang",
                    lang: e
                }), this;
            }
        },
        {
            key: "setProxyUrl",
            value: function(e) {
                return this.sendMessageToCallMachine({
                    action: "set-proxy-url",
                    proxyUrl: e
                }), this;
            }
        },
        {
            key: "setIceConfig",
            value: function(e) {
                return this.sendMessageToCallMachine({
                    action: "set-ice-config",
                    iceConfig: e
                }), this;
            }
        },
        {
            key: "meetingSessionSummary",
            value: function() {
                return [
                    si,
                    ai
                ].includes(this._callState) ? this._finalSummaryOfPrevSession : this._meetingSessionSummary;
            }
        },
        {
            key: "getMeetingSession",
            value: (H = p(function*() {
                var e = this;
                return console.warn("getMeetingSession() is deprecated: use meetingSessionSummary(), which will return immediately"), Ka(this._callState, "getMeetingSession()"), new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-meeting-session"
                    }, function(e) {
                        delete e.action, delete e.callbackStamp, t(e);
                    });
                });
            }), function() {
                return H.apply(this, arguments);
            })
        },
        {
            key: "meetingSessionState",
            value: function() {
                return Ka(this._callState, "meetingSessionState"), this._meetingSessionState;
            }
        },
        {
            key: "setMeetingSessionData",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "replace";
                tc(this._callObjectMode, "setMeetingSessionData()"), Ka(this._callState, "setMeetingSessionData");
                try {
                    !function(e, t) {
                        new Ds({
                            data: e,
                            mergeStrategy: t
                        });
                    }(e, t);
                } catch (e) {
                    throw console.error(e), e;
                }
                try {
                    this.sendMessageToCallMachine({
                        action: "set-session-data",
                        data: e,
                        mergeStrategy: t
                    });
                } catch (e) {
                    throw new Error("Error setting meeting session data: ".concat(e));
                }
            }
        },
        {
            key: "setUserName",
            value: function(e, t) {
                var n = this;
                return this.properties.userName = e, new Promise(function(r) {
                    n.sendMessageToCallMachine({
                        action: "set-user-name",
                        name: null != e ? e : "",
                        thisMeetingOnly: is() || !!t && !!t.thisMeetingOnly
                    }, function(e) {
                        delete e.action, delete e.callbackStamp, r(e);
                    });
                });
            }
        },
        {
            key: "setUserData",
            value: (W = p(function*(e) {
                var t = this;
                try {
                    oc(e);
                } catch (e) {
                    throw console.error(e), e;
                }
                if (this.properties.userData = e, this._callMachineInitialized) return new Promise(function(n) {
                    try {
                        t.sendMessageToCallMachine({
                            action: "set-user-data",
                            userData: e
                        }, function(e) {
                            delete e.action, delete e.callbackStamp, n(e);
                        });
                    } catch (e) {
                        throw new Error("Error setting user data: ".concat(e));
                    }
                });
            }), function(e) {
                return W.apply(this, arguments);
            })
        },
        {
            key: "validateAudioLevelInterval",
            value: function(e) {
                if (e && (e < 100 || "number" != typeof e)) throw new Error("The interval must be a number greater than or equal to 100 milliseconds.");
            }
        },
        {
            key: "startLocalAudioLevelObserver",
            value: function(e) {
                var t = this;
                if ("undefined" == typeof AudioWorkletNode && !is()) throw new Error("startLocalAudioLevelObserver() is not supported on this browser");
                if (this.validateAudioLevelInterval(e), this._callMachineInitialized) return this._isLocalAudioLevelObserverRunning = !0, new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "start-local-audio-level-observer",
                        interval: e
                    }, function(e) {
                        t._isLocalAudioLevelObserverRunning = !e.error, e.error ? r({
                            error: e.error
                        }) : n();
                    });
                });
                this._preloadCache.localAudioLevelObserver = {
                    enabled: !0,
                    interval: e
                };
            }
        },
        {
            key: "isLocalAudioLevelObserverRunning",
            value: function() {
                return this._isLocalAudioLevelObserverRunning;
            }
        },
        {
            key: "stopLocalAudioLevelObserver",
            value: function() {
                this._preloadCache.localAudioLevelObserver = null, this._localAudioLevel = 0, this._isLocalAudioLevelObserverRunning = !1, this.sendMessageToCallMachine({
                    action: "stop-local-audio-level-observer"
                });
            }
        },
        {
            key: "startRemoteParticipantsAudioLevelObserver",
            value: function(e) {
                var t = this;
                if (this.validateAudioLevelInterval(e), this._callMachineInitialized) return this._isRemoteParticipantsAudioLevelObserverRunning = !0, new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "start-remote-participants-audio-level-observer",
                        interval: e
                    }, function(e) {
                        t._isRemoteParticipantsAudioLevelObserverRunning = !e.error, e.error ? r({
                            error: e.error
                        }) : n();
                    });
                });
                this._preloadCache.remoteParticipantsAudioLevelObserver = {
                    enabled: !0,
                    interval: e
                };
            }
        },
        {
            key: "isRemoteParticipantsAudioLevelObserverRunning",
            value: function() {
                return this._isRemoteParticipantsAudioLevelObserverRunning;
            }
        },
        {
            key: "stopRemoteParticipantsAudioLevelObserver",
            value: function() {
                this._preloadCache.remoteParticipantsAudioLevelObserver = null, this._remoteParticipantsAudioLevel = {}, this._isRemoteParticipantsAudioLevelObserverRunning = !1, this.sendMessageToCallMachine({
                    action: "stop-remote-participants-audio-level-observer"
                });
            }
        },
        {
            key: "startCamera",
            value: (z = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (tc(this._callObjectMode, "startCamera()"), Xa(this._callState, this._isPreparingToJoin, "startCamera()", "Did you mean to use setLocalAudio() and/or setLocalVideo() instead?"), this.needsLoad()) try {
                    yield this.load(t);
                } catch (e) {
                    return Promise.reject(e);
                }
                else {
                    if (this._didPreAuth) {
                        if (t.url && t.url !== this.properties.url) return console.error("url in startCamera() is different than the one used in preAuth()"), Promise.reject();
                        if (t.token && t.token !== this.properties.token) return console.error("token in startCamera() is different than the one used in preAuth()"), Promise.reject();
                    }
                    this.validateProperties(t), this.properties = Aa(Aa({}, this.properties), t);
                }
                return new Promise(function(t, n) {
                    e._preloadCache.inputSettings = e._prepInputSettingsForSharing(e._inputSettings, !1), e.sendMessageToCallMachine({
                        action: "start-camera",
                        properties: Qa(e.properties, e.callClientId),
                        preloadCache: Qa(e._preloadCache, e.callClientId)
                    }, function(e) {
                        e.error ? n(e.error) : t({
                            camera: e.camera,
                            mic: e.mic,
                            speaker: e.speaker
                        });
                    });
                });
            }), function() {
                return z.apply(this, arguments);
            })
        },
        {
            key: "validateCustomTrack",
            value: function(e, t, n) {
                if (n && n.length > 50) throw new Error("Custom track `trackName` must not be more than 50 characters");
                if (t && "music" !== t && "speech" !== t && !(t instanceof Object)) throw new Error("Custom track `mode` must be either `music` | `speech` | `DailyMicAudioModeSettings` or `undefined`");
                if (!!n && [
                    "cam-audio",
                    "cam-video",
                    "screen-video",
                    "screen-audio",
                    "rmpAudio",
                    "rmpVideo",
                    "customVideoDefaults"
                ].includes(n)) throw new Error("Custom track `trackName` must not match a track name already used by daily: cam-audio, cam-video, customVideoDefaults, screen-video, screen-audio, rmpAudio, rmpVideo");
                if (!(e instanceof MediaStreamTrack)) throw new Error("Custom tracks provided must be instances of MediaStreamTrack");
            }
        },
        {
            key: "startCustomTrack",
            value: function() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                    track: track,
                    mode: mode,
                    trackName: trackName,
                    ignoreAudioLevel: ignoreAudioLevel
                };
                return rc(), Ka(this._callState, "startCustomTrack()"), this.validateCustomTrack(t.track, t.mode, t.trackName), new Promise(function(n, r) {
                    e._sharedTracks.customTrack = t.track, t.track = Qo, e.sendMessageToCallMachine({
                        action: "start-custom-track",
                        properties: t
                    }, function(e) {
                        e.error ? r({
                            error: e.error
                        }) : n(e.mediaTag);
                    });
                });
            }
        },
        {
            key: "stopCustomTrack",
            value: function(e) {
                var t = this;
                return rc(), Ka(this._callState, "stopCustomTrack()"), new Promise(function(n) {
                    t.sendMessageToCallMachine({
                        action: "stop-custom-track",
                        mediaTag: e
                    }, function(e) {
                        n(e.mediaTag);
                    });
                });
            }
        },
        {
            key: "setCamera",
            value: function(e) {
                var t = this;
                return ic(), Za(this._callMachineInitialized, "setCamera()"), new Promise(function(n) {
                    t.sendMessageToCallMachine({
                        action: "set-camera",
                        cameraDeviceId: e
                    }, function(e) {
                        n({
                            device: e.device
                        });
                    });
                });
            }
        },
        {
            key: "setAudioDevice",
            value: (q = p(function*(e) {
                return ic(), this.nativeUtils().setAudioDevice(e), {
                    deviceId: yield this.nativeUtils().getAudioDevice()
                };
            }), function(e) {
                return q.apply(this, arguments);
            })
        },
        {
            key: "cycleCamera",
            value: function() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return new Promise(function(n) {
                    e.sendMessageToCallMachine({
                        action: "cycle-camera",
                        properties: t
                    }, function(e) {
                        n({
                            device: e.device
                        });
                    });
                });
            }
        },
        {
            key: "cycleMic",
            value: function() {
                var e = this;
                return rc(), new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "cycle-mic"
                    }, function(e) {
                        t({
                            device: e.device
                        });
                    });
                });
            }
        },
        {
            key: "getCameraFacingMode",
            value: function() {
                var e = this;
                return ic(), new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-camera-facing-mode"
                    }, function(e) {
                        t(e.facingMode);
                    });
                });
            }
        },
        {
            key: "setInputDevicesAsync",
            value: ($ = p(function*(e) {
                var t = this, n = e.audioDeviceId, r = e.videoDeviceId, i = e.audioSource, o = e.videoSource;
                if (rc(), void 0 !== i && (n = i), void 0 !== o && (r = o), "boolean" == typeof n && (this._setAllowLocalAudio(n), n = void 0), "boolean" == typeof r && (this._setAllowLocalVideo(r), r = void 0), !n && !r) return yield this.getInputDevices();
                var s = {};
                return n && (n instanceof MediaStreamTrack ? (this._sharedTracks.audioTrack = n, n = Qo, s.audio = {
                    settings: {
                        customTrack: n
                    }
                }) : (delete this._sharedTracks.audioTrack, s.audio = {
                    settings: {
                        deviceId: n
                    }
                })), r && (r instanceof MediaStreamTrack ? (this._sharedTracks.videoTrack = r, r = Qo, s.video = {
                    settings: {
                        customTrack: r
                    }
                }) : (delete this._sharedTracks.videoTrack, s.video = {
                    settings: {
                        deviceId: r
                    }
                })), this._callObjectMode && this.needsLoad() ? (this._updatePreloadCacheInputSettings(s, !1), this._devicesFromInputSettings(this._inputSettings)) : new Promise(function(e) {
                    t.sendMessageToCallMachine({
                        action: "set-input-devices",
                        audioDeviceId: n,
                        videoDeviceId: r
                    }, function(n) {
                        if (delete n.action, delete n.callbackStamp, n.returnPreloadCache) return t._updatePreloadCacheInputSettings(s, !1), void e(t._devicesFromInputSettings(t._inputSettings));
                        e(n);
                    });
                });
            }), function(e) {
                return $.apply(this, arguments);
            })
        },
        {
            key: "setOutputDeviceAsync",
            value: (J = p(function*(e) {
                var t = this, n = e.outputDeviceId;
                if (rc(), !n || "string" != typeof n) throw new Error("outputDeviceId must be provided and must be a valid device id");
                return this._preloadCache.outputDeviceId = n, this._callObjectMode && this.needsLoad() ? this._devicesFromInputSettings(this._inputSettings) : new Promise(function(e, r) {
                    t.sendMessageToCallMachine({
                        action: "set-output-device",
                        outputDeviceId: n
                    }, function(n) {
                        if (delete n.action, delete n.callbackStamp, n.error) {
                            var i = new Error(n.error.message);
                            return i.type = n.error.type, void r(i);
                        }
                        n.returnPreloadCache ? e(t._devicesFromInputSettings(t._inputSettings)) : e(n);
                    });
                });
            }), function(e) {
                return J.apply(this, arguments);
            })
        },
        {
            key: "getInputDevices",
            value: (V = p(function*() {
                var e = this;
                return this._callObjectMode && this.needsLoad() ? this._devicesFromInputSettings(this._inputSettings) : new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-input-devices"
                    }, function(n) {
                        n.returnPreloadCache ? t(e._devicesFromInputSettings(e._inputSettings)) : t({
                            camera: n.camera,
                            mic: n.mic,
                            speaker: n.speaker
                        });
                    });
                });
            }), function() {
                return V.apply(this, arguments);
            })
        },
        {
            key: "nativeInCallAudioMode",
            value: function() {
                return ic(), this._nativeInCallAudioMode;
            }
        },
        {
            key: "setNativeInCallAudioMode",
            value: function(e) {
                if (ic(), [
                    Da,
                    Na
                ].includes(e)) {
                    if (e !== this._nativeInCallAudioMode) return this._nativeInCallAudioMode = e, !this.disableReactNativeAutoDeviceManagement("audio") && Ya(this._callState, this._isPreparingToJoin) && this.nativeUtils().setAudioMode(this._nativeInCallAudioMode), this;
                } else console.error("invalid in-call audio mode specified: ", e);
            }
        },
        {
            key: "preAuth",
            value: (U = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (tc(this._callObjectMode, "preAuth()"), Xa(this._callState, this._isPreparingToJoin, "preAuth()"), this.needsLoad() && (yield this.load(t)), !t.url) throw new Error("preAuth() requires at least a url to be provided");
                return this.validateProperties(t), this.properties = Aa(Aa({}, this.properties), t), new Promise(function(t, n) {
                    e._preloadCache.inputSettings = e._prepInputSettingsForSharing(e._inputSettings, !1), e.sendMessageToCallMachine({
                        action: "daily-method-preauth",
                        properties: Qa(e.properties, e.callClientId),
                        preloadCache: Qa(e._preloadCache, e.callClientId)
                    }, function(r) {
                        return r.error ? n(r.error) : r.access ? (e._didPreAuth = !0, void t({
                            access: r.access
                        })) : n(new Error("unknown error in preAuth()"));
                    });
                });
            }), function() {
                return U.apply(this, arguments);
            })
        },
        {
            key: "load",
            value: (R = p(function*(e) {
                var t = this;
                if (this.needsLoad()) {
                    if (this._destroyed && (this._logUseAfterDestroy(), this.strictMode)) throw new Error("Use after destroy");
                    if (e && (this.validateProperties(e), this.properties = Aa(Aa({}, this.properties), e)), !this._callObjectMode && !this.properties.url) throw new Error("can't load iframe meeting because url property isn't set");
                    return this._updateCallState(ni), this.emitDailyJSEvent({
                        action: Vi
                    }), this._callObjectMode ? new Promise(function(e, n) {
                        t._callObjectLoader.cancel();
                        var r = Date.now();
                        t._callObjectLoader.load(t.properties.dailyConfig, function(n) {
                            t._bundleLoadTime = n ? "no-op" : Date.now() - r, t._updateCallState(ri), n && t.emitDailyJSEvent({
                                action: $i
                            }), e();
                        }, function(e, r) {
                            if (t.emitDailyJSEvent({
                                action: Ji
                            }), !r) {
                                t._updateCallState(ai), t.resetMeetingDependentVars();
                                var i = {
                                    action: Jo,
                                    errorMsg: e.msg,
                                    error: {
                                        type: "connection-error",
                                        msg: "Failed to load call object bundle.",
                                        details: {
                                            on: "load",
                                            sourceError: e,
                                            bundleUrl: B(t.properties.dailyConfig)
                                        }
                                    }
                                };
                                t._maybeSendToSentry(i), t.emitDailyJSEvent(i), n(e.msg);
                            }
                        });
                    }) : (this._iframe.src = F(this.assembleMeetingUrl(), this.properties.dailyConfig), new Promise(function(e, n) {
                        t._loadedCallback = function(r) {
                            t._callState !== ai ? (t._updateCallState(ri), (t.properties.cssFile || t.properties.cssText) && t.loadCss(t.properties), e()) : n(r);
                        };
                    }));
                }
            }), function(e) {
                return R.apply(this, arguments);
            })
        },
        {
            key: "join",
            value: (L = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (this._testCallInProgress && this.stopTestCallQuality(), !t.url && !this.properties.url) {
                    var n = "No room URL has been provided";
                    return console.error(n), Promise.reject(new Error(n));
                }
                var r = !1;
                if (this.needsLoad()) {
                    this.updateIsPreparingToJoin(!0);
                    try {
                        yield this.load(t);
                    } catch (e) {
                        return this.updateIsPreparingToJoin(!1), Promise.reject(e);
                    }
                } else {
                    if (r = !(!this.properties.cssFile && !this.properties.cssText), this._didPreAuth) {
                        if (t.url && t.url !== this.properties.url) return console.error("url in join() is different than the one used in preAuth()"), this.updateIsPreparingToJoin(!1), Promise.reject();
                        if (t.token && t.token !== this.properties.token) return console.error("token in join() is different than the one used in preAuth()"), this.updateIsPreparingToJoin(!1), Promise.reject();
                    }
                    if (t.url && !this._callObjectMode && t.url && t.url !== this.properties.url) return console.error("url in join() is different than the one used in load() (".concat(this.properties.url, " -> ").concat(t.url, ")")), this.updateIsPreparingToJoin(!1), Promise.reject();
                    this.validateProperties(t), this.properties = Aa(Aa({}, this.properties), t);
                }
                return void 0 !== t.showLocalVideo && (this._callObjectMode ? console.error("showLocalVideo is not available in callObject mode") : this._showLocalVideo = !!t.showLocalVideo), void 0 !== t.showParticipantsBar && (this._callObjectMode ? console.error("showParticipantsBar is not available in callObject mode") : this._showParticipantsBar = !!t.showParticipantsBar), this._callState === oi || this._callState === ii ? (console.warn("already joined meeting, call leave() before joining again"), void this.updateIsPreparingToJoin(!1)) : (this._updateCallState(ii, !1), this.emitDailyJSEvent({
                    action: Wi
                }), this._preloadCache.inputSettings = this._prepInputSettingsForSharing(this._inputSettings || {}, !1), this.sendMessageToCallMachine({
                    action: "join-meeting",
                    properties: Qa(this.properties, this.callClientId),
                    preloadCache: Qa(this._preloadCache, this.callClientId)
                }, function(t) {
                    t.error && e._joinedCallback && (e._joinedCallback(null, t.error), e._joinedCallback = null);
                }), new Promise(function(t, n) {
                    e._joinedCallback = function(i, o) {
                        if (e._callState !== ai) {
                            if (o) return e._updateCallState(si), void n(o);
                            if (e._updateCallState(oi), i) for(var s in i){
                                if (e._callObjectMode) {
                                    var a = e._callMachine().store;
                                    Zs(i[s], a), ea(i[s], a), na(i[s], e._participants[s], a);
                                }
                                e._participants[s] = Aa({}, i[s]), e.toggleParticipantAudioBasedOnNativeAudioFocus();
                            }
                            r && e.loadCss(e.properties), t(i);
                        } else n(o);
                    };
                }));
            }), function() {
                return L.apply(this, arguments);
            })
        },
        {
            key: "leave",
            value: (x = p(function*() {
                var e = this;
                return this._testCallInProgress && this.stopTestCallQuality(), new Promise(function(t) {
                    e._callState === si || e._callState === ai ? t() : e._callObjectLoader && !e._callObjectLoader.loaded ? (e._callObjectLoader.cancel(), e._updateCallState(si), e.resetMeetingDependentVars(), e.emitDailyJSEvent({
                        action: si
                    }), t()) : (e._resolveLeave = t, e.sendMessageToCallMachine({
                        action: "leave-meeting"
                    }));
                });
            }), function() {
                return x.apply(this, arguments);
            })
        },
        {
            key: "startScreenShare",
            value: (I = p(function*() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (Za(this._callMachineInitialized, "startScreenShare()"), t.screenVideoSendSettings && this._validateVideoSendSettings("screenVideo", t.screenVideoSendSettings), t.mediaStream && (this._sharedTracks.screenMediaStream = t.mediaStream, t.mediaStream = Qo), "undefined" != typeof DailyNativeUtils && void 0 !== DailyNativeUtils.isIOS && DailyNativeUtils.isIOS) {
                    var n = this.nativeUtils();
                    if (yield n.isScreenBeingCaptured()) return void this.emitDailyJSEvent({
                        action: Vo,
                        type: "screen-share-error",
                        errorMsg: "Could not start the screen sharing. The screen is already been captured!"
                    });
                    n.setSystemScreenCaptureStartCallback(function() {
                        n.setSystemScreenCaptureStartCallback(null), e.sendMessageToCallMachine({
                            action: Wo,
                            captureOptions: t
                        });
                    }), n.presentSystemScreenCapturePrompt();
                } else this.sendMessageToCallMachine({
                    action: Wo,
                    captureOptions: t
                });
            }), function() {
                return I.apply(this, arguments);
            })
        },
        {
            key: "stopScreenShare",
            value: function() {
                Za(this._callMachineInitialized, "stopScreenShare()"), this.sendMessageToCallMachine({
                    action: "local-screen-stop"
                });
            }
        },
        {
            key: "startRecording",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type;
                if (t && "cloud" !== t && "cloud-audio-only" !== t && "raw-tracks" !== t && "local" !== t) throw new Error("invalid type: ".concat(t, ", allowed values 'cloud', 'cloud-audio-only', 'raw-tracks', or 'local'"));
                this.sendMessageToCallMachine(Aa({
                    action: "local-recording-start"
                }, e));
            }
        },
        {
            key: "updateRecording",
            value: function(e) {
                var t = e.layout, n = void 0 === t ? {
                    preset: "default"
                } : t, r = e.instanceId;
                this.sendMessageToCallMachine({
                    action: "daily-method-update-recording",
                    layout: n,
                    instanceId: r
                });
            }
        },
        {
            key: "stopRecording",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                this.sendMessageToCallMachine(Aa({
                    action: "local-recording-stop"
                }, e));
            }
        },
        {
            key: "startLiveStreaming",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                this.sendMessageToCallMachine(Aa({
                    action: "daily-method-start-live-streaming"
                }, e));
            }
        },
        {
            key: "updateLiveStreaming",
            value: function(e) {
                var t = e.layout, n = void 0 === t ? {
                    preset: "default"
                } : t, r = e.instanceId;
                this.sendMessageToCallMachine({
                    action: "daily-method-update-live-streaming",
                    layout: n,
                    instanceId: r
                });
            }
        },
        {
            key: "addLiveStreamingEndpoints",
            value: function(e) {
                var t = e.endpoints, n = e.instanceId;
                this.sendMessageToCallMachine({
                    action: Ho,
                    endpointsOp: es,
                    endpoints: t,
                    instanceId: n
                });
            }
        },
        {
            key: "removeLiveStreamingEndpoints",
            value: function(e) {
                var t = e.endpoints, n = e.instanceId;
                this.sendMessageToCallMachine({
                    action: Ho,
                    endpointsOp: ts,
                    endpoints: t,
                    instanceId: n
                });
            }
        },
        {
            key: "stopLiveStreaming",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                this.sendMessageToCallMachine(Aa({
                    action: "daily-method-stop-live-streaming"
                }, e));
            }
        },
        {
            key: "validateDailyConfig",
            value: function(e) {
                e.camSimulcastEncodings && (console.warn("camSimulcastEncodings is deprecated. Use sendSettings, found in DailyCallOptions, to provide camera simulcast settings."), this.validateSimulcastEncodings(e.camSimulcastEncodings)), e.screenSimulcastEncodings && console.warn("screenSimulcastEncodings is deprecated. Use sendSettings, found in DailyCallOptions, to provide screen simulcast settings."), vs() && e.noAutoDefaultDeviceChange && console.warn("noAutoDefaultDeviceChange is not supported on Android, and will be ignored.");
            }
        },
        {
            key: "validateSimulcastEncodings",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                if (e) {
                    if (!(e instanceof Array || Array.isArray(e))) throw new Error("encodings must be an Array");
                    if (!_c(e.length, 1, 3)) throw new Error("encodings must be an Array with between 1 to ".concat(3, " layers"));
                    for(var r = 0; r < e.length; r++){
                        var i = e[r];
                        for(var o in this._validateEncodingLayerHasValidProperties(i), i)if (Ua.includes(o)) {
                            if ("number" != typeof i[o]) throw new Error("".concat(o, " must be a number"));
                            if (t) {
                                var s = t[o], a = s.min, c = s.max;
                                if (!_c(i[o], a, c)) throw new Error("".concat(o, " value not in range. valid range: ").concat(a, " to ").concat(c));
                            }
                        } else if (![
                            "active",
                            "scalabilityMode"
                        ].includes(o)) throw new Error("Invalid key ".concat(o, ", valid keys are:") + Object.values(Ua));
                        if (n && !i.hasOwnProperty("maxBitrate")) throw new Error("maxBitrate is not specified");
                    }
                }
            }
        },
        {
            key: "startRemoteMediaPlayer",
            value: (j = p(function*(e) {
                var t = this, n = e.url, r = e.settings, i = void 0 === r ? {
                    state: Xo.PLAY
                } : r;
                try {
                    !function(e) {
                        if ("string" != typeof e) throw new Error('url parameter must be "string" type');
                    }(n), bc(i), function(e) {
                        for(var t in e)if (!Va.includes(t)) throw new Error("Invalid key ".concat(t, ", valid keys are: ").concat(Va));
                        e.simulcastEncodings && this.validateSimulcastEncodings(e.simulcastEncodings, Ba, !0);
                    }(i);
                } catch (e) {
                    throw console.error("invalid argument Error: ".concat(e)), console.error('startRemoteMediaPlayer arguments must be of the form:\n  { url: "playback url",\n  settings?:\n  {state: "play"|"pause", simulcastEncodings?: [{}] } }'), e;
                }
                return new Promise(function(e, r) {
                    t.sendMessageToCallMachine({
                        action: "daily-method-start-remote-media-player",
                        url: n,
                        settings: i
                    }, function(t) {
                        t.error ? r({
                            error: t.error,
                            errorMsg: t.errorMsg
                        }) : e({
                            session_id: t.session_id,
                            remoteMediaPlayerState: {
                                state: t.state,
                                settings: t.settings
                            }
                        });
                    });
                });
            }), function(e) {
                return j.apply(this, arguments);
            })
        },
        {
            key: "stopRemoteMediaPlayer",
            value: (A = p(function*(e) {
                var t = this;
                if ("string" != typeof e) throw new Error(" remotePlayerID must be of type string");
                return new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "daily-method-stop-remote-media-player",
                        session_id: e
                    }, function(e) {
                        e.error ? r({
                            error: e.error,
                            errorMsg: e.errorMsg
                        }) : n();
                    });
                });
            }), function(e) {
                return A.apply(this, arguments);
            })
        },
        {
            key: "updateRemoteMediaPlayer",
            value: (P = p(function*(e) {
                var t = this, n = e.session_id, r = e.settings;
                try {
                    bc(r);
                } catch (e) {
                    throw console.error("invalid argument Error: ".concat(e)), console.error('updateRemoteMediaPlayer arguments must be of the form:\n  session_id: "participant session",\n  { settings?: {state: "play"|"pause"} }'), e;
                }
                return new Promise(function(e, i) {
                    t.sendMessageToCallMachine({
                        action: "daily-method-update-remote-media-player",
                        session_id: n,
                        settings: r
                    }, function(t) {
                        t.error ? i({
                            error: t.error,
                            errorMsg: t.errorMsg
                        }) : e({
                            session_id: t.session_id,
                            remoteMediaPlayerState: {
                                state: t.state,
                                settings: t.settings
                            }
                        });
                    });
                });
            }), function(e) {
                return P.apply(this, arguments);
            })
        },
        {
            key: "startTranscription",
            value: function(e) {
                Ka(this._callState, "startTranscription()"), this.sendMessageToCallMachine(Aa({
                    action: "daily-method-start-transcription"
                }, e));
            }
        },
        {
            key: "updateTranscription",
            value: function(e) {
                if (Ka(this._callState, "updateTranscription()"), !e) throw new Error("updateTranscription Error: options is mandatory");
                if ("object" !== n(e)) throw new Error("updateTranscription Error: options must be object type");
                if (e.participants && !Array.isArray(e.participants)) throw new Error("updateTranscription Error: participants must be an array");
                this.sendMessageToCallMachine(Aa({
                    action: "daily-method-update-transcription"
                }, e));
            }
        },
        {
            key: "stopTranscription",
            value: function(e) {
                if (Ka(this._callState, "stopTranscription()"), e && "object" !== n(e)) throw new Error("stopTranscription Error: options must be object type");
                if (e && !e.instanceId) throw new Error('"instanceId" not provided');
                this.sendMessageToCallMachine(Aa({
                    action: "daily-method-stop-transcription"
                }, e));
            }
        },
        {
            key: "startDialOut",
            value: (O = p(function*(e) {
                var t = this;
                Ka(this._callState, "startDialOut()");
                var n = function(e) {
                    if (e) {
                        if (!Array.isArray(e)) throw new Error("Error starting dial out: audio codec must be an array");
                        if (e.length <= 0) throw new Error("Error starting dial out: audio codec array specified but empty");
                        e.forEach(function(e) {
                            if ("string" != typeof e) throw new Error("Error starting dial out: audio codec must be a string");
                            if ("OPUS" !== e && "PCMU" !== e && "PCMA" !== e && "G722" !== e) throw new Error("Error starting dial out: audio codec must be one of OPUS, PCMU, PCMA, G722");
                        });
                    }
                };
                if (!e.sipUri && !e.phoneNumber) throw new Error("Error starting dial out: either a sip uri or phone number must be provided");
                if (e.sipUri && e.phoneNumber) throw new Error("Error starting dial out: only one of sip uri or phone number must be provided");
                if (e.sipUri) {
                    if ("string" != typeof e.sipUri) throw new Error("Error starting dial out: sipUri must be a string");
                    if (!e.sipUri.startsWith("sip:")) throw new Error("Error starting dial out: Invalid SIP URI, must start with 'sip:'");
                    if (e.video && "boolean" != typeof e.video) throw new Error("Error starting dial out: video must be a boolean value");
                    !function(e) {
                        if (e && (n(e.audio), e.video)) {
                            if (!Array.isArray(e.video)) throw new Error("Error starting dial out: video codec must be an array");
                            if (e.video.length <= 0) throw new Error("Error starting dial out: video codec array specified but empty");
                            e.video.forEach(function(e) {
                                if ("string" != typeof e) throw new Error("Error starting dial out: video codec must be a string");
                                if ("H264" !== e && "VP8" !== e) throw new Error("Error starting dial out: video codec must be H264 or VP8");
                            });
                        }
                    }(e.codecs);
                }
                if (e.phoneNumber) {
                    if ("string" != typeof e.phoneNumber) throw new Error("Error starting dial out: phoneNumber must be a string");
                    if (!/^\+\d{1,}$/.test(e.phoneNumber)) throw new Error("Error starting dial out: Invalid phone number, must be valid phone number as per E.164");
                    e.codecs && n(e.codecs.audio);
                }
                if (e.callerId) {
                    if ("string" != typeof e.callerId) throw new Error("Error starting dial out: callerId must be a string");
                    if (e.sipUri) throw new Error("Error starting dial out: callerId not allowed with sipUri");
                }
                if (e.displayName) {
                    if ("string" != typeof e.displayName) throw new Error("Error starting dial out: displayName must be a string");
                    if (e.displayName.length >= 200) throw new Error("Error starting dial out: displayName length must be less than 200");
                }
                if (e.userId) {
                    if ("string" != typeof e.userId) throw new Error("Error starting dial out: userId must be a string");
                    if (e.userId.length > 36) throw new Error("Error starting dial out: userId length must be less than or equal to 36");
                }
                if (Ga(e), e.permissions && e.permissions.canReceive) {
                    var r = f(Ca.validateJSONObject(e.permissions.canReceive), 2), i = r[0], o = r[1];
                    if (!i) throw new Error(o);
                }
                if (e.provider) {
                    if ("daily" !== e.provider) throw new Error("Error: provider can be set only to 'daily', got: ".concat(e.provider));
                    if (e.phoneNumber) throw new Error("Error starting dial out: provider valid only for sipUri, not phoneNumber");
                    console.warn("(pre-beta) provider=daily is currently in pre-beta, things might break!");
                }
                return new Promise(function(n, r) {
                    t.sendMessageToCallMachine(Aa({
                        action: "dialout-start"
                    }, e), function(e) {
                        e.error ? r(e.error) : n(e);
                    });
                });
            }), function(e) {
                return O.apply(this, arguments);
            })
        },
        {
            key: "stopDialOut",
            value: function(e) {
                var t = this;
                return Ka(this._callState, "stopDialOut()"), new Promise(function(n, r) {
                    t.sendMessageToCallMachine(Aa({
                        action: "dialout-stop"
                    }, e), function(e) {
                        e.error ? r(e.error) : n(e);
                    });
                });
            }
        },
        {
            key: "sipCallTransfer",
            value: (T = p(function*(e) {
                var t = this;
                if (Ka(this._callState, "sipCallTransfer()"), !e) throw new Error("sipCallTransfer() requires a sessionId and toEndPoint");
                return e.useSipRefer = !1, yc(e, "sipCallTransfer"), Ga(e), new Promise(function(n, r) {
                    t.sendMessageToCallMachine(Aa({
                        action: ns
                    }, e), function(e) {
                        e.error ? r(e.error) : n(e);
                    });
                });
            }), function(e) {
                return T.apply(this, arguments);
            })
        },
        {
            key: "sipRefer",
            value: (E = p(function*(e) {
                var t = this;
                if (Ka(this._callState, "sipRefer()"), !e) throw new Error("sessionId and toEndPoint are mandatory parameter");
                return e.useSipRefer = !0, yc(e, "sipRefer"), new Promise(function(n, r) {
                    t.sendMessageToCallMachine(Aa({
                        action: ns
                    }, e), function(e) {
                        e.error ? r(e.error) : n(e);
                    });
                });
            }), function(e) {
                return E.apply(this, arguments);
            })
        },
        {
            key: "sendDTMF",
            value: (C = p(function*(e) {
                var t = this;
                return Ka(this._callState, "sendDTMF()"), function(e) {
                    var t = e.sessionId, n = e.tones;
                    if (!t || !n) throw new Error("sessionId and tones are mandatory parameter");
                    if ("string" != typeof t || "string" != typeof n) throw new Error("sessionId and tones should be of string type");
                    if (n.length > 20) throw new Error("tones string must be upto 20 characters");
                    var r = /[^0-9A-D*#]/g, i = n.match(r);
                    if (i && i[0]) throw new Error("".concat(i[0], " is not valid DTMF tone"));
                }(e), new Promise(function(n, r) {
                    t.sendMessageToCallMachine(Aa({
                        action: "send-dtmf"
                    }, e), function(e) {
                        e.error ? r(e.error) : n(e);
                    });
                });
            }), function(e) {
                return C.apply(this, arguments);
            })
        },
        {
            key: "getNetworkStats",
            value: function() {
                var e = this;
                if (this._callState !== oi) {
                    return Promise.resolve(Aa({
                        stats: {
                            latest: {}
                        }
                    }, this._network));
                }
                return new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-calc-stats"
                    }, function(n) {
                        t(Aa(Aa({}, e._network), {}, {
                            stats: n.stats
                        }));
                    });
                });
            }
        },
        {
            key: "testWebsocketConnectivity",
            value: (M = p(function*() {
                var e = this;
                if (ec(this._testCallInProgress, "testWebsocketConnectivity()"), this.needsLoad()) try {
                    yield this.load();
                } catch (e) {
                    return Promise.reject(e);
                }
                return new Promise(function(t, n) {
                    e.sendMessageToCallMachine({
                        action: "test-websocket-connectivity"
                    }, function(e) {
                        e.error ? n(e.error) : t(e.results);
                    });
                });
            }), function() {
                return M.apply(this, arguments);
            })
        },
        {
            key: "abortTestWebsocketConnectivity",
            value: function() {
                this.sendMessageToCallMachine({
                    action: "abort-test-websocket-connectivity"
                });
            }
        },
        {
            key: "_validateVideoTrackForNetworkTests",
            value: function(e) {
                return e ? e instanceof MediaStreamTrack ? !!va(e, {
                    isLocalScreenVideo: !1
                }) || (console.error("Video track is not playable. This test needs a live video track."), !1) : (console.error("Video track needs to be of type `MediaStreamTrack`."), !1) : (console.error("Missing video track. You must provide a video track in order to run this test."), !1);
            }
        },
        {
            key: "testCallQuality",
            value: (k = p(function*() {
                var t = this;
                rc(), tc(this._callObjectMode, "testCallQuality()"), Za(this._callMachineInitialized, "testCallQuality()", null, !0), Xa(this._callState, this._isPreparingToJoin, "testCallQuality()");
                var n = this._testCallAlreadyInProgress, r = function(e) {
                    n || (t._testCallInProgress = e);
                };
                if (r(!0), this.needsLoad()) try {
                    var i = this._callState;
                    yield this.load(), this._callState = i;
                } catch (e) {
                    return r(!1), Promise.reject(e);
                }
                return new Promise(function(n) {
                    t.sendMessageToCallMachine({
                        action: "test-call-quality",
                        dailyJsVersion: t.properties.dailyJsVersion
                    }, function(i) {
                        var o = i.results, s = o.result, a = e(o, Ta);
                        if ("failed" === s) {
                            var c, l = Aa({}, a);
                            null !== (c = a.error) && void 0 !== c && c.details ? (a.error.details = JSON.parse(a.error.details), l.error = Aa(Aa({}, l.error), {}, {
                                details: Aa({}, l.error.details)
                            }), l.error.details.duringTest = "testCallQuality") : (l.error = l.error ? Aa({}, l.error) : {}, l.error.details = {
                                duringTest: "testCallQuality"
                            }), t._maybeSendToSentry(l);
                        }
                        r(!1), n(Aa({
                            result: s
                        }, a));
                    });
                });
            }), function() {
                return k.apply(this, arguments);
            })
        },
        {
            key: "stopTestCallQuality",
            value: function() {
                this.sendMessageToCallMachine({
                    action: "stop-test-call-quality"
                });
            }
        },
        {
            key: "testConnectionQuality",
            value: (w = p(function*(e) {
                var t;
                is() ? (console.warn("testConnectionQuality() is deprecated: use testPeerToPeerCallQuality() instead"), t = yield this.testPeerToPeerCallQuality(e)) : (console.warn("testConnectionQuality() is deprecated: use testCallQuality() instead"), t = yield this.testCallQuality());
                var n = {
                    result: t.result,
                    secondsElapsed: t.secondsElapsed
                };
                return t.data && (n.data = {
                    maxRTT: t.data.maxRoundTripTime,
                    packetLoss: t.data.avgRecvPacketLoss
                }), n;
            }), function(e) {
                return w.apply(this, arguments);
            })
        },
        {
            key: "testPeerToPeerCallQuality",
            value: (_ = p(function*(e) {
                var t = this;
                if (ec(this._testCallInProgress, "testPeerToPeerCallQuality()"), this.needsLoad()) try {
                    yield this.load();
                } catch (e) {
                    return Promise.reject(e);
                }
                var n = e.videoTrack, r = e.duration;
                if (!this._validateVideoTrackForNetworkTests(n)) throw new Error("Video track error");
                return this._sharedTracks.videoTrackForConnectionQualityTest = n, new Promise(function(e, n) {
                    t.sendMessageToCallMachine({
                        action: "test-p2p-call-quality",
                        duration: r
                    }, function(t) {
                        t.error ? n(t.error) : e(t.results);
                    });
                });
            }), function(e) {
                return _.apply(this, arguments);
            })
        },
        {
            key: "stopTestConnectionQuality",
            value: function() {
                is() ? (console.warn("stopTestConnectionQuality() is deprecated: use testPeerToPeerCallQuality() and stopTestPeerToPeerCallQuality() instead"), this.stopTestPeerToPeerCallQuality()) : (console.warn("stopTestConnectionQuality() is deprecated: use testCallQuality() and stopTestCallQuality() instead"), this.stopTestCallQuality());
            }
        },
        {
            key: "stopTestPeerToPeerCallQuality",
            value: function() {
                this.sendMessageToCallMachine({
                    action: "stop-test-p2p-call-quality"
                });
            }
        },
        {
            key: "testNetworkConnectivity",
            value: (y = p(function*(e) {
                var t = this;
                if (ec(this._testCallInProgress, "testNetworkConnectivity()"), this.needsLoad()) try {
                    yield this.load();
                } catch (e) {
                    return Promise.reject(e);
                }
                if (!this._validateVideoTrackForNetworkTests(e)) throw new Error("Video track error");
                return this._sharedTracks.videoTrackForNetworkConnectivityTest = e, new Promise(function(e, n) {
                    t.sendMessageToCallMachine({
                        action: "test-network-connectivity"
                    }, function(t) {
                        t.error ? n(t.error) : e(t.results);
                    });
                });
            }), function(e) {
                return y.apply(this, arguments);
            })
        },
        {
            key: "abortTestNetworkConnectivity",
            value: function() {
                this.sendMessageToCallMachine({
                    action: "abort-test-network-connectivity"
                });
            }
        },
        {
            key: "getCpuLoadStats",
            value: function() {
                var e = this;
                return new Promise(function(t) {
                    if (e._callState === oi) {
                        e.sendMessageToCallMachine({
                            action: "get-cpu-load-stats"
                        }, function(e) {
                            t(e.cpuStats);
                        });
                    } else t({
                        cpuLoadState: void 0,
                        cpuLoadStateReason: void 0,
                        stats: {}
                    });
                });
            }
        },
        {
            key: "_validateEncodingLayerHasValidProperties",
            value: function(e) {
                var t;
                if (!((null === (t = Object.keys(e)) || void 0 === t ? void 0 : t.length) > 0)) throw new Error("Empty encoding is not allowed. At least one of these valid keys should be specified:" + Object.values(Ua));
            }
        },
        {
            key: "_validateVideoSendSettings",
            value: function(e, t) {
                var r = "screenVideo" === e ? [
                    "default-screen-video",
                    "detail-optimized",
                    "motion-optimized",
                    "motion-and-detail-balanced"
                ] : [
                    "default-video",
                    "bandwidth-optimized",
                    "bandwidth-and-quality-balanced",
                    "quality-optimized",
                    "adaptive-2-layers",
                    "adaptive-3-layers"
                ], i = "Video send settings should be either an object or one of the supported presets: ".concat(r.join());
                if ("string" == typeof t) {
                    if (!r.includes(t)) throw new Error(i);
                } else {
                    if ("object" !== n(t)) throw new Error(i);
                    if (!t.maxQuality && !t.encodings && void 0 === t.allowAdaptiveLayers) throw new Error("Video send settings must contain at least maxQuality, allowAdaptiveLayers or encodings attribute");
                    if (t.maxQuality && -1 === [
                        "low",
                        "medium",
                        "high"
                    ].indexOf(t.maxQuality)) throw new Error("maxQuality must be either low, medium or high");
                    if (t.encodings) {
                        var o = !1;
                        switch(Object.keys(t.encodings).length){
                            case 1:
                                o = !t.encodings.low;
                                break;
                            case 2:
                                o = !t.encodings.low || !t.encodings.medium;
                                break;
                            case 3:
                                o = !t.encodings.low || !t.encodings.medium || !t.encodings.high;
                                break;
                            default:
                                o = !0;
                        }
                        if (o) throw new Error("Encodings must be defined as: low, low and medium, or low, medium and high.");
                        t.encodings.low && this._validateEncodingLayerHasValidProperties(t.encodings.low), t.encodings.medium && this._validateEncodingLayerHasValidProperties(t.encodings.medium), t.encodings.high && this._validateEncodingLayerHasValidProperties(t.encodings.high);
                    }
                }
            }
        },
        {
            key: "validateUpdateSendSettings",
            value: function(e) {
                var t = this;
                if (!e || 0 === Object.keys(e).length) throw new Error("Send settings must contain at least information for one track!");
                Object.entries(e).forEach(function(e) {
                    var n = f(e, 2), r = n[0], i = n[1];
                    t._validateVideoSendSettings(r, i);
                });
            }
        },
        {
            key: "updateSendSettings",
            value: function(e) {
                var t = this;
                return this.validateUpdateSendSettings(e), this.needsLoad() ? (this._preloadCache.sendSettings = e, {
                    sendSettings: this._preloadCache.sendSettings
                }) : new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "update-send-settings",
                        sendSettings: e
                    }, function(e) {
                        e.error ? r(e.error) : n(e.sendSettings);
                    });
                });
            }
        },
        {
            key: "getSendSettings",
            value: function() {
                return this._sendSettings || this._preloadCache.sendSettings;
            }
        },
        {
            key: "getLocalAudioLevel",
            value: function() {
                return this._localAudioLevel;
            }
        },
        {
            key: "getRemoteParticipantsAudioLevel",
            value: function() {
                return this._remoteParticipantsAudioLevel;
            }
        },
        {
            key: "getActiveSpeaker",
            value: function() {
                return rc(), this._activeSpeaker;
            }
        },
        {
            key: "setActiveSpeakerMode",
            value: function(e) {
                return rc(), this.sendMessageToCallMachine({
                    action: "set-active-speaker-mode",
                    enabled: e
                }), this;
            }
        },
        {
            key: "activeSpeakerMode",
            value: function() {
                return rc(), this._activeSpeakerMode;
            }
        },
        {
            key: "subscribeToTracksAutomatically",
            value: function() {
                return this._preloadCache.subscribeToTracksAutomatically;
            }
        },
        {
            key: "setSubscribeToTracksAutomatically",
            value: function(e) {
                return Ka(this._callState, "setSubscribeToTracksAutomatically()", "Use the subscribeToTracksAutomatically configuration property."), this._preloadCache.subscribeToTracksAutomatically = e, this.sendMessageToCallMachine({
                    action: "daily-method-subscribe-to-tracks-automatically",
                    enabled: e
                }), this;
            }
        },
        {
            key: "enumerateDevices",
            value: (m = p(function*() {
                var e = this;
                if (this._callObjectMode) {
                    var t = yield navigator.mediaDevices.enumerateDevices();
                    return "Firefox" === ms() && ys().major > 115 && ys().major < 123 && (t = t.filter(function(e) {
                        return "audiooutput" !== e.kind;
                    })), {
                        devices: t.map(function(e) {
                            var t = JSON.parse(JSON.stringify(e));
                            if (!is() && "videoinput" === e.kind && e.getCapabilities) {
                                var n, r = e.getCapabilities();
                                t.facing = (null == r || null === (n = r.facingMode) || void 0 === n ? void 0 : n.length) >= 1 ? r.facingMode[0] : void 0;
                            }
                            return t;
                        })
                    };
                }
                return new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "enumerate-devices"
                    }, function(e) {
                        t({
                            devices: e.devices
                        });
                    });
                });
            }), function() {
                return m.apply(this, arguments);
            })
        },
        {
            key: "sendAppMessage",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "*";
                if (Ka(this._callState, "sendAppMessage()"), JSON.stringify(e).length > this._maxAppMessageSize) throw new Error("Message data too large. Max size is " + this._maxAppMessageSize);
                return this.sendMessageToCallMachine({
                    action: "app-msg",
                    data: e,
                    to: t
                }), this;
            }
        },
        {
            key: "addFakeParticipant",
            value: function(e) {
                return rc(), Ka(this._callState, "addFakeParticipant()"), this.sendMessageToCallMachine(Aa({
                    action: "add-fake-participant"
                }, e)), this;
            }
        },
        {
            key: "setShowNamesMode",
            value: function(e) {
                return nc(this._callObjectMode, "setShowNamesMode()"), rc(), e && "always" !== e && "never" !== e ? (console.error('setShowNamesMode argument should be "always", "never", or false'), this) : (this.sendMessageToCallMachine({
                    action: "set-show-names",
                    mode: e
                }), this);
            }
        },
        {
            key: "setShowLocalVideo",
            value: function() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                return nc(this._callObjectMode, "setShowLocalVideo()"), rc(), Ka(this._callState, "setShowLocalVideo()"), "boolean" != typeof e ? (console.error("setShowLocalVideo only accepts a boolean value"), this) : (this.sendMessageToCallMachine({
                    action: "set-show-local-video",
                    show: e
                }), this._showLocalVideo = e, this);
            }
        },
        {
            key: "showLocalVideo",
            value: function() {
                return nc(this._callObjectMode, "showLocalVideo()"), rc(), this._showLocalVideo;
            }
        },
        {
            key: "setShowParticipantsBar",
            value: function() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                return nc(this._callObjectMode, "setShowParticipantsBar()"), rc(), Ka(this._callState, "setShowParticipantsBar()"), "boolean" != typeof e ? (console.error("setShowParticipantsBar only accepts a boolean value"), this) : (this.sendMessageToCallMachine({
                    action: "set-show-participants-bar",
                    show: e
                }), this._showParticipantsBar = e, this);
            }
        },
        {
            key: "showParticipantsBar",
            value: function() {
                return nc(this._callObjectMode, "showParticipantsBar()"), rc(), this._showParticipantsBar;
            }
        },
        {
            key: "customIntegrations",
            value: function() {
                return rc(), nc(this._callObjectMode, "customIntegrations()"), this._customIntegrations;
            }
        },
        {
            key: "setCustomIntegrations",
            value: function(e) {
                return rc(), nc(this._callObjectMode, "setCustomIntegrations()"), Ka(this._callState, "setCustomIntegrations()"), gc(e) ? (this.sendMessageToCallMachine({
                    action: "set-custom-integrations",
                    integrations: e
                }), this._customIntegrations = e, this) : this;
            }
        },
        {
            key: "startCustomIntegrations",
            value: function(e) {
                var t = this;
                if (rc(), nc(this._callObjectMode, "startCustomIntegrations()"), Ka(this._callState, "startCustomIntegrations()"), Array.isArray(e) && e.some(function(e) {
                    return "string" != typeof e;
                }) || !Array.isArray(e) && "string" != typeof e) return console.error("startCustomIntegrations() only accepts string | string[]"), this;
                var n = "string" == typeof e ? [
                    e
                ] : e, r = n.filter(function(e) {
                    return !(e in t._customIntegrations);
                });
                return r.length ? (console.error("Can't find custom integration(s): \"".concat(r.join(", "), '"')), this) : (this.sendMessageToCallMachine({
                    action: "start-custom-integrations",
                    ids: n
                }), this);
            }
        },
        {
            key: "stopCustomIntegrations",
            value: function(e) {
                var t = this;
                if (rc(), nc(this._callObjectMode, "stopCustomIntegrations()"), Ka(this._callState, "stopCustomIntegrations()"), Array.isArray(e) && e.some(function(e) {
                    return "string" != typeof e;
                }) || !Array.isArray(e) && "string" != typeof e) return console.error("stopCustomIntegrations() only accepts string | string[]"), this;
                var n = "string" == typeof e ? [
                    e
                ] : e, r = n.filter(function(e) {
                    return !(e in t._customIntegrations);
                });
                return r.length ? (console.error("Can't find custom integration(s): \"".concat(r.join(", "), '"')), this) : (this.sendMessageToCallMachine({
                    action: "stop-custom-integrations",
                    ids: n
                }), this);
            }
        },
        {
            key: "customTrayButtons",
            value: function() {
                return nc(this._callObjectMode, "customTrayButtons()"), rc(), this._customTrayButtons;
            }
        },
        {
            key: "updateCustomTrayButtons",
            value: function(e) {
                return nc(this._callObjectMode, "updateCustomTrayButtons()"), rc(), Ka(this._callState, "updateCustomTrayButtons()"), vc(e) ? (this.sendMessageToCallMachine({
                    action: "update-custom-tray-buttons",
                    btns: e
                }), this._customTrayButtons = e, this) : (console.error("updateCustomTrayButtons only accepts a dictionary of the type ".concat(JSON.stringify($a))), this);
            }
        },
        {
            key: "theme",
            value: function() {
                return nc(this._callObjectMode, "theme()"), this.properties.theme;
            }
        },
        {
            key: "setTheme",
            value: function(e) {
                var t = this;
                return nc(this._callObjectMode, "setTheme()"), new Promise(function(n, r) {
                    try {
                        t.validateProperties({
                            theme: e
                        }), t.properties.theme = Aa({}, e), t.sendMessageToCallMachine({
                            action: "set-theme",
                            theme: t.properties.theme
                        });
                        try {
                            t.emitDailyJSEvent({
                                action: Ui,
                                theme: t.properties.theme
                            });
                        } catch (e) {
                            console.log("could not emit 'theme-updated'", e);
                        }
                        n(t.properties.theme);
                    } catch (e) {
                        r(e);
                    }
                });
            }
        },
        {
            key: "requestFullscreen",
            value: (g = p(function*() {
                if (rc(), this._iframe && !document.fullscreenElement && as()) try {
                    (yield this._iframe.requestFullscreen) ? this._iframe.requestFullscreen() : this._iframe.webkitRequestFullscreen();
                } catch (e) {
                    console.log("could not make video call fullscreen", e);
                }
            }), function() {
                return g.apply(this, arguments);
            })
        },
        {
            key: "exitFullscreen",
            value: function() {
                rc(), document.fullscreenElement ? document.exitFullscreen() : document.webkitFullscreenElement && document.webkitExitFullscreen();
            }
        },
        {
            key: "getSidebarView",
            value: (v = p(function*() {
                var e = this;
                return this._callObjectMode ? (console.error("getSidebarView is not available in callObject mode"), Promise.resolve(null)) : new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "get-sidebar-view"
                    }, function(e) {
                        t(e.view);
                    });
                });
            }), function() {
                return v.apply(this, arguments);
            })
        },
        {
            key: "setSidebarView",
            value: function(e) {
                return this._callObjectMode ? (console.error("setSidebarView is not available in callObject mode"), this) : (this.sendMessageToCallMachine({
                    action: "set-sidebar-view",
                    view: e
                }), this);
            }
        },
        {
            key: "room",
            value: (h = p(function*() {
                var e = this, t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).includeRoomConfigDefaults, n = void 0 === t || t;
                return this._accessState.access === fi || this.needsLoad() ? this.properties.url ? {
                    roomUrlPendingJoin: this.properties.url
                } : null : new Promise(function(t) {
                    e.sendMessageToCallMachine({
                        action: "lib-room-info",
                        includeRoomConfigDefaults: n
                    }, function(e) {
                        delete e.action, delete e.callbackStamp, t(e);
                    });
                });
            }), function() {
                return h.apply(this, arguments);
            })
        },
        {
            key: "geo",
            value: (d = p(function*() {
                try {
                    var e = yield fetch("https://gs.daily.co/_ks_/x-swsl/:");
                    return {
                        current: (yield e.json()).geo
                    };
                } catch (e) {
                    return console.error("geo lookup failed", e), {
                        current: ""
                    };
                }
            }), function() {
                return d.apply(this, arguments);
            })
        },
        {
            key: "setNetworkTopology",
            value: (c = p(function*(e) {
                var t = this;
                return rc(), Ka(this._callState, "setNetworkTopology()"), new Promise(function(n, r) {
                    t.sendMessageToCallMachine({
                        action: "set-network-topology",
                        opts: e
                    }, function(e) {
                        e.error ? r({
                            error: e.error
                        }) : n({
                            workerId: e.workerId
                        });
                    });
                });
            }), function(e) {
                return c.apply(this, arguments);
            })
        },
        {
            key: "getNetworkTopology",
            value: (i = p(function*() {
                var e = this;
                return new Promise(function(t, n) {
                    e.needsLoad() && t({
                        topology: "none"
                    }), e.sendMessageToCallMachine({
                        action: "get-network-topology"
                    }, function(e) {
                        e.error ? n({
                            error: e.error
                        }) : t({
                            topology: e.topology
                        });
                    });
                });
            }), function() {
                return i.apply(this, arguments);
            })
        },
        {
            key: "setPlayNewParticipantSound",
            value: function(e) {
                if (rc(), "number" != typeof e && !0 !== e && !1 !== e) throw new Error("argument to setShouldPlayNewParticipantSound should be true, false, or a number, but is ".concat(e));
                this.sendMessageToCallMachine({
                    action: "daily-method-set-play-ding",
                    arg: e
                });
            }
        },
        {
            key: "on",
            value: function(e, t) {
                return b.prototype.on.call(this, e, t);
            }
        },
        {
            key: "once",
            value: function(e, t) {
                return b.prototype.once.call(this, e, t);
            }
        },
        {
            key: "off",
            value: function(e, t) {
                return b.prototype.off.call(this, e, t);
            }
        },
        {
            key: "validateProperties",
            value: function(e) {
                var t, n;
                if (null != e && null !== (t = e.dailyConfig) && void 0 !== t && t.userMediaAudioConstraints) {
                    var r, i;
                    is() || console.warn("userMediaAudioConstraints is deprecated. You can override constraints with inputSettings.audio.settings, found in DailyCallOptions.");
                    var o = e.inputSettings || {};
                    o.audio = (null === (r = e.inputSettings) || void 0 === r ? void 0 : r.audio) || {}, o.audio.settings = (null === (i = e.inputSettings) || void 0 === i || null === (i = i.audio) || void 0 === i ? void 0 : i.settings) || {}, o.audio.settings = Aa(Aa({}, o.audio.settings), e.dailyConfig.userMediaAudioConstraints), e.inputSettings = o, delete e.dailyConfig.userMediaAudioConstraints;
                }
                if (null != e && null !== (n = e.dailyConfig) && void 0 !== n && n.userMediaVideoConstraints) {
                    var s, a;
                    is() || console.warn("userMediaVideoConstraints is deprecated. You can override constraints with inputSettings.video.settings, found in DailyCallOptions.");
                    var c = e.inputSettings || {};
                    c.video = (null === (s = e.inputSettings) || void 0 === s ? void 0 : s.video) || {}, c.video.settings = (null === (a = e.inputSettings) || void 0 === a || null === (a = a.video) || void 0 === a ? void 0 : a.settings) || {}, c.video.settings = Aa(Aa({}, c.video.settings), e.dailyConfig.userMediaVideoConstraints), e.inputSettings = c, delete e.dailyConfig.userMediaVideoConstraints;
                }
                for(var l in e)if (za[l]) {
                    if (za[l].validate && !za[l].validate(e[l], this)) throw new Error("property '".concat(l, "': ").concat(za[l].help));
                } else console.warn("Ignoring unrecognized property '".concat(l, "'")), delete e[l];
            }
        },
        {
            key: "assembleMeetingUrl",
            value: function() {
                var e, t, n = Aa(Aa({}, this.properties), {}, {
                    emb: this.callClientId,
                    embHref: encodeURIComponent(window.location.href),
                    proxy: null !== (e = this.properties.dailyConfig) && void 0 !== e && e.proxyUrl ? encodeURIComponent(null === (t = this.properties.dailyConfig) || void 0 === t ? void 0 : t.proxyUrl) : void 0
                }), r = n.url.match(/\?/) ? "&" : "?";
                return n.url + r + Object.keys(za).filter(function(e) {
                    return za[e].queryString && void 0 !== n[e];
                }).map(function(e) {
                    return "".concat(za[e].queryString, "=").concat(n[e]);
                }).join("&");
            }
        },
        {
            key: "needsLoad",
            value: function() {
                return [
                    ti,
                    ni,
                    si,
                    ai
                ].includes(this._callState);
            }
        },
        {
            key: "sendMessageToCallMachine",
            value: function(e, t) {
                if (this._destroyed && (this._logUseAfterDestroy(), this.strictMode)) throw new Error("Use after destroy");
                this._messageChannel.sendMessageToCallMachine(e, t, this.callClientId, this._iframe);
            }
        },
        {
            key: "forwardPackagedMessageToCallMachine",
            value: function(e) {
                this._messageChannel.forwardPackagedMessageToCallMachine(e, this._iframe, this.callClientId);
            }
        },
        {
            key: "addListenerForPackagedMessagesFromCallMachine",
            value: function(e) {
                return this._messageChannel.addListenerForPackagedMessagesFromCallMachine(e, this.callClientId);
            }
        },
        {
            key: "removeListenerForPackagedMessagesFromCallMachine",
            value: function(e) {
                this._messageChannel.removeListenerForPackagedMessagesFromCallMachine(e);
            }
        },
        {
            key: "handleMessageFromCallMachine",
            value: function(t) {
                switch(t.action){
                    case Fi:
                        this.sendMessageToCallMachine(Aa({
                            action: Bi
                        }, this.properties));
                        break;
                    case "call-machine-initialized":
                        this._callMachineInitialized = !0;
                        var n = {
                            action: Go,
                            level: "log",
                            code: 1011,
                            stats: {
                                event: "bundle load",
                                time: "no-op" === this._bundleLoadTime ? 0 : this._bundleLoadTime,
                                preLoaded: "no-op" === this._bundleLoadTime,
                                url: B(this.properties.dailyConfig)
                            }
                        };
                        this.sendMessageToCallMachine(n), this._delayDuplicateInstanceLog && this._logDuplicateInstanceAttempt();
                        break;
                    case $i:
                        this._loadedCallback && (this._loadedCallback(), this._loadedCallback = null), this.emitDailyJSEvent(t);
                        break;
                    case Hi:
                        var r, i = Aa({}, t);
                        delete i.internal, this._maxAppMessageSize = (null === (r = t.internal) || void 0 === r ? void 0 : r._maxAppMessageSize) || $o, this._joinedCallback && (this._joinedCallback(t.participants), this._joinedCallback = null), this.emitDailyJSEvent(i);
                        break;
                    case Qi:
                    case Ki:
                        if (this._callState === si) return;
                        if (t.participant && t.participant.session_id) {
                            var o = t.participant.local ? "local" : t.participant.session_id;
                            if (this._callObjectMode) {
                                var s = this._callMachine().store;
                                Zs(t.participant, s), ea(t.participant, s), na(t.participant, this._participants[o], s);
                            }
                            try {
                                this.maybeParticipantTracksStopped(this._participants[o], t.participant), this.maybeParticipantTracksStarted(this._participants[o], t.participant), this.maybeEventRecordingStopped(this._participants[o], t.participant), this.maybeEventRecordingStarted(this._participants[o], t.participant);
                            } catch (e) {
                                console.error("track events error", e);
                            }
                            this.compareEqualForParticipantUpdateEvent(t.participant, this._participants[o]) || (this._participants[o] = Aa({}, t.participant), this.toggleParticipantAudioBasedOnNativeAudioFocus(), this.emitDailyJSEvent(t));
                        }
                        break;
                    case Yi:
                        if (t.participant && t.participant.session_id) {
                            var a = this._participants[t.participant.session_id];
                            a && this.maybeParticipantTracksStopped(a, null), delete this._participants[t.participant.session_id], this.emitDailyJSEvent(t);
                        }
                        break;
                    case Xi:
                        S(this._participantCounts, t.participantCounts) || (this._participantCounts = t.participantCounts, this.emitDailyJSEvent(t));
                        break;
                    case Zi:
                        var c = {
                            access: t.access
                        };
                        t.awaitingAccess && (c.awaitingAccess = t.awaitingAccess), S(this._accessState, c) || (this._accessState = c, this.emitDailyJSEvent(t));
                        break;
                    case eo:
                        if (t.meetingSession) {
                            this._meetingSessionSummary = t.meetingSession, this.emitDailyJSEvent(t);
                            var l = Aa(Aa({}, t), {}, {
                                action: "meeting-session-updated"
                            });
                            this.emitDailyJSEvent(l);
                        }
                        break;
                    case Jo:
                        var u;
                        this._iframe && !t.preserveIframe && (this._iframe.src = ""), this._updateCallState(ai), this.resetMeetingDependentVars(), this._loadedCallback && (this._loadedCallback(t.errorMsg), this._loadedCallback = null), t.preserveIframe;
                        var d = e(t, Oa);
                        null != d && null !== (u = d.error) && void 0 !== u && u.details && (d.error.details = JSON.parse(d.error.details)), this._maybeSendToSentry(t), this._joinedCallback && (this._joinedCallback(null, d), this._joinedCallback = null), this.emitDailyJSEvent(d);
                        break;
                    case Gi:
                        this._callState !== ai && this._updateCallState(si), this.resetMeetingDependentVars(), this._resolveLeave && (this._resolveLeave(), this._resolveLeave = null), this.emitDailyJSEvent(t);
                        break;
                    case "selected-devices-updated":
                        t.devices && this.emitDailyJSEvent(t);
                        break;
                    case Oo:
                        var p = t.state, h = t.threshold, f = t.quality, v = p.state, g = p.reasons;
                        v === this._network.networkState && S(g, this._network.networkStateReasons) && h === this._network.threshold && f === this._network.quality || (this._network.networkState = v, this._network.networkStateReasons = g, this._network.quality = f, this._network.threshold = h, t.networkState = v, g.length && (t.networkStateReasons = g), delete t.state, this.emitDailyJSEvent(t));
                        break;
                    case Ao:
                        t && t.cpuLoadState && this.emitDailyJSEvent(t);
                        break;
                    case jo:
                        t && void 0 !== t.faceCounts && this.emitDailyJSEvent(t);
                        break;
                    case Eo:
                        var m = t.activeSpeaker;
                        this._activeSpeaker.peerId !== m.peerId && (this._activeSpeaker.peerId = m.peerId, this.emitDailyJSEvent({
                            action: t.action,
                            activeSpeaker: this._activeSpeaker
                        }));
                        break;
                    case "show-local-video-changed":
                        if (this._callObjectMode) return;
                        var y = t.show;
                        this._showLocalVideo = y, this.emitDailyJSEvent({
                            action: t.action,
                            show: y
                        });
                        break;
                    case To:
                        var b = t.enabled;
                        this._activeSpeakerMode !== b && (this._activeSpeakerMode = b, this.emitDailyJSEvent({
                            action: t.action,
                            enabled: this._activeSpeakerMode
                        }));
                        break;
                    case ro:
                    case io:
                    case oo:
                        this._waitingParticipants = t.allWaitingParticipants, this.emitDailyJSEvent({
                            action: t.action,
                            participant: t.participant
                        });
                        break;
                    case Bo:
                        S(this._receiveSettings, t.receiveSettings) || (this._receiveSettings = t.receiveSettings, this.emitDailyJSEvent({
                            action: t.action,
                            receiveSettings: t.receiveSettings
                        }));
                        break;
                    case Uo:
                        this._maybeUpdateInputSettings(t.inputSettings);
                        break;
                    case "send-settings-updated":
                        S(this._sendSettings, t.sendSettings) || (this._sendSettings = t.sendSettings, this._preloadCache.sendSettings = null, this.emitDailyJSEvent({
                            action: t.action,
                            sendSettings: t.sendSettings
                        }));
                        break;
                    case "local-audio-level":
                        this._localAudioLevel = t.audioLevel, this._preloadCache.localAudioLevelObserver = null, this.emitDailyJSEvent(t);
                        break;
                    case "remote-participants-audio-level":
                        this._remoteParticipantsAudioLevel = t.participantsAudioLevel, this._preloadCache.remoteParticipantsAudioLevelObserver = null, this.emitDailyJSEvent(t);
                        break;
                    case _o:
                        var _ = t.session_id;
                        this._rmpPlayerState[_] = t.playerState, this.emitDailyJSEvent(t);
                        break;
                    case So:
                        delete this._rmpPlayerState[t.session_id], this.emitDailyJSEvent(t);
                        break;
                    case wo:
                        var w = t.session_id, k = this._rmpPlayerState[w];
                        k && this.compareEqualForRMPUpdateEvent(k, t.remoteMediaPlayerState) || (this._rmpPlayerState[w] = t.remoteMediaPlayerState, this.emitDailyJSEvent(t));
                        break;
                    case "custom-button-click":
                    case "sidebar-view-changed":
                    case "pip-started":
                    case "pip-stopped":
                        this.emitDailyJSEvent(t);
                        break;
                    case to:
                        var M = this._meetingSessionState.topology !== (t.meetingSessionState && t.meetingSessionState.topology);
                        this._meetingSessionState = wc(t.meetingSessionState, this._callObjectMode), (this._callObjectMode || M) && this.emitDailyJSEvent(t);
                        break;
                    case ko:
                        this._isScreenSharing = !0, this.emitDailyJSEvent(t);
                        break;
                    case Mo:
                    case Co:
                        this._isScreenSharing = !1, this.emitDailyJSEvent(t);
                        break;
                    case po:
                    case ho:
                    case fo:
                    case vo:
                    case go:
                    case co:
                    case lo:
                    case uo:
                    case qi:
                    case zi:
                    case yo:
                    case bo:
                    case "test-completed":
                    case Po:
                    case mo:
                    case Lo:
                    case Do:
                    case No:
                    case Ro:
                    case Vo:
                    case Fo:
                    case "dialin-ready":
                    case "dialin-connected":
                    case "dialin-error":
                    case "dialin-stopped":
                    case "dialin-warning":
                    case "dialout-connected":
                    case "dialout-answered":
                    case "dialout-error":
                    case "dialout-stopped":
                    case "dialout-warning":
                        this.emitDailyJSEvent(t);
                        break;
                    case "request-fullscreen":
                        this.requestFullscreen();
                        break;
                    case "request-exit-fullscreen":
                        this.exitFullscreen();
                }
            }
        },
        {
            key: "maybeEventRecordingStopped",
            value: function(e, t) {
                var n = "record";
                e && (t.local || !1 !== t[n] || e[n] === t[n] || this.emitDailyJSEvent({
                    action: ho
                }));
            }
        },
        {
            key: "maybeEventRecordingStarted",
            value: function(e, t) {
                var n = "record";
                e && (t.local || !0 !== t[n] || e[n] === t[n] || this.emitDailyJSEvent({
                    action: po
                }));
            }
        },
        {
            key: "_trackStatePlayable",
            value: function(e) {
                return !(!e || e.state !== hi);
            }
        },
        {
            key: "_trackChanged",
            value: function(e, t) {
                return !((null == e ? void 0 : e.id) === (null == t ? void 0 : t.id));
            }
        },
        {
            key: "maybeEventTrackStopped",
            value: function(e, t, n) {
                var r, i, o = null !== (r = null == t ? void 0 : t.tracks[e]) && void 0 !== r ? r : null, s = null !== (i = null == n ? void 0 : n.tracks[e]) && void 0 !== i ? i : null, a = null == o ? void 0 : o.track;
                if (a) {
                    var c = this._trackStatePlayable(o), l = this._trackStatePlayable(s), u = this._trackChanged(a, null == s ? void 0 : s.track);
                    c && (l && !u || this.emitDailyJSEvent({
                        action: ao,
                        track: a,
                        participant: null != n ? n : t,
                        type: e
                    }));
                }
            }
        },
        {
            key: "maybeEventTrackStarted",
            value: function(e, t, n) {
                var r, i, o = null !== (r = null == t ? void 0 : t.tracks[e]) && void 0 !== r ? r : null, s = null !== (i = null == n ? void 0 : n.tracks[e]) && void 0 !== i ? i : null, a = null == s ? void 0 : s.track;
                if (a) {
                    var c = this._trackStatePlayable(o), l = this._trackStatePlayable(s), u = this._trackChanged(null == o ? void 0 : o.track, a);
                    l && (c && !u || this.emitDailyJSEvent({
                        action: so,
                        track: a,
                        participant: n,
                        type: e
                    }));
                }
            }
        },
        {
            key: "maybeParticipantTracksStopped",
            value: function(e, t) {
                if (e) for(var n in e.tracks)this.maybeEventTrackStopped(n, e, t);
            }
        },
        {
            key: "maybeParticipantTracksStarted",
            value: function(e, t) {
                if (t) for(var n in t.tracks)this.maybeEventTrackStarted(n, e, t);
            }
        },
        {
            key: "compareEqualForRMPUpdateEvent",
            value: function(e, t) {
                var n, r;
                return e.state === t.state && (null === (n = e.settings) || void 0 === n ? void 0 : n.volume) === (null === (r = t.settings) || void 0 === r ? void 0 : r.volume);
            }
        },
        {
            key: "emitDailyJSEvent",
            value: function(e) {
                try {
                    e.callClientId = this.callClientId, this.emit(e.action, e);
                } catch (t) {
                    console.log("could not emit", e, t);
                }
            }
        },
        {
            key: "compareEqualForParticipantUpdateEvent",
            value: function(e, t) {
                return !!S(e, t) && (!e.videoTrack || !t.videoTrack || e.videoTrack.id === t.videoTrack.id && e.videoTrack.muted === t.videoTrack.muted && e.videoTrack.enabled === t.videoTrack.enabled) && (!e.audioTrack || !t.audioTrack || e.audioTrack.id === t.audioTrack.id && e.audioTrack.muted === t.audioTrack.muted && e.audioTrack.enabled === t.audioTrack.enabled);
            }
        },
        {
            key: "nativeUtils",
            value: function() {
                return is() ? "undefined" == typeof DailyNativeUtils ? (console.warn("in React Native, DailyNativeUtils is expected to be available"), null) : DailyNativeUtils : null;
            }
        },
        {
            key: "updateIsPreparingToJoin",
            value: function(e) {
                this._updateCallState(this._callState, e);
            }
        },
        {
            key: "_updateCallState",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this._isPreparingToJoin;
                if (e !== this._callState || t !== this._isPreparingToJoin) {
                    var n = this._callState, r = this._isPreparingToJoin;
                    this._callState = e, this._isPreparingToJoin = t;
                    var i = this._callState === oi;
                    this.updateShowAndroidOngoingMeetingNotification(i);
                    var o = Ya(n, r), s = Ya(this._callState, this._isPreparingToJoin);
                    o !== s && (this.updateKeepDeviceAwake(s), this.updateDeviceAudioMode(s), this.updateNoOpRecordingEnsuringBackgroundContinuity(s));
                }
            }
        },
        {
            key: "resetMeetingDependentVars",
            value: function() {
                this._participants = {}, this._participantCounts = Fa, this._waitingParticipants = {}, this._activeSpeaker = {}, this._activeSpeakerMode = !1, this._didPreAuth = !1, this._accessState = {
                    access: fi
                }, this._finalSummaryOfPrevSession = this._meetingSessionSummary, this._meetingSessionSummary = {}, this._meetingSessionState = wc(Ra, this._callObjectMode), this._isScreenSharing = !1, this._receiveSettings = {}, this._inputSettings = void 0, this._sendSettings = {}, this._localAudioLevel = 0, this._isLocalAudioLevelObserverRunning = !1, this._remoteParticipantsAudioLevel = {}, this._isRemoteParticipantsAudioLevelObserverRunning = !1, this._maxAppMessageSize = $o, this._callMachineInitialized = !1, this._bundleLoadTime = void 0, this._preloadCache;
            }
        },
        {
            key: "updateKeepDeviceAwake",
            value: function(e) {
                is() && this.nativeUtils().setKeepDeviceAwake(e, this.callClientId);
            }
        },
        {
            key: "updateDeviceAudioMode",
            value: function(e) {
                if (is() && !this.disableReactNativeAutoDeviceManagement("audio")) {
                    var t = e ? this._nativeInCallAudioMode : "idle";
                    this.nativeUtils().setAudioMode(t);
                }
            }
        },
        {
            key: "updateShowAndroidOngoingMeetingNotification",
            value: function(e) {
                if (is() && this.nativeUtils().setShowOngoingMeetingNotification) {
                    var t, n, r, i;
                    if (this.properties.reactNativeConfig && this.properties.reactNativeConfig.androidInCallNotification) {
                        var o = this.properties.reactNativeConfig.androidInCallNotification;
                        t = o.title, n = o.subtitle, r = o.iconName, i = o.disableForCustomOverride;
                    }
                    i && (e = !1), this.nativeUtils().setShowOngoingMeetingNotification(e, t, n, r, this.callClientId);
                }
            }
        },
        {
            key: "updateNoOpRecordingEnsuringBackgroundContinuity",
            value: function(e) {
                is() && this.nativeUtils().enableNoOpRecordingEnsuringBackgroundContinuity && this.nativeUtils().enableNoOpRecordingEnsuringBackgroundContinuity(e);
            }
        },
        {
            key: "toggleParticipantAudioBasedOnNativeAudioFocus",
            value: function() {
                var e;
                if (is()) {
                    var t = null === (e = this._callMachine()) || void 0 === e || null === (e = e.store) || void 0 === e ? void 0 : e.getState();
                    for(var n in null == t ? void 0 : t.streams){
                        var r = t.streams[n];
                        r && r.pendingTrack && "audio" === r.pendingTrack.kind && (r.pendingTrack.enabled = this._hasNativeAudioFocus);
                    }
                }
            }
        },
        {
            key: "disableReactNativeAutoDeviceManagement",
            value: function(e) {
                return this.properties.reactNativeConfig && this.properties.reactNativeConfig.disableAutoDeviceManagement && this.properties.reactNativeConfig.disableAutoDeviceManagement[e];
            }
        },
        {
            key: "absoluteUrl",
            value: function(e) {
                if (void 0 !== e) {
                    var t = document.createElement("a");
                    return t.href = e, t.href;
                }
            }
        },
        {
            key: "sayHello",
            value: function() {
                var e = "hello, world.";
                return console.log(e), e;
            }
        },
        {
            key: "_logUseAfterDestroy",
            value: function() {
                var e = Object.values(La)[0];
                if (this.needsLoad()) {
                    if (e && !e.needsLoad()) {
                        var t = {
                            action: Go,
                            level: "error",
                            code: this.strictMode ? 9995 : 9997
                        };
                        e.sendMessageToCallMachine(t);
                    } else if (!this.strictMode) {
                        console.error("You are are attempting to use a call instance that was previously destroyed, which is unsupported. Please remove `strictMode: false` from your constructor properties to enable strict mode to track down and fix this unsupported usage.");
                    }
                } else {
                    var n = {
                        action: Go,
                        level: "error",
                        code: this.strictMode ? 9995 : 9997
                    };
                    this._messageChannel.sendMessageToCallMachine(n, null, this.callClientId, this._iframe);
                }
            }
        },
        {
            key: "_logDuplicateInstanceAttempt",
            value: function() {
                for(var e = 0, t = Object.values(La); e < t.length; e++){
                    var n = t[e];
                    n._callMachineInitialized ? (n.sendMessageToCallMachine({
                        action: Go,
                        level: "warn",
                        code: this.allowMultipleCallInstances ? 9993 : 9992
                    }), n._delayDuplicateInstanceLog = !1) : n._delayDuplicateInstanceLog = !0;
                }
            }
        },
        {
            key: "_maybeSendToSentry",
            value: function(e) {
                var t, n, i, o;
                if (null !== (t = e.error) && void 0 !== t && t.type) {
                    if (![
                        Pi,
                        Ti,
                        Ci
                    ].includes(e.error.type)) return;
                    if (e.error.type === Ci && e.error.msg.includes("deleted")) return;
                }
                var s = null !== (n = this.properties) && void 0 !== n && n.url ? new URL(this.properties.url) : void 0, a = "production";
                s && s.host.includes(".staging.daily") && (a = "staging");
                var c, l, u, d, p, h = (function(e) {
                    const t = [
                        Ln(),
                        In(),
                        qr(),
                        Jr(),
                        Kr(),
                        ei(),
                        $n(),
                        Zr()
                    ];
                    return !1 !== e.autoSessionTracking && t.push(Qr()), t;
                })({}).filter(function(e) {
                    return ![
                        "BrowserApiErrors",
                        "Breadcrumbs",
                        "GlobalHandlers"
                    ].includes(e.name);
                }), f = new mr({
                    dsn: "https://f10f1c81e5d44a4098416c0867a8b740@o77906.ingest.sentry.io/168844",
                    transport: Ir,
                    stackParser: Br,
                    integrations: h,
                    environment: a
                }), v = new ut;
                if (v.setClient(f), f.init(), this.session_id && v.setExtra("sessionId", this.session_id), this.properties) {
                    var g = Aa({}, this.properties);
                    g.userName = g.userName ? "[Filtered]" : void 0, g.userData = g.userData ? "[Filtered]" : void 0, g.token = g.token ? "[Filtered]" : void 0, v.setExtra("properties", g);
                }
                if (s) {
                    var m = s.searchParams.get("domain");
                    if (!m) {
                        var y = s.host.match(/(.*?)\./);
                        m = y && y[1] || "";
                    }
                    m && v.setTag("domain", m);
                }
                e.error && (v.setTag("fatalErrorType", e.error.type), v.setExtra("errorDetails", e.error.details), (null === (c = e.error.details) || void 0 === c ? void 0 : c.uri) && v.setTag("serverAddress", e.error.details.uri), (null === (l = e.error.details) || void 0 === l ? void 0 : l.workerGroup) && v.setTag("workerGroup", e.error.details.workerGroup), (null === (u = e.error.details) || void 0 === u ? void 0 : u.geoGroup) && v.setTag("geoGroup", e.error.details.geoGroup), (null === (d = e.error.details) || void 0 === d ? void 0 : d.on) && v.setTag("connectionAttempt", e.error.details.on), null !== (p = e.error.details) && void 0 !== p && p.bundleUrl && (v.setTag("bundleUrl", e.error.details.bundleUrl), v.setTag("bundleError", e.error.details.sourceError.type)));
                v.setTags({
                    callMode: this._callObjectMode ? is() ? "reactNative" : null !== (i = this.properties) && void 0 !== i && null !== (i = i.dailyConfig) && void 0 !== i && null !== (i = i.callMode) && void 0 !== i && i.includes("prebuilt") ? this.properties.dailyConfig.callMode : "custom" : "prebuilt-frame",
                    version: r.version()
                });
                var b = (null === (o = e.error) || void 0 === o ? void 0 : o.msg) || e.errorMsg;
                v.captureException(new Error(b));
            }
        },
        {
            key: "_callMachine",
            value: function() {
                var e;
                return null === (e = window._daily) || void 0 === e || null === (e = e.instances) || void 0 === e || null === (e = e[this.callClientId]) || void 0 === e ? void 0 : e.callMachine;
            }
        },
        {
            key: "_maybeUpdateInputSettings",
            value: function(e) {
                if (!S(this._inputSettings, e)) {
                    var t = this._getInputSettings();
                    this._inputSettings = e;
                    var n = this._getInputSettings();
                    S(t, n) || this.emitDailyJSEvent({
                        action: Uo,
                        inputSettings: n
                    });
                }
            }
        }
    ], [
        {
            key: "supportedBrowser",
            value: function() {
                if (is()) return {
                    supported: !0,
                    mobile: !0,
                    name: "React Native",
                    version: null,
                    supportsScreenShare: !0,
                    supportsSfu: !0,
                    supportsVideoProcessing: !1,
                    supportsAudioProcessing: !1
                };
                var e = D.getParser(rs());
                return {
                    supported: !!fs(),
                    mobile: "mobile" === e.getPlatformType(),
                    name: e.getBrowserName(),
                    version: e.getBrowserVersion(),
                    supportsFullscreen: !!as(),
                    supportsScreenShare: !!ss(),
                    supportsSfu: !!fs(),
                    supportsVideoProcessing: ps(),
                    supportsAudioProcessing: hs()
                };
            }
        },
        {
            key: "version",
            value: function() {
                return "0.87.0";
            }
        },
        {
            key: "createCallObject",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.layout = "none", new r(null, e);
            }
        },
        {
            key: "wrap",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (rc(), !e || !e.contentWindow || "string" != typeof e.src) throw new Error("DailyIframe::Wrap needs an iframe-like first argument");
                return t.layout || (t.customLayout ? t.layout = "custom-v1" : t.layout = "browser"), new r(e, t);
            }
        },
        {
            key: "createFrame",
            value: function(e, t) {
                var n, i;
                rc(), e && t ? (n = e, i = t) : e && e.append ? (n = e, i = {}) : (n = document.body, i = e || {});
                var o = i.iframeStyle;
                o || (o = n === document.body ? {
                    position: "fixed",
                    border: "1px solid black",
                    backgroundColor: "white",
                    width: "375px",
                    height: "450px",
                    right: "1em",
                    bottom: "1em"
                } : {
                    border: 0,
                    width: "100%",
                    height: "100%"
                });
                var s = document.createElement("iframe");
                window.navigator && window.navigator.userAgent.match(/Chrome\/61\./) ? s.allow = "microphone, camera" : s.allow = "microphone; camera; autoplay; display-capture; screen-wake-lock; compute-pressure;", s.style.visibility = "hidden", n.appendChild(s), s.style.visibility = null, Object.keys(o).forEach(function(e) {
                    return s.style[e] = o[e];
                }), i.layout || (i.customLayout ? i.layout = "custom-v1" : i.layout = "browser");
                try {
                    return new r(s, i);
                } catch (e) {
                    throw n.removeChild(s), e;
                }
            }
        },
        {
            key: "createTransparentFrame",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                rc();
                var t = document.createElement("iframe");
                return t.allow = "microphone; camera; autoplay", t.style.cssText = "\n      position: fixed;\n      top: 0;\n      left: 0;\n      width: 100%;\n      height: 100%;\n      border: 0;\n      pointer-events: none;\n    ", document.body.appendChild(t), e.layout || (e.layout = "custom-v1"), r.wrap(t, e);
            }
        },
        {
            key: "getCallInstance",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0;
                return e ? La[e] : Object.values(La)[0];
            }
        }
    ]);
    //TURBOPACK unreachable
    ;
    var i, c, d, h, v, g, m, y, _, w, k, M, C, E, T, O, P, A, j, I, x, L, R, U, V, J, $, q, z, W, H, G, Q, K, Y, X, Z, ee;
}();
function Ga(e) {
    if (e.extension) {
        if ("string" != typeof e.extension) throw new Error("Error starting dial out: extension must be a string");
        if (e.extension.length > 20) throw new Error("Error starting dial out: extension length must be less than or equal to 20");
    }
    if (e.waitBeforeExtensionDialSec) {
        if ("number" != typeof e.waitBeforeExtensionDialSec) throw new Error("Error starting dial out: waitBeforeExtensionDialSec must be a number");
        if (e.waitBeforeExtensionDialSec > 60) throw new Error("Error starting dial out: waitBeforeExtensionDialSec must be less than or equal to 60");
        if (!e.extension) throw new Error("Error starting dial out: waitBeforeExtensionDialSec requires a phoneNumber and extension");
    }
}
function Qa(e, t) {
    var n = {};
    for(var r in e)if (e[r] instanceof MediaStreamTrack) console.warn("MediaStreamTrack found in props or cache.", r), n[r] = Qo;
    else if ("dailyConfig" === r) {
        if (e[r].modifyLocalSdpHook) {
            var i = window._daily.instances[t].customCallbacks || {};
            i.modifyLocalSdpHook = e[r].modifyLocalSdpHook, window._daily.instances[t].customCallbacks = i, delete e[r].modifyLocalSdpHook;
        }
        if (e[r].modifyRemoteSdpHook) {
            var o = window._daily.instances[t].customCallbacks || {};
            o.modifyRemoteSdpHook = e[r].modifyRemoteSdpHook, window._daily.instances[t].customCallbacks = o, delete e[r].modifyRemoteSdpHook;
        }
        n[r] = e[r];
    } else n[r] = e[r];
    return n;
}
function Ka(e) {
    var t = arguments.length > 2 ? arguments[2] : void 0;
    if (e !== oi) {
        var n = "".concat(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "This daily-js method", " only supported after join.");
        throw t && (n += " ".concat(t)), console.error(n), new Error(n);
    }
}
function Ya(e, t) {
    return [
        ii,
        oi
    ].includes(e) || t;
}
function Xa(e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "This daily-js method", r = arguments.length > 3 ? arguments[3] : void 0;
    if (Ya(e, t)) {
        var i = "".concat(n, " not supported after joining a meeting.");
        throw r && (i += " ".concat(r)), console.error(i), new Error(i);
    }
}
function Za(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "This daily-js method", n = arguments.length > 2 ? arguments[2] : void 0;
    if (!e) {
        var r = "".concat(t, arguments.length > 3 && void 0 !== arguments[3] && arguments[3] ? " requires preAuth() or startCamera() to initialize call state." : " requires preAuth(), startCamera(), or join() to initialize call state.");
        throw n && (r += " ".concat(n)), console.error(r), new Error(r);
    }
}
function ec(e) {
    if (e) {
        var t = "A pre-call quality test is in progress. Please try ".concat(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "This daily-js method", " again once testing has completed. Use stopTestCallQuality() to end it early.");
        throw console.error(t), new Error(t);
    }
}
function tc(e) {
    if (!e) {
        var t = "".concat(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "This daily-js method", " is only supported on custom callObject instances");
        throw console.error(t), new Error(t);
    }
}
function nc(e) {
    if (e) {
        var t = "".concat(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "This daily-js method", " is only supported as part of Daily's Prebuilt");
        throw console.error(t), new Error(t);
    }
}
function rc() {
    if (is()) throw new Error("This daily-js method is not currently supported in React Native");
}
function ic() {
    if (!is()) throw new Error("This daily-js method is only supported in React Native");
}
function oc(e) {
    if (void 0 === e) return !0;
    var t;
    if ("string" == typeof e) t = e;
    else try {
        t = JSON.stringify(e), S(JSON.parse(t), e) || console.warn("The userData provided will be modified when serialized.");
    } catch (e) {
        throw Error("userData must be serializable to JSON: ".concat(e));
    }
    if (t.length > 4096) throw Error("userData is too large (".concat(t.length, " characters). Maximum size suppported is ").concat(4096, "."));
    return !0;
}
function sc(e, t) {
    for(var n = t.allowAllParticipantsKey, r = function(e) {
        var t = [
            "local"
        ];
        return n || t.push("*"), e && !t.includes(e);
    }, i = function(e) {
        return !!(void 0 === e.layer || Number.isInteger(e.layer) && e.layer >= 0 || "inherit" === e.layer);
    }, o = function(e) {
        return !!e && !(e.video && !i(e.video)) && !(e.screenVideo && !i(e.screenVideo));
    }, s = 0, a = Object.entries(e); s < a.length; s++){
        var c = f(a[s], 2), l = c[0], u = c[1];
        if (!r(l) || !o(u)) return !1;
    }
    return !0;
}
function ac(e) {
    if ("object" !== n(e)) return !1;
    for(var t = 0, r = Object.entries(e); t < r.length; t++){
        var i = f(r[t], 2), o = i[0], s = i[1];
        switch(o){
            case "video":
                if ("object" !== n(s)) return !1;
                for(var a = 0, c = Object.entries(s); a < c.length; a++){
                    var l = f(c[a], 2), u = l[0], d = l[1];
                    switch(u){
                        case "processor":
                            if (!uc(d)) return !1;
                            break;
                        case "settings":
                            if (!dc(d)) return !1;
                            break;
                        default:
                            return !1;
                    }
                }
                break;
            case "audio":
                if ("object" !== n(s)) return !1;
                for(var p = 0, h = Object.entries(s); p < h.length; p++){
                    var v = f(h[p], 2), g = v[0], m = v[1];
                    switch(g){
                        case "processor":
                            if (!lc(m)) return !1;
                            break;
                        case "settings":
                            if (!dc(m)) return !1;
                            break;
                        default:
                            return !1;
                    }
                }
                break;
            default:
                return !1;
        }
    }
    return !0;
}
function cc(e, t, n) {
    var r, i = [];
    e.video && e.video.processor && (ps(null !== (r = null == t ? void 0 : t.useLegacyVideoProcessor) && void 0 !== r && r) || (e.video.settings ? delete e.video.processor : delete e.video, i.push("video")));
    e.audio && e.audio.processor && (hs() || (e.audio.settings ? delete e.audio.processor : delete e.audio, i.push("audio"))), i.length > 0 && console.error("Ignoring settings for browser- or platform-unsupported input processor(s): ".concat(i.join(", "))), e.audio && e.audio.settings && (e.audio.settings.customTrack ? (n.audioTrack = e.audio.settings.customTrack, e.audio.settings = {
        customTrack: Qo
    }) : delete n.audioTrack), e.video && e.video.settings && (e.video.settings.customTrack ? (n.videoTrack = e.video.settings.customTrack, e.video.settings = {
        customTrack: Qo
    }) : delete n.videoTrack);
}
function lc(e) {
    if (is()) return console.warn("Video processing is not yet supported in React Native"), !1;
    var t = [
        "type"
    ];
    return !!e && "object" === n(e) && (Object.keys(e).filter(function(e) {
        return !t.includes(e);
    }).forEach(function(t) {
        console.warn("invalid key inputSettings -> audio -> processor : ".concat(t)), delete e[t];
    }), !!function(e) {
        if ("string" != typeof e) return !1;
        if (!Object.values(Yo).includes(e)) return console.error("inputSettings audio processor type invalid"), !1;
        return !0;
    }(e.type));
}
function uc(e) {
    if (is()) return console.warn("Video processing is not yet supported in React Native"), !1;
    var t = [
        "type",
        "config"
    ];
    if (!e) return !1;
    if ("object" !== n(e)) return !1;
    if (!function(e) {
        if ("string" != typeof e) return !1;
        if (!Object.values(Ko).includes(e)) return console.error("inputSettings video processor type invalid"), !1;
        return !0;
    }(e.type)) return !1;
    if (e.config) {
        if ("object" !== n(e.config)) return !1;
        if (!function(e, t) {
            var n = Object.keys(t);
            if (0 === n.length) return !0;
            var r = "invalid object in inputSettings -> video -> processor -> config";
            switch(e){
                case Ko.BGBLUR:
                    return n.length > 1 || "strength" !== n[0] ? (console.error(r), !1) : !("number" != typeof t.strength || t.strength <= 0 || t.strength > 1 || isNaN(t.strength)) || (console.error("".concat(r, "; expected: {0 < strength <= 1}, got: ").concat(t.strength)), !1);
                case Ko.BGIMAGE:
                    return !(void 0 !== t.source && !function(e) {
                        if ("default" === e.source) return e.type = "default", !0;
                        if (e.source instanceof ArrayBuffer) return !0;
                        if (U(e.source)) return e.type = "url", !!function(e) {
                            var t = new URL(e), n = t.pathname;
                            if ("data:" === t.protocol) try {
                                var r = n.substring(n.indexOf(":") + 1, n.indexOf(";")).split("/")[1];
                                return Zo.includes(r);
                            } catch (e) {
                                return console.error("failed to deduce blob content type", e), !1;
                            }
                            var i = n.split(".").at(-1).toLowerCase().trim();
                            return Zo.includes(i);
                        }(e.source) || (console.error("invalid image type; supported types: [".concat(Zo.join(", "), "]")), !1);
                        return t = e.source, n = Number(t), isNaN(n) || !Number.isInteger(n) || n <= 0 || n > 10 ? (console.error("invalid image selection; must be an int, > 0, <= ".concat(10)), !1) : (e.type = "daily-preselect", !0);
                        //TURBOPACK unreachable
                        ;
                        var t, n;
                    }(t));
                default:
                    return !0;
            }
        }(e.type, e.config)) return !1;
    }
    return Object.keys(e).filter(function(e) {
        return !t.includes(e);
    }).forEach(function(t) {
        console.warn("invalid key inputSettings -> video -> processor : ".concat(t)), delete e[t];
    }), !0;
}
function dc(e) {
    return "object" === n(e) && (!e.customTrack || e.customTrack instanceof MediaStreamTrack);
}
function pc() {
    var e = Object.values(Ko).join(" | "), t = Object.values(Yo).join(" | ");
    return "inputSettings must be of the form: { video?: { processor?: { type: [ ".concat(e, " ], config?: {} } }, audio?: { processor: {type: [ ").concat(t, " ] } } }");
}
function hc(e) {
    var t = e.allowAllParticipantsKey;
    return "receiveSettings must be of the form { [<remote participant id> | ".concat(yi).concat(t ? ' | "'.concat("*", '"') : "", "]: ") + '{ [video: [{ layer: [<non-negative integer> | "inherit"] } | "inherit"]], [screenVideo: [{ layer: [<non-negative integer> | "inherit"] } | "inherit"]] }}}';
}
function fc() {
    return "customIntegrations should be an object of type ".concat(JSON.stringify(qa), ".");
}
function vc(e) {
    if (e && "object" !== n(e) || Array.isArray(e)) return console.error("customTrayButtons should be an Object of the type ".concat(JSON.stringify($a), ".")), !1;
    if (e) for(var t = 0, r = Object.entries(e); t < r.length; t++)for(var i = f(r[t], 1)[0], o = 0, s = Object.entries(e[i]); o < s.length; o++){
        var a = f(s[o], 2), c = a[0], l = a[1], u = $a.id[c];
        if (!u) return console.error("customTrayButton does not support key ".concat(c)), !1;
        switch(c){
            case "iconPath":
            case "iconPathDarkMode":
                if (!U(l)) return console.error("customTrayButton ".concat(c, " should be a url.")), !1;
                break;
            case "visualState":
                if (![
                    "default",
                    "sidebar-open",
                    "active"
                ].includes(l)) return console.error("customTrayButton ".concat(c, " should be ").concat(u, ". Got: ").concat(l)), !1;
                break;
            default:
                if (n(l) !== u) return console.error("customTrayButton ".concat(c, " should be a ").concat(u, ".")), !1;
        }
    }
    return !0;
}
function gc(e) {
    if (!e || e && "object" !== n(e) || Array.isArray(e)) return console.error(fc()), !1;
    for(var t = function(e) {
        return "".concat(e, " should be ").concat(qa.id[e]);
    }, r = function(e, t) {
        return console.error("customIntegration ".concat(e, ": ").concat(t));
    }, i = 0, o = Object.entries(e); i < o.length; i++){
        var s = f(o[i], 1)[0];
        if (!("label" in e[s])) return r(s, "label is required"), !1;
        if (!("location" in e[s])) return r(s, "location is required"), !1;
        if (!("src" in e[s]) && !("srcdoc" in e[s])) return r(s, "src or srcdoc is required"), !1;
        for(var a = 0, c = Object.entries(e[s]); a < c.length; a++){
            var l = f(c[a], 2), u = l[0], d = l[1];
            switch(u){
                case "allow":
                case "csp":
                case "name":
                case "referrerPolicy":
                case "sandbox":
                    if ("string" != typeof d) return r(s, t(u)), !1;
                    break;
                case "iconURL":
                    if (!U(d)) return r(s, "".concat(u, " should be a url")), !1;
                    break;
                case "src":
                    if ("srcdoc" in e[s]) return r(s, "cannot have both src and srcdoc"), !1;
                    if (!U(d)) return r(s, 'src "'.concat(d, '" is not a valid URL')), !1;
                    break;
                case "srcdoc":
                    if ("src" in e[s]) return r(s, "cannot have both src and srcdoc"), !1;
                    if ("string" != typeof d) return r(s, t(u)), !1;
                    break;
                case "location":
                    if (![
                        "main",
                        "sidebar"
                    ].includes(d)) return r(s, t(u)), !1;
                    break;
                case "controlledBy":
                    if ("*" !== d && "owners" !== d && (!Array.isArray(d) || d.some(function(e) {
                        return "string" != typeof e;
                    }))) return r(s, t(u)), !1;
                    break;
                case "shared":
                    if ((!Array.isArray(d) || d.some(function(e) {
                        return "string" != typeof e;
                    })) && "owners" !== d && "boolean" != typeof d) return r(s, t(u)), !1;
                    break;
                default:
                    if (!qa.id[u]) return console.error("customIntegration does not support key ".concat(u)), !1;
            }
        }
    }
    return !0;
}
function mc(e, t) {
    if (void 0 === t) return !1;
    switch(n(t)){
        case "string":
            return n(e) === t;
        case "object":
            if ("object" !== n(e)) return !1;
            for(var r in e)if (!mc(e[r], t[r])) return !1;
            return !0;
        default:
            return !1;
    }
}
function yc(e, t) {
    var n = e.sessionId, r = e.toEndPoint, i = e.callerId, o = e.useSipRefer;
    if (!n || !r) throw new Error("".concat(t, "() requires a sessionId and toEndPoint"));
    if ("string" != typeof n || "string" != typeof r) throw new Error("Invalid paramater: sessionId and toEndPoint must be of type string");
    if (o && !r.startsWith("sip:")) throw new Error('"toEndPoint" must be a "sip" address');
    if (!r.startsWith("sip:") && !r.startsWith("+")) throw new Error("toEndPoint: ".concat(r, ' must starts with either "sip:" or "+"'));
    if (i && "string" != typeof i) throw new Error("callerId must be of type string");
    if (i && !r.startsWith("+")) throw new Error("callerId is only valid when transferring to a PSTN number");
}
function bc(e) {
    if ("object" !== n(e)) throw new Error('RemoteMediaPlayerSettings: must be "object" type');
    if (e.state && !Object.values(Xo).includes(e.state)) throw new Error("Invalid value for RemoteMediaPlayerSettings.state, valid values are: " + JSON.stringify(Xo));
    if (e.volume) {
        if ("number" != typeof e.volume) throw new Error('RemoteMediaPlayerSettings.volume: must be "number" type');
        if (e.volume < 0 || e.volume > 2) throw new Error("RemoteMediaPlayerSettings.volume: must be between 0.0 - 2.0");
    }
}
function _c(e, t, n) {
    return !("number" != typeof e || e < t || e > n);
}
function wc(e, t) {
    return e && !t && delete e.data, e;
}
;
}),
]);

//# debugId=4d65853e-c4c1-6bcb-cf84-f29a7f297ccc
//# sourceMappingURL=c427b_%40daily-co_daily-js_dist_daily-esm_5eede5d3.js.map