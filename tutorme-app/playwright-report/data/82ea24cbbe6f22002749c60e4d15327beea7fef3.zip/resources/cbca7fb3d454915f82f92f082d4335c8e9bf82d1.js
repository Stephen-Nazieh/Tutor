(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_app_45dd5852._.css",
  "static/chunks/c427b_72f408ef._.js"
],
    source: "dynamic"
});
