(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b1c00_TutorMekimi_tutorme-app_src_app_[locale]_tutor_live-class_page_tsx_12a3f88c._.js"
],
    source: "dynamic"
});
