;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="14400441-72a5-aeeb-6327-9e06b5aa8de9")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "idValidator",
    ()=>idValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
function idValidator(prefix) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.refine((id)=>{
        if (!id.startsWith(`${prefix}:`)) {
            throw new Error(`${prefix} ID must start with "${prefix}:"`);
        }
        return id;
    });
}
;
 //# sourceMappingURL=id-validator.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assetIdValidator",
    ()=>assetIdValidator,
    "createAssetValidator",
    ()=>createAssetValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
;
;
const assetIdValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("asset");
function createAssetValidator(type, props) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        id: assetIdValidator,
        typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("asset"),
        type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal(type),
        props,
        meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
    });
}
;
 //# sourceMappingURL=TLBaseAsset.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "boxModelValidator",
    ()=>boxModelValidator,
    "vecModelValidator",
    ()=>vecModelValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
const vecModelValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    z: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number.optional()
});
const boxModelValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
});
;
 //# sourceMappingURL=geometry-types.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLOpacity.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "opacityValidator",
    ()=>opacityValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
const opacityValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].unitInterval;
;
 //# sourceMappingURL=TLOpacity.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createShapeValidator",
    ()=>createShapeValidator,
    "parentIdValidator",
    ()=>parentIdValidator,
    "shapeIdValidator",
    ()=>shapeIdValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLOpacity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
;
;
;
const parentIdValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.refine((id)=>{
    if (!id.startsWith("page:") && !id.startsWith("shape:")) {
        throw new Error('Parent ID must start with "page:" or "shape:"');
    }
    return id;
});
const shapeIdValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("shape");
function createShapeValidator(type, props, meta) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        id: shapeIdValidator,
        typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("shape"),
        x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        rotation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        index: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].indexKey,
        parentId: parentIdValidator,
        type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal(type),
        isLocked: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        opacity: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opacityValidator"],
        props: props ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object(props) : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue,
        meta: meta ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object(meta) : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
    });
}
;
 //# sourceMappingURL=TLBaseShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLBaseBinding.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bindingIdValidator",
    ()=>bindingIdValidator,
    "createBindingValidator",
    ()=>createBindingValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
;
;
;
const bindingIdValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("binding");
function createBindingValidator(type, props, meta) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        id: bindingIdValidator,
        typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("binding"),
        type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal(type),
        fromId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"],
        toId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"],
        props: props ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object(props) : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue,
        meta: meta ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object(meta) : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
    });
}
;
 //# sourceMappingURL=TLBaseBinding.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBindingId",
    ()=>createBindingId,
    "createBindingPropsMigrationIds",
    ()=>createBindingPropsMigrationIds,
    "createBindingPropsMigrationSequence",
    ()=>createBindingPropsMigrationSequence,
    "createBindingRecordType",
    ()=>createBindingRecordType,
    "isBinding",
    ()=>isBinding,
    "isBindingId",
    ()=>isBindingId,
    "rootBindingMigrations",
    ()=>rootBindingMigrations,
    "rootBindingVersions",
    ()=>rootBindingVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLBaseBinding.mjs [app-client] (ecmascript)");
;
;
;
;
const rootBindingVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.binding", {});
const rootBindingMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.binding",
    recordType: "binding",
    sequence: []
});
function isBinding(record) {
    if (!record) return false;
    return record.typeName === "binding";
}
function isBindingId(id) {
    if (!id) return false;
    return id.startsWith("binding:");
}
function createBindingId(id) {
    return `binding:${id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()}`;
}
function createBindingPropsMigrationSequence(migrations) {
    return migrations;
}
function createBindingPropsMigrationIds(bindingType, ids) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"])(ids, (_k, v)=>`com.tldraw.binding.${bindingType}/${v}`);
}
function createBindingRecordType(bindings) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("binding", {
        scope: "document",
        validator: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("binding", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].union("type", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"])(bindings, (type, { props, meta })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingValidator"])(type, props, meta))))
    }).withDefaultProperties(()=>({
            meta: {}
        }));
}
;
 //# sourceMappingURL=TLBinding.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "richTextValidator",
    ()=>richTextValidator,
    "toRichText",
    ()=>toRichText
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
const richTextValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    content: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].unknown),
    attrs: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].any.optional()
});
function toRichText(text) {
    const lines = text.split("\n");
    const content = lines.map((text2)=>{
        if (!text2) {
            return {
                type: "paragraph"
            };
        }
        return {
            type: "paragraph",
            content: [
                {
                    type: "text",
                    text: text2
                }
            ]
        };
    });
    return {
        type: "doc",
        content
    };
}
;
 //# sourceMappingURL=TLRichText.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EnumStyleProp",
    ()=>EnumStyleProp,
    "StyleProp",
    ()=>StyleProp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
class StyleProp {
    /** @internal */ constructor(id, defaultValue, type){
        this.id = id;
        this.defaultValue = defaultValue;
        this.type = type;
    }
    /**
   * Define a new {@link StyleProp}.
   *
   * @param uniqueId - Each StyleProp must have a unique ID. We recommend you prefix this with
   * your app/library name.
   * @param options -
   * - `defaultValue`: The default value for this style prop.
   *
   * - `type`: Optionally, describe what type of data you expect for this style prop.
   *
   * @example
   * ```ts
   * import {T} from '@tldraw/validate'
   * import {StyleProp} from '@tldraw/tlschema'
   *
   * const MyLineWidthProp = StyleProp.define('myApp:lineWidth', {
   *   defaultValue: 1,
   *   type: T.number,
   * })
   * ```
   * @public
   */ static define(uniqueId, options) {
        const { defaultValue, type = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].any } = options;
        return new StyleProp(uniqueId, defaultValue, type);
    }
    /**
   * Define a new {@link StyleProp} as a list of possible values.
   *
   * @param uniqueId - Each StyleProp must have a unique ID. We recommend you prefix this with
   * your app/library name.
   * @param options -
   * - `defaultValue`: The default value for this style prop.
   *
   * - `values`: An array of possible values of this style prop.
   *
   * @example
   * ```ts
   * import {StyleProp} from '@tldraw/tlschema'
   *
   * const MySizeProp = StyleProp.defineEnum('myApp:size', {
   *   defaultValue: 'medium',
   *   values: ['small', 'medium', 'large'],
   * })
   * ```
   */ static defineEnum(uniqueId, options) {
        const { defaultValue, values } = options;
        return new EnumStyleProp(uniqueId, defaultValue, values);
    }
    setDefaultValue(value) {
        this.defaultValue = value;
    }
    validate(value) {
        return this.type.validate(value);
    }
    validateUsingKnownGoodVersion(prevValue, newValue) {
        if (this.type.validateUsingKnownGoodVersion) {
            return this.type.validateUsingKnownGoodVersion(prevValue, newValue);
        } else {
            return this.validate(newValue);
        }
    }
}
class EnumStyleProp extends StyleProp {
    /** @internal */ constructor(id, defaultValue, values){
        super(id, defaultValue, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum(...values));
        this.values = values;
    }
}
;
 //# sourceMappingURL=StyleProp.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createShapeId",
    ()=>createShapeId,
    "createShapePropsMigrationIds",
    ()=>createShapePropsMigrationIds,
    "createShapePropsMigrationSequence",
    ()=>createShapePropsMigrationSequence,
    "createShapeRecordType",
    ()=>createShapeRecordType,
    "getShapePropKeysByStyle",
    ()=>getShapePropKeysByStyle,
    "isShape",
    ()=>isShape,
    "isShapeId",
    ()=>isShapeId,
    "rootShapeMigrations",
    ()=>rootShapeMigrations,
    "rootShapeVersions",
    ()=>rootShapeVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
;
;
;
;
const rootShapeVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.shape", {
    AddIsLocked: 1,
    HoistOpacity: 2,
    AddMeta: 3,
    AddWhite: 4
});
const rootShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.shape",
    recordType: "shape",
    sequence: [
        {
            id: rootShapeVersions.AddIsLocked,
            up: (record)=>{
                record.isLocked = false;
            },
            down: (record)=>{
                delete record.isLocked;
            }
        },
        {
            id: rootShapeVersions.HoistOpacity,
            up: (record)=>{
                record.opacity = Number(record.props.opacity ?? "1");
                delete record.props.opacity;
            },
            down: (record)=>{
                const opacity = record.opacity;
                delete record.opacity;
                record.props.opacity = opacity < 0.175 ? "0.1" : opacity < 0.375 ? "0.25" : opacity < 0.625 ? "0.5" : opacity < 0.875 ? "0.75" : "1";
            }
        },
        {
            id: rootShapeVersions.AddMeta,
            up: (record)=>{
                record.meta = {};
            }
        },
        {
            id: rootShapeVersions.AddWhite,
            up: (_record)=>{},
            down: (record)=>{
                if (record.props.color === "white") {
                    record.props.color = "black";
                }
            }
        }
    ]
});
function isShape(record) {
    if (!record) return false;
    return record.typeName === "shape";
}
function isShapeId(id) {
    if (!id) return false;
    return id.startsWith("shape:");
}
function createShapeId(id) {
    return `shape:${id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()}`;
}
function getShapePropKeysByStyle(props) {
    const propKeysByStyle = /* @__PURE__ */ new Map();
    for (const [key, prop] of Object.entries(props)){
        if (prop instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"]) {
            if (propKeysByStyle.has(prop)) {
                throw new Error(`Duplicate style prop ${prop.id}. Each style prop can only be used once within a shape.`);
            }
            propKeysByStyle.set(prop, key);
        }
    }
    return propKeysByStyle;
}
function createShapePropsMigrationSequence(migrations) {
    return migrations;
}
function createShapePropsMigrationIds(shapeType, ids) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"])(ids, (_k, v)=>`com.tldraw.shape.${shapeType}/${v}`);
}
function createShapeRecordType(shapes) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("shape", {
        scope: "document",
        validator: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("shape", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].union("type", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"])(shapes, (type, { props, meta })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeValidator"])(type, props, meta))))
    }).withDefaultProperties(()=>({
            x: 0,
            y: 0,
            rotation: 0,
            isLocked: false,
            opacity: 1,
            meta: {}
        }));
}
;
 //# sourceMappingURL=TLShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/recordsWithProps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createPropsMigration",
    ()=>createPropsMigration,
    "processPropsMigrations",
    ()=>processPropsMigrations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
;
;
function processPropsMigrations(typeName, records) {
    const result = [];
    for (const [subType, { migrations }] of Object.entries(records)){
        const sequenceId = `com.tldraw.${typeName}.${subType}`;
        if (!migrations) {
            result.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"])({
                sequenceId,
                retroactive: true,
                sequence: []
            }));
        } else if ("sequenceId" in migrations) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(sequenceId === migrations.sequenceId, `sequenceId mismatch for ${subType} ${__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecordType"]} migrations. Expected '${sequenceId}', got '${migrations.sequenceId}'`);
            result.push(migrations);
        } else if ("sequence" in migrations) {
            result.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"])({
                sequenceId,
                retroactive: true,
                sequence: migrations.sequence.map((m)=>"id" in m ? createPropsMigration(typeName, subType, m) : m)
            }));
        } else {
            result.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"])({
                sequenceId,
                retroactive: true,
                sequence: Object.keys(migrations.migrators).map((k)=>Number(k)).sort((a, b)=>a - b).map((version)=>({
                        id: `${sequenceId}/${version}`,
                        scope: "record",
                        filter: (r)=>r.typeName === typeName && r.type === subType,
                        up: (record)=>{
                            const result2 = migrations.migrators[version].up(record);
                            if (result2) {
                                return result2;
                            }
                        },
                        down: (record)=>{
                            const result2 = migrations.migrators[version].down(record);
                            if (result2) {
                                return result2;
                            }
                        }
                    }))
            }));
        }
    }
    return result;
}
function createPropsMigration(typeName, subType, m) {
    return {
        id: m.id,
        dependsOn: m.dependsOn,
        scope: "record",
        filter: (r)=>r.typeName === typeName && r.type === subType,
        up: (record)=>{
            const result = m.up(record.props);
            if (result) {
                record.props = result;
            }
        },
        down: typeof m.down === "function" ? (record)=>{
            const result = m.down(record.props);
            if (result) {
                record.props = result;
            }
        } : void 0
    };
}
;
 //# sourceMappingURL=recordsWithProps.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultColorStyle",
    ()=>DefaultColorStyle,
    "DefaultColorThemePalette",
    ()=>DefaultColorThemePalette,
    "DefaultLabelColorStyle",
    ()=>DefaultLabelColorStyle,
    "defaultColorNames",
    ()=>defaultColorNames,
    "getColorValue",
    ()=>getColorValue,
    "getDefaultColorTheme",
    ()=>getDefaultColorTheme,
    "isDefaultThemeColor",
    ()=>isDefaultThemeColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const defaultColorNames = [
    "black",
    "grey",
    "light-violet",
    "violet",
    "blue",
    "light-blue",
    "yellow",
    "orange",
    "green",
    "light-green",
    "light-red",
    "red",
    "white"
];
const DefaultColorThemePalette = {
    lightMode: {
        id: "light",
        text: "#000000",
        background: "#f9fafb",
        solid: "#fcfffe",
        black: {
            solid: "#1d1d1d",
            fill: "#1d1d1d",
            linedFill: "#363636",
            frameHeadingStroke: "#717171",
            frameHeadingFill: "#ffffff",
            frameStroke: "#717171",
            frameFill: "#ffffff",
            frameText: "#000000",
            noteFill: "#FCE19C",
            noteText: "#000000",
            semi: "#e8e8e8",
            pattern: "#494949",
            highlightSrgb: "#fddd00",
            highlightP3: "color(display-p3 0.972 0.8205 0.05)"
        },
        blue: {
            solid: "#4465e9",
            fill: "#4465e9",
            linedFill: "#6580ec",
            frameHeadingStroke: "#6681ec",
            frameHeadingFill: "#f9fafe",
            frameStroke: "#6681ec",
            frameFill: "#f9fafe",
            frameText: "#000000",
            noteFill: "#8AA3FF",
            noteText: "#000000",
            semi: "#dce1f8",
            pattern: "#6681ee",
            highlightSrgb: "#10acff",
            highlightP3: "color(display-p3 0.308 0.6632 0.9996)"
        },
        green: {
            solid: "#099268",
            fill: "#099268",
            linedFill: "#0bad7c",
            frameHeadingStroke: "#37a684",
            frameHeadingFill: "#f8fcfa",
            frameStroke: "#37a684",
            frameFill: "#f8fcfa",
            frameText: "#000000",
            noteFill: "#6FC896",
            noteText: "#000000",
            semi: "#d3e9e3",
            pattern: "#39a785",
            highlightSrgb: "#00ffc8",
            highlightP3: "color(display-p3 0.2536 0.984 0.7981)"
        },
        grey: {
            solid: "#9fa8b2",
            fill: "#9fa8b2",
            linedFill: "#bbc1c9",
            frameHeadingStroke: "#aaaaab",
            frameHeadingFill: "#fbfcfc",
            frameStroke: "#aaaaab",
            frameFill: "#fcfcfd",
            frameText: "#000000",
            noteFill: "#C0CAD3",
            noteText: "#000000",
            semi: "#eceef0",
            pattern: "#bcc3c9",
            highlightSrgb: "#cbe7f1",
            highlightP3: "color(display-p3 0.8163 0.9023 0.9416)"
        },
        "light-blue": {
            solid: "#4ba1f1",
            fill: "#4ba1f1",
            linedFill: "#7abaf5",
            frameHeadingStroke: "#6cb2f3",
            frameHeadingFill: "#f8fbfe",
            frameStroke: "#6cb2f3",
            frameFill: "#fafcff",
            frameText: "#000000",
            noteFill: "#9BC4FD",
            noteText: "#000000",
            semi: "#ddedfa",
            pattern: "#6fbbf8",
            highlightSrgb: "#00f4ff",
            highlightP3: "color(display-p3 0.1512 0.9414 0.9996)"
        },
        "light-green": {
            solid: "#4cb05e",
            fill: "#4cb05e",
            linedFill: "#7ec88c",
            frameHeadingStroke: "#6dbe7c",
            frameHeadingFill: "#f8fcf9",
            frameStroke: "#6dbe7c",
            frameFill: "#fafdfa",
            frameText: "#000000",
            noteFill: "#98D08A",
            noteText: "#000000",
            semi: "#dbf0e0",
            pattern: "#65cb78",
            highlightSrgb: "#65f641",
            highlightP3: "color(display-p3 0.563 0.9495 0.3857)"
        },
        "light-red": {
            solid: "#f87777",
            fill: "#f87777",
            linedFill: "#f99a9a",
            frameHeadingStroke: "#f89090",
            frameHeadingFill: "#fffafa",
            frameStroke: "#f89090",
            frameFill: "#fffbfb",
            frameText: "#000000",
            noteFill: "#F7A5A1",
            noteText: "#000000",
            semi: "#f4dadb",
            pattern: "#fe9e9e",
            highlightSrgb: "#ff7fa3",
            highlightP3: "color(display-p3 0.9988 0.5301 0.6397)"
        },
        "light-violet": {
            solid: "#e085f4",
            fill: "#e085f4",
            linedFill: "#e9abf7",
            frameHeadingStroke: "#e59bf5",
            frameHeadingFill: "#fefaff",
            frameStroke: "#e59bf5",
            frameFill: "#fefbff",
            frameText: "#000000",
            noteFill: "#DFB0F9",
            noteText: "#000000",
            semi: "#f5eafa",
            pattern: "#e9acf8",
            highlightSrgb: "#ff88ff",
            highlightP3: "color(display-p3 0.9676 0.5652 0.9999)"
        },
        orange: {
            solid: "#e16919",
            fill: "#e16919",
            linedFill: "#ea8643",
            frameHeadingStroke: "#e68544",
            frameHeadingFill: "#fef9f6",
            frameStroke: "#e68544",
            frameFill: "#fef9f6",
            frameText: "#000000",
            noteFill: "#FAA475",
            noteText: "#000000",
            semi: "#f8e2d4",
            pattern: "#f78438",
            highlightSrgb: "#ffa500",
            highlightP3: "color(display-p3 0.9988 0.6905 0.266)"
        },
        red: {
            solid: "#e03131",
            fill: "#e03131",
            linedFill: "#e75f5f",
            frameHeadingStroke: "#e55757",
            frameHeadingFill: "#fef7f7",
            frameStroke: "#e55757",
            frameFill: "#fef9f9",
            frameText: "#000000",
            noteFill: "#FC8282",
            noteText: "#000000",
            semi: "#f4dadb",
            pattern: "#e55959",
            highlightSrgb: "#ff636e",
            highlightP3: "color(display-p3 0.9992 0.4376 0.45)"
        },
        violet: {
            solid: "#ae3ec9",
            fill: "#ae3ec9",
            linedFill: "#be68d4",
            frameHeadingStroke: "#bc62d3",
            frameHeadingFill: "#fcf7fd",
            frameStroke: "#bc62d3",
            frameFill: "#fdf9fd",
            frameText: "#000000",
            noteFill: "#DB91FD",
            noteText: "#000000",
            semi: "#ecdcf2",
            pattern: "#bd63d3",
            highlightSrgb: "#c77cff",
            highlightP3: "color(display-p3 0.7469 0.5089 0.9995)"
        },
        yellow: {
            solid: "#f1ac4b",
            fill: "#f1ac4b",
            linedFill: "#f5c27a",
            frameHeadingStroke: "#f3bb6c",
            frameHeadingFill: "#fefcf8",
            frameStroke: "#f3bb6c",
            frameFill: "#fffdfa",
            frameText: "#000000",
            noteFill: "#FED49A",
            noteText: "#000000",
            semi: "#f9f0e6",
            pattern: "#fecb92",
            highlightSrgb: "#fddd00",
            highlightP3: "color(display-p3 0.972 0.8705 0.05)"
        },
        white: {
            solid: "#FFFFFF",
            fill: "#FFFFFF",
            linedFill: "#ffffff",
            semi: "#f5f5f5",
            pattern: "#f9f9f9",
            frameHeadingStroke: "#7d7d7d",
            frameHeadingFill: "#ffffff",
            frameStroke: "#7d7d7d",
            frameFill: "#ffffff",
            frameText: "#000000",
            noteFill: "#FFFFFF",
            noteText: "#000000",
            highlightSrgb: "#ffffff",
            highlightP3: "color(display-p3 1 1 1)"
        }
    },
    darkMode: {
        id: "dark",
        text: "hsl(210, 17%, 98%)",
        background: "hsl(240, 5%, 6.5%)",
        solid: "#010403",
        black: {
            solid: "#f2f2f2",
            fill: "#f2f2f2",
            linedFill: "#ffffff",
            frameHeadingStroke: "#5c5c5c",
            frameHeadingFill: "#252525",
            frameStroke: "#5c5c5c",
            frameFill: "#0c0c0c",
            frameText: "#f2f2f2",
            noteFill: "#2c2c2c",
            noteText: "#f2f2f2",
            semi: "#2c3036",
            pattern: "#989898",
            highlightSrgb: "#d2b700",
            highlightP3: "color(display-p3 0.8078 0.6225 0.0312)"
        },
        blue: {
            solid: "#4f72fc",
            // 3c60f0
            fill: "#4f72fc",
            linedFill: "#3c5cdd",
            frameHeadingStroke: "#384994",
            frameHeadingFill: "#1C2036",
            frameStroke: "#384994",
            frameFill: "#11141f",
            frameText: "#f2f2f2",
            noteFill: "#2A3F98",
            noteText: "#f2f2f2",
            semi: "#262d40",
            pattern: "#3a4b9e",
            highlightSrgb: "#0079d2",
            highlightP3: "color(display-p3 0.0032 0.4655 0.7991)"
        },
        green: {
            solid: "#099268",
            fill: "#099268",
            linedFill: "#087856",
            frameHeadingStroke: "#10513C",
            frameHeadingFill: "#14241f",
            frameStroke: "#10513C",
            frameFill: "#0E1614",
            frameText: "#f2f2f2",
            noteFill: "#014429",
            noteText: "#f2f2f2",
            semi: "#253231",
            pattern: "#366a53",
            highlightSrgb: "#009774",
            highlightP3: "color(display-p3 0.0085 0.582 0.4604)"
        },
        grey: {
            solid: "#9398b0",
            fill: "#9398b0",
            linedFill: "#8388a5",
            frameHeadingStroke: "#42474D",
            frameHeadingFill: "#23262A",
            frameStroke: "#42474D",
            frameFill: "#151719",
            frameText: "#f2f2f2",
            noteFill: "#56595F",
            noteText: "#f2f2f2",
            semi: "#33373c",
            pattern: "#7c8187",
            highlightSrgb: "#9cb4cb",
            highlightP3: "color(display-p3 0.6299 0.7012 0.7856)"
        },
        "light-blue": {
            solid: "#4dabf7",
            fill: "#4dabf7",
            linedFill: "#2793ec",
            frameHeadingStroke: "#075797",
            frameHeadingFill: "#142839",
            frameStroke: "#075797",
            frameFill: "#0B1823",
            frameText: "#f2f2f2",
            noteFill: "#1F5495",
            noteText: "#f2f2f2",
            semi: "#2a3642",
            pattern: "#4d7aa9",
            highlightSrgb: "#00bdc8",
            highlightP3: "color(display-p3 0.0023 0.7259 0.7735)"
        },
        "light-green": {
            solid: "#40c057",
            fill: "#40c057",
            linedFill: "#37a44b",
            frameHeadingStroke: "#1C5427",
            frameHeadingFill: "#18251A",
            frameStroke: "#1C5427",
            frameFill: "#0F1911",
            frameText: "#f2f2f2",
            noteFill: "#21581D",
            noteText: "#f2f2f2",
            semi: "#2a3830",
            pattern: "#4e874e",
            highlightSrgb: "#00a000",
            highlightP3: "color(display-p3 0.2711 0.6172 0.0195)"
        },
        "light-red": {
            solid: "#ff8787",
            fill: "#ff8787",
            linedFill: "#ff6666",
            frameHeadingStroke: "#6f3232",
            // Darker and desaturated variant of solid
            frameHeadingFill: "#341818",
            // Deep, muted dark red
            frameStroke: "#6f3232",
            // Matches headingStroke
            frameFill: "#181212",
            // Darker, muted background shade
            frameText: "#f2f2f2",
            // Consistent bright text color
            noteFill: "#7a3333",
            // Medium-dark, muted variant of solid
            noteText: "#f2f2f2",
            semi: "#3c2b2b",
            // Subdued, darker neutral-red tone
            pattern: "#a56767",
            // Existing pattern shade retained
            highlightSrgb: "#db005b",
            highlightP3: "color(display-p3 0.7849 0.0585 0.3589)"
        },
        "light-violet": {
            solid: "#e599f7",
            fill: "#e599f7",
            linedFill: "#dc71f4",
            frameHeadingStroke: "#6c367a",
            frameHeadingFill: "#2D2230",
            frameStroke: "#6c367a",
            frameFill: "#1C151E",
            frameText: "#f2f2f2",
            noteFill: "#762F8E",
            noteText: "#f2f2f2",
            semi: "#383442",
            pattern: "#9770a9",
            highlightSrgb: "#c400c7",
            highlightP3: "color(display-p3 0.7024 0.0403 0.753)"
        },
        orange: {
            solid: "#f76707",
            fill: "#f76707",
            linedFill: "#f54900",
            frameHeadingStroke: "#773a0e",
            // Darker, muted version of solid
            frameHeadingFill: "#2f1d13",
            // Deep, warm, muted background
            frameStroke: "#773a0e",
            // Matches headingStroke
            frameFill: "#1c1512",
            // Darker, richer muted background
            frameText: "#f2f2f2",
            // Bright text for contrast
            noteFill: "#7c3905",
            // Muted dark variant for note fill
            noteText: "#f2f2f2",
            semi: "#3b2e27",
            // Muted neutral-orange tone
            pattern: "#9f552d",
            // Retained existing shade
            highlightSrgb: "#d07a00",
            highlightP3: "color(display-p3 0.7699 0.4937 0.0085)"
        },
        red: {
            solid: "#e03131",
            fill: "#e03131",
            linedFill: "#c31d1d",
            frameHeadingStroke: "#701e1e",
            // Darker, muted variation of solid
            frameHeadingFill: "#301616",
            // Deep, muted reddish backdrop
            frameStroke: "#701e1e",
            // Matches headingStroke
            frameFill: "#1b1313",
            // Rich, dark muted background
            frameText: "#f2f2f2",
            // Bright text for readability
            noteFill: "#7e201f",
            // Muted dark variant for note fill
            noteText: "#f2f2f2",
            semi: "#382726",
            // Dark neutral-red tone
            pattern: "#8f3734",
            // Existing pattern color retained
            highlightSrgb: "#de002c",
            highlightP3: "color(display-p3 0.7978 0.0509 0.2035)"
        },
        violet: {
            solid: "#ae3ec9",
            fill: "#ae3ec9",
            linedFill: "#8f2fa7",
            frameHeadingStroke: "#6d1583",
            // Darker, muted variation of solid
            frameHeadingFill: "#27152e",
            // Deep, rich muted violet backdrop
            frameStroke: "#6d1583",
            // Matches headingStroke
            frameFill: "#1b0f21",
            // Darker muted violet background
            frameText: "#f2f2f2",
            // Consistent bright text color
            noteFill: "#5f1c70",
            // Muted dark variant for note fill
            noteText: "#f2f2f2",
            semi: "#342938",
            // Dark neutral-violet tone
            pattern: "#763a8b",
            // Retained existing pattern color
            highlightSrgb: "#9e00ee",
            highlightP3: "color(display-p3 0.5651 0.0079 0.8986)"
        },
        yellow: {
            solid: "#ffc034",
            fill: "#ffc034",
            linedFill: "#ffae00",
            frameHeadingStroke: "#684e12",
            // Darker, muted variant of solid
            frameHeadingFill: "#2a2113",
            // Rich, muted dark-yellow background
            frameStroke: "#684e12",
            // Matches headingStroke
            frameFill: "#1e1911",
            // Darker muted shade for background fill
            frameText: "#f2f2f2",
            // Bright text color for readability
            noteFill: "#8a5e1c",
            // Muted, dark complementary variant
            noteText: "#f2f2f2",
            semi: "#3b352b",
            // Dark muted neutral-yellow tone
            pattern: "#fecb92",
            // Existing shade retained
            highlightSrgb: "#d2b700",
            highlightP3: "color(display-p3 0.8078 0.7225 0.0312)"
        },
        white: {
            solid: "#f3f3f3",
            fill: "#f3f3f3",
            linedFill: "#f3f3f3",
            semi: "#f5f5f5",
            pattern: "#f9f9f9",
            frameHeadingStroke: "#ffffff",
            frameHeadingFill: "#ffffff",
            frameStroke: "#ffffff",
            frameFill: "#ffffff",
            frameText: "#000000",
            noteFill: "#eaeaea",
            noteText: "#1d1d1d",
            highlightSrgb: "#ffffff",
            highlightP3: "color(display-p3 1 1 1)"
        }
    }
};
function getDefaultColorTheme(opts) {
    return opts.isDarkMode ? DefaultColorThemePalette.darkMode : DefaultColorThemePalette.lightMode;
}
const DefaultColorStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:color", {
    defaultValue: "black",
    values: defaultColorNames
});
const DefaultLabelColorStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:labelColor", {
    defaultValue: "black",
    values: defaultColorNames
});
const defaultColorNamesSet = new Set(defaultColorNames);
function isDefaultThemeColor(color) {
    return defaultColorNamesSet.has(color);
}
function getColorValue(theme, color, variant) {
    if (!isDefaultThemeColor(color)) {
        return color;
    }
    return theme[color][variant];
}
;
 //# sourceMappingURL=TLColorStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultDashStyle",
    ()=>DefaultDashStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultDashStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:dash", {
    defaultValue: "draw",
    values: [
        "draw",
        "solid",
        "dashed",
        "dotted"
    ]
});
;
 //# sourceMappingURL=TLDashStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultFillStyle",
    ()=>DefaultFillStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultFillStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:fill", {
    defaultValue: "none",
    values: [
        "none",
        "semi",
        "solid",
        "pattern",
        "fill",
        "lined-fill"
    ]
});
;
 //# sourceMappingURL=TLFillStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultFontFamilies",
    ()=>DefaultFontFamilies,
    "DefaultFontStyle",
    ()=>DefaultFontStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultFontStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:font", {
    defaultValue: "draw",
    values: [
        "draw",
        "sans",
        "serif",
        "mono"
    ]
});
const DefaultFontFamilies = {
    draw: "'tldraw_draw', sans-serif",
    sans: "'tldraw_sans', sans-serif",
    serif: "'tldraw_serif', serif",
    mono: "'tldraw_mono', monospace"
};
;
 //# sourceMappingURL=TLFontStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultSizeStyle",
    ()=>DefaultSizeStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultSizeStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:size", {
    defaultValue: "m",
    values: [
        "s",
        "m",
        "l",
        "xl"
    ]
});
;
 //# sourceMappingURL=TLSizeStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLArrowShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowShapeArrowheadEndStyle",
    ()=>ArrowShapeArrowheadEndStyle,
    "ArrowShapeArrowheadStartStyle",
    ()=>ArrowShapeArrowheadStartStyle,
    "ArrowShapeKindStyle",
    ()=>ArrowShapeKindStyle,
    "arrowShapeMigrations",
    ()=>arrowShapeMigrations,
    "arrowShapeProps",
    ()=>arrowShapeProps,
    "arrowShapeVersions",
    ()=>arrowShapeVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$recordsWithProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/recordsWithProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const arrowKinds = [
    "arc",
    "elbow"
];
const ArrowShapeKindStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:arrowKind", {
    defaultValue: "arc",
    values: arrowKinds
});
const arrowheadTypes = [
    "arrow",
    "triangle",
    "square",
    "dot",
    "pipe",
    "diamond",
    "inverted",
    "bar",
    "none"
];
const ArrowShapeArrowheadStartStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:arrowheadStart", {
    defaultValue: "none",
    values: arrowheadTypes
});
const ArrowShapeArrowheadEndStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:arrowheadEnd", {
    defaultValue: "arrow",
    values: arrowheadTypes
});
const arrowShapeProps = {
    kind: ArrowShapeKindStyle,
    labelColor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultLabelColorStyle"],
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    fill: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"],
    dash: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    arrowheadStart: ArrowShapeArrowheadStartStyle,
    arrowheadEnd: ArrowShapeArrowheadEndStyle,
    font: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontStyle"],
    start: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    end: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    bend: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    richText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"],
    labelPosition: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    elbowMidPoint: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
};
const arrowShapeVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("arrow", {
    AddLabelColor: 1,
    AddIsPrecise: 2,
    AddLabelPosition: 3,
    ExtractBindings: 4,
    AddScale: 5,
    AddElbow: 6,
    AddRichText: 7,
    AddRichTextAttrs: 8
});
function propsMigration(migration) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$recordsWithProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPropsMigration"])("shape", "arrow", migration);
}
const arrowShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"])({
    sequenceId: "com.tldraw.shape.arrow",
    retroactive: false,
    sequence: [
        propsMigration({
            id: arrowShapeVersions.AddLabelColor,
            up: (props)=>{
                props.labelColor = "black";
            },
            down: "retired"
        }),
        propsMigration({
            id: arrowShapeVersions.AddIsPrecise,
            up: ({ start, end })=>{
                if (start.type === "binding") {
                    start.isPrecise = !(start.normalizedAnchor.x === 0.5 && start.normalizedAnchor.y === 0.5);
                }
                if (end.type === "binding") {
                    end.isPrecise = !(end.normalizedAnchor.x === 0.5 && end.normalizedAnchor.y === 0.5);
                }
            },
            down: ({ start, end })=>{
                if (start.type === "binding") {
                    if (!start.isPrecise) {
                        start.normalizedAnchor = {
                            x: 0.5,
                            y: 0.5
                        };
                    }
                    delete start.isPrecise;
                }
                if (end.type === "binding") {
                    if (!end.isPrecise) {
                        end.normalizedAnchor = {
                            x: 0.5,
                            y: 0.5
                        };
                    }
                    delete end.isPrecise;
                }
            }
        }),
        propsMigration({
            id: arrowShapeVersions.AddLabelPosition,
            up: (props)=>{
                props.labelPosition = 0.5;
            },
            down: (props)=>{
                delete props.labelPosition;
            }
        }),
        {
            id: arrowShapeVersions.ExtractBindings,
            scope: "storage",
            up: (storage)=>{
                const updates = [];
                for (const record of storage.values()){
                    if (record.typeName !== "shape" || record.type !== "arrow") continue;
                    const arrow = record;
                    const newArrow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(arrow);
                    const { start, end } = arrow.props;
                    if (start.type === "binding") {
                        const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])();
                        const binding = {
                            typeName: "binding",
                            id,
                            type: "arrow",
                            fromId: arrow.id,
                            toId: start.boundShapeId,
                            meta: {},
                            props: {
                                terminal: "start",
                                normalizedAnchor: start.normalizedAnchor,
                                isExact: start.isExact,
                                isPrecise: start.isPrecise
                            }
                        };
                        updates.push([
                            id,
                            binding
                        ]);
                        newArrow.props.start = {
                            x: 0,
                            y: 0
                        };
                    } else {
                        delete newArrow.props.start.type;
                    }
                    if (end.type === "binding") {
                        const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])();
                        const binding = {
                            typeName: "binding",
                            id,
                            type: "arrow",
                            fromId: arrow.id,
                            toId: end.boundShapeId,
                            meta: {},
                            props: {
                                terminal: "end",
                                normalizedAnchor: end.normalizedAnchor,
                                isExact: end.isExact,
                                isPrecise: end.isPrecise
                            }
                        };
                        updates.push([
                            id,
                            binding
                        ]);
                        newArrow.props.end = {
                            x: 0,
                            y: 0
                        };
                    } else {
                        delete newArrow.props.end.type;
                    }
                    updates.push([
                        arrow.id,
                        newArrow
                    ]);
                }
                for (const [id, record] of updates){
                    storage.set(id, record);
                }
            }
        },
        propsMigration({
            id: arrowShapeVersions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        }),
        propsMigration({
            id: arrowShapeVersions.AddElbow,
            up: (props)=>{
                props.kind = "arc";
                props.elbowMidPoint = 0.5;
            },
            down: (props)=>{
                delete props.kind;
                delete props.elbowMidPoint;
            }
        }),
        propsMigration({
            id: arrowShapeVersions.AddRichText,
            up: (props)=>{
                props.richText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(props.text);
                delete props.text;
            }
        }),
        propsMigration({
            id: arrowShapeVersions.AddRichTextAttrs,
            up: (_props)=>{},
            down: (props)=>{
                if (props.richText && "attrs" in props.richText) {
                    delete props.richText.attrs;
                }
            }
        })
    ]
});
;
 //# sourceMappingURL=TLArrowShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLArrowBinding.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ElbowArrowSnap",
    ()=>ElbowArrowSnap,
    "arrowBindingMigrations",
    ()=>arrowBindingMigrations,
    "arrowBindingProps",
    ()=>arrowBindingProps,
    "arrowBindingVersions",
    ()=>arrowBindingVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLArrowShape.mjs [app-client] (ecmascript)");
;
;
;
;
const ElbowArrowSnap = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("center", "edge-point", "edge", "none");
const arrowBindingProps = {
    terminal: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("start", "end"),
    normalizedAnchor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    isExact: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    isPrecise: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    snap: ElbowArrowSnap
};
const arrowBindingVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingPropsMigrationIds"])("arrow", {
    AddSnap: 1
});
const arrowBindingMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingPropsMigrationSequence"])({
    sequence: [
        {
            dependsOn: [
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeVersions"].ExtractBindings
            ]
        },
        {
            id: arrowBindingVersions.AddSnap,
            up: (props)=>{
                props.snap = "none";
            },
            down: (props)=>{
                delete props.snap;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLArrowBinding.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CameraRecordType",
    ()=>CameraRecordType,
    "cameraMigrations",
    ()=>cameraMigrations,
    "cameraValidator",
    ()=>cameraValidator,
    "cameraVersions",
    ()=>cameraVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
;
;
;
const cameraValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("camera", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("camera"),
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("camera"),
    x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    z: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
const cameraVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.camera", {
    AddMeta: 1
});
const cameraMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.camera",
    recordType: "camera",
    sequence: [
        {
            id: cameraVersions.AddMeta,
            up: (record)=>{
                ;
                record.meta = {};
            }
        }
    ]
});
const CameraRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("camera", {
    validator: cameraValidator,
    scope: "session"
}).withDefaultProperties(()=>({
        x: 0,
        y: 0,
        z: 1,
        meta: {}
    }));
;
 //# sourceMappingURL=TLCamera.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLCursor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TL_CURSOR_TYPES",
    ()=>TL_CURSOR_TYPES,
    "cursorTypeValidator",
    ()=>cursorTypeValidator,
    "cursorValidator",
    ()=>cursorValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
const TL_CURSOR_TYPES = /* @__PURE__ */ new Set([
    "none",
    "default",
    "pointer",
    "cross",
    "grab",
    "rotate",
    "grabbing",
    "resize-edge",
    "resize-corner",
    "text",
    "move",
    "ew-resize",
    "ns-resize",
    "nesw-resize",
    "nwse-resize",
    "nesw-rotate",
    "nwse-rotate",
    "swne-rotate",
    "senw-rotate",
    "zoom-in",
    "zoom-out"
]);
const cursorTypeValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].setEnum(TL_CURSOR_TYPES);
const cursorValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    type: cursorTypeValidator,
    rotation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
});
;
 //# sourceMappingURL=TLCursor.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLColor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TL_CANVAS_UI_COLOR_TYPES",
    ()=>TL_CANVAS_UI_COLOR_TYPES,
    "canvasUiColorTypeValidator",
    ()=>canvasUiColorTypeValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
const TL_CANVAS_UI_COLOR_TYPES = /* @__PURE__ */ new Set([
    "accent",
    "white",
    "black",
    "selection-stroke",
    "selection-fill",
    "laser",
    "muted-1"
]);
const canvasUiColorTypeValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].setEnum(TL_CANVAS_UI_COLOR_TYPES);
;
 //# sourceMappingURL=TLColor.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLScribble.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TL_SCRIBBLE_STATES",
    ()=>TL_SCRIBBLE_STATES,
    "scribbleValidator",
    ()=>scribbleValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLColor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
;
;
;
const TL_SCRIBBLE_STATES = /* @__PURE__ */ new Set([
    "starting",
    "paused",
    "active",
    "complete",
    "stopping"
]);
const scribbleValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    points: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"]),
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].positiveNumber,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canvasUiColorTypeValidator"],
    opacity: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    state: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].setEnum(TL_SCRIBBLE_STATES),
    delay: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    shrink: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    taper: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean
});
;
 //# sourceMappingURL=TLScribble.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PageRecordType",
    ()=>PageRecordType,
    "isPageId",
    ()=>isPageId,
    "pageIdValidator",
    ()=>pageIdValidator,
    "pageMigrations",
    ()=>pageMigrations,
    "pageValidator",
    ()=>pageValidator,
    "pageVersions",
    ()=>pageVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
;
;
;
const pageIdValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("page");
const pageValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("page", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("page"),
    id: pageIdValidator,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    index: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].indexKey,
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
const pageVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.page", {
    AddMeta: 1
});
const pageMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.page",
    recordType: "page",
    sequence: [
        {
            id: pageVersions.AddMeta,
            up: (record)=>{
                record.meta = {};
            }
        }
    ]
});
const PageRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("page", {
    validator: pageValidator,
    scope: "document"
}).withDefaultProperties(()=>({
        meta: {}
    }));
function isPageId(id) {
    return PageRecordType.isId(id);
}
;
 //# sourceMappingURL=TLPage.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TLINSTANCE_ID",
    ()=>TLINSTANCE_ID,
    "createInstanceRecordType",
    ()=>createInstanceRecordType,
    "instanceIdValidator",
    ()=>instanceIdValidator,
    "instanceMigrations",
    ()=>instanceMigrations,
    "instanceVersions",
    ()=>instanceVersions,
    "pluckPreservingValues",
    ()=>pluckPreservingValues,
    "shouldKeyBePreservedBetweenSessions",
    ()=>shouldKeyBePreservedBetweenSessions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLOpacity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLScribble.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const shouldKeyBePreservedBetweenSessions = {
    // This object defines keys that should be preserved across calls to loadSnapshot()
    id: false,
    // meta
    typeName: false,
    // meta
    currentPageId: false,
    // does not preserve because who knows if the page still exists
    opacityForNextShape: false,
    // does not preserve because it's a temporary state
    stylesForNextShape: false,
    // does not preserve because it's a temporary state
    followingUserId: false,
    // does not preserve because it's a temporary state
    highlightedUserIds: false,
    // does not preserve because it's a temporary state
    brush: false,
    // does not preserve because it's a temporary state
    cursor: false,
    // does not preserve because it's a temporary state
    scribbles: false,
    // does not preserve because it's a temporary state
    isFocusMode: true,
    // preserves because it's a user preference
    isDebugMode: true,
    // preserves because it's a user preference
    isToolLocked: true,
    // preserves because it's a user preference
    exportBackground: true,
    // preserves because it's a user preference
    screenBounds: true,
    // preserves because it's capturing the user's screen state
    insets: true,
    // preserves because it's capturing the user's screen state
    zoomBrush: false,
    // does not preserve because it's a temporary state
    chatMessage: false,
    // does not preserve because it's a temporary state
    isChatting: false,
    // does not preserve because it's a temporary state
    isPenMode: false,
    // does not preserve because it's a temporary state
    isGridMode: true,
    // preserves because it's a user preference
    isFocused: true,
    // preserves because obviously
    devicePixelRatio: true,
    // preserves because it captures the user's screen state
    isCoarsePointer: true,
    // preserves because it captures the user's screen state
    isHoveringCanvas: false,
    // does not preserve because it's a temporary state
    openMenus: false,
    // does not preserve because it's a temporary state
    isChangingStyle: false,
    // does not preserve because it's a temporary state
    isReadonly: true,
    // preserves because it's a config option
    meta: false,
    // does not preserve because who knows what's in there, leave it up to sdk users to save and reinstate
    duplicateProps: false,
    //
    cameraState: false
};
function pluckPreservingValues(val) {
    return val ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"])(val, (key)=>{
        return shouldKeyBePreservedBetweenSessions[key];
    }) : null;
}
const instanceIdValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("instance");
function createInstanceRecordType(stylesById) {
    const stylesForNextShapeValidators = {};
    for (const [id, style] of stylesById){
        stylesForNextShapeValidators[id] = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].optional(style);
    }
    const instanceTypeValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("instance", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("instance"),
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("instance"),
        currentPageId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageIdValidator"],
        followingUserId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable(),
        brush: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"].nullable(),
        opacityForNextShape: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opacityValidator"],
        stylesForNextShape: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object(stylesForNextShapeValidators),
        cursor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cursorValidator"],
        scribbles: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scribbleValidator"]),
        isFocusMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        isDebugMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        isToolLocked: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        exportBackground: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        screenBounds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"],
        insets: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean),
        zoomBrush: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"].nullable(),
        isPenMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        isGridMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        chatMessage: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
        isChatting: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        highlightedUserIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string),
        isFocused: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        devicePixelRatio: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        isCoarsePointer: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        isHoveringCanvas: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable(),
        openMenus: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string),
        isChangingStyle: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        isReadonly: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
        meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue,
        duplicateProps: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
            shapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("shape")),
            offset: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
                x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
                y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
            })
        }).nullable(),
        cameraState: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("idle", "moving")
    }));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("instance", {
        validator: instanceTypeValidator,
        scope: "session",
        ephemeralKeys: {
            currentPageId: false,
            meta: false,
            followingUserId: true,
            opacityForNextShape: true,
            stylesForNextShape: true,
            brush: true,
            cursor: true,
            scribbles: true,
            isFocusMode: true,
            isDebugMode: true,
            isToolLocked: true,
            exportBackground: true,
            screenBounds: true,
            insets: true,
            zoomBrush: true,
            isPenMode: true,
            isGridMode: true,
            chatMessage: true,
            isChatting: true,
            highlightedUserIds: true,
            isFocused: true,
            devicePixelRatio: true,
            isCoarsePointer: true,
            isHoveringCanvas: true,
            openMenus: true,
            isChangingStyle: true,
            isReadonly: true,
            duplicateProps: true,
            cameraState: true
        }
    }).withDefaultProperties(()=>({
            followingUserId: null,
            opacityForNextShape: 1,
            stylesForNextShape: {},
            brush: null,
            scribbles: [],
            cursor: {
                type: "default",
                rotation: 0
            },
            isFocusMode: false,
            exportBackground: false,
            isDebugMode: false,
            isToolLocked: false,
            screenBounds: {
                x: 0,
                y: 0,
                w: 1080,
                h: 720
            },
            insets: [
                false,
                false,
                false,
                false
            ],
            zoomBrush: null,
            isGridMode: false,
            isPenMode: false,
            chatMessage: "",
            isChatting: false,
            highlightedUserIds: [],
            isFocused: false,
            devicePixelRatio: typeof window === "undefined" ? 1 : window.devicePixelRatio,
            isCoarsePointer: false,
            isHoveringCanvas: null,
            openMenus: [],
            isChangingStyle: false,
            isReadonly: false,
            meta: {},
            duplicateProps: null,
            cameraState: "idle"
        }));
}
const instanceVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.instance", {
    AddTransparentExportBgs: 1,
    RemoveDialog: 2,
    AddToolLockMode: 3,
    RemoveExtraPropsForNextShape: 4,
    AddLabelColor: 5,
    AddFollowingUserId: 6,
    RemoveAlignJustify: 7,
    AddZoom: 8,
    AddVerticalAlign: 9,
    AddScribbleDelay: 10,
    RemoveUserId: 11,
    AddIsPenModeAndIsGridMode: 12,
    HoistOpacity: 13,
    AddChat: 14,
    AddHighlightedUserIds: 15,
    ReplacePropsForNextShapeWithStylesForNextShape: 16,
    AddMeta: 17,
    RemoveCursorColor: 18,
    AddLonelyProperties: 19,
    ReadOnlyReadonly: 20,
    AddHoveringCanvas: 21,
    AddScribbles: 22,
    AddInset: 23,
    AddDuplicateProps: 24,
    RemoveCanMoveCamera: 25,
    AddCameraState: 26
});
const instanceMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.instance",
    recordType: "instance",
    sequence: [
        {
            id: instanceVersions.AddTransparentExportBgs,
            up: (instance)=>{
                return {
                    ...instance,
                    exportBackground: true
                };
            }
        },
        {
            id: instanceVersions.RemoveDialog,
            up: ({ dialog: _, ...instance })=>{
                return instance;
            }
        },
        {
            id: instanceVersions.AddToolLockMode,
            up: (instance)=>{
                return {
                    ...instance,
                    isToolLocked: false
                };
            }
        },
        {
            id: instanceVersions.RemoveExtraPropsForNextShape,
            up: ({ propsForNextShape, ...instance })=>{
                return {
                    ...instance,
                    propsForNextShape: Object.fromEntries(Object.entries(propsForNextShape).filter(([key])=>[
                            "color",
                            "labelColor",
                            "dash",
                            "fill",
                            "size",
                            "font",
                            "align",
                            "verticalAlign",
                            "icon",
                            "geo",
                            "arrowheadStart",
                            "arrowheadEnd",
                            "spline"
                        ].includes(key)))
                };
            }
        },
        {
            id: instanceVersions.AddLabelColor,
            up: ({ propsForNextShape, ...instance })=>{
                return {
                    ...instance,
                    propsForNextShape: {
                        ...propsForNextShape,
                        labelColor: "black"
                    }
                };
            }
        },
        {
            id: instanceVersions.AddFollowingUserId,
            up: (instance)=>{
                return {
                    ...instance,
                    followingUserId: null
                };
            }
        },
        {
            id: instanceVersions.RemoveAlignJustify,
            up: (instance)=>{
                let newAlign = instance.propsForNextShape.align;
                if (newAlign === "justify") {
                    newAlign = "start";
                }
                return {
                    ...instance,
                    propsForNextShape: {
                        ...instance.propsForNextShape,
                        align: newAlign
                    }
                };
            }
        },
        {
            id: instanceVersions.AddZoom,
            up: (instance)=>{
                return {
                    ...instance,
                    zoomBrush: null
                };
            }
        },
        {
            id: instanceVersions.AddVerticalAlign,
            up: (instance)=>{
                return {
                    ...instance,
                    propsForNextShape: {
                        ...instance.propsForNextShape,
                        verticalAlign: "middle"
                    }
                };
            }
        },
        {
            id: instanceVersions.AddScribbleDelay,
            up: (instance)=>{
                if (instance.scribble !== null) {
                    return {
                        ...instance,
                        scribble: {
                            ...instance.scribble,
                            delay: 0
                        }
                    };
                }
                return {
                    ...instance
                };
            }
        },
        {
            id: instanceVersions.RemoveUserId,
            up: ({ userId: _, ...instance })=>{
                return instance;
            }
        },
        {
            id: instanceVersions.AddIsPenModeAndIsGridMode,
            up: (instance)=>{
                return {
                    ...instance,
                    isPenMode: false,
                    isGridMode: false
                };
            }
        },
        {
            id: instanceVersions.HoistOpacity,
            up: ({ propsForNextShape: { opacity, ...propsForNextShape }, ...instance })=>{
                return {
                    ...instance,
                    opacityForNextShape: Number(opacity ?? "1"),
                    propsForNextShape
                };
            }
        },
        {
            id: instanceVersions.AddChat,
            up: (instance)=>{
                return {
                    ...instance,
                    chatMessage: "",
                    isChatting: false
                };
            }
        },
        {
            id: instanceVersions.AddHighlightedUserIds,
            up: (instance)=>{
                return {
                    ...instance,
                    highlightedUserIds: []
                };
            }
        },
        {
            id: instanceVersions.ReplacePropsForNextShapeWithStylesForNextShape,
            up: ({ propsForNextShape: _, ...instance })=>{
                return {
                    ...instance,
                    stylesForNextShape: {}
                };
            }
        },
        {
            id: instanceVersions.AddMeta,
            up: (record)=>{
                return {
                    ...record,
                    meta: {}
                };
            }
        },
        {
            id: instanceVersions.RemoveCursorColor,
            up: (record)=>{
                const { color: _, ...cursor } = record.cursor;
                return {
                    ...record,
                    cursor
                };
            }
        },
        {
            id: instanceVersions.AddLonelyProperties,
            up: (record)=>{
                return {
                    ...record,
                    canMoveCamera: true,
                    isFocused: false,
                    devicePixelRatio: 1,
                    isCoarsePointer: false,
                    openMenus: [],
                    isChangingStyle: false,
                    isReadOnly: false
                };
            }
        },
        {
            id: instanceVersions.ReadOnlyReadonly,
            up: ({ isReadOnly: _isReadOnly, ...record })=>{
                return {
                    ...record,
                    isReadonly: _isReadOnly
                };
            }
        },
        {
            id: instanceVersions.AddHoveringCanvas,
            up: (record)=>{
                return {
                    ...record,
                    isHoveringCanvas: null
                };
            }
        },
        {
            id: instanceVersions.AddScribbles,
            up: ({ scribble: _, ...record })=>{
                return {
                    ...record,
                    scribbles: []
                };
            }
        },
        {
            id: instanceVersions.AddInset,
            up: (record)=>{
                return {
                    ...record,
                    insets: [
                        false,
                        false,
                        false,
                        false
                    ]
                };
            },
            down: ({ insets: _, ...record })=>{
                return {
                    ...record
                };
            }
        },
        {
            id: instanceVersions.AddDuplicateProps,
            up: (record)=>{
                return {
                    ...record,
                    duplicateProps: null
                };
            },
            down: ({ duplicateProps: _, ...record })=>{
                return {
                    ...record
                };
            }
        },
        {
            id: instanceVersions.RemoveCanMoveCamera,
            up: ({ canMoveCamera: _, ...record })=>{
                return {
                    ...record
                };
            },
            down: (instance)=>{
                return {
                    ...instance,
                    canMoveCamera: true
                };
            }
        },
        {
            id: instanceVersions.AddCameraState,
            up: (record)=>{
                return {
                    ...record,
                    cameraState: "idle"
                };
            },
            down: ({ cameraState: _, ...record })=>{
                return record;
            }
        }
    ]
});
const TLINSTANCE_ID = "instance:instance";
;
 //# sourceMappingURL=TLInstance.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InstancePageStateRecordType",
    ()=>InstancePageStateRecordType,
    "instancePageStateMigrations",
    ()=>instancePageStateMigrations,
    "instancePageStateValidator",
    ()=>instancePageStateValidator,
    "instancePageStateVersions",
    ()=>instancePageStateVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
;
;
;
;
;
const instancePageStateValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("instance_page_state", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("instance_page_state"),
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("instance_page_state"),
    pageId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageIdValidator"],
    selectedShapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"]),
    hintingShapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"]),
    erasingShapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"]),
    hoveredShapeId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"].nullable(),
    editingShapeId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"].nullable(),
    croppingShapeId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"].nullable(),
    focusedGroupId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"].nullable(),
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
const instancePageStateVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.instance_page_state", {
    AddCroppingId: 1,
    RemoveInstanceIdAndCameraId: 2,
    AddMeta: 3,
    RenameProperties: 4,
    RenamePropertiesAgain: 5
});
const instancePageStateMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.instance_page_state",
    recordType: "instance_page_state",
    sequence: [
        {
            id: instancePageStateVersions.AddCroppingId,
            up (instance) {
                instance.croppingShapeId = null;
            }
        },
        {
            id: instancePageStateVersions.RemoveInstanceIdAndCameraId,
            up (instance) {
                delete instance.instanceId;
                delete instance.cameraId;
            }
        },
        {
            id: instancePageStateVersions.AddMeta,
            up: (record)=>{
                record.meta = {};
            }
        },
        {
            id: instancePageStateVersions.RenameProperties,
            // this migration is cursed: it was written wrong and doesn't do anything.
            // rather than replace it, I've added another migration below that fixes it.
            up: (_record)=>{},
            down: (_record)=>{}
        },
        {
            id: instancePageStateVersions.RenamePropertiesAgain,
            up: (record)=>{
                record.selectedShapeIds = record.selectedIds;
                delete record.selectedIds;
                record.hintingShapeIds = record.hintingIds;
                delete record.hintingIds;
                record.erasingShapeIds = record.erasingIds;
                delete record.erasingIds;
                record.hoveredShapeId = record.hoveredId;
                delete record.hoveredId;
                record.editingShapeId = record.editingId;
                delete record.editingId;
                record.croppingShapeId = record.croppingShapeId ?? record.croppingId ?? null;
                delete record.croppingId;
                record.focusedGroupId = record.focusLayerId;
                delete record.focusLayerId;
            },
            down: (record)=>{
                record.selectedIds = record.selectedShapeIds;
                delete record.selectedShapeIds;
                record.hintingIds = record.hintingShapeIds;
                delete record.hintingShapeIds;
                record.erasingIds = record.erasingShapeIds;
                delete record.erasingShapeIds;
                record.hoveredId = record.hoveredShapeId;
                delete record.hoveredShapeId;
                record.editingId = record.editingShapeId;
                delete record.editingShapeId;
                record.croppingId = record.croppingShapeId;
                delete record.croppingShapeId;
                record.focusLayerId = record.focusedGroupId;
                delete record.focusedGroupId;
            }
        }
    ]
});
const InstancePageStateRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("instance_page_state", {
    validator: instancePageStateValidator,
    scope: "session",
    ephemeralKeys: {
        pageId: false,
        selectedShapeIds: false,
        editingShapeId: false,
        croppingShapeId: false,
        meta: false,
        hintingShapeIds: true,
        erasingShapeIds: true,
        hoveredShapeId: true,
        focusedGroupId: true
    }
}).withDefaultProperties(()=>({
        editingShapeId: null,
        croppingShapeId: null,
        selectedShapeIds: [],
        hoveredShapeId: null,
        erasingShapeIds: [],
        hintingShapeIds: [],
        focusedGroupId: null,
        meta: {}
    }));
;
 //# sourceMappingURL=TLPageState.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PointerRecordType",
    ()=>PointerRecordType,
    "TLPOINTER_ID",
    ()=>TLPOINTER_ID,
    "pointerMigrations",
    ()=>pointerMigrations,
    "pointerValidator",
    ()=>pointerValidator,
    "pointerVersions",
    ()=>pointerVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
;
;
;
const pointerValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("pointer", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("pointer"),
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("pointer"),
    x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    lastActivityTimestamp: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
const pointerVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.pointer", {
    AddMeta: 1
});
const pointerMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.pointer",
    recordType: "pointer",
    sequence: [
        {
            id: pointerVersions.AddMeta,
            up: (record)=>{
                record.meta = {};
            }
        }
    ]
});
const PointerRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("pointer", {
    validator: pointerValidator,
    scope: "session"
}).withDefaultProperties(()=>({
        x: 0,
        y: 0,
        lastActivityTimestamp: 0,
        meta: {}
    }));
const TLPOINTER_ID = PointerRecordType.createId("pointer");
;
 //# sourceMappingURL=TLPointer.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPresence.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InstancePresenceRecordType",
    ()=>InstancePresenceRecordType,
    "instancePresenceMigrations",
    ()=>instancePresenceMigrations,
    "instancePresenceValidator",
    ()=>instancePresenceValidator,
    "instancePresenceVersions",
    ()=>instancePresenceVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLScribble.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const instancePresenceValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("instance_presence", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("instance_presence"),
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("instance_presence"),
    userId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    userName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    lastActivityTimestamp: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number.nullable(),
    followingUserId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable(),
    cursor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cursorTypeValidator"],
        rotation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
    }).nullable(),
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    camera: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
        z: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
    }).nullable(),
    screenBounds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"].nullable(),
    selectedShapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("shape")),
    currentPageId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"])("page"),
    brush: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"].nullable(),
    scribbles: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scribbleValidator"]),
    chatMessage: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
const instancePresenceVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.instance_presence", {
    AddScribbleDelay: 1,
    RemoveInstanceId: 2,
    AddChatMessage: 3,
    AddMeta: 4,
    RenameSelectedShapeIds: 5,
    NullableCameraCursor: 6
});
const instancePresenceMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.instance_presence",
    recordType: "instance_presence",
    sequence: [
        {
            id: instancePresenceVersions.AddScribbleDelay,
            up: (instance)=>{
                if (instance.scribble !== null) {
                    instance.scribble.delay = 0;
                }
            }
        },
        {
            id: instancePresenceVersions.RemoveInstanceId,
            up: (instance)=>{
                delete instance.instanceId;
            }
        },
        {
            id: instancePresenceVersions.AddChatMessage,
            up: (instance)=>{
                instance.chatMessage = "";
            }
        },
        {
            id: instancePresenceVersions.AddMeta,
            up: (record)=>{
                record.meta = {};
            }
        },
        {
            id: instancePresenceVersions.RenameSelectedShapeIds,
            up: (_record)=>{}
        },
        {
            id: instancePresenceVersions.NullableCameraCursor,
            up: (_record)=>{},
            down: (record)=>{
                if (record.camera === null) {
                    record.camera = {
                        x: 0,
                        y: 0,
                        z: 1
                    };
                }
                if (record.lastActivityTimestamp === null) {
                    record.lastActivityTimestamp = 0;
                }
                if (record.cursor === null) {
                    record.cursor = {
                        type: "default",
                        x: 0,
                        y: 0,
                        rotation: 0
                    };
                }
                if (record.screenBounds === null) {
                    record.screenBounds = {
                        x: 0,
                        y: 0,
                        w: 1,
                        h: 1
                    };
                }
            }
        }
    ]
});
const InstancePresenceRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("instance_presence", {
    validator: instancePresenceValidator,
    scope: "presence"
}).withDefaultProperties(()=>({
        lastActivityTimestamp: null,
        followingUserId: null,
        color: "#FF0000",
        camera: null,
        cursor: null,
        screenBounds: null,
        selectedShapeIds: [],
        brush: null,
        scribbles: [],
        chatMessage: "",
        meta: {}
    }));
;
 //# sourceMappingURL=TLPresence.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createPresenceStateDerivation.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createPresenceStateDerivation",
    ()=>createPresenceStateDerivation,
    "getDefaultUserPresence",
    ()=>getDefaultUserPresence
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPresence.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
function createPresenceStateDerivation($user, instanceId) {
    return (store)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("instancePresence", ()=>{
            const user = $user.get();
            if (!user) return null;
            const state = getDefaultUserPresence(store, user);
            if (!state) return null;
            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePresenceRecordType"].create({
                ...state,
                id: instanceId ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePresenceRecordType"].createId(store.id)
            });
        });
    };
}
function getDefaultUserPresence(store, user) {
    const instance = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
    const pageState = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(instance?.currentPageId));
    const camera = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(instance?.currentPageId));
    const pointer = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"]);
    if (!pageState || !instance || !camera || !pointer) {
        return null;
    }
    return {
        selectedShapeIds: pageState.selectedShapeIds,
        brush: instance.brush,
        scribbles: instance.scribbles,
        userId: user.id,
        userName: user.name ?? "",
        followingUserId: instance.followingUserId,
        camera: {
            x: camera.x,
            y: camera.y,
            z: camera.z
        },
        color: user.color ?? "#FF0000",
        currentPageId: instance.currentPageId,
        cursor: {
            x: pointer.x,
            y: pointer.y,
            rotation: instance.cursor.rotation,
            type: instance.cursor.type
        },
        lastActivityTimestamp: pointer.lastActivityTimestamp,
        screenBounds: instance.screenBounds,
        chatMessage: instance.chatMessage,
        meta: {}
    };
}
;
 //# sourceMappingURL=createPresenceStateDerivation.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DocumentRecordType",
    ()=>DocumentRecordType,
    "TLDOCUMENT_ID",
    ()=>TLDOCUMENT_ID,
    "documentMigrations",
    ()=>documentMigrations,
    "documentValidator",
    ()=>documentValidator,
    "documentVersions",
    ()=>documentVersions,
    "isDocument",
    ()=>isDocument
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
;
const documentValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("document", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("document"),
    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literal("document:document"),
    gridSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    meta: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].jsonValue
}));
function isDocument(record) {
    if (!record) return false;
    return record.typeName === "document";
}
const documentVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.document", {
    AddName: 1,
    AddMeta: 2
});
const documentMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.document",
    recordType: "document",
    sequence: [
        {
            id: documentVersions.AddName,
            up: (document)=>{
                ;
                document.name = "";
            },
            down: (document)=>{
                delete document.name;
            }
        },
        {
            id: documentVersions.AddMeta,
            up: (record)=>{
                ;
                record.meta = {};
            }
        }
    ]
});
const DocumentRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("document", {
    validator: documentValidator,
    scope: "document"
}).withDefaultProperties(()=>({
        gridSize: 10,
        name: "",
        meta: {}
    }));
const TLDOCUMENT_ID = DocumentRecordType.createId("document");
;
 //# sourceMappingURL=TLDocument.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/TLStore.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createIntegrityChecker",
    ()=>createIntegrityChecker,
    "onValidationFailure",
    ()=>onValidationFailure,
    "redactRecordForErrorReporting",
    ()=>redactRecordForErrorReporting
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
function redactRecordForErrorReporting(record) {
    if (record.typeName === "asset") {
        if ("src" in record) {
            record.src = "<redacted>";
        }
        if ("src" in record.props) {
            record.props.src = "<redacted>";
        }
    }
}
function onValidationFailure({ error, phase, record, recordBefore }) {
    const isExistingValidationIssue = phase === "initialize";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["annotateError"])(error, {
        tags: {
            origin: "store.validateRecord",
            storePhase: phase,
            isExistingValidationIssue
        },
        extras: {
            recordBefore: recordBefore ? redactRecordForErrorReporting((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(recordBefore)) : void 0,
            recordAfter: redactRecordForErrorReporting((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(record))
        }
    });
    throw error;
}
function getDefaultPages() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].create({
            id: "page:page",
            name: "Page 1",
            index: "a1",
            meta: {}
        })
    ];
}
function createIntegrityChecker(store) {
    const $pageIds = store.query.ids("page");
    const $pageStates = store.query.records("instance_page_state");
    const ensureStoreIsUsable = ()=>{
        if (!store.has(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLDOCUMENT_ID"])) {
            store.put([
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentRecordType"].create({
                    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLDOCUMENT_ID"],
                    name: store.props.defaultName
                })
            ]);
            return ensureStoreIsUsable();
        }
        if (!store.has(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"])) {
            store.put([
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerRecordType"].create({
                    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"]
                })
            ]);
            return ensureStoreIsUsable();
        }
        const pageIds = $pageIds.get();
        if (pageIds.size === 0) {
            store.put(getDefaultPages());
            return ensureStoreIsUsable();
        }
        const getFirstPageId = ()=>[
                ...pageIds
            ].map((id)=>store.get(id)).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"])[0].id;
        const instanceState = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        if (!instanceState) {
            store.put([
                store.schema.types.instance.create({
                    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"],
                    currentPageId: getFirstPageId(),
                    exportBackground: true
                })
            ]);
            return ensureStoreIsUsable();
        } else if (!pageIds.has(instanceState.currentPageId)) {
            store.put([
                {
                    ...instanceState,
                    currentPageId: getFirstPageId()
                }
            ]);
            return ensureStoreIsUsable();
        }
        const missingPageStateIds = /* @__PURE__ */ new Set();
        const missingCameraIds = /* @__PURE__ */ new Set();
        for (const id of pageIds){
            const pageStateId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(id);
            const pageState = store.get(pageStateId);
            if (!pageState) {
                missingPageStateIds.add(pageStateId);
            }
            const cameraId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(id);
            if (!store.has(cameraId)) {
                missingCameraIds.add(cameraId);
            }
        }
        if (missingPageStateIds.size > 0) {
            store.put([
                ...missingPageStateIds
            ].map((id)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].create({
                    id,
                    pageId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].parseId(id)
                })));
        }
        if (missingCameraIds.size > 0) {
            store.put([
                ...missingCameraIds
            ].map((id)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].create({
                    id
                })));
        }
        const pageStates = $pageStates.get();
        for (const pageState of pageStates){
            if (!pageIds.has(pageState.pageId)) {
                store.remove([
                    pageState.id
                ]);
                continue;
            }
            if (pageState.croppingShapeId && !store.has(pageState.croppingShapeId)) {
                store.put([
                    {
                        ...pageState,
                        croppingShapeId: null
                    }
                ]);
                return ensureStoreIsUsable();
            }
            if (pageState.focusedGroupId && !store.has(pageState.focusedGroupId)) {
                store.put([
                    {
                        ...pageState,
                        focusedGroupId: null
                    }
                ]);
                return ensureStoreIsUsable();
            }
            if (pageState.hoveredShapeId && !store.has(pageState.hoveredShapeId)) {
                store.put([
                    {
                        ...pageState,
                        hoveredShapeId: null
                    }
                ]);
                return ensureStoreIsUsable();
            }
            const filteredSelectedIds = pageState.selectedShapeIds.filter((id)=>store.has(id));
            if (filteredSelectedIds.length !== pageState.selectedShapeIds.length) {
                store.put([
                    {
                        ...pageState,
                        selectedShapeIds: filteredSelectedIds
                    }
                ]);
                return ensureStoreIsUsable();
            }
            const filteredHintingIds = pageState.hintingShapeIds.filter((id)=>store.has(id));
            if (filteredHintingIds.length !== pageState.hintingShapeIds.length) {
                store.put([
                    {
                        ...pageState,
                        hintingShapeIds: filteredHintingIds
                    }
                ]);
                return ensureStoreIsUsable();
            }
            const filteredErasingIds = pageState.erasingShapeIds.filter((id)=>store.has(id));
            if (filteredErasingIds.length !== pageState.erasingShapeIds.length) {
                store.put([
                    {
                        ...pageState,
                        erasingShapeIds: filteredErasingIds
                    }
                ]);
                return ensureStoreIsUsable();
            }
        }
    };
    return ensureStoreIsUsable;
}
;
 //# sourceMappingURL=TLStore.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBookmarkAsset.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bookmarkAssetMigrations",
    ()=>bookmarkAssetMigrations,
    "bookmarkAssetValidator",
    ()=>bookmarkAssetValidator,
    "bookmarkAssetVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
;
;
;
const bookmarkAssetValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAssetValidator"])("bookmark", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    title: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    image: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    favicon: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    src: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.nullable()
}));
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.asset.bookmark", {
    MakeUrlsValid: 1,
    AddFavicon: 2
});
const bookmarkAssetMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.asset.bookmark",
    recordType: "asset",
    filter: (asset)=>asset.type === "bookmark",
    sequence: [
        {
            id: Versions.MakeUrlsValid,
            up: (asset)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.isValid(asset.props.src)) {
                    asset.props.src = "";
                }
            },
            down: (_asset)=>{}
        },
        {
            id: Versions.AddFavicon,
            up: (asset)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.isValid(asset.props.favicon)) {
                    asset.props.favicon = "";
                }
            },
            down: (asset)=>{
                delete asset.props.favicon;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLBookmarkAsset.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLImageAsset.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "imageAssetMigrations",
    ()=>imageAssetMigrations,
    "imageAssetValidator",
    ()=>imageAssetValidator,
    "imageAssetVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
;
;
;
const imageAssetValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAssetValidator"])("image", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    isAnimated: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    mimeType: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable(),
    src: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.nullable(),
    fileSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber.optional()
}));
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.asset.image", {
    AddIsAnimated: 1,
    RenameWidthHeight: 2,
    MakeUrlsValid: 3,
    AddFileSize: 4,
    MakeFileSizeOptional: 5
});
const imageAssetMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.asset.image",
    recordType: "asset",
    filter: (asset)=>asset.type === "image",
    sequence: [
        {
            id: Versions.AddIsAnimated,
            up: (asset)=>{
                asset.props.isAnimated = false;
            },
            down: (asset)=>{
                delete asset.props.isAnimated;
            }
        },
        {
            id: Versions.RenameWidthHeight,
            up: (asset)=>{
                asset.props.w = asset.props.width;
                asset.props.h = asset.props.height;
                delete asset.props.width;
                delete asset.props.height;
            },
            down: (asset)=>{
                asset.props.width = asset.props.w;
                asset.props.height = asset.props.h;
                delete asset.props.w;
                delete asset.props.h;
            }
        },
        {
            id: Versions.MakeUrlsValid,
            up: (asset)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.isValid(asset.props.src)) {
                    asset.props.src = "";
                }
            },
            down: (_asset)=>{}
        },
        {
            id: Versions.AddFileSize,
            up: (asset)=>{
                asset.props.fileSize = -1;
            },
            down: (asset)=>{
                delete asset.props.fileSize;
            }
        },
        {
            id: Versions.MakeFileSizeOptional,
            up: (asset)=>{
                if (asset.props.fileSize === -1) {
                    asset.props.fileSize = void 0;
                }
            },
            down: (asset)=>{
                if (asset.props.fileSize === void 0) {
                    asset.props.fileSize = -1;
                }
            }
        }
    ]
});
;
 //# sourceMappingURL=TLImageAsset.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLVideoAsset.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "videoAssetMigrations",
    ()=>videoAssetMigrations,
    "videoAssetValidator",
    ()=>videoAssetValidator,
    "videoAssetVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
;
;
;
const videoAssetValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAssetValidator"])("video", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    isAnimated: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    mimeType: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable(),
    src: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.nullable(),
    fileSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number.optional()
}));
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.asset.video", {
    AddIsAnimated: 1,
    RenameWidthHeight: 2,
    MakeUrlsValid: 3,
    AddFileSize: 4,
    MakeFileSizeOptional: 5
});
const videoAssetMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.asset.video",
    recordType: "asset",
    filter: (asset)=>asset.type === "video",
    sequence: [
        {
            id: Versions.AddIsAnimated,
            up: (asset)=>{
                asset.props.isAnimated = false;
            },
            down: (asset)=>{
                delete asset.props.isAnimated;
            }
        },
        {
            id: Versions.RenameWidthHeight,
            up: (asset)=>{
                asset.props.w = asset.props.width;
                asset.props.h = asset.props.height;
                delete asset.props.width;
                delete asset.props.height;
            },
            down: (asset)=>{
                asset.props.width = asset.props.w;
                asset.props.height = asset.props.h;
                delete asset.props.w;
                delete asset.props.h;
            }
        },
        {
            id: Versions.MakeUrlsValid,
            up: (asset)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].srcUrl.isValid(asset.props.src)) {
                    asset.props.src = "";
                }
            },
            down: (_asset)=>{}
        },
        {
            id: Versions.AddFileSize,
            up: (asset)=>{
                asset.props.fileSize = -1;
            },
            down: (asset)=>{
                delete asset.props.fileSize;
            }
        },
        {
            id: Versions.MakeFileSizeOptional,
            up: (asset)=>{
                if (asset.props.fileSize === -1) {
                    asset.props.fileSize = void 0;
                }
            },
            down: (asset)=>{
                if (asset.props.fileSize === void 0) {
                    asset.props.fileSize = -1;
                }
            }
        }
    ]
});
;
 //# sourceMappingURL=TLVideoAsset.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLAsset.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AssetRecordType",
    ()=>AssetRecordType,
    "assetMigrations",
    ()=>assetMigrations,
    "assetValidator",
    ()=>assetValidator,
    "assetVersions",
    ()=>assetVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBookmarkAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBookmarkAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLImageAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLImageAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLVideoAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLVideoAsset.mjs [app-client] (ecmascript)");
;
;
;
;
;
const assetValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].model("asset", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].union("type", {
    image: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLImageAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageAssetValidator"],
    video: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLVideoAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoAssetValidator"],
    bookmark: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBookmarkAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkAssetValidator"]
}));
const assetVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.asset", {
    AddMeta: 1
});
const assetMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"])({
    sequenceId: "com.tldraw.asset",
    recordType: "asset",
    sequence: [
        {
            id: assetVersions.AddMeta,
            up: (record)=>{
                ;
                record.meta = {};
            }
        }
    ]
});
const AssetRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"])("asset", {
    validator: assetValidator,
    scope: "document"
}).withDefaultProperties(()=>({
        meta: {}
    }));
;
 //# sourceMappingURL=TLAsset.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBookmarkShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bookmarkShapeMigrations",
    ()=>bookmarkShapeMigrations,
    "bookmarkShapeProps",
    ()=>bookmarkShapeProps,
    "bookmarkShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
;
;
const bookmarkShapeProps = {
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    assetId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetIdValidator"].nullable(),
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("bookmark", {
    NullAssetId: 1,
    MakeUrlsValid: 2
});
const bookmarkShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.NullAssetId,
            up: (props)=>{
                if (props.assetId === void 0) {
                    props.assetId = null;
                }
            },
            down: "retired"
        },
        {
            id: Versions.MakeUrlsValid,
            up: (props)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl.isValid(props.url)) {
                    props.url = "";
                }
            },
            down: (_props)=>{}
        }
    ]
});
;
 //# sourceMappingURL=TLBookmarkShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/b64Vecs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "b64Vecs",
    ()=>b64Vecs,
    "fallbackBase64ToUint8Array",
    ()=>fallbackBase64ToUint8Array,
    "fallbackUint8ArrayToBase64",
    ()=>fallbackUint8ArrayToBase64,
    "float16BitsToNumber",
    ()=>float16BitsToNumber,
    "numberToFloat16Bits",
    ()=>numberToFloat16Bits
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
;
const _POINT_B64_LENGTH = 8;
const FIRST_POINT_B64_LENGTH = 16;
const BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const B64_LOOKUP = new Uint8Array(128);
for(let i = 0; i < 64; i++){
    B64_LOOKUP[BASE64_CHARS.charCodeAt(i)] = i;
}
const POW2 = new Float64Array(31);
for(let i = 0; i < 31; i++){
    POW2[i] = Math.pow(2, i - 15);
}
const POW2_SUBNORMAL = Math.pow(2, -14) / 1024;
const MANTISSA = new Float64Array(1024);
for(let i = 0; i < 1024; i++){
    MANTISSA[i] = 1 + i / 1024;
}
function nativeGetFloat16(dataView, offset) {
    return dataView.getFloat16(offset, true);
}
function fallbackGetFloat16(dataView, offset) {
    return float16BitsToNumber(dataView.getUint16(offset, true));
}
const getFloat16 = typeof DataView.prototype.getFloat16 === "function" ? nativeGetFloat16 : fallbackGetFloat16;
function nativeSetFloat16(dataView, offset, value) {
    ;
    dataView.setFloat16(offset, value, true);
}
function fallbackSetFloat16(dataView, offset, value) {
    dataView.setUint16(offset, numberToFloat16Bits(value), true);
}
const setFloat16 = typeof DataView.prototype.setFloat16 === "function" ? nativeSetFloat16 : fallbackSetFloat16;
function nativeBase64ToUint8Array(base64) {
    return Uint8Array.fromBase64(base64);
}
function fallbackBase64ToUint8Array(base64) {
    const numBytes = Math.floor(base64.length * 3 / 4);
    const bytes = new Uint8Array(numBytes);
    let byteIndex = 0;
    for(let i = 0; i < base64.length; i += 4){
        const c0 = B64_LOOKUP[base64.charCodeAt(i)];
        const c1 = B64_LOOKUP[base64.charCodeAt(i + 1)];
        const c2 = B64_LOOKUP[base64.charCodeAt(i + 2)];
        const c3 = B64_LOOKUP[base64.charCodeAt(i + 3)];
        const bitmap = c0 << 18 | c1 << 12 | c2 << 6 | c3;
        bytes[byteIndex++] = bitmap >> 16 & 255;
        bytes[byteIndex++] = bitmap >> 8 & 255;
        bytes[byteIndex++] = bitmap & 255;
    }
    return bytes;
}
function nativeUint8ArrayToBase64(uint8Array) {
    return uint8Array.toBase64();
}
function fallbackUint8ArrayToBase64(uint8Array) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(uint8Array.length % 3 === 0, "Uint8Array length must be a multiple of 3");
    let result = "";
    for(let i = 0; i < uint8Array.length; i += 3){
        const byte1 = uint8Array[i];
        const byte2 = uint8Array[i + 1];
        const byte3 = uint8Array[i + 2];
        const bitmap = byte1 << 16 | byte2 << 8 | byte3;
        result += BASE64_CHARS[bitmap >> 18 & 63] + BASE64_CHARS[bitmap >> 12 & 63] + BASE64_CHARS[bitmap >> 6 & 63] + BASE64_CHARS[bitmap & 63];
    }
    return result;
}
const uint8ArrayToBase64 = typeof Uint8Array.prototype.toBase64 === "function" ? nativeUint8ArrayToBase64 : fallbackUint8ArrayToBase64;
const base64ToUint8Array = typeof Uint8Array.fromBase64 === "function" ? nativeBase64ToUint8Array : fallbackBase64ToUint8Array;
function float16BitsToNumber(bits) {
    const sign = bits >> 15;
    const exp = bits >> 10 & 31;
    const frac = bits & 1023;
    if (exp === 0) {
        return sign ? -frac * POW2_SUBNORMAL : frac * POW2_SUBNORMAL;
    }
    if (exp === 31) {
        return frac ? NaN : sign ? -Infinity : Infinity;
    }
    const magnitude = POW2[exp] * MANTISSA[frac];
    return sign ? -magnitude : magnitude;
}
function numberToFloat16Bits(value) {
    if (value === 0) return Object.is(value, -0) ? 32768 : 0;
    if (!Number.isFinite(value)) {
        if (Number.isNaN(value)) return 32256;
        return value > 0 ? 31744 : 64512;
    }
    const sign = value < 0 ? 1 : 0;
    value = Math.abs(value);
    const exp = Math.floor(Math.log2(value));
    let expBiased = exp + 15;
    if (expBiased >= 31) {
        return sign << 15 | 31744;
    }
    if (expBiased <= 0) {
        const frac2 = Math.round(value * Math.pow(2, 14) * 1024);
        return sign << 15 | frac2 & 1023;
    }
    const mantissa = value / Math.pow(2, exp) - 1;
    let frac = Math.round(mantissa * 1024);
    if (frac >= 1024) {
        frac = 0;
        expBiased++;
        if (expBiased >= 31) {
            return sign << 15 | 31744;
        }
    }
    return sign << 15 | expBiased << 10 | frac;
}
class b64Vecs {
    /**
   * Encode a single point (x, y, z) to 8 base64 characters using legacy Float16 encoding.
   * Each coordinate is encoded as a Float16 value, resulting in 6 bytes total.
   *
   * @param x - The x coordinate
   * @param y - The y coordinate
   * @param z - The z coordinate
   * @returns An 8-character base64 string representing the point
   * @internal
   */ static _legacyEncodePoint(x, y, z) {
        const buffer = new Uint8Array(6);
        const dataView = new DataView(buffer.buffer);
        setFloat16(dataView, 0, x);
        setFloat16(dataView, 2, y);
        setFloat16(dataView, 4, z);
        return uint8ArrayToBase64(buffer);
    }
    /**
   * Convert an array of VecModels to a base64 string using legacy Float16 encoding.
   * Uses Float16 encoding for each coordinate (x, y, z). If a point's z value is
   * undefined, it defaults to 0.5.
   *
   * @param points - An array of VecModel objects to encode
   * @returns A base64-encoded string containing all points
   * @internal Used only for migrations from legacy format
   */ static _legacyEncodePoints(points) {
        if (points.length === 0) return "";
        const buffer = new Uint8Array(points.length * 6);
        const dataView = new DataView(buffer.buffer);
        for(let i = 0; i < points.length; i++){
            const p = points[i];
            const offset = i * 6;
            setFloat16(dataView, offset, p.x);
            setFloat16(dataView, offset + 2, p.y);
            setFloat16(dataView, offset + 4, p.z ?? 0.5);
        }
        return uint8ArrayToBase64(buffer);
    }
    /**
   * Convert a legacy base64 string back to an array of VecModels.
   * Decodes Float16-encoded coordinates (x, y, z) from the base64 string.
   *
   * @param base64 - The base64-encoded string containing point data
   * @returns An array of VecModel objects decoded from the string
   * @internal Used only for migrations from legacy format
   */ static _legacyDecodePoints(base64) {
        const bytes = base64ToUint8Array(base64);
        const dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const result = [];
        for(let offset = 0; offset < bytes.length; offset += 6){
            result.push({
                x: getFloat16(dataView, offset),
                y: getFloat16(dataView, offset + 2),
                z: getFloat16(dataView, offset + 4)
            });
        }
        return result;
    }
    /**
   * Encode an array of VecModels using delta encoding for improved precision.
   * The first point is stored as Float32 (high precision for absolute position),
   * subsequent points are stored as Float16 deltas from the previous point.
   * This provides full precision for the starting position and excellent precision
   * for deltas between consecutive points (which are typically small values).
   *
   * Format:
   * - First point: 3 Float32 values = 12 bytes = 16 base64 chars
   * - Delta points: 3 Float16 values each = 6 bytes = 8 base64 chars each
   *
   * @param points - An array of VecModel objects to encode
   * @returns A base64-encoded string containing delta-encoded points
   * @public
   */ static encodePoints(points) {
        if (points.length === 0) return "";
        const firstPointBytes = 12;
        const deltaBytes = (points.length - 1) * 6;
        const totalBytes = firstPointBytes + deltaBytes;
        const buffer = new Uint8Array(totalBytes);
        const dataView = new DataView(buffer.buffer);
        const first = points[0];
        dataView.setFloat32(0, first.x, true);
        dataView.setFloat32(4, first.y, true);
        dataView.setFloat32(8, first.z ?? 0.5, true);
        let prevX = first.x;
        let prevY = first.y;
        let prevZ = first.z ?? 0.5;
        for(let i = 1; i < points.length; i++){
            const p = points[i];
            const z = p.z ?? 0.5;
            const offset = firstPointBytes + (i - 1) * 6;
            setFloat16(dataView, offset, p.x - prevX);
            setFloat16(dataView, offset + 2, p.y - prevY);
            setFloat16(dataView, offset + 4, z - prevZ);
            prevX = p.x;
            prevY = p.y;
            prevZ = z;
        }
        return uint8ArrayToBase64(buffer);
    }
    /**
   * Decode a delta-encoded base64 string back to an array of absolute VecModels.
   * The first point is stored as Float32 (high precision), subsequent points are
   * Float16 deltas that are accumulated to reconstruct absolute positions.
   *
   * @param base64 - The base64-encoded string containing delta-encoded point data
   * @returns An array of VecModel objects with absolute coordinates
   * @public
   */ static decodePoints(base64) {
        if (base64.length === 0) return [];
        const bytes = base64ToUint8Array(base64);
        const dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const result = [];
        let x = dataView.getFloat32(0, true);
        let y = dataView.getFloat32(4, true);
        let z = dataView.getFloat32(8, true);
        result.push({
            x,
            y,
            z
        });
        const firstPointBytes = 12;
        for(let offset = firstPointBytes; offset < bytes.length; offset += 6){
            x += getFloat16(dataView, offset);
            y += getFloat16(dataView, offset + 2);
            z += getFloat16(dataView, offset + 4);
            result.push({
                x,
                y,
                z
            });
        }
        return result;
    }
    /**
   * Get the first point from a delta-encoded base64 string.
   * The first point is stored as Float32 for full precision.
   *
   * @param b64Points - The delta-encoded base64 string
   * @returns The first point as a VecModel, or null if the string is too short
   * @public
   */ static decodeFirstPoint(b64Points) {
        if (b64Points.length < FIRST_POINT_B64_LENGTH) return null;
        const bytes = base64ToUint8Array(b64Points.slice(0, FIRST_POINT_B64_LENGTH));
        const dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return {
            x: dataView.getFloat32(0, true),
            y: dataView.getFloat32(4, true),
            z: dataView.getFloat32(8, true)
        };
    }
    /**
   * Get the last point from a delta-encoded base64 string.
   * Requires decoding all points to accumulate deltas.
   *
   * @param b64Points - The delta-encoded base64 string
   * @returns The last point as a VecModel, or null if the string is too short
   * @public
   */ static decodeLastPoint(b64Points) {
        if (b64Points.length < FIRST_POINT_B64_LENGTH) return null;
        const bytes = base64ToUint8Array(b64Points);
        const dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        let x = dataView.getFloat32(0, true);
        let y = dataView.getFloat32(4, true);
        let z = dataView.getFloat32(8, true);
        const firstPointBytes = 12;
        for(let offset = firstPointBytes; offset < bytes.length; offset += 6){
            x += getFloat16(dataView, offset);
            y += getFloat16(dataView, offset + 2);
            z += getFloat16(dataView, offset + 4);
        }
        return {
            x,
            y,
            z
        };
    }
}
;
 //# sourceMappingURL=b64Vecs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLDrawShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DrawShapeSegment",
    ()=>DrawShapeSegment,
    "compressLegacySegments",
    ()=>compressLegacySegments,
    "drawShapeMigrations",
    ()=>drawShapeMigrations,
    "drawShapeProps",
    ()=>drawShapeProps,
    "drawShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/b64Vecs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const DrawShapeSegment = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("free", "straight"),
    path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string
});
const drawShapeProps = {
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    fill: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"],
    dash: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    segments: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(DrawShapeSegment),
    isComplete: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    isClosed: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    isPen: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    scaleX: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroFiniteNumber,
    scaleY: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroFiniteNumber
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("draw", {
    AddInPen: 1,
    AddScale: 2,
    Base64: 3,
    LegacyPointsConversion: 4
});
const drawShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddInPen,
            up: (props)=>{
                const { points } = props.segments[0];
                if (points.length === 0) {
                    props.isPen = false;
                    return;
                }
                let isPen = !(points[0].z === 0 || points[0].z === 0.5);
                if (points[1]) {
                    isPen = isPen && !(points[1].z === 0 || points[1].z === 0.5);
                }
                props.isPen = isPen;
            },
            down: "retired"
        },
        {
            id: Versions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        },
        {
            id: Versions.Base64,
            up: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    if (segment.path !== void 0) return segment;
                    const { points, ...rest } = segment;
                    const vecModels = Array.isArray(points) ? points : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"]._legacyDecodePoints(points);
                    return {
                        ...rest,
                        path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(vecModels)
                    };
                });
                props.scaleX = props.scaleX ?? 1;
                props.scaleY = props.scaleY ?? 1;
            },
            down: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    const { path, ...rest } = segment;
                    return {
                        ...rest,
                        points: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].decodePoints(path)
                    };
                });
                delete props.scaleX;
                delete props.scaleY;
            }
        },
        {
            id: Versions.LegacyPointsConversion,
            up: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    if (segment.path !== void 0) return segment;
                    const { points, ...rest } = segment;
                    const vecModels = Array.isArray(points) ? points : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"]._legacyDecodePoints(points);
                    return {
                        ...rest,
                        path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(vecModels)
                    };
                });
            },
            down: (_props)=>{}
        }
    ]
});
function compressLegacySegments(segments) {
    return segments.map((segment)=>({
            type: segment.type,
            path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(segment.points)
        }));
}
;
 //# sourceMappingURL=TLDrawShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLEmbedShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "embedShapeMigrations",
    ()=>embedShapeMigrations,
    "embedShapeProps",
    ()=>embedShapeProps,
    "embedShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/url.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
;
;
const TLDRAW_APP_RE = /(^\/r\/[^/]+\/?$)/;
const EMBED_DEFINITIONS = [
    {
        hostnames: [
            "beta.tldraw.com",
            "tldraw.com",
            "localhost:3000"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(TLDRAW_APP_RE)) {
                return url;
            }
            return;
        }
    },
    {
        hostnames: [
            "figma.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/?$/)) {
                const outUrl = urlObj.searchParams.get("url");
                if (outUrl) {
                    return outUrl;
                }
            }
            return;
        }
    },
    {
        hostnames: [
            "google.*"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (!urlObj) return;
            const matches = urlObj.pathname.match(/^\/maps\/embed\/v1\/view\/?$/);
            if (matches && urlObj.searchParams.has("center") && urlObj.searchParams.get("zoom")) {
                const zoom = urlObj.searchParams.get("zoom");
                const [lat, lon] = urlObj.searchParams.get("center").split(",");
                return `https://www.google.com/maps/@${lat},${lon},${zoom}z`;
            }
            return;
        }
    },
    {
        hostnames: [
            "val.town"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/embed\/(.+)\/?/);
            if (matches) {
                return `https://www.val.town/v/${matches[1]}`;
            }
            return;
        }
    },
    {
        hostnames: [
            "codesandbox.io"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/embed\/([^/]+)\/?/);
            if (matches) {
                return `https://codesandbox.io/s/${matches[1]}`;
            }
            return;
        }
    },
    {
        hostnames: [
            "codepen.io"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const CODEPEN_EMBED_REGEXP = /https:\/\/codepen.io\/([^/]+)\/embed\/([^/]+)/;
            const matches = url.match(CODEPEN_EMBED_REGEXP);
            if (matches) {
                const [_, user, id] = matches;
                return `https://codepen.io/${user}/pen/${id}`;
            }
            return;
        }
    },
    {
        hostnames: [
            "scratch.mit.edu"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const SCRATCH_EMBED_REGEXP = /https:\/\/scratch.mit.edu\/projects\/embed\/([^/]+)/;
            const matches = url.match(SCRATCH_EMBED_REGEXP);
            if (matches) {
                const [_, id] = matches;
                return `https://scratch.mit.edu/projects/${id}`;
            }
            return;
        }
    },
    {
        hostnames: [
            "*.youtube.com",
            "youtube.com",
            "youtu.be"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (!urlObj) return;
            const hostname = urlObj.hostname.replace(/^www./, "");
            if (hostname === "youtube.com") {
                const matches = urlObj.pathname.match(/^\/embed\/([^/]+)\/?/);
                if (matches) {
                    return `https://www.youtube.com/watch?v=${matches[1]}`;
                }
            }
            return;
        }
    },
    {
        hostnames: [
            "calendar.google.*"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const srcQs = urlObj?.searchParams.get("src");
            if (urlObj?.pathname.match(/\/calendar\/embed/) && srcQs) {
                urlObj.pathname = "/calendar/u/0";
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                urlObj.searchParams.set("cid", srcQs);
                return urlObj.href;
            }
            return;
        }
    },
    {
        hostnames: [
            "docs.google.*"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj?.pathname.match(/^\/presentation/) && urlObj?.pathname.match(/\/embed\/?$/)) {
                urlObj.pathname = urlObj.pathname.replace(/\/embed$/, "/pub");
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                return urlObj.href;
            }
            return;
        }
    },
    {
        hostnames: [
            "gist.github.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/([^/]+)\/([^/]+)/)) {
                if (!url.split("/").pop()) return;
                return url;
            }
            return;
        }
    },
    {
        hostnames: [
            "replit.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/@([^/]+)\/([^/]+)/) && urlObj.searchParams.has("embed")) {
                urlObj.searchParams.delete("embed");
                return urlObj.href;
            }
            return;
        }
    },
    {
        hostnames: [
            "felt.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/map\//)) {
                urlObj.pathname = urlObj.pathname.replace(/^\/embed/, "");
                return urlObj.href;
            }
            return;
        }
    },
    {
        hostnames: [
            "open.spotify.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/(artist|album)\//)) {
                return urlObj.origin + urlObj.pathname.replace(/^\/embed/, "");
            }
            return;
        }
    },
    {
        hostnames: [
            "vimeo.com",
            "player.vimeo.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "player.vimeo.com") {
                const matches = urlObj.pathname.match(/^\/video\/([^/]+)\/?$/);
                if (matches) {
                    return "https://vimeo.com/" + matches[1];
                }
            }
            return;
        }
    },
    {
        hostnames: [
            "observablehq.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/@([^/]+)\/([^/]+)\/?$/)) {
                return `${urlObj.origin}${urlObj.pathname.replace("/embed", "")}#cell-*`;
            }
            if (urlObj && urlObj.pathname.match(/^\/embed\/([^/]+)\/?$/)) {
                return `${urlObj.origin}${urlObj.pathname.replace("/embed", "/d")}#cell-*`;
            }
            return;
        }
    },
    {
        hostnames: [
            "desmos.com"
        ],
        canEditWhileLocked: true,
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "www.desmos.com" && urlObj.pathname.match(/^\/calculator\/([^/]+)\/?$/) && urlObj.search === "?embed" && urlObj.hash === "") {
                return url.replace("?embed", "");
            }
            return;
        }
    }
];
const embedShapeProps = {
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("embed", {
    GenOriginalUrlInEmbed: 1,
    RemoveDoesResize: 2,
    RemoveTmpOldUrl: 3,
    RemovePermissionOverrides: 4
});
const embedShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.GenOriginalUrlInEmbed,
            // add tmpOldUrl property
            up: (props)=>{
                try {
                    const url = props.url;
                    const host = new URL(url).host.replace("www.", "");
                    let originalUrl;
                    for (const localEmbedDef of EMBED_DEFINITIONS){
                        if (localEmbedDef.hostnames.includes(host)) {
                            try {
                                originalUrl = localEmbedDef.fromEmbedUrl(url);
                            } catch (err) {
                                console.warn(err);
                            }
                        }
                    }
                    props.tmpOldUrl = props.url;
                    props.url = originalUrl ?? "";
                } catch  {
                    props.url = "";
                    props.tmpOldUrl = props.url;
                }
            },
            down: "retired"
        },
        {
            id: Versions.RemoveDoesResize,
            up: (props)=>{
                delete props.doesResize;
            },
            down: "retired"
        },
        {
            id: Versions.RemoveTmpOldUrl,
            up: (props)=>{
                delete props.tmpOldUrl;
            },
            down: "retired"
        },
        {
            id: Versions.RemovePermissionOverrides,
            up: (props)=>{
                delete props.overridePermissions;
            },
            down: "retired"
        }
    ]
});
;
 //# sourceMappingURL=TLEmbedShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLFrameShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "frameShapeMigrations",
    ()=>frameShapeMigrations,
    "frameShapeProps",
    ()=>frameShapeProps,
    "frameShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
;
;
;
const frameShapeProps = {
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    // because shape colors are an option, we don't want them to be picked up by the editor as a
    // style prop by default, so instead of a proper style we just supply an equivalent validator.
    // Check `FrameShapeUtil.configure` for how we replace this with the original
    // `DefaultColorStyle` style when the option is turned on.
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum(...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"].values)
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("frame", {
    AddColorProp: 1
});
const frameShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddColorProp,
            up: (props)=>{
                props.color = "black";
            },
            down: (props)=>{
                delete props.color;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLFrameShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLHorizontalAlignStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultHorizontalAlignStyle",
    ()=>DefaultHorizontalAlignStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultHorizontalAlignStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:horizontalAlign", {
    defaultValue: "middle",
    values: [
        "start",
        "middle",
        "end",
        "start-legacy",
        "end-legacy",
        "middle-legacy"
    ]
});
;
 //# sourceMappingURL=TLHorizontalAlignStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLVerticalAlignStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultVerticalAlignStyle",
    ()=>DefaultVerticalAlignStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultVerticalAlignStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:verticalAlign", {
    defaultValue: "middle",
    values: [
        "start",
        "middle",
        "end"
    ]
});
;
 //# sourceMappingURL=TLVerticalAlignStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGeoShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GeoShapeGeoStyle",
    ()=>GeoShapeGeoStyle,
    "geoShapeMigrations",
    ()=>geoShapeMigrations,
    "geoShapeProps",
    ()=>geoShapeProps,
    "geoShapeVersions",
    ()=>geoShapeVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLHorizontalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLVerticalAlignStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const GeoShapeGeoStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:geo", {
    defaultValue: "rectangle",
    values: [
        "cloud",
        "rectangle",
        "ellipse",
        "triangle",
        "diamond",
        "pentagon",
        "hexagon",
        "octagon",
        "star",
        "rhombus",
        "rhombus-2",
        "oval",
        "trapezoid",
        "arrow-right",
        "arrow-left",
        "arrow-up",
        "arrow-down",
        "x-box",
        "check-box",
        "heart"
    ]
});
const geoShapeProps = {
    geo: GeoShapeGeoStyle,
    dash: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl,
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    growY: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].positiveNumber,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    // Text properties
    labelColor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultLabelColorStyle"],
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    fill: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    font: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontStyle"],
    align: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultHorizontalAlignStyle"],
    verticalAlign: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultVerticalAlignStyle"],
    richText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"]
};
const geoShapeVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("geo", {
    AddUrlProp: 1,
    AddLabelColor: 2,
    RemoveJustify: 3,
    AddCheckBox: 4,
    AddVerticalAlign: 5,
    MigrateLegacyAlign: 6,
    AddCloud: 7,
    MakeUrlsValid: 8,
    AddScale: 9,
    AddRichText: 10,
    AddRichTextAttrs: 11
});
const geoShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: geoShapeVersions.AddUrlProp,
            up: (props)=>{
                props.url = "";
            },
            down: "retired"
        },
        {
            id: geoShapeVersions.AddLabelColor,
            up: (props)=>{
                props.labelColor = "black";
            },
            down: "retired"
        },
        {
            id: geoShapeVersions.RemoveJustify,
            up: (props)=>{
                if (props.align === "justify") {
                    props.align = "start";
                }
            },
            down: "retired"
        },
        {
            id: geoShapeVersions.AddCheckBox,
            up: (_props)=>{},
            down: "retired"
        },
        {
            id: geoShapeVersions.AddVerticalAlign,
            up: (props)=>{
                props.verticalAlign = "middle";
            },
            down: "retired"
        },
        {
            id: geoShapeVersions.MigrateLegacyAlign,
            up: (props)=>{
                let newAlign;
                switch(props.align){
                    case "start":
                        newAlign = "start-legacy";
                        break;
                    case "end":
                        newAlign = "end-legacy";
                        break;
                    default:
                        newAlign = "middle-legacy";
                        break;
                }
                props.align = newAlign;
            },
            down: "retired"
        },
        {
            id: geoShapeVersions.AddCloud,
            up: (_props)=>{},
            down: "retired"
        },
        {
            id: geoShapeVersions.MakeUrlsValid,
            up: (props)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl.isValid(props.url)) {
                    props.url = "";
                }
            },
            down: (_props)=>{}
        },
        {
            id: geoShapeVersions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        },
        {
            id: geoShapeVersions.AddRichText,
            up: (props)=>{
                props.richText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(props.text);
                delete props.text;
            }
        },
        {
            id: geoShapeVersions.AddRichTextAttrs,
            up: (_props)=>{},
            down: (props)=>{
                if (props.richText && "attrs" in props.richText) {
                    delete props.richText.attrs;
                }
            }
        }
    ]
});
;
 //# sourceMappingURL=TLGeoShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGroupShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "groupShapeMigrations",
    ()=>groupShapeMigrations,
    "groupShapeProps",
    ()=>groupShapeProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
const groupShapeProps = {};
const groupShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: []
});
;
 //# sourceMappingURL=TLGroupShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLHighlightShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "highlightShapeMigrations",
    ()=>highlightShapeMigrations,
    "highlightShapeProps",
    ()=>highlightShapeProps,
    "highlightShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/b64Vecs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLDrawShape.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const highlightShapeProps = {
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    segments: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawShapeSegment"]),
    isComplete: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    isPen: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    scaleX: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroFiniteNumber,
    scaleY: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroFiniteNumber
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("highlight", {
    AddScale: 1,
    Base64: 2,
    LegacyPointsConversion: 3
});
const highlightShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        },
        {
            id: Versions.Base64,
            up: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    if (segment.path !== void 0) return segment;
                    const { points, ...rest } = segment;
                    const vecModels = Array.isArray(points) ? points : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"]._legacyDecodePoints(points);
                    return {
                        ...rest,
                        path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(vecModels)
                    };
                });
                props.scaleX = props.scaleX ?? 1;
                props.scaleY = props.scaleY ?? 1;
            },
            down: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    const { path, ...rest } = segment;
                    return {
                        ...rest,
                        points: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].decodePoints(path)
                    };
                });
                delete props.scaleX;
                delete props.scaleY;
            }
        },
        {
            id: Versions.LegacyPointsConversion,
            up: (props)=>{
                props.segments = props.segments.map((segment)=>{
                    if (segment.path !== void 0) return segment;
                    const { points, ...rest } = segment;
                    const vecModels = Array.isArray(points) ? points : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"]._legacyDecodePoints(points);
                    return {
                        ...rest,
                        path: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(vecModels)
                    };
                });
            },
            down: (_props)=>{}
        }
    ]
});
;
 //# sourceMappingURL=TLHighlightShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLImageShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImageShapeCrop",
    ()=>ImageShapeCrop,
    "imageShapeMigrations",
    ()=>imageShapeMigrations,
    "imageShapeProps",
    ()=>imageShapeProps,
    "imageShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
;
;
;
const ImageShapeCrop = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    topLeft: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    bottomRight: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    isCircle: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional()
});
const imageShapeProps = {
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    playing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl,
    assetId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetIdValidator"].nullable(),
    crop: ImageShapeCrop.nullable(),
    flipX: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    flipY: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    altText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("image", {
    AddUrlProp: 1,
    AddCropProp: 2,
    MakeUrlsValid: 3,
    AddFlipProps: 4,
    AddAltText: 5
});
const imageShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddUrlProp,
            up: (props)=>{
                props.url = "";
            },
            down: "retired"
        },
        {
            id: Versions.AddCropProp,
            up: (props)=>{
                props.crop = null;
            },
            down: (props)=>{
                delete props.crop;
            }
        },
        {
            id: Versions.MakeUrlsValid,
            up: (props)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl.isValid(props.url)) {
                    props.url = "";
                }
            },
            down: (_props)=>{}
        },
        {
            id: Versions.AddFlipProps,
            up: (props)=>{
                props.flipX = false;
                props.flipY = false;
            },
            down: (props)=>{
                delete props.flipX;
                delete props.flipY;
            }
        },
        {
            id: Versions.AddAltText,
            up: (props)=>{
                props.altText = "";
            },
            down: (props)=>{
                delete props.altText;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLImageShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLLineShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LineShapeSplineStyle",
    ()=>LineShapeSplineStyle,
    "lineShapeMigrations",
    ()=>lineShapeMigrations,
    "lineShapeProps",
    ()=>lineShapeProps,
    "lineShapeVersions",
    ()=>lineShapeVersions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const LineShapeSplineStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:spline", {
    defaultValue: "line",
    values: [
        "cubic",
        "line"
    ]
});
const lineShapePointValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    index: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].indexKey,
    x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
});
const lineShapeProps = {
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    dash: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    spline: LineShapeSplineStyle,
    points: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].dict(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string, lineShapePointValidator),
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber
};
const lineShapeVersions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("line", {
    AddSnapHandles: 1,
    RemoveExtraHandleProps: 2,
    HandlesToPoints: 3,
    PointIndexIds: 4,
    AddScale: 5
});
const lineShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: lineShapeVersions.AddSnapHandles,
            up: (props)=>{
                for (const handle of Object.values(props.handles)){
                    ;
                    handle.canSnap = true;
                }
            },
            down: "retired"
        },
        {
            id: lineShapeVersions.RemoveExtraHandleProps,
            up: (props)=>{
                props.handles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapFromEntries"])(Object.values(props.handles).map((handle)=>[
                        handle.index,
                        {
                            x: handle.x,
                            y: handle.y
                        }
                    ]));
            },
            down: (props)=>{
                const handles = Object.entries(props.handles).map(([index, handle])=>({
                        index,
                        ...handle
                    })).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
                props.handles = Object.fromEntries(handles.map((handle, i)=>{
                    const id = i === 0 ? "start" : i === handles.length - 1 ? "end" : `handle:${handle.index}`;
                    return [
                        id,
                        {
                            id,
                            type: "vertex",
                            canBind: false,
                            canSnap: true,
                            index: handle.index,
                            x: handle.x,
                            y: handle.y
                        }
                    ];
                }));
            }
        },
        {
            id: lineShapeVersions.HandlesToPoints,
            up: (props)=>{
                const sortedHandles = Object.entries(props.handles).map(([index, { x, y }])=>({
                        x,
                        y,
                        index
                    })).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
                props.points = sortedHandles.map(({ x, y })=>({
                        x,
                        y
                    }));
                delete props.handles;
            },
            down: (props)=>{
                const indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndices"])(props.points.length);
                props.handles = Object.fromEntries(props.points.map((handle, i)=>{
                    const index = indices[i];
                    return [
                        index,
                        {
                            x: handle.x,
                            y: handle.y
                        }
                    ];
                }));
                delete props.points;
            }
        },
        {
            id: lineShapeVersions.PointIndexIds,
            up: (props)=>{
                const indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndices"])(props.points.length);
                props.points = Object.fromEntries(props.points.map((point, i)=>{
                    const id = indices[i];
                    return [
                        id,
                        {
                            id,
                            index: id,
                            x: point.x,
                            y: point.y
                        }
                    ];
                }));
            },
            down: (props)=>{
                const sortedHandles = Object.values(props.points).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
                props.points = sortedHandles.map(({ x, y })=>({
                        x,
                        y
                    }));
            }
        },
        {
            id: lineShapeVersions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLLineShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLNoteShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteShapeMigrations",
    ()=>noteShapeMigrations,
    "noteShapeProps",
    ()=>noteShapeProps,
    "noteShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLHorizontalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLVerticalAlignStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const noteShapeProps = {
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    labelColor: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultLabelColorStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    font: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontStyle"],
    fontSizeAdjustment: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].positiveNumber,
    align: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultHorizontalAlignStyle"],
    verticalAlign: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultVerticalAlignStyle"],
    growY: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].positiveNumber,
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl,
    richText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"],
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("note", {
    AddUrlProp: 1,
    RemoveJustify: 2,
    MigrateLegacyAlign: 3,
    AddVerticalAlign: 4,
    MakeUrlsValid: 5,
    AddFontSizeAdjustment: 6,
    AddScale: 7,
    AddLabelColor: 8,
    AddRichText: 9,
    AddRichTextAttrs: 10
});
const noteShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddUrlProp,
            up: (props)=>{
                props.url = "";
            },
            down: "retired"
        },
        {
            id: Versions.RemoveJustify,
            up: (props)=>{
                if (props.align === "justify") {
                    props.align = "start";
                }
            },
            down: "retired"
        },
        {
            id: Versions.MigrateLegacyAlign,
            up: (props)=>{
                switch(props.align){
                    case "start":
                        props.align = "start-legacy";
                        return;
                    case "end":
                        props.align = "end-legacy";
                        return;
                    default:
                        props.align = "middle-legacy";
                        return;
                }
            },
            down: "retired"
        },
        {
            id: Versions.AddVerticalAlign,
            up: (props)=>{
                props.verticalAlign = "middle";
            },
            down: "retired"
        },
        {
            id: Versions.MakeUrlsValid,
            up: (props)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl.isValid(props.url)) {
                    props.url = "";
                }
            },
            down: (_props)=>{}
        },
        {
            id: Versions.AddFontSizeAdjustment,
            up: (props)=>{
                props.fontSizeAdjustment = 0;
            },
            down: (props)=>{
                delete props.fontSizeAdjustment;
            }
        },
        {
            id: Versions.AddScale,
            up: (props)=>{
                props.scale = 1;
            },
            down: (props)=>{
                delete props.scale;
            }
        },
        {
            id: Versions.AddLabelColor,
            up: (props)=>{
                props.labelColor = "black";
            },
            down: (props)=>{
                delete props.labelColor;
            }
        },
        {
            id: Versions.AddRichText,
            up: (props)=>{
                props.richText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(props.text);
                delete props.text;
            }
        },
        {
            id: Versions.AddRichTextAttrs,
            up: (_props)=>{},
            down: (props)=>{
                if (props.richText && "attrs" in props.richText) {
                    delete props.richText.attrs;
                }
            }
        }
    ]
});
;
 //# sourceMappingURL=TLNoteShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLTextAlignStyle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultTextAlignStyle",
    ()=>DefaultTextAlignStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
;
const DefaultTextAlignStyle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"].defineEnum("tldraw:textAlign", {
    defaultValue: "start",
    values: [
        "start",
        "middle",
        "end"
    ]
});
;
 //# sourceMappingURL=TLTextAlignStyle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLTextShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "textShapeMigrations",
    ()=>textShapeMigrations,
    "textShapeProps",
    ()=>textShapeProps,
    "textShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLTextAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLTextAlignStyle.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const textShapeProps = {
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    size: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    font: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontStyle"],
    textAlign: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLTextAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultTextAlignStyle"],
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    richText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"],
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    autoSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("text", {
    RemoveJustify: 1,
    AddTextAlign: 2,
    AddRichText: 3,
    AddRichTextAttrs: 4
});
const textShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.RemoveJustify,
            up: (props)=>{
                if (props.align === "justify") {
                    props.align = "start";
                }
            },
            down: "retired"
        },
        {
            id: Versions.AddTextAlign,
            up: (props)=>{
                props.textAlign = props.align;
                delete props.align;
            },
            down: (props)=>{
                props.align = props.textAlign;
                delete props.textAlign;
            }
        },
        {
            id: Versions.AddRichText,
            up: (props)=>{
                props.richText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(props.text);
                delete props.text;
            }
        },
        {
            id: Versions.AddRichTextAttrs,
            up: (_props)=>{},
            down: (props)=>{
                if (props.richText && "attrs" in props.richText) {
                    delete props.richText.attrs;
                }
            }
        }
    ]
});
;
 //# sourceMappingURL=TLTextShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLVideoShape.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "videoShapeMigrations",
    ()=>videoShapeMigrations,
    "videoShapeProps",
    ()=>videoShapeProps,
    "videoShapeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
;
;
const videoShapeProps = {
    w: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    h: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].nonZeroNumber,
    time: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    playing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    autoplay: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean,
    url: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl,
    assetId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetIdValidator"].nullable(),
    altText: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string
};
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"])("video", {
    AddUrlProp: 1,
    MakeUrlsValid: 2,
    AddAltText: 3,
    AddAutoplay: 4
});
const videoShapeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"])({
    sequence: [
        {
            id: Versions.AddUrlProp,
            up: (props)=>{
                props.url = "";
            },
            down: "retired"
        },
        {
            id: Versions.MakeUrlsValid,
            up: (props)=>{
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].linkUrl.isValid(props.url)) {
                    props.url = "";
                }
            },
            down: (_props)=>{}
        },
        {
            id: Versions.AddAltText,
            up: (props)=>{
                props.altText = "";
            },
            down: (props)=>{
                delete props.altText;
            }
        },
        {
            id: Versions.AddAutoplay,
            up: (props)=>{
                props.autoplay = true;
            },
            down: (props)=>{
                delete props.autoplay;
            }
        }
    ]
});
;
 //# sourceMappingURL=TLVideoShape.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/store-migrations.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "storeMigrations",
    ()=>storeMigrations,
    "storeVersions",
    ()=>Versions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
;
const Versions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"])("com.tldraw.store", {
    RemoveCodeAndIconShapeTypes: 1,
    AddInstancePresenceType: 2,
    RemoveTLUserAndPresenceAndAddPointer: 3,
    RemoveUserDocument: 4,
    FixIndexKeys: 5
});
const storeMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"])({
    sequenceId: "com.tldraw.store",
    retroactive: false,
    sequence: [
        {
            id: Versions.RemoveCodeAndIconShapeTypes,
            scope: "storage",
            up: (storage)=>{
                for (const [id, record] of storage.entries()){
                    if (record.typeName === "shape" && "type" in record && (record.type === "icon" || record.type === "code")) {
                        storage.delete(id);
                    }
                }
            }
        },
        {
            id: Versions.AddInstancePresenceType,
            scope: "storage",
            up (_storage) {}
        },
        {
            // remove user and presence records and add pointer records
            id: Versions.RemoveTLUserAndPresenceAndAddPointer,
            scope: "storage",
            up: (storage)=>{
                for (const [id, record] of storage.entries()){
                    if (record.typeName.match(/^(user|user_presence)$/)) {
                        storage.delete(id);
                    }
                }
            }
        },
        {
            // remove user document records
            id: Versions.RemoveUserDocument,
            scope: "storage",
            up: (storage)=>{
                for (const [id, record] of storage.entries()){
                    if (record.typeName.match("user_document")) {
                        storage.delete(id);
                    }
                }
            }
        },
        {
            id: Versions.FixIndexKeys,
            scope: "record",
            up: (record)=>{
                if ([
                    "shape",
                    "page"
                ].includes(record.typeName) && "index" in record) {
                    const recordWithIndex = record;
                    if (recordWithIndex.index.endsWith("0") && recordWithIndex.index !== "a0") {
                        recordWithIndex.index = recordWithIndex.index.slice(0, -1) + getNRandomBase62Digits(3);
                    }
                    if (record.typeName === "shape" && recordWithIndex.type === "line") {
                        const lineShape = recordWithIndex;
                        for (const [_, point] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(lineShape.props.points)){
                            if (point.index.endsWith("0") && point.index !== "a0") {
                                point.index = point.index.slice(0, -1) + getNRandomBase62Digits(3);
                            }
                        }
                    }
                }
            },
            down: ()=>{}
        }
    ]
});
const BASE_62_DIGITS_WITHOUT_ZERO = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
const getRandomBase62Digit = ()=>{
    return BASE_62_DIGITS_WITHOUT_ZERO.charAt(Math.floor(Math.random() * BASE_62_DIGITS_WITHOUT_ZERO.length));
};
const getNRandomBase62Digits = (n)=>{
    return Array.from({
        length: n
    }, getRandomBase62Digit).join("");
};
;
 //# sourceMappingURL=store-migrations.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createTLSchema.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTLSchema",
    ()=>createTLSchema,
    "defaultBindingSchemas",
    ()=>defaultBindingSchemas,
    "defaultShapeSchemas",
    ()=>defaultShapeSchemas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$TLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/TLStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBookmarkAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBookmarkAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLImageAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLImageAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLVideoAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLVideoAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLArrowBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPresence.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$recordsWithProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/recordsWithProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLArrowShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBookmarkShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLDrawShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLEmbedShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLFrameShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGeoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGroupShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLHighlightShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLImageShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLLineShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLNoteShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLTextShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLVideoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$store$2d$migrations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/store-migrations.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const defaultShapeSchemas = {
    arrow: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeProps"]
    },
    bookmark: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkShapeProps"]
    },
    draw: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["drawShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["drawShapeProps"]
    },
    embed: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embedShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embedShapeProps"]
    },
    frame: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frameShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frameShapeProps"]
    },
    geo: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geoShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geoShapeProps"]
    },
    group: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeProps"]
    },
    highlight: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["highlightShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["highlightShapeProps"]
    },
    image: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageShapeProps"]
    },
    line: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lineShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lineShapeProps"]
    },
    note: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noteShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noteShapeProps"]
    },
    text: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textShapeProps"]
    },
    video: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoShapeMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoShapeProps"]
    }
};
const defaultBindingSchemas = {
    arrow: {
        migrations: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingMigrations"],
        props: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingProps"]
    }
};
function createTLSchema({ shapes = defaultShapeSchemas, bindings = defaultBindingSchemas, migrations } = {}) {
    const stylesById = /* @__PURE__ */ new Map();
    for (const shape of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(shapes)){
        for (const style of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShapePropKeysByStyle"])(shape.props ?? {}).keys()){
            if (stylesById.has(style.id) && stylesById.get(style.id) !== style) {
                throw new Error(`Multiple StyleProp instances with the same id: ${style.id}`);
            }
            stylesById.set(style.id, style);
        }
    }
    const ShapeRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeRecordType"])(shapes);
    const BindingRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingRecordType"])(bindings);
    const InstanceRecordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createInstanceRecordType"])(stylesById);
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreSchema"].create({
        asset: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"],
        binding: BindingRecordType,
        camera: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"],
        document: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentRecordType"],
        instance: InstanceRecordType,
        instance_page_state: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"],
        page: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"],
        instance_presence: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePresenceRecordType"],
        pointer: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerRecordType"],
        shape: ShapeRecordType
    }, {
        migrations: [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$store$2d$migrations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cameraMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["documentMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["instanceMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["instancePageStateMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["instancePresenceMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointerMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootShapeMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBookmarkAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkAssetMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLImageAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageAssetMigrations"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLVideoAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoAssetMigrations"],
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$recordsWithProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["processPropsMigrations"])("shape", shapes),
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$recordsWithProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["processPropsMigrations"])("binding", bindings),
            ...migrations ?? []
        ],
        onValidationFailure: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$TLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onValidationFailure"],
        createIntegrityChecker: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$TLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIntegrityChecker"]
    });
}
;
 //# sourceMappingURL=createTLSchema.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TL_HANDLE_TYPES",
    ()=>TL_HANDLE_TYPES
]);
const TL_HANDLE_TYPES = /* @__PURE__ */ new Set([
    "vertex",
    "virtual",
    "create",
    "clone"
]);
;
 //# sourceMappingURL=TLHandle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/languages.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LANGUAGES",
    ()=>LANGUAGES
]);
const LANGUAGES = [
    {
        locale: "id",
        label: "Bahasa Indonesia"
    },
    {
        locale: "ms",
        label: "Bahasa Melayu"
    },
    {
        locale: "ca",
        label: "Catal\xE0"
    },
    {
        locale: "cs",
        label: "\u010Ce\u0161tina"
    },
    {
        locale: "da",
        label: "Danish"
    },
    {
        locale: "de",
        label: "Deutsch"
    },
    {
        locale: "en",
        label: "English"
    },
    {
        locale: "es",
        label: "Espa\xF1ol"
    },
    {
        locale: "tl",
        label: "Filipino"
    },
    {
        locale: "fr",
        label: "Fran\xE7ais"
    },
    {
        locale: "gl",
        label: "Galego"
    },
    {
        locale: "hr",
        label: "Hrvatski"
    },
    {
        locale: "it",
        label: "Italiano"
    },
    {
        locale: "hu",
        label: "Magyar"
    },
    {
        locale: "nl",
        label: "Nederlands"
    },
    {
        locale: "no",
        label: "Norwegian"
    },
    {
        locale: "pl",
        label: "Polski"
    },
    {
        locale: "pt-br",
        label: "Portugu\xEAs - Brasil"
    },
    {
        locale: "pt-pt",
        label: "Portugu\xEAs - Europeu"
    },
    {
        locale: "ro",
        label: "Rom\xE2n\u0103"
    },
    {
        locale: "sl",
        label: "Sloven\u0161\u010Dina"
    },
    {
        locale: "so",
        label: "Somali"
    },
    {
        locale: "fi",
        label: "Suomi"
    },
    {
        locale: "sv",
        label: "Svenska"
    },
    {
        locale: "vi",
        label: "Ti\u1EBFng Vi\u1EC7t"
    },
    {
        locale: "tr",
        label: "T\xFCrk\xE7e"
    },
    {
        locale: "el",
        label: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC"
    },
    {
        locale: "ru",
        label: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439"
    },
    {
        locale: "uk",
        label: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"
    },
    {
        locale: "he",
        label: "\u05E2\u05D1\u05E8\u05D9\u05EA"
    },
    {
        locale: "ur",
        label: "\u0627\u0631\u062F\u0648"
    },
    {
        locale: "ar",
        label: "\u0639\u0631\u0628\u064A"
    },
    {
        locale: "fa",
        label: "\u0641\u0627\u0631\u0633\u06CC"
    },
    {
        locale: "ne",
        label: "\u0928\u0947\u092A\u093E\u0932\u0940"
    },
    {
        locale: "mr",
        label: "\u092E\u0930\u093E\u0920\u0940"
    },
    {
        locale: "hi-in",
        label: "\u0939\u093F\u0928\u094D\u0926\u0940"
    },
    {
        locale: "bn",
        label: "\u09AC\u09BE\u0982\u09B2\u09BE"
    },
    {
        locale: "pa",
        label: "\u0A2A\u0A70\u0A1C\u0A3E\u0A2C\u0A40"
    },
    {
        locale: "gu-in",
        label: "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0"
    },
    {
        locale: "ta",
        label: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD"
    },
    {
        locale: "te",
        label: "\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41"
    },
    {
        locale: "kn",
        label: "\u0C95\u0CA8\u0CCD\u0CA8\u0CA1"
    },
    {
        locale: "ml",
        label: "\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02"
    },
    {
        locale: "th",
        label: "\u0E20\u0E32\u0E29\u0E32\u0E44\u0E17\u0E22"
    },
    {
        locale: "km-kh",
        label: "\u1797\u17B6\u179F\u17B6\u1781\u17D2\u1798\u17C2\u179A"
    },
    {
        locale: "ko-kr",
        label: "\uD55C\uAD6D\uC5B4"
    },
    {
        locale: "ja",
        label: "\u65E5\u672C\u8A9E"
    },
    {
        locale: "zh-cn",
        label: "\u7B80\u4F53\u4E2D\u6587"
    },
    {
        locale: "zh-tw",
        label: "\u7E41\u9AD4\u4E2D\u6587 (\u53F0\u7063)"
    }
];
;
 //# sourceMappingURL=languages.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/translations.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_getDefaultTranslationLocale",
    ()=>_getDefaultTranslationLocale,
    "getDefaultTranslationLocale",
    ()=>getDefaultTranslationLocale
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/languages.mjs [app-client] (ecmascript)");
;
function getDefaultTranslationLocale() {
    const locales = typeof window !== "undefined" && window.navigator ? window.navigator.languages ?? [
        "en"
    ] : [
        "en"
    ];
    return _getDefaultTranslationLocale(locales);
}
function _getDefaultTranslationLocale(locales) {
    for (const locale of locales){
        const supportedLocale = getSupportedLocale(locale);
        if (supportedLocale) {
            return supportedLocale;
        }
    }
    return "en";
}
const DEFAULT_LOCALE_REGIONS = {
    zh: "zh-cn",
    pt: "pt-br",
    ko: "ko-kr",
    hi: "hi-in"
};
function getSupportedLocale(locale) {
    const exactMatch = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LANGUAGES"].find((t)=>t.locale === locale.toLowerCase());
    if (exactMatch) {
        return exactMatch.locale;
    }
    const [language, region] = locale.split(/[-_]/).map((s)=>s.toLowerCase());
    if (region) {
        const languageMatch = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LANGUAGES"].find((t)=>t.locale === language);
        if (languageMatch) {
            return languageMatch.locale;
        }
    }
    if (language in DEFAULT_LOCALE_REGIONS) {
        return DEFAULT_LOCALE_REGIONS[language];
    }
    return null;
}
;
 //# sourceMappingURL=translations.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLArrowBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLBaseBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createPresenceStateDerivation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createPresenceStateDerivation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createTLSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLColor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLOpacity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLScribble.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPresence.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLArrowShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBookmarkShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLDrawShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLEmbedShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLFrameShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGeoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGroupShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLHighlightShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLImageShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLLineShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLNoteShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLTextShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLVideoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLHorizontalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLTextAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLTextAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLVerticalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/translations.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/languages.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/b64Vecs.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerTldrawLibraryVersion"])("@tldraw/tlschema", "4.4.0", "esm");
;
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowShapeArrowheadEndStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowShapeArrowheadEndStyle"],
    "ArrowShapeArrowheadStartStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowShapeArrowheadStartStyle"],
    "ArrowShapeKindStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowShapeKindStyle"],
    "AssetRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"],
    "CameraRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"],
    "DefaultColorStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    "DefaultColorThemePalette",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorThemePalette"],
    "DefaultDashStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    "DefaultFillStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"],
    "DefaultFontFamilies",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontFamilies"],
    "DefaultFontStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontStyle"],
    "DefaultHorizontalAlignStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultHorizontalAlignStyle"],
    "DefaultLabelColorStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultLabelColorStyle"],
    "DefaultSizeStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"],
    "DefaultTextAlignStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLTextAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultTextAlignStyle"],
    "DefaultVerticalAlignStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultVerticalAlignStyle"],
    "DocumentRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentRecordType"],
    "ElbowArrowSnap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElbowArrowSnap"],
    "EnumStyleProp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EnumStyleProp"],
    "GeoShapeGeoStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeoShapeGeoStyle"],
    "ImageShapeCrop",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageShapeCrop"],
    "InstancePageStateRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"],
    "InstancePresenceRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePresenceRecordType"],
    "LANGUAGES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LANGUAGES"],
    "LineShapeSplineStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineShapeSplineStyle"],
    "PageRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"],
    "PointerRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerRecordType"],
    "StyleProp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleProp"],
    "TLDOCUMENT_ID",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLDOCUMENT_ID"],
    "TLINSTANCE_ID",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"],
    "TLPOINTER_ID",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"],
    "TL_CANVAS_UI_COLOR_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TL_CANVAS_UI_COLOR_TYPES"],
    "TL_CURSOR_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TL_CURSOR_TYPES"],
    "TL_HANDLE_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TL_HANDLE_TYPES"],
    "TL_SCRIBBLE_STATES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TL_SCRIBBLE_STATES"],
    "arrowBindingMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingMigrations"],
    "arrowBindingProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingProps"],
    "arrowBindingVersions",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingVersions"],
    "arrowShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeMigrations"],
    "arrowShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeProps"],
    "arrowShapeVersions",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowShapeVersions"],
    "assetIdValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetIdValidator"],
    "assetMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetMigrations"],
    "assetValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetValidator"],
    "b64Vecs",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"],
    "bindingIdValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bindingIdValidator"],
    "bookmarkShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkShapeMigrations"],
    "bookmarkShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bookmarkShapeProps"],
    "boxModelValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boxModelValidator"],
    "canvasUiColorTypeValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canvasUiColorTypeValidator"],
    "compressLegacySegments",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compressLegacySegments"],
    "createAssetValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAssetValidator"],
    "createBindingId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"],
    "createBindingPropsMigrationIds",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingPropsMigrationIds"],
    "createBindingPropsMigrationSequence",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingPropsMigrationSequence"],
    "createBindingValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingValidator"],
    "createPresenceStateDerivation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createPresenceStateDerivation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPresenceStateDerivation"],
    "createShapeId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"],
    "createShapePropsMigrationIds",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationIds"],
    "createShapePropsMigrationSequence",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapePropsMigrationSequence"],
    "createShapeValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeValidator"],
    "createTLSchema",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTLSchema"],
    "defaultBindingSchemas",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultBindingSchemas"],
    "defaultColorNames",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultColorNames"],
    "defaultShapeSchemas",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultShapeSchemas"],
    "drawShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["drawShapeMigrations"],
    "drawShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["drawShapeProps"],
    "embedShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embedShapeMigrations"],
    "embedShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embedShapeProps"],
    "frameShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frameShapeMigrations"],
    "frameShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frameShapeProps"],
    "geoShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geoShapeMigrations"],
    "geoShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geoShapeProps"],
    "getColorValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getColorValue"],
    "getDefaultColorTheme",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultColorTheme"],
    "getDefaultTranslationLocale",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getDefaultTranslationLocale"],
    "getDefaultUserPresence",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createPresenceStateDerivation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultUserPresence"],
    "getShapePropKeysByStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShapePropKeysByStyle"],
    "groupShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeMigrations"],
    "groupShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeProps"],
    "highlightShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["highlightShapeMigrations"],
    "highlightShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["highlightShapeProps"],
    "idValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["idValidator"],
    "imageShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageShapeMigrations"],
    "imageShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageShapeProps"],
    "isBinding",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBinding"],
    "isBindingId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBindingId"],
    "isDocument",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDocument"],
    "isPageId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"],
    "isShape",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"],
    "isShapeId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"],
    "lineShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lineShapeMigrations"],
    "lineShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lineShapeProps"],
    "noteShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noteShapeMigrations"],
    "noteShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noteShapeProps"],
    "opacityValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opacityValidator"],
    "pageIdValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageIdValidator"],
    "parentIdValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parentIdValidator"],
    "pluckPreservingValues",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pluckPreservingValues"],
    "richTextValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["richTextValidator"],
    "rootBindingMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootBindingMigrations"],
    "rootShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootShapeMigrations"],
    "scribbleValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scribbleValidator"],
    "shapeIdValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"],
    "textShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textShapeMigrations"],
    "textShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textShapeProps"],
    "toRichText",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"],
    "vecModelValidator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vecModelValidator"],
    "videoShapeMigrations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoShapeMigrations"],
    "videoShapeProps",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videoShapeProps"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$assets$2f$TLBaseAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/assets/TLBaseAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLArrowBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLArrowBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$bindings$2f$TLBaseBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/bindings/TLBaseBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createPresenceStateDerivation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createPresenceStateDerivation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createTLSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$geometry$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/geometry-types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$id$2d$validator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/id-validator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLColor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLColor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLOpacity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLOpacity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLRichText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLRichText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$TLScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/TLScribble.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLAsset$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLAsset.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPresence$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPresence.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLArrowShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLArrowShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBookmarkShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBookmarkShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLDrawShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLDrawShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLEmbedShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLEmbedShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLFrameShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLFrameShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGeoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGeoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGroupShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLHighlightShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLHighlightShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLImageShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLImageShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLLineShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLLineShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLNoteShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLNoteShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLTextShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLTextShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLVideoShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLVideoShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$StyleProp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/StyleProp.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLDashStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLDashStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFillStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFillStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLFontStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLFontStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLHorizontalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLHorizontalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLSizeStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLSizeStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLTextAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLTextAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLVerticalAlignStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLVerticalAlignStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/translations.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$languages$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/languages.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$misc$2f$b64Vecs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/misc/b64Vecs.mjs [app-client] (ecmascript)");
}),
]);

//# debugId=14400441-72a5-aeeb-6327-9e06b5aa8de9
//# sourceMappingURL=c427b_%40tldraw_tlschema_dist-esm_40108547._.js.map