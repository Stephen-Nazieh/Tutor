;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="ae077a18-a269-f53e-e469-423950358f24")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EASINGS",
    ()=>EASINGS
]);
const EASINGS = {
    linear: (t)=>t,
    easeInQuad: (t)=>t * t,
    easeOutQuad: (t)=>t * (2 - t),
    easeInOutQuad: (t)=>t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
    easeInCubic: (t)=>t * t * t,
    easeOutCubic: (t)=>--t * t * t + 1,
    easeInOutCubic: (t)=>t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
    easeInQuart: (t)=>t * t * t * t,
    easeOutQuart: (t)=>1 - --t * t * t * t,
    easeInOutQuart: (t)=>t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t,
    easeInQuint: (t)=>t * t * t * t * t,
    easeOutQuint: (t)=>1 + --t * t * t * t * t,
    easeInOutQuint: (t)=>t < 0.5 ? 16 * t * t * t * t * t : 1 + 16 * --t * t * t * t * t,
    easeInSine: (t)=>1 - Math.cos(t * Math.PI / 2),
    easeOutSine: (t)=>Math.sin(t * Math.PI / 2),
    easeInOutSine: (t)=>-(Math.cos(Math.PI * t) - 1) / 2,
    easeInExpo: (t)=>t <= 0 ? 0 : Math.pow(2, 10 * t - 10),
    easeOutExpo: (t)=>t >= 1 ? 1 : 1 - Math.pow(2, -10 * t),
    easeInOutExpo: (t)=>t <= 0 ? 0 : t >= 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2
};
;
 //# sourceMappingURL=easings.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Vec",
    ()=>Vec
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
;
;
class Vec {
    constructor(x = 0, y = 0, z = 1){
        this.x = x;
        this.y = y;
        this.z = z;
    }
    // eslint-disable-next-line no-restricted-syntax
    get pressure() {
        return this.z;
    }
    set(x = this.x, y = this.y, z = this.z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }
    setTo({ x = 0, y = 0, z = 1 }) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }
    rot(r) {
        if (r === 0) return this;
        const { x, y } = this;
        const s = Math.sin(r);
        const c = Math.cos(r);
        this.x = x * c - y * s;
        this.y = x * s + y * c;
        return this;
    }
    rotWith(C, r) {
        if (r === 0) return this;
        const x = this.x - C.x;
        const y = this.y - C.y;
        const s = Math.sin(r);
        const c = Math.cos(r);
        this.x = C.x + (x * c - y * s);
        this.y = C.y + (x * s + y * c);
        return this;
    }
    clone() {
        const { x, y, z } = this;
        return new Vec(x, y, z);
    }
    sub(V) {
        this.x -= V.x;
        this.y -= V.y;
        return this;
    }
    subXY(x, y) {
        this.x -= x;
        this.y -= y;
        return this;
    }
    subScalar(n) {
        this.x -= n;
        this.y -= n;
        return this;
    }
    add(V) {
        this.x += V.x;
        this.y += V.y;
        return this;
    }
    addXY(x, y) {
        this.x += x;
        this.y += y;
        return this;
    }
    addScalar(n) {
        this.x += n;
        this.y += n;
        return this;
    }
    clamp(min, max) {
        this.x = Math.max(this.x, min);
        this.y = Math.max(this.y, min);
        if (max !== void 0) {
            this.x = Math.min(this.x, max);
            this.y = Math.min(this.y, max);
        }
        return this;
    }
    div(t) {
        this.x /= t;
        this.y /= t;
        return this;
    }
    divV(V) {
        this.x /= V.x;
        this.y /= V.y;
        return this;
    }
    mul(t) {
        this.x *= t;
        this.y *= t;
        return this;
    }
    mulV(V) {
        this.x *= V.x;
        this.y *= V.y;
        return this;
    }
    abs() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
        return this;
    }
    nudge(B, distance) {
        const tan = Vec.Tan(B, this);
        return this.add(tan.mul(distance));
    }
    neg() {
        this.x *= -1;
        this.y *= -1;
        return this;
    }
    cross(V) {
        this.x = this.y * V.z - this.z * V.y;
        this.y = this.z * V.x - this.x * V.z;
        return this;
    }
    dpr(V) {
        return Vec.Dpr(this, V);
    }
    cpr(V) {
        return Vec.Cpr(this, V);
    }
    len2() {
        return Vec.Len2(this);
    }
    len() {
        return Vec.Len(this);
    }
    pry(V) {
        return Vec.Pry(this, V);
    }
    per() {
        const { x, y } = this;
        this.x = y;
        this.y = -x;
        return this;
    }
    uni() {
        const l = this.len();
        if (l === 0) return this;
        this.x /= l;
        this.y /= l;
        return this;
    }
    tan(V) {
        return this.sub(V).uni();
    }
    dist(V) {
        return Vec.Dist(this, V);
    }
    distanceToLineSegment(A, B) {
        return Vec.DistanceToLineSegment(A, B, this);
    }
    slope(B) {
        return Vec.Slope(this, B);
    }
    snapToGrid(gridSize) {
        this.x = Math.round(this.x / gridSize) * gridSize;
        this.y = Math.round(this.y / gridSize) * gridSize;
        return this;
    }
    angle(B) {
        return Vec.Angle(this, B);
    }
    toAngle() {
        return Vec.ToAngle(this);
    }
    lrp(B, t) {
        this.x = this.x + (B.x - this.x) * t;
        this.y = this.y + (B.y - this.y) * t;
        return this;
    }
    equals(B) {
        return Vec.Equals(this, B);
    }
    equalsXY(x, y) {
        return Vec.EqualsXY(this, x, y);
    }
    toFixed() {
        this.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFixed"])(this.x);
        this.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFixed"])(this.y);
        return this;
    }
    toString() {
        return Vec.ToString(Vec.ToFixed(this));
    }
    toJson() {
        return Vec.ToJson(this);
    }
    toArray() {
        return Vec.ToArray(this);
    }
    static Add(A, B) {
        return new Vec(A.x + B.x, A.y + B.y);
    }
    static AddXY(A, x, y) {
        return new Vec(A.x + x, A.y + y);
    }
    static Sub(A, B) {
        return new Vec(A.x - B.x, A.y - B.y);
    }
    static SubXY(A, x, y) {
        return new Vec(A.x - x, A.y - y);
    }
    static AddScalar(A, n) {
        return new Vec(A.x + n, A.y + n);
    }
    static SubScalar(A, n) {
        return new Vec(A.x - n, A.y - n);
    }
    static Div(A, t) {
        return new Vec(A.x / t, A.y / t);
    }
    static Mul(A, t) {
        return new Vec(A.x * t, A.y * t);
    }
    static DivV(A, B) {
        return new Vec(A.x / B.x, A.y / B.y);
    }
    static MulV(A, B) {
        return new Vec(A.x * B.x, A.y * B.y);
    }
    static Neg(A) {
        return new Vec(-A.x, -A.y);
    }
    /**
   * Get the perpendicular vector to A.
   */ static Per(A) {
        return new Vec(A.y, -A.x);
    }
    static Abs(A) {
        return new Vec(Math.abs(A.x), Math.abs(A.y));
    }
    // Get the distance between two points.
    static Dist(A, B) {
        return ((A.y - B.y) ** 2 + (A.x - B.x) ** 2) ** 0.5;
    }
    // Get the Manhattan distance between two points.
    static ManhattanDist(A, B) {
        return Math.abs(A.x - B.x) + Math.abs(A.y - B.y);
    }
    // Get whether a distance between two points is less than a number. This is faster to calulate than using `Vec.Dist(a, b) < n`.
    static DistMin(A, B, n) {
        return (A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y) < n ** 2;
    }
    // Get the squared distance between two points. This is faster to calculate (no square root) so useful for "minimum distance" checks where the actual measurement does not matter.
    static Dist2(A, B) {
        return (A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y);
    }
    /**
   * Dot product of two vectors which is used to calculate the angle between them.
   */ static Dpr(A, B) {
        return A.x * B.x + A.y * B.y;
    }
    static Cross(A, V) {
        return new Vec(A.y * V.z - A.z * V.y, A.z * V.x - A.x * V.z);
    }
    /**
   * Cross product of two vectors which is used to calculate the area of a parallelogram.
   */ static Cpr(A, B) {
        return A.x * B.y - B.x * A.y;
    }
    static Len2(A) {
        return A.x * A.x + A.y * A.y;
    }
    static Len(A) {
        return (A.x * A.x + A.y * A.y) ** 0.5;
    }
    /**
   * Get the projection of A onto B.
   */ static Pry(A, B) {
        return Vec.Dpr(A, B) / Vec.Len(B);
    }
    /**
   * Get the unit vector of A.
   */ static Uni(A) {
        const l = Vec.Len(A);
        return new Vec(l === 0 ? 0 : A.x / l, l === 0 ? 0 : A.y / l);
    }
    static Tan(A, B) {
        return Vec.Uni(Vec.Sub(A, B));
    }
    static Min(A, B) {
        return new Vec(Math.min(A.x, B.x), Math.min(A.y, B.y));
    }
    static Max(A, B) {
        return new Vec(Math.max(A.x, B.x), Math.max(A.y, B.y));
    }
    static From({ x, y, z = 1 }) {
        return new Vec(x, y, z);
    }
    static FromArray(v) {
        return new Vec(v[0], v[1]);
    }
    static Rot(A, r = 0) {
        const s = Math.sin(r);
        const c = Math.cos(r);
        return new Vec(A.x * c - A.y * s, A.x * s + A.y * c);
    }
    static RotWith(A, C, r) {
        const x = A.x - C.x;
        const y = A.y - C.y;
        const s = Math.sin(r);
        const c = Math.cos(r);
        return new Vec(C.x + (x * c - y * s), C.y + (x * s + y * c));
    }
    /**
   * Get the nearest point on a line with a known unit vector that passes through point A
   *
   * ```ts
   * Vec.nearestPointOnLineThroughPoint(A, u, Point)
   * ```
   *
   * @param A - Any point on the line
   * @param u - The unit vector for the line.
   * @param P - A point not on the line to test.
   */ static NearestPointOnLineThroughPoint(A, u, P) {
        return Vec.Mul(u, Vec.Sub(P, A).pry(u)).add(A);
    }
    static NearestPointOnLineSegment(A, B, P, clamp2 = true) {
        if (Vec.Equals(A, P)) return Vec.From(P);
        if (Vec.Equals(B, P)) return Vec.From(P);
        const u = Vec.Tan(B, A);
        const C = Vec.Add(A, Vec.Mul(u, Vec.Sub(P, A).pry(u)));
        if (clamp2) {
            if (C.x < Math.min(A.x, B.x)) return Vec.Cast(A.x < B.x ? A : B);
            if (C.x > Math.max(A.x, B.x)) return Vec.Cast(A.x > B.x ? A : B);
            if (C.y < Math.min(A.y, B.y)) return Vec.Cast(A.y < B.y ? A : B);
            if (C.y > Math.max(A.y, B.y)) return Vec.Cast(A.y > B.y ? A : B);
        }
        return C;
    }
    static DistanceToLineThroughPoint(A, u, P) {
        return Vec.Dist(P, Vec.NearestPointOnLineThroughPoint(A, u, P));
    }
    static DistanceToLineSegment(A, B, P, clamp2 = true) {
        return Vec.Dist(P, Vec.NearestPointOnLineSegment(A, B, P, clamp2));
    }
    static Snap(A, step = 1) {
        return new Vec(Math.round(A.x / step) * step, Math.round(A.y / step) * step);
    }
    static Cast(A) {
        if (A instanceof Vec) return A;
        return Vec.From(A);
    }
    static Slope(A, B) {
        if (A.x === B.y) return NaN;
        return (A.y - B.y) / (A.x - B.x);
    }
    static IsNaN(A) {
        return isNaN(A.x) || isNaN(A.y);
    }
    /**
   * Get the angle from position A to position B.
   */ static Angle(A, B) {
        return Math.atan2(B.y - A.y, B.x - A.x);
    }
    /**
   * Get the angle between vector A and vector B. This will return the smallest angle between the
   * two vectors, between -π and π. The sign indicates direction of angle.
   */ static AngleBetween(A, B) {
        const p = A.x * B.x + A.y * B.y;
        const n = Math.sqrt((Math.pow(A.x, 2) + Math.pow(A.y, 2)) * (Math.pow(B.x, 2) + Math.pow(B.y, 2)));
        const sign = A.x * B.y - A.y * B.x < 0 ? -1 : 1;
        const angle = sign * Math.acos((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(p / n, -1, 1));
        return angle;
    }
    /**
   * Linearly interpolate between two points.
   * @param A - The first point.
   * @param B - The second point.
   * @param t - The interpolation value between 0 and 1.
   * @returns The interpolated point.
   */ static Lrp(A, B, t) {
        return Vec.Sub(B, A).mul(t).add(A);
    }
    static Med(A, B) {
        return new Vec((A.x + B.x) / 2, (A.y + B.y) / 2);
    }
    static Equals(A, B) {
        return Math.abs(A.x - B.x) < 1e-4 && Math.abs(A.y - B.y) < 1e-4;
    }
    static EqualsXY(A, x, y) {
        return A.x === x && A.y === y;
    }
    static Clockwise(A, B, C) {
        return (C.x - A.x) * (B.y - A.y) - (B.x - A.x) * (C.y - A.y) < 0;
    }
    static Rescale(A, n) {
        const l = Vec.Len(A);
        return new Vec(n * A.x / l, n * A.y / l);
    }
    static ScaleWithOrigin(A, scale, origin) {
        return Vec.Sub(A, origin).mul(scale).add(origin);
    }
    static ToFixed(A) {
        return new Vec((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFixed"])(A.x), (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFixed"])(A.y));
    }
    static ToInt(A) {
        return new Vec(parseInt(A.x.toFixed(0)), parseInt(A.y.toFixed(0)), parseInt((A.z ?? 0).toFixed(0)));
    }
    static ToCss(A) {
        return `${A.x},${A.y}`;
    }
    static Nudge(A, B, distance) {
        return Vec.Add(A, Vec.Tan(B, A).mul(distance));
    }
    static ToString(A) {
        return `${A.x}, ${A.y}`;
    }
    static ToAngle(A) {
        let r = Math.atan2(A.y, A.x);
        if (r < 0) r += Math.PI * 2;
        return r;
    }
    static FromAngle(r, length = 1) {
        return new Vec(Math.cos(r) * length, Math.sin(r) * length);
    }
    static ToArray(A) {
        return [
            A.x,
            A.y,
            A.z
        ];
    }
    static ToJson(A) {
        const { x, y, z } = A;
        return {
            x,
            y,
            z
        };
    }
    static Average(arr) {
        const len = arr.length;
        const avg = new Vec(0, 0);
        if (len === 0) {
            return avg;
        }
        for(let i = 0; i < len; i++){
            avg.add(arr[i]);
        }
        return avg.div(len);
    }
    static Clamp(A, min, max) {
        if (max === void 0) {
            return new Vec(Math.min(Math.max(A.x, min)), Math.min(Math.max(A.y, min)));
        }
        return new Vec(Math.min(Math.max(A.x, min), max), Math.min(Math.max(A.y, min), max));
    }
    /**
   * Get an array of points (with simulated pressure) between two points.
   *
   * @param A - The first point.
   * @param B - The second point.
   * @param steps - The number of points to return.
   */ static PointsBetween(A, B, steps = 6) {
        const results = [];
        for(let i = 0; i < steps; i++){
            const t = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeInQuad(i / (steps - 1));
            const point = Vec.Lrp(A, B, t);
            point.z = Math.min(1, 0.5 + Math.abs(0.5 - ease(t)) * 0.65);
            results.push(point);
        }
        return results;
    }
    static SnapToGrid(A, gridSize = 8) {
        return new Vec(Math.round(A.x / gridSize) * gridSize, Math.round(A.y / gridSize) * gridSize);
    }
}
const ease = (t)=>t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
;
 //# sourceMappingURL=Vec.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HALF_PI",
    ()=>HALF_PI,
    "PI",
    ()=>PI,
    "PI2",
    ()=>PI2,
    "SIN",
    ()=>SIN,
    "angleDistance",
    ()=>angleDistance,
    "approximately",
    ()=>approximately,
    "approximatelyLte",
    ()=>approximatelyLte,
    "areAnglesCompatible",
    ()=>areAnglesCompatible,
    "average",
    ()=>average,
    "canonicalizeRotation",
    ()=>canonicalizeRotation,
    "centerOfCircleFromThreePoints",
    ()=>centerOfCircleFromThreePoints,
    "clamp",
    ()=>clamp,
    "clampRadians",
    ()=>clampRadians,
    "clockwiseAngleDist",
    ()=>clockwiseAngleDist,
    "counterClockwiseAngleDist",
    ()=>counterClockwiseAngleDist,
    "degreesToRadians",
    ()=>degreesToRadians,
    "getArcMeasure",
    ()=>getArcMeasure,
    "getPointInArcT",
    ()=>getPointInArcT,
    "getPointOnCircle",
    ()=>getPointOnCircle,
    "getPointsOnArc",
    ()=>getPointsOnArc,
    "getPolygonVertices",
    ()=>getPolygonVertices,
    "isSafeFloat",
    ()=>isSafeFloat,
    "perimeterOfEllipse",
    ()=>perimeterOfEllipse,
    "pointInPolygon",
    ()=>pointInPolygon,
    "precise",
    ()=>precise,
    "radiansToDegrees",
    ()=>radiansToDegrees,
    "rangeIntersection",
    ()=>rangeIntersection,
    "rangesOverlap",
    ()=>rangesOverlap,
    "shortAngleDist",
    ()=>shortAngleDist,
    "snapAngle",
    ()=>snapAngle,
    "toDomPrecision",
    ()=>toDomPrecision,
    "toFixed",
    ()=>toFixed,
    "toPrecision",
    ()=>toPrecision
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
function precise(A) {
    return `${toDomPrecision(A.x)},${toDomPrecision(A.y)} `;
}
function average(A, B) {
    return `${toDomPrecision((A.x + B.x) / 2)},${toDomPrecision((A.y + B.y) / 2)} `;
}
const PI = Math.PI;
const HALF_PI = PI / 2;
const PI2 = PI * 2;
const SIN = Math.sin;
function clamp(n, min, max) {
    return Math.max(min, typeof max !== "undefined" ? Math.min(n, max) : n);
}
function toPrecision(n, precision = 1e10) {
    if (!n) return 0;
    return Math.round(n * precision) / precision;
}
function approximately(a, b, precision = 1e-6) {
    return Math.abs(a - b) <= precision;
}
function approximatelyLte(a, b, precision = 1e-6) {
    return a < b || approximately(a, b, precision);
}
function perimeterOfEllipse(rx, ry) {
    const h = Math.pow(rx - ry, 2) / Math.pow(rx + ry, 2);
    return PI * (rx + ry) * (1 + 3 * h / (10 + Math.sqrt(4 - 3 * h)));
}
function canonicalizeRotation(a) {
    a = a % PI2;
    if (a < 0) {
        a = a + PI2;
    } else if (a === 0) {
        a = 0;
    }
    return a;
}
function clockwiseAngleDist(a0, a1) {
    a0 = canonicalizeRotation(a0);
    a1 = canonicalizeRotation(a1);
    if (a0 > a1) {
        a1 += PI2;
    }
    return a1 - a0;
}
function counterClockwiseAngleDist(a0, a1) {
    return PI2 - clockwiseAngleDist(a0, a1);
}
function shortAngleDist(a0, a1) {
    const da = (a1 - a0) % PI2;
    return 2 * da % PI2 - da;
}
function clampRadians(r) {
    return (PI2 + r) % PI2;
}
function snapAngle(r, segments) {
    const seg = PI2 / segments;
    let ang = Math.floor((clampRadians(r) + seg / 2) / seg) * seg % PI2;
    if (ang < PI) ang += PI2;
    if (ang > PI) ang -= PI2;
    return ang;
}
function areAnglesCompatible(a, b) {
    return a === b || approximately(a % (Math.PI / 2) - b % (Math.PI / 2), 0);
}
function degreesToRadians(d) {
    return d * PI / 180;
}
function radiansToDegrees(r) {
    return r * 180 / PI;
}
function getPointOnCircle(center, r, a) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](center.x, center.y).add(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].FromAngle(a, r));
}
function getPolygonVertices(width, height, sides) {
    const cx = width / 2;
    const cy = height / 2;
    const pointsOnPerimeter = [];
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for(let i = 0; i < sides; i++){
        const step = PI2 / sides;
        const t = -HALF_PI + i * step;
        const x = cx + cx * Math.cos(t);
        const y = cy + cy * Math.sin(t);
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
        pointsOnPerimeter.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x, y));
    }
    const w = maxX - minX;
    const h = maxY - minY;
    const dx = width - w;
    const dy = height - h;
    if (dx !== 0 || dy !== 0) {
        for(let i = 0; i < pointsOnPerimeter.length; i++){
            const pt = pointsOnPerimeter[i];
            pt.x = (pt.x - minX) / w * width;
            pt.y = (pt.y - minY) / h * height;
        }
    }
    return pointsOnPerimeter;
}
function rangesOverlap(a0, a1, b0, b1) {
    return a0 < b1 && b0 < a1;
}
function rangeIntersection(a0, a1, b0, b1) {
    const min = Math.max(a0, b0);
    const max = Math.min(a1, b1);
    if (min <= max) {
        return [
            min,
            max
        ];
    }
    return null;
}
function cross(x, y, z) {
    return (y.x - x.x) * (z.y - x.y) - (z.x - x.x) * (y.y - x.y);
}
function pointInPolygon(A, points) {
    let windingNumber = 0;
    let a;
    let b;
    for(let i = 0; i < points.length; i++){
        a = points[i];
        if (a.x === A.x && a.y === A.y) return true;
        b = points[(i + 1) % points.length];
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(A, a) + __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(A, b) === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(a, b)) return true;
        if (a.y <= A.y) {
            if (b.y > A.y && cross(a, b, A) > 0) {
                windingNumber += 1;
            }
        } else if (b.y <= A.y && cross(a, b, A) < 0) {
            windingNumber -= 1;
        }
    }
    return windingNumber !== 0;
}
function toDomPrecision(v) {
    return Math.round(v * 1e4) / 1e4;
}
function toFixed(v) {
    return Math.round(v * 100) / 100;
}
const isSafeFloat = (n)=>{
    return Math.abs(n) < Number.MAX_SAFE_INTEGER;
};
function angleDistance(fromAngle, toAngle, direction) {
    const dist = direction < 0 ? clockwiseAngleDist(fromAngle, toAngle) : counterClockwiseAngleDist(fromAngle, toAngle);
    return dist;
}
function getPointInArcT(mAB, A, B, P) {
    let mAP;
    if (Math.abs(mAB) > PI) {
        mAP = shortAngleDist(A, P);
        const mPB = shortAngleDist(P, B);
        if (Math.abs(mAP) < Math.abs(mPB)) {
            return mAP / mAB;
        } else {
            return (mAB - mPB) / mAB;
        }
    } else {
        mAP = shortAngleDist(A, P);
        const t = mAP / mAB;
        if (Math.sign(mAP) !== Math.sign(mAB)) {
            return Math.abs(t) > 0.5 ? 1 : 0;
        }
        return t;
    }
}
function getArcMeasure(A, B, sweepFlag, largeArcFlag) {
    const m = 2 * ((B - A) % PI2) % PI2 - (B - A) % PI2;
    if (!largeArcFlag) return m;
    return (PI2 - Math.abs(m)) * (sweepFlag ? 1 : -1);
}
function centerOfCircleFromThreePoints(a, b, c) {
    const u = -2 * (a.x * (b.y - c.y) - a.y * (b.x - c.x) + b.x * c.y - c.x * b.y);
    const x = ((a.x * a.x + a.y * a.y) * (c.y - b.y) + (b.x * b.x + b.y * b.y) * (a.y - c.y) + (c.x * c.x + c.y * c.y) * (b.y - a.y)) / u;
    const y = ((a.x * a.x + a.y * a.y) * (b.x - c.x) + (b.x * b.x + b.y * b.y) * (c.x - a.x) + (c.x * c.x + c.y * c.y) * (a.x - b.x)) / u;
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
        return null;
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x, y);
}
function getPointsOnArc(startPoint, endPoint, center, radius, numPoints) {
    if (center === null) {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(startPoint),
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(endPoint)
        ];
    }
    const results = [];
    const startAngle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(center, startPoint);
    const endAngle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(center, endPoint);
    const l = clockwiseAngleDist(startAngle, endAngle);
    for(let i = 0; i < numPoints; i++){
        const t = i / (numPoints - 1);
        const angle = startAngle + l * t;
        const point = getPointOnCircle(center, radius, angle);
        results.push(point);
    }
    return results;
}
;
 //# sourceMappingURL=utils.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Box",
    ()=>Box,
    "ROTATE_CORNER_TO_SELECTION_CORNER",
    ()=>ROTATE_CORNER_TO_SELECTION_CORNER,
    "flipSelectionHandleX",
    ()=>flipSelectionHandleX,
    "flipSelectionHandleY",
    ()=>flipSelectionHandleY,
    "isSelectionCorner",
    ()=>isSelectionCorner,
    "rotateSelectionHandle",
    ()=>rotateSelectionHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
;
;
class Box {
    constructor(x = 0, y = 0, w = 0, h = 0){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    // eslint-disable-next-line no-restricted-syntax
    get point() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y);
    }
    // eslint-disable-next-line no-restricted-syntax
    set point(val) {
        this.x = val.x;
        this.y = val.y;
    }
    // eslint-disable-next-line no-restricted-syntax
    get minX() {
        return this.x;
    }
    // eslint-disable-next-line no-restricted-syntax
    set minX(n) {
        this.x = n;
    }
    // eslint-disable-next-line no-restricted-syntax
    get left() {
        return this.x;
    }
    // eslint-disable-next-line no-restricted-syntax
    get midX() {
        return this.x + this.w / 2;
    }
    // eslint-disable-next-line no-restricted-syntax
    get maxX() {
        return this.x + this.w;
    }
    // eslint-disable-next-line no-restricted-syntax
    get right() {
        return this.x + this.w;
    }
    // eslint-disable-next-line no-restricted-syntax
    get minY() {
        return this.y;
    }
    // eslint-disable-next-line no-restricted-syntax
    set minY(n) {
        this.y = n;
    }
    // eslint-disable-next-line no-restricted-syntax
    get top() {
        return this.y;
    }
    // eslint-disable-next-line no-restricted-syntax
    get midY() {
        return this.y + this.h / 2;
    }
    // eslint-disable-next-line no-restricted-syntax
    get maxY() {
        return this.y + this.h;
    }
    // eslint-disable-next-line no-restricted-syntax
    get bottom() {
        return this.y + this.h;
    }
    // eslint-disable-next-line no-restricted-syntax
    get width() {
        return this.w;
    }
    // eslint-disable-next-line no-restricted-syntax
    set width(n) {
        this.w = n;
    }
    // eslint-disable-next-line no-restricted-syntax
    get height() {
        return this.h;
    }
    // eslint-disable-next-line no-restricted-syntax
    set height(n) {
        this.h = n;
    }
    // eslint-disable-next-line no-restricted-syntax
    get aspectRatio() {
        return this.width / this.height;
    }
    // eslint-disable-next-line no-restricted-syntax
    get center() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w / 2, this.y + this.h / 2);
    }
    // eslint-disable-next-line no-restricted-syntax
    set center(v) {
        this.x = v.x - this.w / 2;
        this.y = v.y - this.h / 2;
    }
    // eslint-disable-next-line no-restricted-syntax
    get corners() {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y + this.h),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y + this.h)
        ];
    }
    // eslint-disable-next-line no-restricted-syntax
    get cornersAndCenter() {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y + this.h),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y + this.h),
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w / 2, this.y + this.h / 2)
        ];
    }
    // eslint-disable-next-line no-restricted-syntax
    get sides() {
        const { corners } = this;
        return [
            [
                corners[0],
                corners[1]
            ],
            [
                corners[1],
                corners[2]
            ],
            [
                corners[2],
                corners[3]
            ],
            [
                corners[3],
                corners[0]
            ]
        ];
    }
    // eslint-disable-next-line no-restricted-syntax
    get size() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.w, this.h);
    }
    isValid() {
        return Number.isFinite(this.x) && Number.isFinite(this.y) && Number.isFinite(this.w) && Number.isFinite(this.h);
    }
    toFixed() {
        this.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPrecision"])(this.x);
        this.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPrecision"])(this.y);
        this.w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPrecision"])(this.w);
        this.h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPrecision"])(this.h);
        return this;
    }
    setTo(B) {
        this.x = B.x;
        this.y = B.y;
        this.w = B.w;
        this.h = B.h;
        return this;
    }
    set(x = 0, y = 0, w = 0, h = 0) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        return this;
    }
    expand(A) {
        const minX = Math.min(this.x, A.x);
        const minY = Math.min(this.y, A.y);
        const maxX = Math.max(this.x + this.w, A.x + A.w);
        const maxY = Math.max(this.y + this.h, A.y + A.h);
        this.x = minX;
        this.y = minY;
        this.w = maxX - minX;
        this.h = maxY - minY;
        return this;
    }
    expandBy(n) {
        this.x -= n;
        this.y -= n;
        this.w += n * 2;
        this.h += n * 2;
        return this;
    }
    scale(n) {
        this.x /= n;
        this.y /= n;
        this.w /= n;
        this.h /= n;
        return this;
    }
    clone() {
        const { x, y, w, h } = this;
        return new Box(x, y, w, h);
    }
    translate(delta) {
        this.x += delta.x;
        this.y += delta.y;
        return this;
    }
    snapToGrid(size) {
        const minX = Math.round(this.x / size) * size;
        const minY = Math.round(this.y / size) * size;
        const maxX = Math.round((this.x + this.w) / size) * size;
        const maxY = Math.round((this.y + this.h) / size) * size;
        this.minX = minX;
        this.minY = minY;
        this.width = Math.max(1, maxX - minX);
        this.height = Math.max(1, maxY - minY);
    }
    collides(B) {
        return Box.Collides(this, B);
    }
    contains(B) {
        return Box.Contains(this, B);
    }
    includes(B) {
        return Box.Includes(this, B);
    }
    containsPoint(V, margin = 0) {
        return Box.ContainsPoint(this, V, margin);
    }
    getHandlePoint(handle) {
        switch(handle){
            case "top_left":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y);
            case "top_right":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y);
            case "bottom_left":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y + this.h);
            case "bottom_right":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y + this.h);
            case "top":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w / 2, this.y);
            case "right":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w, this.y + this.h / 2);
            case "bottom":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x + this.w / 2, this.y + this.h);
            case "left":
                return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](this.x, this.y + this.h / 2);
        }
    }
    toJson() {
        return {
            x: this.x,
            y: this.y,
            w: this.w,
            h: this.h
        };
    }
    resize(handle, dx, dy) {
        const { minX: a0x, minY: a0y, maxX: a1x, maxY: a1y } = this;
        let { minX: b0x, minY: b0y, maxX: b1x, maxY: b1y } = this;
        switch(handle){
            case "left":
            case "top_left":
            case "bottom_left":
                {
                    b0x += dx;
                    break;
                }
            case "right":
            case "top_right":
            case "bottom_right":
                {
                    b1x += dx;
                    break;
                }
        }
        switch(handle){
            case "top":
            case "top_left":
            case "top_right":
                {
                    b0y += dy;
                    break;
                }
            case "bottom":
            case "bottom_left":
            case "bottom_right":
                {
                    b1y += dy;
                    break;
                }
        }
        const scaleX = (b1x - b0x) / (a1x - a0x);
        const scaleY = (b1y - b0y) / (a1y - a0y);
        const flipX = scaleX < 0;
        const flipY = scaleY < 0;
        if (flipX) {
            const t = b1x;
            b1x = b0x;
            b0x = t;
        }
        if (flipY) {
            const t = b1y;
            b1y = b0y;
            b0y = t;
        }
        this.minX = b0x;
        this.minY = b0y;
        this.width = Math.abs(b1x - b0x);
        this.height = Math.abs(b1y - b0y);
    }
    union(box) {
        const minX = Math.min(this.x, box.x);
        const minY = Math.min(this.y, box.y);
        const maxX = Math.max(this.x + this.w, box.x + box.w);
        const maxY = Math.max(this.y + this.h, box.y + box.h);
        this.x = minX;
        this.y = minY;
        this.width = maxX - minX;
        this.height = maxY - minY;
        return this;
    }
    static From(box) {
        return new Box(box.x, box.y, box.w, box.h);
    }
    static FromCenter(center, size) {
        return new Box(center.x - size.x / 2, center.y - size.y / 2, size.x, size.y);
    }
    static FromPoints(points) {
        if (points.length === 0) return new Box();
        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        let point;
        for(let i = 0, n = points.length; i < n; i++){
            point = points[i];
            minX = Math.min(point.x, minX);
            minY = Math.min(point.y, minY);
            maxX = Math.max(point.x, maxX);
            maxY = Math.max(point.y, maxY);
        }
        return new Box(minX, minY, maxX - minX, maxY - minY);
    }
    static Expand(A, B) {
        const minX = Math.min(B.minX, A.minX);
        const minY = Math.min(B.minY, A.minY);
        const maxX = Math.max(B.maxX, A.maxX);
        const maxY = Math.max(B.maxY, A.maxY);
        return new Box(minX, minY, maxX - minX, maxY - minY);
    }
    static ExpandBy(A, n) {
        return new Box(A.minX - n, A.minY - n, A.width + n * 2, A.height + n * 2);
    }
    static Collides(A, B) {
        return !(A.maxX < B.minX || A.minX > B.maxX || A.maxY < B.minY || A.minY > B.maxY);
    }
    static Contains(A, B) {
        return A.minX < B.minX && A.minY < B.minY && A.maxY > B.maxY && A.maxX > B.maxX;
    }
    static ContainsApproximately(A, B, precision) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(A.minX, B.minX, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(A.minY, B.minY, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(B.maxX, A.maxX, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(B.maxY, A.maxY, precision);
    }
    static Includes(A, B) {
        return Box.Collides(A, B) || Box.Contains(A, B);
    }
    static ContainsPoint(A, B, margin = 0) {
        return !(B.x < A.minX - margin || B.y < A.minY - margin || B.x > A.maxX + margin || B.y > A.maxY + margin);
    }
    static Common(boxes) {
        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        for(let i = 0; i < boxes.length; i++){
            const B = boxes[i];
            minX = Math.min(minX, B.minX);
            minY = Math.min(minY, B.minY);
            maxX = Math.max(maxX, B.maxX);
            maxY = Math.max(maxY, B.maxY);
        }
        return new Box(minX, minY, maxX - minX, maxY - minY);
    }
    static Sides(A, inset = 0) {
        const { corners } = A;
        if (inset) {}
        return [
            [
                corners[0],
                corners[1]
            ],
            [
                corners[1],
                corners[2]
            ],
            [
                corners[2],
                corners[3]
            ],
            [
                corners[3],
                corners[0]
            ]
        ];
    }
    static Resize(box, handle, dx, dy, isAspectRatioLocked = false) {
        const { minX: a0x, minY: a0y, maxX: a1x, maxY: a1y } = box;
        let { minX: b0x, minY: b0y, maxX: b1x, maxY: b1y } = box;
        switch(handle){
            case "left":
            case "top_left":
            case "bottom_left":
                {
                    b0x += dx;
                    break;
                }
            case "right":
            case "top_right":
            case "bottom_right":
                {
                    b1x += dx;
                    break;
                }
        }
        switch(handle){
            case "top":
            case "top_left":
            case "top_right":
                {
                    b0y += dy;
                    break;
                }
            case "bottom":
            case "bottom_left":
            case "bottom_right":
                {
                    b1y += dy;
                    break;
                }
        }
        const scaleX = (b1x - b0x) / (a1x - a0x);
        const scaleY = (b1y - b0y) / (a1y - a0y);
        const flipX = scaleX < 0;
        const flipY = scaleY < 0;
        if (isAspectRatioLocked) {
            const aspectRatio = (a1x - a0x) / (a1y - a0y);
            const bw = Math.abs(b1x - b0x);
            const bh = Math.abs(b1y - b0y);
            const tw = bw * (scaleY < 0 ? 1 : -1) * (1 / aspectRatio);
            const th = bh * (scaleX < 0 ? 1 : -1) * aspectRatio;
            const isTall = aspectRatio < bw / bh;
            switch(handle){
                case "top_left":
                    {
                        if (isTall) b0y = b1y + tw;
                        else b0x = b1x + th;
                        break;
                    }
                case "top_right":
                    {
                        if (isTall) b0y = b1y + tw;
                        else b1x = b0x - th;
                        break;
                    }
                case "bottom_right":
                    {
                        if (isTall) b1y = b0y - tw;
                        else b1x = b0x - th;
                        break;
                    }
                case "bottom_left":
                    {
                        if (isTall) b1y = b0y - tw;
                        else b0x = b1x + th;
                        break;
                    }
                case "bottom":
                case "top":
                    {
                        const m = (b0x + b1x) / 2;
                        const w = bh * aspectRatio;
                        b0x = m - w / 2;
                        b1x = m + w / 2;
                        break;
                    }
                case "left":
                case "right":
                    {
                        const m = (b0y + b1y) / 2;
                        const h = bw / aspectRatio;
                        b0y = m - h / 2;
                        b1y = m + h / 2;
                        break;
                    }
            }
        }
        if (flipX) {
            const t = b1x;
            b1x = b0x;
            b0x = t;
        }
        if (flipY) {
            const t = b1y;
            b1y = b0y;
            b0y = t;
        }
        const final = new Box(b0x, b0y, Math.abs(b1x - b0x), Math.abs(b1y - b0y));
        return {
            box: final,
            scaleX: +(final.width / box.width * (scaleX > 0 ? 1 : -1)).toFixed(5),
            scaleY: +(final.height / box.height * (scaleY > 0 ? 1 : -1)).toFixed(5)
        };
    }
    equals(other) {
        return Box.Equals(this, other);
    }
    static Equals(a, b) {
        return b.x === a.x && b.y === a.y && b.w === a.w && b.h === a.h;
    }
    zeroFix() {
        this.w = Math.max(1, this.w);
        this.h = Math.max(1, this.h);
        return this;
    }
    static ZeroFix(other) {
        return new Box(other.x, other.y, Math.max(1, other.w), Math.max(1, other.h));
    }
}
function flipSelectionHandleY(handle) {
    switch(handle){
        case "top":
            return "bottom";
        case "bottom":
            return "top";
        case "top_left":
            return "bottom_left";
        case "top_right":
            return "bottom_right";
        case "bottom_left":
            return "top_left";
        case "bottom_right":
            return "top_right";
        default:
            return handle;
    }
}
function flipSelectionHandleX(handle) {
    switch(handle){
        case "left":
            return "right";
        case "right":
            return "left";
        case "top_left":
            return "top_right";
        case "top_right":
            return "top_left";
        case "bottom_left":
            return "bottom_right";
        case "bottom_right":
            return "bottom_left";
        default:
            return handle;
    }
}
const ORDERED_SELECTION_HANDLES = [
    "top",
    "top_right",
    "right",
    "bottom_right",
    "bottom",
    "bottom_left",
    "left",
    "top_left"
];
function rotateSelectionHandle(handle, rotation) {
    rotation = rotation % __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI2"];
    const numSteps = Math.round(rotation / (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] / 4));
    const currentIndex = ORDERED_SELECTION_HANDLES.indexOf(handle);
    return ORDERED_SELECTION_HANDLES[(currentIndex + numSteps) % ORDERED_SELECTION_HANDLES.length];
}
function isSelectionCorner(selection) {
    return selection === "top_left" || selection === "top_right" || selection === "bottom_right" || selection === "bottom_left";
}
const ROTATE_CORNER_TO_SELECTION_CORNER = {
    top_left_rotate: "top_left",
    top_right_rotate: "top_right",
    bottom_right_rotate: "bottom_right",
    bottom_left_rotate: "bottom_left",
    mobile_rotate: "top_left"
};
;
 //# sourceMappingURL=Box.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Mat",
    ()=>Mat,
    "decomposeMatrix",
    ()=>decomposeMatrix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
;
;
class Mat {
    constructor(a, b, c, d, e, f){
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    a = 1;
    b = 0;
    c = 0;
    d = 1;
    e = 0;
    f = 0;
    equals(m) {
        return this === m || this.a === m.a && this.b === m.b && this.c === m.c && this.d === m.d && this.e === m.e && this.f === m.f;
    }
    identity() {
        this.a = 1;
        this.b = 0;
        this.c = 0;
        this.d = 1;
        this.e = 0;
        this.f = 0;
        return this;
    }
    multiply(m) {
        const m2 = m;
        const { a, b, c, d, e, f } = this;
        this.a = a * m2.a + c * m2.b;
        this.c = a * m2.c + c * m2.d;
        this.e = a * m2.e + c * m2.f + e;
        this.b = b * m2.a + d * m2.b;
        this.d = b * m2.c + d * m2.d;
        this.f = b * m2.e + d * m2.f + f;
        return this;
    }
    rotate(r, cx, cy) {
        if (r === 0) return this;
        if (cx === void 0) return this.multiply(Mat.Rotate(r));
        return this.translate(cx, cy).multiply(Mat.Rotate(r)).translate(-cx, -cy);
    }
    translate(x, y) {
        return this.multiply(Mat.Translate(x, y));
    }
    scale(x, y) {
        return this.multiply(Mat.Scale(x, y));
    }
    invert() {
        const { a, b, c, d, e, f } = this;
        const denom = a * d - b * c;
        this.a = d / denom;
        this.b = b / -denom;
        this.c = c / -denom;
        this.d = a / denom;
        this.e = (d * e - c * f) / -denom;
        this.f = (b * e - a * f) / denom;
        return this;
    }
    applyToPoint(point) {
        return Mat.applyToPoint(this, point);
    }
    applyToPoints(points) {
        return Mat.applyToPoints(this, points);
    }
    rotation() {
        return Mat.Rotation(this);
    }
    point() {
        return Mat.Point(this);
    }
    decomposed() {
        return Mat.Decompose(this);
    }
    toCssString() {
        return Mat.toCssString(this);
    }
    setTo(model) {
        Object.assign(this, model);
        return this;
    }
    decompose() {
        return Mat.Decompose(this);
    }
    clone() {
        return new Mat(this.a, this.b, this.c, this.d, this.e, this.f);
    }
    /* --------------------- Static --------------------- */ static Identity() {
        return new Mat(1, 0, 0, 1, 0, 0);
    }
    static Translate(x, y) {
        return new Mat(1, 0, 0, 1, x, y);
    }
    static Rotate(r, cx, cy) {
        if (r === 0) return Mat.Identity();
        const cosAngle = Math.cos(r);
        const sinAngle = Math.sin(r);
        const rotationMatrix = new Mat(cosAngle, sinAngle, -sinAngle, cosAngle, 0, 0);
        if (cx === void 0) return rotationMatrix;
        return Mat.Compose(Mat.Translate(cx, cy), rotationMatrix, Mat.Translate(-cx, -cy));
    }
    static Scale(x, y, cx, cy) {
        const scaleMatrix = new Mat(x, 0, 0, y, 0, 0);
        if (cx === void 0) return scaleMatrix;
        return Mat.Translate(cx, cy).multiply(scaleMatrix).translate(-cx, -cy);
    }
    static Multiply(m1, m2) {
        return {
            a: m1.a * m2.a + m1.c * m2.b,
            c: m1.a * m2.c + m1.c * m2.d,
            e: m1.a * m2.e + m1.c * m2.f + m1.e,
            b: m1.b * m2.a + m1.d * m2.b,
            d: m1.b * m2.c + m1.d * m2.d,
            f: m1.b * m2.e + m1.d * m2.f + m1.f
        };
    }
    static Inverse(m) {
        const denom = m.a * m.d - m.b * m.c;
        return {
            a: m.d / denom,
            b: m.b / -denom,
            c: m.c / -denom,
            d: m.a / denom,
            e: (m.d * m.e - m.c * m.f) / -denom,
            f: (m.b * m.e - m.a * m.f) / denom
        };
    }
    static Absolute(m) {
        const denom = m.a * m.d - m.b * m.c;
        return {
            a: m.d / denom,
            b: m.b / -denom,
            c: m.c / -denom,
            d: m.a / denom,
            e: (m.d * m.e - m.c * m.f) / denom,
            f: (m.b * m.e - m.a * m.f) / -denom
        };
    }
    static Compose(...matrices) {
        const matrix = Mat.Identity();
        for(let i = 0, n = matrices.length; i < n; i++){
            matrix.multiply(matrices[i]);
        }
        return matrix;
    }
    static Point(m) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](m.e, m.f);
    }
    static Rotation(m) {
        let rotation;
        if (m.a !== 0 || m.c !== 0) {
            const hypotAc = (m.a * m.a + m.c * m.c) ** 0.5;
            rotation = Math.acos(m.a / hypotAc) * (m.c > 0 ? -1 : 1);
        } else if (m.b !== 0 || m.d !== 0) {
            const hypotBd = (m.b * m.b + m.d * m.d) ** 0.5;
            rotation = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] + Math.acos(m.b / hypotBd) * (m.d > 0 ? -1 : 1);
        } else {
            rotation = 0;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampRadians"])(rotation);
    }
    static Decompose(m) {
        let scaleX, scaleY, rotation;
        if (m.a !== 0 || m.c !== 0) {
            const hypotAc = (m.a * m.a + m.c * m.c) ** 0.5;
            scaleX = hypotAc;
            scaleY = (m.a * m.d - m.b * m.c) / hypotAc;
            rotation = Math.acos(m.a / hypotAc) * (m.c > 0 ? -1 : 1);
        } else if (m.b !== 0 || m.d !== 0) {
            const hypotBd = (m.b * m.b + m.d * m.d) ** 0.5;
            scaleX = (m.a * m.d - m.b * m.c) / hypotBd;
            scaleY = hypotBd;
            rotation = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] + Math.acos(m.b / hypotBd) * (m.d > 0 ? -1 : 1);
        } else {
            scaleX = 0;
            scaleY = 0;
            rotation = 0;
        }
        return {
            x: m.e,
            y: m.f,
            scaleX,
            scaleY,
            rotation: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampRadians"])(rotation)
        };
    }
    static Smooth(m, precision = 1e10) {
        m.a = Math.round(m.a * precision) / precision;
        m.b = Math.round(m.b * precision) / precision;
        m.c = Math.round(m.c * precision) / precision;
        m.d = Math.round(m.d * precision) / precision;
        m.e = Math.round(m.e * precision) / precision;
        m.f = Math.round(m.f * precision) / precision;
        return m;
    }
    static toCssString(m) {
        return `matrix(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.a)}, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.b)}, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.c)}, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.d)}, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.e)}, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(m.f)})`;
    }
    static applyToPoint(m, point) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](m.a * point.x + m.c * point.y + m.e, m.b * point.x + m.d * point.y + m.f, point.z);
    }
    static applyToXY(m, x, y) {
        return [
            m.a * x + m.c * y + m.e,
            m.b * x + m.d * y + m.f
        ];
    }
    static applyToPoints(m, points) {
        return points.map((point)=>new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](m.a * point.x + m.c * point.y + m.e, m.b * point.x + m.d * point.y + m.f, point.z));
    }
    static applyToBounds(m, box) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](m.e + box.minX, m.f + box.minY, box.width, box.height);
    }
    static From(m) {
        return new Mat(m.a, m.b, m.c, m.d, m.e, m.f);
    }
    static Cast(m) {
        return m instanceof Mat ? m : Mat.From(m);
    }
}
function decomposeMatrix(m) {
    return {
        x: m.e,
        y: m.f,
        scaleX: Math.sqrt(m.a * m.a + m.b * m.b),
        scaleY: Math.sqrt(m.c * m.c + m.d * m.d),
        rotation: Math.atan2(m.b, m.a)
    };
}
;
 //# sourceMappingURL=Mat.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "intersectCircleCircle",
    ()=>intersectCircleCircle,
    "intersectCirclePolygon",
    ()=>intersectCirclePolygon,
    "intersectCirclePolyline",
    ()=>intersectCirclePolyline,
    "intersectLineSegmentCircle",
    ()=>intersectLineSegmentCircle,
    "intersectLineSegmentLineSegment",
    ()=>intersectLineSegmentLineSegment,
    "intersectLineSegmentPolygon",
    ()=>intersectLineSegmentPolygon,
    "intersectLineSegmentPolyline",
    ()=>intersectLineSegmentPolyline,
    "intersectPolygonBounds",
    ()=>intersectPolygonBounds,
    "intersectPolygonPolygon",
    ()=>intersectPolygonPolygon,
    "intersectPolys",
    ()=>intersectPolys,
    "linesIntersect",
    ()=>linesIntersect,
    "polygonIntersectsPolyline",
    ()=>polygonIntersectsPolyline,
    "polygonsIntersect",
    ()=>polygonsIntersect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
;
function intersectLineSegmentLineSegment(a1, a2, b1, b2, precision = 1e-10) {
    const ABx = a1.x - b1.x;
    const ABy = a1.y - b1.y;
    const BVx = b2.x - b1.x;
    const BVy = b2.y - b1.y;
    const AVx = a2.x - a1.x;
    const AVy = a2.y - a1.y;
    const ua_t = BVx * ABy - BVy * ABx;
    const ub_t = AVx * ABy - AVy * ABx;
    const u_b = BVy * AVx - BVx * AVy;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(ua_t, 0, precision) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(ub_t, 0, precision)) return null;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(u_b, 0, precision)) return null;
    if (u_b !== 0) {
        const ua = ua_t / u_b;
        const ub = ub_t / u_b;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(0, ua, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(ua, 1, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(0, ub, precision) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximatelyLte"])(ub, 1, precision)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].AddXY(a1, ua * AVx, ua * AVy);
        }
    }
    return null;
}
function intersectLineSegmentCircle(a1, a2, c, r) {
    const a = (a2.x - a1.x) * (a2.x - a1.x) + (a2.y - a1.y) * (a2.y - a1.y);
    const b = 2 * ((a2.x - a1.x) * (a1.x - c.x) + (a2.y - a1.y) * (a1.y - c.y));
    const cc = c.x * c.x + c.y * c.y + a1.x * a1.x + a1.y * a1.y - 2 * (c.x * a1.x + c.y * a1.y) - r * r;
    const deter = b * b - 4 * a * cc;
    if (deter < 0) return null;
    if (deter === 0) return null;
    const e = Math.sqrt(deter);
    const u1 = (-b + e) / (2 * a);
    const u2 = (-b - e) / (2 * a);
    if ((u1 < 0 || u1 > 1) && (u2 < 0 || u2 > 1)) {
        return null;
    }
    const result = [];
    if (0 <= u1 && u1 <= 1) result.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Lrp(a1, a2, u1));
    if (0 <= u2 && u2 <= 1) result.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Lrp(a1, a2, u2));
    if (result.length === 0) return null;
    return result;
}
function intersectLineSegmentPolyline(a1, a2, points) {
    const result = [];
    let segmentIntersection;
    for(let i = 0, n = points.length - 1; i < n; i++){
        segmentIntersection = intersectLineSegmentLineSegment(a1, a2, points[i], points[i + 1]);
        if (segmentIntersection) result.push(segmentIntersection);
    }
    if (result.length === 0) return null;
    return result;
}
function intersectLineSegmentPolygon(a1, a2, points) {
    const result = [];
    let segmentIntersection;
    for(let i = 1, n = points.length; i < n + 1; i++){
        segmentIntersection = intersectLineSegmentLineSegment(a1, a2, points[i - 1], points[i % points.length]);
        if (segmentIntersection) result.push(segmentIntersection);
    }
    if (result.length === 0) return null;
    return result;
}
function intersectCircleCircle(c1, r1, c2, r2) {
    let dx = c2.x - c1.x;
    let dy = c2.y - c1.y;
    const d = Math.sqrt(dx * dx + dy * dy), x = (d * d - r2 * r2 + r1 * r1) / (2 * d), y = Math.sqrt(r1 * r1 - x * x);
    dx /= d;
    dy /= d;
    return [
        new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](c1.x + dx * x - dy * y, c1.y + dy * x + dx * y),
        new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](c1.x + dx * x + dy * y, c1.y + dy * x - dx * y)
    ];
}
function intersectCirclePolygon(c, r, points) {
    const result = [];
    let a, b, int;
    for(let i = 0, n = points.length; i < n; i++){
        a = points[i];
        b = points[(i + 1) % points.length];
        int = intersectLineSegmentCircle(a, b, c, r);
        if (int) result.push(...int);
    }
    if (result.length === 0) return null;
    return result;
}
function intersectCirclePolyline(c, r, points) {
    const result = [];
    let a, b, int;
    for(let i = 1, n = points.length; i < n; i++){
        a = points[i - 1];
        b = points[i];
        int = intersectLineSegmentCircle(a, b, c, r);
        if (int) result.push(...int);
    }
    if (result.length === 0) return null;
    return result;
}
function intersectPolygonBounds(points, bounds) {
    const result = [];
    let segmentIntersection;
    for (const side of bounds.sides){
        segmentIntersection = intersectLineSegmentPolygon(side[0], side[1], points);
        if (segmentIntersection) result.push(...segmentIntersection);
    }
    if (result.length === 0) return null;
    return result;
}
function ccw(A, B, C) {
    return (C.y - A.y) * (B.x - A.x) > (B.y - A.y) * (C.x - A.x);
}
function linesIntersect(A, B, C, D) {
    return ccw(A, C, D) !== ccw(B, C, D) && ccw(A, B, C) !== ccw(A, B, D);
}
function intersectPolygonPolygon(polygonA, polygonB) {
    const result = /* @__PURE__ */ new Map();
    let a, b, c, d;
    for(let i = 0, n = polygonA.length; i < n; i++){
        a = polygonA[i];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(a, polygonB)) {
            const id = getPointId(a);
            if (!result.has(id)) {
                result.set(id, a);
            }
        }
    }
    for(let i = 0, n = polygonB.length; i < n; i++){
        a = polygonB[i];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(a, polygonA)) {
            const id = getPointId(a);
            if (!result.has(id)) {
                result.set(id, a);
            }
        }
    }
    for(let i = 0, n = polygonA.length; i < n; i++){
        a = polygonA[i];
        b = polygonA[(i + 1) % polygonA.length];
        for(let j = 0, m = polygonB.length; j < m; j++){
            c = polygonB[j];
            d = polygonB[(j + 1) % polygonB.length];
            const intersection = intersectLineSegmentLineSegment(a, b, c, d);
            if (intersection !== null) {
                const id = getPointId(intersection);
                if (!result.has(id)) {
                    result.set(id, intersection);
                }
            }
        }
    }
    if (result.size === 0) return null;
    return orderClockwise([
        ...result.values()
    ]);
}
function intersectPolys(polyA, polyB, isAClosed, isBClosed) {
    const result = /* @__PURE__ */ new Map();
    for(let i = 0, n = isAClosed ? polyA.length : polyA.length - 1; i < n; i++){
        const currentA = polyA[i];
        const nextA = polyA[(i + 1) % polyA.length];
        for(let j = 0, m = isBClosed ? polyB.length : polyB.length - 1; j < m; j++){
            const currentB = polyB[j];
            const nextB = polyB[(j + 1) % polyB.length];
            const intersection = intersectLineSegmentLineSegment(currentA, nextA, currentB, nextB);
            if (intersection !== null) {
                const id = getPointId(intersection);
                if (!result.has(id)) {
                    result.set(id, intersection);
                }
            }
        }
    }
    return [
        ...result.values()
    ];
}
function getPointId(point) {
    return `${point.x},${point.y}`;
}
function orderClockwise(points) {
    const C = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Average(points);
    return points.sort((A, B)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(C, A) - __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(C, B));
}
function polygonsIntersect(a, b) {
    let a0, a1, b0, b1;
    for(let i = 0, n = a.length; i < n; i++){
        a0 = a[i];
        a1 = a[(i + 1) % n];
        for(let j = 0, m = b.length; j < m; j++){
            b0 = b[j];
            b1 = b[(j + 1) % m];
            if (linesIntersect(a0, a1, b0, b1)) return true;
        }
    }
    return false;
}
function polygonIntersectsPolyline(polygon, polyline) {
    let a, b, c, d;
    for(let i = 0, n = polygon.length; i < n; i++){
        a = polygon[i];
        b = polygon[(i + 1) % n];
        for(let j = 1, m = polyline.length; j < m; j++){
            c = polyline[j - 1];
            d = polyline[j];
            if (linesIntersect(a, b, c, d)) return true;
        }
    }
    return false;
}
;
 //# sourceMappingURL=intersect.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Geometry2d",
    ()=>Geometry2d,
    "Geometry2dFilters",
    ()=>Geometry2dFilters,
    "TransformedGeometry2d",
    ()=>TransformedGeometry2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const Geometry2dFilters = {
    EXCLUDE_NON_STANDARD: {
        includeLabels: false,
        includeInternal: false
    },
    INCLUDE_ALL: {
        includeLabels: true,
        includeInternal: true
    },
    EXCLUDE_LABELS: {
        includeLabels: false,
        includeInternal: true
    },
    EXCLUDE_INTERNAL: {
        includeLabels: true,
        includeInternal: false
    }
};
class Geometry2d {
    // todo: consider making accessors for these too, so that they can be overridden in subclasses by geometries with more complex logic
    isFilled = false;
    isClosed = true;
    isLabel = false;
    isEmptyLabel = false;
    isInternal = false;
    excludeFromShapeBounds = false;
    debugColor;
    ignore;
    constructor(opts){
        const { isLabel = false, isEmptyLabel = false, isInternal = false, excludeFromShapeBounds = false } = opts;
        this.isFilled = opts.isFilled;
        this.isClosed = opts.isClosed;
        this.debugColor = opts.debugColor;
        this.ignore = opts.ignore;
        this.isLabel = isLabel;
        this.isEmptyLabel = isEmptyLabel;
        this.isInternal = isInternal;
        this.excludeFromShapeBounds = excludeFromShapeBounds;
    }
    isExcludedByFilter(filters) {
        if (!filters) return false;
        if (this.isLabel && !filters.includeLabels) return true;
        if (this.isInternal && !filters.includeInternal) return true;
        return false;
    }
    hitTestPoint(point, margin = 0, hitInside = false, _filters) {
        if (this.isClosed && (this.isFilled || hitInside) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(point, this.vertices)) {
            return true;
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(point, this.nearestPoint(point)) <= margin * margin;
    }
    distanceToPoint(point, hitInside = false, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(point, this.nearestPoint(point, filters)) * (this.isClosed && (this.isFilled || hitInside) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(point, this.vertices) ? -1 : 1);
    }
    distanceToLineSegment(A, B, filters) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Equals(A, B)) return this.distanceToPoint(A, false, filters);
        const { vertices } = this;
        if (vertices.length === 0) throw Error("nearest point not found");
        if (vertices.length === 1) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(A, vertices[0]);
        let nearest;
        let dist = Infinity;
        let d, p, q;
        const nextLimit = this.isClosed ? vertices.length : vertices.length - 1;
        for(let i = 0; i < vertices.length; i++){
            p = vertices[i];
            if (i < nextLimit) {
                const next = vertices[(i + 1) % vertices.length];
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["linesIntersect"])(A, B, p, next)) return 0;
            }
            q = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].NearestPointOnLineSegment(A, B, p, true);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, q);
            if (d < dist) {
                dist = d;
                nearest = q;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        dist = Math.sqrt(dist);
        return this.isClosed && this.isFilled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(nearest, this.vertices) ? -dist : dist;
    }
    hitTestLineSegment(A, B, distance = 0, filters) {
        return this.distanceToLineSegment(A, B, filters) <= distance;
    }
    intersectLineSegment(A, B, _filters) {
        const intersections = this.isClosed ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentPolygon"])(A, B, this.vertices) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentPolyline"])(A, B, this.vertices);
        return intersections ?? [];
    }
    intersectCircle(center, radius, _filters) {
        const intersections = this.isClosed ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectCirclePolygon"])(center, radius, this.vertices) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectCirclePolyline"])(center, radius, this.vertices);
        return intersections ?? [];
    }
    intersectPolygon(polygon, _filters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectPolys"])(polygon, this.vertices, true, this.isClosed);
    }
    intersectPolyline(polyline, _filters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectPolys"])(polyline, this.vertices, false, this.isClosed);
    }
    /**
   * Find a point along the edge of the geometry that is a fraction `t` along the entire way round.
   */ interpolateAlongEdge(t, _filters) {
        const { vertices } = this;
        if (vertices.length === 0) return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
        if (vertices.length === 1) return vertices[0];
        if (t <= 0) return vertices[0];
        const distanceToTravel = t * this.length;
        let distanceTraveled = 0;
        for(let i = 0; i < (this.isClosed ? vertices.length : vertices.length - 1); i++){
            const curr = vertices[i];
            const next = vertices[(i + 1) % vertices.length];
            const dist = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(curr, next);
            const newDistanceTraveled = distanceTraveled + dist;
            if (newDistanceTraveled >= distanceToTravel) {
                const p = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Lrp(curr, next, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invLerp"])(distanceTraveled, newDistanceTraveled, distanceToTravel));
                return p;
            }
            distanceTraveled = newDistanceTraveled;
        }
        return this.isClosed ? vertices[0] : vertices[vertices.length - 1];
    }
    /**
   * Take `point`, find the closest point to it on the edge of the geometry, and return how far
   * along the edge it is as a fraction of the total length.
   */ uninterpolateAlongEdge(point, _filters) {
        const { vertices, length } = this;
        let closestSegment = null;
        let closestDistance = Infinity;
        let distanceTraveled = 0;
        if (vertices.length === 0 || vertices.length === 1) return 0;
        for(let i = 0; i < (this.isClosed ? vertices.length : vertices.length - 1); i++){
            const curr = vertices[i];
            const next = vertices[(i + 1) % vertices.length];
            const nearestPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].NearestPointOnLineSegment(curr, next, point, true);
            const distance = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(nearestPoint, point);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSegment = {
                    start: curr,
                    end: next,
                    nearestPoint,
                    distanceToStart: distanceTraveled
                };
            }
            distanceTraveled += __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(curr, next);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(closestSegment);
        const distanceAlongRoute = closestSegment.distanceToStart + __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(closestSegment.start, closestSegment.nearestPoint);
        return distanceAlongRoute / length;
    }
    isPointInBounds(point, margin = 0) {
        const { bounds } = this;
        return !(point.x < bounds.minX - margin || point.y < bounds.minY - margin || point.x > bounds.maxX + margin || point.y > bounds.maxY + margin);
    }
    overlapsPolygon(_polygon) {
        const polygon = _polygon.map((v)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(v));
        const { vertices, center, isFilled, isEmptyLabel, isClosed } = this;
        if (isEmptyLabel) return false;
        if (vertices.some((v)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(v, polygon))) {
            return true;
        }
        if (isClosed) {
            if (isFilled) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(center, polygon)) {
                    return true;
                }
                if (polygon.every((v)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(v, vertices))) {
                    return true;
                }
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polygonsIntersect"])(polygon, vertices)) {
                return true;
            }
        } else {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polygonIntersectsPolyline"])(polygon, vertices)) {
                return true;
            }
        }
        return false;
    }
    transform(transform, opts) {
        return new TransformedGeometry2d(this, transform, opts);
    }
    _vertices;
    // eslint-disable-next-line no-restricted-syntax
    get vertices() {
        if (!this._vertices) {
            this._vertices = this.getVertices(Geometry2dFilters.EXCLUDE_LABELS);
        }
        return this._vertices;
    }
    getBoundsVertices() {
        if (this.excludeFromShapeBounds) return [];
        return this.vertices;
    }
    _boundsVertices;
    // eslint-disable-next-line no-restricted-syntax
    get boundsVertices() {
        if (!this._boundsVertices) {
            this._boundsVertices = this.getBoundsVertices();
        }
        return this._boundsVertices;
    }
    getBounds() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(this.boundsVertices);
    }
    _bounds;
    // eslint-disable-next-line no-restricted-syntax
    get bounds() {
        if (!this._bounds) {
            this._bounds = this.getBounds();
        }
        return this._bounds;
    }
    // eslint-disable-next-line no-restricted-syntax
    get center() {
        return this.bounds.center;
    }
    _area;
    // eslint-disable-next-line no-restricted-syntax
    get area() {
        if (!this._area) {
            this._area = this.getArea();
        }
        return this._area;
    }
    getArea() {
        if (!this.isClosed) {
            return 0;
        }
        const { vertices } = this;
        let area = 0;
        for(let i = 0, n = vertices.length; i < n; i++){
            const curr = vertices[i];
            const next = vertices[(i + 1) % n];
            area += curr.x * next.y - next.x * curr.y;
        }
        return area / 2;
    }
    toSimpleSvgPath() {
        let path = "";
        const { vertices } = this;
        const n = vertices.length;
        if (n === 0) return path;
        path += `M${vertices[0].x},${vertices[0].y}`;
        for(let i = 1; i < n; i++){
            path += `L${vertices[i].x},${vertices[i].y}`;
        }
        if (this.isClosed) {
            path += "Z";
        }
        return path;
    }
    _length;
    // eslint-disable-next-line no-restricted-syntax
    get length() {
        if (this._length) return this._length;
        this._length = this.getLength(Geometry2dFilters.EXCLUDE_LABELS);
        return this._length;
    }
    getLength(_filters) {
        const vertices = this.getVertices(_filters ?? Geometry2dFilters.EXCLUDE_LABELS);
        if (vertices.length === 0) return 0;
        let prev = vertices[0];
        let length = 0;
        for(let i = 1; i < vertices.length; i++){
            const next = vertices[i];
            length += __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(prev, next);
            prev = next;
        }
        if (this.isClosed) {
            length += __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(vertices[vertices.length - 1], vertices[0]);
        }
        return length;
    }
}
class TransformedGeometry2d extends Geometry2d {
    constructor(geometry, matrix, opts){
        super(geometry);
        this.geometry = geometry;
        this.matrix = matrix;
        this.inverse = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Inverse(matrix);
        this.decomposed = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Decompose(matrix);
        if (opts) {
            if (opts.isLabel != null) this.isLabel = opts.isLabel;
            if (opts.isInternal != null) this.isInternal = opts.isInternal;
            if (opts.debugColor != null) this.debugColor = opts.debugColor;
            if (opts.ignore != null) this.ignore = opts.ignore;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(this.decomposed.scaleX, this.decomposed.scaleY), "non-uniform scaling is not yet supported");
    }
    inverse;
    decomposed;
    getVertices(filters) {
        return this.geometry.getVertices(filters).map((v)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.matrix, v));
    }
    getBoundsVertices() {
        return this.geometry.getBoundsVertices().map((v)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.matrix, v));
    }
    nearestPoint(point, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.matrix, this.geometry.nearestPoint(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, point), filters));
    }
    hitTestPoint(point, margin = 0, hitInside, filters) {
        return this.geometry.hitTestPoint(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, point), margin / this.decomposed.scaleX, hitInside, filters);
    }
    distanceToPoint(point, hitInside = false, filters) {
        return this.geometry.distanceToPoint(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, point), hitInside, filters) * this.decomposed.scaleX;
    }
    distanceToLineSegment(A, B, filters) {
        return this.geometry.distanceToLineSegment(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, A), __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, B), filters) * this.decomposed.scaleX;
    }
    hitTestLineSegment(A, B, distance = 0, filters) {
        return this.geometry.hitTestLineSegment(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, A), __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, B), distance / this.decomposed.scaleX, filters);
    }
    intersectLineSegment(A, B, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.matrix, this.geometry.intersectLineSegment(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, A), __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, B), filters));
    }
    intersectCircle(center, radius, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.matrix, this.geometry.intersectCircle(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.inverse, center), radius / this.decomposed.scaleX, filters));
    }
    intersectPolygon(polygon, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.matrix, this.geometry.intersectPolygon(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.inverse, polygon), filters));
    }
    intersectPolyline(polyline, filters) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.matrix, this.geometry.intersectPolyline(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(this.inverse, polyline), filters));
    }
    transform(transform, opts) {
        return new TransformedGeometry2d(this.geometry, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Multiply(transform, this.matrix), {
            isLabel: opts?.isLabel ?? this.isLabel,
            isInternal: opts?.isInternal ?? this.isInternal,
            debugColor: opts?.debugColor ?? this.debugColor,
            ignore: opts?.ignore ?? this.ignore
        });
    }
    getSvgPathData() {
        throw new Error("Cannot get SVG path data for transformed geometry.");
    }
}
;
 //# sourceMappingURL=Geometry2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Group2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Group2d",
    ()=>Group2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
;
;
;
class Group2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    children = [];
    ignoredChildren = [];
    constructor(config){
        super({
            ...config,
            isClosed: true,
            isFilled: false
        });
        const addChildren = (children)=>{
            for (const child of children){
                if (child instanceof Group2d) {
                    addChildren(child.children);
                } else if (child.ignore) {
                    this.ignoredChildren.push(child);
                } else {
                    this.children.push(child);
                }
            }
        };
        addChildren(config.children);
        if (this.children.length === 0) throw Error("Group2d must have at least one child");
    }
    getVertices(filters) {
        if (this.isExcludedByFilter(filters)) return [];
        return this.children.filter((c)=>!c.isExcludedByFilter(filters)).flatMap((c)=>c.getVertices(filters));
    }
    nearestPoint(point, filters) {
        let dist = Infinity;
        let nearest;
        const { children } = this;
        if (children.length === 0) {
            throw Error("no children");
        }
        let p;
        let d;
        for (const child of children){
            if (child.isExcludedByFilter(filters)) continue;
            p = child.nearestPoint(point, filters);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, point);
            if (d < dist) {
                dist = d;
                nearest = p;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    distanceToPoint(point, hitInside = false, filters) {
        let smallestDistance = Infinity;
        for (const child of this.children){
            if (child.isExcludedByFilter(filters)) continue;
            const distance = child.distanceToPoint(point, hitInside, filters);
            if (distance < smallestDistance) {
                smallestDistance = distance;
            }
        }
        return smallestDistance;
    }
    hitTestPoint(point, margin, hitInside, filters = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2dFilters"].EXCLUDE_LABELS) {
        return !!this.children.filter((c)=>!c.isExcludedByFilter(filters)).find((c)=>c.hitTestPoint(point, margin, hitInside));
    }
    hitTestLineSegment(A, B, zoom, filters = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2dFilters"].EXCLUDE_LABELS) {
        return !!this.children.filter((c)=>!c.isExcludedByFilter(filters)).find((c)=>c.hitTestLineSegment(A, B, zoom));
    }
    intersectLineSegment(A, B, filters) {
        return this.children.flatMap((child)=>{
            if (child.isExcludedByFilter(filters)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
            return child.intersectLineSegment(A, B, filters);
        });
    }
    intersectCircle(center, radius, filters) {
        return this.children.flatMap((child)=>{
            if (child.isExcludedByFilter(filters)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
            return child.intersectCircle(center, radius, filters);
        });
    }
    getBoundsVertices() {
        if (this.excludeFromShapeBounds) return [];
        return this.children.flatMap((child)=>child.getBoundsVertices());
    }
    intersectPolygon(polygon, filters) {
        return this.children.flatMap((child)=>{
            if (child.isExcludedByFilter(filters)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
            return child.intersectPolygon(polygon, filters);
        });
    }
    intersectPolyline(polyline, filters) {
        return this.children.flatMap((child)=>{
            if (child.isExcludedByFilter(filters)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
            return child.intersectPolyline(polyline, filters);
        });
    }
    interpolateAlongEdge(t, filters) {
        const totalLength = this.getLength(filters);
        const distanceToTravel = t * totalLength;
        let distanceTraveled = 0;
        for (const child of this.children){
            if (child.isExcludedByFilter(filters)) continue;
            const childLength = child.length;
            const newDistanceTraveled = distanceTraveled + childLength;
            if (newDistanceTraveled >= distanceToTravel) {
                return child.interpolateAlongEdge((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invLerp"])(distanceTraveled, newDistanceTraveled, distanceToTravel), filters);
            }
            distanceTraveled = newDistanceTraveled;
        }
        return this.children[this.children.length - 1].interpolateAlongEdge(1, filters);
    }
    uninterpolateAlongEdge(point, filters) {
        const totalLength = this.getLength(filters);
        let closestChild = null;
        let closestDistance = Infinity;
        let distanceTraveled = 0;
        for (const child of this.children){
            if (child.isExcludedByFilter(filters)) continue;
            const childLength = child.getLength(filters);
            const newDistanceTraveled = distanceTraveled + childLength;
            const distance = child.distanceToPoint(point, false, filters);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestChild = {
                    startLength: distanceTraveled,
                    endLength: newDistanceTraveled,
                    child
                };
            }
            distanceTraveled = newDistanceTraveled;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(closestChild);
        const normalizedDistanceInChild = closestChild.child.uninterpolateAlongEdge(point, filters);
        const childTLength = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(closestChild.startLength, closestChild.endLength, normalizedDistanceInChild);
        return childTLength / totalLength;
    }
    transform(transform) {
        return new Group2d({
            children: this.children.map((c)=>c.transform(transform)),
            isLabel: this.isLabel,
            debugColor: this.debugColor,
            ignore: this.ignore
        });
    }
    getArea() {
        return this.children[0].area;
    }
    toSimpleSvgPath() {
        let path = "";
        for (const child of this.children){
            path += child.toSimpleSvgPath();
        }
        const corners = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(this.boundsVertices).corners;
        for(let i = 0, n = corners.length; i < n; i++){
            const corner = corners[i];
            const prevCorner = corners[(i - 1 + n) % n];
            const prevDist = corner.dist(prevCorner);
            const nextCorner = corners[(i + 1) % n];
            const nextDist = corner.dist(nextCorner);
            const A = corner.clone().lrp(prevCorner, 4 / prevDist);
            const B = corner;
            const C = corner.clone().lrp(nextCorner, 4 / nextDist);
            path += `M${A.x},${A.y} L${B.x},${B.y} L${C.x},${C.y} `;
        }
        return path;
    }
    getLength(filters) {
        let length = 0;
        for (const child of this.children){
            if (child.isExcludedByFilter(filters)) continue;
            length += child.length;
        }
        return length;
    }
    getSvgPathData() {
        return this.children.map((c, i)=>c.isLabel ? "" : c.getSvgPathData(i === 0)).join(" ");
    }
    overlapsPolygon(polygon) {
        return this.children.some((child)=>child.overlapsPolygon(polygon));
    }
}
;
 //# sourceMappingURL=Group2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Edge2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Edge2d",
    ()=>Edge2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
class Edge2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    _start;
    _end;
    _d;
    _u;
    _ul;
    constructor(config){
        super({
            ...config,
            isClosed: false,
            isFilled: false
        });
        const { start, end } = config;
        this._start = start;
        this._end = end;
        this._d = start.clone().sub(end);
        this._u = this._d.clone().uni();
        this._ul = this._u.len();
    }
    getLength() {
        return this._d.len();
    }
    getVertices() {
        return [
            this._start,
            this._end
        ];
    }
    nearestPoint(point) {
        const { _start: start, _end: end, _d: d, _u: u, _ul: l } = this;
        if (d.len() === 0) return start;
        if (l === 0) return start;
        const k = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(point, start).dpr(u) / l;
        const cx = start.x + u.x * k;
        if (cx < Math.min(start.x, end.x)) return start.x < end.x ? start : end;
        if (cx > Math.max(start.x, end.x)) return start.x > end.x ? start : end;
        const cy = start.y + u.y * k;
        if (cy < Math.min(start.y, end.y)) return start.y < end.y ? start : end;
        if (cy > Math.max(start.y, end.y)) return start.y > end.y ? start : end;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx, cy);
    }
    getSvgPathData(first = true) {
        const { _start: start, _end: end } = this;
        return `${first ? `M${start.toFixed()}` : ``} L${end.toFixed()}`;
    }
}
;
 //# sourceMappingURL=Edge2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Polyline2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Polyline2d",
    ()=>Polyline2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Edge2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
;
class Polyline2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    _points;
    _segments;
    constructor(config){
        super({
            isClosed: false,
            isFilled: false,
            ...config
        });
        const { points } = config;
        this._points = points;
        if (points.length < 2) {
            throw new Error("Polyline2d: points must be an array of at least 2 points");
        }
    }
    // eslint-disable-next-line no-restricted-syntax
    get segments() {
        if (!this._segments) {
            this._segments = [];
            const { vertices } = this;
            for(let i = 0, n = vertices.length - 1; i < n; i++){
                const start = vertices[i];
                const end = vertices[i + 1];
                this._segments.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                    start,
                    end
                }));
            }
            if (this.isClosed) {
                this._segments.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                    start: vertices[vertices.length - 1],
                    end: vertices[0]
                }));
            }
        }
        return this._segments;
    }
    getLength() {
        return this.segments.reduce((acc, segment)=>acc + segment.length, 0);
    }
    getVertices() {
        return this._points;
    }
    nearestPoint(A) {
        const { segments } = this;
        let nearest = this._points[0];
        let dist = Infinity;
        let p;
        let d;
        for(let i = 0; i < segments.length; i++){
            p = segments[i].nearestPoint(A);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, A);
            if (d < dist) {
                nearest = p;
                dist = d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    hitTestLineSegment(A, B, distance = 0) {
        const { segments } = this;
        for(let i = 0, n = segments.length; i < n; i++){
            if (segments[i].hitTestLineSegment(A, B, distance)) {
                return true;
            }
        }
        return false;
    }
    getSvgPathData() {
        const { vertices } = this;
        if (vertices.length < 2) return "";
        return vertices.reduce((acc, vertex, i)=>{
            if (i === 0) return `M ${vertex.x} ${vertex.y}`;
            return `${acc} L ${vertex.x} ${vertex.y}`;
        }, "");
    }
}
;
 //# sourceMappingURL=Polyline2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Polygon2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Polygon2d",
    ()=>Polygon2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polyline2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Polyline2d.mjs [app-client] (ecmascript)");
;
class Polygon2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polyline2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polyline2d"] {
    constructor(config){
        super({
            ...config
        });
        this.isClosed = true;
        if (config.points.length < 3) {
            throw new Error("Polygon2d: points must be an array of at least 3 points");
        }
    }
}
;
 //# sourceMappingURL=Polygon2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Rectangle2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Rectangle2d",
    ()=>Rectangle2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polygon2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Polygon2d.mjs [app-client] (ecmascript)");
;
;
;
class Rectangle2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polygon2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polygon2d"] {
    _x;
    _y;
    _w;
    _h;
    constructor(config){
        const { x = 0, y = 0, width, height } = config;
        super({
            ...config,
            points: [
                new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x, y),
                new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x + width, y),
                new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x + width, y + height),
                new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x, y + height)
            ]
        });
        this._x = x;
        this._y = y;
        this._w = width;
        this._h = height;
    }
    getBounds() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](this._x, this._y, this._w, this._h);
    }
    getSvgPathData() {
        const { _x: x, _y: y, _w: w, _h: h } = this;
        this.negativeZeroFix();
        return `M${x},${y} h${w} v${h} h${-w}z`;
    }
    negativeZeroFix() {
        this._x = zeroFix(this._x);
        this._y = zeroFix(this._y);
        this._w = zeroFix(this._w);
        this._h = zeroFix(this._h);
    }
}
function zeroFix(value) {
    if (Object.is(value, -0)) return 0;
    return value;
}
;
 //# sourceMappingURL=Rectangle2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/geometry-constants.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVerticesCountForArcLength",
    ()=>getVerticesCountForArcLength
]);
const SPACING = 20;
const MIN_COUNT = 8;
function getVerticesCountForArcLength(length, spacing = SPACING) {
    return Math.max(MIN_COUNT, Math.ceil(length / spacing));
}
;
 //# sourceMappingURL=geometry-constants.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Arc2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Arc2d",
    ()=>Arc2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/geometry-constants.mjs [app-client] (ecmascript)");
;
;
;
;
;
class Arc2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    _center;
    _radius;
    _start;
    _end;
    _largeArcFlag;
    _sweepFlag;
    _measure;
    _angleStart;
    _angleEnd;
    constructor(config){
        super({
            ...config,
            isFilled: false,
            isClosed: false
        });
        const { center, sweepFlag, largeArcFlag, start, end } = config;
        if (start.equals(end)) throw Error(`Arc must have different start and end points.`);
        this._angleStart = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(center, start);
        this._angleEnd = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(center, end);
        this._radius = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(center, start);
        this._measure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArcMeasure"])(this._angleStart, this._angleEnd, sweepFlag, largeArcFlag);
        this._start = start;
        this._end = end;
        this._sweepFlag = sweepFlag;
        this._largeArcFlag = largeArcFlag;
        this._center = center;
    }
    nearestPoint(point) {
        const { _center, _measure: measure, _radius: radius, _angleEnd: angleEnd, _angleStart: angleStart, _start: A, _end: B } = this;
        const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPointInArcT"])(measure, angleStart, angleEnd, _center.angle(point));
        if (t <= 0) return A;
        if (t >= 1) return B;
        const P = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(point, _center).uni().mul(radius).add(_center);
        let nearest;
        let dist = Infinity;
        let d;
        for (const p of [
            A,
            B,
            P
        ]){
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(point, p);
            if (d < dist) {
                nearest = p;
                dist = d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    hitTestLineSegment(A, B) {
        const { _center, _radius: radius, _measure: measure, _angleStart: angleStart, _angleEnd: angleEnd } = this;
        const intersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentCircle"])(A, B, _center, radius);
        if (intersection === null) return false;
        return intersection.some((p)=>{
            const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPointInArcT"])(measure, angleStart, angleEnd, _center.angle(p));
            return result >= 0 && result <= 1;
        });
    }
    getVertices() {
        const { _center, _measure: measure, length, _radius: radius, _angleStart: angleStart } = this;
        const vertices = [];
        for(let i = 0, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVerticesCountForArcLength"])(Math.abs(length)); i < n + 1; i++){
            const t = i / n * measure;
            const angle = angleStart + t;
            vertices.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPointOnCircle"])(_center, radius, angle));
        }
        return vertices;
    }
    getSvgPathData(first = true) {
        const { _start: start, _end: end, _radius: radius, _largeArcFlag: largeArcFlag, _sweepFlag: sweepFlag } = this;
        return `${first ? `M${start.toFixed()}` : ``} A${radius} ${radius} 0 ${largeArcFlag} ${sweepFlag} ${end.toFixed()}`;
    }
    getLength() {
        return Math.abs(this._measure * this._radius);
    }
}
;
 //# sourceMappingURL=Arc2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Circle2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Circle2d",
    ()=>Circle2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/geometry-constants.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
class Circle2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    constructor(config){
        super({
            isClosed: true,
            ...config
        });
        this.config = config;
        const { x = 0, y = 0, radius } = config;
        this._x = x;
        this._y = y;
        this._center = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](radius + x, radius + y);
        this._radius = radius;
    }
    _center;
    _radius;
    _x;
    _y;
    getBounds() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](this._x, this._y, this._radius * 2, this._radius * 2);
    }
    getVertices() {
        const { _center, _radius: radius } = this;
        const perimeter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI2"] * radius;
        const vertices = [];
        for(let i = 0, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVerticesCountForArcLength"])(perimeter); i < n; i++){
            const angle = i / n * __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI2"];
            vertices.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPointOnCircle"])(_center, radius, angle));
        }
        return vertices;
    }
    nearestPoint(point) {
        const { _center, _radius: radius } = this;
        if (_center.equals(point)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].AddXY(_center, radius, 0);
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(point, _center).uni().mul(radius).add(_center);
    }
    hitTestLineSegment(A, B, distance = 0) {
        const { _center, _radius: radius } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentCircle"])(A, B, _center, radius + distance) !== null;
    }
    getSvgPathData() {
        const { _center, _radius: radius } = this;
        return `M${_center.x + radius},${_center.y} a${radius},${radius} 0 1,0 ${radius * 2},0a${radius},${radius} 0 1,0 -${radius * 2},0`;
    }
}
;
 //# sourceMappingURL=Circle2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/CubicBezier2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CubicBezier2d",
    ()=>CubicBezier2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polyline2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Polyline2d.mjs [app-client] (ecmascript)");
;
;
class CubicBezier2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Polyline2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polyline2d"] {
    _a;
    _b;
    _c;
    _d;
    _resolution;
    constructor(config){
        const { start: a, cp1: b, cp2: c, end: d } = config;
        super({
            ...config,
            points: [
                a,
                d
            ]
        });
        this._a = a;
        this._b = b;
        this._c = c;
        this._d = d;
        this._resolution = config.resolution ?? 10;
    }
    getVertices() {
        const vertices = [];
        const { _a: a, _b: b, _c: c, _d: d } = this;
        for(let i = 0, n = this._resolution; i <= n; i++){
            const t = i / n;
            vertices.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((1 - t) * (1 - t) * (1 - t) * a.x + 3 * ((1 - t) * (1 - t)) * t * b.x + 3 * (1 - t) * (t * t) * c.x + t * t * t * d.x, (1 - t) * (1 - t) * (1 - t) * a.y + 3 * ((1 - t) * (1 - t)) * t * b.y + 3 * (1 - t) * (t * t) * c.y + t * t * t * d.y));
        }
        return vertices;
    }
    nearestPoint(A) {
        let nearest;
        let dist = Infinity;
        let d;
        let p;
        for (const edge of this.segments){
            p = edge.nearestPoint(A);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, A);
            if (d < dist) {
                nearest = p;
                dist = d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    getSvgPathData(first = true) {
        const { _a: a, _b: b, _c: c, _d: d } = this;
        return `${first ? `M ${a.toFixed()} ` : ``} C${b.toFixed()} ${c.toFixed()} ${d.toFixed()}`;
    }
    static GetAtT(segment, t) {
        const { _a: a, _b: b, _c: c, _d: d } = segment;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((1 - t) * (1 - t) * (1 - t) * a.x + 3 * ((1 - t) * (1 - t)) * t * b.x + 3 * (1 - t) * (t * t) * c.x + t * t * t * d.x, (1 - t) * (1 - t) * (1 - t) * a.y + 3 * ((1 - t) * (1 - t)) * t * b.y + 3 * (1 - t) * (t * t) * c.y + t * t * t * d.y);
    }
    getLength(_filters, precision = 32) {
        let n1, p1 = this._a, length = 0;
        for(let i = 1; i <= precision; i++){
            n1 = CubicBezier2d.GetAtT(this, i / precision);
            length += __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(p1, n1);
            p1 = n1;
        }
        return length;
    }
}
;
 //# sourceMappingURL=CubicBezier2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/CubicSpline2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CubicSpline2d",
    ()=>CubicSpline2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$CubicBezier2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/CubicBezier2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
;
class CubicSpline2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    _points;
    constructor(config){
        super({
            ...config,
            isClosed: false,
            isFilled: false
        });
        const { points } = config;
        this._points = points;
    }
    _segments;
    // eslint-disable-next-line no-restricted-syntax
    get segments() {
        if (!this._segments) {
            this._segments = [];
            const { _points: points } = this;
            const len = points.length;
            const last = len - 2;
            const k = 1.25;
            for(let i = 0; i < len - 1; i++){
                const p0 = i === 0 ? points[0] : points[i - 1];
                const p1 = points[i];
                const p2 = points[i + 1];
                const p3 = i === last ? p2 : points[i + 2];
                const start = p1, cp1 = i === 0 ? p0 : new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](p1.x + (p2.x - p0.x) / 6 * k, p1.y + (p2.y - p0.y) / 6 * k), cp2 = i === last ? p2 : new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](p2.x - (p3.x - p1.x) / 6 * k, p2.y - (p3.y - p1.y) / 6 * k), end = p2;
                this._segments.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$CubicBezier2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CubicBezier2d"]({
                    start,
                    cp1,
                    cp2,
                    end
                }));
            }
        }
        return this._segments;
    }
    getLength() {
        return this.segments.reduce((acc, segment)=>acc + segment.length, 0);
    }
    getVertices() {
        const vertices = this.segments.reduce((acc, segment)=>{
            return acc.concat(segment.vertices);
        }, []);
        vertices.push(this._points[this._points.length - 1]);
        return vertices;
    }
    nearestPoint(A) {
        let nearest;
        let dist = Infinity;
        let d;
        let p;
        for (const segment of this.segments){
            p = segment.nearestPoint(A);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, A);
            if (d < dist) {
                nearest = p;
                dist = d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    hitTestLineSegment(A, B) {
        return this.segments.some((segment)=>segment.hitTestLineSegment(A, B));
    }
    getSvgPathData() {
        let d = this.segments.reduce((d2, segment, i)=>{
            return d2 + segment.getSvgPathData(i === 0);
        }, "");
        if (this.isClosed) {
            d += "Z";
        }
        return d;
    }
}
;
 //# sourceMappingURL=CubicSpline2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Ellipse2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Ellipse2d",
    ()=>Ellipse2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Edge2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/geometry-constants.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
class Ellipse2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    constructor(config){
        super({
            ...config,
            isClosed: true
        });
        this.config = config;
        const { width, height } = config;
        this._w = width;
        this._h = height;
    }
    _w;
    _h;
    _edges;
    // eslint-disable-next-line no-restricted-syntax
    get edges() {
        if (!this._edges) {
            const { vertices } = this;
            this._edges = [];
            for(let i = 0, n = vertices.length; i < n; i++){
                const start = vertices[i];
                const end = vertices[(i + 1) % n];
                this._edges.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                    start,
                    end
                }));
            }
        }
        return this._edges;
    }
    getVertices() {
        const w = Math.max(1, this._w);
        const h = Math.max(1, this._h);
        const cx = w / 2;
        const cy = h / 2;
        const q = Math.pow(cx - cy, 2) / Math.pow(cx + cy, 2);
        const p = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] * (cx + cy) * (1 + 3 * q / (10 + Math.sqrt(4 - 3 * q)));
        const len = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$geometry$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVerticesCountForArcLength"])(p);
        const step = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI2"] / len;
        const a = Math.cos(step);
        const b = Math.sin(step);
        let sin = 0;
        let cos = 1;
        let ts = 0;
        let tc = 1;
        const vertices = Array(len);
        for(let i = 0; i < len; i++){
            vertices[i] = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(cx + cx * cos, 0, w), (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(cy + cy * sin, 0, h));
            ts = b * cos + a * sin;
            tc = a * cos - b * sin;
            sin = ts;
            cos = tc;
        }
        return vertices;
    }
    nearestPoint(A) {
        let nearest;
        let dist = Infinity;
        let d;
        let p;
        for (const edge of this.edges){
            p = edge.nearestPoint(A);
            d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, A);
            if (d < dist) {
                nearest = p;
                dist = d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    hitTestLineSegment(A, B) {
        return this.edges.some((edge)=>edge.hitTestLineSegment(A, B));
    }
    getBounds() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](0, 0, this._w, this._h);
    }
    getLength() {
        const { _w: w, _h: h } = this;
        const cx = w / 2;
        const cy = h / 2;
        const rx = Math.max(0, cx);
        const ry = Math.max(0, cy);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["perimeterOfEllipse"])(rx, ry);
    }
    getSvgPathData(first = false) {
        const { _w: w, _h: h } = this;
        const cx = w / 2;
        const cy = h / 2;
        const rx = Math.max(0, cx);
        const ry = Math.max(0, cy);
        return `${first ? `M${cx - rx},${cy}` : ``} a${rx},${ry},0,1,1,${rx * 2},0a${rx},${ry},0,1,1,-${rx * 2},0`;
    }
}
;
 //# sourceMappingURL=Ellipse2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Point2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Point2d",
    ()=>Point2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
class Point2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    _point;
    constructor(config){
        super({
            ...config,
            isClosed: true,
            isFilled: true
        });
        const { point } = config;
        this._point = point;
    }
    getVertices() {
        return [
            this._point
        ];
    }
    nearestPoint() {
        return this._point;
    }
    hitTestLineSegment(A, B, margin) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].DistanceToLineSegment(A, B, this._point) < margin;
    }
    getSvgPathData() {
        const { _point: point } = this;
        return `M${point.toFixed()}`;
    }
}
;
 //# sourceMappingURL=Point2d.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Stadium2d.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stadium2d",
    ()=>Stadium2d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Arc2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Arc2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Edge2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Geometry2d.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
class Stadium2d extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Geometry2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Geometry2d"] {
    constructor(config){
        super({
            ...config,
            isClosed: true
        });
        this.config = config;
        const { width: w, height: h } = config;
        this._w = w;
        this._h = h;
        if (h > w) {
            const r = w / 2;
            this._a = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Arc2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arc2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, r),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w, r),
                center: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w / 2, r),
                sweepFlag: 1,
                largeArcFlag: 1
            });
            this._b = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w, r),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w, h - r)
            });
            this._c = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Arc2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arc2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w, h - r),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, h - r),
                center: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w / 2, h - r),
                sweepFlag: 1,
                largeArcFlag: 1
            });
            this._d = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, h - r),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, r)
            });
        } else {
            const r = h / 2;
            this._a = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Arc2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arc2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](r, h),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](r, 0),
                center: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](r, r),
                sweepFlag: 1,
                largeArcFlag: 1
            });
            this._b = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](r, 0),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w - r, 0)
            });
            this._c = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Arc2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arc2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w - r, 0),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w - r, h),
                center: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w - r, r),
                sweepFlag: 1,
                largeArcFlag: 1
            });
            this._d = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Edge2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Edge2d"]({
                start: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w - r, h),
                end: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](r, h)
            });
        }
    }
    _w;
    _h;
    _a;
    _b;
    _c;
    _d;
    nearestPoint(A) {
        let nearest;
        let dist = Infinity;
        let _d;
        let p;
        const { _a: a, _b: b, _c: c, _d: d } = this;
        for (const part of [
            a,
            b,
            c,
            d
        ]){
            p = part.nearestPoint(A);
            _d = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(p, A);
            if (_d < dist) {
                nearest = p;
                dist = _d;
            }
        }
        if (!nearest) throw Error("nearest point not found");
        return nearest;
    }
    hitTestLineSegment(A, B) {
        const { _a: a, _b: b, _c: c, _d: d } = this;
        return [
            a,
            b,
            c,
            d
        ].some((edge)=>edge.hitTestLineSegment(A, B));
    }
    getVertices() {
        const { _a: a, _b: b, _c: c, _d: d } = this;
        return [
            a,
            b,
            c,
            d
        ].reduce((a2, p)=>{
            a2.push(...p.vertices);
            return a2;
        }, []);
    }
    getBounds() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](0, 0, this._w, this._h);
    }
    getLength() {
        const { _h: h, _w: w } = this;
        if (h > w) return (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] * (w / 2) + (h - w)) * 2;
        else return (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] * (h / 2) + (w - h)) * 2;
    }
    getSvgPathData() {
        const { _a: a, _b: b, _c: c, _d: d } = this;
        return [
            a,
            b,
            c,
            d
        ].map((p, i)=>p.getSvgPathData(i === 0)).join(" ") + " Z";
    }
}
;
 //# sourceMappingURL=Stadium2d.mjs.map
}),
]);

//# debugId=ae077a18-a269-f53e-e469-423950358f24
//# sourceMappingURL=c427b_%40tldraw_editor_dist-esm_lib_primitives_cfe6c1c6._.js.map