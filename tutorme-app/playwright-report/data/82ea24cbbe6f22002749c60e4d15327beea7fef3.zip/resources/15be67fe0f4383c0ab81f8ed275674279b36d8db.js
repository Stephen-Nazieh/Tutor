;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="8b844292-c90b-1a6c-7561-aa965ae6c5fc")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/a11y.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "A11yContext",
    ()=>A11yContext,
    "TldrawUiA11yProvider",
    ()=>TldrawUiA11yProvider,
    "useA11y",
    ()=>useA11y
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
const A11yContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function TldrawUiA11yProvider({ children }) {
    const currentMsg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])("a11y", {
        msg: "",
        priority: "assertive"
    });
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(A11yContext);
    const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawUiA11yProvider.useMemo[current]": ()=>({
                currentMsg,
                announce (msg) {
                    if (!msg) return;
                    currentMsg.set(msg);
                }
            })
    }["TldrawUiA11yProvider.useMemo[current]"], [
        currentMsg
    ]);
    if (ctx) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children
        });
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(A11yContext.Provider, {
        value: current,
        children
    });
}
function useA11y() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(A11yContext);
    if (!ctx) {
        throw new Error("useA11y must be used within a A11yContext.Provider");
    }
    return ctx;
}
;
 //# sourceMappingURL=a11y.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/asset-urls.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AssetUrlsProvider",
    ()=>AssetUrlsProvider,
    "useAssetUrls",
    ()=>useAssetUrls
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
const AssetUrlsContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function AssetUrlsProvider({ assetUrls, children }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AssetUrlsProvider.useEffect": ()=>{
            for (const src of Object.values(assetUrls.icons)){
                if (!src) continue;
                const image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"])();
                image.crossOrigin = "anonymous";
                image.src = src;
                image.decode();
            }
            for (const src of Object.values(assetUrls.embedIcons)){
                if (!src) continue;
                const image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"])();
                image.crossOrigin = "anonymous";
                image.src = src;
                image.decode();
            }
        }
    }["AssetUrlsProvider.useEffect"], [
        assetUrls
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(AssetUrlsContext.Provider, {
        value: assetUrls,
        children
    });
}
function useAssetUrls() {
    const assetUrls = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AssetUrlsContext);
    if (!assetUrls) {
        throw new Error("useAssetUrls must be used within an AssetUrlsProvider");
    }
    return assetUrls;
}
;
 //# sourceMappingURL=asset-urls.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/breakpoints.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BreakPointProvider",
    ()=>BreakPointProvider,
    "useBreakpoint",
    ()=>useBreakpoint
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/constants.mjs [app-client] (ecmascript)");
;
;
;
;
const BreakpointContext = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
function BreakPointProvider({ forceMobile = false, children }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const breakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("breakpoint", {
        "BreakPointProvider.useValue[breakpoint]": ()=>{
            const { width } = editor?.getViewportScreenBounds() ?? {
                width: window.innerWidth
            };
            const maxBreakpoint = forceMobile ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PORTRAIT_BREAKPOINT"].MOBILE_SM : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PORTRAIT_BREAKPOINTS"].length - 1;
            for(let i = 0; i < maxBreakpoint; i++){
                if (width > __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PORTRAIT_BREAKPOINTS"][i] && width <= __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PORTRAIT_BREAKPOINTS"][i + 1]) {
                    return i;
                }
            }
            return maxBreakpoint;
        }
    }["BreakPointProvider.useValue[breakpoint]"], [
        editor
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BreakpointContext.Provider, {
        value: breakpoint,
        children
    });
}
function useBreakpoint() {
    const breakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(BreakpointContext);
    if (breakpoint === null) {
        throw new Error("useBreakpoint must be used inside of the <BreakpointProvider /> component");
    }
    return breakpoint;
}
;
 //# sourceMappingURL=breakpoints.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventsContext",
    ()=>EventsContext,
    "TldrawUiEventsProvider",
    ()=>TldrawUiEventsProvider,
    "useUiEvents",
    ()=>useUiEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const defaultEventHandler = ()=>void 0;
const EventsContext = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function TldrawUiEventsProvider({ onEvent, children }) {
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(EventsContext.Provider, {
        value: onEvent ?? defaultEventHandler,
        children
    });
}
function useUiEvents() {
    const eventHandler = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](EventsContext);
    return eventHandler ?? defaultEventHandler;
}
;
 //# sourceMappingURL=events.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/dialogs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogsContext",
    ()=>DialogsContext,
    "TldrawUiDialogsProvider",
    ()=>TldrawUiDialogsProvider,
    "useDialogs",
    ()=>useDialogs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/menus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
;
;
;
;
const DialogsContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function TldrawUiDialogsProvider({ context, children }) {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DialogsContext);
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const dialogs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])("dialogs", []);
    const content = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawUiDialogsProvider.useMemo[content]": ()=>{
            return {
                dialogs,
                addDialog (dialog) {
                    const id = dialog.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
                    dialogs.update({
                        "TldrawUiDialogsProvider.useMemo[content]": (d)=>{
                            return [
                                ...d.filter({
                                    "TldrawUiDialogsProvider.useMemo[content]": (m)=>m.id !== dialog.id
                                }["TldrawUiDialogsProvider.useMemo[content]"]),
                                {
                                    ...dialog,
                                    id
                                }
                            ];
                        }
                    }["TldrawUiDialogsProvider.useMemo[content]"]);
                    trackEvent("open-menu", {
                        source: "dialog",
                        id
                    });
                    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlmenus"].addOpenMenu(id, context);
                    return id;
                },
                removeDialog (id) {
                    const dialog = dialogs.get().find({
                        "TldrawUiDialogsProvider.useMemo[content].dialog": (d)=>d.id === id
                    }["TldrawUiDialogsProvider.useMemo[content].dialog"]);
                    if (dialog) {
                        dialog.onClose?.();
                        trackEvent("close-menu", {
                            source: "dialog",
                            id
                        });
                        __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlmenus"].deleteOpenMenu(id, context);
                        dialogs.update({
                            "TldrawUiDialogsProvider.useMemo[content]": (d)=>d.filter({
                                    "TldrawUiDialogsProvider.useMemo[content]": (m)=>m !== dialog
                                }["TldrawUiDialogsProvider.useMemo[content]"])
                        }["TldrawUiDialogsProvider.useMemo[content]"]);
                    }
                    return id;
                },
                clearDialogs () {
                    const current = dialogs.get();
                    if (current.length === 0) return;
                    current.forEach({
                        "TldrawUiDialogsProvider.useMemo[content]": (d)=>{
                            d.onClose?.();
                            trackEvent("close-menu", {
                                source: "dialog",
                                id: d.id
                            });
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlmenus"].deleteOpenMenu(d.id, context);
                        }
                    }["TldrawUiDialogsProvider.useMemo[content]"]);
                    dialogs.set([]);
                }
            };
        }
    }["TldrawUiDialogsProvider.useMemo[content]"], [
        trackEvent,
        dialogs,
        context
    ]);
    if (ctx) return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogsContext.Provider, {
        value: content,
        children
    });
}
function useDialogs() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DialogsContext);
    if (!ctx) {
        throw new Error("useDialogs must be used within a DialogsProvider");
    }
    return ctx;
}
;
 //# sourceMappingURL=dialogs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawUiToastsProvider",
    ()=>TldrawUiToastsProvider,
    "ToastsContext",
    ()=>ToastsContext,
    "useToasts",
    ()=>useToasts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Toast$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-toast/dist/index.mjs [app-client] (ecmascript) <export * as Toast>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
const ToastsContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function TldrawUiToastsProvider({ children }) {
    const toasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])("toasts", []);
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastsContext);
    const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawUiToastsProvider.useMemo[current]": ()=>{
            return {
                toasts,
                addToast (toast) {
                    const id = toast.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
                    toasts.update({
                        "TldrawUiToastsProvider.useMemo[current]": (d)=>[
                                ...d.filter({
                                    "TldrawUiToastsProvider.useMemo[current]": (m)=>m.id !== toast.id
                                }["TldrawUiToastsProvider.useMemo[current]"]),
                                {
                                    ...toast,
                                    id
                                }
                            ]
                    }["TldrawUiToastsProvider.useMemo[current]"]);
                    return id;
                },
                removeToast (id) {
                    toasts.update({
                        "TldrawUiToastsProvider.useMemo[current]": (d)=>d.filter({
                                "TldrawUiToastsProvider.useMemo[current]": (m)=>m.id !== id
                            }["TldrawUiToastsProvider.useMemo[current]"])
                    }["TldrawUiToastsProvider.useMemo[current]"]);
                    return id;
                },
                clearToasts () {
                    toasts.set([]);
                }
            };
        }
    }["TldrawUiToastsProvider.useMemo[current]"], [
        toasts
    ]);
    if (ctx) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children
        });
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Toast$3e$__["Toast"].Provider, {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ToastsContext.Provider, {
            value: current,
            children
        })
    });
}
function useToasts() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastsContext);
    if (!ctx) {
        throw new Error("useToasts must be used within a ToastsProvider");
    }
    return ctx;
}
;
 //# sourceMappingURL=toasts.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/components.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawUiComponentsProvider",
    ()=>TldrawUiComponentsProvider,
    "useTldrawUiComponents",
    ()=>useTldrawUiComponents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useIdentity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$A11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/A11y.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ActionsMenu$2f$DefaultActionsMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/ActionsMenu/DefaultActionsMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ContextMenu$2f$DefaultContextMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/ContextMenu/DefaultContextMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$CursorChatBubble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/CursorChatBubble.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DebugMenu$2f$DefaultDebugMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/DebugMenu/DefaultDebugMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultDebugPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/DefaultDebugPanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultFollowingIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/DefaultFollowingIndicator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultMenuPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/DefaultMenuPanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Dialogs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Dialogs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$HelperButtons$2f$DefaultHelperButtons$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/HelperButtons/DefaultHelperButtons.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$KeyboardShortcutsDialog$2f$DefaultKeyboardShortcutsDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/KeyboardShortcutsDialog/DefaultKeyboardShortcutsDialog.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$MainMenu$2f$DefaultMainMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/MainMenu/DefaultMainMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Minimap$2f$DefaultMinimap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Minimap/DefaultMinimap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$NavigationPanel$2f$DefaultNavigationPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/NavigationPanel/DefaultNavigationPanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$PageMenu$2f$DefaultPageMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/PageMenu/DefaultPageMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$QuickActions$2f$DefaultQuickActions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/QuickActions/DefaultQuickActions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$SharePanel$2f$DefaultSharePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/SharePanel/DefaultSharePanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$StylePanel$2f$DefaultStylePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/StylePanel/DefaultStylePanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Toasts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultImageToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Toolbar/DefaultImageToolbar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultRichTextToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Toolbar/DefaultRichTextToolbar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Toolbar/DefaultToolbar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultVideoToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Toolbar/DefaultVideoToolbar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ZoomMenu$2f$DefaultZoomMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/ZoomMenu/DefaultZoomMenu.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useCollaborationStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useCollaborationStatus.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const TldrawUiComponentsContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function TldrawUiComponentsProvider({ overrides = {}, children }) {
    const _overrides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowObjectIdentity"])(overrides);
    const showCollaborationUi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useCollaborationStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShowCollaborationUi"])();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawUiComponentsContext.Provider, {
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
            "TldrawUiComponentsProvider.useMemo": ()=>({
                    ContextMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ContextMenu$2f$DefaultContextMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultContextMenu"],
                    ActionsMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ActionsMenu$2f$DefaultActionsMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultActionsMenu"],
                    HelpMenu: null,
                    ZoomMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$ZoomMenu$2f$DefaultZoomMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultZoomMenu"],
                    MainMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$MainMenu$2f$DefaultMainMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultMainMenu"],
                    Minimap: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Minimap$2f$DefaultMinimap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultMinimap"],
                    StylePanel: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$StylePanel$2f$DefaultStylePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultStylePanel"],
                    PageMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$PageMenu$2f$DefaultPageMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultPageMenu"],
                    NavigationPanel: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$NavigationPanel$2f$DefaultNavigationPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultNavigationPanel"],
                    Toolbar: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultToolbar"],
                    RichTextToolbar: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultRichTextToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRichTextToolbar"],
                    ImageToolbar: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultImageToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultImageToolbar"],
                    VideoToolbar: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toolbar$2f$DefaultVideoToolbar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultVideoToolbar"],
                    KeyboardShortcutsDialog: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$KeyboardShortcutsDialog$2f$DefaultKeyboardShortcutsDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultKeyboardShortcutsDialog"],
                    QuickActions: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$QuickActions$2f$DefaultQuickActions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultQuickActions"],
                    HelperButtons: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$HelperButtons$2f$DefaultHelperButtons$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultHelperButtons"],
                    DebugPanel: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultDebugPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDebugPanel"],
                    DebugMenu: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DebugMenu$2f$DefaultDebugMenu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDebugMenu"],
                    MenuPanel: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultMenuPanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultMenuPanel"],
                    SharePanel: showCollaborationUi ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$SharePanel$2f$DefaultSharePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSharePanel"] : null,
                    CursorChatBubble: showCollaborationUi ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$CursorChatBubble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CursorChatBubble"] : null,
                    TopPanel: null,
                    Dialogs: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Dialogs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDialogs"],
                    Toasts: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultToasts"],
                    A11y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$A11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultA11yAnnouncer"],
                    FollowingIndicator: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$DefaultFollowingIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFollowingIndicator"],
                    ..._overrides
                })
        }["TldrawUiComponentsProvider.useMemo"], [
            _overrides,
            showCollaborationUi
        ]),
        children
    });
}
function useTldrawUiComponents() {
    const components = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TldrawUiComponentsContext);
    if (!components) {
        throw new Error("useTldrawUiComponents must be used within a TldrawUiComponentsProvider");
    }
    return components;
}
;
 //# sourceMappingURL=components.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/actions.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionsContext",
    ()=>ActionsContext,
    "ActionsProvider",
    ()=>ActionsProvider,
    "supportsDownloadingOriginal",
    ()=>supportsDownloadingOriginal,
    "unwrapLabel",
    ()=>unwrapLabel,
    "useActions",
    ()=>useActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$window$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/window-open.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$bookmarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/bookmark/bookmarks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$frames$2f$frames$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/frames/frames.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$A11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/A11y.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EditLinkDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/EditLinkDialog.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EmbedDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/EmbedDialog.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$KeyboardShortcutsDialog$2f$DefaultKeyboardShortcutsDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/KeyboardShortcutsDialog/DefaultKeyboardShortcutsDialog.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useCollaborationStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useCollaborationStatus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useFlatten$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useFlatten.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/overrides.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/a11y.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/components.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ActionsContext = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function supportsDownloadingOriginal(shape, editor) {
    return (editor.isShapeOfType(shape, "image") || editor.isShapeOfType(shape, "video")) && !!shape.props.assetId;
}
function makeActions(actions) {
    return Object.fromEntries(actions.map((action)=>[
            action.id,
            action
        ]));
}
function getExportName(editor, defaultName) {
    const selectedShapes = editor.getSelectedShapes();
    if (selectedShapes.length === 0) {
        return editor.getDocumentSettings().name || defaultName;
    }
    return void 0;
}
function ActionsProvider({ overrides, children }) {
    const _editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const showCollaborationUi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useCollaborationStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShowCollaborationUi"])();
    const helpers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultHelpers"])();
    const components = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTldrawUiComponents"])();
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const a11y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useA11y"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const defaultDocumentName = helpers.msg("document.default-name");
    const actions = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "ActionsProvider.useMemo[actions]": ()=>{
            const editor = _editor;
            if (!editor) return {};
            function mustGoBackToSelectToolFirst() {
                if (!editor.isIn("select")) {
                    editor.complete();
                    editor.setCurrentTool("select");
                    return false;
                }
                return false;
            }
            function canApplySelectionAction() {
                return editor.isIn("select") && editor.getSelectedShapeIds().length > 0;
            }
            function scaleShapes(scaleFactor) {
                if (!canApplySelectionAction()) return;
                if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                ;
                editor.markHistoryStoppingPoint("resize shapes");
                const selectedShapeIds = editor.getSelectedShapeIds();
                if (selectedShapeIds.length === 0) return;
                editor.run({
                    "ActionsProvider.useMemo[actions].scaleShapes": ()=>{
                        const shapes = selectedShapeIds.map({
                            "ActionsProvider.useMemo[actions].scaleShapes.shapes": (id)=>editor.getShape(id)
                        }["ActionsProvider.useMemo[actions].scaleShapes.shapes"]).filter(Boolean);
                        shapes.forEach({
                            "ActionsProvider.useMemo[actions].scaleShapes": (shape)=>{
                                editor.resizeShape(shape.id, new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](scaleFactor, scaleFactor), {
                                    scaleOrigin: editor.getSelectionPageBounds()?.center
                                });
                            }
                        }["ActionsProvider.useMemo[actions].scaleShapes"]);
                    }
                }["ActionsProvider.useMemo[actions].scaleShapes"]);
            }
            const actionItems = [
                {
                    id: "edit-link",
                    label: "action.edit-link",
                    icon: "link",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("edit-link", {
                            source
                        });
                        editor.markHistoryStoppingPoint("edit-link");
                        helpers.addDialog({
                            component: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EditLinkDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditLinkDialog"]
                        });
                    }
                },
                {
                    id: "insert-embed",
                    label: "action.insert-embed",
                    kbd: "cmd+i,ctrl+i",
                    onSelect (source) {
                        trackEvent("insert-embed", {
                            source
                        });
                        helpers.addDialog({
                            component: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EmbedDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmbedDialog"]
                        });
                    }
                },
                {
                    id: "open-kbd-shortcuts",
                    label: "action.open-kbd-shortcuts",
                    kbd: "cmd+alt+/,ctrl+alt+/",
                    onSelect (source) {
                        trackEvent("open-kbd-shortcuts", {
                            source
                        });
                        helpers.addDialog({
                            component: components.KeyboardShortcutsDialog ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$KeyboardShortcutsDialog$2f$DefaultKeyboardShortcutsDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultKeyboardShortcutsDialog"]
                        });
                    }
                },
                {
                    id: "insert-media",
                    label: "action.insert-media",
                    kbd: "cmd+u,ctrl+u",
                    onSelect (source) {
                        trackEvent("insert-media", {
                            source
                        });
                        helpers.insertMedia();
                    }
                },
                {
                    id: "undo",
                    label: "action.undo",
                    icon: "undo",
                    kbd: "cmd+z,ctrl+z",
                    onSelect (source) {
                        trackEvent("undo", {
                            source
                        });
                        editor.undo();
                    }
                },
                {
                    id: "redo",
                    label: "action.redo",
                    icon: "redo",
                    kbd: "cmd+shift+z,ctrl+shift+z",
                    onSelect (source) {
                        trackEvent("redo", {
                            source
                        });
                        editor.redo();
                    }
                },
                {
                    id: "export-as-svg",
                    label: {
                        default: "action.export-as-svg",
                        menu: "action.export-as-svg.short",
                        ["context-menu"]: "action.export-as-svg.short"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        let ids = editor.getSelectedShapeIds();
                        if (ids.length === 0) ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("export-as", {
                            format: "svg",
                            source
                        });
                        helpers.exportAs(ids, {
                            format: "svg",
                            name: getExportName(editor, defaultDocumentName)
                        });
                    }
                },
                {
                    id: "export-as-png",
                    label: {
                        default: "action.export-as-png",
                        menu: "action.export-as-png.short",
                        ["context-menu"]: "action.export-as-png.short"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        let ids = editor.getSelectedShapeIds();
                        if (ids.length === 0) ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("export-as", {
                            format: "png",
                            source
                        });
                        helpers.exportAs(ids, {
                            format: "png",
                            name: getExportName(editor, defaultDocumentName)
                        });
                    }
                },
                {
                    id: "export-all-as-svg",
                    label: {
                        default: "action.export-all-as-svg",
                        menu: "action.export-all-as-svg.short",
                        ["context-menu"]: "action.export-all-as-svg.short"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        let ids = editor.getSelectedShapeIds();
                        if (ids.length === 0) ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("export-all-as", {
                            format: "svg",
                            source
                        });
                        helpers.exportAs(Array.from(editor.getCurrentPageShapeIds()), {
                            format: "svg",
                            name: getExportName(editor, defaultDocumentName)
                        });
                    }
                },
                {
                    id: "export-all-as-png",
                    label: {
                        default: "action.export-all-as-png",
                        menu: "action.export-all-as-png.short",
                        ["context-menu"]: "action.export-all-as-png.short"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        const ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("export-all-as", {
                            format: "png",
                            source
                        });
                        helpers.exportAs(ids, {
                            format: "png",
                            name: getExportName(editor, defaultDocumentName)
                        });
                    }
                },
                {
                    id: "copy-as-svg",
                    label: {
                        default: "action.copy-as-svg",
                        menu: "action.copy-as-svg.short",
                        ["context-menu"]: "action.copy-as-svg.short"
                    },
                    kbd: "cmd+shift+c,ctrl+shift+c",
                    readonlyOk: true,
                    onSelect (source) {
                        let ids = editor.getSelectedShapeIds();
                        if (ids.length === 0) ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("copy-as", {
                            format: "svg",
                            source
                        });
                        helpers.copyAs(ids, "svg");
                    }
                },
                {
                    id: "copy-as-png",
                    label: {
                        default: "action.copy-as-png",
                        menu: "action.copy-as-png.short",
                        ["context-menu"]: "action.copy-as-png.short"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        let ids = editor.getSelectedShapeIds();
                        if (ids.length === 0) ids = Array.from(editor.getCurrentPageShapeIds().values());
                        if (ids.length === 0) return;
                        trackEvent("copy-as", {
                            format: "png",
                            source
                        });
                        helpers.copyAs(ids, "png");
                    }
                },
                {
                    id: "toggle-auto-size",
                    label: "action.toggle-auto-size",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("toggle-auto-size", {
                            source
                        });
                        editor.markHistoryStoppingPoint("toggling auto size");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const shapes = editor.getSelectedShapes().filter({
                                    "ActionsProvider.useMemo[actions].shapes": (shape)=>editor.isShapeOfType(shape, "text") && shape.props.autoSize === false
                                }["ActionsProvider.useMemo[actions].shapes"]);
                                editor.updateShapes(shapes.map({
                                    "ActionsProvider.useMemo[actions]": (shape)=>{
                                        return {
                                            id: shape.id,
                                            type: shape.type,
                                            props: {
                                                ...shape.props,
                                                w: 8,
                                                autoSize: true
                                            }
                                        };
                                    }
                                }["ActionsProvider.useMemo[actions]"]));
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, shapes.map({
                                    "ActionsProvider.useMemo[actions]": (shape)=>shape.id
                                }["ActionsProvider.useMemo[actions]"]));
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "open-embed-link",
                    label: "action.open-embed-link",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("open-embed-link", {
                            source
                        });
                        const ids = editor.getSelectedShapeIds();
                        const warnMsg = "No embed shapes selected";
                        if (ids.length !== 1) {
                            console.error(warnMsg);
                            return;
                        }
                        const shape = editor.getShape(ids[0]);
                        if (!shape || !editor.isShapeOfType(shape, "embed")) {
                            console.error(warnMsg);
                            return;
                        }
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$window$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openWindow"])(shape.props.url, "_blank");
                    }
                },
                {
                    id: "select-zoom-tool",
                    label: "action.select-zoom-tool",
                    readonlyOk: true,
                    kbd: "z, !z",
                    onSelect (source) {
                        if (editor.inputs.getAccelKey()) return;
                        const path = editor.getPath();
                        if (!path.endsWith(".idle")) return;
                        if (editor.root.getCurrent()?.id === "zoom") return;
                        trackEvent("zoom-tool", {
                            source
                        });
                        editor.setCurrentTool("zoom", {
                            onInteractionEnd: path,
                            maskAs: "zoom"
                        });
                    }
                },
                {
                    id: "convert-to-bookmark",
                    label: "action.convert-to-bookmark",
                    async onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("convert-to-bookmark", {
                            source
                        });
                        const shapes = editor.getSelectedShapes();
                        const markId = editor.markHistoryStoppingPoint("convert shapes to bookmark");
                        const creationPromises = [];
                        for (const shape of shapes){
                            if (!shape || !editor.isShapeOfType(shape, "embed") || !shape.props.url) continue;
                            const center = editor.getShapePageBounds(shape)?.center;
                            if (!center) continue;
                            editor.deleteShapes([
                                shape.id
                            ]);
                            creationPromises.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$bookmarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBookmarkFromUrl"])(editor, {
                                url: shape.props.url,
                                center
                            }).then({
                                "ActionsProvider.useMemo[actions]": (res)=>{
                                    if (!res.ok) {
                                        throw new Error(res.error);
                                    }
                                    return res;
                                }
                            }["ActionsProvider.useMemo[actions]"]));
                        }
                        await Promise.all(creationPromises).catch({
                            "ActionsProvider.useMemo[actions]": (error)=>{
                                editor.bailToMark(markId);
                                console.error(error);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "convert-to-embed",
                    label: "action.convert-to-embed",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("convert-to-embed", {
                            source
                        });
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const ids = editor.getSelectedShapeIds();
                                const shapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map({
                                    "ActionsProvider.useMemo[actions].shapes": (id)=>editor.getShape(id)
                                }["ActionsProvider.useMemo[actions].shapes"]));
                                const createList = [];
                                const deleteList = [];
                                for (const shape of shapes){
                                    if (!editor.isShapeOfType(shape, "bookmark")) continue;
                                    const { url } = shape.props;
                                    const embedInfo = helpers.getEmbedDefinition(url);
                                    if (!embedInfo) continue;
                                    if (!embedInfo.definition) continue;
                                    const { width, height } = embedInfo.definition;
                                    const newPos = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](shape.x, shape.y);
                                    newPos.rot(-shape.rotation);
                                    newPos.add(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](shape.props.w / 2 - width / 2, shape.props.h / 2 - height / 2));
                                    newPos.rot(shape.rotation);
                                    const shapeToCreate = {
                                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(),
                                        type: "embed",
                                        x: newPos.x,
                                        y: newPos.y,
                                        rotation: shape.rotation,
                                        props: {
                                            url,
                                            w: width,
                                            h: height
                                        }
                                    };
                                    createList.push(shapeToCreate);
                                    deleteList.push(shape.id);
                                }
                                editor.markHistoryStoppingPoint("convert shapes to embed");
                                editor.deleteShapes(deleteList);
                                editor.createShapes(createList);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "duplicate",
                    kbd: "cmd+d,ctrl+d",
                    label: "action.duplicate",
                    icon: "duplicate",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("duplicate-shapes", {
                            source
                        });
                        const instanceState = editor.getInstanceState();
                        let ids;
                        let offset;
                        if (instanceState.duplicateProps) {
                            ids = instanceState.duplicateProps.shapeIds;
                            offset = instanceState.duplicateProps.offset;
                        } else {
                            ids = editor.getSelectedShapeIds();
                            const commonBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map({
                                "ActionsProvider.useMemo[actions].commonBounds": (id)=>editor.getShapePageBounds(id)
                            }["ActionsProvider.useMemo[actions].commonBounds"])));
                            offset = editor.getCameraOptions().isLocked ? {
                                // same as the adjacent note margin
                                x: editor.options.adjacentShapeMargin,
                                y: editor.options.adjacentShapeMargin
                            } : {
                                x: commonBounds.width + editor.options.adjacentShapeMargin,
                                y: 0
                            };
                        }
                        editor.markHistoryStoppingPoint("duplicate shapes");
                        editor.duplicateShapes(ids, offset);
                        if (instanceState.duplicateProps) {
                            editor.updateInstanceState({
                                duplicateProps: {
                                    ...instanceState.duplicateProps,
                                    shapeIds: editor.getSelectedShapeIds()
                                }
                            });
                        }
                    }
                },
                {
                    id: "ungroup",
                    label: "action.ungroup",
                    kbd: "cmd+shift+g,ctrl+shift+g",
                    icon: "ungroup",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("ungroup-shapes", {
                            source
                        });
                        editor.markHistoryStoppingPoint("ungroup");
                        editor.ungroupShapes(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "group",
                    label: "action.group",
                    kbd: "cmd+g,ctrl+g",
                    icon: "group",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("group-shapes", {
                            source
                        });
                        const onlySelectedShape = editor.getOnlySelectedShape();
                        if (onlySelectedShape && editor.isShapeOfType(onlySelectedShape, "group")) {
                            editor.markHistoryStoppingPoint("ungroup");
                            editor.ungroupShapes(editor.getSelectedShapeIds());
                        } else {
                            editor.markHistoryStoppingPoint("group");
                            editor.groupShapes(editor.getSelectedShapeIds());
                        }
                    }
                },
                {
                    id: "remove-frame",
                    label: "action.remove-frame",
                    kbd: "cmd+shift+f,ctrl+shift+f",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        trackEvent("remove-frame", {
                            source
                        });
                        const selectedShapes = editor.getSelectedShapes();
                        if (selectedShapes.length > 0 && selectedShapes.every({
                            "ActionsProvider.useMemo[actions]": (shape)=>editor.isShapeOfType(shape, "frame")
                        }["ActionsProvider.useMemo[actions]"])) {
                            editor.markHistoryStoppingPoint("remove-frame");
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$frames$2f$frames$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFrame"])(editor, selectedShapes.map({
                                "ActionsProvider.useMemo[actions]": (shape)=>shape.id
                            }["ActionsProvider.useMemo[actions]"]));
                        }
                    }
                },
                {
                    id: "fit-frame-to-content",
                    label: "action.fit-frame-to-content",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        trackEvent("fit-frame-to-content", {
                            source
                        });
                        const onlySelectedShape = editor.getOnlySelectedShape();
                        if (onlySelectedShape && editor.isShapeOfType(onlySelectedShape, "frame")) {
                            editor.markHistoryStoppingPoint("fit-frame-to-content");
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$frames$2f$frames$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitFrameToContent"])(editor, onlySelectedShape.id);
                        }
                    }
                },
                {
                    id: "align-left",
                    label: "action.align-left",
                    kbd: "alt+A",
                    icon: "align-left",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "left",
                            source
                        });
                        editor.markHistoryStoppingPoint("align left");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "left");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "align-center-horizontal",
                    label: {
                        default: "action.align-center-horizontal",
                        ["context-menu"]: "action.align-center-horizontal.short"
                    },
                    kbd: "alt+H",
                    icon: "align-center-horizontal",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "center-horizontal",
                            source
                        });
                        editor.markHistoryStoppingPoint("align center horizontal");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "center-horizontal");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "align-right",
                    label: "action.align-right",
                    kbd: "alt+D",
                    icon: "align-right",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "right",
                            source
                        });
                        editor.markHistoryStoppingPoint("align right");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "right");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "align-center-vertical",
                    label: {
                        default: "action.align-center-vertical",
                        ["context-menu"]: "action.align-center-vertical.short"
                    },
                    kbd: "alt+V",
                    icon: "align-center-vertical",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "center-vertical",
                            source
                        });
                        editor.markHistoryStoppingPoint("align center vertical");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "center-vertical");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "align-top",
                    label: "action.align-top",
                    icon: "align-top",
                    kbd: "alt+W",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "top",
                            source
                        });
                        editor.markHistoryStoppingPoint("align top");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "top");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "align-bottom",
                    label: "action.align-bottom",
                    icon: "align-bottom",
                    kbd: "alt+S",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("align-shapes", {
                            operation: "bottom",
                            source
                        });
                        editor.markHistoryStoppingPoint("align bottom");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.alignShapes(selectedShapeIds, "bottom");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "distribute-horizontal",
                    label: {
                        default: "action.distribute-horizontal",
                        ["context-menu"]: "action.distribute-horizontal.short"
                    },
                    icon: "distribute-horizontal",
                    kbd: "alt+shift+h",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("distribute-shapes", {
                            operation: "horizontal",
                            source
                        });
                        editor.markHistoryStoppingPoint("distribute horizontal");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.distributeShapes(selectedShapeIds, "horizontal");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "distribute-vertical",
                    label: {
                        default: "action.distribute-vertical",
                        ["context-menu"]: "action.distribute-vertical.short"
                    },
                    icon: "distribute-vertical",
                    kbd: "alt+shift+V",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("distribute-shapes", {
                            operation: "vertical",
                            source
                        });
                        editor.markHistoryStoppingPoint("distribute vertical");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.distributeShapes(selectedShapeIds, "vertical");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "stretch-horizontal",
                    label: {
                        default: "action.stretch-horizontal",
                        ["context-menu"]: "action.stretch-horizontal.short"
                    },
                    icon: "stretch-horizontal",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("stretch-shapes", {
                            operation: "horizontal",
                            source
                        });
                        editor.markHistoryStoppingPoint("stretch horizontal");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.stretchShapes(selectedShapeIds, "horizontal");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "stretch-vertical",
                    label: {
                        default: "action.stretch-vertical",
                        ["context-menu"]: "action.stretch-vertical.short"
                    },
                    icon: "stretch-vertical",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("stretch-shapes", {
                            operation: "vertical",
                            source
                        });
                        editor.markHistoryStoppingPoint("stretch vertical");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.stretchShapes(selectedShapeIds, "vertical");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "flip-horizontal",
                    label: {
                        default: "action.flip-horizontal",
                        ["context-menu"]: "action.flip-horizontal.short"
                    },
                    kbd: "shift+h",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("flip-shapes", {
                            operation: "horizontal",
                            source
                        });
                        editor.markHistoryStoppingPoint("flip horizontal");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.flipShapes(selectedShapeIds, "horizontal");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "flip-vertical",
                    label: {
                        default: "action.flip-vertical",
                        ["context-menu"]: "action.flip-vertical.short"
                    },
                    kbd: "shift+v",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("flip-shapes", {
                            operation: "vertical",
                            source
                        });
                        editor.markHistoryStoppingPoint("flip vertical");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.flipShapes(selectedShapeIds, "vertical");
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "pack",
                    label: "action.pack",
                    icon: "pack",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("pack-shapes", {
                            source
                        });
                        editor.markHistoryStoppingPoint("pack");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.packShapes(selectedShapeIds, editor.options.adjacentShapeMargin);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "stack-vertical",
                    label: {
                        default: "action.stack-vertical",
                        ["context-menu"]: "action.stack-vertical.short"
                    },
                    icon: "stack-vertical",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("stack-shapes", {
                            operation: "vertical",
                            source
                        });
                        editor.markHistoryStoppingPoint("stack-vertical");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.stackShapes(selectedShapeIds, "vertical", editor.options.adjacentShapeMargin);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "stack-horizontal",
                    label: {
                        default: "action.stack-horizontal",
                        ["context-menu"]: "action.stack-horizontal.short"
                    },
                    icon: "stack-horizontal",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("stack-shapes", {
                            operation: "horizontal",
                            source
                        });
                        editor.markHistoryStoppingPoint("stack-horizontal");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.stackShapes(selectedShapeIds, "horizontal", editor.options.adjacentShapeMargin);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "bring-to-front",
                    label: "action.bring-to-front",
                    kbd: "]",
                    icon: "bring-to-front",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("reorder-shapes", {
                            operation: "toFront",
                            source
                        });
                        editor.markHistoryStoppingPoint("bring to front");
                        editor.bringToFront(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "bring-forward",
                    label: "action.bring-forward",
                    icon: "bring-forward",
                    kbd: "alt+]",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("reorder-shapes", {
                            operation: "forward",
                            source
                        });
                        editor.markHistoryStoppingPoint("bring forward");
                        editor.bringForward(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "send-backward",
                    label: "action.send-backward",
                    icon: "send-backward",
                    kbd: "alt+[",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("reorder-shapes", {
                            operation: "backward",
                            source
                        });
                        editor.markHistoryStoppingPoint("send backward");
                        editor.sendBackward(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "send-to-back",
                    label: "action.send-to-back",
                    icon: "send-to-back",
                    kbd: "[",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("reorder-shapes", {
                            operation: "toBack",
                            source
                        });
                        editor.markHistoryStoppingPoint("send to back");
                        editor.sendToBack(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "cut",
                    label: "action.cut",
                    kbd: "cmd+x,ctrl+x",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        editor.markHistoryStoppingPoint("cut");
                        helpers.cut(source);
                    }
                },
                {
                    id: "copy",
                    label: "action.copy",
                    kbd: "cmd+c,ctrl+c",
                    readonlyOk: true,
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        helpers.copy(source);
                    }
                },
                {
                    id: "paste",
                    label: "action.paste",
                    kbd: "cmd+v,ctrl+v",
                    onSelect (source) {
                        navigator.clipboard?.read().then({
                            "ActionsProvider.useMemo[actions]": (clipboardItems)=>{
                                helpers.paste(clipboardItems, source, source === "context-menu" ? editor.inputs.getCurrentPagePoint() : void 0);
                            }
                        }["ActionsProvider.useMemo[actions]"]).catch({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                helpers.addToast({
                                    title: helpers.msg("action.paste-error-title"),
                                    description: helpers.msg("action.paste-error-description"),
                                    severity: "error"
                                });
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "select-all",
                    label: "action.select-all",
                    kbd: "cmd+a,ctrl+a",
                    readonlyOk: true,
                    onSelect (source) {
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                                ;
                                trackEvent("select-all-shapes", {
                                    source
                                });
                                editor.markHistoryStoppingPoint("select all kbd");
                                editor.selectAll();
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "select-none",
                    label: "action.select-none",
                    readonlyOk: true,
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("select-none-shapes", {
                            source
                        });
                        editor.markHistoryStoppingPoint("select none");
                        editor.selectNone();
                    }
                },
                {
                    id: "delete",
                    label: "action.delete",
                    kbd: "\u232B,del",
                    icon: "trash",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("delete-shapes", {
                            source
                        });
                        editor.markHistoryStoppingPoint("delete");
                        editor.deleteShapes(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "rotate-cw",
                    label: "action.rotate-cw",
                    icon: "rotate-cw",
                    kbd: "shift+.,shift+alt+.",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        const isFine = editor.inputs.getAltKey();
                        trackEvent("rotate-cw", {
                            source,
                            fine: isFine
                        });
                        editor.markHistoryStoppingPoint("rotate-cw");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const rotation = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] / (isFine ? 96 : 6);
                                const offset = editor.getSelectionRotation() % rotation;
                                const dontUseOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(offset, 0) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(offset, rotation);
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.rotateShapesBy(selectedShapeIds, rotation - (dontUseOffset ? 0 : offset));
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "rotate-ccw",
                    label: "action.rotate-ccw",
                    icon: "rotate-ccw",
                    // omg double comma
                    kbd: "shift+,,shift+alt+,",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        const isFine = editor.inputs.getAltKey();
                        trackEvent("rotate-ccw", {
                            source,
                            fine: isFine
                        });
                        editor.markHistoryStoppingPoint("rotate-ccw");
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                const rotation = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] / (isFine ? 96 : 6);
                                const offset = editor.getSelectionRotation() % rotation;
                                const offsetCloseToZero = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(offset, 0);
                                const selectedShapeIds = editor.getSelectedShapeIds();
                                editor.rotateShapesBy(selectedShapeIds, offsetCloseToZero ? -rotation : -offset);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, selectedShapeIds);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "zoom-in",
                    label: "action.zoom-in",
                    kbd: "cmd+=,ctrl+=,=",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-in", {
                            source,
                            towardsCursor: false
                        });
                        editor.zoomIn(void 0, {
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-in-on-cursor",
                    label: "action.zoom-in",
                    kbd: "shift+cmd+=,shift+ctrl+=,shift+=",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-in", {
                            source,
                            towardsCursor: true
                        });
                        editor.zoomIn(editor.inputs.getCurrentScreenPoint(), {
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-out",
                    label: "action.zoom-out",
                    kbd: "cmd+-,ctrl+-,-",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-out", {
                            source,
                            towardsCursor: false
                        });
                        editor.zoomOut(void 0, {
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-out-on-cursor",
                    label: "action.zoom-out",
                    kbd: "shift+cmd+-,shift+ctrl+-,shift+-",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-out", {
                            source,
                            towardsCursor: true
                        });
                        editor.zoomOut(editor.inputs.getCurrentScreenPoint(), {
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-to-100",
                    label: "action.zoom-to-100",
                    icon: "reset-zoom",
                    kbd: "shift+0",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("reset-zoom", {
                            source
                        });
                        editor.resetZoom(void 0, {
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-to-fit",
                    label: "action.zoom-to-fit",
                    kbd: "shift+1",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-to-fit", {
                            source
                        });
                        editor.zoomToFit({
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "zoom-to-selection",
                    label: "action.zoom-to-selection",
                    kbd: "shift+2",
                    readonlyOk: true,
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        if (mustGoBackToSelectToolFirst()) //TURBOPACK unreachable
                        ;
                        trackEvent("zoom-to-selection", {
                            source
                        });
                        editor.zoomToSelection({
                            animation: {
                                duration: editor.options.animationMediumMs
                            }
                        });
                    }
                },
                {
                    id: "toggle-snap-mode",
                    label: {
                        default: "action.toggle-snap-mode",
                        menu: "action.toggle-snap-mode.menu"
                    },
                    onSelect (source) {
                        trackEvent("toggle-snap-mode", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            isSnapMode: !editor.user.getIsSnapMode()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-dark-mode",
                    label: {
                        default: "action.toggle-dark-mode",
                        menu: "action.toggle-dark-mode.menu"
                    },
                    kbd: "cmd+/,ctrl+/",
                    readonlyOk: true,
                    onSelect (source) {
                        const value = editor.user.getIsDarkMode() ? "light" : "dark";
                        trackEvent("color-scheme", {
                            source,
                            value
                        });
                        editor.user.updateUserPreferences({
                            colorScheme: value
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-wrap-mode",
                    label: {
                        default: "action.toggle-wrap-mode",
                        menu: "action.toggle-wrap-mode.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-wrap-mode", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            isWrapMode: !editor.user.getIsWrapMode()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-dynamic-size-mode",
                    label: {
                        default: "action.toggle-dynamic-size-mode",
                        menu: "action.toggle-dynamic-size-mode.menu"
                    },
                    readonlyOk: false,
                    onSelect (source) {
                        trackEvent("toggle-dynamic-size-mode", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            isDynamicSizeMode: !editor.user.getIsDynamicResizeMode()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-paste-at-cursor",
                    label: {
                        default: "action.toggle-paste-at-cursor",
                        menu: "action.toggle-paste-at-cursor.menu"
                    },
                    readonlyOk: false,
                    onSelect (source) {
                        trackEvent("toggle-paste-at-cursor", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            isPasteAtCursorMode: !editor.user.getIsPasteAtCursorMode()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-reduce-motion",
                    label: {
                        default: "action.toggle-reduce-motion",
                        menu: "action.toggle-reduce-motion.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-reduce-motion", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            animationSpeed: editor.user.getAnimationSpeed() === 0 ? 1 : 0
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-keyboard-shortcuts",
                    label: {
                        default: "action.toggle-keyboard-shortcuts",
                        menu: "action.toggle-keyboard-shortcuts.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-keyboard-shortcuts", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            areKeyboardShortcutsEnabled: !editor.user.getAreKeyboardShortcutsEnabled()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "enhanced-a11y-mode",
                    label: {
                        default: "action.enhanced-a11y-mode",
                        menu: "action.enhanced-a11y-mode.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("enhanced-a11y-mode", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            enhancedA11yMode: !editor.user.getEnhancedA11yMode()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-edge-scrolling",
                    label: {
                        default: "action.toggle-edge-scrolling",
                        menu: "action.toggle-edge-scrolling.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-edge-scrolling", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            edgeScrollSpeed: editor.user.getEdgeScrollSpeed() === 0 ? 1 : 0
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-invert-zoom",
                    label: {
                        default: "action.toggle-invert-zoom",
                        menu: "action.toggle-invert-zoom.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-invert-zoom", {
                            source
                        });
                        editor.user.updateUserPreferences({
                            isZoomDirectionInverted: !editor.user.getIsZoomDirectionInverted()
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-transparent",
                    label: {
                        default: "action.toggle-transparent",
                        menu: "action.toggle-transparent.menu",
                        ["context-menu"]: "action.toggle-transparent.context-menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-transparent", {
                            source
                        });
                        editor.updateInstanceState({
                            exportBackground: !editor.getInstanceState().exportBackground
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-tool-lock",
                    label: {
                        default: "action.toggle-tool-lock",
                        menu: "action.toggle-tool-lock.menu"
                    },
                    kbd: "q",
                    onSelect (source) {
                        trackEvent("toggle-tool-lock", {
                            source
                        });
                        editor.updateInstanceState({
                            isToolLocked: !editor.getInstanceState().isToolLocked
                        });
                    },
                    checkbox: true
                },
                {
                    id: "unlock-all",
                    label: "action.unlock-all",
                    onSelect (source) {
                        trackEvent("unlock-all", {
                            source
                        });
                        const updates = [];
                        for (const shape of editor.getCurrentPageShapes()){
                            if (shape.isLocked) {
                                updates.push({
                                    id: shape.id,
                                    type: shape.type,
                                    isLocked: false
                                });
                            }
                        }
                        if (updates.length > 0) {
                            editor.updateShapes(updates);
                        }
                    }
                },
                {
                    id: "toggle-focus-mode",
                    label: {
                        default: "action.toggle-focus-mode",
                        menu: "action.toggle-focus-mode.menu"
                    },
                    readonlyOk: true,
                    kbd: "cmd+.,ctrl+.",
                    checkbox: true,
                    onSelect (source) {
                        editor.timers.requestAnimationFrame({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.run({
                                    "ActionsProvider.useMemo[actions]": ()=>{
                                        trackEvent("toggle-focus-mode", {
                                            source
                                        });
                                        helpers.clearDialogs();
                                        helpers.clearToasts();
                                        editor.updateInstanceState({
                                            isFocusMode: !editor.getInstanceState().isFocusMode
                                        });
                                    }
                                }["ActionsProvider.useMemo[actions]"]);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                },
                {
                    id: "toggle-grid",
                    label: {
                        default: "action.toggle-grid",
                        menu: "action.toggle-grid.menu"
                    },
                    readonlyOk: true,
                    kbd: "cmd+',ctrl+'",
                    onSelect (source) {
                        trackEvent("toggle-grid-mode", {
                            source
                        });
                        editor.updateInstanceState({
                            isGridMode: !editor.getInstanceState().isGridMode
                        });
                    },
                    checkbox: true
                },
                {
                    id: "toggle-debug-mode",
                    label: {
                        default: "action.toggle-debug-mode",
                        menu: "action.toggle-debug-mode.menu"
                    },
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("toggle-debug-mode", {
                            source
                        });
                        editor.updateInstanceState({
                            isDebugMode: !editor.getInstanceState().isDebugMode
                        });
                    },
                    checkbox: true
                },
                {
                    id: "print",
                    label: "action.print",
                    kbd: "cmd+p,ctrl+p",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("print", {
                            source
                        });
                        helpers.printSelectionOrPages();
                    }
                },
                {
                    id: "exit-pen-mode",
                    label: "action.exit-pen-mode",
                    icon: "cross-2",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("exit-pen-mode", {
                            source
                        });
                        editor.updateInstanceState({
                            isPenMode: false
                        });
                    }
                },
                {
                    id: "stop-following",
                    label: "action.stop-following",
                    icon: "cross-2",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("stop-following", {
                            source
                        });
                        editor.stopFollowingUser();
                    }
                },
                {
                    id: "back-to-content",
                    label: "action.back-to-content",
                    icon: "arrow-left",
                    readonlyOk: true,
                    onSelect (source) {
                        trackEvent("zoom-to-content", {
                            source
                        });
                        const bounds = editor.getSelectionPageBounds() ?? editor.getCurrentPageBounds();
                        if (!bounds) return;
                        editor.zoomToBounds(bounds, {
                            targetZoom: Math.min(1, editor.getZoomLevel()),
                            animation: {
                                duration: 220
                            }
                        });
                    }
                },
                {
                    id: "toggle-lock",
                    label: "action.toggle-lock",
                    kbd: "shift+l",
                    onSelect (source) {
                        if (!canApplySelectionAction()) return;
                        editor.markHistoryStoppingPoint("locking");
                        trackEvent("toggle-lock", {
                            source
                        });
                        editor.toggleLock(editor.getSelectedShapeIds());
                    }
                },
                {
                    id: "move-to-new-page",
                    label: "context.pages.new-page",
                    onSelect (source) {
                        const newPageId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].createId();
                        const ids = editor.getSelectedShapeIds();
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.markHistoryStoppingPoint("move_shapes_to_page");
                                editor.createPage({
                                    name: helpers.msg("page-menu.new-page-initial-name"),
                                    id: newPageId
                                });
                                editor.moveShapesToPage(ids, newPageId);
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                        trackEvent("move-to-new-page", {
                            source
                        });
                    }
                },
                {
                    id: "select-white-color",
                    label: "color-style.white",
                    kbd: "alt+t",
                    onSelect (source) {
                        const style = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"];
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.markHistoryStoppingPoint("change-color");
                                if (editor.isIn("select")) {
                                    editor.setStyleForSelectedShapes(style, "white");
                                }
                                editor.setStyleForNextShapes(style, "white");
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                        trackEvent("set-style", {
                            source,
                            id: style.id,
                            value: "white"
                        });
                    }
                },
                {
                    id: "select-fill-fill",
                    label: "fill-style.fill",
                    kbd: "alt+f",
                    onSelect (source) {
                        const style = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"];
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.markHistoryStoppingPoint("change-fill");
                                if (editor.isIn("select")) {
                                    editor.setStyleForSelectedShapes(style, "fill");
                                }
                                editor.setStyleForNextShapes(style, "fill");
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                        trackEvent("set-style", {
                            source,
                            id: style.id,
                            value: "fill"
                        });
                    }
                },
                {
                    id: "select-fill-lined-fill",
                    label: "fill-style.lined-fill",
                    kbd: "alt+shift+f",
                    onSelect (source) {
                        const style = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"];
                        editor.run({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.markHistoryStoppingPoint("change-fill");
                                if (editor.isIn("select")) {
                                    editor.setStyleForSelectedShapes(style, "lined-fill");
                                }
                                editor.setStyleForNextShapes(style, "lined-fill");
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                        trackEvent("set-style", {
                            source,
                            id: style.id,
                            value: "lined-fill"
                        });
                    }
                },
                {
                    id: "flatten-to-image",
                    label: "action.flatten-to-image",
                    kbd: "shift+f",
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            const ids = editor.getSelectedShapeIds();
                            if (ids.length === 0) return;
                            editor.markHistoryStoppingPoint("flattening to image");
                            trackEvent("flatten-to-image", {
                                source
                            });
                            const newShapeIds = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useFlatten$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flattenShapesToImages"])(editor, ids, editor.options.flattenImageBoundsExpand);
                            if (newShapeIds?.length) {
                                editor.setSelectedShapes(newShapeIds);
                            }
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "select-geo-tool",
                    kbd: "g",
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            trackEvent("select-tool", {
                                source,
                                id: `geo-previous`
                            });
                            editor.setCurrentTool("geo");
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "change-page-prev",
                    kbd: "alt+left,alt+up",
                    readonlyOk: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            const pages = editor.getPages();
                            const currentPageIndex = pages.findIndex({
                                "ActionsProvider.useMemo[actions].currentPageIndex": (page)=>page.id === editor.getCurrentPageId()
                            }["ActionsProvider.useMemo[actions].currentPageIndex"]);
                            if (currentPageIndex < 1) return;
                            trackEvent("change-page", {
                                source,
                                direction: "prev"
                            });
                            editor.setCurrentPage(pages[currentPageIndex - 1].id);
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "change-page-next",
                    kbd: "alt+right,alt+down",
                    readonlyOk: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            const pages = editor.getPages();
                            const currentPageIndex = pages.findIndex({
                                "ActionsProvider.useMemo[actions].currentPageIndex": (page)=>page.id === editor.getCurrentPageId()
                            }["ActionsProvider.useMemo[actions].currentPageIndex"]);
                            if (currentPageIndex === -1 || currentPageIndex >= pages.length - 1) {
                                if (editor.getCurrentPageShapes().length <= 0 || editor.getIsReadonly()) {
                                    return;
                                }
                                trackEvent("new-page", {
                                    source
                                });
                                editor.run({
                                    "ActionsProvider.useMemo[actions]": ()=>{
                                        editor.markHistoryStoppingPoint("creating page");
                                        const newPageId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].createId();
                                        editor.createPage({
                                            name: helpers.msg("page-menu.new-page-initial-name"),
                                            id: newPageId
                                        });
                                        editor.setCurrentPage(newPageId);
                                    }
                                }["ActionsProvider.useMemo[actions]"]);
                                return;
                            }
                            editor.setCurrentPage(pages[currentPageIndex + 1].id);
                            trackEvent("change-page", {
                                source,
                                direction: "next"
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "adjust-shape-styles",
                    label: "a11y.adjust-shape-styles",
                    kbd: "cmd+Enter,ctrl+Enter",
                    isRequiredA11yAction: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            if (!canApplySelectionAction()) return;
                            const onlySelectedShape = editor.getOnlySelectedShape();
                            if (onlySelectedShape && (editor.isShapeOfType(onlySelectedShape, "image") || editor.isShapeOfType(onlySelectedShape, "video"))) {
                                const firstToolbarButton = editor.getContainer().querySelector(".tlui-contextual-toolbar button:first-child");
                                firstToolbarButton?.focus();
                                return;
                            }
                            const firstButton = editor.getContainer().querySelector(".tlui-style-panel button");
                            firstButton?.focus();
                            trackEvent("adjust-shape-styles", {
                                source
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "a11y-open-context-menu",
                    kbd: "cmd+shift+Enter,ctrl+shift+Enter",
                    isRequiredA11yAction: true,
                    readonlyOk: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            if (!canApplySelectionAction()) return;
                            const selectionBounds = editor.getSelectionPageBounds();
                            if (!selectionBounds) return;
                            const centerX = selectionBounds.x + selectionBounds.width / 2;
                            const centerY = selectionBounds.y + selectionBounds.height / 2;
                            const screenPoint = editor.pageToScreen(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](centerX, centerY));
                            editor.getContainer().querySelector(".tl-canvas")?.dispatchEvent(new PointerEvent("contextmenu", {
                                clientX: screenPoint.x,
                                clientY: screenPoint.y,
                                bubbles: true
                            }));
                            trackEvent("open-context-menu", {
                                source
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "enlarge-shapes",
                    label: "a11y.enlarge-shape",
                    kbd: "cmd+alt+shift+=,ctrl+alt+shift+=",
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            if (!canApplySelectionAction()) return;
                            scaleShapes(1.1);
                            trackEvent("enlarge-shapes", {
                                source
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "shrink-shapes",
                    label: "a11y.shrink-shape",
                    kbd: "cmd+alt+shift+-,ctrl+alt+shift+-",
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            if (!canApplySelectionAction()) return;
                            scaleShapes(1 / 1.1);
                            trackEvent("shrink-shapes", {
                                source
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "a11y-repeat-shape-announce",
                    kbd: "alt+r",
                    label: "a11y.repeat-shape",
                    isRequiredA11yAction: true,
                    readonlyOk: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            const selectedShapeIds = editor.getSelectedShapeIds();
                            if (!selectedShapeIds.length) return;
                            const a11yLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$A11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateShapeAnnouncementMessage"])({
                                editor,
                                selectedShapeIds,
                                msg
                            });
                            if (a11yLive) {
                                a11y.announce({
                                    msg: ""
                                });
                                editor.timers.requestAnimationFrame({
                                    "ActionsProvider.useMemo[actions]": ()=>{
                                        a11y.announce({
                                            msg: a11yLive
                                        });
                                    }
                                }["ActionsProvider.useMemo[actions]"]);
                                trackEvent("a11y-repeat-shape-announce", {
                                    source
                                });
                            }
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "image-replace",
                    label: "tool.replace-media",
                    icon: "arrow-cycle",
                    readonlyOk: false,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            trackEvent("image-replace", {
                                source
                            });
                            helpers.replaceImage();
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "video-replace",
                    label: "tool.replace-media",
                    icon: "arrow-cycle",
                    readonlyOk: false,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            trackEvent("video-replace", {
                                source
                            });
                            helpers.replaceVideo();
                        }
                    }["ActionsProvider.useMemo[actions]"]
                },
                {
                    id: "download-original",
                    label: "action.download-original",
                    readonlyOk: true,
                    onSelect: {
                        "ActionsProvider.useMemo[actions]": async (source)=>{
                            const selectedShapes = editor.getSelectedShapes();
                            if (selectedShapes.length === 0) return;
                            const mediaShapes = selectedShapes.filter({
                                "ActionsProvider.useMemo[actions].mediaShapes": (s)=>supportsDownloadingOriginal(s, editor)
                            }["ActionsProvider.useMemo[actions].mediaShapes"]);
                            if (mediaShapes.length === 0) return;
                            for (const mediaShape of mediaShapes){
                                const asset = editor.getAsset(mediaShape.props.assetId);
                                if (!asset || !asset.props.src) continue;
                                const url = await editor.resolveAssetUrl(asset.id, {
                                    shouldResolveToOriginal: true
                                });
                                if (!url) return;
                                const link = document.createElement("a");
                                link.href = url;
                                if ((asset.type === "video" || asset.type === "image") && !asset.props.src.startsWith("asset:")) {
                                    link.download = asset.props.name;
                                } else {
                                    link.download = "download";
                                }
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                            }
                            trackEvent("download-original", {
                                source
                            });
                        }
                    }["ActionsProvider.useMemo[actions]"]
                }
            ];
            if (showCollaborationUi) {
                actionItems.push({
                    id: "open-cursor-chat",
                    label: "action.open-cursor-chat",
                    readonlyOk: true,
                    kbd: "/",
                    onSelect (source) {
                        trackEvent("open-cursor-chat", {
                            source
                        });
                        if (editor.getInstanceState().isCoarsePointer) {
                            return;
                        }
                        editor.timers.requestAnimationFrame({
                            "ActionsProvider.useMemo[actions]": ()=>{
                                editor.updateInstanceState({
                                    isChatting: true
                                });
                            }
                        }["ActionsProvider.useMemo[actions]"]);
                    }
                });
            }
            const actions2 = makeActions(actionItems);
            if (overrides) {
                return overrides(editor, actions2, helpers);
            }
            return actions2;
        }
    }["ActionsProvider.useMemo[actions]"], [
        helpers,
        _editor,
        trackEvent,
        overrides,
        defaultDocumentName,
        showCollaborationUi,
        msg,
        a11y,
        components
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ActionsContext.Provider, {
        value: asActions(actions),
        children
    });
}
function useActions() {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ActionsContext);
    if (!ctx) {
        throw new Error("useTools must be used within a ToolProvider");
    }
    return ctx;
}
function asActions(actions) {
    return actions;
}
function unwrapLabel(label, menuType) {
    return label ? typeof label === "string" ? label : menuType ? label[menuType] ?? label["default"] : void 0 : void 0;
}
;
 //# sourceMappingURL=actions.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/TldrawUiContextProvider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawUiContextProvider",
    ()=>TldrawUiContextProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLUserPreferences.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/assetUrls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$primitives$2f$TldrawUiTooltip$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/primitives/TldrawUiTooltip.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTools.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/overrides.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/a11y.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$actions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/actions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/asset-urls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$breakpoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/breakpoints.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/components.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$dialogs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/dialogs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const TldrawUiContextProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["track"])(function TldrawUiContextProvider2({ overrides, components, assetUrls, onUiEvent, forceMobile, mediaMimeTypes, children }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MimeTypeContext"].Provider, {
        value: mediaMimeTypes,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$primitives$2f$TldrawUiTooltip$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiTooltipProvider"], {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetUrlsProvider"], {
                assetUrls: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultUiAssetUrlsWithOverrides"])(assetUrls),
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiTranslationProvider"], {
                    overrides: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedTranslationOverrides"])(overrides),
                    locale: editor?.user.getLocale() ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].locale,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiEventsProvider"], {
                        onEvent: onUiEvent,
                        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiToastsProvider"], {
                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$dialogs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiDialogsProvider"], {
                                context: "tla",
                                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiA11yProvider"], {
                                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$breakpoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BreakPointProvider"], {
                                        forceMobile,
                                        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiComponentsProvider"], {
                                            overrides: components,
                                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InternalProviders, {
                                                overrides,
                                                children
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    });
});
function InternalProviders({ overrides, children }) {
    const mergedOverrides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedOverrides"])(overrides);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$actions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionsProvider"], {
        overrides: mergedOverrides.actions,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToolsProvider"], {
            overrides: mergedOverrides.tools,
            children
        })
    });
}
;
 //# sourceMappingURL=TldrawUiContextProvider.mjs.map
}),
]);

//# debugId=8b844292-c90b-1a6c-7561-aa965ae6c5fc
//# sourceMappingURL=c427b_tldraw_dist-esm_lib_ui_context_895b928c._.js.map