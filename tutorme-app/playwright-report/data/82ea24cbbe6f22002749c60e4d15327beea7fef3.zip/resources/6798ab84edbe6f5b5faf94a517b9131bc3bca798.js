(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_b6326336._.js",
  "static/chunks/c427b_9780a8e0._.js"
],
    source: "dynamic"
});
