(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_49c3ba1c._.js",
  "static/chunks/c427b_lucide-react_dist_esm_icons_d1e67ddb._.js"
],
    source: "dynamic"
});
