;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="7c23b29e-9537-3c8e-00c7-96995e030367")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tlenv",
    ()=>tlenv,
    "tlenvReactive",
    ()=>tlenvReactive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
;
const tlenv = {
    isSafari: false,
    isIos: false,
    isChromeForIos: false,
    isFirefox: false,
    isAndroid: false,
    isWebview: false,
    isDarwin: false,
    hasCanvasSupport: false
};
let isForcedFinePointer = false;
if (typeof window !== "undefined") {
    if ("navigator" in window) {
        tlenv.isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        tlenv.isIos = !!navigator.userAgent.match(/iPad/i) || !!navigator.userAgent.match(/iPhone/i);
        tlenv.isChromeForIos = /crios.*safari/i.test(navigator.userAgent);
        tlenv.isFirefox = /firefox/i.test(navigator.userAgent);
        tlenv.isAndroid = /android/i.test(navigator.userAgent);
        tlenv.isDarwin = window.navigator.userAgent.toLowerCase().indexOf("mac") > -1;
    }
    tlenv.hasCanvasSupport = "Promise" in window && "HTMLCanvasElement" in window;
    isForcedFinePointer = tlenv.isFirefox && !tlenv.isAndroid && !tlenv.isIos;
}
const tlenvReactive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("tlenvReactive", {
    // Whether the user's device has a coarse pointer. This is dynamic on many systems, especially
    // on touch-screen laptops, which will become "coarse" if the user touches the screen.
    // See https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/pointer#coarse
    isCoarsePointer: false
});
if (typeof window !== "undefined" && !isForcedFinePointer) {
    const mql = window.matchMedia && window.matchMedia("(any-pointer: coarse)");
    const isCurrentCoarsePointer = ()=>tlenvReactive.__unsafe__getWithoutCapture().isCoarsePointer;
    if (mql) {
        const updateIsCoarsePointer = ()=>{
            const isCoarsePointer = mql.matches;
            if (isCoarsePointer !== isCurrentCoarsePointer()) {
                tlenvReactive.update((prev)=>({
                        ...prev,
                        isCoarsePointer
                    }));
            }
        };
        updateIsCoarsePointer();
        mql.addEventListener("change", updateIsCoarsePointer);
    }
    window.addEventListener("pointerdown", (e)=>{
        const isCoarseEvent = e.pointerType !== "mouse";
        if (isCoarseEvent !== isCurrentCoarsePointer()) {
            tlenvReactive.update((prev)=>({
                    ...prev,
                    isCoarsePointer: isCoarseEvent
                }));
        }
    }, {
        capture: true
    });
}
;
 //# sourceMappingURL=environment.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/menus.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tlmenus",
    ()=>tlmenus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
;
const tlmenus = {
    /**
   * A set of strings representing any open menus. When menus are open,
   * certain interactions will behave differently; for example, when a
   * draw tool is selected and a menu is open, a pointer-down will not
   * create a dot (because the user is probably trying to close the menu)
   * however a pointer-down event followed by a drag will begin drawing
   * a line (because the user is BOTH trying to close the menu AND start
   * drawing a line).
   *
   * @public
   */ menus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("open menus", []),
    /**
   * Get the current open menus.
   *
   * @param contextId - An optional context to get menus for.
   *
   * @public
   */ getOpenMenus (contextId) {
        if (contextId) return this.menus.get().filter((m)=>m.endsWith("-" + contextId));
        return this.menus.get();
    },
    /**
   * Add an open menu.
   *
   * @example
   * ```ts
   * addOpenMenu('menu-id')
   * addOpenMenu('menu-id', myEditorId)
   * ```
   *
   * @param id - The id of the menu to add.
   * @param contextId - An optional context to add the menu to.
   *
   * @public
   */ addOpenMenu (id, contextId = "") {
        const idWithContext = contextId ? `${id}-${contextId}` : id;
        const menus = new Set(this.menus.get());
        if (!menus.has(idWithContext)) {
            menus.add(idWithContext);
            this.menus.set([
                ...menus
            ]);
        }
    },
    /**
   * Delete an open menu.
   *
   * @example
   * ```ts
   * deleteOpenMenu('menu-id')
   * deleteOpenMenu('menu-id', myEditorId)
   * ```
   *
   * @param id - The id of the menu to delete.
   * @param contextId - An optional context to delete the menu from.
   *
   * @public
   */ deleteOpenMenu (id, contextId = "") {
        const idWithContext = contextId ? `${id}-${contextId}` : id;
        const menus = new Set(this.menus.get());
        if (menus.has(idWithContext)) {
            menus.delete(idWithContext);
            this.menus.set([
                ...menus
            ]);
        }
    },
    /**
   * Clear all open menus.
   *
   * @example
   * ```ts
   * clearOpenMenus()
   * clearOpenMenus(myEditorId)
   * ```
   *
   * @param contextId - An optional context to clear menus for.
   *
   * @public
   */ clearOpenMenus (contextId) {
        this.menus.set(contextId ? this.menus.get().filter((m)=>!m.endsWith("-" + contextId)) : []);
    },
    _hiddenMenus: [],
    /**
   * Hide all open menus. Restore them with the `showOpenMenus` method.
   *
   * @example
   * ```ts
   * hideOpenMenus()
   * hideOpenMenus(myEditorId)
   * ```
   *
   * @param contextId - An optional context to hide menus for.
   *
   * @public
   */ hideOpenMenus (contextId) {
        this._hiddenMenus = [
            ...this.getOpenMenus(contextId)
        ];
        if (this._hiddenMenus.length === 0) return;
        for (const menu of this._hiddenMenus){
            this.deleteOpenMenu(menu, contextId);
        }
    },
    /**
   * Show all hidden menus.
   *
   * @example
   * ```ts
   * showOpenMenus()
   * showOpenMenus(myEditorId)
   * ```
   *
   * @param contextId - An optional context to show menus for.
   *
   * @public
   */ showOpenMenus (contextId) {
        if (this._hiddenMenus.length === 0) return;
        for (const menu of this._hiddenMenus){
            this.addOpenMenu(menu, contextId);
        }
        this._hiddenMenus = [];
    },
    /**
   * Get whether a menu is open for a given context.
   *
   * @example
   * ```ts
   * isMenuOpem(id, myEditorId)
   * ```
   *
   * @param id - The id of the menu to check.
   * @param contextId - An optional context to check menus for.
   *
   * @public
   */ isMenuOpen (id, contextId) {
        return this.getOpenMenus(contextId).includes(`${id}-${contextId}`);
    },
    /**
   * Get whether any menus are open for a given context.
   *
   * @example
   * ```ts
   * hasOpenMenus(myEditorId)
   * ```
   *
   * @param contextId - A context to check menus for.
   *
   * @public
   */ hasOpenMenus (contextId) {
        return this.getOpenMenus(contextId).length > 0;
    },
    /**
   * Get whether any menus are open for any context.
   *
   * @example
   * ```ts
   * hasAnyOpenMenus()
   * ```
   *
   * @public
   */ hasAnyOpenMenus () {
        return this.getOpenMenus().length > 0;
    },
    forContext (contextId) {
        return {
            getOpenMenus: ()=>this.getOpenMenus(contextId),
            addOpenMenu: (id)=>this.addOpenMenu(id, contextId),
            deleteOpenMenu: (id)=>this.deleteOpenMenu(id, contextId),
            clearOpenMenus: ()=>this.clearOpenMenus(contextId),
            // Gets whether any menus are open
            isMenuOpen: (id)=>this.isMenuOpen(id, contextId),
            hasOpenMenus: ()=>this.hasOpenMenus(contextId),
            hasAnyOpenMenus: ()=>this.hasAnyOpenMenus()
        };
    }
};
;
 //# sourceMappingURL=menus.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/time.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tltime",
    ()=>tltime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$timers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/timers.mjs [app-client] (ecmascript)");
;
const tltime = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$timers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timers"]();
;
 //# sourceMappingURL=time.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/constants.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_ANIMATION_OPTIONS",
    ()=>DEFAULT_ANIMATION_OPTIONS,
    "DEFAULT_CAMERA_OPTIONS",
    ()=>DEFAULT_CAMERA_OPTIONS,
    "INTERNAL_POINTER_IDS",
    ()=>INTERNAL_POINTER_IDS,
    "LEFT_MOUSE_BUTTON",
    ()=>LEFT_MOUSE_BUTTON,
    "MIDDLE_MOUSE_BUTTON",
    ()=>MIDDLE_MOUSE_BUTTON,
    "RIGHT_MOUSE_BUTTON",
    ()=>RIGHT_MOUSE_BUTTON,
    "SIDES",
    ()=>SIDES,
    "STYLUS_ERASER_BUTTON",
    ()=>STYLUS_ERASER_BUTTON
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
;
const DEFAULT_CAMERA_OPTIONS = {
    isLocked: false,
    wheelBehavior: "pan",
    panSpeed: 1,
    zoomSpeed: 1,
    zoomSteps: [
        0.05,
        0.1,
        0.25,
        0.5,
        1,
        2,
        4,
        8
    ]
};
const DEFAULT_ANIMATION_OPTIONS = {
    duration: 0,
    easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeInOutCubic
};
const INTERNAL_POINTER_IDS = {
    CAMERA_MOVE: -10
};
const SIDES = [
    "top",
    "right",
    "bottom",
    "left"
];
const LEFT_MOUSE_BUTTON = 0;
const RIGHT_MOUSE_BUTTON = 2;
const MIDDLE_MOUSE_BUTTON = 1;
const STYLUS_ERASER_BUTTON = 5;
;
 //# sourceMappingURL=constants.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLUserPreferences.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "USER_COLORS",
    ()=>USER_COLORS,
    "defaultUserPreferences",
    ()=>defaultUserPreferences,
    "getFreshUserPreferences",
    ()=>getFreshUserPreferences,
    "getUserPreferences",
    ()=>getUserPreferences,
    "setUserPreferences",
    ()=>setUserPreferences,
    "userPrefersReducedMotion",
    ()=>userPrefersReducedMotion,
    "userTypeValidator",
    ()=>userTypeValidator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/translations/translations.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/storage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
;
;
;
;
const USER_DATA_KEY = "TLDRAW_USER_DATA_v3";
const userTypeValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string,
    name: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable().optional(),
    color: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable().optional(),
    // N.B. These are duplicated in TLdrawAppUser.
    locale: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].string.nullable().optional(),
    animationSpeed: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number.nullable().optional(),
    areKeyboardShortcutsEnabled: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    edgeScrollSpeed: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number.nullable().optional(),
    colorScheme: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("light", "dark", "system").optional(),
    isSnapMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    isWrapMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    isDynamicSizeMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    isPasteAtCursorMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    enhancedA11yMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional(),
    inputMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].literalEnum("trackpad", "mouse").nullable().optional(),
    isZoomDirectionInverted: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.nullable().optional()
});
const Versions = {
    AddAnimationSpeed: 1,
    AddIsSnapMode: 2,
    MakeFieldsNullable: 3,
    AddEdgeScrollSpeed: 4,
    AddExcalidrawSelectMode: 5,
    AddDynamicSizeMode: 6,
    AllowSystemColorScheme: 7,
    AddPasteAtCursor: 8,
    AddKeyboardShortcuts: 9,
    AddShowUiLabels: 10,
    AddPointerPeripheral: 11,
    RenameShowUiLabelsToEnhancedA11yMode: 12,
    AddZoomDirectionInverted: 13
};
const CURRENT_VERSION = Math.max(...Object.values(Versions));
function migrateSnapshot(data) {
    if (data.version < Versions.AddAnimationSpeed) {
        data.user.animationSpeed = 1;
    }
    if (data.version < Versions.AddIsSnapMode) {
        data.user.isSnapMode = false;
    }
    if (data.version < Versions.MakeFieldsNullable) {}
    if (data.version < Versions.AddEdgeScrollSpeed) {
        data.user.edgeScrollSpeed = 1;
    }
    if (data.version < Versions.AddExcalidrawSelectMode) {
        data.user.isWrapMode = false;
    }
    if (data.version < Versions.AllowSystemColorScheme) {
        if (data.user.isDarkMode === true) {
            data.user.colorScheme = "dark";
        } else if (data.user.isDarkMode === false) {
            data.user.colorScheme = "light";
        }
        delete data.user.isDarkMode;
    }
    if (data.version < Versions.AddDynamicSizeMode) {
        data.user.isDynamicSizeMode = false;
    }
    if (data.version < Versions.AddPasteAtCursor) {
        data.user.isPasteAtCursorMode = false;
    }
    if (data.version < Versions.AddKeyboardShortcuts) {
        data.user.areKeyboardShortcutsEnabled = true;
    }
    if (data.version < Versions.AddShowUiLabels) {
        data.user.showUiLabels = false;
    }
    if (data.version < Versions.RenameShowUiLabelsToEnhancedA11yMode) {
        data.user.enhancedA11yMode = data.user.showUiLabels;
        delete data.user.showUiLabels;
    }
    if (data.version < Versions.AddPointerPeripheral) {
        data.user.inputMode = null;
    }
    if (data.version < Versions.AddZoomDirectionInverted) {
        data.user.isZoomDirectionInverted = false;
    }
    data.version = CURRENT_VERSION;
}
const USER_COLORS = [
    "#FF802B",
    "#EC5E41",
    "#F2555A",
    "#F04F88",
    "#E34BA9",
    "#BD54C6",
    "#9D5BD2",
    "#7B66DC",
    "#02B1CC",
    "#11B3A3",
    "#39B178",
    "#55B467"
];
function getRandomColor() {
    return USER_COLORS[Math.floor(Math.random() * USER_COLORS.length)];
}
function userPrefersReducedMotion() {
    if (typeof window !== "undefined" && window.matchMedia) {
        return window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false;
    }
    return false;
}
const defaultUserPreferences = Object.freeze({
    name: "",
    locale: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$translations$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getDefaultTranslationLocale"])(),
    color: getRandomColor(),
    // N.B. These are duplicated in TLdrawAppUser.
    edgeScrollSpeed: 1,
    animationSpeed: userPrefersReducedMotion() ? 0 : 1,
    areKeyboardShortcutsEnabled: true,
    isSnapMode: false,
    isWrapMode: false,
    isDynamicSizeMode: false,
    isPasteAtCursorMode: false,
    enhancedA11yMode: false,
    colorScheme: "light",
    inputMode: null,
    isZoomDirectionInverted: false
});
function getFreshUserPreferences() {
    return {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
        color: getRandomColor()
    };
}
function migrateUserPreferences(userData) {
    if (userData === null || typeof userData !== "object") {
        return getFreshUserPreferences();
    }
    if (!("version" in userData) || !("user" in userData) || typeof userData.version !== "number") {
        return getFreshUserPreferences();
    }
    const snapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(userData);
    migrateSnapshot(snapshot);
    try {
        return userTypeValidator.validate(snapshot.user);
    } catch  {
        return getFreshUserPreferences();
    }
}
function loadUserPreferences() {
    const userData = JSON.parse((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFromLocalStorage"])(USER_DATA_KEY) || "null") ?? null;
    return migrateUserPreferences(userData);
}
const globalUserPreferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("globalUserData", null);
function storeUserPreferences() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInLocalStorage"])(USER_DATA_KEY, JSON.stringify({
        version: CURRENT_VERSION,
        user: globalUserPreferences.get()
    }));
}
function setUserPreferences(user) {
    userTypeValidator.validate(user);
    globalUserPreferences.set(user);
    storeUserPreferences();
    broadcastUserPreferencesChange();
}
const isTest = typeof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && ("TURBOPACK compile-time value", "development") === "test";
const channel = typeof BroadcastChannel !== "undefined" && !isTest ? new BroadcastChannel("tldraw-user-sync") : null;
channel?.addEventListener("message", (e)=>{
    const data = e.data;
    if (data?.type === broadcastEventKey && data?.origin !== getBroadcastOrigin()) {
        globalUserPreferences.set(migrateUserPreferences(data.data));
    }
});
let _broadcastOrigin = null;
function getBroadcastOrigin() {
    if (_broadcastOrigin === null) {
        _broadcastOrigin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
    }
    return _broadcastOrigin;
}
const broadcastEventKey = "tldraw-user-preferences-change";
function broadcastUserPreferencesChange() {
    channel?.postMessage({
        type: broadcastEventKey,
        origin: getBroadcastOrigin(),
        data: {
            user: getUserPreferences(),
            version: CURRENT_VERSION
        }
    });
}
function getUserPreferences() {
    let prefs = globalUserPreferences.get();
    if (!prefs) {
        prefs = loadUserPreferences();
        setUserPreferences(prefs);
    }
    return prefs;
}
;
 //# sourceMappingURL=TLUserPreferences.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/createTLUser.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTLUser",
    ()=>createTLUser,
    "useTldrawUser",
    ()=>useTldrawUser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$isSignal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/isSignal.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useAtom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useAtom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useIdentity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLUserPreferences.mjs [app-client] (ecmascript)");
;
;
;
;
;
const defaultLocalStorageUserPrefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("defaultLocalStorageUserPrefs", ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserPreferences"])());
function createTLUser(opts = {}) {
    return {
        userPreferences: opts.userPreferences ?? defaultLocalStorageUserPrefs,
        setUserPreferences: opts.setUserPreferences ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setUserPreferences"]
    };
}
function useTldrawUser(opts) {
    const prefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowObjectIdentity"])(opts.userPreferences ?? defaultLocalStorageUserPrefs);
    const userAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useAtom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])("userAtom", prefs);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useTldrawUser.useEffect": ()=>{
            userAtom.set(prefs);
        }
    }["useTldrawUser.useEffect"], [
        prefs,
        userAtom
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useTldrawUser.useMemo": ()=>createTLUser({
                userPreferences: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("userPreferences", {
                    "useTldrawUser.useMemo": ()=>{
                        const userStuff = userAtom.get();
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$isSignal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSignal"])(userStuff) ? userStuff.get() : userStuff;
                    }
                }["useTldrawUser.useMemo"]),
                setUserPreferences: opts.setUserPreferences
            })
    }["useTldrawUser.useMemo"], [
        userAtom,
        opts.setUserPreferences
    ]);
}
;
 //# sourceMappingURL=createTLUser.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLSessionStateSnapshot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TAB_ID",
    ()=>TAB_ID,
    "createSessionStateSnapshotSignal",
    ()=>createSessionStateSnapshotSignal,
    "extractSessionStateFromLegacySnapshot",
    ()=>extractSessionStateFromLegacySnapshot,
    "loadSessionStateSnapshotIntoStore",
    ()=>loadSessionStateSnapshotIntoStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLBaseShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/storage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript) <export default as isEqual>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/lib/validation.mjs [app-client] (ecmascript) <export * as T>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)");
;
;
;
;
;
const tabIdKey = "TLDRAW_TAB_ID_v2";
const window = globalThis.window;
function iOS() {
    if (!window) return false;
    return [
        "iPad Simulator",
        "iPhone Simulator",
        "iPod Simulator",
        "iPad",
        "iPhone",
        "iPod"
    ].includes(// eslint-disable-next-line @typescript-eslint/no-deprecated
    window.navigator.platform) || // iPad on iOS 13 detection
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isDarwin && "ontouchend" in document;
}
const TAB_ID = window ? window[tabIdKey] ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFromSessionStorage"])(tabIdKey) ?? `TLDRAW_INSTANCE_STATE_V1_` + (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])() : "<error>";
if (window) {
    window[tabIdKey] = TAB_ID;
    if (iOS()) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInSessionStorage"])(tabIdKey, TAB_ID);
    } else {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteFromSessionStorage"])(tabIdKey);
    }
}
window?.addEventListener("beforeunload", ()=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInSessionStorage"])(tabIdKey, TAB_ID);
});
const Versions = {
    Initial: 0
};
const CURRENT_SESSION_STATE_SNAPSHOT_VERSION = Math.max(...Object.values(Versions));
function migrate(snapshot) {
    if (snapshot.version < Versions.Initial) {}
    snapshot.version = CURRENT_SESSION_STATE_SNAPSHOT_VERSION;
}
const sessionStateSnapshotValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
    version: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
    currentPageId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageIdValidator"].optional(),
    isFocusMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional(),
    exportBackground: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional(),
    isDebugMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional(),
    isToolLocked: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional(),
    isGridMode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].boolean.optional(),
    pageStates: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
        pageId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageIdValidator"],
        camera: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].object({
            x: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
            y: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number,
            z: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].number
        }).optional(),
        selectedShapeIds: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$lib$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__T$3e$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"]).optional(),
        focusedGroupId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLBaseShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shapeIdValidator"].nullable().optional()
    })).optional()
});
function migrateAndValidateSessionStateSnapshot(state) {
    if (!state || typeof state !== "object") {
        console.warn("Invalid instance state");
        return null;
    }
    if (!("version" in state) || typeof state.version !== "number") {
        console.warn("No version in instance state");
        return null;
    }
    if (state.version !== CURRENT_SESSION_STATE_SNAPSHOT_VERSION) {
        state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(state);
        migrate(state);
    }
    try {
        return sessionStateSnapshotValidator.validate(state);
    } catch (e) {
        console.warn(e);
        return null;
    }
}
function createSessionStateSnapshotSignal(store) {
    const $allPageIds = store.query.ids("page");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("sessionStateSnapshot", ()=>{
        const instanceState = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        if (!instanceState) return null;
        const allPageIds = [
            ...$allPageIds.get()
        ];
        return {
            version: CURRENT_SESSION_STATE_SNAPSHOT_VERSION,
            currentPageId: instanceState.currentPageId,
            exportBackground: instanceState.exportBackground,
            isFocusMode: instanceState.isFocusMode,
            isDebugMode: instanceState.isDebugMode,
            isToolLocked: instanceState.isToolLocked,
            isGridMode: instanceState.isGridMode,
            pageStates: allPageIds.map((id)=>{
                const ps = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(id));
                const camera = store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(id));
                return {
                    pageId: id,
                    camera: {
                        x: camera?.x ?? 0,
                        y: camera?.y ?? 0,
                        z: camera?.z ?? 1
                    },
                    selectedShapeIds: ps?.selectedShapeIds ?? [],
                    focusedGroupId: ps?.focusedGroupId ?? null
                };
            })
        };
    }, {
        isEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"]
    });
}
function loadSessionStateSnapshotIntoStore(store, snapshot, opts) {
    const res = migrateAndValidateSessionStateSnapshot(snapshot);
    if (!res) return;
    const preserved = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pluckPreservingValues"])(store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]));
    const primary = opts?.forceOverwrite ? res : preserved;
    const secondary = opts?.forceOverwrite ? preserved : res;
    const instanceState = store.schema.types.instance.create({
        id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"],
        ...preserved,
        // the integrity checker will ensure that the currentPageId is valid
        currentPageId: res.currentPageId,
        isDebugMode: primary?.isDebugMode ?? secondary?.isDebugMode,
        isFocusMode: primary?.isFocusMode ?? secondary?.isFocusMode,
        isToolLocked: primary?.isToolLocked ?? secondary?.isToolLocked,
        isGridMode: primary?.isGridMode ?? secondary?.isGridMode,
        exportBackground: primary?.exportBackground ?? secondary?.exportBackground
    });
    store.atomic(()=>{
        for (const ps of res.pageStates ?? []){
            if (!store.has(ps.pageId)) continue;
            const cameraId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(ps.pageId);
            const instancePageState = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(ps.pageId);
            const previousCamera = store.get(cameraId);
            const previousInstanceState = store.get(instancePageState);
            store.put([
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].create({
                    id: cameraId,
                    x: ps.camera?.x ?? previousCamera?.x,
                    y: ps.camera?.y ?? previousCamera?.y,
                    z: ps.camera?.z ?? previousCamera?.z
                }),
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].create({
                    id: instancePageState,
                    pageId: ps.pageId,
                    selectedShapeIds: ps.selectedShapeIds ?? previousInstanceState?.selectedShapeIds,
                    focusedGroupId: ps.focusedGroupId ?? previousInstanceState?.focusedGroupId
                })
            ]);
        }
        store.put([
            instanceState
        ]);
        store.ensureStoreIsUsable();
    });
}
function extractSessionStateFromLegacySnapshot(store) {
    const instanceRecords = [];
    for (const record of Object.values(store)){
        if (record.typeName?.match(/^(instance.*|pointer|camera)$/)) {
            instanceRecords.push(record);
        }
    }
    const oldInstance = instanceRecords.filter((r)=>r.typeName === "instance" && r.id !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"])[0];
    if (!oldInstance) return null;
    const result = {
        version: CURRENT_SESSION_STATE_SNAPSHOT_VERSION,
        currentPageId: oldInstance.currentPageId,
        exportBackground: !!oldInstance.exportBackground,
        isFocusMode: !!oldInstance.isFocusMode,
        isDebugMode: !!oldInstance.isDebugMode,
        isToolLocked: !!oldInstance.isToolLocked,
        isGridMode: false,
        pageStates: instanceRecords.filter((r)=>r.typeName === "instance_page_state" && r.instanceId === oldInstance.id).map((ps)=>{
            const camera = store[ps.cameraId] ?? {
                x: 0,
                y: 0,
                z: 1
            };
            return {
                pageId: ps.pageId,
                camera: {
                    x: camera.x,
                    y: camera.y,
                    z: camera.z
                },
                selectedShapeIds: ps.selectedShapeIds,
                focusedGroupId: ps.focusedGroupId
            };
        })
    };
    try {
        sessionStateSnapshotValidator.validate(result);
        return result;
    } catch  {
        return null;
    }
}
;
 //# sourceMappingURL=TLSessionStateSnapshot.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLEditorSnapshot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSnapshot",
    ()=>getSnapshot,
    "loadSnapshot",
    ()=>loadSnapshot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/cache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLSessionStateSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLSessionStateSnapshot.mjs [app-client] (ecmascript)");
;
;
;
function loadSnapshot(store, _snapshot, opts) {
    let snapshot = {};
    if ("store" in _snapshot) {
        const migrationResult = store.schema.migrateStoreSnapshot(_snapshot);
        if (migrationResult.type !== "success") {
            throw new Error("Failed to migrate store snapshot: " + migrationResult.reason);
        }
        snapshot.document = {
            schema: store.schema.serialize(),
            store: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"])(migrationResult.value, (_, { typeName })=>store.scopedTypes.document.has(typeName))
        };
    } else {
        snapshot = _snapshot;
    }
    const preservingInstanceState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pluckPreservingValues"])(store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]));
    const preservingSessionState = sessionStateCache.get(store, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLSessionStateSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSessionStateSnapshotSignal"]).get();
    store.atomic(()=>{
        if (snapshot.document) {
            store.loadStoreSnapshot(snapshot.document);
        }
        if (preservingInstanceState) {
            store.update(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"], (r)=>({
                    ...r,
                    ...preservingInstanceState
                }));
        }
        if (preservingSessionState) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLSessionStateSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadSessionStateSnapshotIntoStore"])(store, preservingSessionState);
        }
        if (snapshot.session) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLSessionStateSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadSessionStateSnapshotIntoStore"])(store, snapshot.session, {
                forceOverwrite: opts?.forceOverwriteSessionState
            });
        }
    });
}
const sessionStateCache = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"]();
function getSnapshot(store) {
    const sessionState$ = sessionStateCache.get(store, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLSessionStateSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSessionStateSnapshotSignal"]);
    const session = sessionState$.get();
    if (!session) {
        throw new Error("Session state is not ready yet");
    }
    return {
        document: store.getStoreSnapshot(),
        session
    };
}
;
 //# sourceMappingURL=TLEditorSnapshot.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultBindings.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkBindings",
    ()=>checkBindings
]);
function checkBindings(customBindings) {
    const bindings = [];
    const addedCustomBindingTypes = /* @__PURE__ */ new Set();
    for (const customBinding of customBindings){
        if (addedCustomBindingTypes.has(customBinding.type)) {
            throw new Error(`Binding type "${customBinding.type}" is defined more than once`);
        }
        bindings.push(customBinding);
        addedCustomBindingTypes.add(customBinding.type);
    }
    return bindings;
}
;
 //# sourceMappingURL=defaultBindings.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultShapes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkShapesAndAddCore",
    ()=>checkShapesAndAddCore,
    "coreShapes",
    ()=>coreShapes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$group$2f$GroupShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/group/GroupShapeUtil.mjs [app-client] (ecmascript)");
;
const coreShapes = [
    // created by grouping interactions, probably the corest core shape that we have
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$group$2f$GroupShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GroupShapeUtil"]
];
const coreShapeTypes = new Set(coreShapes.map((s)=>s.type));
function checkShapesAndAddCore(customShapes) {
    const shapes = [
        ...coreShapes
    ];
    const addedCustomShapeTypes = /* @__PURE__ */ new Set();
    for (const customShape of customShapes){
        if (coreShapeTypes.has(customShape.type)) {
            throw new Error(`Shape type "${customShape.type}" is a core shapes type and cannot be overridden`);
        }
        if (addedCustomShapeTypes.has(customShape.type)) {
            throw new Error(`Shape type "${customShape.type}" is defined more than once`);
        }
        shapes.push(customShape);
        addedCustomShapeTypes.add(customShape.type);
    }
    return shapes;
}
;
 //# sourceMappingURL=defaultShapes.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/createTLStore.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTLSchemaFromUtils",
    ()=>createTLSchemaFromUtils,
    "createTLStore",
    ()=>createTLStore,
    "inlineBase64AssetStore",
    ()=>inlineBase64AssetStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/Store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/createTLSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/Editor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLEditorSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLEditorSnapshot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultBindings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultBindings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultShapes.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const defaultAssetResolve = (asset)=>asset.props.src;
const inlineBase64AssetStore = {
    upload: async (_, file)=>{
        return {
            src: await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(file)
        };
    }
};
function createTLSchemaFromUtils(opts) {
    if ("schema" in opts && opts.schema) return opts.schema;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$createTLSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTLSchema"])({
        shapes: "shapeUtils" in opts && opts.shapeUtils ? utilsToMap((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkShapesAndAddCore"])(opts.shapeUtils)) : void 0,
        bindings: "bindingUtils" in opts && opts.bindingUtils ? utilsToMap((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultBindings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkBindings"])(opts.bindingUtils)) : void 0,
        migrations: "migrations" in opts ? opts.migrations : void 0
    });
}
function createTLStore({ initialData, defaultName = "", id, assets = inlineBase64AssetStore, onMount, collaboration, ...rest } = {}) {
    const schema = createTLSchemaFromUtils(rest);
    const store = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Store"]({
        id,
        schema,
        initialData,
        props: {
            defaultName,
            assets: {
                upload: assets.upload,
                resolve: assets.resolve ?? defaultAssetResolve,
                remove: assets.remove ?? (()=>Promise.resolve())
            },
            onMount: (editor)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(editor instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Editor"]);
                onMount?.(editor);
            },
            collaboration
        }
    });
    if (rest.snapshot) {
        if (initialData) throw new Error("Cannot provide both initialData and snapshot");
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLEditorSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadSnapshot"])(store, rest.snapshot, {
            forceOverwriteSessionState: true
        });
    }
    return store;
}
function utilsToMap(utils) {
    return Object.fromEntries(utils.map((s)=>[
            s.type,
            {
                props: s.props,
                migrations: s.migrations
            }
        ]));
}
;
 //# sourceMappingURL=createTLStore.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/fetchCache.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchCache",
    ()=>fetchCache,
    "resourceToDataUrl",
    ()=>resourceToDataUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
;
function fetchCache(cb, init) {
    const cache = /* @__PURE__ */ new Map();
    return async function fetchCached(url) {
        const existing = cache.get(url);
        if (existing) return existing;
        const promise = (async ()=>{
            try {
                const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(url, init);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(response.ok);
                return await cb(response);
            } catch (err) {
                console.error(err);
                return null;
            }
        })();
        cache.set(url, promise);
        return promise;
    };
}
const resourceToDataUrl = fetchCache(async (response)=>{
    return await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(await response.blob());
});
;
 //# sourceMappingURL=fetchCache.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/parseCss.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseCss",
    ()=>parseCss,
    "parseCssFontFaces",
    ()=>parseCssFontFaces,
    "parseCssFontFamilyValue",
    ()=>parseCssFontFamilyValue,
    "parseCssImports",
    ()=>parseCssImports,
    "parseCssValueUrls",
    ()=>parseCssValueUrls,
    "shouldIncludeCssProperty",
    ()=>shouldIncludeCssProperty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/url.mjs [app-client] (ecmascript)");
;
const importsRegex = /@import\s+(?:"([^"]+)"|'([^']+)'|url\s*\(\s*(?:"([^"]+)"|'([^']+)'|([^'")]+))\s*\))([^;]+);/gi;
const fontFaceRegex = /@font-face\s*{([^}]+)}/gi;
const urlsRegex = /url\s*\(\s*(?:"([^"]+)"|'([^']+)'|([^'")]+))\s*\)/gi;
const fontFamilyRegex = /(?:^|;)\s*font-family\s*:\s*(?:([^'"][^;\n]+)|"([^"]+)"|'([^']+)')\s*(?:;|$)/gi;
function parseCssImports(css) {
    return Array.from(css.matchAll(importsRegex), (m)=>({
            url: m[1] || m[2] || m[3] || m[4] || m[5],
            extras: m[6]
        }));
}
function parseCssFontFaces(css, baseUrl) {
    return Array.from(css.matchAll(fontFaceRegex), (m)=>{
        const fontFace = m[1];
        const urls = Array.from(fontFace.matchAll(urlsRegex), (m2)=>{
            const original = m2[1] || m2[2] || m2[3];
            return {
                original,
                resolved: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(original, baseUrl)?.href ?? null
            };
        });
        const fontFamilies = new Set(Array.from(fontFace.matchAll(fontFamilyRegex), (m2)=>(m2[1] || m2[2] || m2[3]).toLowerCase()));
        return {
            fontFace,
            urls,
            fontFamilies
        };
    });
}
function parseCssFontFamilyValue(value) {
    const valueRegex = /\s*(?:([^'"][^;\n\s,]+)|"([^"]+)"|'([^']+)')\s*/gi;
    const separatorRegex = /\s*,\s*/gi;
    const fontFamilies = /* @__PURE__ */ new Set();
    while(true){
        const valueMatch = valueRegex.exec(value);
        if (!valueMatch) {
            break;
        }
        const fontFamily = valueMatch[1] || valueMatch[2] || valueMatch[3];
        fontFamilies.add(fontFamily.toLowerCase());
        separatorRegex.lastIndex = valueRegex.lastIndex;
        const separatorMatch = separatorRegex.exec(value);
        if (!separatorMatch) {
            break;
        }
        valueRegex.lastIndex = separatorRegex.lastIndex;
    }
    return fontFamilies;
}
function shouldIncludeCssProperty(property) {
    if (property.startsWith("-")) return false;
    if (property.startsWith("animation")) return false;
    if (property.startsWith("transition")) return false;
    if (property === "cursor") return false;
    if (property === "pointer-events") return false;
    if (property === "user-select") return false;
    if (property === "touch-action") return false;
    return true;
}
function parseCss(css, baseUrl) {
    return {
        imports: parseCssImports(css),
        fontFaces: parseCssFontFaces(css, baseUrl)
    };
}
function parseCssValueUrls(value) {
    return Array.from(value.matchAll(urlsRegex), (m)=>({
            original: m[0],
            url: m[1] || m[2] || m[3]
        })).filter((m)=>!m.url.startsWith("#"));
}
;
 //# sourceMappingURL=parseCss.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/FontEmbedder.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FontEmbedder",
    ()=>FontEmbedder,
    "SVG_EXPORT_CLASSNAME",
    ()=>SVG_EXPORT_CLASSNAME
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/fetchCache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/parseCss.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _onFontFamilyValue_dec, _init;
;
;
;
const SVG_EXPORT_CLASSNAME = "tldraw-svg-export";
_onFontFamilyValue_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
];
class FontEmbedder {
    constructor(){
        __runInitializers(_init, 5, this);
        __publicField(this, "fontFacesPromise", null);
        __publicField(this, "foundFontNames", /* @__PURE__ */ new Set());
        __publicField(this, "fontFacesToEmbed", /* @__PURE__ */ new Set());
        __publicField(this, "pendingPromises", []);
    }
    startFindingCurrentDocumentFontFaces() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(!this.fontFacesPromise, "FontEmbedder already started");
        this.fontFacesPromise = getCurrentDocumentFontFaces();
    }
    onFontFamilyValue(fontFamilyValue) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(this.fontFacesPromise, "FontEmbedder not started");
        const fonts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseCssFontFamilyValue"])(fontFamilyValue);
        for (const font of fonts){
            if (this.foundFontNames.has(font)) return;
            this.foundFontNames.add(font);
            this.pendingPromises.push(this.fontFacesPromise.then((fontFaces)=>{
                const relevantFontFaces = fontFaces.filter((fontFace)=>fontFace.fontFamilies.has(font));
                for (const fontFace of relevantFontFaces){
                    if (this.fontFacesToEmbed.has(fontFace)) continue;
                    this.fontFacesToEmbed.add(fontFace);
                    for (const url of fontFace.urls){
                        if (!url.resolved || url.embedded) continue;
                        url.embedded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resourceToDataUrl"])(url.resolved);
                    }
                }
            }));
        }
    }
    async createCss() {
        await Promise.all(this.pendingPromises);
        let css = "";
        for (const fontFace of this.fontFacesToEmbed){
            let fontFaceString = `@font-face {${fontFace.fontFace}}`;
            for (const url of fontFace.urls){
                if (!url.embedded) continue;
                const dataUrl = await url.embedded;
                if (!dataUrl) continue;
                fontFaceString = fontFaceString.replace(url.original, dataUrl);
            }
            css += fontFaceString;
        }
        return css;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "onFontFamilyValue", _onFontFamilyValue_dec, FontEmbedder);
__decoratorMetadata(_init, FontEmbedder);
async function getCurrentDocumentFontFaces() {
    const fontFaces = [];
    const styleSheetsWithoutSvgExports = Array.from(document.styleSheets).filter((styleSheet)=>!styleSheet.ownerNode?.closest(`.${SVG_EXPORT_CLASSNAME}`));
    for (const styleSheet of styleSheetsWithoutSvgExports){
        let cssRules;
        try {
            cssRules = styleSheet.cssRules;
        } catch  {}
        if (cssRules) {
            for (const rule of styleSheet.cssRules){
                if (rule instanceof CSSFontFaceRule) {
                    fontFaces.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseCssFontFaces"])(rule.cssText, styleSheet.href ?? document.baseURI));
                } else if (rule instanceof CSSImportRule) {
                    const absoluteUrl = new URL(rule.href, rule.parentStyleSheet?.href ?? document.baseURI);
                    fontFaces.push(fetchCssFontFaces(absoluteUrl.href));
                }
            }
        } else if (styleSheet.href) {
            fontFaces.push(fetchCssFontFaces(styleSheet.href));
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(await Promise.all(fontFaces)).flat();
}
const fetchCssFontFaces = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchCache"])(async (response)=>{
    const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseCss"])(await response.text(), response.url);
    const importedFontFaces = await Promise.all(parsed.imports.map(({ url })=>fetchCssFontFaces(new URL(url, response.url).href)));
    return [
        ...parsed.fontFaces,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(importedFontFaces).flat()
    ];
});
;
 //# sourceMappingURL=FontEmbedder.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/cssRules.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cssRules",
    ()=>cssRules
]);
const isCoveredByCurrentColor = (value, property, { currentColor })=>{
    return value === "currentColor" || value === currentColor;
};
const isInherited = (value, property, { parentStyles })=>{
    return parentStyles[property] === value;
};
const isExcludedBorder = (borderDirection)=>(value, property, { getStyle })=>{
        const borderWidth = getStyle(`border-${borderDirection}-width`);
        const borderStyle = getStyle(`border-${borderDirection}-style`);
        if (borderWidth === "0px") return true;
        if (borderStyle === "none") return true;
        return false;
    };
const cssRules = {
    // currentColor properties:
    "border-block-end-color": isCoveredByCurrentColor,
    "border-block-start-color": isCoveredByCurrentColor,
    "border-bottom-color": isCoveredByCurrentColor,
    "border-inline-end-color": isCoveredByCurrentColor,
    "border-inline-start-color": isCoveredByCurrentColor,
    "border-left-color": isCoveredByCurrentColor,
    "border-right-color": isCoveredByCurrentColor,
    "border-top-color": isCoveredByCurrentColor,
    "caret-color": isCoveredByCurrentColor,
    "column-rule-color": isCoveredByCurrentColor,
    "outline-color": isCoveredByCurrentColor,
    "text-decoration": (value, property, { currentColor })=>{
        return value === "none solid currentColor" || value === "none solid " + currentColor;
    },
    "text-decoration-color": isCoveredByCurrentColor,
    "text-emphasis-color": isCoveredByCurrentColor,
    // inherited properties:
    "border-collapse": isInherited,
    "border-spacing": isInherited,
    "caption-side": isInherited,
    // N.B. We shouldn't inherit 'color' because there's some UA styling, e.g. `mark` elements
    // 'color': isInherited,
    cursor: isInherited,
    direction: isInherited,
    "empty-cells": isInherited,
    "font-family": isInherited,
    "font-size": isInherited,
    "font-style": isInherited,
    "font-variant": isInherited,
    "font-weight": isInherited,
    "font-size-adjust": isInherited,
    "font-stretch": isInherited,
    font: isInherited,
    "letter-spacing": isInherited,
    "line-height": isInherited,
    "list-style-image": isInherited,
    "list-style-position": isInherited,
    "list-style-type": isInherited,
    "list-style": isInherited,
    orphans: isInherited,
    "overflow-wrap": isInherited,
    quotes: isInherited,
    "stroke-linecap": isInherited,
    "stroke-linejoin": isInherited,
    "tab-size": isInherited,
    "text-align": isInherited,
    "text-align-last": isInherited,
    "text-indent": isInherited,
    "text-justify": isInherited,
    "text-shadow": isInherited,
    "text-transform": isInherited,
    visibility: isInherited,
    "white-space": isInherited,
    "white-space-collapse": isInherited,
    widows: isInherited,
    "word-break": isInherited,
    "word-spacing": isInherited,
    "word-wrap": isInherited,
    // special border cases - we have a weird case (tailwind seems to trigger this) where all
    // border-styles sometimes get set to 'solid', but the border-width is 0 so they don't render.
    // but in SVGs, **sometimes**, the border-width defaults (i think from a UA style-sheet? but
    // honestly can't tell) to 1.5px so the border displays. we work around this by only including
    // border styles at all if both the border-width and border-style are set to something that
    // would show a border.
    "border-top": isExcludedBorder("top"),
    "border-right": isExcludedBorder("right"),
    "border-bottom": isExcludedBorder("bottom"),
    "border-left": isExcludedBorder("left"),
    "border-block-end": isExcludedBorder("block-end"),
    "border-block-start": isExcludedBorder("block-start"),
    "border-inline-end": isExcludedBorder("inline-end"),
    "border-inline-start": isExcludedBorder("inline-start"),
    "border-top-style": isExcludedBorder("top"),
    "border-right-style": isExcludedBorder("right"),
    "border-bottom-style": isExcludedBorder("bottom"),
    "border-left-style": isExcludedBorder("left"),
    "border-block-end-style": isExcludedBorder("block-end"),
    "border-block-start-style": isExcludedBorder("block-start"),
    "border-inline-end-style": isExcludedBorder("inline-end"),
    "border-inline-start-style": isExcludedBorder("inline-start"),
    "border-top-width": isExcludedBorder("top"),
    "border-right-width": isExcludedBorder("right"),
    "border-bottom-width": isExcludedBorder("bottom"),
    "border-left-width": isExcludedBorder("left"),
    "border-block-end-width": isExcludedBorder("block-end"),
    "border-block-start-width": isExcludedBorder("block-start"),
    "border-inline-end-width": isExcludedBorder("inline-end")
};
;
 //# sourceMappingURL=cssRules.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/domUtils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "elementStyle",
    ()=>elementStyle,
    "getComputedStyle",
    ()=>getComputedStyle,
    "getRenderedChildNodes",
    ()=>getRenderedChildNodes,
    "getRenderedChildren",
    ()=>getRenderedChildren,
    "isElement",
    ()=>isElement
]);
function getRenderedChildNodes(node) {
    if (node.shadowRoot) {
        return node.shadowRoot.childNodes;
    }
    if (isShadowSlotElement(node)) {
        const assignedNodes = node.assignedNodes();
        if (assignedNodes?.length) {
            return assignedNodes;
        }
    }
    return node.childNodes;
}
function* getRenderedChildren(node) {
    for (const child of getRenderedChildNodes(node)){
        if (isElement(child)) yield child;
    }
}
function getWindow(node) {
    return node.ownerDocument?.defaultView ?? globalThis;
}
function isElement(node) {
    return node instanceof getWindow(node).Element;
}
function isShadowRoot(node) {
    return node instanceof getWindow(node).ShadowRoot;
}
function isInShadowRoot(node) {
    return "getRootNode" in node && isShadowRoot(node.getRootNode());
}
function isShadowSlotElement(node) {
    return isInShadowRoot(node) && node instanceof getWindow(node).HTMLSlotElement;
}
function elementStyle(element) {
    return element.style;
}
function getComputedStyle(element, pseudoElement) {
    return getWindow(element).getComputedStyle(element, pseudoElement);
}
;
 //# sourceMappingURL=domUtils.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/StyleEmbedder.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StyleEmbedder",
    ()=>StyleEmbedder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$FontEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/FontEmbedder.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$cssRules$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/cssRules.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/domUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/fetchCache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/parseCss.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const NO_STYLES = {};
class StyleEmbedder {
    constructor(root){
        this.root = root;
    }
    styles = /* @__PURE__ */ new Map();
    fonts = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$FontEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontEmbedder"]();
    readRootElementStyles(rootElement) {
        this.readElementStyles(rootElement, {
            shouldRespectDefaults: false,
            shouldSkipInheritedParentStyles: false
        });
        const children = Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRenderedChildren"])(rootElement));
        while(children.length){
            const child = children.pop();
            children.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRenderedChildren"])(child));
            this.readElementStyles(child, {
                shouldRespectDefaults: true,
                shouldSkipInheritedParentStyles: true
            });
        }
    }
    readElementStyles(element, { shouldRespectDefaults = true, shouldSkipInheritedParentStyles = true }) {
        const defaultStyles = shouldRespectDefaults ? getDefaultStylesForTagName(element.tagName.toLowerCase()) : NO_STYLES;
        const parentStyles = Object.assign({}, NO_STYLES);
        if (shouldSkipInheritedParentStyles) {
            let el = element.parentElement;
            while(el){
                const currentStyles = this.styles.get(el)?.self;
                for(const style in currentStyles){
                    if (!parentStyles[style]) {
                        parentStyles[style] = currentStyles[style];
                    }
                }
                el = el.parentElement;
            }
        }
        const info = {
            self: styleFromElement(element, {
                defaultStyles,
                parentStyles
            }),
            before: styleFromPseudoElement(element, "::before"),
            after: styleFromPseudoElement(element, "::after")
        };
        this.styles.set(element, info);
    }
    fetchResources() {
        const promises = [];
        for (const info of this.styles.values()){
            for (const styles of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(info)){
                if (!styles) continue;
                for (const [property, value] of Object.entries(styles)){
                    if (!value) continue;
                    if (property === "font-family") {
                        this.fonts.onFontFamilyValue(value);
                    }
                    const urlMatches = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseCssValueUrls"])(value);
                    if (urlMatches.length === 0) continue;
                    promises.push(...urlMatches.map(async ({ url, original })=>{
                        const dataUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resourceToDataUrl"])(url) ?? "data:";
                        styles[property] = value.replace(original, `url("${dataUrl}")`);
                    }));
                }
            }
        }
        return Promise.all(promises);
    }
    // custom elements are tricky. if we serialize the dom as-is, the custom elements wont have
    // their shadow-dom contents serialized. after we've read all the styles, we need to unwrap the
    // contents of each custom elements shadow dom directly into the parent element itself.
    unwrapCustomElements() {
        const visited = /* @__PURE__ */ new Set();
        const visit = (element, clonedParent)=>{
            if (visited.has(element)) return;
            visited.add(element);
            const shadowRoot = element.shadowRoot;
            if (shadowRoot) {
                const clonedCustomEl = document.createElement("div");
                this.styles.set(clonedCustomEl, this.styles.get(element));
                clonedCustomEl.setAttribute("data-tl-custom-element", element.tagName);
                (clonedParent ?? element.parentElement).appendChild(clonedCustomEl);
                for (const child of shadowRoot.childNodes){
                    if (child instanceof Element) {
                        visit(child, clonedCustomEl);
                    } else {
                        clonedCustomEl.appendChild(child.cloneNode(true));
                    }
                }
                element.remove();
            } else if (clonedParent) {
                if (element.tagName.toLowerCase() === "style") {
                    return;
                }
                const clonedEl = element.cloneNode(false);
                this.styles.set(clonedEl, this.styles.get(element));
                clonedParent.appendChild(clonedEl);
                for (const child of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRenderedChildNodes"])(element)){
                    if (child instanceof Element) {
                        visit(child, clonedEl);
                    } else {
                        clonedEl.appendChild(child.cloneNode(true));
                    }
                }
            }
        };
        for (const element of this.styles.keys()){
            visit(element, null);
        }
    }
    embedStyles() {
        let css = "";
        for (const [element, info] of this.styles){
            if (info.after || info.before) {
                const className = `pseudo-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()}`;
                element.classList.add(className);
                if (info.before) {
                    css += `.${className}::before {${formatCss(info.before)}}
`;
                }
                if (info.after) {
                    css += `.${className}::after {${formatCss(info.after)}}
`;
                }
            }
            const style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["elementStyle"])(element);
            for (const [property, value] of Object.entries(info.self)){
                if (!value) continue;
                style.setProperty(property, value);
            }
            if (style.fontKerning === "auto") {
                style.fontKerning = "normal";
            }
        }
        return css;
    }
    async getFontFaceCss() {
        return await this.fonts.createCss();
    }
    dispose() {
        destroyDefaultStyleFrame();
    }
}
function styleFromElement(element, { defaultStyles, parentStyles }) {
    if (element.computedStyleMap) {
        return styleFromComputedStyleMap(element.computedStyleMap(), {
            defaultStyles,
            parentStyles
        });
    }
    return styleFromComputedStyle((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element), {
        defaultStyles,
        parentStyles
    });
}
function styleFromPseudoElement(element, pseudo) {
    const style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element, pseudo);
    const content = style.getPropertyValue("content");
    if (content === "" || content === "none") {
        return void 0;
    }
    return styleFromComputedStyle(style, {
        defaultStyles: NO_STYLES,
        parentStyles: NO_STYLES
    });
}
function styleFromComputedStyleMap(style, { defaultStyles, parentStyles }) {
    const styles = {};
    const currentColor = style.get("color")?.toString() || "";
    const ruleOptions = {
        currentColor,
        parentStyles,
        defaultStyles,
        getStyle: (property)=>style.get(property)?.toString() ?? ""
    };
    for (const property of style.keys()){
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldIncludeCssProperty"])(property)) continue;
        const value = style.get(property).toString();
        if (defaultStyles[property] === value) continue;
        const rule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$cssRules$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cssRules"], property);
        if (rule && rule(value, property, ruleOptions)) continue;
        styles[property] = value;
    }
    return styles;
}
function styleFromComputedStyle(style, { defaultStyles, parentStyles }) {
    const styles = {};
    const currentColor = style.color;
    const ruleOptions = {
        currentColor,
        parentStyles,
        defaultStyles,
        getStyle: (property)=>style.getPropertyValue(property)
    };
    for(const property in style){
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$parseCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldIncludeCssProperty"])(property)) continue;
        const value = style.getPropertyValue(property);
        if (defaultStyles[property] === value) continue;
        const rule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$cssRules$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cssRules"], property);
        if (rule && rule(value, property, ruleOptions)) continue;
        styles[property] = value;
    }
    return styles;
}
function formatCss(style) {
    let cssText = "";
    for (const [property, value] of Object.entries(style)){
        cssText += `${property}: ${value};`;
    }
    return cssText;
}
let defaultStyleFrame;
const defaultStylesByTagName = {};
function getDefaultStyleFrame() {
    if (!defaultStyleFrame) {
        const frame = document.createElement("iframe");
        frame.style.display = "none";
        document.body.appendChild(frame);
        const frameDocument = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(frame.contentDocument, "frame must have a document");
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        const foreignObject = document.createElementNS("http://www.w3.org/2000/svg", "foreignObject");
        svg.appendChild(foreignObject);
        frameDocument.body.appendChild(svg);
        defaultStyleFrame = {
            iframe: frame,
            foreignObject,
            document: frameDocument
        };
    }
    return defaultStyleFrame;
}
function destroyDefaultStyleFrame() {
    if (defaultStyleFrame) {
        document.body.removeChild(defaultStyleFrame.iframe);
        defaultStyleFrame = void 0;
    }
}
const defaultStyleReadOptions = {
    defaultStyles: NO_STYLES,
    parentStyles: NO_STYLES
};
function getDefaultStylesForTagName(tagName) {
    let existing = defaultStylesByTagName[tagName];
    if (!existing) {
        const { foreignObject, document: document2 } = getDefaultStyleFrame();
        const element = document2.createElement(tagName);
        foreignObject.appendChild(element);
        existing = element.computedStyleMap ? styleFromComputedStyleMap(element.computedStyleMap(), defaultStyleReadOptions) : styleFromComputedStyle((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element), defaultStyleReadOptions);
        foreignObject.removeChild(element);
        defaultStylesByTagName[tagName] = existing;
    }
    return existing;
}
;
 //# sourceMappingURL=StyleEmbedder.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/embedMedia.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "embedMedia",
    ()=>embedMedia
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/media.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/domUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/fetchCache.mjs [app-client] (ecmascript)");
;
;
;
function copyAttrs(source, target) {
    const attrs = Array.from(source.attributes);
    attrs.forEach((attr)=>{
        target.setAttribute(attr.name, attr.value);
    });
}
function replace(original, replacement) {
    original.replaceWith(replacement);
    return replacement;
}
async function createImage(dataUrl, cloneAttributesFrom) {
    const image = document.createElement("img");
    if (cloneAttributesFrom) {
        copyAttrs(cloneAttributesFrom, image);
    }
    image.setAttribute("src", dataUrl ?? "data:");
    image.setAttribute("decoding", "sync");
    image.setAttribute("loading", "eager");
    try {
        await image.decode();
    } catch  {}
    return image;
}
async function getCanvasReplacement(canvas) {
    try {
        const dataURL = canvas.toDataURL();
        return await createImage(dataURL, canvas);
    } catch  {
        return await createImage(null, canvas);
    }
}
async function getVideoReplacement(video) {
    try {
        const dataUrl = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].getVideoFrameAsDataUrl(video);
        return createImage(dataUrl, video);
    } catch (err) {
        console.error("Could not get video frame", err);
    }
    if (video.poster) {
        const dataUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resourceToDataUrl"])(video.poster);
        return createImage(dataUrl, video);
    }
    return createImage(null, video);
}
async function embedMedia(node) {
    if (node instanceof HTMLCanvasElement) {
        return replace(node, await getCanvasReplacement(node));
    } else if (node instanceof HTMLVideoElement) {
        return replace(node, await getVideoReplacement(node));
    } else if (node instanceof HTMLImageElement) {
        const src = node.currentSrc || node.src;
        const dataUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$fetchCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resourceToDataUrl"])(src);
        node.setAttribute("src", dataUrl ?? "data:");
        node.setAttribute("decoding", "sync");
        node.setAttribute("loading", "eager");
        try {
            await node.decode();
        } catch  {}
        return node;
    } else if (node instanceof HTMLInputElement) {
        node.setAttribute("value", node.value);
    } else if (node instanceof HTMLTextAreaElement) {
        node.textContent = node.value;
    }
    await Promise.all(Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$domUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRenderedChildren"])(node), (child)=>embedMedia(child)));
}
;
 //# sourceMappingURL=embedMedia.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/ExportDelay.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExportDelay",
    ()=>ExportDelay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _waitUntil_dec, _init;
;
_waitUntil_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
];
class ExportDelay {
    constructor(maxDelayTimeMs){
        this.maxDelayTimeMs = maxDelayTimeMs;
        __runInitializers(_init, 5, this);
        __publicField(this, "isResolved", false);
        __publicField(this, "promisesToWaitFor", []);
    }
    waitUntil(promise) {
        if (this.isResolved) {
            throw new Error("Cannot `waitUntil` - the export has already been resolved. Make sure to call `waitUntil` as soon as possible during an export - ie within the first react effect after rendering.");
        }
        this.promisesToWaitFor.push(promise.catch((err)=>console.error("Error while waiting for export:", err)));
    }
    async resolvePromises() {
        let lastLength = null;
        while(this.promisesToWaitFor.length !== lastLength){
            lastLength = this.promisesToWaitFor.length;
            await Promise.allSettled(this.promisesToWaitFor);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(0);
        }
    }
    async resolve() {
        const timeoutPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(this.maxDelayTimeMs).then(()=>"timeout");
        const resolvePromise = this.resolvePromises().then(()=>"resolved");
        const result = await Promise.race([
            timeoutPromise,
            resolvePromise
        ]);
        if (result === "timeout") {
            console.warn("[tldraw] Export delay timed out after ${this.maxDelayTimeMs}ms");
        }
        this.isResolved = true;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "waitUntil", _waitUntil_dec, ExportDelay);
__decoratorMetadata(_init, ExportDelay);
;
 //# sourceMappingURL=ExportDelay.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/getSvgJsx.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getExportDefaultBounds",
    ()=>getExportDefaultBounds,
    "getSvgJsx",
    ()=>getSvgJsx
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useAtom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useAtom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/styles/TLColorStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$ErrorBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/ErrorBoundary.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$Shape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/Shape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$types$2f$SvgExportContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/types/SvgExportContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEvent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSafeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useSafeId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$ExportDelay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/ExportDelay.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getSvgJsx(editor, ids, opts = {}) {
    if (!window.document) throw Error("No document");
    const { scale = 1, // should we include the background in the export? or is it transparent?
    background = editor.getInstanceState().exportBackground, padding = editor.options.defaultSvgPadding, preserveAspectRatio } = opts;
    const isDarkMode = opts.darkMode ?? editor.user.getIsDarkMode();
    const shapeIdsToInclude = editor.getShapeAndDescendantIds(ids);
    const renderingShapes = editor.getUnorderedRenderingShapes(false).filter(({ id })=>shapeIdsToInclude.has(id));
    const singleFrameShapeId = ids.length === 1 && editor.isShapeOfType(editor.getShape(ids[0]), "frame") ? ids[0] : null;
    let bbox = null;
    if (opts.bounds) {
        bbox = opts.bounds.clone().expandBy(padding);
    } else {
        bbox = getExportDefaultBounds(editor, renderingShapes, padding, singleFrameShapeId);
    }
    if (!bbox) return;
    const w = bbox.width * scale;
    const h = bbox.height * scale;
    try {
        document.body.focus?.();
    } catch  {}
    const exportDelay = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$ExportDelay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExportDelay"](editor.options.maxExportDelayMs);
    const initialEffectPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["promiseWithResolve"])();
    exportDelay.waitUntil(initialEffectPromise);
    const svg = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SvgExport, {
        editor,
        preserveAspectRatio,
        scale,
        pixelRatio: opts.pixelRatio ?? null,
        bbox,
        background,
        singleFrameShapeId,
        isDarkMode,
        renderingShapes,
        onMount: initialEffectPromise.resolve,
        waitUntil: exportDelay.waitUntil
    });
    return {
        jsx: svg,
        width: w,
        height: h,
        exportDelay
    };
}
function getExportDefaultBounds(editor, renderingShapes, padding, singleFrameShapeId) {
    let isBoundedByContainer = false;
    let bbox = null;
    for (const { id } of renderingShapes){
        const maskedPageBounds = editor.getShapeMaskedPageBounds(id);
        if (!maskedPageBounds) continue;
        const shape = editor.getShape(id);
        const isContainer = editor.getShapeUtil(shape).isExportBoundsContainer(shape);
        if (bbox) {
            if (isContainer && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].ContainsApproximately(maskedPageBounds, bbox)) {
                isBoundedByContainer = true;
                bbox = maskedPageBounds.clone();
            } else {
                if (isBoundedByContainer && !__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].ContainsApproximately(bbox, maskedPageBounds)) {
                    isBoundedByContainer = false;
                }
                bbox.union(maskedPageBounds);
            }
        } else {
            isBoundedByContainer = isContainer;
            bbox = maskedPageBounds.clone();
        }
    }
    if (!bbox) return null;
    if (!singleFrameShapeId && !isBoundedByContainer) {
        bbox.expandBy(padding);
    }
    return bbox;
}
function SvgExport({ editor, preserveAspectRatio, scale, pixelRatio, bbox, background, singleFrameShapeId, isDarkMode, renderingShapes, onMount, waitUntil }) {
    const masksId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSafeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUniqueSafeId"])();
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultColorTheme"])({
        isDarkMode
    });
    const stateAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useAtom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])("export state", {
        defsById: {},
        shapeElements: null
    });
    const { defsById, shapeElements } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])(stateAtom);
    const addExportDef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])({
        "SvgExport.useEvent[addExportDef]": (def)=>{
            stateAtom.update({
                "SvgExport.useEvent[addExportDef]": (state)=>{
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"])(state.defsById, def.key)) return state;
                    const promise = Promise.resolve(def.getElement());
                    waitUntil(promise.then({
                        "SvgExport.useEvent[addExportDef]": (result)=>{
                            stateAtom.update({
                                "SvgExport.useEvent[addExportDef]": (state2)=>({
                                        ...state2,
                                        defsById: {
                                            ...state2.defsById,
                                            [def.key]: {
                                                pending: false,
                                                element: result
                                            }
                                        }
                                    })
                            }["SvgExport.useEvent[addExportDef]"]);
                        }
                    }["SvgExport.useEvent[addExportDef]"]));
                    return {
                        ...state,
                        defsById: {
                            ...state.defsById,
                            [def.key]: {
                                pending: true,
                                element: promise
                            }
                        }
                    };
                }
            }["SvgExport.useEvent[addExportDef]"]);
        }
    }["SvgExport.useEvent[addExportDef]"]);
    const exportContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SvgExport.useMemo[exportContext]": ()=>({
                isDarkMode,
                waitUntil,
                addExportDef,
                scale,
                pixelRatio,
                async resolveAssetUrl (assetId, width) {
                    const asset = editor.getAsset(assetId);
                    if (!asset || asset.type !== "image" && asset.type !== "video") return null;
                    return await editor.resolveAssetUrl(assetId, {
                        screenScale: scale * (width / asset.props.w),
                        shouldResolveToOriginal: pixelRatio === null,
                        dpr: pixelRatio ?? void 0
                    });
                }
            })
    }["SvgExport.useMemo[exportContext]"], [
        isDarkMode,
        waitUntil,
        addExportDef,
        scale,
        pixelRatio,
        editor
    ]);
    const didRenderRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SvgExport.useLayoutEffect": ()=>{
            if (didRenderRef.current) {
                throw new Error("SvgExport should only render once - do not use with react strict mode");
            }
            didRenderRef.current = true;
            ({
                "SvgExport.useLayoutEffect": async ()=>{
                    const shapeDefs = {};
                    const unorderedShapeElementPromises = renderingShapes.map({
                        "SvgExport.useLayoutEffect.unorderedShapeElementPromises": async ({ id, opacity, index, backgroundIndex })=>{
                            if (id === singleFrameShapeId) return [];
                            const shape = editor.getShape(id);
                            if (editor.isShapeOfType(shape, "group")) return [];
                            const elements = [];
                            const util = editor.getShapeUtil(shape);
                            if (util.toSvg || util.toBackgroundSvg) {
                                const [toSvgResult, toBackgroundSvgResult] = await Promise.all([
                                    util.toSvg?.(shape, exportContext),
                                    util.toBackgroundSvg?.(shape, exportContext)
                                ]);
                                const pageTransform = editor.getShapePageTransform(shape);
                                let pageTransformString = pageTransform.toCssString();
                                let scale2 = 1;
                                if ("scale" in shape.props) {
                                    if (shape.props.scale !== 1) {
                                        scale2 = shape.props.scale;
                                        pageTransformString = `${pageTransformString} scale(${shape.props.scale}, ${shape.props.scale})`;
                                    }
                                }
                                const pageMask = editor.getShapeMask(shape.id);
                                const shapeMask = pageMask ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].From(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Inverse(pageTransform)).applyToPoints(pageMask) : null;
                                const shapeMaskId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSafeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["suffixSafeId"])(masksId, shape.id);
                                if (shapeMask) {
                                    shapeDefs[shapeMaskId] = {
                                        pending: false,
                                        element: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("clipPath", {
                                            id: shapeMaskId,
                                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                                d: `M${shapeMask.map({
                                                    "SvgExport.useLayoutEffect.unorderedShapeElementPromises": ({ x, y })=>`${x / scale2},${y / scale2}`
                                                }["SvgExport.useLayoutEffect.unorderedShapeElementPromises"]).join("L")}Z`
                                            })
                                        })
                                    };
                                }
                                if (toSvgResult) {
                                    elements.push({
                                        zIndex: index,
                                        element: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                                            transform: pageTransformString,
                                            opacity,
                                            clipPath: pageMask ? `url(#${shapeMaskId})` : void 0,
                                            children: toSvgResult
                                        }, `fg_${shape.id}`)
                                    });
                                }
                                if (toBackgroundSvgResult) {
                                    elements.push({
                                        zIndex: backgroundIndex,
                                        element: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                                            transform: pageTransformString,
                                            opacity,
                                            clipPath: pageMask ? `url(#${shapeMaskId})` : void 0,
                                            children: toBackgroundSvgResult
                                        }, `bg_${shape.id}`)
                                    });
                                }
                            } else {
                                elements.push({
                                    zIndex: index,
                                    element: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ForeignObjectShape, {
                                        shape,
                                        util,
                                        component: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$Shape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InnerShape"],
                                        className: "tl-shape",
                                        bbox,
                                        opacity
                                    }, `fg_${shape.id}`)
                                });
                                if (util.backgroundComponent) {
                                    elements.push({
                                        zIndex: backgroundIndex,
                                        element: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ForeignObjectShape, {
                                            shape,
                                            util,
                                            component: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$Shape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InnerShapeBackground"],
                                            className: "tl-shape tl-shape-background",
                                            bbox,
                                            opacity
                                        }, `bg_${shape.id}`)
                                    });
                                }
                            }
                            return elements;
                        }
                    }["SvgExport.useLayoutEffect.unorderedShapeElementPromises"]);
                    const unorderedShapeElements = (await Promise.all(unorderedShapeElementPromises)).flat();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])({
                        "SvgExport.useLayoutEffect": ()=>{
                            stateAtom.update({
                                "SvgExport.useLayoutEffect": (state)=>({
                                        ...state,
                                        shapeElements: unorderedShapeElements.sort({
                                            "SvgExport.useLayoutEffect": (a, b)=>a.zIndex - b.zIndex
                                        }["SvgExport.useLayoutEffect"]).map({
                                            "SvgExport.useLayoutEffect": ({ element })=>element
                                        }["SvgExport.useLayoutEffect"]),
                                        defsById: {
                                            ...state.defsById,
                                            ...shapeDefs
                                        }
                                    })
                            }["SvgExport.useLayoutEffect"]);
                        }
                    }["SvgExport.useLayoutEffect"]);
                }
            })["SvgExport.useLayoutEffect"]();
        }
    }["SvgExport.useLayoutEffect"], [
        bbox,
        editor,
        exportContext,
        masksId,
        renderingShapes,
        singleFrameShapeId,
        stateAtom
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SvgExport.useEffect": ()=>{
            const fontsInUse = /* @__PURE__ */ new Set();
            for (const { id } of renderingShapes){
                for (const font of editor.fonts.getShapeFontFaces(id)){
                    fontsInUse.add(font);
                }
            }
            for (const font of fontsInUse){
                addExportDef({
                    key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                    getElement: {
                        "SvgExport.useEffect": async ()=>{
                            const declaration = await editor.fonts.toEmbeddedCssDeclaration(font);
                            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("style", {
                                nonce: editor.options.nonce,
                                children: declaration
                            });
                        }
                    }["SvgExport.useEffect"]
                });
            }
        }
    }["SvgExport.useEffect"], [
        editor,
        renderingShapes,
        addExportDef
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SvgExport.useEffect": ()=>{
            if (shapeElements === null) return;
            onMount();
        }
    }["SvgExport.useEffect"], [
        onMount,
        shapeElements
    ]);
    let backgroundColor = background ? theme.background : "transparent";
    if (singleFrameShapeId && background) {
        const frameShapeUtil = editor.getShapeUtil("frame");
        if (frameShapeUtil?.options.showColors) {
            const shape = editor.getShape(singleFrameShapeId);
            backgroundColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$styles$2f$TLColorStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getColorValue"])(theme, shape.props.color, "frameFill");
        } else {
            backgroundColor = theme.solid;
        }
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$types$2f$SvgExportContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SvgExportContextProvider"], {
        editor,
        context: exportContext,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
            preserveAspectRatio,
            direction: "ltr",
            width: bbox.width * scale,
            height: bbox.height * scale,
            viewBox: `${bbox.minX} ${bbox.minY} ${bbox.width} ${bbox.height}`,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            style: {
                backgroundColor
            },
            "data-color-mode": isDarkMode ? "dark" : "light",
            className: `tl-container tl-theme__force-sRGB ${isDarkMode ? "tl-theme__dark" : "tl-theme__light"}`,
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("defs", {
                    children: Object.entries(defsById).map(([key, def])=>def.pending ? null : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: def.element
                        }, key))
                }),
                shapeElements
            ]
        })
    });
}
function ForeignObjectShape({ shape, util, className, component: Component, bbox, opacity }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const transform = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Translate(-bbox.minX, -bbox.minY).multiply(editor.getShapePageTransform(shape.id));
    const bounds = editor.getShapeGeometry(shape.id).bounds;
    const width = Math.max(bounds.width, 1);
    const height = Math.max(bounds.height, 1);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$ErrorBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorBoundary"], {
        fallback: ()=>null,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("foreignObject", {
            x: bbox.minX,
            y: bbox.minY,
            width: bbox.w,
            height: bbox.h,
            className: "tl-shape-foreign-object tl-export-embed-styles",
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className,
                "data-shape-type": shape.type,
                style: {
                    clipPath: editor.getShapeClipPath(shape.id),
                    transform: transform.toCssString(),
                    width,
                    height,
                    opacity
                },
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
                    shape,
                    util
                })
            })
        })
    });
}
;
 //# sourceMappingURL=getSvgJsx.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/exportToSvg.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "exportToSvg",
    ()=>exportToSvg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react-dom/client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$FontEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/FontEmbedder.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$StyleEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/StyleEmbedder.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$embedMedia$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/embedMedia.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$getSvgJsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/getSvgJsx.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
let idCounter = 1;
async function exportToSvg(editor, shapeIds, opts = {}) {
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$getSvgJsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSvgJsx"])(editor, shapeIds, opts);
    if (!result) return void 0;
    const container = editor.getContainer();
    const renderTarget = document.createElement("div");
    renderTarget.className = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$FontEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SVG_EXPORT_CLASSNAME"];
    renderTarget.inert = true;
    renderTarget.tabIndex = -1;
    Object.assign(renderTarget.style, {
        position: "absolute",
        top: "0px",
        left: "0px",
        width: result.width + "px",
        height: result.height + "px",
        pointerEvents: "none",
        opacity: 0
    });
    container.appendChild(renderTarget);
    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRoot"])(renderTarget, {
        identifierPrefix: `export_${idCounter++}_`
    });
    try {
        await Promise.resolve();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(()=>{
            root.render(result.jsx);
        });
        await result.exportDelay.resolve();
        const svg = renderTarget.firstElementChild;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(svg instanceof SVGSVGElement, "Expected an SVG element");
        await applyChangesToForeignObjects(svg);
        return {
            svg,
            width: result.width,
            height: result.height
        };
    } finally{
        setTimeout(()=>{
            root.unmount();
            container.removeChild(renderTarget);
        }, 0);
    }
}
async function applyChangesToForeignObjects(svg) {
    const foreignObjectChildren = [
        ...svg.querySelectorAll("foreignObject.tl-export-embed-styles > *")
    ];
    if (!foreignObjectChildren.length) return;
    const styleEmbedder = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$StyleEmbedder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyleEmbedder"](svg);
    try {
        styleEmbedder.fonts.startFindingCurrentDocumentFontFaces();
        await Promise.all(foreignObjectChildren.map((el)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$embedMedia$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embedMedia"])(el)));
        for (const el of foreignObjectChildren){
            styleEmbedder.readRootElementStyles(el);
        }
        await styleEmbedder.fetchResources();
        const fontCss = await styleEmbedder.getFontFaceCss();
        styleEmbedder.unwrapCustomElements();
        const pseudoCss = styleEmbedder.embedStyles();
        if (fontCss || pseudoCss) {
            const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
            style.textContent = `${fontCss}
${pseudoCss}`;
            svg.prepend(style);
        }
    } finally{
        styleEmbedder.dispose();
    }
}
;
 //# sourceMappingURL=exportToSvg.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/getSvgAsImage.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSvgAsImage",
    ()=>getSvgAsImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/png.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$browserCanvasMaxSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/browserCanvasMaxSize.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/debug-flags.mjs [app-client] (ecmascript)");
;
;
;
;
async function getSvgAsImage(svgString, options) {
    const { type, width, height, quality = 1, pixelRatio = 2 } = options;
    let [clampedWidth, clampedHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$browserCanvasMaxSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampToBrowserMaxCanvasSize"])(width * pixelRatio, height * pixelRatio);
    clampedWidth = Math.floor(clampedWidth);
    clampedHeight = Math.floor(clampedHeight);
    const effectiveScale = clampedWidth / width;
    const svgUrl = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(new Blob([
        svgString
    ], {
        type: "image/svg+xml"
    }));
    const canvas = await new Promise((resolve)=>{
        const image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"])();
        image.crossOrigin = "anonymous";
        image.onload = async ()=>{
            if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isSafari) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(250);
            }
            const canvas2 = document.createElement("canvas");
            const ctx = canvas2.getContext("2d");
            canvas2.width = clampedWidth;
            canvas2.height = clampedHeight;
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.drawImage(image, 0, 0, clampedWidth, clampedHeight);
            URL.revokeObjectURL(svgUrl);
            resolve(canvas2);
        };
        image.onerror = ()=>{
            resolve(null);
        };
        image.src = svgUrl;
    });
    if (!canvas) return null;
    const blob = await new Promise((resolve)=>canvas.toBlob((blob2)=>{
            if (!blob2 || __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugFlags"].throwToBlob.get()) {
                resolve(null);
            }
            resolve(blob2);
        }, "image/" + type, quality));
    if (!blob) return null;
    if (type === "png") {
        const view = new DataView(await blob.arrayBuffer());
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PngHelpers"].setPhysChunk(view, effectiveScale, {
            type: "image/" + type
        });
    } else {
        return blob;
    }
}
;
 //# sourceMappingURL=getSvgAsImage.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/options.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultTldrawOptions",
    ()=>defaultTldrawOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/constants.mjs [app-client] (ecmascript)");
;
;
const defaultTldrawOptions = {
    maxShapesPerPage: 4e3,
    maxFilesAtOnce: 100,
    maxPages: 40,
    animationMediumMs: 320,
    followChaseViewportSnap: 2,
    doubleClickDurationMs: 450,
    multiClickDurationMs: 200,
    coarseDragDistanceSquared: 36,
    // 6 squared
    dragDistanceSquared: 16,
    // 4 squared
    uiDragDistanceSquared: 16,
    // 4 squared
    // it's really easy to accidentally drag from the toolbar on mobile, so we use a much larger
    // threshold than usual here to try and prevent accidental drags.
    uiCoarseDragDistanceSquared: 625,
    // 25 squared
    defaultSvgPadding: 32,
    cameraSlideFriction: 0.09,
    gridSteps: [
        {
            min: -1,
            mid: 0.15,
            step: 64
        },
        {
            min: 0.05,
            mid: 0.375,
            step: 16
        },
        {
            min: 0.15,
            mid: 1,
            step: 4
        },
        {
            min: 0.7,
            mid: 2.5,
            step: 1
        }
    ],
    collaboratorInactiveTimeoutMs: 6e4,
    collaboratorIdleTimeoutMs: 3e3,
    collaboratorCheckIntervalMs: 1200,
    cameraMovingTimeoutMs: 64,
    hitTestMargin: 8,
    edgeScrollDelay: 200,
    edgeScrollEaseDuration: 200,
    edgeScrollSpeed: 25,
    edgeScrollDistance: 8,
    coarsePointerWidth: 12,
    coarseHandleRadius: 20,
    handleRadius: 12,
    longPressDurationMs: 500,
    textShadowLod: 0.35,
    adjacentShapeMargin: 10,
    flattenImageBoundsExpand: 64,
    flattenImageBoundsPadding: 16,
    laserDelayMs: 1200,
    laserFadeoutMs: 500,
    maxExportDelayMs: 5e3,
    tooltipDelayMs: 700,
    temporaryAssetPreviewLifetimeMs: 18e4,
    actionShortcutsLocation: "swap",
    createTextOnCanvasDoubleClick: true,
    exportProvider: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"],
    enableToolbarKeyboardShortcuts: true,
    maxFontsToLoadBeforeRender: Infinity,
    nonce: void 0,
    debouncedZoom: true,
    debouncedZoomThreshold: 500,
    spacebarPanning: true,
    zoomToFitPadding: 128,
    snapThreshold: 8,
    camera: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CAMERA_OPTIONS"],
    text: {},
    deepLinks: void 0,
    quickZoomPreservesScreenBounds: true
};
;
 //# sourceMappingURL=options.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FLAGS",
    ()=>FLAGS,
    "LicenseManager",
    ()=>LicenseManager,
    "PROPERTIES",
    ()=>PROPERTIES,
    "getLicenseState",
    ()=>getLicenseState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/assets.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$licensing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/licensing.mjs [app-client] (ecmascript)");
;
;
;
;
const GRACE_PERIOD_DAYS = 30;
const FLAGS = {
    // -- MUTUALLY EXCLUSIVE FLAGS --
    // Annual means the license expires after a time period, usually 1 year.
    ANNUAL_LICENSE: 1,
    // Perpetual means the license never expires up to the max supported version.
    PERPETUAL_LICENSE: 1 << 1,
    // -- ADDITIVE FLAGS --
    // Internal means the license is for internal use only.
    INTERNAL_LICENSE: 1 << 2,
    // Watermark means the product is watermarked.
    WITH_WATERMARK: 1 << 3,
    // Evaluation means the license is for evaluation purposes only.
    EVALUATION_LICENSE: 1 << 4,
    // Native means the license is for native apps which switches
    // on special-case logic.
    NATIVE_LICENSE: 1 << 5
};
const HIGHEST_FLAG = Math.max(...Object.values(FLAGS));
const PROPERTIES = {
    ID: 0,
    HOSTS: 1,
    FLAGS: 2,
    EXPIRY_DATE: 3
};
const NUMBER_OF_KNOWN_PROPERTIES = Object.keys(PROPERTIES).length;
const LICENSE_EMAIL = "sales@tldraw.com";
const WATERMARK_TRACK_SRC = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/watermarks/watermark-track.svg`;
class LicenseManager {
    publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHJh0uUfxHtCGyerXmmatE368Hd9rI6LH9oPDQihnaCryRFWEVeOvf9U/SPbyxX74LFyJs5tYeAHq5Nc0Ax25LQ";
    isDevelopment;
    isTest;
    isCryptoAvailable;
    state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("license state", "pending");
    verbose = true;
    constructor(licenseKey, testPublicKey){
        this.isTest = ("TURBOPACK compile-time value", "development") === "test";
        this.isDevelopment = this.getIsDevelopment();
        this.publicKey = testPublicKey || this.publicKey;
        this.isCryptoAvailable = !!crypto.subtle;
        this.getLicenseFromKey(licenseKey).then((result)=>{
            const licenseState = getLicenseState(result, (messages)=>this.outputMessages(messages), this.isDevelopment);
            this.maybeTrack(result, licenseState);
            this.state.set(licenseState);
        }).catch((error)=>{
            console.error("License validation failed:", error);
            this.state.set("unlicensed");
        });
    }
    getIsDevelopment() {
        return ![
            "https:",
            "vscode-webview:"
        ].includes(window.location.protocol) || window.location.hostname === "localhost" || ("TURBOPACK compile-time value", "development") !== "production";
    }
    getTrackType(result, licenseState) {
        if (licenseState === "unlicensed-production") {
            return "unlicensed";
        }
        if (this.isDevelopment) {
            return null;
        }
        if (!result.isLicenseParseable) {
            return null;
        }
        if (result.isEvaluationLicense) {
            return "evaluation";
        }
        if (licenseState === "licensed-with-watermark") {
            return "with_watermark";
        }
        return null;
    }
    maybeTrack(result, licenseState) {
        const trackType = this.getTrackType(result, licenseState);
        if (!trackType) {
            return;
        }
        const url = new URL(WATERMARK_TRACK_SRC);
        url.searchParams.set("version", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["version"]);
        url.searchParams.set("license_type", trackType);
        if ("license" in result) {
            url.searchParams.set("license_id", result.license.id);
            const sku = this.isFlagEnabled(result.license.flags, FLAGS.EVALUATION_LICENSE) ? "evaluation" : this.isFlagEnabled(result.license.flags, FLAGS.ANNUAL_LICENSE) ? "annual" : this.isFlagEnabled(result.license.flags, FLAGS.PERPETUAL_LICENSE) ? "perpetual" : "unknown";
            url.searchParams.set("sku", sku);
        }
        url.searchParams.set("url", window.location.href);
        if ("TURBOPACK compile-time truthy", 1) {
            url.searchParams.set("environment", ("TURBOPACK compile-time value", "development"));
        }
        fetch(url.toString());
    }
    async extractLicenseKey(licenseKey) {
        const [data, signature] = licenseKey.split(".");
        const [prefix, encodedData] = data.split("/");
        if (!prefix.startsWith("tldraw-")) {
            throw new Error(`Unsupported prefix '${prefix}'`);
        }
        const publicCryptoKey = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$licensing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["importPublicKey"])(this.publicKey);
        let isVerified;
        try {
            isVerified = await crypto.subtle.verify({
                name: "ECDSA",
                hash: {
                    name: "SHA-256"
                }
            }, publicCryptoKey, new Uint8Array((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$licensing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["str2ab"])(atob(signature))), new Uint8Array((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$licensing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["str2ab"])(atob(encodedData))));
        } catch (e) {
            console.error(e);
            throw new Error("Could not perform signature validation");
        }
        if (!isVerified) {
            throw new Error("Invalid signature");
        }
        let decodedData;
        try {
            decodedData = JSON.parse(atob(encodedData));
        } catch  {
            throw new Error("Could not parse object");
        }
        if (decodedData.length > NUMBER_OF_KNOWN_PROPERTIES) {
            this.outputMessages([
                "License key contains some unknown properties.",
                "You may want to update tldraw packages to a newer version to get access to new functionality."
            ]);
        }
        return {
            id: decodedData[PROPERTIES.ID],
            hosts: decodedData[PROPERTIES.HOSTS],
            flags: decodedData[PROPERTIES.FLAGS],
            expiryDate: decodedData[PROPERTIES.EXPIRY_DATE]
        };
    }
    async getLicenseFromKey(licenseKey) {
        if (!licenseKey) {
            if (!this.isDevelopment) {
                this.outputNoLicenseKeyProvided();
            }
            return {
                isLicenseParseable: false,
                reason: "no-key-provided"
            };
        }
        if (this.isDevelopment && !this.isCryptoAvailable) {
            if (this.verbose) {
                console.log("tldraw: you seem to be in a development environment that does not support crypto. License not verified.");
                console.log("You should check that this works in production separately.");
            }
            return {
                isLicenseParseable: false,
                reason: "has-key-development-mode"
            };
        }
        let cleanedLicenseKey = licenseKey.replace(/[\u200B-\u200D\uFEFF]/g, "");
        cleanedLicenseKey = cleanedLicenseKey.replace(/\r?\n|\r/g, "");
        try {
            const licenseInfo = await this.extractLicenseKey(cleanedLicenseKey);
            const expiryDate = new Date(licenseInfo.expiryDate);
            const isAnnualLicense = this.isFlagEnabled(licenseInfo.flags, FLAGS.ANNUAL_LICENSE);
            const isPerpetualLicense = this.isFlagEnabled(licenseInfo.flags, FLAGS.PERPETUAL_LICENSE);
            const isEvaluationLicense = this.isFlagEnabled(licenseInfo.flags, FLAGS.EVALUATION_LICENSE);
            const daysSinceExpiry = this.getDaysSinceExpiry(expiryDate);
            const result = {
                license: licenseInfo,
                isLicenseParseable: true,
                isDevelopment: this.isDevelopment,
                isDomainValid: this.isDomainValid(licenseInfo),
                expiryDate,
                isAnnualLicense,
                isAnnualLicenseExpired: isAnnualLicense && this.isAnnualLicenseExpired(expiryDate),
                isPerpetualLicense,
                isPerpetualLicenseExpired: isPerpetualLicense && this.isPerpetualLicenseExpired(expiryDate),
                isInternalLicense: this.isFlagEnabled(licenseInfo.flags, FLAGS.INTERNAL_LICENSE),
                isNativeLicense: this.isNativeLicense(licenseInfo),
                isLicensedWithWatermark: this.isFlagEnabled(licenseInfo.flags, FLAGS.WITH_WATERMARK),
                isEvaluationLicense,
                isEvaluationLicenseExpired: isEvaluationLicense && this.isEvaluationLicenseExpired(expiryDate),
                daysSinceExpiry
            };
            this.outputLicenseInfoIfNeeded(result);
            return result;
        } catch (e) {
            this.outputInvalidLicenseKey(e.message);
            return {
                isLicenseParseable: false,
                reason: "invalid-license-key"
            };
        }
    }
    isDomainValid(licenseInfo) {
        const currentHostname = window.location.hostname.toLowerCase();
        return licenseInfo.hosts.some((host)=>{
            const normalizedHostOrUrlRegex = host.toLowerCase().trim();
            if (normalizedHostOrUrlRegex === currentHostname || `www.${normalizedHostOrUrlRegex}` === currentHostname || normalizedHostOrUrlRegex === `www.${currentHostname}`) {
                return true;
            }
            if (host === "*") {
                return true;
            }
            if (this.isNativeLicense(licenseInfo)) {
                return new RegExp(normalizedHostOrUrlRegex).test(window.location.href);
            }
            if (host.includes("*")) {
                const globToRegex = new RegExp(host.replace(/\*/g, ".*?"));
                return globToRegex.test(currentHostname) || globToRegex.test(`www.${currentHostname}`);
            }
            if (window.location.protocol === "vscode-webview:") {
                const currentUrl = new URL(window.location.href);
                const extensionId = currentUrl.searchParams.get("extensionId");
                if (normalizedHostOrUrlRegex === extensionId) {
                    return true;
                }
            }
            return false;
        });
    }
    isNativeLicense(licenseInfo) {
        return this.isFlagEnabled(licenseInfo.flags, FLAGS.NATIVE_LICENSE);
    }
    getExpirationDateWithoutGracePeriod(expiryDate) {
        return new Date(expiryDate.getFullYear(), expiryDate.getMonth(), expiryDate.getDate());
    }
    getExpirationDateWithGracePeriod(expiryDate) {
        return new Date(expiryDate.getFullYear(), expiryDate.getMonth(), expiryDate.getDate() + GRACE_PERIOD_DAYS + 1);
    }
    isAnnualLicenseExpired(expiryDate) {
        const expiration = this.getExpirationDateWithGracePeriod(expiryDate);
        return /* @__PURE__ */ new Date() >= expiration;
    }
    isPerpetualLicenseExpired(expiryDate) {
        const expiration = this.getExpirationDateWithGracePeriod(expiryDate);
        const dates = {
            major: new Date(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["publishDates"].major),
            minor: new Date(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["publishDates"].minor)
        };
        return dates.major >= expiration || dates.minor >= expiration;
    }
    getDaysSinceExpiry(expiryDate) {
        const now = /* @__PURE__ */ new Date();
        const expiration = this.getExpirationDateWithoutGracePeriod(expiryDate);
        const diffTime = now.getTime() - expiration.getTime();
        const diffDays = Math.floor(diffTime / (1e3 * 60 * 60 * 24));
        return Math.max(0, diffDays);
    }
    isEvaluationLicenseExpired(expiryDate) {
        const now = /* @__PURE__ */ new Date();
        const expiration = this.getExpirationDateWithoutGracePeriod(expiryDate);
        return now >= expiration;
    }
    isFlagEnabled(flags, flag) {
        return (flags & flag) === flag;
    }
    outputNoLicenseKeyProvided() {}
    outputInvalidLicenseKey(msg) {
        this.outputMessages([
            "Invalid tldraw license key",
            `Reason: ${msg}`
        ]);
    }
    outputLicenseInfoIfNeeded(result) {
        if (result.license.flags >= HIGHEST_FLAG * 2) {
            this.outputMessages([
                "Warning: This tldraw license contains some unknown flags.",
                "This will still work, however, you may want to update tldraw packages to a newer version to get access to new functionality."
            ], "warning");
        }
    }
    outputMessages(messages, type = "error") {
        if (this.isTest) return;
        if (this.verbose) {
            this.outputDelimiter(type);
            for (const message of messages){
                const bgColor = type === "warning" ? "orange" : "crimson";
                console.log(`%c${message}`, `color: white; background: ${bgColor}; padding: 2px; border-radius: 3px;`);
            }
            this.outputDelimiter(type);
        }
    }
    outputDelimiter(type = "error") {
        const bgColor = type === "warning" ? "orange" : "crimson";
        console.log("%c-------------------------------------------------------------------", `color: white; background: ${bgColor}; padding: 2px; border-radius: 3px;`);
    }
    static className = "tl-watermark_SEE-LICENSE";
}
function getLicenseState(result, outputMessages, isDevelopment) {
    if (!result.isLicenseParseable) {
        if (isDevelopment) {
            return "unlicensed";
        }
        if (result.reason === "no-key-provided") {
            outputMessages([
                "No tldraw license key provided!",
                "A license is required for production deployments.",
                `Please reach out to ${LICENSE_EMAIL} to purchase a license.`
            ]);
        } else {
            outputMessages([
                "Invalid license key. tldraw requires a valid license for production use.",
                `Please reach out to ${LICENSE_EMAIL} to purchase a license.`
            ]);
        }
        return "unlicensed-production";
    }
    if (!result.isDomainValid && !result.isDevelopment) {
        outputMessages([
            "License key is not valid for this domain.",
            "A license is required for production deployments.",
            `Please reach out to ${LICENSE_EMAIL} to purchase a license.`
        ]);
        return "unlicensed-production";
    }
    if (result.isEvaluationLicense) {
        if (result.isEvaluationLicenseExpired) {
            outputMessages([
                "Your tldraw evaluation license has expired!",
                `Please reach out to ${LICENSE_EMAIL} to purchase a full license.`
            ]);
            return "expired";
        } else {
            return "licensed";
        }
    }
    if (result.isPerpetualLicenseExpired || result.isAnnualLicenseExpired) {
        outputMessages([
            "Your tldraw license has been expired for more than 30 days!",
            `Please reach out to ${LICENSE_EMAIL} to renew your license.`
        ]);
        return "expired";
    }
    const daysSinceExpiry = result.daysSinceExpiry;
    if (daysSinceExpiry > 0 && !result.isEvaluationLicense) {
        outputMessages([
            "Your tldraw license has expired.",
            `License expired ${daysSinceExpiry} days ago.`,
            `Please reach out to ${LICENSE_EMAIL} to renew your license.`
        ]);
        return "licensed";
    }
    if (result.isLicensedWithWatermark) {
        return "licensed-with-watermark";
    }
    return "licensed";
}
;
 //# sourceMappingURL=LicenseManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseProvider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LICENSE_TIMEOUT",
    ()=>LICENSE_TIMEOUT,
    "LicenseContext",
    ()=>LicenseContext,
    "LicenseProvider",
    ()=>LicenseProvider,
    "useLicenseContext",
    ()=>useLicenseContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseManager.mjs [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseProvider.mjs")}`;
    }
};
;
;
;
;
const LicenseContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({});
const useLicenseContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LicenseContext);
function shouldHideEditorAfterDelay(licenseState) {
    return licenseState === "expired" || licenseState === "unlicensed-production";
}
const LICENSE_TIMEOUT = 5e3;
function LicenseProvider({ licenseKey = getLicenseKeyFromEnv() ?? void 0, children }) {
    const [licenseManager] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "LicenseProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LicenseManager"](licenseKey)
    }["LicenseProvider.useState"]);
    const licenseState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])(licenseManager.state);
    const [showEditor, setShowEditor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LicenseProvider.useEffect": ()=>{
            if (shouldHideEditorAfterDelay(licenseState) && showEditor) {
                const timer = setTimeout({
                    "LicenseProvider.useEffect.timer": ()=>{
                        setShowEditor(false);
                    }
                }["LicenseProvider.useEffect.timer"], LICENSE_TIMEOUT);
                return ({
                    "LicenseProvider.useEffect": ()=>clearTimeout(timer)
                })["LicenseProvider.useEffect"];
            }
        }
    }["LicenseProvider.useEffect"], [
        licenseState,
        showEditor
    ]);
    if (shouldHideEditorAfterDelay(licenseState) && !showEditor) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LicenseGate, {});
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LicenseContext.Provider, {
        value: licenseManager,
        children
    });
}
function LicenseGate() {
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        "data-testid": "tl-license-expired",
        style: {
            display: "none"
        }
    });
}
let envLicenseKey = void 0;
function getLicenseKeyFromEnv() {
    if (envLicenseKey !== void 0) {
        return envLicenseKey;
    }
    envLicenseKey = getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.REACT_APP_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GATSBY_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.VITE_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.PUBLIC_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.NEXT_PUBLIC_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.REACT_APP_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.GATSBY_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.VITE_TLDRAW_LICENSE_KEY) || getEnv(()=>__TURBOPACK__import$2e$meta__.env.PUBLIC_TLDRAW_LICENSE_KEY) || null;
    return envLicenseKey;
}
function getEnv(cb) {
    try {
        return cb();
    } catch  {
        return void 0;
    }
}
;
 //# sourceMappingURL=LicenseProvider.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/useLicenseManagerState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLicenseManagerState",
    ()=>useLicenseManagerState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useValue.mjs [app-client] (ecmascript)");
;
function useLicenseManagerState(licenseManager) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("watermarkState", {
        "useLicenseManagerState.useValue": ()=>licenseManager.state.get()
    }["useLicenseManagerState.useValue"], [
        licenseManager
    ]);
}
;
 //# sourceMappingURL=useLicenseManagerState.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/Watermark.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Watermark",
    ()=>Watermark
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCanvasEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useCanvasEvents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$usePassThroughWheelEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/usePassThroughWheelEvents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$runtime$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/runtime.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$watermarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/watermarks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseProvider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$useLicenseManagerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/useLicenseManagerState.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const WATERMARK_DESKTOP_LOCAL_SRC = `data:image/svg+xml;utf8,${encodeURIComponent(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$watermarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["watermarkDesktopSvg"])}`;
const WATERMARK_MOBILE_LOCAL_SRC = `data:image/svg+xml;utf8,${encodeURIComponent(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$watermarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["watermarkMobileSvg"])}`;
const Watermark = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function Watermark2() {
    const licenseManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLicenseContext"])();
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("is mobile", {
        "Watermark.Watermark2.useValue[isMobile]": ()=>editor.getViewportScreenBounds().width < 700
    }["Watermark.Watermark2.useValue[isMobile]"], [
        editor
    ]);
    const licenseManagerState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$useLicenseManagerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLicenseManagerState"])(licenseManager);
    if (![
        "licensed-with-watermark",
        "unlicensed"
    ].includes(licenseManagerState)) return null;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LicenseStyles, {}),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(WatermarkInner, {
                src: isMobile ? WATERMARK_MOBILE_LOCAL_SRC : WATERMARK_DESKTOP_LOCAL_SRC,
                isUnlicensed: licenseManagerState === "unlicensed"
            })
        ]
    });
});
const UnlicensedWatermark = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function UnlicensedWatermark2({ isDebugMode, isMobile }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCanvasEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCanvasEvents"])();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$usePassThroughWheelEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePassThroughWheelEvents"])(ref);
    const url = "https://tldraw.dev/pricing?utm_source=sdk&utm_medium=organic&utm_campaign=watermark";
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LicenseManager"].className,
        "data-debug": isDebugMode,
        "data-mobile": isMobile,
        "data-unlicensed": true,
        "data-testid": "tl-watermark-unlicensed",
        draggable: false,
        ...events,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
            draggable: false,
            role: "button",
            onPointerDown: (e)=>{
                editor.markEventAsHandled(e);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
            },
            title: "The tldraw SDK requires a license key to work in production. You can get a free 100-day trial license at tldraw.dev/pricing.",
            onClick: ()=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$runtime$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runtime"].openWindow(url, "_blank", true);
            },
            children: "Get a license for production"
        })
    });
});
const WatermarkInner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function WatermarkInner2({ src, isUnlicensed }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const isDebugMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("debug mode", {
        "WatermarkInner.WatermarkInner2.useValue[isDebugMode]": ()=>editor.getInstanceState().isDebugMode
    }["WatermarkInner.WatermarkInner2.useValue[isDebugMode]"], [
        editor
    ]);
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("is mobile", {
        "WatermarkInner.WatermarkInner2.useValue[isMobile]": ()=>editor.getViewportScreenBounds().width < 700
    }["WatermarkInner.WatermarkInner2.useValue[isMobile]"], [
        editor
    ]);
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCanvasEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCanvasEvents"])();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$usePassThroughWheelEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePassThroughWheelEvents"])(ref);
    const maskCss = `url('${src}') center 100% / 100% no-repeat`;
    const url = "https://tldraw.dev/?utm_source=sdk&utm_medium=organic&utm_campaign=watermark";
    if (isUnlicensed) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(UnlicensedWatermark, {
            isDebugMode,
            isMobile
        });
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LicenseManager"].className,
        "data-debug": isDebugMode,
        "data-mobile": isMobile,
        "data-testid": "tl-watermark-licensed",
        draggable: false,
        ...events,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
            draggable: false,
            role: "button",
            onPointerDown: (e)=>{
                editor.markEventAsHandled(e);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
            },
            title: "Build infinite canvas applications with the tldraw SDK. Learn more at https://tldraw.dev.",
            onClick: ()=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$runtime$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runtime"].openWindow(url, "_blank");
            },
            style: {
                mask: maskCss,
                WebkitMask: maskCss
            }
        })
    });
});
const LicenseStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function LicenseStyles2() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const className = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LicenseManager"].className;
    const CSS = `
/* ------------------- SEE LICENSE -------------------
The tldraw watermark is part of tldraw's license. It is shown for unlicensed
or "licensed-with-watermark" users. By using this library, you agree to
preserve the watermark's behavior, keeping it visible, unobscured, and
available to user-interaction.

To remove the watermark, please purchase a license at tldraw.dev.
*/

.${className} {
	position: absolute;
	bottom: max(var(--tl-space-2), env(safe-area-inset-bottom));
	right: max(var(--tl-space-2), env(safe-area-inset-right));
	width: 96px;
	height: 32px;
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: var(--tl-layer-watermark) !important;
	background-color: color-mix(in srgb, var(--tl-color-background) 62%, transparent);
	opacity: 1;
	border-radius: 5px;
	pointer-events: all;
	padding: 2px;
	box-sizing: content-box;
}

.${className} > button {
	position: absolute;
	width: 96px;
	height: 32px;
	pointer-events: all;
	cursor: inherit;
	color: var(--tl-color-text);
	opacity: .38;
	border: 0;
	padding: 0;
	background-color: currentColor;
}

.${className}[data-debug='true'] {
	bottom: max(46px, env(safe-area-inset-bottom));
}

.${className}[data-mobile='true'] {
	border-radius: 4px 0px 0px 4px;
	right: max(-2px, calc(env(safe-area-inset-right) - 2px));
	width: 8px;
	height: 48px;
}

.${className}[data-mobile='true'] > button {
	width: 8px;
	height: 32px;
}

.${className}[data-unlicensed='true'] > button {
	font-size: 100px;
	position: absolute;
	pointer-events: all;
	cursor: pointer;
	color: var(--tl-color-text);
	opacity: 0.8;
	border: 0;
	padding: 0;
	background-color: transparent;
	font-size: 11px;
	font-weight: 600;
	text-align: center;
}

.${className}[data-mobile='true'][data-unlicensed='true'] > button {
	display: none;
}

@media (hover: hover) {
	.${className} > button {
		pointer-events: none;
	}

	.${className}:hover {
		background-color: var(--tl-color-background);
		transition: background-color 0.2s ease-in-out;
		transition-delay: 0.32s;
	}

	.${className}:hover > button {
		animation: ${className}_delayed_link 0.2s forwards ease-in-out;
		animation-delay: 0.32s;
	}

	.${className} > button:focus-visible {
		opacity: 1;
	}
}

@keyframes ${className}_delayed_link {
	0% {
		cursor: inherit;
		opacity: .38;
		pointer-events: none;
	}
	100% {
		cursor: pointer;
		opacity: 1;
		pointer-events: all;
	}
}`;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("style", {
        nonce: editor.options.nonce,
        children: CSS
    });
});
;
 //# sourceMappingURL=Watermark.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/watermarks.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "watermarkDesktopSvg",
    ()=>watermarkDesktopSvg,
    "watermarkMobileSvg",
    ()=>watermarkMobileSvg,
    "watermarkTrackSvg",
    ()=>watermarkTrackSvg
]);
const watermarkDesktopSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="3001" height="1000" fill="none"><path fill="#000" d="M590.656 300.449c0 49.706-40.294 90-90 90-49.705 0-90-40.294-90-90 0-49.705 40.295-90 90-90 49.706 0 90 40.295 90 90M569.431 719.011c-15.247 32.821-56.006 91.589-98.338 91.438-32.004-.115-38.642-30.904-17.414-50.856 17.381-16.337 28.246-48.075 31.995-72.719.415-2.728-1.556-5.197-4.272-5.679-39.666-7.04-70.746-40.877-70.746-83.417 0-48.23 38.983-87.329 87.07-87.329 39.936 0 70.172 22.237 83.369 52.397 18.839 43.055 7.117 115.733-11.664 156.165M2613.29 385.681V239.319c0-11.363 9.22-20.569 20.59-20.569h8.26c11.37 0 20.59 9.206 20.59 20.569v36.911c0 8.629 7 15.625 15.63 15.625h35.25c8.63 0 15.63-6.996 15.63-15.625v-36.911c0-11.363 9.22-20.569 20.59-20.569h8.17c11.37 0 20.59 9.206 20.59 20.569v146.362c0 11.363-9.22 20.569-20.59 20.569h-8.17c-11.37 0-20.59-9.206-20.59-20.569v-36.999c0-8.63-7-15.625-15.63-15.625h-35.25c-8.63 0-15.63 6.995-15.63 15.625v36.999c0 11.363-9.22 20.569-20.59 20.569h-8.26c-11.37 0-20.59-9.206-20.59-20.569M2391.97 239.319v146.362c0 11.348-9.16 20.569-20.49 20.569h-8.2c-11.33 0-20.49-9.221-20.49-20.569V239.319c0-11.348 9.16-20.569 20.49-20.569h8.2c11.33 0 20.49 9.221 20.49 20.569M2098.23 391.43l-42.69-146.361c-3.85-13.171 6.06-26.319 19.79-26.319h10.6c9.59 0 17.93 6.611 20.08 15.952l17.01 73.045c1.48 6.348 10.47 6.478 12.14.176l19.47-73.838c2.38-9.04 10.57-15.335 19.93-15.335h12.1c9.37 0 17.56 6.3 19.94 15.346l19.49 74.067c1.66 6.305 10.65 6.178 12.13-.171l17.09-73.294c2.15-9.339 10.49-15.948 20.08-15.948h10.53c13.72 0 23.63 13.141 19.79 26.31l-42.63 146.361c-2.56 8.789-10.63 14.829-19.79 14.829h-15.68c-9.12 0-17.16-5.98-19.76-14.709l-21.17-71.059c-1.77-5.948-10.19-5.957-11.97-.012l-21.33 71.071c-2.6 8.729-10.64 14.709-19.76 14.709h-15.59c-9.17 0-17.23-6.035-19.8-14.82M2443.23 218.75h118.59c11.38 0 20.62 9.195 20.62 20.557s-9.24 20.556-20.62 20.556h-24.79c-5.53 0-10 4.477-10 10v115.818c0 11.368-9.25 20.569-20.63 20.569h-7.65c-11.39 0-20.63-9.201-20.63-20.569V269.863c0-5.523-4.48-10-10-10h-24.89c-11.37 0-20.61-9.195-20.61-20.556s9.24-20.557 20.61-20.557M1174.15 218.75h24.64c8.35 0 15.88 5.042 19.04 12.764l34.61 83.942c2.13 5.161 9.44 5.155 11.56-.01l34.43-83.932a20.58 20.58 0 0 1 19.04-12.764h24.64c11.37 0 20.58 9.208 20.58 20.569v146.362c0 11.361-9.21 20.569-20.58 20.569h-7.09c-11.36 0-20.58-9.208-20.58-20.569l-.12-50.645c-.01-6.888-9.53-8.688-12.06-2.283l-23.46 59.332a20.57 20.57 0 0 1-19.14 13.009h-3.03a20.57 20.57 0 0 1-19.15-13.046l-23.47-59.68c-2.52-6.416-12.05-4.623-12.06 2.271l-.13 51.042c0 11.361-9.21 20.569-20.57 20.569h-7.1c-11.36 0-20.57-9.208-20.57-20.569V239.319c0-11.361 9.21-20.569 20.57-20.569"/><path fill="#000" fill-rule="evenodd" d="m1449.94 391.836 6.12-19.392a6.255 6.255 0 0 1 5.96-4.369l50.22-.061a6.24 6.24 0 0 1 5.96 4.348l6.23 19.486c2.71 8.581 10.71 14.402 19.74 14.402h9.34c14.13 0 24.15-13.791 19.61-27.151l-49.74-146.361c-2.85-8.37-10.74-13.988-19.61-13.988h-33.16c-8.87 0-16.77 5.618-19.61 13.988l-49.74 146.361c-4.54 13.36 5.48 27.151 19.61 27.151h9.32c9.04 0 17.04-5.827 19.75-14.414m31.1-98.858c1.85-5.807 10.08-5.796 11.91.016l8.83 27.916c1.28 4.028-1.73 8.134-5.96 8.134h-17.74c-4.23 0-7.24-4.119-5.95-8.151zM1681.81 406.25c18.91 0 35.39-3.686 49.36-11.168 13.97-7.544 24.73-18.394 32.24-32.489 7.56-14.105 11.29-30.866 11.29-50.182 0-19.256-3.73-35.957-11.29-50.004-7.57-14.094-18.35-24.912-32.32-32.397-13.91-7.545-30.4-11.26-49.37-11.26h-49.5c-11.38 0-20.63 9.201-20.63 20.569v146.362c0 11.368 9.25 20.569 20.63 20.569zm23.13-47.701c-6.62 3.215-14.85 4.886-24.79 4.886-10.49 0-19-8.507-19-19v-64.34c0-10.149 8.23-18.376 18.38-18.376 10.18 0 18.56 1.703 25.23 4.974 6.59 3.149 11.63 8.315 15.08 15.633 3.45 7.269 5.28 17.268 5.28 30.162 0 12.891-1.82 22.951-5.28 30.347-3.39 7.319-8.36 12.509-14.9 15.714" clip-rule="evenodd"/><path fill="#000" d="M1804.21 385.681V239.319c0-11.361 9.21-20.569 20.58-20.569h91.28c11.36 0 20.57 9.202 20.57 20.557s-9.21 20.556-20.57 20.556h-54.64a7.807 7.807 0 0 0-7.81 7.813v16.366a7.806 7.806 0 0 0 7.81 7.812h48.13c11.37 0 20.58 9.246 20.58 20.602s-9.21 20.601-20.58 20.601h-48.13a7.806 7.806 0 0 0-7.81 7.812v16.455a7.807 7.807 0 0 0 7.81 7.813h54.64c11.36 0 20.57 9.202 20.57 20.556s-9.21 20.557-20.57 20.557h-91.28c-11.37 0-20.58-9.208-20.58-20.569"/><path fill="#000" fill-rule="evenodd" d="M2875.5 68.75h-2750c-31.066 0-56.25 25.184-56.25 56.25v750c0 31.066 25.184 56.25 56.25 56.25h2750c31.07 0 56.25-25.184 56.25-56.25V125c0-31.066-25.18-56.25-56.25-56.25M125.5 0C56.464 0 .5 55.964.5 125v750c0 69.036 55.965 125 125 125h2750c69.04 0 125-55.964 125-125V125c0-69.036-55.96-125-125-125z" clip-rule="evenodd"/><path fill="#000" d="M2476.06 804.813c-10.54 0-19.82-6.947-22.81-17.068L2390.79 575.7c-4.49-15.248 6.92-30.534 22.8-30.534h27.75c11.1 0 20.72 7.686 23.18 18.52L2489 671.402c2.07 9.093 14.93 9.321 17.32.308l28.83-108.844c2.76-10.435 12.19-17.7 22.98-17.7h25.17c10.8 0 20.25 7.293 22.99 17.755l28.27 107.739c2.36 9.001 15.18 8.829 17.3-.232l25.01-106.888c2.51-10.763 12.1-18.374 23.14-18.374h27.87c15.88 0 27.29 15.286 22.8 30.534l-62.46 212.045a23.78 23.78 0 0 1-22.81 17.068h-32.12c-10.39 0-19.58-6.763-22.69-16.696l-32.08-102.694c-2.62-8.397-14.51-8.331-17.04.095l-30.74 102.346c-3.02 10.061-12.27 16.949-22.76 16.949zM1742.44 804.813h-75.81c-13.09 0-23.71-10.656-23.71-23.801V568.967c0-13.145 10.62-23.801 23.71-23.801h74.8c26.6 0 49.59 5.198 68.95 15.594 19.45 10.312 34.44 25.187 44.96 44.627 10.61 19.355 15.91 42.556 15.91 69.602q0 40.57-15.78 69.73c-10.53 19.355-25.43 34.231-44.71 44.627-19.28 10.311-42.05 15.467-68.32 15.467m-29.3-83.642c0 13.145 10.61 23.801 23.71 23.801h3.06c12.8 0 23.7-2.07 32.71-6.212 9.09-4.141 16-11.283 20.71-21.426q7.2-15.213 7.2-42.345 0-27.13-7.32-42.344c-4.8-10.143-11.87-17.285-21.22-21.426-9.26-4.142-20.63-6.212-34.1-6.212h-1.04c-13.1 0-23.71 10.656-23.71 23.801zM1460.86 804.813c-13.12 0-23.76-10.656-23.76-23.801V568.967c0-13.145 10.64-23.801 23.76-23.801h22.84c13.13 0 23.76 10.656 23.76 23.801v155.247c0 13.145 10.64 23.801 23.76 23.801h57.27c13.12 0 23.76 10.656 23.76 23.801v9.196c0 13.145-10.64 23.801-23.76 23.801zM1204.45 601.964c-13.13 0-23.77-10.656-23.77-23.801v-9.196c0-13.145 10.64-23.801 23.77-23.801h177.89c13.13 0 23.78 10.656 23.78 23.801v9.196c0 13.145-10.65 23.801-23.78 23.801h-39.38c-8.21 0-14.86 6.66-14.86 14.875v164.173c0 13.145-10.64 23.801-23.78 23.801h-21.85c-13.13 0-23.78-10.656-23.78-23.801V616.839c0-8.215-6.65-14.875-14.86-14.875z"/><path fill="#000" fill-rule="evenodd" d="M2223.05 787.891c-3.02 10.047-12.27 16.922-22.74 16.922h-25.43c-16.19 0-27.64-15.862-22.57-31.261l69.88-212.045c3.21-9.753 12.31-16.341 22.56-16.341h61.84c10.25 0 19.35 6.588 22.56 16.341l69.87 212.045c5.08 15.399-6.37 31.261-22.56 31.261h-25.43c-10.48 0-19.72-6.875-22.74-16.922l-6.7-22.2a14.84 14.84 0 0 0-14.21-10.576h-63.42c-6.55 0-12.32 4.296-14.22 10.576zm76.13-96.945-14.13-48.436c-2.46-8.451-14.36-8.602-17.04-.217l-15.46 48.436c-1.84 5.759 2.45 11.645 8.48 11.645h29.6c5.94 0 10.22-5.715 8.55-11.428" clip-rule="evenodd"/><path fill="#000" d="M1939.6 804.813c-13.13 0-23.77-10.656-23.77-23.801V568.967c0-13.145 10.64-23.801 23.77-23.801h88.13c19.24 0 36.08 3.508 50.51 10.523s25.65 17.115 33.67 30.3q12.03 19.779 12.03 47.416c0 18.595-4.14 34.273-12.41 47.036-7.64 11.913-18.18 21.101-31.63 27.564-16.98 8.159-36 11.104-54.7 11.104h-43.07c-76.56 0 4.08-135.84 4.08-84.706v7.996c0 12.117 9.81 21.941 21.91 21.941 8.12 0 16.3-.345 24.04-3.043 5.91-2.113 10.43-5.451 13.55-10.015 3.2-4.565 4.81-10.523 4.81-17.877 0-7.437-1.61-13.481-4.81-18.129-3.12-4.733-7.64-8.199-13.55-10.396-7.05-2.766-14.67-3.423-22.18-3.423-13.13 0-23.77 10.656-23.77 23.801v47.71c0 11.825 11.14 16.003 19.91 20.752 12.31 6.671 7.58 25.389-6.42 25.389-7.45 0-13.49 6.048-13.49 13.508v48.395c0 13.145-10.63 23.801-23.76 23.801zm134.89-106.758 5.41 9.95 33.51 61.622c8.62 15.86-2.84 35.186-20.87 35.186h-22.27c-8.74 0-16.77-4.798-20.92-12.496l-35.05-65.04a15.52 15.52 0 0 0-13.66-8.168c-42.24 0 40.62-82.154 73.85-21.054M931.652 0h68.748v1000h-68.748z"/></svg>';
const watermarkMobileSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="1601" fill="none"><path fill="#000" d="M72 1319.8c0-10.73 7.071-20.18 17.372-23.22l215.823-63.62c15.519-4.57 31.078 7.05 31.078 23.22v28.26c0 11.31-7.824 21.1-18.85 23.61l-109.636 24.94c-9.254 2.1-9.487 15.2-.313 17.63l110.784 29.37a24.21 24.21 0 0 1 18.015 23.4v25.64c0 11-7.423 20.62-18.071 23.41l-109.659 28.79c-9.162 2.41-8.986 15.47.236 17.63l108.792 25.46c10.955 2.56 18.702 12.33 18.702 23.57v28.39c0 16.17-15.559 27.79-31.078 23.22l-215.823-63.62c-10.3-3.04-17.372-12.49-17.372-23.22v-32.72c0-10.59 6.883-19.95 16.994-23.11l104.523-32.67c8.547-2.67 8.479-14.79-.096-17.36l-104.17-31.3C79.01 1372.42 72 1363 72 1352.31zM72 572.638V495.43c0-13.336 10.846-24.147 24.225-24.147h215.823c13.379 0 24.225 10.811 24.225 24.147v76.179q0 40.645-15.872 70.228-15.743 29.712-45.422 45.79-29.55 16.206-70.843 16.206-41.292 0-70.971-16.078-29.55-16.077-45.422-45.532Q72 612.767 72 572.638m85.132-29.84c-13.379 0-24.225 10.81-24.225 24.146v3.122q0 19.55 6.323 33.313 6.323 13.89 21.807 21.094 15.485 7.332 43.099 7.331t43.1-7.46q15.484-7.33 21.807-21.608 6.323-14.15 6.323-34.728v-1.064c0-13.336-10.846-24.146-24.225-24.146zM72 285.858c0-13.363 10.846-24.197 24.225-24.197h215.823c13.379 0 24.225 10.834 24.225 24.197v23.27c0 13.364-10.846 24.197-24.225 24.197H154.035c-13.379 0-24.225 10.834-24.225 24.197v58.328c0 13.364-10.846 24.197-24.225 24.197h-9.36C82.845 440.047 72 429.214 72 415.85zM278.463 24.72c0-13.374 10.846-24.216 24.225-24.216h9.36c13.379 0 24.225 10.842 24.225 24.216v181.174c0 13.374-10.846 24.216-24.225 24.216h-9.36c-13.379 0-24.225-10.842-24.225-24.216v-40.108c0-8.359-6.779-15.135-15.141-15.135H96.225c-13.38 0-24.225-10.842-24.225-24.216v-22.256c0-13.374 10.846-24.216 24.225-24.216h167.097c8.362 0 15.141-6.776 15.141-15.135z"/><path fill="#000" fill-rule="evenodd" d="M89.224 1062.13C78.997 1059.04 72 1049.63 72 1038.96v-25.9c0-16.486 16.145-28.147 31.818-22.979l215.823 71.169a24.19 24.19 0 0 1 16.632 22.98v62.97c0 10.45-6.706 19.71-16.632 22.98l-215.823 71.17C88.145 1246.51 72 1234.86 72 1218.37v-25.9c0-10.67 6.997-20.08 17.224-23.17l22.595-6.81a15.13 15.13 0 0 0 10.765-14.48v-64.59a15.13 15.13 0 0 0-10.765-14.48zm98.672 77.53 49.299-14.39c8.601-2.51 8.755-14.62.22-17.35l-49.299-15.75c-5.861-1.88-11.852 2.49-11.852 8.64v30.14c0 6.05 5.817 10.41 11.632 8.71" clip-rule="evenodd"/><path fill="#000" d="M72 773.439c0-13.367 10.846-24.203 24.225-24.203h215.823c13.379 0 24.225 10.836 24.225 24.203v89.762q0 29.395-10.711 51.439-10.71 22.046-30.84 34.293t-48.261 12.248q-28.388 0-47.873-12.635-18.187-11.672-28.056-32.218c-8.303-17.289-11.301-36.661-11.301-55.705v-43.867c0-77.976 138.26 4.16 86.215 4.16h-8.138c-12.334 0-22.332 9.989-22.332 22.311 0 8.269.351 16.6 3.097 24.487q3.225 9.024 10.194 13.794 6.968 4.899 18.194 4.899 11.356 0 18.453-4.899 7.226-4.77 10.581-13.794c2.815-7.188 3.484-14.944 3.484-22.596 0-13.366-10.846-24.202-24.225-24.202h-48.56c-12.036 0-16.288 11.345-21.122 20.272-6.79 12.539-25.841 7.72-25.841-6.536 0-7.586-6.156-13.736-13.749-13.736H96.225C82.845 820.916 72 810.08 72 796.714zm108.66 137.378-10.128 5.511-62.72 34.131C91.67 959.243 72 947.569 72 929.205V906.52a24.2 24.2 0 0 1 12.719-21.299l66.199-35.696a15.82 15.82 0 0 0 8.313-13.921c0-43.012 83.618 41.371 21.429 75.213"/></svg>';
const watermarkTrackSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>';
;
 //# sourceMappingURL=watermarks.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/TldrawEditor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorScreen",
    ()=>ErrorScreen,
    "LoadingScreen",
    ()=>LoadingScreen,
    "TL_CONTAINER_CLASS",
    ()=>TL_CONTAINER_CLASS,
    "TldrawEditor",
    ()=>TldrawEditor,
    "useOnMount",
    ()=>useOnMount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/Store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$default$2d$components$2f$DefaultErrorFallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/default-components/DefaultErrorFallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$ErrorBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/ErrorBoundary.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/createTLUser.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/Editor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useContainer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useDarkMode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useDarkMode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditorComponents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEvent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useForceUpdate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useForceUpdate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useIdentity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useLocalStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useLocalStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useRefState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useRefState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useStateAttribute$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useStateAttribute.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useZoomCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useZoomCss.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/LicenseProvider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$Watermark$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/license/Watermark.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const EMPTY_SHAPE_UTILS_ARRAY = [];
const EMPTY_BINDING_UTILS_ARRAY = [];
const EMPTY_TOOLS_ARRAY = [];
const TL_CONTAINER_CLASS = "tl-container";
const TldrawEditor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function TldrawEditor2({ store, components, className, user: _user, options: _options, // eslint-disable-next-line @typescript-eslint/no-deprecated
textOptions: _textOptions, // eslint-disable-next-line @typescript-eslint/no-deprecated
deepLinks: _deepLinks, ...rest }) {
    const [container, setContainer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawEditor.TldrawEditor2.useMemo[user]": ()=>_user ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTLUser"])()
    }["TldrawEditor.TldrawEditor2.useMemo[user]"], [
        _user
    ]);
    const ErrorFallback = components?.ErrorFallback === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$default$2d$components$2f$DefaultErrorFallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultErrorFallback"] : components?.ErrorFallback;
    const mergedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawEditor.TldrawEditor2.useMemo[mergedOptions]": ()=>{
            let result = _options;
            if (_textOptions) {
                result = {
                    ...result,
                    text: result?.text ?? _textOptions
                };
            }
            if (_deepLinks !== void 0) {
                result = {
                    ...result,
                    deepLinks: result?.deepLinks ?? _deepLinks
                };
            }
            return result;
        }
    }["TldrawEditor.TldrawEditor2.useMemo[mergedOptions]"], [
        _options,
        _textOptions,
        _deepLinks
    ]);
    const withDefaults = {
        ...rest,
        shapeUtils: rest.shapeUtils ?? EMPTY_SHAPE_UTILS_ARRAY,
        bindingUtils: rest.bindingUtils ?? EMPTY_BINDING_UTILS_ARRAY,
        tools: rest.tools ?? EMPTY_TOOLS_ARRAY,
        components,
        options: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowObjectIdentity"])(mergedOptions)
    };
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: setContainer,
        "data-tldraw": __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["version"],
        draggable: false,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`${TL_CONTAINER_CLASS} tl-theme__light`, className),
        tabIndex: -1,
        role: "application",
        "aria-label": _options?.branding ?? "tldraw",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$ErrorBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OptionalErrorBoundary"], {
            fallback: ErrorFallback,
            onError: (error)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["annotateError"])(error, {
                    tags: {
                        origin: "react.tldraw-before-app"
                    }
                }),
            children: container && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$LicenseProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LicenseProvider"], {
                licenseKey: rest.licenseKey,
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContainerProvider"], {
                    container,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorComponentsProvider"], {
                        overrides: components,
                        children: store ? store instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Store"] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawEditorWithReadyStore, {
                            ...withDefaults,
                            store,
                            user
                        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawEditorWithLoadingStore, {
                            ...withDefaults,
                            store,
                            user
                        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawEditorWithOwnStore, {
                            ...withDefaults,
                            store,
                            user
                        })
                    })
                })
            })
        })
    });
});
function TldrawEditorWithOwnStore(props) {
    const { defaultName, snapshot, initialData, shapeUtils, bindingUtils, persistenceKey, sessionId, user, assets, migrations } = props;
    const syncedStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useLocalStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocalStore"])({
        shapeUtils,
        bindingUtils,
        initialData,
        persistenceKey,
        sessionId,
        defaultName,
        snapshot,
        assets,
        migrations
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawEditorWithLoadingStore, {
        ...props,
        store: syncedStore,
        user
    });
}
const TldrawEditorWithLoadingStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function TldrawEditorBeforeLoading({ store, user, ...rest }) {
    const container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContainer"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithLoadingStore.TldrawEditorBeforeLoading.useLayoutEffect": ()=>{
            if (user.userPreferences.get().colorScheme === "dark") {
                container.classList.remove("tl-theme__light");
                container.classList.add("tl-theme__dark");
            }
        }
    }["TldrawEditorWithLoadingStore.TldrawEditorBeforeLoading.useLayoutEffect"], [
        container,
        user
    ]);
    const { LoadingScreen: LoadingScreen2 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditorComponents"])();
    switch(store.status){
        case "error":
            {
                throw store.error;
            }
        case "loading":
            {
                return LoadingScreen2 ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LoadingScreen2, {}) : null;
            }
        case "not-synced":
            {
                break;
            }
        case "synced-local":
            {
                break;
            }
        case "synced-remote":
            {
                break;
            }
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawEditorWithReadyStore, {
        ...rest,
        store: store.store,
        user
    });
});
const noAutoFocus = ()=>document.location.search.includes("tldraw_preserve_focus");
function TldrawEditorWithReadyStore({ onMount, children, store, tools, shapeUtils, bindingUtils, user, initialState, autoFocus = true, inferDarkMode, // eslint-disable-next-line @typescript-eslint/no-deprecated
cameraOptions, options, licenseKey, getShapeVisibility, assetUrls }) {
    const { ErrorFallback } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditorComponents"])();
    const container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContainer"])();
    const [editor, setEditor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useRefState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefState"])(null);
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const _deepLinks = options?.deepLinks;
    const deepLinks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowObjectIdentity"])(_deepLinks === true ? {} : _deepLinks);
    const editorOptionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        // for these, it's because they're only used when the editor first mounts:
        autoFocus: autoFocus && !noAutoFocus(),
        inferDarkMode,
        initialState,
        // for these, it's because we keep them up to date in a separate effect:
        cameraOptions,
        deepLinks
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
            editorOptionsRef.current = {
                autoFocus: autoFocus && !noAutoFocus(),
                inferDarkMode,
                initialState,
                cameraOptions,
                deepLinks
            };
        }
    }["TldrawEditorWithReadyStore.useLayoutEffect"], [
        autoFocus,
        inferDarkMode,
        initialState,
        cameraOptions,
        deepLinks
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
            const { autoFocus: autoFocus2, inferDarkMode: inferDarkMode2, initialState: initialState2, cameraOptions: cameraOptions2, deepLinks: deepLinks2 } = editorOptionsRef.current;
            const editor2 = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Editor"]({
                store,
                shapeUtils,
                bindingUtils,
                tools,
                getContainer: {
                    "TldrawEditorWithReadyStore.useLayoutEffect": ()=>container
                }["TldrawEditorWithReadyStore.useLayoutEffect"],
                user,
                initialState: initialState2,
                // we should check for some kind of query parameter that turns off autofocus
                autoFocus: autoFocus2,
                inferDarkMode: inferDarkMode2,
                cameraOptions: cameraOptions2,
                options,
                licenseKey,
                getShapeVisibility,
                fontAssetUrls: assetUrls?.fonts
            });
            editor2.updateViewportScreenBounds(canvasRef.current ?? container);
            if (deepLinks2) {
                if (!deepLinks2?.getUrl) {
                    editor2.navigateToDeepLink(deepLinks2);
                } else {
                    editor2.navigateToDeepLink({
                        ...deepLinks2,
                        url: deepLinks2.getUrl(editor2)
                    });
                }
            }
            setEditor(editor2);
            return ({
                "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
                    editor2.dispose();
                }
            })["TldrawEditorWithReadyStore.useLayoutEffect"];
        }
    }["TldrawEditorWithReadyStore.useLayoutEffect"], // if any of these change, we need to recreate the editor.
    [
        bindingUtils,
        container,
        options,
        shapeUtils,
        store,
        tools,
        user,
        setEditor,
        licenseKey,
        getShapeVisibility,
        assetUrls
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
            if (!editor) return;
            if (deepLinks) {
                return editor.registerDeepLinkListener(deepLinks);
            }
        }
    }["TldrawEditorWithReadyStore.useLayoutEffect"], [
        editor,
        deepLinks
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
            if (editor && (cameraOptions || options?.camera)) {
                editor.setCameraOptions({
                    ...cameraOptions,
                    ...options?.camera
                });
            }
        }
    }["TldrawEditorWithReadyStore.useLayoutEffect"], [
        editor,
        cameraOptions,
        options?.camera
    ]);
    const crashingError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]": (onStoreChange)=>{
            if (editor) {
                editor.on("crash", onStoreChange);
                return ({
                    "TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]": ()=>editor.off("crash", onStoreChange)
                })["TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]"];
            }
            return ({
                "TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]": ()=>{}
            })["TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]"];
        }
    }["TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]"], [
        editor
    ]), {
        "TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]": ()=>editor?.getCrashingError() ?? null
    }["TldrawEditorWithReadyStore.useSyncExternalStore[crashingError]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function handleFocusOnPointerDownForPreserveFocusMode() {
        if (!editor) return;
        function handleFocusOnPointerDown() {
            if (!editor) return;
            editor.focus();
        }
        function handleBlurOnPointerDown() {
            if (!editor) return;
            editor.blur();
        }
        if (autoFocus && noAutoFocus()) {
            editor.getContainer().addEventListener("pointerdown", handleFocusOnPointerDown);
            document.body.addEventListener("pointerdown", handleBlurOnPointerDown);
            return ({
                "TldrawEditorWithReadyStore.useEffect.handleFocusOnPointerDownForPreserveFocusMode": ()=>{
                    editor.getContainer()?.removeEventListener("pointerdown", handleFocusOnPointerDown);
                    document.body.removeEventListener("pointerdown", handleBlurOnPointerDown);
                }
            })["TldrawEditorWithReadyStore.useEffect.handleFocusOnPointerDownForPreserveFocusMode"];
        }
    }, [
        editor,
        autoFocus
    ]);
    const [_fontLoadingState, setFontLoadingState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let fontLoadingState = _fontLoadingState;
    if (editor !== fontLoadingState?.editor) {
        fontLoadingState = null;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
            if (!editor) return;
            if (editor.options.maxFontsToLoadBeforeRender === 0) {
                setFontLoadingState({
                    editor,
                    isLoaded: true
                });
                return;
            }
            let isCancelled = false;
            setFontLoadingState({
                editor,
                isLoaded: false
            });
            editor.fonts.loadRequiredFontsForCurrentPage(editor.options.maxFontsToLoadBeforeRender).finally({
                "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
                    if (isCancelled) return;
                    setFontLoadingState({
                        editor,
                        isLoaded: true
                    });
                }
            }["TldrawEditorWithReadyStore.useLayoutEffect"]);
            return ({
                "TldrawEditorWithReadyStore.useLayoutEffect": ()=>{
                    isCancelled = true;
                }
            })["TldrawEditorWithReadyStore.useLayoutEffect"];
        }
    }["TldrawEditorWithReadyStore.useLayoutEffect"], [
        editor
    ]);
    const { Canvas, LoadingScreen: LoadingScreen2 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditorComponents"])();
    if (!editor || !fontLoadingState?.isLoaded) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                LoadingScreen2 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LoadingScreen2, {}),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: "tl-canvas",
                    ref: canvasRef
                })
            ]
        });
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$ErrorBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OptionalErrorBoundary"], {
        fallback: ErrorFallback,
        onError: (error)=>editor.annotateError(error, {
                origin: "react.tldraw",
                willCrashApp: true
            }),
        children: crashingError ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Crash, {
            crashingError
        }) : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorProvider"], {
            editor,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Layout, {
                onMount,
                children: [
                    children ?? (Canvas ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Canvas, {}, editor.contextId) : null),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$license$2f$Watermark$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Watermark"], {})
                ]
            })
        })
    });
}
function Layout({ children, onMount }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useZoomCss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useZoomCss"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCursor"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useDarkMode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDarkMode"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useForceUpdate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForceUpdate"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useStateAttribute$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStateAttribute"])();
    useOnMount({
        "Layout.useOnMount": (editor)=>{
            const teardownStore = editor.store.props.onMount(editor);
            const teardownCallback = onMount?.(editor);
            return ({
                "Layout.useOnMount": ()=>{
                    teardownStore?.();
                    teardownCallback?.();
                }
            })["Layout.useOnMount"];
        }
    }["Layout.useOnMount"]);
    return children;
}
function Crash({ crashingError }) {
    throw crashingError;
}
function LoadingScreen({ children }) {
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "tl-loading",
        "aria-busy": "true",
        tabIndex: 0,
        children
    });
}
function ErrorScreen({ children }) {
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "tl-loading",
        children
    });
}
function useOnMount(onMount) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const onMountEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])({
        "useOnMount.useEvent[onMountEvent]": (editor2)=>{
            let teardown = void 0;
            editor2.run({
                "useOnMount.useEvent[onMountEvent]": ()=>{
                    teardown = onMount?.(editor2);
                    editor2.emit("mount");
                }
            }["useOnMount.useEvent[onMountEvent]"], {
                history: "ignore"
            });
            window.tldrawReady = true;
            return teardown;
        }
    }["useOnMount.useEvent[onMountEvent]"]);
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useLayoutEffect({
        "useOnMount.useLayoutEffect": ()=>{
            if (editor) return onMountEvent?.(editor);
        }
    }["useOnMount.useLayoutEffect"], [
        editor,
        onMountEvent
    ]);
}
;
 //# sourceMappingURL=TldrawEditor.mjs.map
}),
]);

//# debugId=7c23b29e-9537-3c8e-00c7-96995e030367
//# sourceMappingURL=c427b_%40tldraw_editor_dist-esm_lib_d94db4cc._.js.map