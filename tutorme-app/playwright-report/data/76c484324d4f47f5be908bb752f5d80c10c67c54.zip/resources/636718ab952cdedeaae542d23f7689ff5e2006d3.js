;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="841f9d27-db64-89ab-34a7-0938b208f0d3")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/frames/frames.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_FRAME_PADDING",
    ()=>DEFAULT_FRAME_PADDING,
    "fitFrameToContent",
    ()=>fitFrameToContent,
    "getFrameChildrenBounds",
    ()=>getFrameChildrenBounds,
    "removeFrame",
    ()=>removeFrame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reparenting.mjs [app-client] (ecmascript)");
;
function removeFrame(editor, ids) {
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>editor.getShape(id)).filter((f)=>f && editor.isShapeOfType(f, "frame")));
    if (!frames.length) return;
    const allChildren = [];
    editor.run(()=>{
        frames.map((frame)=>{
            const children = editor.getSortedChildIdsForParent(frame.id);
            if (children.length) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reparenting$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kickoutOccludedShapes"])(editor, children, {
                    filter: (s)=>!frames.find((f)=>f.id === s.id)
                });
                allChildren.push(...children);
            }
        });
        editor.setSelectedShapes(allChildren);
        editor.deleteShapes(ids);
    });
}
const DEFAULT_FRAME_PADDING = 50;
function getFrameChildrenBounds(children, editor, opts = {
    padding: DEFAULT_FRAME_PADDING
}) {
    const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(children.flatMap((shape)=>{
        if (!shape) return [];
        const geometry = editor.getShapeGeometry(shape.id);
        const transform = editor.getShapeLocalTransform(shape);
        return transform?.applyToPoints(geometry.vertices) ?? [];
    }));
    const padding = opts.padding ?? DEFAULT_FRAME_PADDING;
    const w = bounds.w + 2 * padding;
    const h = bounds.h + 2 * padding;
    const dx = padding - bounds.minX;
    const dy = padding - bounds.minY;
    return {
        w,
        h,
        dx,
        dy
    };
}
function fitFrameToContent(editor, id, opts = {}) {
    const frame = editor.getShape(id);
    if (!frame) return;
    const childIds = editor.getSortedChildIdsForParent(frame.id);
    const children = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(childIds.map((id2)=>editor.getShape(id2)));
    if (!children.length) return;
    const { w, h, dx, dy } = getFrameChildrenBounds(children, editor, opts);
    if (dx === 0 && dy === 0 && frame.props.w === w && frame.props.h === h) return;
    const diff = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](dx, dy).rot(frame.rotation);
    editor.run(()=>{
        const changes = childIds.map((child)=>{
            const shape = editor.getShape(child);
            return {
                id: shape.id,
                type: shape.type,
                x: shape.x + dx,
                y: shape.y + dy
            };
        });
        changes.push({
            id: frame.id,
            type: frame.type,
            x: frame.x - diff.x,
            y: frame.y - diff.y,
            props: {
                w,
                h
            }
        });
        editor.updateShapes(changes);
    });
}
;
 //# sourceMappingURL=frames.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/clipboard.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TLDRAW_CUSTOM_PNG_MIME_TYPE",
    ()=>TLDRAW_CUSTOM_PNG_MIME_TYPE,
    "clipboardWrite",
    ()=>clipboardWrite,
    "doesClipboardSupportType",
    ()=>doesClipboardSupportType,
    "getAdditionalClipboardWriteType",
    ()=>getAdditionalClipboardWriteType,
    "getCanonicalClipboardReadType",
    ()=>getCanonicalClipboardReadType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
const TLDRAW_CUSTOM_PNG_MIME_TYPE = "web image/vnd.tldraw+png";
const additionalClipboardWriteTypes = {
    png: TLDRAW_CUSTOM_PNG_MIME_TYPE
};
const canonicalClipboardReadTypes = {
    [TLDRAW_CUSTOM_PNG_MIME_TYPE]: "image/png"
};
function getAdditionalClipboardWriteType(format) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(additionalClipboardWriteTypes, format) ?? null;
}
function getCanonicalClipboardReadType(mimeType) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(canonicalClipboardReadTypes, mimeType) ?? mimeType;
}
function doesClipboardSupportType(mimeType) {
    return typeof ClipboardItem !== "undefined" && "supports" in ClipboardItem && ClipboardItem.supports(mimeType);
}
function clipboardWrite(types) {
    const entries = Object.entries(types);
    for (const [_, promise] of entries)promise.catch((err)=>console.error(err));
    return navigator.clipboard.write([
        new ClipboardItem(types)
    ]).catch((err)=>{
        console.error(err);
        return Promise.all(entries.map(async ([type, promise])=>{
            return [
                type,
                await promise
            ];
        })).then((entries2)=>{
            const resolvedTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapFromEntries"])(entries2);
            return navigator.clipboard.write([
                new ClipboardItem(resolvedTypes)
            ]);
        });
    });
}
;
 //# sourceMappingURL=clipboard.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/export.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "exportToImagePromiseForClipboard",
    ()=>exportToImagePromiseForClipboard,
    "exportToString",
    ()=>exportToString
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
async function getSvgString(editor, ids, opts) {
    const svg = await editor.getSvgString(ids, opts);
    if (!svg) {
        throw new Error("Could not construct SVG.");
    }
    return svg;
}
async function exportToString(editor, ids, format, opts = {}) {
    switch(format){
        case "svg":
            {
                return (await getSvgString(editor, ids, opts))?.svg;
            }
        case "json":
            {
                const data = await editor.resolveAssetsInContent(editor.getContentFromCurrentPage(ids));
                return JSON.stringify(data);
            }
        default:
            {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(format);
            }
    }
}
const clipboardMimeTypesByFormat = {
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    svg: "text/plain"
};
function exportToImagePromiseForClipboard(editor, ids, opts = {}) {
    const idsToUse = ids?.length ? ids : [
        ...editor.getCurrentPageShapeIds()
    ];
    const format = opts.format ?? "png";
    return {
        blobPromise: editor.toImage(idsToUse, opts).then((result)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].rewriteMimeType(result.blob, clipboardMimeTypesByFormat[format])),
        mimeType: clipboardMimeTypesByFormat[format]
    };
}
;
 //# sourceMappingURL=export.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/copyAs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "copyAs",
    ()=>copyAs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/clipboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$export$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/export.mjs [app-client] (ecmascript)");
;
;
;
function copyAs(editor, ids, opts) {
    if (!navigator.clipboard) return Promise.reject(new Error("Copy not supported"));
    if (navigator.clipboard.write) {
        const { blobPromise, mimeType } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$export$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportToImagePromiseForClipboard"])(editor, ids, opts);
        const types = {
            [mimeType]: blobPromise
        };
        const additionalMimeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAdditionalClipboardWriteType"])(opts.format);
        if (additionalMimeType && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doesClipboardSupportType"])(additionalMimeType)) {
            types[additionalMimeType] = blobPromise.then((blob)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].rewriteMimeType(blob, additionalMimeType));
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clipboardWrite"])(types);
    }
    switch(opts.format){
        case "svg":
            {
                return fallbackWriteTextAsync(async ()=>{
                    const result = await editor.getSvgString(ids, opts);
                    if (!result) throw new Error("Failed to copy");
                    return result.svg;
                });
            }
        case "png":
            throw new Error("Copy not supported");
        default:
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(opts.format);
    }
}
async function fallbackWriteTextAsync(getText) {
    await navigator.clipboard?.writeText?.(await getText());
}
;
 //# sourceMappingURL=copyAs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/exportAs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "downloadFile",
    ()=>downloadFile,
    "exportAs",
    ()=>exportAs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSafeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useSafeId.mjs [app-client] (ecmascript)");
;
async function exportAs(editor, ids, opts) {
    let name = opts.name;
    if (!name) {
        name = `shapes at ${getTimestamp()}`;
        if (ids.length === 1) {
            const first = editor.getShape(ids[0]);
            if (editor.isShapeOfType(first, "frame")) {
                name = first.props.name || "frame";
            } else {
                name = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSafeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeId"])(first.id)} at ${getTimestamp()}`;
            }
        }
    }
    name += `.${opts.format}`;
    const { blob } = await editor.toImage(ids, opts);
    const file = new File([
        blob
    ], name, {
        type: blob.type
    });
    downloadFile(file);
}
function getTimestamp() {
    const now = /* @__PURE__ */ new Date();
    const year = String(now.getFullYear()).slice(2);
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}.${minutes}.${seconds}`;
}
function downloadFile(file) {
    const link = document.createElement("a");
    const url = URL.createObjectURL(file);
    link.href = url;
    link.download = file.name;
    link.click();
    URL.revokeObjectURL(url);
}
;
 //# sourceMappingURL=exportAs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/assets/assets.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "containBoxSize",
    ()=>containBoxSize,
    "downsizeImage",
    ()=>downsizeImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$browserCanvasMaxSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/browserCanvasMaxSize.mjs [app-client] (ecmascript)");
;
function containBoxSize(originalSize, containBoxSize2) {
    const overByXScale = originalSize.w / containBoxSize2.w;
    const overByYScale = originalSize.h / containBoxSize2.h;
    if (overByXScale <= 1 && overByYScale <= 1) {
        return originalSize;
    } else if (overByXScale > overByYScale) {
        return {
            w: originalSize.w / overByXScale,
            h: originalSize.h / overByXScale
        };
    } else {
        return {
            w: originalSize.w / overByYScale,
            h: originalSize.h / overByYScale
        };
    }
}
async function downsizeImage(blob, width, height, opts = {}) {
    const { w, h, image } = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].usingObjectURL(blob, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].getImageAndDimensions);
    const { type = blob.type, quality = 0.85 } = opts;
    const [desiredWidth, desiredHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$browserCanvasMaxSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampToBrowserMaxCanvasSize"])(Math.min(width * 2, w), Math.min(height * 2, h));
    const canvas = document.createElement("canvas");
    canvas.width = desiredWidth;
    canvas.height = desiredHeight;
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(canvas.getContext("2d", {
        willReadFrequently: true
    }), "Could not get canvas context");
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(image, 0, 0, desiredWidth, desiredHeight);
    return new Promise((resolve, reject)=>{
        canvas.toBlob((blob2)=>{
            if (blob2) {
                resolve(blob2);
            } else {
                reject(new Error("Could not resize image"));
            }
        }, type, quality);
    });
}
;
 //# sourceMappingURL=assets.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/excalidraw/putExcalidrawContent.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "putExcalidrawContent",
    ()=>putExcalidrawContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
async function putExcalidrawContent(editor, excalidrawClipboardContent, point) {
    const { elements, files } = excalidrawClipboardContent;
    const tldrawContent = {
        shapes: [],
        bindings: [],
        rootShapeIds: [],
        assets: [],
        schema: editor.store.schema.serialize()
    };
    const groupShapeIdToChildren = /* @__PURE__ */ new Map();
    const rotatedElements = /* @__PURE__ */ new Map();
    const currentPageId = editor.getCurrentPageId();
    const excElementIdsToTldrawShapeIds = /* @__PURE__ */ new Map();
    const rootShapeIds = [];
    const skipIds = /* @__PURE__ */ new Set();
    elements.forEach((element)=>{
        excElementIdsToTldrawShapeIds.set(element.id, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])());
        if (element.boundElements !== null) {
            for (const boundElement of element.boundElements){
                if (boundElement.type === "text") {
                    skipIds.add(boundElement.id);
                }
            }
        }
    });
    let index = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZERO_INDEX_KEY"];
    for (const element of elements){
        if (skipIds.has(element.id)) {
            continue;
        }
        const id = excElementIdsToTldrawShapeIds.get(element.id);
        const base = {
            id,
            typeName: "shape",
            parentId: currentPageId,
            index,
            x: element.x,
            y: element.y,
            rotation: 0,
            isLocked: element.locked,
            opacity: getOpacity(element.opacity),
            meta: {}
        };
        if (element.angle !== 0) {
            rotatedElements.set(id, element.angle);
        }
        if (element.groupIds && element.groupIds.length > 0) {
            if (groupShapeIdToChildren.has(element.groupIds[0])) {
                groupShapeIdToChildren.get(element.groupIds[0])?.push(id);
            } else {
                groupShapeIdToChildren.set(element.groupIds[0], [
                    id
                ]);
            }
        } else {
            rootShapeIds.push(id);
        }
        switch(element.type){
            case "rectangle":
            case "ellipse":
            case "diamond":
                {
                    let text = "";
                    let align = "middle";
                    if (element.boundElements !== null) {
                        for (const boundElement of element.boundElements){
                            if (boundElement.type === "text") {
                                const labelElement = elements.find((elm)=>elm.id === boundElement.id);
                                if (labelElement) {
                                    text = labelElement.text;
                                    align = textAlignToAlignTypes[labelElement.textAlign];
                                }
                            }
                        }
                    }
                    const colorToUse = element.backgroundColor === "transparent" ? element.strokeColor : element.backgroundColor;
                    tldrawContent.shapes.push({
                        ...base,
                        type: "geo",
                        props: {
                            ...editor.getShapeUtil("geo").getDefaultProps(),
                            geo: element.type,
                            url: element.link ?? "",
                            w: element.width,
                            h: element.height,
                            size: strokeWidthsToSizes[element.strokeWidth] ?? "draw",
                            color: colorsToColors[colorToUse] ?? "black",
                            richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(text),
                            align,
                            dash: getDash(element),
                            fill: getFill(element)
                        }
                    });
                    break;
                }
            case "freedraw":
                {
                    const points = element.points.map(([x, y, z = 0.5])=>({
                            x,
                            y,
                            z
                        }));
                    const base64Points = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(points);
                    tldrawContent.shapes.push({
                        ...base,
                        type: "draw",
                        props: {
                            ...editor.getShapeUtil("draw").getDefaultProps(),
                            dash: getDash(element),
                            size: strokeWidthsToSizes[element.strokeWidth],
                            color: colorsToColors[element.strokeColor] ?? "black",
                            segments: [
                                {
                                    type: "free",
                                    path: base64Points
                                }
                            ]
                        }
                    });
                    break;
                }
            case "line":
                {
                    const points = element.points.slice();
                    if (points.length < 2) {
                        break;
                    }
                    const indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndices"])(element.points.length);
                    tldrawContent.shapes.push({
                        ...base,
                        type: "line",
                        props: {
                            ...editor.getShapeUtil("line").getDefaultProps(),
                            dash: getDash(element),
                            size: strokeWidthsToSizes[element.strokeWidth],
                            color: colorsToColors[element.strokeColor] ?? "black",
                            spline: element.roundness ? "cubic" : "line",
                            points: {
                                ...Object.fromEntries(element.points.map(([x, y], i)=>{
                                    const index2 = indices[i];
                                    return [
                                        index2,
                                        {
                                            id: index2,
                                            index: index2,
                                            x,
                                            y
                                        }
                                    ];
                                }))
                            }
                        }
                    });
                    break;
                }
            case "arrow":
                {
                    let text = "";
                    if (element.boundElements !== null) {
                        for (const boundElement of element.boundElements){
                            if (boundElement.type === "text") {
                                const labelElement = elements.find((elm)=>elm.id === boundElement.id);
                                if (labelElement) {
                                    text = labelElement.text;
                                }
                            }
                        }
                    }
                    const start = element.points[0];
                    const end = element.points[element.points.length - 1];
                    const startTargetId = excElementIdsToTldrawShapeIds.get(element.startBinding?.elementId);
                    const endTargetId = excElementIdsToTldrawShapeIds.get(element.endBinding?.elementId);
                    tldrawContent.shapes.push({
                        ...base,
                        type: "arrow",
                        props: {
                            ...editor.getShapeUtil("arrow").getDefaultProps(),
                            richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(text),
                            kind: element.elbowed ? "elbow" : "arc",
                            bend: getBend(element, start, end),
                            dash: getDash(element),
                            size: strokeWidthsToSizes[element.strokeWidth] ?? "m",
                            color: colorsToColors[element.strokeColor] ?? "black",
                            start: {
                                x: start[0],
                                y: start[1]
                            },
                            end: {
                                x: end[0],
                                y: end[1]
                            },
                            arrowheadEnd: arrowheadsToArrowheadTypes[element.endArrowhead] ?? "none",
                            arrowheadStart: arrowheadsToArrowheadTypes[element.startArrowhead] ?? "none"
                        }
                    });
                    if (startTargetId) {
                        tldrawContent.bindings.push({
                            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])(),
                            typeName: "binding",
                            type: "arrow",
                            fromId: id,
                            toId: startTargetId,
                            props: {
                                terminal: "start",
                                snap: "none",
                                normalizedAnchor: {
                                    x: 0.5,
                                    y: 0.5
                                },
                                isPrecise: false,
                                isExact: false
                            },
                            meta: {}
                        });
                    }
                    if (endTargetId) {
                        tldrawContent.bindings.push({
                            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])(),
                            typeName: "binding",
                            type: "arrow",
                            fromId: id,
                            toId: endTargetId,
                            props: {
                                terminal: "end",
                                snap: "none",
                                normalizedAnchor: {
                                    x: 0.5,
                                    y: 0.5
                                },
                                isPrecise: false,
                                isExact: false
                            },
                            meta: {}
                        });
                    }
                    break;
                }
            case "text":
                {
                    const { size, scale } = getFontSizeAndScale(element.fontSize);
                    tldrawContent.shapes.push({
                        ...base,
                        type: "text",
                        props: {
                            ...editor.getShapeUtil("text").getDefaultProps(),
                            size,
                            scale,
                            font: fontFamilyToFontType[element.fontFamily] ?? "draw",
                            color: colorsToColors[element.strokeColor] ?? "black",
                            richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(element.text),
                            textAlign: textAlignToTextAlignTypes[element.textAlign]
                        }
                    });
                    break;
                }
            case "image":
                {
                    const file = files[element.fileId];
                    if (!file) break;
                    const assetId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId();
                    tldrawContent.assets.push({
                        id: assetId,
                        typeName: "asset",
                        type: "image",
                        props: {
                            w: element.width,
                            h: element.height,
                            fileSize: file.size,
                            name: element.id ?? "Untitled",
                            isAnimated: false,
                            mimeType: file.mimeType,
                            src: file.dataURL
                        },
                        meta: {}
                    });
                    tldrawContent.shapes.push({
                        ...base,
                        type: "image",
                        props: {
                            ...editor.getShapeUtil("image").getDefaultProps(),
                            w: element.width,
                            h: element.height,
                            assetId
                        }
                    });
                }
        }
        index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(index);
    }
    const p = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : void 0);
    editor.putContentOntoCurrentPage(tldrawContent, {
        point: p,
        select: false,
        preserveIds: true
    });
    for (const groupedShapeIds of groupShapeIdToChildren.values()){
        if (groupedShapeIds.length > 1) {
            editor.groupShapes(groupedShapeIds);
            const groupShape = editor.getShape(groupedShapeIds[0]);
            if (groupShape?.parentId && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(groupShape.parentId)) {
                rootShapeIds.push(groupShape.parentId);
            }
        }
    }
    for (const [id, angle] of rotatedElements){
        editor.select(id);
        editor.rotateShapesBy([
            id
        ], angle);
    }
    const rootShapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(rootShapeIds.map((id)=>editor.getShape(id)));
    const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(rootShapes.map((s)=>editor.getShapePageBounds(s)));
    const viewPortCenter = editor.getViewportPageBounds().center;
    editor.updateShapes(rootShapes.map((s)=>{
        const delta = {
            x: (s.x ?? 0) - (bounds.x + bounds.w / 2),
            y: (s.y ?? 0) - (bounds.y + bounds.h / 2)
        };
        return {
            id: s.id,
            type: s.type,
            x: viewPortCenter.x + delta.x,
            y: viewPortCenter.y + delta.y
        };
    }));
    editor.setSelectedShapes(rootShapeIds);
}
const getOpacity = (opacity)=>{
    const t = opacity / 100;
    if (t < 0.2) {
        return 0.1;
    } else if (t < 0.4) {
        return 0.25;
    } else if (t < 0.6) {
        return 0.5;
    } else if (t < 0.8) {
        return 0.75;
    }
    return 1;
};
const strokeWidthsToSizes = {
    1: "s",
    2: "m",
    3: "l",
    4: "xl"
};
const fontSizesToSizes = {
    16: "s",
    20: "m",
    28: "l",
    36: "xl"
};
function getFontSizeAndScale(fontSize) {
    const size = fontSizesToSizes[fontSize];
    if (size) {
        return {
            size,
            scale: 1
        };
    }
    if (fontSize < 16) {
        return {
            size: "s",
            scale: fontSize / 16
        };
    }
    if (fontSize > 36) {
        return {
            size: "xl",
            scale: fontSize / 36
        };
    }
    return {
        size: "m",
        scale: 1
    };
}
const fontFamilyToFontType = {
    1: "draw",
    2: "sans",
    3: "mono"
};
const oc = {
    gray: [
        "#f8f9fa",
        "#e9ecef",
        "#ced4da",
        "#868e96",
        "#343a40"
    ],
    red: [
        "#fff5f5",
        "#ffc9c9",
        "#ff8787",
        "#fa5252",
        "#e03131"
    ],
    pink: [
        "#fff0f6",
        "#fcc2d7",
        "#f783ac",
        "#e64980",
        "#c2255c"
    ],
    grape: [
        "#f8f0fc",
        "#eebefa",
        "#da77f2",
        "#be4bdb",
        "#9c36b5"
    ],
    violet: [
        "#f3f0ff",
        "#d0bfff",
        "#9775fa",
        "#7950f2",
        "#6741d9"
    ],
    indigo: [
        "#edf2ff",
        "#bac8ff",
        "#748ffc",
        "#4c6ef5",
        "#3b5bdb"
    ],
    blue: [
        "#e7f5ff",
        "#a5d8ff",
        "#4dabf7",
        "#228be6",
        "#1971c2"
    ],
    cyan: [
        "#e3fafc",
        "#99e9f2",
        "#3bc9db",
        "#15aabf",
        "#0c8599"
    ],
    teal: [
        "#e6fcf5",
        "#96f2d7",
        "#38d9a9",
        "#12b886",
        "#099268"
    ],
    green: [
        "#ebfbee",
        "#b2f2bb",
        "#69db7c",
        "#40c057",
        "#2f9e44"
    ],
    lime: [
        "#f4fce3",
        "#d8f5a2",
        "#a9e34b",
        "#82c91e",
        "#66a80f"
    ],
    yellow: [
        "#fff9db",
        "#ffec99",
        "#ffd43b",
        "#fab005",
        "#f08c00"
    ],
    orange: [
        "#fff4e6",
        "#ffd8a8",
        "#ffa94d",
        "#fd7e14",
        "#e8590c"
    ]
};
function mapExcalidrawColorToTldrawColors(excalidrawColor, light, dark) {
    const colors = [
        0,
        1,
        2,
        3,
        4
    ].map((index)=>oc[excalidrawColor][index]);
    return Object.fromEntries(colors.map((c, i)=>[
            c,
            i < 3 ? light : dark
        ]));
}
const colorsToColors = {
    ...mapExcalidrawColorToTldrawColors("gray", "grey", "black"),
    ...mapExcalidrawColorToTldrawColors("red", "light-red", "red"),
    ...mapExcalidrawColorToTldrawColors("pink", "light-red", "red"),
    ...mapExcalidrawColorToTldrawColors("grape", "light-violet", "violet"),
    ...mapExcalidrawColorToTldrawColors("blue", "light-blue", "blue"),
    ...mapExcalidrawColorToTldrawColors("cyan", "light-blue", "blue"),
    ...mapExcalidrawColorToTldrawColors("teal", "light-green", "green"),
    ...mapExcalidrawColorToTldrawColors("green", "light-green", "green"),
    ...mapExcalidrawColorToTldrawColors("yellow", "yellow", "orange"),
    ...mapExcalidrawColorToTldrawColors("orange", "yellow", "orange"),
    "#ffffff": "white",
    "#000000": "black"
};
const strokeStylesToStrokeTypes = {
    solid: "draw",
    dashed: "dashed",
    dotted: "dotted"
};
const fillStylesToFillType = {
    "cross-hatch": "pattern",
    hachure: "pattern",
    solid: "solid"
};
const textAlignToAlignTypes = {
    left: "start",
    center: "middle",
    right: "end"
};
const textAlignToTextAlignTypes = {
    left: "start",
    center: "middle",
    right: "end"
};
const arrowheadsToArrowheadTypes = {
    arrow: "arrow",
    dot: "dot",
    triangle: "triangle",
    bar: "pipe"
};
function getBend(element, startPoint, endPoint) {
    let bend = 0;
    if (element.points.length > 2) {
        const start = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](startPoint[0], startPoint[1]);
        const end = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](endPoint[0], endPoint[1]);
        const handle = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](element.points[1][0], element.points[1][1]);
        const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(end, start);
        const v = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Per(delta);
        const med = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Med(end, start);
        const A = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(med, v);
        const B = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(med, v);
        const point = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].NearestPointOnLineSegment(A, B, handle, false);
        bend = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(point, med);
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Clockwise(point, end, med)) bend *= -1;
    }
    return bend;
}
const getDash = (element)=>{
    let dash = strokeStylesToStrokeTypes[element.strokeStyle] ?? "draw";
    if (dash === "draw" && element.roughness === 0) {
        dash = "solid";
    }
    return dash;
};
const getFill = (element)=>{
    if (element.backgroundColor === "transparent") {
        return "none";
    }
    return fillStylesToFillType[element.fillStyle] ?? "solid";
};
;
 //# sourceMappingURL=putExcalidrawContent.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/richText.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KeyboardShiftEnterTweakExtension",
    ()=>KeyboardShiftEnterTweakExtension,
    "defaultAddFontsFromNode",
    ()=>defaultAddFontsFromNode,
    "isEmptyRichText",
    ()=>isEmptyRichText,
    "renderHtmlFromRichText",
    ()=>renderHtmlFromRichText,
    "renderHtmlFromRichTextForMeasurement",
    ()=>renderHtmlFromRichTextForMeasurement,
    "renderPlaintextFromRichText",
    ()=>renderPlaintextFromRichText,
    "renderRichTextFromHTML",
    ()=>renderRichTextFromHTML,
    "tipTapDefaultExtensions",
    ()=>tipTapDefaultExtensions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-code/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$highlight$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-highlight/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$starter$2d$kit$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/starter-kit/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$defaultFonts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/defaultFonts.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const KeyboardShiftEnterTweakExtension = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "keyboardShiftEnterHandler",
    addKeyboardShortcuts () {
        return {
            // We don't support soft breaks, so we just use the default enter command.
            "Shift-Enter": ({ editor })=>editor.commands.enter()
        };
    }
});
__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Code"].config.excludes = void 0;
__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$highlight$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Highlight"].config.priority = 1100;
const tipTapDefaultExtensions = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$starter$2d$kit$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StarterKit"].configure({
        blockquote: false,
        codeBlock: false,
        horizontalRule: false,
        link: {
            openOnClick: false,
            autolink: true
        },
        // Prevent trailing paragraph insertion after lists (fixes #7641)
        trailingNode: {
            notAfter: [
                "paragraph",
                "bulletList",
                "orderedList",
                "listItem"
            ]
        }
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$highlight$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Highlight"],
    KeyboardShiftEnterTweakExtension,
    // N.B. We disable the text direction core extension in RichTextArea,
    // but we add it back in again here in our own extensions list so that
    // people can omit/override it if they want to.
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extensions"].TextDirection.configure({
        direction: "auto"
    })
];
const htmlCache = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"]();
function renderHtmlFromRichText(editor, richText) {
    return htmlCache.get(richText, ()=>{
        const tipTapExtensions = editor.getTextOptions().tipTapConfig?.extensions ?? tipTapDefaultExtensions;
        const html = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateHTML"])(richText, tipTapExtensions);
        return html.replaceAll('<p dir="auto"></p>', "<p><br /></p>") ?? "";
    });
}
function renderHtmlFromRichTextForMeasurement(editor, richText) {
    const html = renderHtmlFromRichText(editor, richText);
    return `<div class="tl-rich-text">${html}</div>`;
}
const plainTextFromRichTextCache = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"]();
function isEmptyRichText(richText) {
    if (richText.content.length === 1) {
        if (!richText.content[0].content) return true;
    }
    return false;
}
function renderPlaintextFromRichText(editor, richText) {
    if (isEmptyRichText(richText)) return "";
    return plainTextFromRichTextCache.get(richText, ()=>{
        const tipTapExtensions = editor.getTextOptions().tipTapConfig?.extensions ?? tipTapDefaultExtensions;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateText"])(richText, tipTapExtensions, {
            blockSeparator: "\n"
        });
    });
}
function renderRichTextFromHTML(editor, html) {
    const tipTapExtensions = editor.getTextOptions().tipTapConfig?.extensions ?? tipTapDefaultExtensions;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateJSON"])(html, tipTapExtensions);
}
function defaultAddFontsFromNode(node, state, addFont) {
    for (const mark of node.marks){
        if (mark.type.name === "bold" && state.weight !== "bold") {
            state = {
                ...state,
                weight: "bold"
            };
        }
        if (mark.type.name === "italic" && state.style !== "italic") {
            state = {
                ...state,
                style: "italic"
            };
        }
        if (mark.type.name === "code" && state.family !== "tldraw_mono") {
            state = {
                ...state,
                family: "tldraw_mono"
            };
        }
    }
    const fontsForFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$defaultFonts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFontFaces"], state.family);
    if (!fontsForFamily) return state;
    const fontsForStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(fontsForFamily, state.style);
    if (!fontsForStyle) return state;
    const fontsForWeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(fontsForStyle, state.weight);
    if (!fontsForWeight) return state;
    addFont(fontsForWeight);
    return state;
}
;
 //# sourceMappingURL=richText.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/text.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cleanupText",
    ()=>cleanupText,
    "convertCommonTitleHTMLEntities",
    ()=>convertCommonTitleHTMLEntities,
    "isRightToLeftLanguage",
    ()=>isRightToLeftLanguage,
    "truncateStringWithEllipsis",
    ()=>truncateStringWithEllipsis
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$TextHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/TextHelpers.mjs [app-client] (ecmascript)");
;
const rtlRegex = /[\u0590-\u05FF\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
function isRightToLeftLanguage(text) {
    return rtlRegex.test(text);
}
function replaceTabsWithSpaces(text) {
    return text.replace(/\t/g, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$TextHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INDENT"]);
}
function stripCommonMinimumIndentation(text) {
    const lines = text.split("\n");
    while(lines[0] && lines[0].trim().length === 0){
        lines.shift();
    }
    let minIndentation = Infinity;
    for (const line of lines){
        if (line.trim().length > 0) {
            const indentation = line.length - line.trimStart().length;
            minIndentation = Math.min(minIndentation, indentation);
        }
    }
    return lines.map((line)=>line.slice(minIndentation)).join("\n");
}
const COMMON_ENTITY_MAP = {
    "&amp;": "&",
    "&quot;": '"',
    "&apos;": "'",
    "&#27;": "'",
    "&#34;": '"',
    "&#38;": "&",
    "&#39;": "'",
    "&#8211;": "\u2013",
    "&#8212;": "\u2014",
    "&#8216;": "\u2018",
    "&#8217;": "\u2019",
    "&#8220;": "\u201C",
    "&#8221;": "\u201D",
    "&#8230;": "\u2026"
};
const entityRegex = new RegExp(Object.keys(COMMON_ENTITY_MAP).join("|"), "g");
function convertCommonTitleHTMLEntities(text) {
    return text.replace(entityRegex, (m)=>COMMON_ENTITY_MAP[m]);
}
function stripTrailingWhitespace(text) {
    return text.replace(/[ \t]+$/gm, "").replace(/\n+$/, "");
}
function cleanupText(text) {
    return stripTrailingWhitespace(stripCommonMinimumIndentation(replaceTabsWithSpaces(text)));
}
const truncateStringWithEllipsis = (str, maxLength)=>{
    return str.length <= maxLength ? str : str.substring(0, maxLength - 3) + "...";
};
;
 //# sourceMappingURL=text.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/embeds/embeds.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getEmbedInfo",
    ()=>getEmbedInfo,
    "matchEmbedUrl",
    ()=>matchEmbedUrl,
    "matchUrl",
    ()=>matchUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
function escapeStringRegexp(string) {
    if (typeof string !== "string") {
        throw new TypeError("Expected a string");
    }
    return string.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
function matchEmbedUrl(definitions, url) {
    const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
    if (!parsed) return;
    const host = parsed.host.replace("www.", "");
    for (const localEmbedDef of definitions){
        if (checkHostnames(localEmbedDef.hostnames, host)) {
            const originalUrl = localEmbedDef.fromEmbedUrl(url);
            if (originalUrl) {
                return {
                    definition: localEmbedDef,
                    url: originalUrl,
                    embedUrl: url
                };
            }
        }
    }
}
const globlikeRegExp = (input)=>{
    return input.split("*").map((str)=>escapeStringRegexp(str)).join(".+");
};
const checkHostnames = (hostnames, targetHostname)=>{
    return !!hostnames.find((hostname)=>{
        const re = new RegExp(globlikeRegExp(hostname));
        return targetHostname.match(re);
    });
};
function matchUrl(definitions, url) {
    const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
    if (!parsed) return;
    const host = parsed.host.replace("www.", "");
    for (const localEmbedDef of definitions){
        if (checkHostnames(localEmbedDef.hostnames, host)) {
            const embedUrl = localEmbedDef.toEmbedUrl(url);
            if (embedUrl) {
                return {
                    definition: localEmbedDef,
                    embedUrl,
                    url
                };
            }
        }
    }
}
function getEmbedInfo(definitions, inputUrl) {
    try {
        return matchUrl(definitions, inputUrl) ?? matchEmbedUrl(definitions, inputUrl);
    } catch  {
        return void 0;
    }
}
;
 //# sourceMappingURL=embeds.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/shapes/shapes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTextLabels",
    ()=>getTextLabels
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Group2d.mjs [app-client] (ecmascript)");
;
function getTextLabels(geometry) {
    if (geometry.isLabel) {
        return [
            geometry
        ];
    }
    if (geometry instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group2d"]) {
        return geometry.children.filter((child)=>child.isLabel);
    }
    return [];
}
;
 //# sourceMappingURL=shapes.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/static-assets/assetUrls.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultEditorAssetUrls",
    ()=>defaultEditorAssetUrls,
    "setDefaultEditorAssetUrls",
    ()=>setDefaultEditorAssetUrls,
    "useDefaultEditorAssetsWithOverrides",
    ()=>useDefaultEditorAssetsWithOverrides
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/assets.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
let defaultEditorAssetUrls = {
    fonts: {
        tldraw_mono: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexMono-Medium.woff2`,
        tldraw_mono_italic: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexMono-MediumItalic.woff2`,
        tldraw_mono_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexMono-Bold.woff2`,
        tldraw_mono_italic_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexMono-BoldItalic.woff2`,
        tldraw_serif: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSerif-Medium.woff2`,
        tldraw_serif_italic: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSerif-MediumItalic.woff2`,
        tldraw_serif_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSerif-Bold.woff2`,
        tldraw_serif_italic_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSerif-BoldItalic.woff2`,
        tldraw_sans: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSans-Medium.woff2`,
        tldraw_sans_italic: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSans-MediumItalic.woff2`,
        tldraw_sans_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSans-Bold.woff2`,
        tldraw_sans_italic_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/IBMPlexSans-BoldItalic.woff2`,
        tldraw_draw: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/Shantell_Sans-Informal_Regular.woff2`,
        tldraw_draw_italic: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/Shantell_Sans-Informal_Regular_Italic.woff2`,
        tldraw_draw_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/Shantell_Sans-Informal_Bold.woff2`,
        tldraw_draw_italic_bold: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultCdnBaseUrl"])()}/fonts/Shantell_Sans-Informal_Bold_Italic.woff2`
    }
};
function setDefaultEditorAssetUrls(assetUrls) {
    defaultEditorAssetUrls = assetUrls;
}
function useDefaultEditorAssetsWithOverrides(overrides) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDefaultEditorAssetsWithOverrides.useMemo": ()=>{
            if (!overrides) return defaultEditorAssetUrls;
            return {
                fonts: {
                    ...defaultEditorAssetUrls.fonts,
                    ...overrides?.fonts
                }
            };
        }
    }["useDefaultEditorAssetsWithOverrides.useMemo"], [
        overrides
    ]);
}
;
 //# sourceMappingURL=assetUrls.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/assets/preload-font.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "preloadFont",
    ()=>preloadFont
]);
async function preloadFont(id, font) {
    const { url, style = "normal", weight = "500", display, featureSettings, stretch, unicodeRange, variant, format } = font;
    const descriptors = {
        style,
        weight,
        display,
        featureSettings,
        stretch,
        unicodeRange,
        // @ts-expect-error why is this here
        variant
    };
    const fontInstance = new FontFace(id, `url(${url})`, descriptors);
    await fontInstance.load();
    document.fonts.add(fontInstance);
    fontInstance.$$_url = url;
    fontInstance.$$_fontface = `
@font-face {
	font-family: ${fontInstance.family};
	font-stretch: ${fontInstance.stretch};
	font-weight: ${fontInstance.weight};
	font-style: ${fontInstance.style};
	src: url("${url}") format("${format}")
}`;
    return fontInstance;
}
;
 //# sourceMappingURL=preload-font.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/tldr/buildFromV1Document.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TLV1AlignStyle",
    ()=>TLV1AlignStyle,
    "TLV1AssetType",
    ()=>TLV1AssetType,
    "TLV1ColorStyle",
    ()=>TLV1ColorStyle,
    "TLV1DashStyle",
    ()=>TLV1DashStyle,
    "TLV1Decoration",
    ()=>TLV1Decoration,
    "TLV1FontStyle",
    ()=>TLV1FontStyle,
    "TLV1ShapeType",
    ()=>TLV1ShapeType,
    "TLV1SizeStyle",
    ()=>TLV1SizeStyle,
    "buildFromV1Document",
    ()=>buildFromV1Document
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/shared.mjs [app-client] (ecmascript)");
;
;
const TLDRAW_V1_VERSION = 15.5;
function buildFromV1Document(editor, _document) {
    let document = _document;
    editor.run(()=>{
        document = migrate(document, TLDRAW_V1_VERSION);
        editor.cancel().cancel().cancel().cancel();
        const firstPageId = editor.getPages()[0].id;
        editor.setCurrentPage(firstPageId);
        for (const page of editor.getPages().slice(1)){
            editor.deletePage(page.id);
        }
        editor.selectAll();
        editor.deleteShapes(editor.getSelectedShapeIds());
        const v1AssetIdsToV2AssetIds = /* @__PURE__ */ new Map();
        Object.values(document.assets ?? {}).forEach((v1Asset)=>{
            switch(v1Asset.type){
                case "image" /* Image */ :
                    {
                        const assetId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId();
                        v1AssetIdsToV2AssetIds.set(v1Asset.id, assetId);
                        const placeholderAsset = {
                            id: assetId,
                            typeName: "asset",
                            type: "image",
                            props: {
                                w: coerceDimension(v1Asset.size[0]),
                                h: coerceDimension(v1Asset.size[1]),
                                name: v1Asset.fileName ?? "Untitled",
                                isAnimated: false,
                                mimeType: null,
                                src: v1Asset.src
                            },
                            meta: {}
                        };
                        editor.createAssets([
                            placeholderAsset
                        ]);
                        tryMigrateAsset(editor, placeholderAsset);
                        break;
                    }
                case "video" /* Video */ :
                    {
                        const assetId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId();
                        v1AssetIdsToV2AssetIds.set(v1Asset.id, assetId);
                        editor.createAssets([
                            {
                                id: assetId,
                                typeName: "asset",
                                type: "video",
                                props: {
                                    w: coerceDimension(v1Asset.size[0]),
                                    h: coerceDimension(v1Asset.size[1]),
                                    name: v1Asset.fileName ?? "Untitled",
                                    isAnimated: true,
                                    mimeType: null,
                                    src: v1Asset.src
                                },
                                meta: {}
                            }
                        ]);
                    }
                    break;
            }
        });
        const v1PageIdsToV2PageIds = /* @__PURE__ */ new Map();
        Object.values(document.pages ?? {}).sort((a, b)=>(a.childIndex ?? 1) < (b.childIndex ?? 1) ? -1 : 1).forEach((v1Page, i)=>{
            if (i === 0) {
                v1PageIdsToV2PageIds.set(v1Page.id, editor.getCurrentPageId());
            } else {
                const pageId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].createId();
                v1PageIdsToV2PageIds.set(v1Page.id, pageId);
                editor.createPage({
                    name: v1Page.name ?? "Page",
                    id: pageId
                });
            }
        });
        Object.values(document.pages ?? {}).sort((a, b)=>(a.childIndex ?? 1) < (b.childIndex ?? 1) ? -1 : 1).forEach((v1Page)=>{
            editor.setCurrentPage(v1PageIdsToV2PageIds.get(v1Page.id));
            const v1ShapeIdsToV2ShapeIds = /* @__PURE__ */ new Map();
            const v1GroupShapeIdsToV1ChildIds = /* @__PURE__ */ new Map();
            const v1Shapes = Object.values(v1Page.shapes ?? {}).sort((a, b)=>a.childIndex < b.childIndex ? -1 : 1).slice(0, editor.options.maxShapesPerPage);
            v1Shapes.forEach((v1Shape)=>{
                if (v1Shape.type !== "group" /* Group */ ) return;
                const shapeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
                v1ShapeIdsToV2ShapeIds.set(v1Shape.id, shapeId);
                v1GroupShapeIdsToV1ChildIds.set(v1Shape.id, []);
            });
            function decideNotToCreateShape(v1Shape) {
                v1ShapeIdsToV2ShapeIds.delete(v1Shape.id);
                const v1GroupParent = v1GroupShapeIdsToV1ChildIds.has(v1Shape.parentId);
                if (v1GroupParent) {
                    const ids = v1GroupShapeIdsToV1ChildIds.get(v1Shape.parentId).filter((id)=>id !== v1Shape.id);
                    v1GroupShapeIdsToV1ChildIds.set(v1Shape.parentId, ids);
                }
            }
            v1Shapes.forEach((v1Shape)=>{
                if (v1Shape.type === "group" /* Group */ ) {
                    return;
                }
                const shapeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
                v1ShapeIdsToV2ShapeIds.set(v1Shape.id, shapeId);
                if (v1Shape.parentId !== v1Page.id) {
                    if (v1GroupShapeIdsToV1ChildIds.has(v1Shape.parentId)) {
                        v1GroupShapeIdsToV1ChildIds.get(v1Shape.parentId).push(v1Shape.id);
                    } else {
                        console.warn("parent does not exist", v1Shape);
                    }
                }
                const parentId = v1PageIdsToV2PageIds.get(v1Page.id);
                const inCommon = {
                    id: shapeId,
                    parentId,
                    x: coerceNumber(v1Shape.point[0]),
                    y: coerceNumber(v1Shape.point[1]),
                    rotation: 0,
                    isLocked: !!v1Shape.isLocked
                };
                switch(v1Shape.type){
                    case "sticky" /* Sticky */ :
                        {
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "note",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.text ?? ""),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        align: getV2Align(v1Shape.style.textAlign)
                                    }
                                }
                            ]);
                            break;
                        }
                    case "rectangle" /* Rectangle */ :
                        {
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "geo",
                                    props: {
                                        geo: "rectangle",
                                        w: coerceDimension(v1Shape.size[0]),
                                        h: coerceDimension(v1Shape.size[1]),
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.label ?? ""),
                                        fill: getV2Fill(v1Shape.style.isFilled, v1Shape.style.color),
                                        labelColor: getV2Color(v1Shape.style.color),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        dash: getV2Dash(v1Shape.style.dash),
                                        align: "middle"
                                    }
                                }
                            ]);
                            const pageBoundsBeforeLabel = editor.getShapePageBounds(inCommon.id);
                            editor.updateShapes([
                                {
                                    id: inCommon.id,
                                    type: "geo",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.label ?? "")
                                    }
                                }
                            ]);
                            if (pageBoundsBeforeLabel.width === pageBoundsBeforeLabel.height) {
                                const shape = editor.getShape(inCommon.id);
                                const { growY } = shape.props;
                                const w = coerceDimension(shape.props.w);
                                const h = coerceDimension(shape.props.h);
                                const newW = w + growY / 2;
                                const newH = h + growY / 2;
                                editor.updateShapes([
                                    {
                                        id: inCommon.id,
                                        type: "geo",
                                        x: coerceNumber(shape.x) - (newW - w) / 2,
                                        y: coerceNumber(shape.y) - (newH - h) / 2,
                                        props: {
                                            w: newW,
                                            h: newH
                                        }
                                    }
                                ]);
                            }
                            break;
                        }
                    case "triangle" /* Triangle */ :
                        {
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "geo",
                                    props: {
                                        geo: "triangle",
                                        w: coerceDimension(v1Shape.size[0]),
                                        h: coerceDimension(v1Shape.size[1]),
                                        fill: getV2Fill(v1Shape.style.isFilled, v1Shape.style.color),
                                        labelColor: getV2Color(v1Shape.style.color),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        dash: getV2Dash(v1Shape.style.dash),
                                        align: "middle"
                                    }
                                }
                            ]);
                            const pageBoundsBeforeLabel = editor.getShapePageBounds(inCommon.id);
                            editor.updateShapes([
                                {
                                    id: inCommon.id,
                                    type: "geo",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.label ?? "")
                                    }
                                }
                            ]);
                            if (pageBoundsBeforeLabel.width === pageBoundsBeforeLabel.height) {
                                const shape = editor.getShape(inCommon.id);
                                const { growY } = shape.props;
                                const w = coerceDimension(shape.props.w);
                                const h = coerceDimension(shape.props.h);
                                const newW = w + growY / 2;
                                const newH = h + growY / 2;
                                editor.updateShapes([
                                    {
                                        id: inCommon.id,
                                        type: "geo",
                                        x: coerceNumber(shape.x) - (newW - w) / 2,
                                        y: coerceNumber(shape.y) - (newH - h) / 2,
                                        props: {
                                            w: newW,
                                            h: newH
                                        }
                                    }
                                ]);
                            }
                            break;
                        }
                    case "ellipse" /* Ellipse */ :
                        {
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "geo",
                                    props: {
                                        geo: "ellipse",
                                        w: coerceDimension(v1Shape.radius[0]) * 2,
                                        h: coerceDimension(v1Shape.radius[1]) * 2,
                                        fill: getV2Fill(v1Shape.style.isFilled, v1Shape.style.color),
                                        labelColor: getV2Color(v1Shape.style.color),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        dash: getV2Dash(v1Shape.style.dash),
                                        align: "middle"
                                    }
                                }
                            ]);
                            const pageBoundsBeforeLabel = editor.getShapePageBounds(inCommon.id);
                            editor.updateShapes([
                                {
                                    id: inCommon.id,
                                    type: "geo",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.label ?? "")
                                    }
                                }
                            ]);
                            if (pageBoundsBeforeLabel.width === pageBoundsBeforeLabel.height) {
                                const shape = editor.getShape(inCommon.id);
                                const { growY } = shape.props;
                                const w = coerceDimension(shape.props.w);
                                const h = coerceDimension(shape.props.h);
                                const newW = w + growY / 2;
                                const newH = h + growY / 2;
                                editor.updateShapes([
                                    {
                                        id: inCommon.id,
                                        type: "geo",
                                        x: coerceNumber(shape.x) - (newW - w) / 2,
                                        y: coerceNumber(shape.y) - (newH - h) / 2,
                                        props: {
                                            w: newW,
                                            h: newH
                                        }
                                    }
                                ]);
                            }
                            break;
                        }
                    case "draw" /* Draw */ :
                        {
                            if (v1Shape.points.length === 0) {
                                decideNotToCreateShape(v1Shape);
                                break;
                            }
                            const points = v1Shape.points.map(getV2Point);
                            const base64Points = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b64Vecs"].encodePoints(points);
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "draw",
                                    props: {
                                        fill: getV2Fill(v1Shape.style.isFilled, v1Shape.style.color),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        dash: getV2Dash(v1Shape.style.dash),
                                        isPen: false,
                                        isComplete: v1Shape.isComplete,
                                        segments: [
                                            {
                                                type: "free",
                                                path: base64Points
                                            }
                                        ],
                                        scale: 1,
                                        scaleX: 1,
                                        scaleY: 1
                                    }
                                }
                            ]);
                            break;
                        }
                    case "arrow" /* Arrow */ :
                        {
                            const v1Bend = coerceNumber(v1Shape.bend);
                            const v1Start = getV2Point(v1Shape.handles.start.point);
                            const v1End = getV2Point(v1Shape.handles.end.point);
                            const dist = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(v1Start, v1End);
                            const v2Bend = dist * -v1Bend / 2;
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "arrow",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.label ?? ""),
                                        color: getV2Color(v1Shape.style.color),
                                        labelColor: getV2Color(v1Shape.style.color),
                                        size: getV2Size(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        dash: getV2Dash(v1Shape.style.dash),
                                        arrowheadStart: getV2Arrowhead(v1Shape.decorations?.start),
                                        arrowheadEnd: getV2Arrowhead(v1Shape.decorations?.end),
                                        start: {
                                            x: coerceNumber(v1Shape.handles.start.point[0]),
                                            y: coerceNumber(v1Shape.handles.start.point[1])
                                        },
                                        end: {
                                            x: coerceNumber(v1Shape.handles.end.point[0]),
                                            y: coerceNumber(v1Shape.handles.end.point[1])
                                        },
                                        bend: v2Bend
                                    }
                                }
                            ]);
                            break;
                        }
                    case "text" /* Text */ :
                        {
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "text",
                                    props: {
                                        richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(v1Shape.text ?? " "),
                                        color: getV2Color(v1Shape.style.color),
                                        size: getV2TextSize(v1Shape.style.size),
                                        font: getV2Font(v1Shape.style.font),
                                        textAlign: getV2TextAlign(v1Shape.style.textAlign),
                                        scale: v1Shape.style.scale ?? 1
                                    }
                                }
                            ]);
                            break;
                        }
                    case "image" /* Image */ :
                        {
                            const assetId = v1AssetIdsToV2AssetIds.get(v1Shape.assetId);
                            if (!assetId) {
                                console.warn("Could not find asset id", v1Shape.assetId);
                                return;
                            }
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "image",
                                    props: {
                                        w: coerceDimension(v1Shape.size[0]),
                                        h: coerceDimension(v1Shape.size[1]),
                                        assetId
                                    }
                                }
                            ]);
                            break;
                        }
                    case "video" /* Video */ :
                        {
                            const assetId = v1AssetIdsToV2AssetIds.get(v1Shape.assetId);
                            if (!assetId) {
                                console.warn("Could not find asset id", v1Shape.assetId);
                                return;
                            }
                            editor.createShapes([
                                {
                                    ...inCommon,
                                    type: "video",
                                    props: {
                                        w: coerceDimension(v1Shape.size[0]),
                                        h: coerceDimension(v1Shape.size[1]),
                                        assetId
                                    }
                                }
                            ]);
                            break;
                        }
                }
                const rotation = coerceNumber(v1Shape.rotation);
                if (rotation !== 0) {
                    editor.select(shapeId);
                    editor.rotateShapesBy([
                        shapeId
                    ], rotation);
                }
            });
            v1GroupShapeIdsToV1ChildIds.forEach((v1ChildIds, v1GroupId)=>{
                const v2ChildShapeIds = v1ChildIds.map((id)=>v1ShapeIdsToV2ShapeIds.get(id));
                const v2GroupId = v1ShapeIdsToV2ShapeIds.get(v1GroupId);
                editor.groupShapes(v2ChildShapeIds, {
                    groupId: v2GroupId
                });
                const v1Group = v1Page.shapes[v1GroupId];
                const rotation = coerceNumber(v1Group.rotation);
                if (rotation !== 0) {
                    editor.select(v2GroupId);
                    editor.rotateShapesBy([
                        v2GroupId
                    ], rotation);
                }
            });
            v1Shapes.forEach((v1Shape)=>{
                if (v1Shape.type !== "arrow" /* Arrow */ ) {
                    return;
                }
                const v2ShapeId = v1ShapeIdsToV2ShapeIds.get(v1Shape.id);
                const util = editor.getShapeUtil("arrow");
                editor.inputs.setCtrlKey(false);
                for (const handleId of [
                    "start",
                    "end"
                ]){
                    const bindingId = v1Shape.handles[handleId].bindingId;
                    if (bindingId) {
                        const binding = v1Page.bindings[bindingId];
                        if (!binding) {
                            continue;
                        }
                        const targetId = v1ShapeIdsToV2ShapeIds.get(binding.toId);
                        const targetShape = editor.getShape(targetId);
                        if (!targetShape) continue;
                        if (targetId) {
                            const bounds2 = editor.getShapePageBounds(targetId);
                            const v2ShapeFresh = editor.getShape(v2ShapeId);
                            const nx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])((coerceNumber(binding.point[0]) + 0.5) / 2, 0.2, 0.8);
                            const ny = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])((coerceNumber(binding.point[1]) + 0.5) / 2, 0.2, 0.8);
                            const point = editor.getPointInShapeSpace(v2ShapeFresh, {
                                x: bounds2.minX + bounds2.width * nx,
                                y: bounds2.minY + bounds2.height * ny
                            });
                            const handles = editor.getShapeHandles(v2ShapeFresh);
                            const change = util.onHandleDrag(v2ShapeFresh, {
                                handle: {
                                    ...handles.find((h)=>h.id === handleId),
                                    x: point.x,
                                    y: point.y
                                },
                                isPrecise: point.x !== 0.5 || point.y !== 0.5,
                                isCreatingShape: true
                            });
                            if (change) {
                                editor.updateShape(change);
                            }
                            const freshBinding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, editor.getShape(v2ShapeId))[handleId];
                            if (freshBinding) {
                                const updatedFreshBinding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(freshBinding);
                                if (binding.distance === 0) {
                                    updatedFreshBinding.props.isExact = true;
                                }
                                if (updatedFreshBinding.toId !== targetId) {
                                    updatedFreshBinding.toId = targetId;
                                    updatedFreshBinding.props.normalizedAnchor = {
                                        x: nx,
                                        y: ny
                                    };
                                }
                                editor.updateBinding(updatedFreshBinding);
                            }
                        }
                    }
                }
            });
        });
        editor.setCurrentPage(firstPageId);
        editor.clearHistory();
        editor.selectNone();
        const bounds = editor.getCurrentPageBounds();
        if (bounds) {
            editor.zoomToBounds(bounds, {
                targetZoom: 1
            });
        }
    });
}
function coerceNumber(n) {
    if (typeof n !== "number") return 0;
    if (Number.isNaN(n)) return 0;
    if (!Number.isFinite(n)) return 0;
    return n;
}
function coerceDimension(d) {
    const n = coerceNumber(d);
    if (n <= 0) return 1;
    return n;
}
async function tryMigrateAsset(editor, placeholderAsset) {
    try {
        if (placeholderAsset.type === "bookmark" || !placeholderAsset.props.src) return;
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(placeholderAsset.props.src);
        if (!response.ok) return;
        const file = new File([
            await response.blob()
        ], placeholderAsset.props.name, {
            type: response.headers.get("content-type") ?? placeholderAsset.props.mimeType ?? void 0
        });
        const newAsset = await editor.getAssetForExternalContent({
            type: "file",
            file
        });
        if (!newAsset) throw new Error("Could not get asset for external content");
        if (newAsset.type === "bookmark") return;
        editor.updateAssets([
            {
                id: placeholderAsset.id,
                type: placeholderAsset.type,
                props: {
                    ...newAsset.props,
                    name: placeholderAsset.props.name
                }
            }
        ]);
    } catch  {}
}
function migrate(document, newVersion) {
    const { version = 0 } = document;
    if (!document.assets) {
        document.assets = {};
    }
    const assetIdsInUse = /* @__PURE__ */ new Set();
    Object.values(document.pages).forEach((page)=>Object.values(page.shapes).forEach((shape)=>{
            const { parentId, children, assetId } = shape;
            if (assetId) {
                assetIdsInUse.add(assetId);
            }
            if (parentId !== page.id && !page.shapes[parentId]) {
                console.warn("Encountered a shape with a missing parent!");
                shape.parentId = page.id;
            }
            if (shape.type === "group" /* Group */  && children) {
                children.forEach((childId)=>{
                    if (!page.shapes[childId]) {
                        console.warn("Encountered a parent with a missing child!", shape.id, childId);
                        children?.splice(children.indexOf(childId), 1);
                    }
                });
            }
        }));
    Object.keys(document.assets).forEach((assetId)=>{
        if (!assetIdsInUse.has(assetId)) {
            delete document.assets[assetId];
        }
    });
    if (version !== newVersion) {
        if (version < 14) {
            Object.values(document.pages).forEach((page)=>{
                Object.values(page.shapes).filter((shape)=>shape.type === "text" /* Text */ ).forEach((shape)=>{
                    if (shape.style.font === void 0) {
                        ;
                        shape.style.font = "script" /* Script */ ;
                    }
                });
            });
        }
        if (version <= 13) {
            Object.values(document.pages).forEach((page)=>{
                Object.values(page.bindings).forEach((binding)=>{
                    Object.assign(binding, binding.meta);
                });
                Object.values(page.shapes).forEach((shape)=>{
                    Object.entries(shape.style).forEach(([id, style])=>{
                        if (typeof style === "string") {
                            shape.style[id] = style.toLowerCase();
                        }
                    });
                    if (shape.type === "arrow" /* Arrow */ ) {
                        if (shape.decorations) {
                            Object.entries(shape.decorations).forEach(([id, decoration])=>{
                                if (decoration === "Arrow") {
                                    shape.decorations = {
                                        ...shape.decorations,
                                        [id]: "arrow" /* Arrow */ 
                                    };
                                }
                            });
                        }
                    }
                });
            });
        }
        if (version <= 13.1 && document.name == null) {
            document.name = "New Document";
        }
        if (version < 15 && document.assets == null) {
            document.assets = {};
        }
        Object.values(document.pages).forEach((page)=>{
            Object.values(page.shapes).forEach((shape)=>{
                if (version < 15.2) {
                    if ((shape.type === "image" /* Image */  || shape.type === "video") && shape.style.isFilled == null) {
                        shape.style.isFilled = true;
                    }
                }
                if (version < 15.3) {
                    if (shape.type === "rectangle" /* Rectangle */  || shape.type === "triangle" /* Triangle */  || shape.type === "ellipse" /* Ellipse */  || shape.type === "arrow" /* Arrow */ ) {
                        if ("text" in shape && typeof shape.text === "string") {
                            shape.label = shape.text;
                        }
                        if (!shape.label) {
                            shape.label = "";
                        }
                        if (!shape.labelPoint) {
                            shape.labelPoint = [
                                0.5,
                                0.5
                            ];
                        }
                    }
                }
            });
        });
    }
    Object.values(document.pageStates).forEach((pageState)=>{
        pageState.selectedIds = pageState.selectedIds.filter((id)=>{
            return document.pages[pageState.id].shapes[id] !== void 0;
        });
        pageState.bindingId = void 0;
        pageState.editingId = void 0;
        pageState.hoveredId = void 0;
        pageState.pointedId = void 0;
    });
    document.version = newVersion;
    return document;
}
var TLV1ShapeType = /* @__PURE__ */ ((TLV1ShapeType2)=>{
    TLV1ShapeType2["Sticky"] = "sticky";
    TLV1ShapeType2["Ellipse"] = "ellipse";
    TLV1ShapeType2["Rectangle"] = "rectangle";
    TLV1ShapeType2["Triangle"] = "triangle";
    TLV1ShapeType2["Draw"] = "draw";
    TLV1ShapeType2["Arrow"] = "arrow";
    TLV1ShapeType2["Text"] = "text";
    TLV1ShapeType2["Group"] = "group";
    TLV1ShapeType2["Image"] = "image";
    TLV1ShapeType2["Video"] = "video";
    return TLV1ShapeType2;
})(TLV1ShapeType || {});
var TLV1ColorStyle = /* @__PURE__ */ ((TLV1ColorStyle2)=>{
    TLV1ColorStyle2["White"] = "white";
    TLV1ColorStyle2["LightGray"] = "lightGray";
    TLV1ColorStyle2["Gray"] = "gray";
    TLV1ColorStyle2["Black"] = "black";
    TLV1ColorStyle2["Green"] = "green";
    TLV1ColorStyle2["Cyan"] = "cyan";
    TLV1ColorStyle2["Blue"] = "blue";
    TLV1ColorStyle2["Indigo"] = "indigo";
    TLV1ColorStyle2["Violet"] = "violet";
    TLV1ColorStyle2["Red"] = "red";
    TLV1ColorStyle2["Orange"] = "orange";
    TLV1ColorStyle2["Yellow"] = "yellow";
    return TLV1ColorStyle2;
})(TLV1ColorStyle || {});
var TLV1SizeStyle = /* @__PURE__ */ ((TLV1SizeStyle2)=>{
    TLV1SizeStyle2["Small"] = "small";
    TLV1SizeStyle2["Medium"] = "medium";
    TLV1SizeStyle2["Large"] = "large";
    return TLV1SizeStyle2;
})(TLV1SizeStyle || {});
var TLV1DashStyle = /* @__PURE__ */ ((TLV1DashStyle2)=>{
    TLV1DashStyle2["Draw"] = "draw";
    TLV1DashStyle2["Solid"] = "solid";
    TLV1DashStyle2["Dashed"] = "dashed";
    TLV1DashStyle2["Dotted"] = "dotted";
    return TLV1DashStyle2;
})(TLV1DashStyle || {});
var TLV1AlignStyle = /* @__PURE__ */ ((TLV1AlignStyle2)=>{
    TLV1AlignStyle2["Start"] = "start";
    TLV1AlignStyle2["Middle"] = "middle";
    TLV1AlignStyle2["End"] = "end";
    TLV1AlignStyle2["Justify"] = "justify";
    return TLV1AlignStyle2;
})(TLV1AlignStyle || {});
var TLV1FontStyle = /* @__PURE__ */ ((TLV1FontStyle2)=>{
    TLV1FontStyle2["Script"] = "script";
    TLV1FontStyle2["Sans"] = "sans";
    TLV1FontStyle2["Serif"] = "serif";
    TLV1FontStyle2["Mono"] = "mono";
    return TLV1FontStyle2;
})(TLV1FontStyle || {});
var TLV1Decoration = /* @__PURE__ */ ((TLV1Decoration2)=>{
    TLV1Decoration2["Arrow"] = "arrow";
    return TLV1Decoration2;
})(TLV1Decoration || {});
var TLV1AssetType = /* @__PURE__ */ ((TLV1AssetType2)=>{
    TLV1AssetType2["Image"] = "image";
    TLV1AssetType2["Video"] = "video";
    return TLV1AssetType2;
})(TLV1AssetType || {});
const v1ColorsToV2Colors = {
    ["white" /* White */ ]: "black",
    ["black" /* Black */ ]: "black",
    ["lightGray" /* LightGray */ ]: "grey",
    ["gray" /* Gray */ ]: "grey",
    ["green" /* Green */ ]: "light-green",
    ["cyan" /* Cyan */ ]: "green",
    ["blue" /* Blue */ ]: "light-blue",
    ["indigo" /* Indigo */ ]: "blue",
    ["orange" /* Orange */ ]: "orange",
    ["yellow" /* Yellow */ ]: "yellow",
    ["red" /* Red */ ]: "red",
    ["violet" /* Violet */ ]: "light-violet"
};
const v1FontsToV2Fonts = {
    ["mono" /* Mono */ ]: "mono",
    ["sans" /* Sans */ ]: "sans",
    ["script" /* Script */ ]: "draw",
    ["serif" /* Serif */ ]: "serif"
};
const v1AlignsToV2Aligns = {
    ["start" /* Start */ ]: "start",
    ["middle" /* Middle */ ]: "middle",
    ["end" /* End */ ]: "end",
    ["justify" /* Justify */ ]: "start"
};
const v1TextAlignsToV2TextAligns = {
    ["start" /* Start */ ]: "start",
    ["middle" /* Middle */ ]: "middle",
    ["end" /* End */ ]: "end",
    ["justify" /* Justify */ ]: "start"
};
const v1TextSizesToV2TextSizes = {
    ["small" /* Small */ ]: "s",
    ["medium" /* Medium */ ]: "l",
    ["large" /* Large */ ]: "xl"
};
const v1SizesToV2Sizes = {
    ["small" /* Small */ ]: "m",
    ["medium" /* Medium */ ]: "l",
    ["large" /* Large */ ]: "xl"
};
const v1DashesToV2Dashes = {
    ["solid" /* Solid */ ]: "solid",
    ["dashed" /* Dashed */ ]: "dashed",
    ["dotted" /* Dotted */ ]: "dotted",
    ["draw" /* Draw */ ]: "draw"
};
function getV2Color(color) {
    return color ? v1ColorsToV2Colors[color] ?? "black" : "black";
}
function getV2Font(font) {
    return font ? v1FontsToV2Fonts[font] ?? "draw" : "draw";
}
function getV2Align(align) {
    return align ? v1AlignsToV2Aligns[align] ?? "middle" : "middle";
}
function getV2TextAlign(align) {
    return align ? v1TextAlignsToV2TextAligns[align] ?? "middle" : "middle";
}
function getV2TextSize(size) {
    return size ? v1TextSizesToV2TextSizes[size] ?? "m" : "m";
}
function getV2Size(size) {
    return size ? v1SizesToV2Sizes[size] ?? "l" : "l";
}
function getV2Dash(dash) {
    return dash ? v1DashesToV2Dashes[dash] ?? "draw" : "draw";
}
function getV2Point(point) {
    return {
        x: coerceNumber(point[0]),
        y: coerceNumber(point[1]),
        z: point[2] == null ? 0.5 : coerceNumber(point[2])
    };
}
function getV2Arrowhead(decoration) {
    return decoration === "arrow" /* Arrow */  ? "arrow" : "none";
}
function getV2Fill(isFilled, color) {
    return isFilled ? color === "black" /* Black */  || color === "white" /* White */  ? "semi" : "solid" : "none";
}
;
 //# sourceMappingURL=buildFromV1Document.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/tldr/file.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TLDRAW_FILE_EXTENSION",
    ()=>TLDRAW_FILE_EXTENSION,
    "TLDRAW_FILE_MIMETYPE",
    ()=>TLDRAW_FILE_MIMETYPE,
    "isV1File",
    ()=>isV1File,
    "parseAndLoadDocument",
    ()=>parseAndLoadDocument,
    "parseTldrawJsonFile",
    ()=>parseTldrawJsonFile,
    "serializeTldrawJson",
    ()=>serializeTldrawJson,
    "serializeTldrawJsonBlob",
    ()=>serializeTldrawJsonBlob
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/validate/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/createTLStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$tldr$2f$buildFromV1Document$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/tldr/buildFromV1Document.mjs [app-client] (ecmascript)");
;
;
const TLDRAW_FILE_MIMETYPE = "application/vnd.tldraw+json";
const TLDRAW_FILE_EXTENSION = ".tldr";
const LATEST_TLDRAW_FILE_FORMAT_VERSION = 1;
const schemaV1 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].object({
    schemaVersion: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].literal(1),
    storeVersion: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].positiveInteger,
    recordVersions: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].dict(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].object({
        version: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].positiveInteger,
        subTypeVersions: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].dict(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].positiveInteger).optional(),
        subTypeKey: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string.optional()
    }))
});
const schemaV2 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].object({
    schemaVersion: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].literal(2),
    sequences: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].dict(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].positiveInteger)
});
const tldrawFileValidator = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].object({
    tldrawFileFormatVersion: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].nonZeroInteger,
    schema: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].numberUnion("schemaVersion", {
        1: schemaV1,
        2: schemaV2
    }),
    records: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].object({
        id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string,
        typeName: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$validate$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["T"].string
    }).allowUnknownProperties())
});
function isV1File(data) {
    try {
        if (data.document?.version) {
            return true;
        }
        return false;
    } catch  {
        return false;
    }
}
function parseTldrawJsonFile({ json, schema }) {
    let data;
    try {
        data = tldrawFileValidator.validate(JSON.parse(json));
    } catch (e) {
        try {
            data = JSON.parse(json);
            if (isV1File(data)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
                    type: "v1File",
                    data
                });
            }
        } catch  {}
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
            type: "notATldrawFile",
            cause: e
        });
    }
    if (data.tldrawFileFormatVersion > LATEST_TLDRAW_FILE_FORMAT_VERSION) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
            type: "fileFormatVersionTooNew",
            version: data.tldrawFileFormatVersion
        });
    }
    let migrationResult;
    let storeSnapshot;
    try {
        const records = pruneUnusedAssets(data.records);
        storeSnapshot = Object.fromEntries(records.map((r)=>[
                r.id,
                r
            ]));
        migrationResult = schema.migrateStoreSnapshot({
            store: storeSnapshot,
            schema: data.schema
        });
    } catch (e) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
            type: "invalidRecords",
            cause: e
        });
    }
    if (migrationResult.type === "error") {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
            type: "migrationFailed",
            reason: migrationResult.reason
        });
    }
    try {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTLStore"])({
            snapshot: {
                store: storeSnapshot,
                schema: data.schema
            },
            schema
        }));
    } catch (e) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err({
            type: "invalidRecords",
            cause: e
        });
    }
}
function pruneUnusedAssets(records) {
    const usedAssets = /* @__PURE__ */ new Set();
    for (const record of records){
        if (record.typeName === "shape" && "assetId" in record.props && record.props.assetId) {
            usedAssets.add(record.props.assetId);
        }
    }
    return records.filter((r)=>r.typeName !== "asset" || usedAssets.has(r.id));
}
async function serializeTldrawJson(editor) {
    const records = [];
    for (const record of editor.store.allRecords()){
        switch(record.typeName){
            case "asset":
                if (record.type !== "bookmark" && record.props.src && !record.props.src.startsWith("data:")) {
                    let assetSrcToSave;
                    try {
                        let src = record.props.src;
                        if (!src.startsWith("http")) {
                            src = await editor.resolveAssetUrl(record.id, {
                                shouldResolveToOriginal: true
                            }) || "";
                        }
                        assetSrcToSave = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(await (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(src)).blob());
                    } catch  {
                        assetSrcToSave = record.props.src;
                    }
                    records.push({
                        ...record,
                        props: {
                            ...record.props,
                            src: assetSrcToSave
                        }
                    });
                } else {
                    records.push(record);
                }
                break;
            default:
                records.push(record);
                break;
        }
    }
    return JSON.stringify({
        tldrawFileFormatVersion: LATEST_TLDRAW_FILE_FORMAT_VERSION,
        schema: editor.store.schema.serialize(),
        records: pruneUnusedAssets(records)
    });
}
async function serializeTldrawJsonBlob(editor) {
    return new Blob([
        await serializeTldrawJson(editor)
    ], {
        type: TLDRAW_FILE_MIMETYPE
    });
}
async function parseAndLoadDocument(editor, document, msg, addToast, onV1FileLoad, forceDarkMode) {
    const parseFileResult = parseTldrawJsonFile({
        schema: editor.store.schema,
        json: document
    });
    if (!parseFileResult.ok) {
        let description;
        switch(parseFileResult.error.type){
            case "notATldrawFile":
                editor.annotateError(parseFileResult.error.cause, {
                    origin: "file-system.open.parse",
                    willCrashApp: false,
                    tags: {
                        parseErrorType: parseFileResult.error.type
                    }
                });
                reportError(parseFileResult.error.cause);
                description = msg("file-system.file-open-error.not-a-tldraw-file");
                break;
            case "fileFormatVersionTooNew":
                description = msg("file-system.file-open-error.file-format-version-too-new");
                break;
            case "migrationFailed":
                if (parseFileResult.error.reason === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].TargetVersionTooNew) {
                    description = msg("file-system.file-open-error.file-format-version-too-new");
                } else {
                    description = msg("file-system.file-open-error.generic-corrupted-file");
                }
                break;
            case "invalidRecords":
                editor.annotateError(parseFileResult.error.cause, {
                    origin: "file-system.open.parse",
                    willCrashApp: false,
                    tags: {
                        parseErrorType: parseFileResult.error.type
                    }
                });
                reportError(parseFileResult.error.cause);
                description = msg("file-system.file-open-error.generic-corrupted-file");
                break;
            case "v1File":
                {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$tldr$2f$buildFromV1Document$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFromV1Document"])(editor, parseFileResult.error.data.document);
                    onV1FileLoad?.();
                    return;
                }
            default:
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(parseFileResult.error, "type");
        }
        addToast({
            title: msg("file-system.file-open-error.title"),
            description,
            severity: "error"
        });
        return;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
        const snapshot = parseFileResult.value.getStoreSnapshot();
        editor.loadSnapshot(snapshot);
        editor.clearHistory();
        extractAssets(editor, snapshot, msg, addToast);
        const bounds = editor.getCurrentPageBounds();
        if (bounds) {
            editor.zoomToBounds(bounds, {
                targetZoom: 1,
                immediate: true
            });
        }
    });
    if (forceDarkMode) editor.user.updateUserPreferences({
        colorScheme: "dark"
    });
}
async function extractAssets(editor, snapshot, msg, addToast) {
    const mediaAssets = /* @__PURE__ */ new Map();
    for (const record of Object.values(snapshot.store)){
        if (record.typeName === "asset" && record.props.src && record.props.src.startsWith("data:") && (record.type === "image" || record.type === "video")) {
            mediaAssets.set(record.id, record);
        }
    }
    Promise.allSettled([
        ...mediaAssets
    ].map(async ([id, asset])=>{
        try {
            const blob = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(asset.props.src).then((r)=>r.blob());
            const file = new File([
                blob
            ], asset.props.name, {
                type: asset.props.mimeType
            });
            const newAsset = await editor.getAssetForExternalContent({
                type: "file",
                file
            });
            if (!newAsset) {
                throw Error("Could not create an asset");
            }
            editor.updateAssets([
                {
                    ...newAsset,
                    id
                }
            ]);
        } catch (error) {
            addToast({
                title: msg("assets.files.upload-failed"),
                severity: "error"
            });
            console.error(error);
            return;
        }
    }));
}
;
 //# sourceMappingURL=file.mjs.map
}),
]);

//# debugId=841f9d27-db64-89ab-34a7-0938b208f0d3
//# sourceMappingURL=c427b_tldraw_dist-esm_lib_utils_a7cf18c1._.js.map