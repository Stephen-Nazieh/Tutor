;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="8333ce02-7e71-1b13-86b8-4b7a8f7ac10e")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/version.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearRegisteredVersionsForTests",
    ()=>clearRegisteredVersionsForTests,
    "registerTldrawLibraryVersion",
    ()=>registerTldrawLibraryVersion
]);
const TLDRAW_LIBRARY_VERSION_KEY = "__TLDRAW_LIBRARY_VERSIONS__";
function getLibraryVersions() {
    if (globalThis[TLDRAW_LIBRARY_VERSION_KEY]) {
        return globalThis[TLDRAW_LIBRARY_VERSION_KEY];
    }
    const info = {
        versions: [],
        didWarn: false,
        scheduledNotice: null
    };
    Object.defineProperty(globalThis, TLDRAW_LIBRARY_VERSION_KEY, {
        value: info,
        writable: false,
        configurable: false,
        enumerable: false
    });
    return info;
}
function clearRegisteredVersionsForTests() {
    const info = getLibraryVersions();
    info.versions = [];
    info.didWarn = false;
    if (info.scheduledNotice) {
        clearTimeout(info.scheduledNotice);
        info.scheduledNotice = null;
    }
}
function registerTldrawLibraryVersion(name, version, modules) {
    if (!name || !version || !modules) {
        if ("TURBOPACK compile-time truthy", 1) {
            throw new Error("Missing name/version/module system in built version of tldraw library");
        }
        return;
    }
    const info = getLibraryVersions();
    info.versions.push({
        name,
        version,
        modules
    });
    if (!info.scheduledNotice) {
        try {
            info.scheduledNotice = setTimeout(()=>{
                info.scheduledNotice = null;
                checkLibraryVersions(info);
            }, 100);
        } catch  {
            checkLibraryVersions(info);
        }
    }
}
function checkLibraryVersions(info) {
    if (!info.versions.length) return;
    if (info.didWarn) return;
    const sorted = info.versions.sort((a, b)=>compareVersions(a.version, b.version));
    const latestVersion = sorted[sorted.length - 1].version;
    const matchingVersions = /* @__PURE__ */ new Set();
    const nonMatchingVersions = /* @__PURE__ */ new Map();
    for (const lib of sorted){
        if (nonMatchingVersions.has(lib.name)) {
            matchingVersions.delete(lib.name);
            entry(nonMatchingVersions, lib.name, /* @__PURE__ */ new Set()).add(lib.version);
            continue;
        }
        if (lib.version === latestVersion) {
            matchingVersions.add(lib.name);
        } else {
            matchingVersions.delete(lib.name);
            entry(nonMatchingVersions, lib.name, /* @__PURE__ */ new Set()).add(lib.version);
        }
    }
    if (nonMatchingVersions.size > 0) {
        const message = [
            `${format("[tldraw]", [
                "bold",
                "bgRed",
                "textWhite"
            ])} ${format("You have multiple versions of tldraw libraries installed. This can lead to bugs and unexpected behavior.", [
                "textRed",
                "bold"
            ])}`,
            "",
            `The latest version you have installed is ${format(`v${latestVersion}`, [
                "bold",
                "textBlue"
            ])}. The following libraries are on the latest version:`,
            ...Array.from(matchingVersions, (name)=>`  \u2022 \u2705 ${format(name, [
                    "bold"
                ])}`),
            "",
            `The following libraries are not on the latest version, or have multiple versions installed:`,
            ...Array.from(nonMatchingVersions, ([name, versions])=>{
                const sortedVersions = Array.from(versions).sort(compareVersions).map((v)=>format(`v${v}`, v === latestVersion ? [
                        "textGreen"
                    ] : [
                        "textRed"
                    ]));
                return `  \u2022 \u274C ${format(name, [
                    "bold"
                ])} (${sortedVersions.join(", ")})`;
            })
        ];
        console.log(message.join("\n"));
        info.didWarn = true;
        return;
    }
    const potentialDuplicates = /* @__PURE__ */ new Map();
    for (const lib of sorted){
        entry(potentialDuplicates, lib.name, {
            version: lib.version,
            modules: []
        }).modules.push(lib.modules);
    }
    const duplicates = /* @__PURE__ */ new Map();
    for (const [name, lib] of potentialDuplicates){
        if (lib.modules.length > 1) duplicates.set(name, lib);
    }
    if (duplicates.size > 0) {
        const message = [
            `${format("[tldraw]", [
                "bold",
                "bgRed",
                "textWhite"
            ])} ${format("You have multiple instances of some tldraw libraries active. This can lead to bugs and unexpected behavior. ", [
                "textRed",
                "bold"
            ])}`,
            "",
            "This usually means that your bundler is misconfigured, and is importing the same library multiple times - usually once as an ES Module, and once as a CommonJS module.",
            "",
            "The following libraries have been imported multiple times:",
            ...Array.from(duplicates, ([name, lib])=>{
                const modules = lib.modules.map((m, i)=>m === "esm" ? `      ${i + 1}. ES Modules` : `      ${i + 1}. CommonJS`).join("\n");
                return `  \u2022 \u274C ${format(name, [
                    "bold"
                ])} v${lib.version}: 
${modules}`;
            }),
            "",
            "You should configure your bundler to only import one version of each library."
        ];
        console.log(message.join("\n"));
        info.didWarn = true;
        return;
    }
}
function compareVersions(a, b) {
    const aMatch = a.match(/^(\d+)\.(\d+)\.(\d+)(?:-(\w+))?$/);
    const bMatch = b.match(/^(\d+)\.(\d+)\.(\d+)(?:-(\w+))?$/);
    if (!aMatch || !bMatch) return a.localeCompare(b);
    if (aMatch[1] !== bMatch[1]) return Number(aMatch[1]) - Number(bMatch[1]);
    if (aMatch[2] !== bMatch[2]) return Number(aMatch[2]) - Number(bMatch[2]);
    if (aMatch[3] !== bMatch[3]) return Number(aMatch[3]) - Number(bMatch[3]);
    if (aMatch[4] && bMatch[4]) return aMatch[4].localeCompare(bMatch[4]);
    if (aMatch[4]) return 1;
    if (bMatch[4]) return -1;
    return 0;
}
const formats = {
    bold: "1",
    textBlue: "94",
    textRed: "31",
    textGreen: "32",
    bgRed: "41",
    textWhite: "97"
};
function format(value, formatters = []) {
    return `\x1B[${formatters.map((f)=>formats[f]).join(";")}m${value}\x1B[m`;
}
function entry(map, key, defaultValue) {
    if (map.has(key)) {
        return map.get(key);
    }
    map.set(key, defaultValue);
    return defaultValue;
}
;
 //# sourceMappingURL=version.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areArraysShallowEqual",
    ()=>areArraysShallowEqual,
    "compact",
    ()=>compact,
    "dedupe",
    ()=>dedupe,
    "last",
    ()=>last,
    "maxBy",
    ()=>maxBy,
    "mergeArraysAndReplaceDefaults",
    ()=>mergeArraysAndReplaceDefaults,
    "minBy",
    ()=>minBy,
    "partition",
    ()=>partition,
    "rotateArray",
    ()=>rotateArray
]);
function rotateArray(arr, offset) {
    if (arr.length === 0) return [];
    const normalizedOffset = (Math.abs(offset) % arr.length + arr.length) % arr.length;
    return [
        ...arr.slice(normalizedOffset),
        ...arr.slice(0, normalizedOffset)
    ];
}
function dedupe(input, equals) {
    const result = [];
    mainLoop: for (const item of input){
        for (const existing of result){
            if (equals ? equals(item, existing) : item === existing) {
                continue mainLoop;
            }
        }
        result.push(item);
    }
    return result;
}
function compact(arr) {
    return arr.filter((i)=>i !== void 0 && i !== null);
}
function last(arr) {
    return arr[arr.length - 1];
}
function minBy(arr, fn) {
    let min;
    let minVal = Infinity;
    for (const item of arr){
        const val = fn(item);
        if (val < minVal) {
            min = item;
            minVal = val;
        }
    }
    return min;
}
function maxBy(arr, fn) {
    let max;
    let maxVal = -Infinity;
    for (const item of arr){
        const val = fn(item);
        if (val > maxVal) {
            max = item;
            maxVal = val;
        }
    }
    return max;
}
function partition(arr, predicate) {
    const satisfies = [];
    const doesNotSatisfy = [];
    for (const item of arr){
        if (predicate(item)) {
            satisfies.push(item);
        } else {
            doesNotSatisfy.push(item);
        }
    }
    return [
        satisfies,
        doesNotSatisfy
    ];
}
function areArraysShallowEqual(arr1, arr2) {
    if (arr1 === arr2) return true;
    if (arr1.length !== arr2.length) return false;
    for(let i = 0; i < arr1.length; i++){
        if (!Object.is(arr1[i], arr2[i])) {
            return false;
        }
    }
    return true;
}
function mergeArraysAndReplaceDefaults(key, customEntries, defaults) {
    const overrideTypes = new Set(customEntries.map((entry)=>entry[key]));
    const result = [];
    for (const defaultEntry of defaults){
        if (overrideTypes.has(defaultEntry[key])) continue;
        result.push(defaultEntry);
    }
    for (const customEntry of customEntries){
        result.push(customEntry);
    }
    return result;
}
;
 //# sourceMappingURL=array.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/function.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noop",
    ()=>noop,
    "omitFromStackTrace",
    ()=>omitFromStackTrace
]);
function omitFromStackTrace(fn) {
    const wrappedFn = (...args)=>{
        try {
            return fn(...args);
        } catch (error) {
            if (error instanceof Error && Error.captureStackTrace) {
                Error.captureStackTrace(error, wrappedFn);
            }
            throw error;
        }
    };
    return wrappedFn;
}
const noop = ()=>{};
;
 //# sourceMappingURL=function.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Result",
    ()=>Result,
    "assert",
    ()=>assert,
    "assertExists",
    ()=>assertExists,
    "exhaustiveSwitchError",
    ()=>exhaustiveSwitchError,
    "promiseWithResolve",
    ()=>promiseWithResolve,
    "sleep",
    ()=>sleep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/function.mjs [app-client] (ecmascript)");
;
const Result = {
    /**
   * Create a successful result containing a value.
   *
   * @param value - The success value to wrap
   * @returns An OkResult containing the value
   */ ok (value) {
        return {
            ok: true,
            value
        };
    },
    /**
   * Create a failed result containing an error.
   *
   * @param error - The error value to wrap
   * @returns An ErrorResult containing the error
   */ err (error) {
        return {
            ok: false,
            error
        };
    },
    /**
   * Create a successful result containing an array of values.
   *
   * If any of the results are errors, the returned result will be an error containing the first error.
   *
   * @param results - The array of results to wrap
   * @returns An OkResult containing the array of values
   */ all (results) {
        return results.every((result)=>result.ok) ? Result.ok(results.map((result)=>result.value)) : Result.err(results.find((result)=>!result.ok)?.error);
    }
};
function exhaustiveSwitchError(value, property) {
    const debugValue = property && value && typeof value === "object" && property in value ? value[property] : value;
    throw new Error(`Unknown switch case ${debugValue}`);
}
const assert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omitFromStackTrace"])((value, message)=>{
    if (!value) {
        throw new Error(message || "Assertion Error");
    }
});
const assertExists = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omitFromStackTrace"])((value, message)=>{
    if (value == null) {
        throw new Error(message ?? "value must be defined");
    }
    return value;
});
function promiseWithResolve() {
    let resolve;
    let reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    return Object.assign(promise, {
        resolve,
        reject
    });
}
function sleep(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
;
 //# sourceMappingURL=control.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bind",
    ()=>bind
]);
/*!
 * MIT License: https://github.com/NoHomey/bind-decorator/blob/master/License
 * Copyright (c) 2016 Ivo Stratev
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
;
function bind(...args) {
    if (args.length === 2) {
        const [originalMethod, context] = args;
        context.addInitializer(function initializeMethod() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(Reflect.isExtensible(this), "Cannot bind to a non-extensible class.");
            const value = originalMethod.bind(this);
            const ok = Reflect.defineProperty(this, context.name, {
                value,
                writable: true,
                configurable: true
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(ok, "Cannot bind a non-configurable class method.");
        });
    } else {
        const [_target, propertyKey, descriptor] = args;
        if (!descriptor || typeof descriptor.value !== "function") {
            throw new TypeError(`Only methods can be decorated with @bind. <${propertyKey}> is not a method!`);
        }
        return {
            configurable: true,
            get () {
                const bound = descriptor.value.bind(this);
                Object.defineProperty(this, propertyKey, {
                    value: bound,
                    configurable: true,
                    writable: true
                });
                return bound;
            }
        };
    }
}
;
 //# sourceMappingURL=bind.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/cache.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WeakCache",
    ()=>WeakCache
]);
class WeakCache {
    /**
   * The internal WeakMap storage for cached key-value pairs.
   *
   * @public
   */ items = /* @__PURE__ */ new WeakMap();
    /**
   * Get the cached value for a given key, computing it if not already cached.
   *
   * Retrieves the cached value associated with the given key. If no cached
   * value exists, calls the provided callback function to compute the value, stores it
   * in the cache, and returns it. Subsequent calls with the same key will return the
   * cached value without recomputation.
   *
   * @param item - The object key to retrieve the cached value for
   * @param cb - Callback function that computes the value when not already cached
   * @returns The cached value if it exists, otherwise the newly computed value from the callback
   *
   * @example
   * ```ts
   * const cache = new WeakCache<HTMLElement, DOMRect>()
   * const element = document.getElementById('my-element')!
   *
   * // First call computes and caches the bounding rect
   * const rect1 = cache.get(element, (el) => el.getBoundingClientRect())
   *
   * // Second call returns cached value
   * const rect2 = cache.get(element, (el) => el.getBoundingClientRect())
   * // rect1 and rect2 are the same object
   * ```
   */ get(item, cb) {
        if (!this.items.has(item)) {
            this.items.set(item, cb(item));
        }
        return this.items.get(item);
    }
}
;
 //# sourceMappingURL=cache.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/debounce.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "debounce",
    ()=>debounce
]);
function debounce(callback, wait) {
    let state = void 0;
    const fn = (...args)=>{
        if (!state) {
            state = {};
            state.promise = new Promise((resolve, reject)=>{
                state.resolve = resolve;
                state.reject = reject;
            });
        }
        clearTimeout(state.timeout);
        state.latestArgs = args;
        state.timeout = setTimeout(()=>{
            const s = state;
            state = void 0;
            try {
                s.resolve(callback(...s.latestArgs));
            } catch (e) {
                s.reject(e);
            }
        }, wait);
        return state.promise;
    };
    fn.cancel = ()=>{
        if (!state) return;
        clearTimeout(state.timeout);
    };
    return fn;
}
;
 //# sourceMappingURL=debounce.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "annotateError",
    ()=>annotateError,
    "getErrorAnnotations",
    ()=>getErrorAnnotations
]);
const annotationsByError = /* @__PURE__ */ new WeakMap();
function annotateError(error, annotations) {
    if (typeof error !== "object" || error === null) return;
    let currentAnnotations = annotationsByError.get(error);
    if (!currentAnnotations) {
        currentAnnotations = {
            tags: {},
            extras: {}
        };
        annotationsByError.set(error, currentAnnotations);
    }
    if (annotations.tags) {
        currentAnnotations.tags = {
            ...currentAnnotations.tags,
            ...annotations.tags
        };
    }
    if (annotations.extras) {
        currentAnnotations.extras = {
            ...currentAnnotations.extras,
            ...annotations.extras
        };
    }
}
function getErrorAnnotations(error) {
    return annotationsByError.get(error) ?? {
        tags: {},
        extras: {}
    };
}
;
 //# sourceMappingURL=error.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/ExecutionQueue.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExecutionQueue",
    ()=>ExecutionQueue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
;
class ExecutionQueue {
    /**
   * Creates a new ExecutionQueue.
   *
   * Creates a new execution queue that will process tasks sequentially.
   * If a timeout is provided, there will be a delay between each task execution,
   * which is useful for rate limiting or controlling execution flow.
   *
   * timeout - Optional delay in milliseconds between task executions
   * @example
   * ```ts
   * // Create queue without delay
   * const fastQueue = new ExecutionQueue()
   *
   * // Create queue with 500ms delay between tasks
   * const slowQueue = new ExecutionQueue(500)
   * ```
   */ constructor(timeout){
        this.timeout = timeout;
    }
    queue = [];
    running = false;
    /**
   * Checks if the queue is empty and not currently running a task.
   *
   * Determines whether the execution queue has completed all tasks and is idle.
   * Returns true only when there are no pending tasks in the queue AND no task is currently being executed.
   *
   * @returns True if the queue has no pending tasks and is not currently executing
   * @example
   * ```ts
   * const queue = new ExecutionQueue()
   *
   * console.log(queue.isEmpty()) // true - queue is empty
   *
   * queue.push(() => console.log('task'))
   * console.log(queue.isEmpty()) // false - task is running/pending
   * ```
   */ isEmpty() {
        return this.queue.length === 0 && !this.running;
    }
    async run() {
        if (this.running) return;
        try {
            this.running = true;
            while(this.queue.length){
                const task = this.queue.shift();
                await task();
                if (this.timeout) {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(this.timeout);
                }
            }
        } finally{
            this.running = false;
        }
    }
    /**
   * Adds a task to the queue and returns a promise that resolves with the task's result.
   *
   * Enqueues a task for sequential execution. The task will be executed after all
   * previously queued tasks have completed. If a timeout was specified in the constructor,
   * there will be a delay between this task and the next one.
   *
   * @param task - The function to execute (can be sync or async)
   * @returns Promise that resolves with the task's return value
   * @example
   * ```ts
   * const queue = new ExecutionQueue(100)
   *
   * // Add async task
   * const result = await queue.push(async () => {
   *   const response = await fetch('/api/data')
   *   return response.json()
   * })
   *
   * // Add sync task
   * const number = await queue.push(() => 42)
   * ```
   */ async push(task) {
        return new Promise((resolve, reject)=>{
            this.queue.push(()=>Promise.resolve(task()).then(resolve).catch(reject));
            this.run();
        });
    }
    /**
   * Clears all pending tasks from the queue.
   *
   * Immediately removes all pending tasks from the queue. Any currently
   * running task will complete normally, but no additional tasks will be executed.
   * This method does not wait for the current task to finish.
   *
   * @returns void
   * @example
   * ```ts
   * const queue = new ExecutionQueue()
   *
   * // Add several tasks
   * queue.push(() => console.log('task 1'))
   * queue.push(() => console.log('task 2'))
   * queue.push(() => console.log('task 3'))
   *
   * // Clear all pending tasks
   * queue.close()
   * // Only 'task 1' will execute if it was already running
   * ```
   */ close() {
        this.queue = [];
    }
}
;
 //# sourceMappingURL=ExecutionQueue.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Image",
    ()=>Image,
    "fetch",
    ()=>fetch
]);
async function fetch(input, init) {
    return window.fetch(input, {
        // We want to make sure that the referrer is not sent to other domains.
        referrerPolicy: "strict-origin-when-cross-origin",
        ...init
    });
}
const Image = (width, height)=>{
    const img = new window.Image(width, height);
    img.referrerPolicy = "strict-origin-when-cross-origin";
    return img;
};
;
 //# sourceMappingURL=network.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FileHelpers",
    ()=>FileHelpers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
;
class FileHelpers {
    /**
   * Converts a URL to an ArrayBuffer by fetching the resource.
   *
   * Fetches the resource at the given URL and returns its content as an ArrayBuffer.
   * This is useful for loading binary data like images, videos, or other file types.
   *
   * @param url - The URL of the file to fetch
   * @returns Promise that resolves to the file content as an ArrayBuffer
   * @example
   * ```ts
   * const buffer = await FileHelpers.urlToArrayBuffer('https://example.com/image.png')
   * console.log(buffer.byteLength) // Size of the file in bytes
   * ```
   * @public
   */ static async urlToArrayBuffer(url) {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(url);
        return await response.arrayBuffer();
    }
    /**
   * Converts a URL to a Blob by fetching the resource.
   *
   * Fetches the resource at the given URL and returns its content as a Blob object.
   * Blobs are useful for handling file data in web applications.
   *
   * @param url - The URL of the file to fetch
   * @returns Promise that resolves to the file content as a Blob
   * @example
   * ```ts
   * const blob = await FileHelpers.urlToBlob('https://example.com/document.pdf')
   * console.log(blob.type) // 'application/pdf'
   * console.log(blob.size) // Size in bytes
   * ```
   * @public
   */ static async urlToBlob(url) {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(url);
        return await response.blob();
    }
    /**
   * Converts a URL to a data URL by fetching the resource.
   *
   * Fetches the resource at the given URL and converts it to a base64-encoded data URL.
   * If the URL is already a data URL, it returns the URL unchanged. This is useful for embedding
   * resources directly in HTML or CSS.
   *
   * @param url - The URL of the file to convert, or an existing data URL
   * @returns Promise that resolves to a data URL string
   * @example
   * ```ts
   * const dataUrl = await FileHelpers.urlToDataUrl('https://example.com/image.jpg')
   * // Returns: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEA...'
   *
   * const existing = await FileHelpers.urlToDataUrl('data:text/plain;base64,SGVsbG8=')
   * // Returns the same data URL unchanged
   * ```
   * @public
   */ static async urlToDataUrl(url) {
        if (url.startsWith("data:")) return url;
        const blob = await FileHelpers.urlToBlob(url);
        return await FileHelpers.blobToDataUrl(blob);
    }
    /**
   * Convert a Blob to a base64 encoded data URL.
   *
   * Converts a Blob object to a base64-encoded data URL using the FileReader API.
   * This is useful for displaying images or embedding file content directly in HTML.
   *
   * @param file - The Blob object to convert
   * @returns Promise that resolves to a base64-encoded data URL string
   * @example
   * ```ts
   * const blob = new Blob(['Hello World'], { type: 'text/plain' })
   * const dataUrl = await FileHelpers.blobToDataUrl(blob)
   * // Returns: 'data:text/plain;base64,SGVsbG8gV29ybGQ='
   *
   * // With an image file
   * const imageDataUrl = await FileHelpers.blobToDataUrl(myImageFile)
   * // Can be used directly in img src attribute
   * ```
   * @public
   */ static async blobToDataUrl(file) {
        return await new Promise((resolve, reject)=>{
            if (file) {
                const reader = new FileReader();
                reader.onload = ()=>resolve(reader.result);
                reader.onerror = (error)=>reject(error);
                reader.onabort = (error)=>reject(error);
                reader.readAsDataURL(file);
            }
        });
    }
    /**
   * Convert a Blob to a unicode text string.
   *
   * Reads the content of a Blob object as a UTF-8 text string using the FileReader API.
   * This is useful for reading text files or extracting text content from blobs.
   *
   * @param file - The Blob object to convert to text
   * @returns Promise that resolves to the text content as a string
   * @example
   * ```ts
   * const textBlob = new Blob(['Hello World'], { type: 'text/plain' })
   * const text = await FileHelpers.blobToText(textBlob)
   * console.log(text) // 'Hello World'
   *
   * // With a text file from user input
   * const content = await FileHelpers.blobToText(myTextFile)
   * console.log(content) // File content as string
   * ```
   * @public
   */ static async blobToText(file) {
        return await new Promise((resolve, reject)=>{
            if (file) {
                const reader = new FileReader();
                reader.onload = ()=>resolve(reader.result);
                reader.onerror = (error)=>reject(error);
                reader.onabort = (error)=>reject(error);
                reader.readAsText(file);
            }
        });
    }
    static rewriteMimeType(blob, newMimeType) {
        if (blob.type === newMimeType) return blob;
        if (blob instanceof File) {
            return new File([
                blob
            ], blob.name, {
                type: newMimeType
            });
        }
        return new Blob([
            blob
        ], {
            type: newMimeType
        });
    }
}
;
 //# sourceMappingURL=file.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/hash.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getHashForBuffer",
    ()=>getHashForBuffer,
    "getHashForObject",
    ()=>getHashForObject,
    "getHashForString",
    ()=>getHashForString,
    "lns",
    ()=>lns
]);
function getHashForString(string) {
    let hash = 0;
    for(let i = 0; i < string.length; i++){
        hash = (hash << 5) - hash + string.charCodeAt(i);
        hash |= 0;
    }
    return hash + "";
}
function getHashForObject(obj) {
    return getHashForString(JSON.stringify(obj));
}
function getHashForBuffer(buffer) {
    const view = new DataView(buffer);
    let hash = 0;
    for(let i = 0; i < view.byteLength; i++){
        hash = (hash << 5) - hash + view.getUint8(i);
        hash |= 0;
    }
    return hash + "";
}
function lns(str) {
    const result = str.split("");
    result.push(...result.splice(0, Math.round(result.length / 5)));
    result.push(...result.splice(0, Math.round(result.length / 4)));
    result.push(...result.splice(0, Math.round(result.length / 3)));
    result.push(...result.splice(0, Math.round(result.length / 2)));
    return result.reverse().map((n)=>+n ? +n < 5 ? 5 + +n : +n > 5 ? +n - 5 : n : n).join("");
}
;
 //# sourceMappingURL=hash.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mockUniqueId",
    ()=>mockUniqueId,
    "restoreUniqueId",
    ()=>restoreUniqueId,
    "uniqueId",
    ()=>uniqueId
]);
/*!
 * MIT License: https://github.com/ai/nanoid/blob/main/LICENSE
 * Modified code originally from <https://github.com/ai/nanoid>
 * Copyright 2017 Andrey Sitnik <andrey@sitnik.ru>
 *
 * `nanoid` is currently only distributed as an ES module. Some tools (jest, playwright) don't
 * properly support ESM-only code yet, and tldraw itself is distributed as both an ES module and a
 * CommonJS module. By including nanoid here, we can make sure it works well in every environment
 * where tldraw is used. We can also remove some unused features like custom alphabets.
 */ const crypto = globalThis.crypto;
const urlAlphabet = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
const POOL_SIZE_MULTIPLIER = 128;
let pool, poolOffset;
function fillPool(bytes) {
    if (!pool || pool.length < bytes) {
        pool = new Uint8Array(bytes * POOL_SIZE_MULTIPLIER);
        crypto.getRandomValues(pool);
        poolOffset = 0;
    } else if (poolOffset + bytes > pool.length) {
        crypto.getRandomValues(pool);
        poolOffset = 0;
    }
    poolOffset += bytes;
}
function nanoid(size = 21) {
    fillPool(size -= 0);
    let id = "";
    for(let i = poolOffset - size; i < poolOffset; i++){
        id += urlAlphabet[pool[i] & 63];
    }
    return id;
}
let impl = nanoid;
function mockUniqueId(fn) {
    impl = fn;
}
function restoreUniqueId() {
    impl = nanoid;
}
function uniqueId(size) {
    return impl(size);
}
;
 //# sourceMappingURL=id.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/iterable.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getFirstFromIterable",
    ()=>getFirstFromIterable
]);
function getFirstFromIterable(set) {
    return set.values().next().value;
}
;
 //# sourceMappingURL=iterable.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/apng.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isApngAnimated",
    ()=>isApngAnimated
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
/*!
 * MIT License: https://github.com/vHeemstra/is-apng/blob/main/license
 * Copyright (c) Philip van Heemstra
 */ function isApngAnimated(buffer) {
    const view = new Uint8Array(buffer);
    if (!view || !(typeof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"] !== "undefined" && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].isBuffer(view) || view instanceof Uint8Array) || view.length < 16) {
        return false;
    }
    const isPNG = view[0] === 137 && view[1] === 80 && view[2] === 78 && view[3] === 71 && view[4] === 13 && view[5] === 10 && view[6] === 26 && view[7] === 10;
    if (!isPNG) {
        return false;
    }
    function indexOfSubstring(haystack, needle, fromIndex, upToIndex, chunksize = 1024) {
        if (!needle) {
            return -1;
        }
        needle = new RegExp(needle, "g");
        const needle_length = needle.source.length;
        const decoder = new TextDecoder();
        const full_haystack_length = haystack.length;
        if (typeof upToIndex === "undefined") {
            upToIndex = full_haystack_length;
        }
        if (fromIndex >= full_haystack_length || upToIndex <= 0 || fromIndex >= upToIndex) {
            return -1;
        }
        haystack = haystack.subarray(fromIndex, upToIndex);
        let position = -1;
        let current_index = 0;
        let full_length = 0;
        let needle_buffer = "";
        outer: while(current_index < haystack.length){
            const next_index = current_index + chunksize;
            const chunk = haystack.subarray(current_index, next_index);
            const decoded = decoder.decode(chunk, {
                stream: true
            });
            const text = needle_buffer + decoded;
            let match;
            let last_index = -1;
            while((match = needle.exec(text)) !== null){
                last_index = match.index - needle_buffer.length;
                position = full_length + last_index;
                break outer;
            }
            current_index = next_index;
            full_length += decoded.length;
            const needle_index = last_index > -1 ? last_index + needle_length : decoded.length - needle_length;
            needle_buffer = decoded.slice(needle_index);
        }
        if (position >= 0) {
            position += fromIndex >= 0 ? fromIndex : full_haystack_length + fromIndex;
        }
        return position;
    }
    const idatIdx = indexOfSubstring(view, "IDAT", 12);
    if (idatIdx >= 12) {
        const actlIdx = indexOfSubstring(view, "acTL", 8, idatIdx);
        return actlIdx >= 8;
    }
    return false;
}
;
 //# sourceMappingURL=apng.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/avif.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isAvifAnimated",
    ()=>isAvifAnimated
]);
const isAvifAnimated = (buffer)=>{
    const view = new Uint8Array(buffer);
    return view[3] === 44;
};
;
 //# sourceMappingURL=avif.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/gif.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isGIF",
    ()=>isGIF,
    "isGifAnimated",
    ()=>isGifAnimated
]);
/*!
 * MIT License
 * Modified code originally from <https://github.com/qzb/is-animated>
 * Copyright (c) 2016 Józef Sokołowski <j.k.sokolowski@gmail.com>
 */ function getDataBlocksLength(buffer, offset) {
    let length = 0;
    while(buffer[offset + length]){
        length += buffer[offset + length] + 1;
    }
    return length + 1;
}
function isGIF(buffer) {
    const enc = new TextDecoder("ascii");
    const header = enc.decode(buffer.slice(0, 3));
    return header === "GIF";
}
function isGifAnimated(buffer) {
    const view = new Uint8Array(buffer);
    let hasColorTable, colorTableSize;
    let offset = 0;
    let imagesCount = 0;
    if (!isGIF(buffer)) {
        return false;
    }
    hasColorTable = view[10] & 128;
    colorTableSize = view[10] & 7;
    offset += 6;
    offset += 7;
    offset += hasColorTable ? 3 * Math.pow(2, colorTableSize + 1) : 0;
    while(imagesCount < 2 && offset < view.length){
        switch(view[offset]){
            // Image descriptor block. According to specification there could be any
            // number of these blocks (even zero). When there is more than one image
            // descriptor browsers will display animation (they shouldn't when there
            // is no delays defined, but they do it anyway).
            case 44:
                imagesCount += 1;
                hasColorTable = view[offset + 9] & 128;
                colorTableSize = view[offset + 9] & 7;
                offset += 10;
                offset += hasColorTable ? 3 * Math.pow(2, colorTableSize + 1) : 0;
                offset += getDataBlocksLength(view, offset + 1) + 1;
                break;
            // Skip all extension blocks. In theory this "plain text extension" blocks
            // could be frames of animation, but no browser renders them.
            case 33:
                offset += 2;
                offset += getDataBlocksLength(view, offset);
                break;
            // Stop processing on trailer block,
            // all data after this point will is ignored by decoders
            case 59:
                offset = view.length;
                break;
            // Oops! This GIF seems to be invalid
            default:
                offset = view.length;
                break;
        }
    }
    return imagesCount > 1;
}
;
 //# sourceMappingURL=gif.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/png.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PngHelpers",
    ()=>PngHelpers
]);
/*!
 * MIT License: https://github.com/alexgorbatchev/crc/blob/master/LICENSE
 * Copyright: 2014 Alex Gorbatchev
 * Code: crc32, https://github.com/alexgorbatchev/crc/blob/master/src/calculators/crc32.ts
 */ let TABLE = [
    0,
    1996959894,
    3993919788,
    2567524794,
    124634137,
    1886057615,
    3915621685,
    2657392035,
    249268274,
    2044508324,
    3772115230,
    2547177864,
    162941995,
    2125561021,
    3887607047,
    2428444049,
    498536548,
    1789927666,
    4089016648,
    2227061214,
    450548861,
    1843258603,
    4107580753,
    2211677639,
    325883990,
    1684777152,
    4251122042,
    2321926636,
    335633487,
    1661365465,
    4195302755,
    2366115317,
    997073096,
    1281953886,
    3579855332,
    2724688242,
    1006888145,
    1258607687,
    3524101629,
    2768942443,
    901097722,
    1119000684,
    3686517206,
    2898065728,
    853044451,
    1172266101,
    3705015759,
    2882616665,
    651767980,
    1373503546,
    3369554304,
    3218104598,
    565507253,
    1454621731,
    3485111705,
    3099436303,
    671266974,
    1594198024,
    3322730930,
    2970347812,
    795835527,
    1483230225,
    3244367275,
    3060149565,
    1994146192,
    31158534,
    2563907772,
    4023717930,
    1907459465,
    112637215,
    2680153253,
    3904427059,
    2013776290,
    251722036,
    2517215374,
    3775830040,
    2137656763,
    141376813,
    2439277719,
    3865271297,
    1802195444,
    476864866,
    2238001368,
    4066508878,
    1812370925,
    453092731,
    2181625025,
    4111451223,
    1706088902,
    314042704,
    2344532202,
    4240017532,
    1658658271,
    366619977,
    2362670323,
    4224994405,
    1303535960,
    984961486,
    2747007092,
    3569037538,
    1256170817,
    1037604311,
    2765210733,
    3554079995,
    1131014506,
    879679996,
    2909243462,
    3663771856,
    1141124467,
    855842277,
    2852801631,
    3708648649,
    1342533948,
    654459306,
    3188396048,
    3373015174,
    1466479909,
    544179635,
    3110523913,
    3462522015,
    1591671054,
    702138776,
    2966460450,
    3352799412,
    1504918807,
    783551873,
    3082640443,
    3233442989,
    3988292384,
    2596254646,
    62317068,
    1957810842,
    3939845945,
    2647816111,
    81470997,
    1943803523,
    3814918930,
    2489596804,
    225274430,
    2053790376,
    3826175755,
    2466906013,
    167816743,
    2097651377,
    4027552580,
    2265490386,
    503444072,
    1762050814,
    4150417245,
    2154129355,
    426522225,
    1852507879,
    4275313526,
    2312317920,
    282753626,
    1742555852,
    4189708143,
    2394877945,
    397917763,
    1622183637,
    3604390888,
    2714866558,
    953729732,
    1340076626,
    3518719985,
    2797360999,
    1068828381,
    1219638859,
    3624741850,
    2936675148,
    906185462,
    1090812512,
    3747672003,
    2825379669,
    829329135,
    1181335161,
    3412177804,
    3160834842,
    628085408,
    1382605366,
    3423369109,
    3138078467,
    570562233,
    1426400815,
    3317316542,
    2998733608,
    733239954,
    1555261956,
    3268935591,
    3050360625,
    752459403,
    1541320221,
    2607071920,
    3965973030,
    1969922972,
    40735498,
    2617837225,
    3943577151,
    1913087877,
    83908371,
    2512341634,
    3803740692,
    2075208622,
    213261112,
    2463272603,
    3855990285,
    2094854071,
    198958881,
    2262029012,
    4057260610,
    1759359992,
    534414190,
    2176718541,
    4139329115,
    1873836001,
    414664567,
    2282248934,
    4279200368,
    1711684554,
    285281116,
    2405801727,
    4167216745,
    1634467795,
    376229701,
    2685067896,
    3608007406,
    1308918612,
    956543938,
    2808555105,
    3495958263,
    1231636301,
    1047427035,
    2932959818,
    3654703836,
    1088359270,
    936918e3,
    2847714899,
    3736837829,
    1202900863,
    817233897,
    3183342108,
    3401237130,
    1404277552,
    615818150,
    3134207493,
    3453421203,
    1423857449,
    601450431,
    3009837614,
    3294710456,
    1567103746,
    711928724,
    3020668471,
    3272380065,
    1510334235,
    755167117
];
if (typeof Int32Array !== "undefined") {
    TABLE = new Int32Array(TABLE);
}
const crc = (current, previous)=>{
    let crc2 = previous === 0 ? 0 : ~~previous ^ -1;
    for(let index = 0; index < current.length; index++){
        crc2 = TABLE[(crc2 ^ current[index]) & 255] ^ crc2 >>> 8;
    }
    return crc2 ^ -1;
};
const LEN_SIZE = 4;
const CRC_SIZE = 4;
class PngHelpers {
    /**
   * Checks if binary data at the specified offset contains a valid PNG file signature.
   * Validates the 8-byte PNG signature: 89 50 4E 47 0D 0A 1A 0A.
   *
   * @param view - DataView containing the binary data to check
   * @param offset - Byte offset where the PNG signature should start
   * @returns True if the data contains a valid PNG signature, false otherwise
   *
   * @example
   * ```ts
   * // Validate PNG from file upload
   * const file = event.target.files[0]
   * const buffer = await file.arrayBuffer()
   * const view = new DataView(buffer)
   *
   * if (PngHelpers.isPng(view, 0)) {
   *   console.log('Valid PNG file detected')
   *   // Process PNG file...
   * } else {
   *   console.error('Not a valid PNG file')
   * }
   * ```
   */ static isPng(view, offset) {
        if (view.getUint8(offset + 0) === 137 && view.getUint8(offset + 1) === 80 && view.getUint8(offset + 2) === 78 && view.getUint8(offset + 3) === 71 && view.getUint8(offset + 4) === 13 && view.getUint8(offset + 5) === 10 && view.getUint8(offset + 6) === 26 && view.getUint8(offset + 7) === 10) {
            return true;
        }
        return false;
    }
    /**
   * Reads the 4-character chunk type identifier from a PNG chunk header.
   *
   * @param view - DataView containing the PNG data
   * @param offset - Byte offset of the chunk type field (after length field)
   * @returns 4-character string representing the chunk type (e.g., 'IHDR', 'IDAT', 'IEND')
   *
   * @example
   * ```ts
   * // Read chunk type from PNG header (after 8-byte signature)
   * const chunkType = PngHelpers.getChunkType(dataView, 8)
   * console.log(chunkType) // 'IHDR' (Image Header)
   *
   * // Read chunk type at a specific position during parsing
   * let offset = 8 // Skip PNG signature
   * const chunkLength = dataView.getUint32(offset)
   * const type = PngHelpers.getChunkType(dataView, offset + 4)
   * ```
   */ static getChunkType(view, offset) {
        return [
            String.fromCharCode(view.getUint8(offset)),
            String.fromCharCode(view.getUint8(offset + 1)),
            String.fromCharCode(view.getUint8(offset + 2)),
            String.fromCharCode(view.getUint8(offset + 3))
        ].join("");
    }
    /**
   * Parses all chunks in a PNG file and returns their metadata.
   * Skips duplicate IDAT chunks but includes all other chunk types.
   *
   * @param view - DataView containing the complete PNG file data
   * @param offset - Starting byte offset (defaults to 0)
   * @returns Record mapping chunk types to their metadata (start position, data offset, and size)
   * @throws Error if the data is not a valid PNG file
   *
   * @example
   * ```ts
   * // Parse PNG structure for metadata extraction
   * const view = new DataView(await blob.arrayBuffer())
   * const chunks = PngHelpers.readChunks(view)
   *
   * // Check for specific chunks
   * const ihdrChunk = chunks['IHDR']
   * const physChunk = chunks['pHYs']
   *
   * if (physChunk) {
   *   console.log(`Found pixel density info at byte ${physChunk.start}`)
   * } else {
   *   console.log('No pixel density information found')
   * }
   * ```
   */ static readChunks(view, offset = 0) {
        const chunks = {};
        if (!PngHelpers.isPng(view, offset)) {
            throw new Error("Not a PNG");
        }
        offset += 8;
        while(offset <= view.buffer.byteLength){
            const start = offset;
            const len = view.getInt32(offset);
            offset += 4;
            const chunkType = PngHelpers.getChunkType(view, offset);
            if (chunkType === "IDAT" && chunks[chunkType]) {
                offset += len + LEN_SIZE + CRC_SIZE;
                continue;
            }
            if (chunkType === "IEND") {
                break;
            }
            chunks[chunkType] = {
                start,
                dataOffset: offset + 4,
                size: len
            };
            offset += len + LEN_SIZE + CRC_SIZE;
        }
        return chunks;
    }
    /**
   * Parses the pHYs (physical pixel dimensions) chunk data.
   * Reads pixels per unit for X and Y axes, and the unit specifier.
   *
   * @param view - DataView containing the PNG data
   * @param offset - Byte offset of the pHYs chunk data
   * @returns Object with ppux (pixels per unit X), ppuy (pixels per unit Y), and unit specifier
   *
   * @example
   * ```ts
   * // Extract pixel density information for DPI calculation
   * const physChunk = PngHelpers.findChunk(dataView, 'pHYs')
   * if (physChunk) {
   *   const physData = PngHelpers.parsePhys(dataView, physChunk.dataOffset)
   *
   *   if (physData.unit === 1) { // meters
   *     const dpiX = Math.round(physData.ppux * 0.0254)
   *     const dpiY = Math.round(physData.ppuy * 0.0254)
   *     console.log(`DPI: ${dpiX} x ${dpiY}`)
   *   }
   * }
   * ```
   */ static parsePhys(view, offset) {
        return {
            ppux: view.getUint32(offset),
            ppuy: view.getUint32(offset + 4),
            unit: view.getUint8(offset + 8)
        };
    }
    /**
   * Finds a specific chunk type in the PNG file and returns its metadata.
   *
   * @param view - DataView containing the PNG file data
   * @param type - 4-character chunk type to search for (e.g., 'pHYs', 'IDAT')
   * @returns Chunk metadata object if found, undefined otherwise
   *
   * @example
   * ```ts
   * // Look for pixel density information in PNG
   * const physChunk = PngHelpers.findChunk(dataView, 'pHYs')
   * if (physChunk) {
   *   const physData = PngHelpers.parsePhys(dataView, physChunk.dataOffset)
   *   console.log(`Found pHYs chunk with ${physData.ppux} x ${physData.ppuy} pixels per unit`)
   * }
   *
   * // Check for text metadata
   * const textChunk = PngHelpers.findChunk(dataView, 'tEXt')
   * if (textChunk) {
   *   console.log(`Found text metadata at byte ${textChunk.start}`)
   * }
   * ```
   */ static findChunk(view, type) {
        const chunks = PngHelpers.readChunks(view);
        return chunks[type];
    }
    /**
   * Adds or replaces a pHYs chunk in a PNG file to set pixel density for high-DPI displays.
   * The method determines insertion point by prioritizing IDAT chunk position over existing pHYs,
   * creates a properly formatted pHYs chunk with CRC validation, and returns a new Blob.
   *
   * @param view - DataView containing the original PNG file data
   * @param dpr - Device pixel ratio multiplier (defaults to 1)
   * @param options - Optional Blob constructor options for MIME type and other properties
   * @returns New Blob containing the PNG with updated pixel density information
   *
   * @example
   * ```ts
   * // Export PNG with proper pixel density for high-DPI displays
   * const canvas = document.createElement('canvas')
   * const ctx = canvas.getContext('2d')
   * // ... draw content to canvas ...
   *
   * canvas.toBlob(async (blob) => {
   *   if (blob) {
   *     const view = new DataView(await blob.arrayBuffer())
   *     // Create 2x DPI version for Retina displays
   *     const highDpiBlob = PngHelpers.setPhysChunk(view, 2, { type: 'image/png' })
   *     // Download or use the blob...
   *   }
   * }, 'image/png')
   * ```
   */ static setPhysChunk(view, dpr = 1, options) {
        let offset = 46;
        let size = 0;
        const res1 = PngHelpers.findChunk(view, "pHYs");
        if (res1) {
            offset = res1.start;
            size = res1.size;
        }
        const res2 = PngHelpers.findChunk(view, "IDAT");
        if (res2) {
            offset = res2.start;
            size = 0;
        }
        const pHYsData = new ArrayBuffer(21);
        const pHYsDataView = new DataView(pHYsData);
        pHYsDataView.setUint32(0, 9);
        pHYsDataView.setUint8(4, "p".charCodeAt(0));
        pHYsDataView.setUint8(5, "H".charCodeAt(0));
        pHYsDataView.setUint8(6, "Y".charCodeAt(0));
        pHYsDataView.setUint8(7, "s".charCodeAt(0));
        const DPI_72 = 2835.5;
        pHYsDataView.setInt32(8, DPI_72 * dpr);
        pHYsDataView.setInt32(12, DPI_72 * dpr);
        pHYsDataView.setInt8(16, 1);
        const crcBit = new Uint8Array(pHYsData.slice(4, 17));
        pHYsDataView.setInt32(17, crc(crcBit));
        const startBuf = view.buffer.slice(0, offset);
        const endBuf = view.buffer.slice(offset + size);
        return new Blob([
            startBuf,
            pHYsData,
            endBuf
        ], options);
    }
}
;
 //# sourceMappingURL=png.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/webp.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isWebp",
    ()=>isWebp,
    "isWebpAnimated",
    ()=>isWebpAnimated
]);
/*!
 * MIT License: https://github.com/sindresorhus/is-webp/blob/main/license
 * Copyright (c) Sindre Sorhus <sindresorhus@gmail.com> (https://sindresorhus.com)
 */ function isWebp(view) {
    if (!view || view.length < 12) {
        return false;
    }
    return view[8] === 87 && view[9] === 69 && view[10] === 66 && view[11] === 80;
}
function isWebpAnimated(buffer) {
    const view = new Uint8Array(buffer);
    if (!isWebp(view)) {
        return false;
    }
    if (!view || view.length < 21) {
        return false;
    }
    return (view[20] >> 1 & 1) === 1;
}
;
 //# sourceMappingURL=webp.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/media.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_SUPPORTED_ANIMATED_IMAGE_TYPES",
    ()=>DEFAULT_SUPPORTED_ANIMATED_IMAGE_TYPES,
    "DEFAULT_SUPPORTED_IMAGE_TYPES",
    ()=>DEFAULT_SUPPORTED_IMAGE_TYPES,
    "DEFAULT_SUPPORTED_MEDIA_TYPES",
    ()=>DEFAULT_SUPPORTED_MEDIA_TYPES,
    "DEFAULT_SUPPORTED_MEDIA_TYPE_LIST",
    ()=>DEFAULT_SUPPORTED_MEDIA_TYPE_LIST,
    "DEFAULT_SUPPORTED_STATIC_IMAGE_TYPES",
    ()=>DEFAULT_SUPPORTED_STATIC_IMAGE_TYPES,
    "DEFAULT_SUPPORTED_VECTOR_IMAGE_TYPES",
    ()=>DEFAULT_SUPPORTED_VECTOR_IMAGE_TYPES,
    "DEFAULT_SUPPORT_VIDEO_TYPES",
    ()=>DEFAULT_SUPPORT_VIDEO_TYPES,
    "MediaHelpers",
    ()=>MediaHelpers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$apng$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/apng.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$avif$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/avif.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$gif$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/gif.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/png.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$webp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/webp.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const DEFAULT_SUPPORTED_VECTOR_IMAGE_TYPES = Object.freeze([
    "image/svg+xml"
]);
const DEFAULT_SUPPORTED_STATIC_IMAGE_TYPES = Object.freeze([
    "image/jpeg",
    "image/png",
    "image/webp"
]);
const DEFAULT_SUPPORTED_ANIMATED_IMAGE_TYPES = Object.freeze([
    "image/gif",
    "image/apng",
    "image/avif"
]);
const DEFAULT_SUPPORTED_IMAGE_TYPES = Object.freeze([
    ...DEFAULT_SUPPORTED_STATIC_IMAGE_TYPES,
    ...DEFAULT_SUPPORTED_VECTOR_IMAGE_TYPES,
    ...DEFAULT_SUPPORTED_ANIMATED_IMAGE_TYPES
]);
const DEFAULT_SUPPORT_VIDEO_TYPES = Object.freeze([
    "video/mp4",
    "video/webm",
    "video/quicktime"
]);
const DEFAULT_SUPPORTED_MEDIA_TYPES = Object.freeze([
    ...DEFAULT_SUPPORTED_IMAGE_TYPES,
    ...DEFAULT_SUPPORT_VIDEO_TYPES
]);
const DEFAULT_SUPPORTED_MEDIA_TYPE_LIST = DEFAULT_SUPPORTED_MEDIA_TYPES.join(",");
class MediaHelpers {
    /**
   * Load a video element from a URL with cross-origin support.
   *
   * @param src - The URL of the video to load
   * @returns Promise that resolves to the loaded HTMLVideoElement
   * @example
   * ```ts
   * const video = await MediaHelpers.loadVideo('https://example.com/video.mp4')
   * console.log(`Video dimensions: ${video.videoWidth}x${video.videoHeight}`)
   * ```
   * @public
   */ static loadVideo(src) {
        return new Promise((resolve, reject)=>{
            const video = document.createElement("video");
            video.onloadeddata = ()=>resolve(video);
            video.onerror = (e)=>{
                console.error(e);
                reject(new Error("Could not load video"));
            };
            video.crossOrigin = "anonymous";
            video.src = src;
        });
    }
    /**
   * Extract a frame from a video element as a data URL.
   *
   * @param video - The HTMLVideoElement to extract frame from
   * @param time - The time in seconds to extract the frame from (default: 0)
   * @returns Promise that resolves to a data URL of the video frame
   * @example
   * ```ts
   * const video = await MediaHelpers.loadVideo('https://example.com/video.mp4')
   * const frameDataUrl = await MediaHelpers.getVideoFrameAsDataUrl(video, 5.0)
   * // Use frameDataUrl as image thumbnail
   * const img = document.createElement('img')
   * img.src = frameDataUrl
   * ```
   * @public
   */ static async getVideoFrameAsDataUrl(video, time = 0) {
        const promise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["promiseWithResolve"])();
        let didSetTime = false;
        const onReadyStateChanged = ()=>{
            if (!didSetTime) {
                if (video.readyState >= video.HAVE_METADATA) {
                    didSetTime = true;
                    video.currentTime = time;
                } else {
                    return;
                }
            }
            if (video.readyState >= video.HAVE_CURRENT_DATA) {
                const canvas = document.createElement("canvas");
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    throw new Error("Could not get 2d context");
                }
                ctx.drawImage(video, 0, 0);
                promise.resolve(canvas.toDataURL());
            }
        };
        const onError = (e)=>{
            console.error(e);
            promise.reject(new Error("Could not get video frame"));
        };
        video.addEventListener("loadedmetadata", onReadyStateChanged);
        video.addEventListener("loadeddata", onReadyStateChanged);
        video.addEventListener("canplay", onReadyStateChanged);
        video.addEventListener("seeked", onReadyStateChanged);
        video.addEventListener("error", onError);
        video.addEventListener("stalled", onError);
        onReadyStateChanged();
        try {
            return await promise;
        } finally{
            video.removeEventListener("loadedmetadata", onReadyStateChanged);
            video.removeEventListener("loadeddata", onReadyStateChanged);
            video.removeEventListener("canplay", onReadyStateChanged);
            video.removeEventListener("seeked", onReadyStateChanged);
            video.removeEventListener("error", onError);
            video.removeEventListener("stalled", onError);
        }
    }
    /**
   * Load an image from a URL and get its dimensions along with the image element.
   *
   * @param src - The URL of the image to load
   * @returns Promise that resolves to an object with width, height, and the image element
   * @example
   * ```ts
   * const { w, h, image } = await MediaHelpers.getImageAndDimensions('https://example.com/image.png')
   * console.log(`Image size: ${w}x${h}`)
   * // Image is ready to use
   * document.body.appendChild(image)
   * ```
   * @public
   */ static getImageAndDimensions(src) {
        return new Promise((resolve, reject)=>{
            const img = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"])();
            img.onload = ()=>{
                let dimensions;
                if (img.naturalWidth) {
                    dimensions = {
                        w: img.naturalWidth,
                        h: img.naturalHeight
                    };
                } else {
                    document.body.appendChild(img);
                    dimensions = {
                        w: img.clientWidth,
                        h: img.clientHeight
                    };
                    document.body.removeChild(img);
                }
                resolve({
                    ...dimensions,
                    image: img
                });
            };
            img.onerror = (e)=>{
                console.error(e);
                reject(new Error("Could not load image"));
            };
            img.crossOrigin = "anonymous";
            img.referrerPolicy = "strict-origin-when-cross-origin";
            img.style.visibility = "hidden";
            img.style.position = "absolute";
            img.style.opacity = "0";
            img.style.zIndex = "-9999";
            img.src = src;
        });
    }
    /**
   * Get the size of a video blob
   *
   * @param blob - A Blob containing the video
   * @returns Promise that resolves to an object with width and height properties
   * @example
   * ```ts
   * const file = new File([...], 'video.mp4', { type: 'video/mp4' })
   * const { w, h } = await MediaHelpers.getVideoSize(file)
   * console.log(`Video dimensions: ${w}x${h}`)
   * ```
   * @public
   */ static async getVideoSize(blob) {
        return MediaHelpers.usingObjectURL(blob, async (url)=>{
            const video = await MediaHelpers.loadVideo(url);
            return {
                w: video.videoWidth,
                h: video.videoHeight
            };
        });
    }
    /**
   * Get the size of an image blob
   *
   * @param blob - A Blob containing the image
   * @returns Promise that resolves to an object with width and height properties
   * @example
   * ```ts
   * const file = new File([...], 'image.png', { type: 'image/png' })
   * const { w, h } = await MediaHelpers.getImageSize(file)
   * console.log(`Image dimensions: ${w}x${h}`)
   * ```
   * @public
   */ static async getImageSize(blob) {
        const { w, h } = await MediaHelpers.usingObjectURL(blob, MediaHelpers.getImageAndDimensions);
        try {
            if (blob.type === "image/png") {
                const view = new DataView(await blob.arrayBuffer());
                if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PngHelpers"].isPng(view, 0)) {
                    const physChunk = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PngHelpers"].findChunk(view, "pHYs");
                    if (physChunk) {
                        const physData = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PngHelpers"].parsePhys(view, physChunk.dataOffset);
                        if (physData.unit === 1 && physData.ppux === physData.ppuy) {
                            const pixelsPerMeter = 72 / 0.0254;
                            const pixelRatio = Math.max(physData.ppux / pixelsPerMeter, 1);
                            return {
                                w: Math.round(w / pixelRatio),
                                h: Math.round(h / pixelRatio)
                            };
                        }
                    }
                }
            }
        } catch (err) {
            console.error(err);
            return {
                w,
                h
            };
        }
        return {
            w,
            h
        };
    }
    /**
   * Check if a media file blob contains animation data.
   *
   * @param file - The Blob to check for animation
   * @returns Promise that resolves to true if the file is animated, false otherwise
   * @example
   * ```ts
   * const file = new File([...], 'animation.gif', { type: 'image/gif' })
   * const animated = await MediaHelpers.isAnimated(file)
   * console.log(animated ? 'Animated' : 'Static')
   * ```
   * @public
   */ static async isAnimated(file) {
        if (file.type === "image/gif") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$gif$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isGifAnimated"])(await file.arrayBuffer());
        }
        if (file.type === "image/avif") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$avif$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAvifAnimated"])(await file.arrayBuffer());
        }
        if (file.type === "image/webp") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$webp$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebpAnimated"])(await file.arrayBuffer());
        }
        if (file.type === "image/apng") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$apng$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isApngAnimated"])(await file.arrayBuffer());
        }
        return false;
    }
    /**
   * Check if a MIME type represents an animated image format.
   *
   * @param mimeType - The MIME type to check
   * @returns True if the MIME type is an animated image format, false otherwise
   * @example
   * ```ts
   * const isAnimated = MediaHelpers.isAnimatedImageType('image/gif')
   * console.log(isAnimated) // true
   * ```
   * @public
   */ static isAnimatedImageType(mimeType) {
        return DEFAULT_SUPPORTED_ANIMATED_IMAGE_TYPES.includes(mimeType || "");
    }
    /**
   * Check if a MIME type represents a static (non-animated) image format.
   *
   * @param mimeType - The MIME type to check
   * @returns True if the MIME type is a static image format, false otherwise
   * @example
   * ```ts
   * const isStatic = MediaHelpers.isStaticImageType('image/jpeg')
   * console.log(isStatic) // true
   * ```
   * @public
   */ static isStaticImageType(mimeType) {
        return DEFAULT_SUPPORTED_STATIC_IMAGE_TYPES.includes(mimeType || "");
    }
    /**
   * Check if a MIME type represents a vector image format.
   *
   * @param mimeType - The MIME type to check
   * @returns True if the MIME type is a vector image format, false otherwise
   * @example
   * ```ts
   * const isVector = MediaHelpers.isVectorImageType('image/svg+xml')
   * console.log(isVector) // true
   * ```
   * @public
   */ static isVectorImageType(mimeType) {
        return DEFAULT_SUPPORTED_VECTOR_IMAGE_TYPES.includes(mimeType || "");
    }
    /**
   * Check if a MIME type represents any supported image format (static, animated, or vector).
   *
   * @param mimeType - The MIME type to check
   * @returns True if the MIME type is a supported image format, false otherwise
   * @example
   * ```ts
   * const isImage = MediaHelpers.isImageType('image/png')
   * console.log(isImage) // true
   * ```
   * @public
   */ static isImageType(mimeType) {
        return DEFAULT_SUPPORTED_IMAGE_TYPES.includes(mimeType || "");
    }
    /**
   * Utility function to create an object URL from a blob, execute a function with it, and automatically clean it up.
   *
   * @param blob - The Blob to create an object URL for
   * @param fn - Function to execute with the object URL
   * @returns Promise that resolves to the result of the function
   * @example
   * ```ts
   * const result = await MediaHelpers.usingObjectURL(imageBlob, async (url) => {
   *   const { w, h } = await MediaHelpers.getImageAndDimensions(url)
   *   return { width: w, height: h }
   * })
   * // Object URL is automatically revoked after function completes
   * console.log(`Image dimensions: ${result.width}x${result.height}`)
   * ```
   * @public
   */ static async usingObjectURL(blob, fn) {
        const url = URL.createObjectURL(blob);
        try {
            return await fn(url);
        } finally{
            URL.revokeObjectURL(url);
        }
    }
}
;
 //# sourceMappingURL=media.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "invLerp",
    ()=>invLerp,
    "lerp",
    ()=>lerp,
    "modulate",
    ()=>modulate,
    "rng",
    ()=>rng
]);
function lerp(a, b, t) {
    return a + (b - a) * t;
}
function invLerp(a, b, t) {
    return (t - a) / (b - a);
}
function rng(seed = "") {
    let x = 0;
    let y = 0;
    let z = 0;
    let w = 0;
    function next() {
        const t = x ^ x << 11;
        x = y;
        y = z;
        z = w;
        w ^= (w >>> 19 ^ t ^ t >>> 8) >>> 0;
        return w / 4294967296 * 2;
    }
    for(let k = 0; k < seed.length + 64; k++){
        x ^= seed.charCodeAt(k) | 0;
        next();
    }
    return next;
}
function modulate(value, rangeA, rangeB, clamp = false) {
    const [fromLow, fromHigh] = rangeA;
    const [v0, v1] = rangeB;
    const result = v0 + (value - fromLow) / (fromHigh - fromLow) * (v1 - v0);
    return clamp ? v0 < v1 ? Math.max(Math.min(result, v1), v0) : Math.max(Math.min(result, v0), v1) : result;
}
;
 //# sourceMappingURL=number.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areObjectsShallowEqual",
    ()=>areObjectsShallowEqual,
    "filterEntries",
    ()=>filterEntries,
    "getChangedKeys",
    ()=>getChangedKeys,
    "getOwnProperty",
    ()=>getOwnProperty,
    "groupBy",
    ()=>groupBy,
    "hasOwnProperty",
    ()=>hasOwnProperty,
    "isEqualAllowingForFloatingPointErrors",
    ()=>isEqualAllowingForFloatingPointErrors,
    "mapObjectMapValues",
    ()=>mapObjectMapValues,
    "objectMapEntries",
    ()=>objectMapEntries,
    "objectMapEntriesIterable",
    ()=>objectMapEntriesIterable,
    "objectMapFromEntries",
    ()=>objectMapFromEntries,
    "objectMapKeys",
    ()=>objectMapKeys,
    "objectMapValues",
    ()=>objectMapValues,
    "omit",
    ()=>omit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequalwith$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequalwith/index.js [app-client] (ecmascript)");
;
function hasOwnProperty(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
}
function getOwnProperty(obj, key) {
    if (!hasOwnProperty(obj, key)) {
        return void 0;
    }
    return obj[key];
}
function objectMapKeys(object) {
    return Object.keys(object);
}
function objectMapValues(object) {
    return Object.values(object);
}
function objectMapEntries(object) {
    return Object.entries(object);
}
function* objectMapEntriesIterable(object) {
    for(const key in object){
        if (!Object.prototype.hasOwnProperty.call(object, key)) continue;
        yield [
            key,
            object[key]
        ];
    }
}
function objectMapFromEntries(entries) {
    return Object.fromEntries(entries);
}
function filterEntries(object, predicate) {
    const result = {};
    let didChange = false;
    for(const key in object){
        if (!Object.prototype.hasOwnProperty.call(object, key)) continue;
        const value = object[key];
        if (predicate(key, value)) {
            result[key] = value;
        } else {
            didChange = true;
        }
    }
    return didChange ? result : object;
}
function mapObjectMapValues(object, mapper) {
    const result = {};
    for(const key in object){
        if (!Object.prototype.hasOwnProperty.call(object, key)) continue;
        result[key] = mapper(key, object[key]);
    }
    return result;
}
function areObjectsShallowEqual(obj1, obj2) {
    if (obj1 === obj2) return true;
    const keys1 = Object.keys(obj1);
    if (keys1.length !== Object.keys(obj2).length) return false;
    for (const key of keys1){
        if (!hasOwnProperty(obj2, key)) return false;
        if (!Object.is(obj1[key], obj2[key])) return false;
    }
    return true;
}
function groupBy(array, keySelector) {
    const result = {};
    for (const value of array){
        const key = keySelector(value);
        if (!result[key]) result[key] = [];
        result[key].push(value);
    }
    return result;
}
function omit(obj, keys) {
    const result = {
        ...obj
    };
    for (const key of keys){
        delete result[key];
    }
    return result;
}
function getChangedKeys(obj1, obj2) {
    const result = [];
    for(const key in obj1){
        if (!Object.is(obj1[key], obj2[key])) {
            result.push(key);
        }
    }
    return result;
}
function isEqualAllowingForFloatingPointErrors(obj1, obj2, threshold = 1e-6) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequalwith$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(obj1, obj2, (value1, value2)=>{
        if (typeof value1 === "number" && typeof value2 === "number") {
            return Math.abs(value1 - value2) < threshold;
        }
        return void 0;
    });
}
;
 //# sourceMappingURL=object.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/perf.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PERFORMANCE_COLORS",
    ()=>PERFORMANCE_COLORS,
    "PERFORMANCE_PREFIX_COLOR",
    ()=>PERFORMANCE_PREFIX_COLOR,
    "measureAverageDuration",
    ()=>measureAverageDuration,
    "measureCbDuration",
    ()=>measureCbDuration,
    "measureDuration",
    ()=>measureDuration
]);
const PERFORMANCE_COLORS = {
    Good: "#40C057",
    Mid: "#FFC078",
    Poor: "#E03131"
};
const PERFORMANCE_PREFIX_COLOR = PERFORMANCE_COLORS.Good;
function measureCbDuration(name, cb) {
    const start = performance.now();
    const result = cb();
    console.debug(`%cPerf%c ${name} took ${performance.now() - start}ms`, `color: white; background: ${PERFORMANCE_PREFIX_COLOR};padding: 2px;border-radius: 3px;`, "font-weight: normal");
    return result;
}
function measureDuration(_target, propertyKey, descriptor) {
    const originalMethod = descriptor.value;
    descriptor.value = function(...args) {
        const start = performance.now();
        const result = originalMethod.apply(this, args);
        console.debug(`%cPerf%c ${propertyKey} took: ${performance.now() - start}ms`, `color: white; background: ${PERFORMANCE_PREFIX_COLOR};padding: 2px;border-radius: 3px;`, "font-weight: normal");
        return result;
    };
    return descriptor;
}
const averages = /* @__PURE__ */ new Map();
function measureAverageDuration(_target, propertyKey, descriptor) {
    const originalMethod = descriptor.value;
    descriptor.value = function(...args) {
        const start = performance.now();
        const result = originalMethod.apply(this, args);
        const end = performance.now();
        const length = end - start;
        if (length !== 0) {
            const value = averages.get(descriptor.value);
            const total = value.total + length;
            const count = value.count + 1;
            averages.set(descriptor.value, {
                total,
                count
            });
            console.debug(`%cPerf%c ${propertyKey} took ${(end - start).toFixed(2)}ms | average ${(total / count).toFixed(2)}ms`, `color: white; background: ${PERFORMANCE_PREFIX_COLOR};padding: 2px;border-radius: 3px;`, "font-weight: normal");
        }
        return result;
    };
    averages.set(descriptor.value, {
        total: 0,
        count: 0
    });
    return descriptor;
}
;
 //# sourceMappingURL=perf.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/PerformanceTracker.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PerformanceTracker",
    ()=>PerformanceTracker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/perf.mjs [app-client] (ecmascript)");
;
class PerformanceTracker {
    startTime = 0;
    name = "";
    frames = 0;
    started = false;
    frame = null;
    /**
   * Records animation frames to calculate frame rate.
   * Called automatically during performance tracking.
   */ // eslint-disable-next-line local/prefer-class-methods
    recordFrame = ()=>{
        this.frames++;
        if (!this.started) return;
        this.frame = requestAnimationFrame(this.recordFrame);
    };
    /**
   * Starts performance tracking for a named operation.
   *
   * @param name - A descriptive name for the operation being tracked
   *
   * @example
   * ```ts
   * tracker.start('canvas-render')
   * // ... perform rendering operations
   * tracker.stop()
   * ```
   */ start(name) {
        this.name = name;
        this.frames = 0;
        this.started = true;
        if (this.frame !== null) cancelAnimationFrame(this.frame);
        this.frame = requestAnimationFrame(this.recordFrame);
        this.startTime = performance.now();
    }
    /**
   * Stops performance tracking and logs results to the console.
   *
   * Displays the operation name, frame rate, and uses color coding:
   * - Green background: \> 55 FPS (good performance)
   * - Yellow background: 30-55 FPS (moderate performance)
   * - Red background: \< 30 FPS (poor performance)
   *
   * @example
   * ```ts
   * tracker.start('interaction')
   * handleUserInteraction()
   * tracker.stop() // Logs: "Perf Interaction 60 fps"
   * ```
   */ stop() {
        this.started = false;
        if (this.frame !== null) cancelAnimationFrame(this.frame);
        const duration = (performance.now() - this.startTime) / 1e3;
        const fps = duration === 0 ? 0 : Math.floor(this.frames / duration);
        const background = fps > 55 ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_COLORS"].Good : fps > 30 ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_COLORS"].Mid : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_COLORS"].Poor;
        const color = background === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_COLORS"].Mid ? "black" : "white";
        const capitalized = this.name[0].toUpperCase() + this.name.slice(1);
        console.debug(`%cPerf%c ${capitalized} %c${fps}%c fps`, `color: white; background: ${__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_PREFIX_COLOR"]};padding: 2px;border-radius: 3px;`, "font-weight: normal", `font-weight: bold; padding: 2px; background: ${background};color: ${color};`, "font-weight: normal");
    }
    /**
   * Checks whether performance tracking is currently active.
   *
   * @returns True if tracking is in progress, false otherwise
   *
   * @example
   * ```ts
   * if (!tracker.isStarted()) {
   *   tracker.start('new-operation')
   * }
   * ```
   */ isStarted() {
        return this.started;
    }
}
;
 //# sourceMappingURL=PerformanceTracker.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZERO_INDEX_KEY",
    ()=>ZERO_INDEX_KEY,
    "getIndexAbove",
    ()=>getIndexAbove,
    "getIndexBelow",
    ()=>getIndexBelow,
    "getIndexBetween",
    ()=>getIndexBetween,
    "getIndices",
    ()=>getIndices,
    "getIndicesAbove",
    ()=>getIndicesAbove,
    "getIndicesBelow",
    ()=>getIndicesBelow,
    "getIndicesBetween",
    ()=>getIndicesBetween,
    "sortByIndex",
    ()=>sortByIndex,
    "sortByMaybeIndex",
    ()=>sortByMaybeIndex,
    "validateIndexKey",
    ()=>validateIndexKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$jittered$2d$fractional$2d$indexing$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/jittered-fractional-indexing/dist/index.js [app-client] (ecmascript)");
;
const generateNKeysBetweenWithNoJitter = (a, b, n)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$jittered$2d$fractional$2d$indexing$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateNKeysBetween"])(a, b, n, {
        jitterBits: 0
    });
};
const generateKeysFn = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$jittered$2d$fractional$2d$indexing$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateNKeysBetween"];
const ZERO_INDEX_KEY = "a0";
function validateIndexKey(index) {
    try {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$jittered$2d$fractional$2d$indexing$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateKeyBetween"])(index, null);
    } catch  {
        throw new Error("invalid index: " + index);
    }
}
function getIndicesBetween(below, above, n) {
    return generateKeysFn(below ?? null, above ?? null, n);
}
function getIndicesAbove(below, n) {
    return generateKeysFn(below ?? null, null, n);
}
function getIndicesBelow(above, n) {
    return generateKeysFn(null, above ?? null, n);
}
function getIndexBetween(below, above) {
    return generateKeysFn(below ?? null, above ?? null, 1)[0];
}
function getIndexAbove(below = null) {
    return generateKeysFn(below, null, 1)[0];
}
function getIndexBelow(above = null) {
    return generateKeysFn(null, above, 1)[0];
}
function getIndices(n, start = "a1") {
    return [
        start,
        ...generateKeysFn(start, null, n)
    ];
}
function sortByIndex(a, b) {
    if (a.index < b.index) {
        return -1;
    } else if (a.index > b.index) {
        return 1;
    }
    return 0;
}
function sortByMaybeIndex(a, b) {
    if (a.index && b.index) {
        return a.index < b.index ? -1 : 1;
    }
    if (a.index && b.index == null) {
        return -1;
    }
    if (a.index == null && b.index == null) {
        return 0;
    }
    return 1;
}
;
 //# sourceMappingURL=reordering.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/retry.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "retry",
    ()=>retry
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
;
async function retry(fn, { attempts = 3, waitDuration = 1e3, abortSignal, matchError } = {}) {
    let error = null;
    for(let i = 0; i < attempts; i++){
        if (abortSignal?.aborted) throw new Error("aborted");
        try {
            return await fn({
                attempt: i,
                remaining: attempts - i,
                total: attempts
            });
        } catch (e) {
            if (matchError && !matchError(e)) throw e;
            error = e;
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(waitDuration);
        }
    }
    throw error;
}
;
 //# sourceMappingURL=retry.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/sort.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sortById",
    ()=>sortById
]);
function sortById(a, b) {
    return a.id > b.id ? 1 : -1;
}
;
 //# sourceMappingURL=sort.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/storage.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearLocalStorage",
    ()=>clearLocalStorage,
    "clearSessionStorage",
    ()=>clearSessionStorage,
    "deleteFromLocalStorage",
    ()=>deleteFromLocalStorage,
    "deleteFromSessionStorage",
    ()=>deleteFromSessionStorage,
    "getFromLocalStorage",
    ()=>getFromLocalStorage,
    "getFromSessionStorage",
    ()=>getFromSessionStorage,
    "setInLocalStorage",
    ()=>setInLocalStorage,
    "setInSessionStorage",
    ()=>setInSessionStorage
]);
function getFromLocalStorage(key) {
    try {
        return localStorage.getItem(key);
    } catch  {
        return null;
    }
}
function setInLocalStorage(key, value) {
    try {
        localStorage.setItem(key, value);
    } catch  {}
}
function deleteFromLocalStorage(key) {
    try {
        localStorage.removeItem(key);
    } catch  {}
}
function clearLocalStorage() {
    try {
        localStorage.clear();
    } catch  {}
}
function getFromSessionStorage(key) {
    try {
        return sessionStorage.getItem(key);
    } catch  {
        return null;
    }
}
function setInSessionStorage(key, value) {
    try {
        sessionStorage.setItem(key, value);
    } catch  {}
}
function deleteFromSessionStorage(key) {
    try {
        sessionStorage.removeItem(key);
    } catch  {}
}
function clearSessionStorage() {
    try {
        sessionStorage.clear();
    } catch  {}
}
;
 //# sourceMappingURL=storage.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/stringEnum.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringEnum",
    ()=>stringEnum
]);
function stringEnum(...values) {
    const obj = {};
    for (const value of values){
        obj[value] = value;
    }
    return obj;
}
;
 //# sourceMappingURL=stringEnum.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/throttle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FpsScheduler",
    ()=>FpsScheduler,
    "fpsThrottle",
    ()=>fpsThrottle,
    "throttleToNextFrame",
    ()=>throttleToNextFrame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const isTest = ()=>typeof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && ("TURBOPACK compile-time value", "development") === "test" && // @ts-expect-error
    !globalThis.__FORCE_RAF_IN_TESTS__;
const timingVarianceFactor = 0.9;
const getTargetTimePerFrame = (targetFps)=>Math.floor(1e3 / targetFps) * timingVarianceFactor;
class FpsScheduler {
    targetFps;
    targetTimePerFrame;
    fpsQueue = [];
    frameRaf;
    flushRaf;
    lastFlushTime;
    constructor(targetFps = 120){
        this.targetFps = targetFps;
        this.targetTimePerFrame = getTargetTimePerFrame(targetFps);
        this.lastFlushTime = -this.targetTimePerFrame;
    }
    updateTargetFps(targetFps) {
        if (targetFps === this.targetFps) return;
        this.targetFps = targetFps;
        this.targetTimePerFrame = getTargetTimePerFrame(targetFps);
        this.lastFlushTime = -this.targetTimePerFrame;
    }
    flush() {
        const queue = this.fpsQueue.splice(0, this.fpsQueue.length);
        for (const fn of queue){
            fn();
        }
    }
    tick(isOnNextFrame = false) {
        if (this.frameRaf) return;
        const now = Date.now();
        const elapsed = now - this.lastFlushTime;
        if (elapsed < this.targetTimePerFrame) {
            this.frameRaf = requestAnimationFrame(()=>{
                this.frameRaf = void 0;
                this.tick(true);
            });
            return;
        }
        if (isOnNextFrame) {
            if (this.flushRaf) return;
            this.lastFlushTime = now;
            this.flush();
        } else {
            if (this.flushRaf) return;
            this.flushRaf = requestAnimationFrame(()=>{
                this.flushRaf = void 0;
                this.lastFlushTime = Date.now();
                this.flush();
            });
        }
    }
    /**
   * Creates a throttled version of a function that executes at most once per frame.
   * The default target frame rate is set by the FpsScheduler instance.
   * Subsequent calls within the same frame are ignored, ensuring smooth performance
   * for high-frequency events like mouse movements or scroll events.
   *
   * @param fn - The function to throttle, optionally with a cancel method
   * @returns A throttled function with an optional cancel method to remove pending calls
   *
   * @public
   */ fpsThrottle(fn) {
        if (isTest()) //TURBOPACK unreachable
        ;
        const throttledFn = ()=>{
            if (this.fpsQueue.includes(fn)) {
                return;
            }
            this.fpsQueue.push(fn);
            this.tick();
        };
        throttledFn.cancel = ()=>{
            const index = this.fpsQueue.indexOf(fn);
            if (index > -1) {
                this.fpsQueue.splice(index, 1);
            }
        };
        return throttledFn;
    }
    /**
   * Schedules a function to execute on the next animation frame.
   * If the same function is passed multiple times before the frame executes,
   * it will only be called once, effectively batching multiple calls.
   *
   * @param fn - The function to execute on the next frame
   * @returns A cancel function that can prevent execution if called before the next frame
   *
   * @public
   */ throttleToNextFrame(fn) {
        if (isTest()) //TURBOPACK unreachable
        ;
        if (!this.fpsQueue.includes(fn)) {
            this.fpsQueue.push(fn);
            this.tick();
        }
        return ()=>{
            const index = this.fpsQueue.indexOf(fn);
            if (index > -1) {
                this.fpsQueue.splice(index, 1);
            }
        };
    }
}
const defaultScheduler = new FpsScheduler(120);
function fpsThrottle(fn) {
    return defaultScheduler.fpsThrottle(fn);
}
function throttleToNextFrame(fn) {
    return defaultScheduler.throttleToNextFrame(fn);
}
;
 //# sourceMappingURL=throttle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/timers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Timers",
    ()=>Timers
]);
class Timers {
    timeouts = /* @__PURE__ */ new Map();
    intervals = /* @__PURE__ */ new Map();
    rafs = /* @__PURE__ */ new Map();
    /**
   * Creates a new Timers instance with bound methods for safe callback usage.
   * @example
   * ```ts
   * const timers = new Timers()
   * // Methods are pre-bound, safe to use as callbacks
   * element.addEventListener('click', timers.dispose)
   * ```
   */ constructor(){
        this.setTimeout = this.setTimeout.bind(this);
        this.setInterval = this.setInterval.bind(this);
        this.requestAnimationFrame = this.requestAnimationFrame.bind(this);
        this.dispose = this.dispose.bind(this);
    }
    /**
   * Creates a timeout that will be tracked under the specified context.
   * @param contextId - The context identifier to group this timer under.
   * @param handler - The function to execute when the timeout expires.
   * @param timeout - The delay in milliseconds (default: 0).
   * @param args - Additional arguments to pass to the handler.
   * @returns The timer ID that can be used with clearTimeout.
   * @example
   * ```ts
   * const timers = new Timers()
   * const id = timers.setTimeout('autosave', () => save(), 5000)
   * // Timer will be automatically cleared when 'autosave' context is disposed
   * ```
   * @public
   */ setTimeout(contextId, handler, timeout, ...args) {
        const id = window.setTimeout(handler, timeout, args);
        const current = this.timeouts.get(contextId) ?? [];
        this.timeouts.set(contextId, [
            ...current,
            id
        ]);
        return id;
    }
    /**
   * Creates an interval that will be tracked under the specified context.
   * @param contextId - The context identifier to group this timer under.
   * @param handler - The function to execute repeatedly.
   * @param timeout - The delay in milliseconds between executions (default: 0).
   * @param args - Additional arguments to pass to the handler.
   * @returns The interval ID that can be used with clearInterval.
   * @example
   * ```ts
   * const timers = new Timers()
   * const id = timers.setInterval('refresh', () => updateData(), 1000)
   * // Interval will be automatically cleared when 'refresh' context is disposed
   * ```
   * @public
   */ setInterval(contextId, handler, timeout, ...args) {
        const id = window.setInterval(handler, timeout, args);
        const current = this.intervals.get(contextId) ?? [];
        this.intervals.set(contextId, [
            ...current,
            id
        ]);
        return id;
    }
    /**
   * Requests an animation frame that will be tracked under the specified context.
   * @param contextId - The context identifier to group this animation frame under.
   * @param callback - The function to execute on the next animation frame.
   * @returns The request ID that can be used with cancelAnimationFrame.
   * @example
   * ```ts
   * const timers = new Timers()
   * const id = timers.requestAnimationFrame('render', () => draw())
   * // Animation frame will be automatically cancelled when 'render' context is disposed
   * ```
   * @public
   */ requestAnimationFrame(contextId, callback) {
        const id = window.requestAnimationFrame(callback);
        const current = this.rafs.get(contextId) ?? [];
        this.rafs.set(contextId, [
            ...current,
            id
        ]);
        return id;
    }
    /**
   * Disposes of all timers associated with the specified context.
   * Clears all timeouts, intervals, and animation frames for the given context ID.
   * @param contextId - The context identifier whose timers should be cleared.
   * @returns void
   * @example
   * ```ts
   * const timers = new Timers()
   * timers.setTimeout('ui', () => console.log('timeout'), 1000)
   * timers.setInterval('ui', () => console.log('interval'), 500)
   *
   * // Clear all 'ui' context timers
   * timers.dispose('ui')
   * ```
   * @public
   */ dispose(contextId) {
        this.timeouts.get(contextId)?.forEach((id)=>clearTimeout(id));
        this.intervals.get(contextId)?.forEach((id)=>clearInterval(id));
        this.rafs.get(contextId)?.forEach((id)=>cancelAnimationFrame(id));
        this.timeouts.delete(contextId);
        this.intervals.delete(contextId);
        this.rafs.delete(contextId);
    }
    /**
   * Disposes of all timers across all contexts.
   * Clears every timeout, interval, and animation frame managed by this instance.
   * @returns void
   * @example
   * ```ts
   * const timers = new Timers()
   * timers.setTimeout('ui', () => console.log('ui'), 1000)
   * timers.setTimeout('background', () => console.log('bg'), 2000)
   *
   * // Clear everything
   * timers.disposeAll()
   * ```
   * @public
   */ disposeAll() {
        for (const contextId of this.timeouts.keys()){
            this.dispose(contextId);
        }
    }
    /**
   * Returns an object with timer methods bound to a specific context.
   * Convenient for getting context-specific timer functions without repeatedly passing the contextId.
   * @param contextId - The context identifier to bind the returned methods to.
   * @returns An object with setTimeout, setInterval, requestAnimationFrame, and dispose methods bound to the context.
   * @example
   * ```ts
   * const timers = new Timers()
   * const uiTimers = timers.forContext('ui')
   *
   * // These are equivalent to calling timers.setTimeout('ui', ...)
   * uiTimers.setTimeout(() => console.log('timeout'), 1000)
   * uiTimers.setInterval(() => console.log('interval'), 500)
   * uiTimers.requestAnimationFrame(() => console.log('frame'))
   *
   * // Dispose only this context
   * uiTimers.dispose()
   * ```
   * @public
   */ forContext(contextId) {
        return {
            setTimeout: (handler, timeout, ...args)=>this.setTimeout(contextId, handler, timeout, args),
            setInterval: (handler, timeout, ...args)=>this.setInterval(contextId, handler, timeout, args),
            requestAnimationFrame: (callback)=>this.requestAnimationFrame(contextId, callback),
            dispose: ()=>this.dispose(contextId)
        };
    }
}
;
 //# sourceMappingURL=timers.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/url.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "safeParseUrl",
    ()=>safeParseUrl
]);
const safeParseUrl = (url, baseUrl)=>{
    try {
        return new URL(url, baseUrl);
    } catch  {
        return;
    }
};
;
 //# sourceMappingURL=url.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STRUCTURED_CLONE_OBJECT_PROTOTYPE",
    ()=>STRUCTURED_CLONE_OBJECT_PROTOTYPE,
    "isDefined",
    ()=>isDefined,
    "isNativeStructuredClone",
    ()=>isNativeStructuredClone,
    "isNonNull",
    ()=>isNonNull,
    "isNonNullish",
    ()=>isNonNullish,
    "structuredClone",
    ()=>structuredClone
]);
function isDefined(value) {
    return value !== void 0;
}
function isNonNull(value) {
    return value !== null;
}
function isNonNullish(value) {
    return value !== null && value !== void 0;
}
function getStructuredClone() {
    if (typeof globalThis !== "undefined" && globalThis.structuredClone) {
        return [
            globalThis.structuredClone,
            true
        ];
    }
    if (("TURBOPACK compile-time value", "object") !== "undefined" && /*TURBOPACK member replacement*/ __turbopack_context__.g.structuredClone) {
        return [
            /*TURBOPACK member replacement*/ __turbopack_context__.g.structuredClone,
            true
        ];
    }
    if (typeof window !== "undefined" && window.structuredClone) {
        return [
            window.structuredClone,
            true
        ];
    }
    return [
        (i)=>i ? JSON.parse(JSON.stringify(i)) : i,
        false
    ];
}
const _structuredClone = getStructuredClone();
const structuredClone = _structuredClone[0];
const isNativeStructuredClone = _structuredClone[1];
const STRUCTURED_CLONE_OBJECT_PROTOTYPE = Object.getPrototypeOf(structuredClone({}));
;
 //# sourceMappingURL=value.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/warn.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "warnDeprecatedGetter",
    ()=>warnDeprecatedGetter,
    "warnOnce",
    ()=>warnOnce
]);
const usedWarnings = /* @__PURE__ */ new Set();
function warnDeprecatedGetter(name) {
    warnOnce(`Using '${name}' is deprecated and will be removed in the near future. Please refactor to use 'get${name[0].toLocaleUpperCase()}${name.slice(1)}' instead.`);
}
function warnOnce(message) {
    if (usedWarnings.has(message)) return;
    usedWarnings.add(message);
    console.warn(`[tldraw] ${message}`);
}
;
 //# sourceMappingURL=warn.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequalwith$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequalwith/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$throttle$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.throttle/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$uniq$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.uniq/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/cache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$debounce$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/debounce.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$ExecutionQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/ExecutionQueue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/function.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/hash.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$iterable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/iterable.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/media.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/png.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/perf.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/PerformanceTracker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$retry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/retry.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$sort$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/sort.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/storage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$stringEnum$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/stringEnum.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/throttle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$timers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/timers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/url.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/warn.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerTldrawLibraryVersion"])("@tldraw/utils", "4.4.0", "esm");
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_SUPPORTED_IMAGE_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_IMAGE_TYPES"],
    "DEFAULT_SUPPORTED_MEDIA_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_MEDIA_TYPES"],
    "DEFAULT_SUPPORTED_MEDIA_TYPE_LIST",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_MEDIA_TYPE_LIST"],
    "DEFAULT_SUPPORT_VIDEO_TYPES",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORT_VIDEO_TYPES"],
    "ExecutionQueue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$ExecutionQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExecutionQueue"],
    "FileHelpers",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"],
    "FpsScheduler",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FpsScheduler"],
    "Image",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"],
    "MediaHelpers",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"],
    "PerformanceTracker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PerformanceTracker"],
    "PngHelpers",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PngHelpers"],
    "Result",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"],
    "STRUCTURED_CLONE_OBJECT_PROTOTYPE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STRUCTURED_CLONE_OBJECT_PROTOTYPE"],
    "Timers",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$timers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timers"],
    "WeakCache",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"],
    "ZERO_INDEX_KEY",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZERO_INDEX_KEY"],
    "annotateError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["annotateError"],
    "areArraysShallowEqual",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysShallowEqual"],
    "areObjectsShallowEqual",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areObjectsShallowEqual"],
    "assert",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"],
    "assertExists",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"],
    "bind",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"],
    "clearLocalStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearLocalStorage"],
    "clearSessionStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSessionStorage"],
    "compact",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"],
    "debounce",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$debounce$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debounce"],
    "dedupe",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dedupe"],
    "deleteFromLocalStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteFromLocalStorage"],
    "deleteFromSessionStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteFromSessionStorage"],
    "exhaustiveSwitchError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"],
    "fetch",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"],
    "filterEntries",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"],
    "fpsThrottle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fpsThrottle"],
    "getChangedKeys",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChangedKeys"],
    "getErrorAnnotations",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorAnnotations"],
    "getFirstFromIterable",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$iterable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirstFromIterable"],
    "getFromLocalStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFromLocalStorage"],
    "getFromSessionStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFromSessionStorage"],
    "getHashForBuffer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForBuffer"],
    "getHashForObject",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForObject"],
    "getHashForString",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForString"],
    "getIndexAbove",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"],
    "getIndexBelow",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexBelow"],
    "getIndexBetween",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexBetween"],
    "getIndices",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndices"],
    "getIndicesAbove",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesAbove"],
    "getIndicesBelow",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesBelow"],
    "getIndicesBetween",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesBetween"],
    "getOwnProperty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"],
    "groupBy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupBy"],
    "hasOwnProperty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"],
    "invLerp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invLerp"],
    "isDefined",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDefined"],
    "isEqual",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "isEqualAllowingForFloatingPointErrors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEqualAllowingForFloatingPointErrors"],
    "isEqualWith",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequalwith$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "isNativeStructuredClone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNativeStructuredClone"],
    "isNonNull",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNonNull"],
    "isNonNullish",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNonNullish"],
    "last",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"],
    "lerp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"],
    "lns",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lns"],
    "mapObjectMapValues",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"],
    "maxBy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maxBy"],
    "measureAverageDuration",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["measureAverageDuration"],
    "measureCbDuration",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["measureCbDuration"],
    "measureDuration",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["measureDuration"],
    "mergeArraysAndReplaceDefaults",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"],
    "minBy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["minBy"],
    "mockUniqueId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockUniqueId"],
    "modulate",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["modulate"],
    "noop",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"],
    "objectMapEntries",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"],
    "objectMapEntriesIterable",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntriesIterable"],
    "objectMapFromEntries",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapFromEntries"],
    "objectMapKeys",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapKeys"],
    "objectMapValues",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"],
    "omit",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"],
    "omitFromStackTrace",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omitFromStackTrace"],
    "partition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["partition"],
    "promiseWithResolve",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["promiseWithResolve"],
    "registerTldrawLibraryVersion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerTldrawLibraryVersion"],
    "restoreUniqueId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreUniqueId"],
    "retry",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$retry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["retry"],
    "rng",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rng"],
    "rotateArray",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotateArray"],
    "safeParseUrl",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"],
    "setInLocalStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInLocalStorage"],
    "setInSessionStorage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInSessionStorage"],
    "sleep",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"],
    "sortById",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$sort$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortById"],
    "sortByIndex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"],
    "sortByMaybeIndex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByMaybeIndex"],
    "stringEnum",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$stringEnum$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringEnum"],
    "structuredClone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"],
    "throttle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$throttle$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "throttleToNextFrame",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throttleToNextFrame"],
    "uniq",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$uniq$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "uniqueId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"],
    "validateIndexKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateIndexKey"],
    "warnDeprecatedGetter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warnDeprecatedGetter"],
    "warnOnce",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warnOnce"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequalwith$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequalwith/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$throttle$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.throttle/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$uniq$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.uniq/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/cache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$debounce$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/debounce.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$ExecutionQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/ExecutionQueue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/function.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$hash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/hash.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$iterable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/iterable.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$media$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/media.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$media$2f$png$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/media/png.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$perf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/perf.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/PerformanceTracker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$retry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/retry.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$sort$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/sort.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$storage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/storage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$stringEnum$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/stringEnum.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/throttle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$timers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/timers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$url$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/url.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/warn.mjs [app-client] (ecmascript)");
}),
]);

//# debugId=8333ce02-7e71-1b13-86b8-4b7a8f7ac10e
//# sourceMappingURL=c427b_%40tldraw_utils_dist-esm_0955d557._.js.map