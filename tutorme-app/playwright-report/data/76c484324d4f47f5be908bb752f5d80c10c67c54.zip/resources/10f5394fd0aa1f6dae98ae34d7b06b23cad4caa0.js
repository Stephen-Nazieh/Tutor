(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_components_gamification_73735d15._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_components_spaced-repetition_ab1277a2._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_components_f8e7c3b5._.js",
  "static/chunks/d33ef_WORKSPACE_TutorMekimi_tutorme-app_src_app_[locale]_student_dashboard_665149e9._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_lib_gamification_c91b670e._.js",
  "static/chunks/c427b_date-fns_a627a3a0._.js",
  "static/chunks/c427b_motion-dom_dist_es_f969fe4b._.js",
  "static/chunks/c427b_framer-motion_dist_es_705f2e18._.js",
  "static/chunks/c427b_@radix-ui_b6188b7e._.js",
  "static/chunks/c427b_react-day-picker_dist_esm_1c3d91c7._.js",
  "static/chunks/c427b_2b1278a3._.js"
],
    source: "dynamic"
});
