;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="97773388-622b-5076-90b7-1e334d3ead21")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/ImmutableMap.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImmutableMap",
    ()=>ImmutableMap,
    "emptyMap",
    ()=>emptyMap,
    "iteratorDone",
    ()=>iteratorDone
]);
/*!
 * This file was lovingly and delicately extracted from Immutable.js
 * MIT License: https://github.com/immutable-js/immutable-js/blob/main/LICENSE
 * Copyright (c) 2014-present, Lee Byron and other contributors.
 */ function smi(i32) {
    return i32 >>> 1 & 1073741824 | i32 & 3221225471;
}
const defaultValueOf = Object.prototype.valueOf;
function hash(o) {
    if (o == null) {
        return hashNullish(o);
    }
    if (typeof o.hashCode === "function") {
        return smi(o.hashCode(o));
    }
    const v = valueOf(o);
    if (v == null) {
        return hashNullish(v);
    }
    switch(typeof v){
        case "boolean":
            return v ? 1108378657 : 1108378656;
        case "number":
            return hashNumber(v);
        case "string":
            return cachedHashString(v);
        case "object":
        case "function":
            return hashJSObj(v);
        case "symbol":
            return hashSymbol(v);
        default:
            if (typeof v.toString === "function") {
                return hashString(v.toString());
            }
            throw new Error("Value type " + typeof v + " cannot be hashed.");
    }
}
function hashNullish(nullish) {
    return nullish === null ? 1108378658 : 1108378659;
}
function hashNumber(n) {
    if (n !== n || n === Infinity) {
        return 0;
    }
    let hash2 = n | 0;
    if (hash2 !== n) {
        hash2 ^= n * 4294967295;
    }
    while(n > 4294967295){
        n /= 4294967295;
        hash2 ^= n;
    }
    return smi(hash2);
}
function cachedHashString(string) {
    let hashed = stringHashCache[string];
    if (hashed === void 0) {
        hashed = hashString(string);
        if (stringHashCacheCount === STRING_HASH_CACHE_SIZE) {
            stringHashCacheCount = 0;
            stringHashCache = {};
        }
        stringHashCache[string] = hashed;
        stringHashCacheCount++;
    }
    return hashed;
}
function hashString(string) {
    let hashed = 0;
    for(let ii = 0; ii < string.length; ii++){
        hashed = 31 * hashed + string.charCodeAt(ii) | 0;
    }
    return smi(hashed);
}
function hashSymbol(sym) {
    let hashed = symbolMap[sym];
    if (hashed !== void 0) {
        return hashed;
    }
    hashed = nextHash();
    symbolMap[sym] = hashed;
    return hashed;
}
function hashJSObj(obj) {
    let hashed = weakMap.get(obj);
    if (hashed !== void 0) {
        return hashed;
    }
    hashed = nextHash();
    weakMap.set(obj, hashed);
    return hashed;
}
function valueOf(obj) {
    return obj.valueOf !== defaultValueOf && typeof obj.valueOf === "function" ? obj.valueOf(obj) : obj;
}
function nextHash() {
    const nextHash2 = ++_objHashUID;
    if (_objHashUID & 1073741824) {
        _objHashUID = 0;
    }
    return nextHash2;
}
const weakMap = /* @__PURE__ */ new WeakMap();
const symbolMap = /* @__PURE__ */ Object.create(null);
let _objHashUID = 0;
let stringHashCache = {};
let stringHashCacheCount = 0;
const STRING_HASH_CACHE_SIZE = 24e3;
const SHIFT = 5;
const SIZE = 1 << SHIFT;
const MASK = SIZE - 1;
const NOT_SET = {};
function MakeRef() {
    return {
        value: false
    };
}
function SetRef(ref) {
    if (ref) {
        ref.value = true;
    }
}
function arrCopy(arr, offset = 0) {
    return arr.slice(offset);
}
class OwnerID {
}
class ImmutableMap {
    // @pragma Construction
    // @ts-ignore
    _root;
    // @ts-ignore
    size;
    // @ts-ignore
    __ownerID;
    // @ts-ignore
    __hash;
    // @ts-ignore
    __altered;
    /**
   * Creates a new ImmutableMap instance.
   *
   * @param value - An iterable of key-value pairs to populate the map, or null/undefined for an empty map
   * @example
   * ```ts
   * // Create from array of pairs
   * const map1 = new ImmutableMap([['a', 1], ['b', 2]])
   *
   * // Create empty map
   * const map2 = new ImmutableMap()
   *
   * // Create from another map
   * const map3 = new ImmutableMap(map1)
   * ```
   */ constructor(value){
        return value === void 0 || value === null ? emptyMap() : value instanceof ImmutableMap ? value : emptyMap().withMutations((map)=>{
            for (const [k, v] of value){
                map.set(k, v);
            }
        });
    }
    /**
   * Gets the value associated with the specified key, with a fallback value.
   *
   * @param k - The key to look up
   * @param notSetValue - The value to return if the key is not found
   * @returns The value associated with the key, or the fallback value if not found
   * @example
   * ```ts
   * const map = new ImmutableMap([['key1', 'value1']])
   * console.log(map.get('key1', 'default')) // 'value1'
   * console.log(map.get('missing', 'default')) // 'default'
   * ```
   */ get(k, notSetValue) {
        return this._root ? this._root.get(0, void 0, k, notSetValue) : notSetValue;
    }
    /**
   * Returns a new ImmutableMap with the specified key-value pair added or updated.
   * If the key already exists, its value is replaced. Otherwise, a new entry is created.
   *
   * @param k - The key to set
   * @param v - The value to associate with the key
   * @returns A new ImmutableMap with the key-value pair set
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1]])
   * const updated = map.set('b', 2) // New map with both 'a' and 'b'
   * const replaced = map.set('a', 10) // New map with 'a' updated to 10
   * ```
   */ set(k, v) {
        return updateMap(this, k, v);
    }
    /**
   * Returns a new ImmutableMap with the specified key removed.
   * If the key doesn't exist, returns the same map instance.
   *
   * @param k - The key to remove
   * @returns A new ImmutableMap with the key removed, or the same instance if key not found
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2]])
   * const smaller = map.delete('a') // New map with only 'b'
   * const same = map.delete('missing') // Returns original map
   * ```
   */ delete(k) {
        return updateMap(this, k, NOT_SET);
    }
    /**
   * Returns a new ImmutableMap with all specified keys removed.
   * This is more efficient than calling delete() multiple times.
   *
   * @param keys - An iterable of keys to remove
   * @returns A new ImmutableMap with all specified keys removed
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2], ['c', 3]])
   * const smaller = map.deleteAll(['a', 'c']) // New map with only 'b'
   * ```
   */ deleteAll(keys) {
        return this.withMutations((map)=>{
            for (const key of keys){
                map.delete(key);
            }
        });
    }
    __ensureOwner(ownerID) {
        if (ownerID === this.__ownerID) {
            return this;
        }
        if (!ownerID) {
            if (this.size === 0) {
                return emptyMap();
            }
            this.__ownerID = ownerID;
            this.__altered = false;
            return this;
        }
        return makeMap(this.size, this._root, ownerID, this.__hash);
    }
    /**
   * Applies multiple mutations efficiently by creating a mutable copy,
   * applying all changes, then returning an immutable result.
   * This is more efficient than chaining multiple set/delete operations.
   *
   * @param fn - Function that receives a mutable copy and applies changes
   * @returns A new ImmutableMap with all mutations applied, or the same instance if no changes
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1]])
   * const updated = map.withMutations(mutable => {
   *   mutable.set('b', 2)
   *   mutable.set('c', 3)
   *   mutable.delete('a')
   * }) // Efficiently applies all changes at once
   * ```
   */ withMutations(fn) {
        const mutable = this.asMutable();
        fn(mutable);
        return mutable.wasAltered() ? mutable.__ensureOwner(this.__ownerID) : this;
    }
    /**
   * Checks if this map instance has been altered during a mutation operation.
   * This is used internally to optimize mutations.
   *
   * @returns True if the map was altered, false otherwise
   * @internal
   */ wasAltered() {
        return this.__altered;
    }
    /**
   * Returns a mutable copy of this map that can be efficiently modified.
   * Multiple changes to the mutable copy are batched together.
   *
   * @returns A mutable copy of this map
   * @internal
   */ asMutable() {
        return this.__ownerID ? this : this.__ensureOwner(new OwnerID());
    }
    /**
   * Makes the map iterable, yielding key-value pairs.
   *
   * @returns An iterator over [key, value] pairs
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2]])
   * for (const [key, value] of map) {
   *   console.log(key, value) // 'a' 1, then 'b' 2
   * }
   * ```
   */ [Symbol.iterator]() {
        return this.entries()[Symbol.iterator]();
    }
    /**
   * Returns an iterable of key-value pairs.
   *
   * @returns An iterable over [key, value] pairs
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2]])
   * const entries = Array.from(map.entries()) // [['a', 1], ['b', 2]]
   * ```
   */ entries() {
        return new MapIterator(this, ITERATE_ENTRIES, false);
    }
    /**
   * Returns an iterable of keys.
   *
   * @returns An iterable over keys
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2]])
   * const keys = Array.from(map.keys()) // ['a', 'b']
   * ```
   */ keys() {
        return new MapIterator(this, ITERATE_KEYS, false);
    }
    /**
   * Returns an iterable of values.
   *
   * @returns An iterable over values
   * @example
   * ```ts
   * const map = new ImmutableMap([['a', 1], ['b', 2]])
   * const values = Array.from(map.values()) // [1, 2]
   * ```
   */ values() {
        return new MapIterator(this, ITERATE_VALUES, false);
    }
}
class ArrayMapNode {
    constructor(ownerID, entries){
        this.ownerID = ownerID;
        this.entries = entries;
    }
    get(_shift, _keyHash, key, notSetValue) {
        const entries = this.entries;
        for(let ii = 0, len = entries.length; ii < len; ii++){
            if (Object.is(key, entries[ii][0])) {
                return entries[ii][1];
            }
        }
        return notSetValue;
    }
    update(ownerID, _shift, _keyHash, key, value, didChangeSize, didAlter) {
        const removed = value === NOT_SET;
        const entries = this.entries;
        let idx = 0;
        const len = entries.length;
        for(; idx < len; idx++){
            if (Object.is(key, entries[idx][0])) {
                break;
            }
        }
        const exists = idx < len;
        if (exists ? entries[idx][1] === value : removed) {
            return this;
        }
        SetRef(didAlter);
        if (removed || !exists) SetRef(didChangeSize);
        if (removed && entries.length === 1) {
            return;
        }
        if (!exists && !removed && entries.length >= MAX_ARRAY_MAP_SIZE) {
            return createNodes(ownerID, entries, key, value);
        }
        const isEditable = ownerID && ownerID === this.ownerID;
        const newEntries = isEditable ? entries : arrCopy(entries);
        if (exists) {
            if (removed) {
                if (idx === len - 1) {
                    newEntries.pop();
                } else {
                    newEntries[idx] = newEntries.pop();
                }
            } else {
                newEntries[idx] = [
                    key,
                    value
                ];
            }
        } else {
            newEntries.push([
                key,
                value
            ]);
        }
        if (isEditable) {
            this.entries = newEntries;
            return this;
        }
        return new ArrayMapNode(ownerID, newEntries);
    }
}
class BitmapIndexedNode {
    constructor(ownerID, bitmap, nodes){
        this.ownerID = ownerID;
        this.bitmap = bitmap;
        this.nodes = nodes;
    }
    get(shift, keyHash, key, notSetValue) {
        if (keyHash === void 0) {
            keyHash = hash(key);
        }
        const bit = 1 << ((shift === 0 ? keyHash : keyHash >>> shift) & MASK);
        const bitmap = this.bitmap;
        return (bitmap & bit) === 0 ? notSetValue : this.nodes[popCount(bitmap & bit - 1)].get(shift + SHIFT, keyHash, key, notSetValue);
    }
    update(ownerID, shift, keyHash, key, value, didChangeSize, didAlter) {
        if (keyHash === void 0) {
            keyHash = hash(key);
        }
        const keyHashFrag = (shift === 0 ? keyHash : keyHash >>> shift) & MASK;
        const bit = 1 << keyHashFrag;
        const bitmap = this.bitmap;
        const exists = (bitmap & bit) !== 0;
        if (!exists && value === NOT_SET) {
            return this;
        }
        const idx = popCount(bitmap & bit - 1);
        const nodes = this.nodes;
        const node = exists ? nodes[idx] : void 0;
        const newNode = updateNode(node, ownerID, shift + SHIFT, keyHash, key, value, didChangeSize, didAlter);
        if (newNode === node) {
            return this;
        }
        if (!exists && newNode && nodes.length >= MAX_BITMAP_INDEXED_SIZE) {
            return expandNodes(ownerID, nodes, bitmap, keyHashFrag, newNode);
        }
        if (exists && !newNode && nodes.length === 2 && isLeafNode(nodes[idx ^ 1])) {
            return nodes[idx ^ 1];
        }
        if (exists && newNode && nodes.length === 1 && isLeafNode(newNode)) {
            return newNode;
        }
        const isEditable = ownerID && ownerID === this.ownerID;
        const newBitmap = exists ? newNode ? bitmap : bitmap ^ bit : bitmap | bit;
        const newNodes = exists ? newNode ? setAt(nodes, idx, newNode, isEditable) : spliceOut(nodes, idx, isEditable) : spliceIn(nodes, idx, newNode, isEditable);
        if (isEditable) {
            this.bitmap = newBitmap;
            this.nodes = newNodes;
            return this;
        }
        return new BitmapIndexedNode(ownerID, newBitmap, newNodes);
    }
}
class HashArrayMapNode {
    constructor(ownerID, count, nodes){
        this.ownerID = ownerID;
        this.count = count;
        this.nodes = nodes;
    }
    get(shift, keyHash, key, notSetValue) {
        if (keyHash === void 0) {
            keyHash = hash(key);
        }
        const idx = (shift === 0 ? keyHash : keyHash >>> shift) & MASK;
        const node = this.nodes[idx];
        return node ? node.get(shift + SHIFT, keyHash, key, notSetValue) : notSetValue;
    }
    update(ownerID, shift, keyHash, key, value, didChangeSize, didAlter) {
        if (keyHash === void 0) {
            keyHash = hash(key);
        }
        const idx = (shift === 0 ? keyHash : keyHash >>> shift) & MASK;
        const removed = value === NOT_SET;
        const nodes = this.nodes;
        const node = nodes[idx];
        if (removed && !node) {
            return this;
        }
        const newNode = updateNode(node, ownerID, shift + SHIFT, keyHash, key, value, didChangeSize, didAlter);
        if (newNode === node) {
            return this;
        }
        let newCount = this.count;
        if (!node) {
            newCount++;
        } else if (!newNode) {
            newCount--;
            if (newCount < MIN_HASH_ARRAY_MAP_SIZE) {
                return packNodes(ownerID, nodes, newCount, idx);
            }
        }
        const isEditable = ownerID && ownerID === this.ownerID;
        const newNodes = setAt(nodes, idx, newNode, isEditable);
        if (isEditable) {
            this.count = newCount;
            this.nodes = newNodes;
            return this;
        }
        return new HashArrayMapNode(ownerID, newCount, newNodes);
    }
}
class HashCollisionNode {
    constructor(ownerID, keyHash, entries){
        this.ownerID = ownerID;
        this.keyHash = keyHash;
        this.entries = entries;
    }
    get(shift, keyHash, key, notSetValue) {
        const entries = this.entries;
        for(let ii = 0, len = entries.length; ii < len; ii++){
            if (Object.is(key, entries[ii][0])) {
                return entries[ii][1];
            }
        }
        return notSetValue;
    }
    update(ownerID, shift, keyHash, key, value, didChangeSize, didAlter) {
        if (keyHash === void 0) {
            keyHash = hash(key);
        }
        const removed = value === NOT_SET;
        if (keyHash !== this.keyHash) {
            if (removed) {
                return this;
            }
            SetRef(didAlter);
            SetRef(didChangeSize);
            return mergeIntoNode(this, ownerID, shift, keyHash, [
                key,
                value
            ]);
        }
        const entries = this.entries;
        let idx = 0;
        const len = entries.length;
        for(; idx < len; idx++){
            if (Object.is(key, entries[idx][0])) {
                break;
            }
        }
        const exists = idx < len;
        if (exists ? entries[idx][1] === value : removed) {
            return this;
        }
        SetRef(didAlter);
        if (removed || !exists) SetRef(didChangeSize);
        if (removed && len === 2) {
            return new ValueNode(ownerID, this.keyHash, entries[idx ^ 1]);
        }
        const isEditable = ownerID && ownerID === this.ownerID;
        const newEntries = isEditable ? entries : arrCopy(entries);
        if (exists) {
            if (removed) {
                if (idx === len - 1) {
                    newEntries.pop();
                } else {
                    newEntries[idx] = newEntries.pop();
                }
            } else {
                newEntries[idx] = [
                    key,
                    value
                ];
            }
        } else {
            newEntries.push([
                key,
                value
            ]);
        }
        if (isEditable) {
            this.entries = newEntries;
            return this;
        }
        return new HashCollisionNode(ownerID, this.keyHash, newEntries);
    }
}
class ValueNode {
    constructor(ownerID, keyHash, entry){
        this.ownerID = ownerID;
        this.keyHash = keyHash;
        this.entry = entry;
    }
    get(shift, keyHash, key, notSetValue) {
        return Object.is(key, this.entry[0]) ? this.entry[1] : notSetValue;
    }
    update(ownerID, shift, keyHash, key, value, didChangeSize, didAlter) {
        const removed = value === NOT_SET;
        const keyMatch = Object.is(key, this.entry[0]);
        if (keyMatch ? value === this.entry[1] : removed) {
            return this;
        }
        SetRef(didAlter);
        if (removed) {
            SetRef(didChangeSize);
            return;
        }
        if (keyMatch) {
            if (ownerID && ownerID === this.ownerID) {
                this.entry[1] = value;
                return this;
            }
            return new ValueNode(ownerID, this.keyHash, [
                key,
                value
            ]);
        }
        SetRef(didChangeSize);
        return mergeIntoNode(this, ownerID, shift, hash(key), [
            key,
            value
        ]);
    }
}
class MapIterator {
    constructor(map, _type, _reverse){
        this._type = _type;
        this._reverse = _reverse;
        this._stack = map._root && mapIteratorFrame(map._root);
    }
    _stack;
    [Symbol.iterator]() {
        return this;
    }
    next() {
        const type = this._type;
        let stack = this._stack;
        while(stack){
            const node = stack.node;
            const index = stack.index++;
            let maxIndex;
            if (node.entry) {
                if (index === 0) {
                    return mapIteratorValue(type, node.entry);
                }
            } else if ("entries" in node && node.entries) {
                maxIndex = node.entries.length - 1;
                if (index <= maxIndex) {
                    return mapIteratorValue(type, node.entries[this._reverse ? maxIndex - index : index]);
                }
            } else {
                maxIndex = node.nodes.length - 1;
                if (index <= maxIndex) {
                    const subNode = node.nodes[this._reverse ? maxIndex - index : index];
                    if (subNode) {
                        if (subNode.entry) {
                            return mapIteratorValue(type, subNode.entry);
                        }
                        stack = this._stack = mapIteratorFrame(subNode, stack);
                    }
                    continue;
                }
            }
            stack = this._stack = this._stack.__prev;
        }
        return iteratorDone();
    }
}
function mapIteratorValue(type, entry) {
    return iteratorValue(type, entry[0], entry[1]);
}
function mapIteratorFrame(node, prev) {
    return {
        node,
        index: 0,
        __prev: prev
    };
}
const ITERATE_KEYS = 0;
const ITERATE_VALUES = 1;
const ITERATE_ENTRIES = 2;
function iteratorValue(type, k, v, iteratorResult) {
    const value = type === ITERATE_KEYS ? k : type === ITERATE_VALUES ? v : [
        k,
        v
    ];
    if (iteratorResult) {
        iteratorResult.value = value;
    } else {
        iteratorResult = {
            value,
            done: false
        };
    }
    return iteratorResult;
}
function iteratorDone() {
    return {
        value: void 0,
        done: true
    };
}
function makeMap(size, root, ownerID, hash2) {
    const map = Object.create(ImmutableMap.prototype);
    map.size = size;
    map._root = root;
    map.__ownerID = ownerID;
    map.__hash = hash2;
    map.__altered = false;
    return map;
}
let EMPTY_MAP;
function emptyMap() {
    return EMPTY_MAP || (EMPTY_MAP = makeMap(0));
}
function updateMap(map, k, v) {
    let newRoot;
    let newSize;
    if (!map._root) {
        if (v === NOT_SET) {
            return map;
        }
        newSize = 1;
        newRoot = new ArrayMapNode(map.__ownerID, [
            [
                k,
                v
            ]
        ]);
    } else {
        const didChangeSize = MakeRef();
        const didAlter = MakeRef();
        newRoot = updateNode(map._root, map.__ownerID, 0, void 0, k, v, didChangeSize, didAlter);
        if (!didAlter.value) {
            return map;
        }
        newSize = map.size + (didChangeSize.value ? v === NOT_SET ? -1 : 1 : 0);
    }
    if (map.__ownerID) {
        map.size = newSize;
        map._root = newRoot;
        map.__hash = void 0;
        map.__altered = true;
        return map;
    }
    return newRoot ? makeMap(newSize, newRoot) : emptyMap();
}
function updateNode(node, ownerID, shift, keyHash, key, value, didChangeSize, didAlter) {
    if (!node) {
        if (value === NOT_SET) {
            return node;
        }
        SetRef(didAlter);
        SetRef(didChangeSize);
        return new ValueNode(ownerID, keyHash, [
            key,
            value
        ]);
    }
    return node.update(ownerID, shift, keyHash, key, value, didChangeSize, didAlter);
}
function isLeafNode(node) {
    return node.constructor === ValueNode || node.constructor === HashCollisionNode;
}
function mergeIntoNode(node, ownerID, shift, keyHash, entry) {
    if (node.keyHash === keyHash) {
        return new HashCollisionNode(ownerID, keyHash, [
            node.entry,
            entry
        ]);
    }
    const idx1 = (shift === 0 ? node.keyHash : node.keyHash >>> shift) & MASK;
    const idx2 = (shift === 0 ? keyHash : keyHash >>> shift) & MASK;
    let newNode;
    const nodes = idx1 === idx2 ? [
        mergeIntoNode(node, ownerID, shift + SHIFT, keyHash, entry)
    ] : (newNode = new ValueNode(ownerID, keyHash, entry), idx1 < idx2 ? [
        node,
        newNode
    ] : [
        newNode,
        node
    ]);
    return new BitmapIndexedNode(ownerID, 1 << idx1 | 1 << idx2, nodes);
}
function createNodes(ownerID, entries, key, value) {
    if (!ownerID) {
        ownerID = new OwnerID();
    }
    let node = new ValueNode(ownerID, hash(key), [
        key,
        value
    ]);
    for(let ii = 0; ii < entries.length; ii++){
        const entry = entries[ii];
        node = node.update(ownerID, 0, void 0, entry[0], entry[1]);
    }
    return node;
}
function packNodes(ownerID, nodes, count, excluding) {
    let bitmap = 0;
    let packedII = 0;
    const packedNodes = new Array(count);
    for(let ii = 0, bit = 1, len = nodes.length; ii < len; ii++, bit <<= 1){
        const node = nodes[ii];
        if (node !== void 0 && ii !== excluding) {
            bitmap |= bit;
            packedNodes[packedII++] = node;
        }
    }
    return new BitmapIndexedNode(ownerID, bitmap, packedNodes);
}
function expandNodes(ownerID, nodes, bitmap, including, node) {
    let count = 0;
    const expandedNodes = new Array(SIZE);
    for(let ii = 0; bitmap !== 0; ii++, bitmap >>>= 1){
        expandedNodes[ii] = bitmap & 1 ? nodes[count++] : void 0;
    }
    expandedNodes[including] = node;
    return new HashArrayMapNode(ownerID, count + 1, expandedNodes);
}
function popCount(x) {
    x -= x >> 1 & 1431655765;
    x = (x & 858993459) + (x >> 2 & 858993459);
    x = x + (x >> 4) & 252645135;
    x += x >> 8;
    x += x >> 16;
    return x & 127;
}
function setAt(array, idx, val, canEdit) {
    const newArray = canEdit ? array : arrCopy(array);
    newArray[idx] = val;
    return newArray;
}
function spliceIn(array, idx, val, canEdit) {
    const newLen = array.length + 1;
    if (canEdit && idx + 1 === newLen) {
        array[idx] = val;
        return array;
    }
    const newArray = new Array(newLen);
    let after = 0;
    for(let ii = 0; ii < newLen; ii++){
        if (ii === idx) {
            newArray[ii] = val;
            after = -1;
        } else {
            newArray[ii] = array[ii + after];
        }
    }
    return newArray;
}
function spliceOut(array, idx, canEdit) {
    const newLen = array.length - 1;
    if (canEdit && idx === newLen) {
        array.pop();
        return array;
    }
    const newArray = new Array(newLen);
    let after = 0;
    for(let ii = 0; ii < newLen; ii++){
        if (ii === idx) {
            after = 1;
        }
        newArray[ii] = array[ii + after];
    }
    return newArray;
}
const MAX_ARRAY_MAP_SIZE = SIZE / 4;
const MAX_BITMAP_INDEXED_SIZE = SIZE / 2;
const MIN_HASH_ARRAY_MAP_SIZE = SIZE / 4;
;
 //# sourceMappingURL=ImmutableMap.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AtomMap",
    ()=>AtomMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/transactions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$ImmutableMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/ImmutableMap.mjs [app-client] (ecmascript)");
;
;
;
class AtomMap {
    /**
   * Creates a new AtomMap instance.
   *
   * name - A unique name for this map, used for atom identification
   * entries - Optional initial entries to populate the map with
   * @example
   * ```ts
   * // Create an empty map
   * const map = new AtomMap('userMap')
   *
   * // Create a map with initial data
   * const initialData: [string, number][] = [['a', 1], ['b', 2]]
   * const mapWithData = new AtomMap('numbersMap', initialData)
   * ```
   */ constructor(name, entries){
        this.name = name;
        let atoms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$ImmutableMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyMap"])();
        if (entries) {
            atoms = atoms.withMutations((atoms2)=>{
                for (const [k, v] of entries){
                    atoms2.set(k, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(`${name}:${String(k)}`, v));
                }
            });
        }
        this.atoms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(`${name}:atoms`, atoms);
    }
    atoms;
    /**
   * Retrieves the underlying atom for a given key.
   *
   * @param key - The key to retrieve the atom for
   * @returns The atom containing the value, or undefined if the key doesn't exist
   * @internal
   */ getAtom(key) {
        const valueAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (!valueAtom) {
            this.atoms.get();
            return void 0;
        }
        return valueAtom;
    }
    /**
   * Gets the value associated with a key. Returns undefined if the key doesn't exist.
   * This method is reactive and will cause reactive contexts to update when the value changes.
   *
   * @param key - The key to retrieve the value for
   * @returns The value associated with the key, or undefined if not found
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('name', 'Alice')
   * console.log(map.get('name')) // 'Alice'
   * console.log(map.get('missing')) // undefined
   * ```
   */ get(key) {
        const value = this.getAtom(key)?.get();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(value !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
        return value;
    }
    /**
   * Gets the value associated with a key without creating reactive dependencies.
   * This method will not cause reactive contexts to update when the value changes.
   *
   * @param key - The key to retrieve the value for
   * @returns The value associated with the key, or undefined if not found
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('count', 42)
   * const value = map.__unsafe__getWithoutCapture('count') // No reactive subscription
   * ```
   */ __unsafe__getWithoutCapture(key) {
        const valueAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (!valueAtom) return void 0;
        const value = valueAtom.__unsafe__getWithoutCapture();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(value !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
        return value;
    }
    /**
   * Checks whether a key exists in the map.
   * This method is reactive and will cause reactive contexts to update when keys are added or removed.
   *
   * @param key - The key to check for
   * @returns True if the key exists in the map, false otherwise
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * console.log(map.has('name')) // false
   * map.set('name', 'Alice')
   * console.log(map.has('name')) // true
   * ```
   */ has(key) {
        const valueAtom = this.getAtom(key);
        if (!valueAtom) {
            return false;
        }
        return valueAtom.get() !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"];
    }
    /**
   * Checks whether a key exists in the map without creating reactive dependencies.
   * This method will not cause reactive contexts to update when keys are added or removed.
   *
   * @param key - The key to check for
   * @returns True if the key exists in the map, false otherwise
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('active', true)
   * const exists = map.__unsafe__hasWithoutCapture('active') // No reactive subscription
   * ```
   */ __unsafe__hasWithoutCapture(key) {
        const valueAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (!valueAtom) return false;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(valueAtom.__unsafe__getWithoutCapture() !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
        return true;
    }
    /**
   * Sets a value for the given key. If the key already exists, its value is updated.
   * If the key doesn't exist, a new entry is created.
   *
   * @param key - The key to set the value for
   * @param value - The value to associate with the key
   * @returns This AtomMap instance for method chaining
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('name', 'Alice').set('age', 30)
   * ```
   */ set(key, value) {
        const existingAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (existingAtom) {
            existingAtom.set(value);
        } else {
            this.atoms.update((atoms)=>{
                return atoms.set(key, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(`${this.name}:${String(key)}`, value));
            });
        }
        return this;
    }
    /**
   * Updates an existing value using an updater function.
   *
   * @param key - The key of the value to update
   * @param updater - A function that receives the current value and returns the new value
   * @throws Error if the key doesn't exist in the map
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('count', 5)
   * map.update('count', count => count + 1) // count is now 6
   * ```
   */ update(key, updater) {
        const valueAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (!valueAtom) {
            throw new Error(`AtomMap: key ${key} not found`);
        }
        const value = valueAtom.__unsafe__getWithoutCapture();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(value !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
        valueAtom.set(updater(value));
    }
    /**
   * Removes a key-value pair from the map.
   *
   * @param key - The key to remove
   * @returns True if the key existed and was removed, false if it didn't exist
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('temp', 'value')
   * console.log(map.delete('temp')) // true
   * console.log(map.delete('missing')) // false
   * ```
   */ delete(key) {
        const valueAtom = this.atoms.__unsafe__getWithoutCapture().get(key);
        if (!valueAtom) {
            return false;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            valueAtom.set(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
            this.atoms.update((atoms)=>{
                return atoms.delete(key);
            });
        });
        return true;
    }
    /**
   * Removes multiple key-value pairs from the map in a single transaction.
   *
   * @param keys - An iterable of keys to remove
   * @returns An array of [key, value] pairs that were actually deleted
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('a', 1).set('b', 2).set('c', 3)
   * const deleted = map.deleteMany(['a', 'c', 'missing'])
   * console.log(deleted) // [['a', 1], ['c', 3]]
   * ```
   */ deleteMany(keys) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            const deleted = [];
            const newAtoms = this.atoms.get().withMutations((atoms)=>{
                for (const key of keys){
                    const valueAtom = atoms.get(key);
                    if (!valueAtom) continue;
                    const oldValue = valueAtom.get();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(oldValue !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
                    deleted.push([
                        key,
                        oldValue
                    ]);
                    atoms.delete(key);
                    valueAtom.set(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
                }
            });
            if (deleted.length) {
                this.atoms.set(newAtoms);
            }
            return deleted;
        });
    }
    /**
   * Removes all key-value pairs from the map.
   *
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('a', 1).set('b', 2)
   * map.clear()
   * console.log(map.size) // 0
   * ```
   */ clear() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            for (const valueAtom of this.atoms.__unsafe__getWithoutCapture().values()){
                valueAtom.set(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
            }
            this.atoms.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$ImmutableMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyMap"])());
        });
    }
    /**
   * Returns an iterator that yields [key, value] pairs for each entry in the map.
   * This method is reactive and will cause reactive contexts to update when entries change.
   *
   * @returns A generator that yields [key, value] tuples
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('a', 1).set('b', 2)
   * for (const [key, value] of map.entries()) {
   *   console.log(`${key}: ${value}`)
   * }
   * ```
   */ *entries() {
        for (const [key, valueAtom] of this.atoms.get()){
            const value = valueAtom.get();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(value !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
            yield [
                key,
                value
            ];
        }
    }
    /**
   * Returns an iterator that yields all keys in the map.
   * This method is reactive and will cause reactive contexts to update when keys change.
   *
   * @returns A generator that yields keys
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('name', 'Alice').set('age', 30)
   * for (const key of map.keys()) {
   *   console.log(key) // 'name', 'age'
   * }
   * ```
   */ *keys() {
        for (const key of this.atoms.get().keys()){
            yield key;
        }
    }
    /**
   * Returns an iterator that yields all values in the map.
   * This method is reactive and will cause reactive contexts to update when values change.
   *
   * @returns A generator that yields values
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('name', 'Alice').set('age', 30)
   * for (const value of map.values()) {
   *   console.log(value) // 'Alice', 30
   * }
   * ```
   */ *values() {
        for (const valueAtom of this.atoms.get().values()){
            const value = valueAtom.get();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(value !== __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNINITIALIZED"]);
            yield value;
        }
    }
    /**
   * The number of key-value pairs in the map.
   * This property is reactive and will cause reactive contexts to update when the size changes.
   *
   * @returns The number of entries in the map
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * console.log(map.size) // 0
   * map.set('a', 1)
   * console.log(map.size) // 1
   * ```
   */ // eslint-disable-next-line no-restricted-syntax
    get size() {
        return this.atoms.get().size;
    }
    /**
   * Executes a provided function once for each key-value pair in the map.
   * This method is reactive and will cause reactive contexts to update when entries change.
   *
   * @param callbackfn - Function to execute for each entry
   *   - value - The value of the current entry
   *   - key - The key of the current entry
   *   - map - The AtomMap being traversed
   * @param thisArg - Value to use as `this` when executing the callback
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('a', 1).set('b', 2)
   * map.forEach((value, key) => {
   *   console.log(`${key} = ${value}`)
   * })
   * ```
   */ forEach(callbackfn, thisArg) {
        for (const [key, value] of this.entries()){
            callbackfn.call(thisArg, value, key, this);
        }
    }
    /**
   * Returns the default iterator for the map, which is the same as entries().
   * This allows the map to be used in for...of loops and other iterable contexts.
   *
   * @returns The same iterator as entries()
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * map.set('a', 1).set('b', 2)
   *
   * // These are equivalent:
   * for (const [key, value] of map) {
   *   console.log(`${key}: ${value}`)
   * }
   *
   * for (const [key, value] of map.entries()) {
   *   console.log(`${key}: ${value}`)
   * }
   * ```
   */ [Symbol.iterator]() {
        return this.entries();
    }
    /**
   * The string tag used by Object.prototype.toString for this class.
   *
   * @example
   * ```ts
   * const map = new AtomMap('myMap')
   * console.log(Object.prototype.toString.call(map)) // '[object AtomMap]'
   * ```
   */ [Symbol.toStringTag] = "AtomMap";
}
;
 //# sourceMappingURL=AtomMap.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomSet.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AtomSet",
    ()=>AtomSet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)");
;
class AtomSet {
    constructor(name, keys){
        this.name = name;
        const entries = keys ? Array.from(keys, (k)=>[
                k,
                k
            ]) : void 0;
        this.map = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomMap"](name, entries);
    }
    map;
    add(value) {
        this.map.set(value, value);
        return this;
    }
    clear() {
        this.map.clear();
    }
    delete(value) {
        return this.map.delete(value);
    }
    forEach(callbackfn, thisArg) {
        for (const value of this){
            callbackfn.call(thisArg, value, value, this);
        }
    }
    has(value) {
        return this.map.has(value);
    }
    // eslint-disable-next-line no-restricted-syntax
    get size() {
        return this.map.size;
    }
    entries() {
        return this.map.entries();
    }
    keys() {
        return this.map.keys();
    }
    values() {
        return this.map.keys();
    }
    [Symbol.iterator]() {
        return this.map.keys();
    }
    [Symbol.toStringTag] = "AtomSet";
}
;
 //# sourceMappingURL=AtomSet.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/isDev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isDev",
    ()=>isDev
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/isDev.mjs")}`;
    }
};
let _isDev = false;
try {
    _isDev = ("TURBOPACK compile-time value", "development") === "development" || ("TURBOPACK compile-time value", "development") === "test";
} catch (_e) {}
try {
    _isDev = _isDev || __TURBOPACK__import$2e$meta__.env.DEV || __TURBOPACK__import$2e$meta__.env.TEST || __TURBOPACK__import$2e$meta__.env.MODE === "development" || __TURBOPACK__import$2e$meta__.env.MODE === "test";
} catch (_e) {}
function isDev() {
    return _isDev;
}
;
 //# sourceMappingURL=isDev.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/devFreeze.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "devFreeze",
    ()=>devFreeze
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$isDev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/isDev.mjs [app-client] (ecmascript)");
;
;
function devFreeze(object) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$isDev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDev"])()) return object;
    const proto = Object.getPrototypeOf(object);
    if (proto && !(Array.isArray(object) || proto === Object.prototype || proto === null || proto === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STRUCTURED_CLONE_OBJECT_PROTOTYPE"])) {
        console.error("cannot include non-js data in a record", object);
        throw new Error("cannot include non-js data in a record");
    }
    if (Object.isFrozen(object)) {
        return object;
    }
    const propNames = Object.getOwnPropertyNames(object);
    for (const name of propNames){
        const value = object[name];
        if (value && typeof value === "object") {
            devFreeze(value);
        }
    }
    return Object.freeze(object);
}
;
 //# sourceMappingURL=devFreeze.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/IncrementalSetConstructor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IncrementalSetConstructor",
    ()=>IncrementalSetConstructor
]);
class IncrementalSetConstructor {
    constructor(previousValue){
        this.previousValue = previousValue;
    }
    /**
   * The next value of the set.
   *
   * @internal
   */ nextValue;
    /**
   * The diff of the set.
   *
   * @internal
   */ diff;
    /**
   * Gets the result of the incremental set construction if any changes were made.
   * Returns undefined if no additions or removals occurred.
   *
   * @returns An object containing the final set value and the diff of changes,
   * or undefined if no changes were made
   *
   * @example
   * ```ts
   * const constructor = new IncrementalSetConstructor(new Set(['a', 'b']))
   * constructor.add('c')
   *
   * const result = constructor.get()
   * // result = {
   * //   value: Set(['a', 'b', 'c']),
   * //   diff: { added: Set(['c']) }
   * // }
   * ```
   *
   * @public
   */ get() {
        const numRemoved = this.diff?.removed?.size ?? 0;
        const numAdded = this.diff?.added?.size ?? 0;
        if (numRemoved === 0 && numAdded === 0) {
            return void 0;
        }
        return {
            value: this.nextValue,
            diff: this.diff
        };
    }
    /**
   * Add an item to the set.
   *
   * @param item - The item to add.
   * @param wasAlreadyPresent - Whether the item was already present in the set.
   * @internal
   */ _add(item, wasAlreadyPresent) {
        this.nextValue ??= new Set(this.previousValue);
        this.nextValue.add(item);
        this.diff ??= {};
        if (wasAlreadyPresent) {
            this.diff.removed?.delete(item);
        } else {
            this.diff.added ??= /* @__PURE__ */ new Set();
            this.diff.added.add(item);
        }
    }
    /**
   * Adds an item to the set. If the item was already present in the original set
   * and was previously removed during this construction, it will be restored.
   * If the item is already present and wasn't removed, this is a no-op.
   *
   * @param item - The item to add to the set
   *
   * @example
   * ```ts
   * const constructor = new IncrementalSetConstructor(new Set(['a', 'b']))
   * constructor.add('c') // Adds new item
   * constructor.add('a') // No-op, already present
   * constructor.remove('b')
   * constructor.add('b') // Restores previously removed item
   * ```
   *
   * @public
   */ add(item) {
        const wasAlreadyPresent = this.previousValue.has(item);
        if (wasAlreadyPresent) {
            const wasRemoved = this.diff?.removed?.has(item);
            if (!wasRemoved) return;
            return this._add(item, wasAlreadyPresent);
        }
        const isCurrentlyPresent = this.nextValue?.has(item);
        if (isCurrentlyPresent) return;
        this._add(item, wasAlreadyPresent);
    }
    /**
   * Remove an item from the set.
   *
   * @param item - The item to remove.
   * @param wasAlreadyPresent - Whether the item was already present in the set.
   * @internal
   */ _remove(item, wasAlreadyPresent) {
        this.nextValue ??= new Set(this.previousValue);
        this.nextValue.delete(item);
        this.diff ??= {};
        if (wasAlreadyPresent) {
            this.diff.removed ??= /* @__PURE__ */ new Set();
            this.diff.removed.add(item);
        } else {
            this.diff.added?.delete(item);
        }
    }
    /**
   * Removes an item from the set. If the item wasn't present in the original set
   * and was added during this construction, it will be removed from the added diff.
   * If the item is not present at all, this is a no-op.
   *
   * @param item - The item to remove from the set
   *
   * @example
   * ```ts
   * const constructor = new IncrementalSetConstructor(new Set(['a', 'b']))
   * constructor.remove('a') // Removes existing item
   * constructor.remove('c') // No-op, not present
   * constructor.add('d')
   * constructor.remove('d') // Removes recently added item
   * ```
   *
   * @public
   */ remove(item) {
        const wasAlreadyPresent = this.previousValue.has(item);
        if (!wasAlreadyPresent) {
            const wasAdded = this.diff?.added?.has(item);
            if (!wasAdded) return;
            return this._remove(item, wasAlreadyPresent);
        }
        const hasAlreadyBeenRemoved = this.diff?.removed?.has(item);
        if (hasAlreadyBeenRemoved) return;
        this._remove(item, wasAlreadyPresent);
    }
}
;
 //# sourceMappingURL=IncrementalSetConstructor.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MigrationFailureReason",
    ()=>MigrationFailureReason,
    "createMigrationIds",
    ()=>createMigrationIds,
    "createMigrationSequence",
    ()=>createMigrationSequence,
    "createRecordMigrationSequence",
    ()=>createRecordMigrationSequence,
    "parseMigrationId",
    ()=>parseMigrationId,
    "sortMigrations",
    ()=>sortMigrations,
    "validateMigrations",
    ()=>validateMigrations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
function squashDependsOn(sequence) {
    const result = [];
    for(let i = sequence.length - 1; i >= 0; i--){
        const elem = sequence[i];
        if (!("id" in elem)) {
            const dependsOn = elem.dependsOn;
            const prev = result[0];
            if (prev) {
                result[0] = {
                    ...prev,
                    dependsOn: dependsOn.concat(prev.dependsOn ?? [])
                };
            }
        } else {
            result.unshift(elem);
        }
    }
    return result;
}
function createMigrationSequence({ sequence, sequenceId, retroactive = true }) {
    const migrations = {
        sequenceId,
        retroactive,
        sequence: squashDependsOn(sequence)
    };
    validateMigrations(migrations);
    return migrations;
}
function createMigrationIds(sequenceId, versions) {
    return Object.fromEntries((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(versions).map(([key, version])=>[
            key,
            `${sequenceId}/${version}`
        ]));
}
function createRecordMigrationSequence(opts) {
    const sequenceId = opts.sequenceId;
    return createMigrationSequence({
        sequenceId,
        retroactive: opts.retroactive ?? true,
        sequence: opts.sequence.map((m)=>"id" in m ? {
                ...m,
                scope: "record",
                filter: (r)=>r.typeName === opts.recordType && (m.filter?.(r) ?? true) && (opts.filter?.(r) ?? true)
            } : m)
    });
}
function sortMigrations(migrations) {
    if (migrations.length === 0) return [];
    const byId = new Map(migrations.map((m)=>[
            m.id,
            m
        ]));
    const dependents = /* @__PURE__ */ new Map();
    const inDegree = /* @__PURE__ */ new Map();
    const explicitDeps = /* @__PURE__ */ new Map();
    for (const m of migrations){
        inDegree.set(m.id, 0);
        dependents.set(m.id, /* @__PURE__ */ new Set());
        explicitDeps.set(m.id, /* @__PURE__ */ new Set());
    }
    for (const m of migrations){
        const { version, sequenceId } = parseMigrationId(m.id);
        const prevId = `${sequenceId}/${version - 1}`;
        if (byId.has(prevId)) {
            dependents.get(prevId).add(m.id);
            inDegree.set(m.id, inDegree.get(m.id) + 1);
        }
        if (m.dependsOn) {
            for (const depId of m.dependsOn){
                if (byId.has(depId)) {
                    dependents.get(depId).add(m.id);
                    explicitDeps.get(m.id).add(depId);
                    inDegree.set(m.id, inDegree.get(m.id) + 1);
                }
            }
        }
    }
    const ready = migrations.filter((m)=>inDegree.get(m.id) === 0);
    const result = [];
    const processed = /* @__PURE__ */ new Set();
    while(ready.length > 0){
        let bestCandidate;
        let bestCandidateScore = -Infinity;
        for (const m of ready){
            let urgencyScore = 0;
            for (const depId of dependents.get(m.id) || []){
                if (!processed.has(depId)) {
                    urgencyScore += 1;
                    if (explicitDeps.get(depId).has(m.id)) {
                        urgencyScore += 100;
                    }
                }
            }
            if (urgencyScore > bestCandidateScore || // Tiebreaker: prefer lower sequence/version
            urgencyScore === bestCandidateScore && m.id.localeCompare(bestCandidate?.id ?? "") < 0) {
                bestCandidate = m;
                bestCandidateScore = urgencyScore;
            }
        }
        const nextMigration = bestCandidate;
        ready.splice(ready.indexOf(nextMigration), 1);
        result.push(nextMigration);
        processed.add(nextMigration.id);
        for (const depId of dependents.get(nextMigration.id) || []){
            if (!processed.has(depId)) {
                inDegree.set(depId, inDegree.get(depId) - 1);
                if (inDegree.get(depId) === 0) {
                    ready.push(byId.get(depId));
                }
            }
        }
    }
    if (result.length !== migrations.length) {
        const unprocessed = migrations.filter((m)=>!processed.has(m.id));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(false, `Circular dependency in migrations: ${unprocessed[0].id}`);
    }
    return result;
}
function parseMigrationId(id) {
    const [sequenceId, version] = id.split("/");
    return {
        sequenceId,
        version: parseInt(version)
    };
}
function validateMigrationId(id, expectedSequenceId) {
    if (expectedSequenceId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(id.startsWith(expectedSequenceId + "/"), `Every migration in sequence '${expectedSequenceId}' must have an id starting with '${expectedSequenceId}/'. Got invalid id: '${id}'`);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(id.match(/^(.*?)\/(0|[1-9]\d*)$/), `Invalid migration id: '${id}'`);
}
function validateMigrations(migrations) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(!migrations.sequenceId.includes("/"), `sequenceId cannot contain a '/', got ${migrations.sequenceId}`);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(migrations.sequenceId.length, "sequenceId must be a non-empty string");
    if (migrations.sequence.length === 0) {
        return;
    }
    validateMigrationId(migrations.sequence[0].id, migrations.sequenceId);
    let n = parseMigrationId(migrations.sequence[0].id).version;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(n === 1, `Expected the first migrationId to be '${migrations.sequenceId}/1' but got '${migrations.sequence[0].id}'`);
    for(let i = 1; i < migrations.sequence.length; i++){
        const id = migrations.sequence[i].id;
        validateMigrationId(id, migrations.sequenceId);
        const m = parseMigrationId(id).version;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(m === n + 1, `Migration id numbers must increase in increments of 1, expected ${migrations.sequenceId}/${n + 1} but got '${migrations.sequence[i].id}'`);
        n = m;
    }
}
var MigrationFailureReason = /* @__PURE__ */ ((MigrationFailureReason2)=>{
    MigrationFailureReason2["IncompatibleSubtype"] = "incompatible-subtype";
    MigrationFailureReason2["UnknownType"] = "unknown-type";
    MigrationFailureReason2["TargetVersionTooNew"] = "target-version-too-new";
    MigrationFailureReason2["TargetVersionTooOld"] = "target-version-too-old";
    MigrationFailureReason2["MigrationError"] = "migration-error";
    MigrationFailureReason2["UnrecognizedSubtype"] = "unrecognized-subtype";
    return MigrationFailureReason2;
})(MigrationFailureReason || {});
;
 //# sourceMappingURL=migrate.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEmptyRecordsDiff",
    ()=>createEmptyRecordsDiff,
    "isRecordsDiffEmpty",
    ()=>isRecordsDiffEmpty,
    "reverseRecordsDiff",
    ()=>reverseRecordsDiff,
    "squashRecordDiffs",
    ()=>squashRecordDiffs,
    "squashRecordDiffsMutable",
    ()=>squashRecordDiffsMutable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
function createEmptyRecordsDiff() {
    return {
        added: {},
        updated: {},
        removed: {}
    };
}
function reverseRecordsDiff(diff) {
    const result = {
        added: diff.removed,
        removed: diff.added,
        updated: {}
    };
    for (const [from, to] of Object.values(diff.updated)){
        result.updated[from.id] = [
            to,
            from
        ];
    }
    return result;
}
function isRecordsDiffEmpty(diff) {
    return Object.keys(diff.added).length === 0 && Object.keys(diff.updated).length === 0 && Object.keys(diff.removed).length === 0;
}
function squashRecordDiffs(diffs, options) {
    const result = options?.mutateFirstDiff ? diffs[0] : {
        added: {},
        removed: {},
        updated: {}
    };
    squashRecordDiffsMutable(result, options?.mutateFirstDiff ? diffs.slice(1) : diffs);
    return result;
}
function squashRecordDiffsMutable(target, diffs) {
    for (const diff of diffs){
        for (const [id, value] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(diff.added)){
            if (target.removed[id]) {
                const original = target.removed[id];
                delete target.removed[id];
                if (original !== value) {
                    target.updated[id] = [
                        original,
                        value
                    ];
                }
            } else {
                target.added[id] = value;
            }
        }
        for (const [id, [_from, to]] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(diff.updated)){
            if (target.added[id]) {
                target.added[id] = to;
                delete target.updated[id];
                delete target.removed[id];
                continue;
            }
            if (target.updated[id]) {
                target.updated[id] = [
                    target.updated[id][0],
                    to
                ];
                delete target.removed[id];
                continue;
            }
            target.updated[id] = diff.updated[id];
            delete target.removed[id];
        }
        for (const [id, value] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(diff.removed)){
            if (target.added[id]) {
                delete target.added[id];
            } else if (target.updated[id]) {
                target.removed[id] = target.updated[id][0];
                delete target.updated[id];
            } else {
                target.removed[id] = value;
            }
        }
    }
}
;
 //# sourceMappingURL=RecordsDiff.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecordType",
    ()=>RecordType,
    "assertIdType",
    ()=>assertIdType,
    "createRecordType",
    ()=>createRecordType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
;
class RecordType {
    /**
   * Creates a new RecordType instance.
   *
   * typeName - The unique type name for records created by this RecordType
   * config - Configuration object for the RecordType
   *   - createDefaultProperties - Function that returns default properties for new records
   *   - validator - Optional validator function for record validation
   *   - scope - Optional scope determining persistence behavior (defaults to 'document')
   *   - ephemeralKeys - Optional mapping of property names to ephemeral status
   * @public
   */ constructor(typeName, config){
        this.typeName = typeName;
        this.createDefaultProperties = config.createDefaultProperties;
        this.validator = config.validator ?? {
            validate: (r)=>r
        };
        this.scope = config.scope ?? "document";
        this.ephemeralKeys = config.ephemeralKeys;
        const ephemeralKeySet = /* @__PURE__ */ new Set();
        if (config.ephemeralKeys) {
            for (const [key, isEphemeral] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(config.ephemeralKeys)){
                if (isEphemeral) ephemeralKeySet.add(key);
            }
        }
        this.ephemeralKeySet = ephemeralKeySet;
    }
    /**
   * Factory function that creates default properties for new records.
   * @public
   */ createDefaultProperties;
    /**
   * Validator function used to validate records of this type.
   * @public
   */ validator;
    /**
   * Optional configuration specifying which record properties are ephemeral.
   * Ephemeral properties are not included in snapshots or synchronization.
   * @public
   */ ephemeralKeys;
    /**
   * Set of property names that are marked as ephemeral for efficient lookup.
   * @public
   */ ephemeralKeySet;
    /**
   * The scope that determines how records of this type are persisted and synchronized.
   * @public
   */ scope;
    /**
   * Creates a new record of this type with the given properties.
   *
   * Properties are merged with default properties from the RecordType configuration.
   * If no id is provided, a unique id will be generated automatically.
   *
   * @example
   * ```ts
   * const book = Book.create({
   *   title: 'The Great Gatsby',
   *   author: 'F. Scott Fitzgerald'
   * })
   * // Result: { id: 'book:abc123', typeName: 'book', title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', inStock: true }
   * ```
   *
   * @param properties - The properties for the new record, including both required and optional fields
   * @returns The newly created record with generated id and typeName
   * @public
   */ create(properties) {
        const result = {
            ...this.createDefaultProperties(),
            id: "id" in properties ? properties.id : this.createId()
        };
        for (const [k, v] of Object.entries(properties)){
            if (v !== void 0) {
                result[k] = v;
            }
        }
        result.typeName = this.typeName;
        return result;
    }
    /**
   * Creates a deep copy of an existing record with a new unique id.
   *
   * This method performs a deep clone of all properties while generating a fresh id,
   * making it useful for duplicating records without id conflicts.
   *
   * @example
   * ```ts
   * const originalBook = Book.create({ title: '1984', author: 'George Orwell' })
   * const duplicatedBook = Book.clone(originalBook)
   * // duplicatedBook has same properties but different id
   * ```
   *
   * @param record - The record to clone
   * @returns A new record with the same properties but a different id
   * @public
   */ clone(record) {
        return {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(record),
            id: this.createId()
        };
    }
    /**
   * Create a new ID for this record type.
   *
   * @example
   *
   * ```ts
   * const id = recordType.createId()
   * ```
   *
   * @returns The new ID.
   * @public
   */ createId(customUniquePart) {
        return this.typeName + ":" + (customUniquePart ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])());
    }
    /**
   * Extracts the unique identifier part from a full record id.
   *
   * Record ids have the format `typeName:uniquePart`. This method returns just the unique part.
   *
   * @example
   * ```ts
   * const bookId = Book.createId() // 'book:abc123'
   * const uniquePart = Book.parseId(bookId) // 'abc123'
   * ```
   *
   * @param id - The full record id to parse
   * @returns The unique identifier portion after the colon
   * @throws Error if the id is not valid for this record type
   * @public
   */ parseId(id) {
        if (!this.isId(id)) {
            throw new Error(`ID "${id}" is not a valid ID for type "${this.typeName}"`);
        }
        return id.slice(this.typeName.length + 1);
    }
    /**
   * Type guard that checks whether a record belongs to this RecordType.
   *
   * This method performs a runtime check by comparing the record's typeName
   * against this RecordType's typeName.
   *
   * @example
   * ```ts
   * if (Book.isInstance(someRecord)) {
   *   // someRecord is now typed as a book record
   *   console.log(someRecord.title)
   * }
   * ```
   *
   * @param record - The record to check, may be undefined
   * @returns True if the record is an instance of this record type
   * @public
   */ isInstance(record) {
        return record?.typeName === this.typeName;
    }
    /**
   * Type guard that checks whether an id string belongs to this RecordType.
   *
   * Validates that the id starts with this RecordType's typeName followed by a colon.
   * This is more efficient than parsing the full id when you only need to verify the type.
   *
   * @example
   * ```ts
   * if (Book.isId(someId)) {
   *   // someId is now typed as IdOf<BookRecord>
   *   const book = store.get(someId)
   * }
   * ```
   *
   * @param id - The id string to check, may be undefined
   * @returns True if the id belongs to this record type
   * @public
   */ isId(id) {
        if (!id) return false;
        for(let i = 0; i < this.typeName.length; i++){
            if (id[i] !== this.typeName[i]) return false;
        }
        return id[this.typeName.length] === ":";
    }
    /**
   * Create a new RecordType that has the same type name as this RecordType and includes the given
   * default properties.
   *
   * @example
   *
   * ```ts
   * const authorType = createRecordType('author', () => ({ living: true }))
   * const deadAuthorType = authorType.withDefaultProperties({ living: false })
   * ```
   *
   * @param createDefaultProperties - A function that returns the default properties of the new RecordType.
   * @returns The new RecordType.
   */ withDefaultProperties(createDefaultProperties) {
        return new RecordType(this.typeName, {
            createDefaultProperties,
            validator: this.validator,
            scope: this.scope,
            ephemeralKeys: this.ephemeralKeys
        });
    }
    /**
   * Validates a record against this RecordType's validator and returns it with proper typing.
   *
   * This method runs the configured validator function and throws an error if validation fails.
   * If a previous version of the record is provided, it may use optimized validation.
   *
   * @example
   * ```ts
   * try {
   *   const validBook = Book.validate(untrustedData)
   *   // validBook is now properly typed and validated
   * } catch (error) {
   *   console.log('Validation failed:', error.message)
   * }
   * ```
   *
   * @param record - The unknown record data to validate
   * @param recordBefore - Optional previous version for optimized validation
   * @returns The validated and properly typed record
   * @throws Error if validation fails
   * @public
   */ validate(record, recordBefore) {
        if (recordBefore && this.validator.validateUsingKnownGoodVersion) {
            return this.validator.validateUsingKnownGoodVersion(recordBefore, record);
        }
        return this.validator.validate(record);
    }
}
function createRecordType(typeName, config) {
    return new RecordType(typeName, {
        createDefaultProperties: ()=>({}),
        validator: config.validator,
        scope: config.scope,
        ephemeralKeys: config.ephemeralKeys
    });
}
function assertIdType(id, type) {
    if (!id || !type.isId(id)) {
        throw new Error(`string ${JSON.stringify(id)} is not a valid ${type.typeName} id`);
    }
}
;
 //# sourceMappingURL=RecordType.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/setUtils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "diffSets",
    ()=>diffSets,
    "intersectSets",
    ()=>intersectSets
]);
function intersectSets(sets) {
    if (sets.length === 0) return /* @__PURE__ */ new Set();
    const first = sets[0];
    const rest = sets.slice(1);
    const result = /* @__PURE__ */ new Set();
    for (const val of first){
        if (rest.every((set)=>set.has(val))) {
            result.add(val);
        }
    }
    return result;
}
function diffSets(prev, next) {
    const result = {};
    for (const val of next){
        if (!prev.has(val)) {
            result.added ??= /* @__PURE__ */ new Set();
            result.added.add(val);
        }
    }
    for (const val of prev){
        if (!next.has(val)) {
            result.removed ??= /* @__PURE__ */ new Set();
            result.removed.add(val);
        }
    }
    return result.added || result.removed ? result : void 0;
}
;
 //# sourceMappingURL=setUtils.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/executeQuery.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeQuery",
    ()=>executeQuery,
    "objectMatchesQuery",
    ()=>objectMatchesQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$setUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/setUtils.mjs [app-client] (ecmascript)");
;
function isQueryValueMatcher(value) {
    if (typeof value !== "object" || value === null) return false;
    return "eq" in value || "neq" in value || "gt" in value;
}
function extractMatcherPaths(query, prefix = "") {
    const paths = [];
    for (const [key, value] of Object.entries(query)){
        const currentPath = prefix ? `${prefix}\\${key}` : key;
        if (isQueryValueMatcher(value)) {
            paths.push({
                path: currentPath,
                matcher: value
            });
        } else if (typeof value === "object" && value !== null) {
            paths.push(...extractMatcherPaths(value, currentPath));
        }
    }
    return paths;
}
function objectMatchesQuery(query, object) {
    for (const [key, matcher] of Object.entries(query)){
        const value = object[key];
        if (isQueryValueMatcher(matcher)) {
            if ("eq" in matcher && value !== matcher.eq) return false;
            if ("neq" in matcher && value === matcher.neq) return false;
            if ("gt" in matcher && (typeof value !== "number" || value <= matcher.gt)) return false;
            continue;
        }
        if (typeof value !== "object" || value === null) return false;
        if (!objectMatchesQuery(matcher, value)) {
            return false;
        }
    }
    return true;
}
function executeQuery(store, typeName, query) {
    const matcherPaths = extractMatcherPaths(query);
    const matchIds = Object.fromEntries(matcherPaths.map(({ path })=>[
            path,
            /* @__PURE__ */ new Set()
        ]));
    for (const { path, matcher } of matcherPaths){
        const index = store.index(typeName, path);
        if ("eq" in matcher) {
            const ids = index.get().get(matcher.eq);
            if (ids) {
                for (const id of ids){
                    matchIds[path].add(id);
                }
            }
        } else if ("neq" in matcher) {
            for (const [value, ids] of index.get()){
                if (value !== matcher.neq) {
                    for (const id of ids){
                        matchIds[path].add(id);
                    }
                }
            }
        } else if ("gt" in matcher) {
            for (const [value, ids] of index.get()){
                if (typeof value === "number" && value > matcher.gt) {
                    for (const id of ids){
                        matchIds[path].add(id);
                    }
                }
            }
        }
        if (matchIds[path].size === 0) {
            return /* @__PURE__ */ new Set();
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$setUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectSets"])(Object.values(matchIds));
}
;
 //# sourceMappingURL=executeQuery.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreQueries.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StoreQueries",
    ()=>StoreQueries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript) <export default as isEqual>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$executeQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/executeQuery.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/IncrementalSetConstructor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$setUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/setUtils.mjs [app-client] (ecmascript)");
;
;
;
;
;
class StoreQueries {
    /**
   * Creates a new StoreQueries instance.
   *
   * recordMap - The atom map containing all records in the store
   * history - The atom tracking the store's change history with diffs
   *
   * @internal
   */ constructor(recordMap, history){
        this.recordMap = recordMap;
        this.history = history;
    }
    /**
   * A cache of derivations (indexes).
   *
   * @internal
   */ indexCache = /* @__PURE__ */ new Map();
    /**
   * A cache of derivations (filtered histories).
   *
   * @internal
   */ historyCache = /* @__PURE__ */ new Map();
    /**
   * @internal
   */ getAllIdsForType(typeName) {
        const ids = /* @__PURE__ */ new Set();
        for (const record of this.recordMap.values()){
            if (record.typeName === typeName) {
                ids.add(record.id);
            }
        }
        return ids;
    }
    /**
   * @internal
   */ getRecordById(typeName, id) {
        const record = this.recordMap.get(id);
        if (record && record.typeName === typeName) {
            return record;
        }
        return void 0;
    }
    /**
   * Helper to extract nested property value using pre-split path parts.
   * @internal
   */ getNestedValue(obj, pathParts) {
        let current = obj;
        for (const part of pathParts){
            if (current == null || typeof current !== "object") return void 0;
            current = current[part];
        }
        return current;
    }
    /**
   * Creates a reactive computed that tracks the change history for records of a specific type.
   * The returned computed provides incremental diffs showing what records of the given type
   * have been added, updated, or removed.
   *
   * @param typeName - The type name to filter the history by
   * @returns A computed value containing the current epoch and diffs of changes for the specified type
   *
   * @example
   * ```ts
   * // Track changes to book records only
   * const bookHistory = store.query.filterHistory('book')
   *
   * // React to book changes
   * react('book-changes', () => {
   *   const currentEpoch = bookHistory.get()
   *   console.log('Books updated at epoch:', currentEpoch)
   * })
   * ```
   *
   * @public
   */ filterHistory(typeName) {
        if (this.historyCache.has(typeName)) {
            return this.historyCache.get(typeName);
        }
        const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("filterHistory:" + typeName, (lastValue, lastComputedEpoch)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(lastValue)) {
                return this.history.get();
            }
            const diff = this.history.getDiffSince(lastComputedEpoch);
            if (diff === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) return this.history.get();
            const res = {
                added: {},
                removed: {},
                updated: {}
            };
            let numAdded = 0;
            let numRemoved = 0;
            let numUpdated = 0;
            for (const changes of diff){
                for (const added of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.added)){
                    if (added.typeName === typeName) {
                        if (res.removed[added.id]) {
                            const original = res.removed[added.id];
                            delete res.removed[added.id];
                            numRemoved--;
                            if (original !== added) {
                                res.updated[added.id] = [
                                    original,
                                    added
                                ];
                                numUpdated++;
                            }
                        } else {
                            res.added[added.id] = added;
                            numAdded++;
                        }
                    }
                }
                for (const [from, to] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.updated)){
                    if (to.typeName === typeName) {
                        if (res.added[to.id]) {
                            res.added[to.id] = to;
                        } else if (res.updated[to.id]) {
                            res.updated[to.id] = [
                                res.updated[to.id][0],
                                to
                            ];
                        } else {
                            res.updated[to.id] = [
                                from,
                                to
                            ];
                            numUpdated++;
                        }
                    }
                }
                for (const removed of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.removed)){
                    if (removed.typeName === typeName) {
                        if (res.added[removed.id]) {
                            delete res.added[removed.id];
                            numAdded--;
                        } else if (res.updated[removed.id]) {
                            res.removed[removed.id] = res.updated[removed.id][0];
                            delete res.updated[removed.id];
                            numUpdated--;
                            numRemoved++;
                        } else {
                            res.removed[removed.id] = removed;
                            numRemoved++;
                        }
                    }
                }
            }
            if (numAdded || numRemoved || numUpdated) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withDiff"])(this.history.get(), res);
            } else {
                return lastValue;
            }
        }, {
            historyLength: 100
        });
        this.historyCache.set(typeName, filtered);
        return filtered;
    }
    /**
   * Creates a reactive index that maps property values to sets of record IDs for efficient lookups.
   * The index automatically updates when records are added, updated, or removed, and results are cached
   * for performance.
   *
   * Supports nested property paths using backslash separator (e.g., 'metadata\\sessionId').
   *
   * @param typeName - The type name of records to index
   * @param path - The property name or backslash-delimited path to index by
   * @returns A reactive computed containing the index map with change diffs
   *
   * @example
   * ```ts
   * // Create an index of books by author ID
   * const booksByAuthor = store.query.index('book', 'authorId')
   *
   * // Get all books by a specific author
   * const authorBooks = booksByAuthor.get().get('author:leguin')
   * console.log(authorBooks) // Set<RecordId<Book>>
   *
   * // Index by nested property using backslash separator
   * const booksBySession = store.query.index('book', 'metadata\\sessionId')
   * const sessionBooks = booksBySession.get().get('session:alpha')
   * ```
   *
   * @public
   */ index(typeName, path) {
        const cacheKey = typeName + ":" + path;
        if (this.indexCache.has(cacheKey)) {
            return this.indexCache.get(cacheKey);
        }
        const index = this.__uncached_createIndex(typeName, path);
        this.indexCache.set(cacheKey, index);
        return index;
    }
    /**
   * Creates a new index without checking the cache. This method performs the actual work
   * of building the reactive index computation that tracks property values to record ID sets.
   *
   * Supports nested property paths using backslash separator.
   *
   * @param typeName - The type name of records to index
   * @param path - The property name or backslash-delimited path to index by
   * @returns A reactive computed containing the index map with change diffs
   *
   * @internal
   */ __uncached_createIndex(typeName, path) {
        const typeHistory = this.filterHistory(typeName);
        const pathParts = path.split("\\");
        const getPropertyValue = pathParts.length > 1 ? (obj)=>this.getNestedValue(obj, pathParts) : (obj)=>obj[path];
        const fromScratch = ()=>{
            typeHistory.get();
            const res = /* @__PURE__ */ new Map();
            for (const record of this.recordMap.values()){
                if (record.typeName === typeName) {
                    const value = getPropertyValue(record);
                    if (value !== void 0) {
                        if (!res.has(value)) {
                            res.set(value, /* @__PURE__ */ new Set());
                        }
                        res.get(value).add(record.id);
                    }
                }
            }
            return res;
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("index:" + typeName + ":" + path, (prevValue, lastComputedEpoch)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(prevValue)) return fromScratch();
            const history = typeHistory.getDiffSince(lastComputedEpoch);
            if (history === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
                return fromScratch();
            }
            const setConstructors = /* @__PURE__ */ new Map();
            const add = (value, id)=>{
                let setConstructor = setConstructors.get(value);
                if (!setConstructor) setConstructor = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IncrementalSetConstructor"](prevValue.get(value) ?? /* @__PURE__ */ new Set());
                setConstructor.add(id);
                setConstructors.set(value, setConstructor);
            };
            const remove = (value, id)=>{
                let set = setConstructors.get(value);
                if (!set) set = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IncrementalSetConstructor"](prevValue.get(value) ?? /* @__PURE__ */ new Set());
                set.remove(id);
                setConstructors.set(value, set);
            };
            for (const changes of history){
                for (const record of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.added)){
                    if (record.typeName === typeName) {
                        const value = getPropertyValue(record);
                        if (value !== void 0) {
                            add(value, record.id);
                        }
                    }
                }
                for (const [from, to] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.updated)){
                    if (to.typeName === typeName) {
                        const prev = getPropertyValue(from);
                        const next = getPropertyValue(to);
                        if (prev !== next) {
                            if (prev !== void 0) {
                                remove(prev, to.id);
                            }
                            if (next !== void 0) {
                                add(next, to.id);
                            }
                        }
                    }
                }
                for (const record of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.removed)){
                    if (record.typeName === typeName) {
                        const value = getPropertyValue(record);
                        if (value !== void 0) {
                            remove(value, record.id);
                        }
                    }
                }
            }
            let nextValue = void 0;
            let nextDiff = void 0;
            for (const [value, setConstructor] of setConstructors){
                const result = setConstructor.get();
                if (!result) continue;
                if (!nextValue) nextValue = new Map(prevValue);
                if (!nextDiff) nextDiff = /* @__PURE__ */ new Map();
                if (result.value.size === 0) {
                    nextValue.delete(value);
                } else {
                    nextValue.set(value, result.value);
                }
                nextDiff.set(value, result.diff);
            }
            if (nextValue && nextDiff) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withDiff"])(nextValue, nextDiff);
            }
            return prevValue;
        }, {
            historyLength: 100
        });
    }
    /**
   * Creates a reactive query that returns the first record matching the given query criteria.
   * Returns undefined if no matching record is found. The query automatically updates
   * when records change.
   *
   * @param typeName - The type name of records to query
   * @param queryCreator - Function that returns the query expression object to match against
   * @param name - Optional name for the query computation (used for debugging)
   * @returns A computed value containing the first matching record or undefined
   *
   * @example
   * ```ts
   * // Find the first book with a specific title
   * const bookLatheOfHeaven = store.query.record('book', () => ({ title: { eq: 'The Lathe of Heaven' } }))
   * console.log(bookLatheOfHeaven.get()?.title) // 'The Lathe of Heaven' or undefined
   *
   * // Find any book in stock
   * const anyInStockBook = store.query.record('book', () => ({ inStock: { eq: true } }))
   * ```
   *
   * @public
   */ record(typeName, queryCreator = ()=>({}), name = "record:" + typeName + (queryCreator ? ":" + queryCreator.toString() : "")) {
        const ids = this.ids(typeName, queryCreator, name);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])(name, ()=>{
            for (const id of ids.get()){
                return this.recordMap.get(id);
            }
            return void 0;
        });
    }
    /**
   * Creates a reactive query that returns an array of all records matching the given query criteria.
   * The array automatically updates when records are added, updated, or removed.
   *
   * @param typeName - The type name of records to query
   * @param queryCreator - Function that returns the query expression object to match against
   * @param name - Optional name for the query computation (used for debugging)
   * @returns A computed value containing an array of all matching records
   *
   * @example
   * ```ts
   * // Get all books in stock
   * const inStockBooks = store.query.records('book', () => ({ inStock: { eq: true } }))
   * console.log(inStockBooks.get()) // Book[]
   *
   * // Get all books by a specific author
   * const leguinBooks = store.query.records('book', () => ({ authorId: { eq: 'author:leguin' } }))
   *
   * // Get all books (no filter)
   * const allBooks = store.query.records('book')
   * ```
   *
   * @public
   */ records(typeName, queryCreator = ()=>({}), name = "records:" + typeName + (queryCreator ? ":" + queryCreator.toString() : "")) {
        const ids = this.ids(typeName, queryCreator, "ids:" + name);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])(name, ()=>{
            return Array.from(ids.get(), (id)=>this.recordMap.get(id));
        }, {
            isEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysShallowEqual"]
        });
    }
    /**
   * Creates a reactive query that returns a set of record IDs matching the given query criteria.
   * This is more efficient than `records()` when you only need the IDs and not the full record objects.
   * The set automatically updates with collection diffs when records change.
   *
   * @param typeName - The type name of records to query
   * @param queryCreator - Function that returns the query expression object to match against
   * @param name - Optional name for the query computation (used for debugging)
   * @returns A computed value containing a set of matching record IDs with collection diffs
   *
   * @example
   * ```ts
   * // Get IDs of all books in stock
   * const inStockBookIds = store.query.ids('book', () => ({ inStock: { eq: true } }))
   * console.log(inStockBookIds.get()) // Set<RecordId<Book>>
   *
   * // Get all book IDs (no filter)
   * const allBookIds = store.query.ids('book')
   *
   * // Use with other queries for efficient lookups
   * const authorBookIds = store.query.ids('book', () => ({ authorId: { eq: 'author:leguin' } }))
   * ```
   *
   * @public
   */ ids(typeName, queryCreator = ()=>({}), name = "ids:" + typeName + (queryCreator ? ":" + queryCreator.toString() : "")) {
        const typeHistory = this.filterHistory(typeName);
        const fromScratch = ()=>{
            typeHistory.get();
            const query = queryCreator();
            if (Object.keys(query).length === 0) {
                return this.getAllIdsForType(typeName);
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$executeQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeQuery"])(this, typeName, query);
        };
        const fromScratchWithDiff = (prevValue)=>{
            const nextValue = fromScratch();
            const diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$setUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["diffSets"])(prevValue, nextValue);
            if (diff) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withDiff"])(nextValue, diff);
            } else {
                return prevValue;
            }
        };
        const cachedQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("ids_query:" + name, queryCreator, {
            isEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"]
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("query:" + name, (prevValue, lastComputedEpoch)=>{
            const query = cachedQuery.get();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(prevValue)) {
                return fromScratch();
            }
            if (lastComputedEpoch < cachedQuery.lastChangedEpoch) {
                return fromScratchWithDiff(prevValue);
            }
            const history = typeHistory.getDiffSince(lastComputedEpoch);
            if (history === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
                return fromScratchWithDiff(prevValue);
            }
            const setConstructor = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IncrementalSetConstructor"](prevValue);
            for (const changes of history){
                for (const added of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.added)){
                    if (added.typeName === typeName && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$executeQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMatchesQuery"])(query, added)) {
                        setConstructor.add(added.id);
                    }
                }
                for (const [_, updated] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.updated)){
                    if (updated.typeName === typeName) {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$executeQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMatchesQuery"])(query, updated)) {
                            setConstructor.add(updated.id);
                        } else {
                            setConstructor.remove(updated.id);
                        }
                    }
                }
                for (const removed of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.removed)){
                    if (removed.typeName === typeName) {
                        setConstructor.remove(removed.id);
                    }
                }
            }
            const result = setConstructor.get();
            if (!result) {
                return prevValue;
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withDiff"])(result.value, result.diff);
        }, {
            historyLength: 50
        });
    }
    /**
   * Executes a one-time query against the current store state and returns matching records.
   * This is a non-reactive query that returns results immediately without creating a computed value.
   * Use this when you need a snapshot of data at a specific point in time.
   *
   * @param typeName - The type name of records to query
   * @param query - The query expression object to match against
   * @returns An array of records that match the query at the current moment
   *
   * @example
   * ```ts
   * // Get current in-stock books (non-reactive)
   * const currentInStockBooks = store.query.exec('book', { inStock: { eq: true } })
   * console.log(currentInStockBooks) // Book[]
   *
   * // Unlike records(), this won't update when the data changes
   * const staticBookList = store.query.exec('book', { authorId: { eq: 'author:leguin' } })
   * ```
   *
   * @public
   */ exec(typeName, query) {
        const ids = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$executeQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeQuery"])(this, typeName, query);
        if (ids.size === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
        }
        return Array.from(ids, (id)=>this.recordMap.get(id));
    }
}
;
 //# sourceMappingURL=StoreQueries.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSideEffects.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StoreSideEffects",
    ()=>StoreSideEffects
]);
class StoreSideEffects {
    /**
   * Creates a new side effects manager for the given store.
   *
   * store - The store instance to manage side effects for
   */ constructor(store){
        this.store = store;
    }
    _beforeCreateHandlers = {};
    _afterCreateHandlers = {};
    _beforeChangeHandlers = {};
    _afterChangeHandlers = {};
    _beforeDeleteHandlers = {};
    _afterDeleteHandlers = {};
    _operationCompleteHandlers = [];
    _isEnabled = true;
    /**
   * Checks whether side effects are currently enabled.
   * When disabled, all side effect handlers are bypassed.
   *
   * @returns `true` if side effects are enabled, `false` otherwise
   * @internal
   */ isEnabled() {
        return this._isEnabled;
    }
    /**
   * Enables or disables side effects processing.
   * When disabled, no side effect handlers will be called.
   *
   * @param enabled - Whether to enable or disable side effects
   * @internal
   */ setIsEnabled(enabled) {
        this._isEnabled = enabled;
    }
    /**
   * Processes all registered 'before create' handlers for a record.
   * Handlers are called in registration order and can transform the record.
   *
   * @param record - The record about to be created
   * @param source - Whether the change originated from 'user' or 'remote'
   * @returns The potentially modified record to actually create
   * @internal
   */ handleBeforeCreate(record, source) {
        if (!this._isEnabled) return record;
        const handlers = this._beforeCreateHandlers[record.typeName];
        if (handlers) {
            let r = record;
            for (const handler of handlers){
                r = handler(r, source);
            }
            return r;
        }
        return record;
    }
    /**
   * Processes all registered 'after create' handlers for a record.
   * Handlers are called in registration order after the record is created.
   *
   * @param record - The record that was created
   * @param source - Whether the change originated from 'user' or 'remote'
   * @internal
   */ handleAfterCreate(record, source) {
        if (!this._isEnabled) return;
        const handlers = this._afterCreateHandlers[record.typeName];
        if (handlers) {
            for (const handler of handlers){
                handler(record, source);
            }
        }
    }
    /**
   * Processes all registered 'before change' handlers for a record.
   * Handlers are called in registration order and can modify or block the change.
   *
   * @param prev - The current version of the record
   * @param next - The proposed new version of the record
   * @param source - Whether the change originated from 'user' or 'remote'
   * @returns The potentially modified record to actually store
   * @internal
   */ handleBeforeChange(prev, next, source) {
        if (!this._isEnabled) return next;
        const handlers = this._beforeChangeHandlers[next.typeName];
        if (handlers) {
            let r = next;
            for (const handler of handlers){
                r = handler(prev, r, source);
            }
            return r;
        }
        return next;
    }
    /**
   * Processes all registered 'after change' handlers for a record.
   * Handlers are called in registration order after the record is updated.
   *
   * @param prev - The previous version of the record
   * @param next - The new version of the record that was stored
   * @param source - Whether the change originated from 'user' or 'remote'
   * @internal
   */ handleAfterChange(prev, next, source) {
        if (!this._isEnabled) return;
        const handlers = this._afterChangeHandlers[next.typeName];
        if (handlers) {
            for (const handler of handlers){
                handler(prev, next, source);
            }
        }
    }
    /**
   * Processes all registered 'before delete' handlers for a record.
   * If any handler returns `false`, the deletion is prevented.
   *
   * @param record - The record about to be deleted
   * @param source - Whether the change originated from 'user' or 'remote'
   * @returns `true` to allow deletion, `false` to prevent it
   * @internal
   */ handleBeforeDelete(record, source) {
        if (!this._isEnabled) return true;
        const handlers = this._beforeDeleteHandlers[record.typeName];
        if (handlers) {
            for (const handler of handlers){
                if (handler(record, source) === false) {
                    return false;
                }
            }
        }
        return true;
    }
    /**
   * Processes all registered 'after delete' handlers for a record.
   * Handlers are called in registration order after the record is deleted.
   *
   * @param record - The record that was deleted
   * @param source - Whether the change originated from 'user' or 'remote'
   * @internal
   */ handleAfterDelete(record, source) {
        if (!this._isEnabled) return;
        const handlers = this._afterDeleteHandlers[record.typeName];
        if (handlers) {
            for (const handler of handlers){
                handler(record, source);
            }
        }
    }
    /**
   * Processes all registered operation complete handlers.
   * Called after an atomic store operation finishes.
   *
   * @param source - Whether the operation originated from 'user' or 'remote'
   * @internal
   */ handleOperationComplete(source) {
        if (!this._isEnabled) return;
        for (const handler of this._operationCompleteHandlers){
            handler(source);
        }
    }
    /**
   * Internal helper for registering multiple side effect handlers at once and keeping them organized.
   * This provides a convenient way to register handlers for multiple record types and lifecycle events
   * in a single call, returning a single cleanup function.
   *
   * @param handlersByType - An object mapping record type names to their respective handlers
   * @returns A function that removes all registered handlers when called
   *
   * @example
   * ```ts
   * const cleanup = sideEffects.register({
   *   shape: {
   *     afterDelete: (shape) => console.log('Shape deleted:', shape.id),
   *     beforeChange: (prev, next) => ({ ...next, lastModified: Date.now() })
   *   },
   *   arrow: {
   *     afterCreate: (arrow) => updateConnectedShapes(arrow)
   *   }
   * })
   *
   * // Later, remove all handlers
   * cleanup()
   * ```
   *
   * @internal
   */ register(handlersByType) {
        const disposes = [];
        for (const [type, handlers] of Object.entries(handlersByType)){
            if (handlers?.beforeCreate) {
                disposes.push(this.registerBeforeCreateHandler(type, handlers.beforeCreate));
            }
            if (handlers?.afterCreate) {
                disposes.push(this.registerAfterCreateHandler(type, handlers.afterCreate));
            }
            if (handlers?.beforeChange) {
                disposes.push(this.registerBeforeChangeHandler(type, handlers.beforeChange));
            }
            if (handlers?.afterChange) {
                disposes.push(this.registerAfterChangeHandler(type, handlers.afterChange));
            }
            if (handlers?.beforeDelete) {
                disposes.push(this.registerBeforeDeleteHandler(type, handlers.beforeDelete));
            }
            if (handlers?.afterDelete) {
                disposes.push(this.registerAfterDeleteHandler(type, handlers.afterDelete));
            }
        }
        return ()=>{
            for (const dispose of disposes)dispose();
        };
    }
    /**
   * Register a handler to be called before a record of a certain type is created. Return a
   * modified record from the handler to change the record that will be created.
   *
   * Use this handle only to modify the creation of the record itself. If you want to trigger a
   * side-effect on a different record (for example, moving one shape when another is created),
   * use {@link StoreSideEffects.registerAfterCreateHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerBeforeCreateHandler('shape', (shape, source) => {
   *     // only modify shapes created by the user
   *     if (source !== 'user') return shape
   *
   *     //by default, arrow shapes have no label. Let's make sure they always have a label.
   *     if (shape.type === 'arrow') {
   *         return {...shape, props: {...shape.props, text: 'an arrow'}}
   *     }
   *
   *     // other shapes get returned unmodified
   *     return shape
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerBeforeCreateHandler(typeName, handler) {
        const handlers = this._beforeCreateHandlers[typeName];
        if (!handlers) this._beforeCreateHandlers[typeName] = [];
        this._beforeCreateHandlers[typeName].push(handler);
        return ()=>remove(this._beforeCreateHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called after a record is created. This is useful for side-effects
   * that would update _other_ records. If you want to modify the record being created use
   * {@link StoreSideEffects.registerBeforeCreateHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerAfterCreateHandler('page', (page, source) => {
   *     // Automatically create a shape when a page is created
   *     editor.createShape({
   *         id: createShapeId(),
   *         type: 'text',
   *         props: { richText: toRichText(page.name) },
   *     })
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerAfterCreateHandler(typeName, handler) {
        const handlers = this._afterCreateHandlers[typeName];
        if (!handlers) this._afterCreateHandlers[typeName] = [];
        this._afterCreateHandlers[typeName].push(handler);
        return ()=>remove(this._afterCreateHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called before a record is changed. The handler is given the old and
   * new record - you can return a modified record to apply a different update, or the old record
   * to block the update entirely.
   *
   * Use this handler only for intercepting updates to the record itself. If you want to update
   * other records in response to a change, use
   * {@link StoreSideEffects.registerAfterChangeHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerBeforeChangeHandler('shape', (prev, next, source) => {
   *     if (next.isLocked && !prev.isLocked) {
   *         // prevent shapes from ever being locked:
   *         return prev
   *     }
   *     // other types of change are allowed
   *     return next
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerBeforeChangeHandler(typeName, handler) {
        const handlers = this._beforeChangeHandlers[typeName];
        if (!handlers) this._beforeChangeHandlers[typeName] = [];
        this._beforeChangeHandlers[typeName].push(handler);
        return ()=>remove(this._beforeChangeHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called after a record is changed. This is useful for side-effects
   * that would update _other_ records - if you want to modify the record being changed, use
   * {@link StoreSideEffects.registerBeforeChangeHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerAfterChangeHandler('shape', (prev, next, source) => {
   *     if (next.props.color === 'red') {
   *         // there can only be one red shape at a time:
   *         const otherRedShapes = editor.getCurrentPageShapes().filter(s => s.props.color === 'red' && s.id !== next.id)
   *         editor.updateShapes(otherRedShapes.map(s => ({...s, props: {...s.props, color: 'blue'}})))
   *     }
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerAfterChangeHandler(typeName, handler) {
        const handlers = this._afterChangeHandlers[typeName];
        if (!handlers) this._afterChangeHandlers[typeName] = [];
        this._afterChangeHandlers[typeName].push(handler);
        return ()=>remove(this._afterChangeHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called before a record is deleted. The handler can return `false` to
   * prevent the deletion.
   *
   * Use this handler only for intercepting deletions of the record itself. If you want to do
   * something to other records in response to a deletion, use
   * {@link StoreSideEffects.registerAfterDeleteHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerBeforeDeleteHandler('shape', (shape, source) => {
   *     if (shape.props.color === 'red') {
   *         // prevent red shapes from being deleted
   * 	       return false
   *     }
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerBeforeDeleteHandler(typeName, handler) {
        const handlers = this._beforeDeleteHandlers[typeName];
        if (!handlers) this._beforeDeleteHandlers[typeName] = [];
        this._beforeDeleteHandlers[typeName].push(handler);
        return ()=>remove(this._beforeDeleteHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called after a record is deleted. This is useful for side-effects
   * that would update _other_ records - if you want to block the deletion of the record itself,
   * use {@link StoreSideEffects.registerBeforeDeleteHandler} instead.
   *
   * @example
   * ```ts
   * editor.sideEffects.registerAfterDeleteHandler('shape', (shape, source) => {
   *     // if the last shape in a frame is deleted, delete the frame too:
   *     const parentFrame = editor.getShape(shape.parentId)
   *     if (!parentFrame || parentFrame.type !== 'frame') return
   *
   *     const siblings = editor.getSortedChildIdsForParent(parentFrame)
   *     if (siblings.length === 0) {
   *         editor.deleteShape(parentFrame.id)
   *     }
   * })
   * ```
   *
   * @param typeName - The type of record to listen for
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   */ registerAfterDeleteHandler(typeName, handler) {
        const handlers = this._afterDeleteHandlers[typeName];
        if (!handlers) this._afterDeleteHandlers[typeName] = [];
        this._afterDeleteHandlers[typeName].push(handler);
        return ()=>remove(this._afterDeleteHandlers[typeName], handler);
    }
    /**
   * Register a handler to be called when a store completes an atomic operation.
   *
   * @example
   * ```ts
   * let count = 0
   *
   * editor.sideEffects.registerOperationCompleteHandler(() => count++)
   *
   * editor.selectAll()
   * expect(count).toBe(1)
   *
   * editor.store.atomic(() => {
   *	editor.selectNone()
   * 	editor.selectAll()
   * })
   *
   * expect(count).toBe(2)
   * ```
   *
   * @param handler - The handler to call
   *
   * @returns A callback that removes the handler.
   *
   * @public
   */ registerOperationCompleteHandler(handler) {
        this._operationCompleteHandlers.push(handler);
        return ()=>remove(this._operationCompleteHandlers, handler);
    }
}
function remove(array, item) {
    const index = array.indexOf(item);
    if (index >= 0) {
        array.splice(index, 1);
    }
}
;
 //# sourceMappingURL=StoreSideEffects.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/Store.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Store",
    ()=>Store,
    "createComputedCache",
    ()=>createComputedCache
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/EffectScheduler.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/transactions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/cache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript) <export default as isEqual>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/throttle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreQueries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreQueries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSideEffects.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/devFreeze.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
class Store {
    /**
   * The unique identifier of the store instance.
   *
   * @public
   */ id;
    /**
   * An AtomMap containing the stores records.
   *
   * @internal
   * @readonly
   */ records;
    /**
   * An atom containing the store's history.
   *
   * @public
   * @readonly
   */ history = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("history", 0, {
        historyLength: 1e3
    });
    /**
   * Reactive queries and indexes for efficiently accessing store data.
   * Provides methods for filtering, indexing, and subscribing to subsets of records.
   *
   * @example
   * ```ts
   * // Create an index by a property
   * const booksByAuthor = store.query.index('book', 'author')
   *
   * // Get records matching criteria
   * const inStockBooks = store.query.records('book', () => ({
   *   inStock: { eq: true }
   * }))
   * ```
   *
   * @public
   * @readonly
   */ query;
    /**
   * A set containing listeners that have been added to this store.
   *
   * @internal
   */ listeners = /* @__PURE__ */ new Set();
    /**
   * An array of history entries that have not yet been flushed.
   *
   * @internal
   */ historyAccumulator = new HistoryAccumulator();
    /**
   * A reactor that responds to changes to the history by squashing the accumulated history and
   * notifying listeners of the changes.
   *
   * @internal
   */ historyReactor;
    /**
   * Function to dispose of any in-flight timeouts.
   *
   * @internal
   */ cancelHistoryReactor() {}
    /**
   * The schema that defines the structure and validation rules for records in this store.
   *
   * @public
   */ schema;
    /**
   * Custom properties associated with this store instance.
   *
   * @public
   */ props;
    /**
   * A mapping of record scopes to the set of record type names that belong to each scope.
   * Used to filter records by their persistence and synchronization behavior.
   *
   * @public
   */ scopedTypes;
    /**
   * Side effects manager that handles lifecycle events for record operations.
   * Allows registration of callbacks for create, update, delete, and validation events.
   *
   * @example
   * ```ts
   * store.sideEffects.registerAfterCreateHandler('book', (book) => {
   *   console.log('Book created:', book.title)
   * })
   * ```
   *
   * @public
   */ sideEffects = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreSideEffects"](this);
    /**
   * Creates a new Store instance.
   *
   * @example
   * ```ts
   * const store = new Store({
   *   schema: StoreSchema.create({ book: Book }),
   *   props: { appName: 'MyLibrary' },
   *   initialData: savedData
   * })
   * ```
   *
   * @param config - Configuration object for the store
   */ constructor(config){
        const { initialData, schema, id } = config;
        this.id = id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
        this.schema = schema;
        this.props = config.props;
        if (initialData) {
            this.records = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomMap"]("store", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(initialData).map(([id2, record])=>[
                    id2,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"])(this.schema.validateRecord(this, record, "initialize", null))
                ]));
        } else {
            this.records = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomMap"]("store");
        }
        this.query = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreQueries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreQueries"](this.records, this.history);
        this.historyReactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reactor"])("Store.historyReactor", ()=>{
            this.history.get();
            this._flushHistory();
        }, {
            scheduleEffect: (cb)=>this.cancelHistoryReactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throttleToNextFrame"])(cb)
        });
        this.scopedTypes = {
            document: new Set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(this.schema.types).filter((t)=>t.scope === "document").map((t)=>t.typeName)),
            session: new Set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(this.schema.types).filter((t)=>t.scope === "session").map((t)=>t.typeName)),
            presence: new Set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(this.schema.types).filter((t)=>t.scope === "presence").map((t)=>t.typeName))
        };
    }
    _flushHistory() {
        if (this.historyAccumulator.hasChanges()) {
            const entries = this.historyAccumulator.flush();
            for (const { changes, source } of entries){
                let instanceChanges = null;
                let documentChanges = null;
                let presenceChanges = null;
                for (const { onHistory, filters } of this.listeners){
                    if (filters.source !== "all" && filters.source !== source) {
                        continue;
                    }
                    if (filters.scope !== "all") {
                        if (filters.scope === "document") {
                            documentChanges ??= this.filterChangesByScope(changes, "document");
                            if (!documentChanges) continue;
                            onHistory({
                                changes: documentChanges,
                                source
                            });
                        } else if (filters.scope === "session") {
                            instanceChanges ??= this.filterChangesByScope(changes, "session");
                            if (!instanceChanges) continue;
                            onHistory({
                                changes: instanceChanges,
                                source
                            });
                        } else {
                            presenceChanges ??= this.filterChangesByScope(changes, "presence");
                            if (!presenceChanges) continue;
                            onHistory({
                                changes: presenceChanges,
                                source
                            });
                        }
                    } else {
                        onHistory({
                            changes,
                            source
                        });
                    }
                }
            }
        }
    }
    dispose() {
        this.cancelHistoryReactor();
    }
    /**
   * Filters out non-document changes from a diff. Returns null if there are no changes left.
   * @param change - the records diff
   * @param scope - the records scope
   * @returns
   */ filterChangesByScope(change, scope) {
        const result = {
            added: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"])(change.added, (_, r)=>this.scopedTypes[scope].has(r.typeName)),
            updated: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"])(change.updated, (_, r)=>this.scopedTypes[scope].has(r[1].typeName)),
            removed: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterEntries"])(change.removed, (_, r)=>this.scopedTypes[scope].has(r.typeName))
        };
        if (Object.keys(result.added).length === 0 && Object.keys(result.updated).length === 0 && Object.keys(result.removed).length === 0) {
            return null;
        }
        return result;
    }
    /**
   * Update the history with a diff of changes.
   *
   * @param changes - The changes to add to the history.
   */ updateHistory(changes) {
        this.historyAccumulator.add({
            changes,
            source: this.isMergingRemoteChanges ? "remote" : "user"
        });
        if (this.listeners.size === 0) {
            this.historyAccumulator.clear();
        }
        this.history.set(this.history.get() + 1, changes);
    }
    validate(phase) {
        this.allRecords().forEach((record)=>this.schema.validateRecord(this, record, phase, null));
    }
    /**
   * Add or update records in the store. If a record with the same ID already exists, it will be updated.
   * Otherwise, a new record will be created.
   *
   * @example
   * ```ts
   * // Add new records
   * const book = Book.create({ title: 'Lathe Of Heaven', author: 'Le Guin' })
   * store.put([book])
   *
   * // Update existing record
   * store.put([{ ...book, title: 'The Lathe of Heaven' }])
   * ```
   *
   * @param records - The records to add or update
   * @param phaseOverride - Override the validation phase (used internally)
   * @public
   */ put(records, phaseOverride) {
        this.atomic(()=>{
            const updates = {};
            const additions = {};
            let record;
            let didChange = false;
            const source = this.isMergingRemoteChanges ? "remote" : "user";
            for(let i = 0, n = records.length; i < n; i++){
                record = records[i];
                const initialValue = this.records.__unsafe__getWithoutCapture(record.id);
                if (initialValue) {
                    record = this.sideEffects.handleBeforeChange(initialValue, record, source);
                    const validated = this.schema.validateRecord(this, record, phaseOverride ?? "updateRecord", initialValue);
                    if (validated === initialValue) continue;
                    record = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"])(record);
                    this.records.set(record.id, record);
                    didChange = true;
                    updates[record.id] = [
                        initialValue,
                        record
                    ];
                    this.addDiffForAfterEvent(initialValue, record);
                } else {
                    record = this.sideEffects.handleBeforeCreate(record, source);
                    didChange = true;
                    record = this.schema.validateRecord(this, record, phaseOverride ?? "createRecord", null);
                    record = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"])(record);
                    additions[record.id] = record;
                    this.addDiffForAfterEvent(null, record);
                    this.records.set(record.id, record);
                }
            }
            if (!didChange) return;
            this.updateHistory({
                added: additions,
                updated: updates,
                removed: {}
            });
        });
    }
    /**
   * Remove records from the store by their IDs.
   *
   * @example
   * ```ts
   * // Remove a single record
   * store.remove([book.id])
   *
   * // Remove multiple records
   * store.remove([book1.id, book2.id, book3.id])
   * ```
   *
   * @param ids - The IDs of the records to remove
   * @public
   */ remove(ids) {
        this.atomic(()=>{
            const toDelete = new Set(ids);
            const source = this.isMergingRemoteChanges ? "remote" : "user";
            if (this.sideEffects.isEnabled()) {
                for (const id of ids){
                    const record = this.records.__unsafe__getWithoutCapture(id);
                    if (!record) continue;
                    if (this.sideEffects.handleBeforeDelete(record, source) === false) {
                        toDelete.delete(id);
                    }
                }
            }
            const actuallyDeleted = this.records.deleteMany(toDelete);
            if (actuallyDeleted.length === 0) return;
            const removed = {};
            for (const [id, record] of actuallyDeleted){
                removed[id] = record;
                this.addDiffForAfterEvent(record, null);
            }
            this.updateHistory({
                added: {},
                updated: {},
                removed
            });
        });
    }
    /**
   * Get a record by its ID. This creates a reactive subscription to the record.
   *
   * @example
   * ```ts
   * const book = store.get(bookId)
   * if (book) {
   *   console.log(book.title)
   * }
   * ```
   *
   * @param id - The ID of the record to get
   * @returns The record if it exists, undefined otherwise
   * @public
   */ get(id) {
        return this.records.get(id);
    }
    /**
   * Get a record by its ID without creating a reactive subscription.
   * Use this when you need to access a record but don't want reactive updates.
   *
   * @example
   * ```ts
   * // Won't trigger reactive updates when this record changes
   * const book = store.unsafeGetWithoutCapture(bookId)
   * ```
   *
   * @param id - The ID of the record to get
   * @returns The record if it exists, undefined otherwise
   * @public
   */ unsafeGetWithoutCapture(id) {
        return this.records.__unsafe__getWithoutCapture(id);
    }
    /**
   * Serialize the store's records to a plain JavaScript object.
   * Only includes records matching the specified scope.
   *
   * @example
   * ```ts
   * // Serialize only document records (default)
   * const documentData = store.serialize('document')
   *
   * // Serialize all records
   * const allData = store.serialize('all')
   * ```
   *
   * @param scope - The scope of records to serialize. Defaults to 'document'
   * @returns The serialized store data
   * @public
   */ serialize(scope = "document") {
        const result = {};
        for (const [id, record] of this.records){
            if (scope === "all" || this.scopedTypes[scope].has(record.typeName)) {
                result[id] = record;
            }
        }
        return result;
    }
    /**
   * Get a serialized snapshot of the store and its schema.
   * This includes both the data and schema information needed for proper migration.
   *
   * @example
   * ```ts
   * const snapshot = store.getStoreSnapshot()
   * localStorage.setItem('myApp', JSON.stringify(snapshot))
   *
   * // Later...
   * const saved = JSON.parse(localStorage.getItem('myApp'))
   * store.loadStoreSnapshot(saved)
   * ```
   *
   * @param scope - The scope of records to serialize. Defaults to 'document'
   * @returns A snapshot containing both store data and schema information
   * @public
   */ getStoreSnapshot(scope = "document") {
        return {
            store: this.serialize(scope),
            schema: this.schema.serialize()
        };
    }
    /**
   * Migrate a serialized snapshot to the current schema version.
   * This applies any necessary migrations to bring old data up to date.
   *
   * @example
   * ```ts
   * const oldSnapshot = JSON.parse(localStorage.getItem('myApp'))
   * const migratedSnapshot = store.migrateSnapshot(oldSnapshot)
   * ```
   *
   * @param snapshot - The snapshot to migrate
   * @returns The migrated snapshot with current schema version
   * @throws Error if migration fails
   * @public
   */ migrateSnapshot(snapshot) {
        const migrationResult = this.schema.migrateStoreSnapshot(snapshot);
        if (migrationResult.type === "error") {
            throw new Error(`Failed to migrate snapshot: ${migrationResult.reason}`);
        }
        return {
            store: migrationResult.value,
            schema: this.schema.serialize()
        };
    }
    /**
   * Load a serialized snapshot into the store, replacing all current data.
   * The snapshot will be automatically migrated to the current schema version if needed.
   *
   * @example
   * ```ts
   * const snapshot = JSON.parse(localStorage.getItem('myApp'))
   * store.loadStoreSnapshot(snapshot)
   * ```
   *
   * @param snapshot - The snapshot to load
   * @throws Error if migration fails or snapshot is invalid
   * @public
   */ loadStoreSnapshot(snapshot) {
        const migrationResult = this.schema.migrateStoreSnapshot(snapshot);
        if (migrationResult.type === "error") {
            throw new Error(`Failed to migrate snapshot: ${migrationResult.reason}`);
        }
        const prevSideEffectsEnabled = this.sideEffects.isEnabled();
        try {
            this.sideEffects.setIsEnabled(false);
            this.atomic(()=>{
                this.clear();
                this.put(Object.values(migrationResult.value));
                this.ensureStoreIsUsable();
            });
        } finally{
            this.sideEffects.setIsEnabled(prevSideEffectsEnabled);
        }
    }
    /**
   * Get an array of all records in the store.
   *
   * @example
   * ```ts
   * const allRecords = store.allRecords()
   * const books = allRecords.filter(r => r.typeName === 'book')
   * ```
   *
   * @returns An array containing all records in the store
   * @public
   */ allRecords() {
        return Array.from(this.records.values());
    }
    /**
   * Remove all records from the store.
   *
   * @example
   * ```ts
   * store.clear()
   * console.log(store.allRecords().length) // 0
   * ```
   *
   * @public
   */ clear() {
        this.remove(Array.from(this.records.keys()));
    }
    /**
   * Update a single record using an updater function. To update multiple records at once,
   * use the `update` method of the `TypedStore` class.
   *
   * @example
   * ```ts
   * store.update(book.id, (book) => ({
   *   ...book,
   *   title: 'Updated Title'
   * }))
   * ```
   *
   * @param id - The ID of the record to update
   * @param updater - A function that receives the current record and returns the updated record
   * @public
   */ update(id, updater) {
        const existing = this.unsafeGetWithoutCapture(id);
        if (!existing) {
            console.error(`Record ${id} not found. This is probably an error`);
            return;
        }
        this.put([
            updater(existing)
        ]);
    }
    /**
   * Check whether a record with the given ID exists in the store.
   *
   * @example
   * ```ts
   * if (store.has(bookId)) {
   *   console.log('Book exists!')
   * }
   * ```
   *
   * @param id - The ID of the record to check
   * @returns True if the record exists, false otherwise
   * @public
   */ has(id) {
        return this.records.has(id);
    }
    /**
   * Add a listener that will be called when the store changes.
   * Returns a function to remove the listener.
   *
   * @example
   * ```ts
   * const removeListener = store.listen((entry) => {
   *   console.log('Changes:', entry.changes)
   *   console.log('Source:', entry.source)
   * })
   *
   * // Listen only to user changes to document records
   * const removeDocumentListener = store.listen(
   *   (entry) => console.log('Document changed:', entry),
   *   { source: 'user', scope: 'document' }
   * )
   *
   * // Later, remove the listener
   * removeListener()
   * ```
   *
   * @param onHistory - The listener function to call when changes occur
   * @param filters - Optional filters to control when the listener is called
   * @returns A function that removes the listener when called
   * @public
   */ listen(onHistory, filters) {
        this._flushHistory();
        const listener = {
            onHistory,
            filters: {
                source: filters?.source ?? "all",
                scope: filters?.scope ?? "all"
            }
        };
        if (!this.historyReactor.scheduler.isActivelyListening) {
            this.historyReactor.start();
            this.historyReactor.scheduler.execute();
        }
        this.listeners.add(listener);
        return ()=>{
            this.listeners.delete(listener);
            if (this.listeners.size === 0) {
                this.historyReactor.stop();
            }
        };
    }
    isMergingRemoteChanges = false;
    /**
   * Merge changes from a remote source. Changes made within the provided function
   * will be marked with source 'remote' instead of 'user'.
   *
   * @example
   * ```ts
   * // Changes from sync/collaboration
   * store.mergeRemoteChanges(() => {
   *   store.put(remoteRecords)
   *   store.remove(deletedIds)
   * })
   * ```
   *
   * @param fn - A function that applies the remote changes
   * @public
   */ mergeRemoteChanges(fn) {
        if (this.isMergingRemoteChanges) {
            return fn();
        }
        if (this._isInAtomicOp) {
            throw new Error("Cannot merge remote changes while in atomic operation");
        }
        try {
            this.atomic(fn, true, true);
        } finally{
            this.ensureStoreIsUsable();
        }
    }
    /**
   * Run `fn` and return a {@link RecordsDiff} of the changes that occurred as a result.
   */ extractingChanges(fn) {
        const changes = [];
        const dispose = this.historyAccumulator.addInterceptor((entry)=>changes.push(entry.changes));
        try {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(fn);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffs"])(changes);
        } finally{
            dispose();
        }
    }
    applyDiff(diff, { runCallbacks = true, ignoreEphemeralKeys = false } = {}) {
        this.atomic(()=>{
            const toPut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(diff.added);
            for (const [_from, to] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(diff.updated)){
                const type = this.schema.getType(to.typeName);
                if (ignoreEphemeralKeys && type.ephemeralKeySet.size) {
                    const existing = this.get(to.id);
                    if (!existing) {
                        toPut.push(to);
                        continue;
                    }
                    let changed = null;
                    for (const [key, value] of Object.entries(to)){
                        if (type.ephemeralKeySet.has(key) || Object.is(value, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(existing, key))) {
                            continue;
                        }
                        if (!changed) changed = {
                            ...existing
                        };
                        changed[key] = value;
                    }
                    if (changed) toPut.push(changed);
                } else {
                    toPut.push(to);
                }
            }
            const toRemove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapKeys"])(diff.removed);
            if (toPut.length) {
                this.put(toPut);
            }
            if (toRemove.length) {
                this.remove(toRemove);
            }
        }, runCallbacks);
    }
    /**
   * Create a cache based on values in the store. Pass in a function that takes and ID and a
   * signal for the underlying record. Return a signal (usually a computed) for the cached value.
   * For simple derivations, use {@link Store.createComputedCache}. This function is useful if you
   * need more precise control over intermediate values.
   */ createCache(create) {
        const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"]();
        return {
            get: (id)=>{
                const atom2 = this.records.getAtom(id);
                if (!atom2) return void 0;
                return cache.get(atom2, ()=>create(id, atom2)).get();
            }
        };
    }
    /**
   * Create a computed cache.
   *
   * @param name - The name of the derivation cache.
   * @param derive - A function used to derive the value of the cache.
   * @param opts - Options for the computed cache.
   * @public
   */ createComputedCache(name, derive, opts) {
        return this.createCache((id, record)=>{
            const recordSignal = opts?.areRecordsEqual ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])(`${name}:${id}:isEqual`, ()=>record.get(), {
                isEqual: opts.areRecordsEqual
            }) : record;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])(name + ":" + id, ()=>{
                return derive(recordSignal.get());
            }, {
                isEqual: opts?.areResultsEqual
            });
        });
    }
    _integrityChecker;
    /** @internal */ ensureStoreIsUsable() {
        this.atomic(()=>{
            this._integrityChecker ??= this.schema.createIntegrityChecker(this);
            this._integrityChecker?.();
        });
    }
    _isPossiblyCorrupted = false;
    /** @internal */ markAsPossiblyCorrupted() {
        this._isPossiblyCorrupted = true;
    }
    /** @internal */ isPossiblyCorrupted() {
        return this._isPossiblyCorrupted;
    }
    pendingAfterEvents = null;
    addDiffForAfterEvent(before, after) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(this.pendingAfterEvents, "must be in event operation");
        if (before === after) return;
        if (before && after) (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(before.id === after.id);
        if (!before && !after) return;
        const id = (before || after).id;
        const existing = this.pendingAfterEvents.get(id);
        if (existing) {
            existing.after = after;
        } else {
            this.pendingAfterEvents.set(id, {
                before,
                after
            });
        }
    }
    flushAtomicCallbacks(isMergingRemoteChanges) {
        let updateDepth = 0;
        let source = isMergingRemoteChanges ? "remote" : "user";
        while(this.pendingAfterEvents){
            const events = this.pendingAfterEvents;
            this.pendingAfterEvents = null;
            if (!this.sideEffects.isEnabled()) continue;
            updateDepth++;
            if (updateDepth > 100) {
                throw new Error("Maximum store update depth exceeded, bailing out");
            }
            for (const { before, after } of events.values()){
                if (before && after && before !== after && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"])(before, after)) {
                    this.sideEffects.handleAfterChange(before, after, source);
                } else if (before && !after) {
                    this.sideEffects.handleAfterDelete(before, source);
                } else if (!before && after) {
                    this.sideEffects.handleAfterCreate(after, source);
                }
            }
            if (!this.pendingAfterEvents) {
                this.sideEffects.handleOperationComplete(source);
            } else {
                source = "user";
            }
        }
    }
    _isInAtomicOp = false;
    /** @internal */ atomic(fn, runCallbacks = true, isMergingRemoteChanges = false) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            if (this._isInAtomicOp) {
                if (!this.pendingAfterEvents) this.pendingAfterEvents = /* @__PURE__ */ new Map();
                const prevSideEffectsEnabled2 = this.sideEffects.isEnabled();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(!isMergingRemoteChanges, "cannot call mergeRemoteChanges while in atomic operation");
                try {
                    if (prevSideEffectsEnabled2 && !runCallbacks) {
                        this.sideEffects.setIsEnabled(false);
                    }
                    return fn();
                } finally{
                    this.sideEffects.setIsEnabled(prevSideEffectsEnabled2);
                }
            }
            this.pendingAfterEvents = /* @__PURE__ */ new Map();
            const prevSideEffectsEnabled = this.sideEffects.isEnabled();
            this.sideEffects.setIsEnabled(runCallbacks ?? prevSideEffectsEnabled);
            this._isInAtomicOp = true;
            if (isMergingRemoteChanges) {
                this.isMergingRemoteChanges = true;
            }
            try {
                const result = fn();
                this.isMergingRemoteChanges = false;
                this.flushAtomicCallbacks(isMergingRemoteChanges);
                return result;
            } finally{
                this.pendingAfterEvents = null;
                this.sideEffects.setIsEnabled(prevSideEffectsEnabled);
                this._isInAtomicOp = false;
                this.isMergingRemoteChanges = false;
            }
        });
    }
    /** @internal */ addHistoryInterceptor(fn) {
        return this.historyAccumulator.addInterceptor((entry)=>fn(entry, this.isMergingRemoteChanges ? "remote" : "user"));
    }
}
function squashHistoryEntries(entries) {
    if (entries.length === 0) return [];
    const chunked = [];
    let chunk = [
        entries[0]
    ];
    let entry;
    for(let i = 1, n = entries.length; i < n; i++){
        entry = entries[i];
        if (chunk[0].source !== entry.source) {
            chunked.push(chunk);
            chunk = [];
        }
        chunk.push(entry);
    }
    chunked.push(chunk);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"])(chunked.map((chunk2)=>({
            source: chunk2[0].source,
            changes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffs"])(chunk2.map((e)=>e.changes))
        })));
}
class HistoryAccumulator {
    _history = [];
    _interceptors = /* @__PURE__ */ new Set();
    /**
   * Add an interceptor that will be called for each history entry.
   * Returns a function to remove the interceptor.
   */ addInterceptor(fn) {
        this._interceptors.add(fn);
        return ()=>{
            this._interceptors.delete(fn);
        };
    }
    /**
   * Add a history entry to the accumulator.
   * Calls all registered interceptors with the entry.
   */ add(entry) {
        this._history.push(entry);
        for (const interceptor of this._interceptors){
            interceptor(entry);
        }
    }
    /**
   * Flush all accumulated history entries, squashing adjacent entries from the same source.
   * Clears the internal history buffer.
   */ flush() {
        const history = squashHistoryEntries(this._history);
        this._history = [];
        return history;
    }
    /**
   * Clear all accumulated history entries without flushing.
   */ clear() {
        this._history = [];
    }
    /**
   * Check if there are any accumulated history entries.
   */ hasChanges() {
        return this._history.length > 0;
    }
}
function createComputedCache(name, derive, opts) {
    const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$cache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeakCache"]();
    return {
        get (context, id) {
            const computedCache = cache.get(context, ()=>{
                const store = context instanceof Store ? context : context.store;
                return store.createComputedCache(name, (record)=>derive(context, record), opts);
            });
            return computedCache.get(id);
        }
    };
}
;
 //# sourceMappingURL=Store.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSchema.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StoreSchema",
    ()=>StoreSchema,
    "upgradeSchema",
    ()=>upgradeSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lodash.isequal/index.js [app-client] (ecmascript) <export default as isEqual>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/devFreeze.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
;
;
;
function upgradeSchema(schema) {
    if (schema.schemaVersion > 2 || schema.schemaVersion < 1) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err("Bad schema version");
    if (schema.schemaVersion === 2) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok(schema);
    const result = {
        schemaVersion: 2,
        sequences: {
            "com.tldraw.store": schema.storeVersion
        }
    };
    for (const [typeName, recordVersion] of Object.entries(schema.recordVersions)){
        result.sequences[`com.tldraw.${typeName}`] = recordVersion.version;
        if ("subTypeKey" in recordVersion) {
            for (const [subType, version] of Object.entries(recordVersion.subTypeVersions)){
                result.sequences[`com.tldraw.${typeName}.${subType}`] = version;
            }
        }
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok(result);
}
class StoreSchema {
    constructor(types, options){
        this.types = types;
        this.options = options;
        for (const m of options.migrations ?? []){
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(!this.migrations[m.sequenceId], `Duplicate migration sequenceId ${m.sequenceId}`);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMigrations"])(m);
            this.migrations[m.sequenceId] = m;
        }
        const allMigrations = Object.values(this.migrations).flatMap((m)=>m.sequence);
        this.sortedMigrations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortMigrations"])(allMigrations);
        for (const migration of this.sortedMigrations){
            if (!migration.dependsOn?.length) continue;
            for (const dep of migration.dependsOn){
                const depMigration = allMigrations.find((m)=>m.id === dep);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(depMigration, `Migration '${migration.id}' depends on missing migration '${dep}'`);
            }
        }
    }
    /**
   * Creates a new StoreSchema with the given record types and options.
   *
   * This static factory method is the recommended way to create a StoreSchema.
   * It ensures type safety while providing a clean API for schema definition.
   *
   * @param types - Object mapping type names to their RecordType definitions
   * @param options - Optional configuration for migrations, validation, and integrity checking
   * @returns A new StoreSchema instance
   *
   * @example
   * ```ts
   * const Book = createRecordType<Book>('book', { scope: 'document' })
   * const Author = createRecordType<Author>('author', { scope: 'document' })
   *
   * const schema = StoreSchema.create(
   *   {
   *     book: Book,
   *     author: Author
   *   },
   *   {
   *     migrations: [bookMigrations],
   *     onValidationFailure: (failure) => failure.record
   *   }
   * )
   * ```
   *
   * @public
   */ static create(types, options) {
        return new StoreSchema(types, options ?? {});
    }
    migrations = {};
    sortedMigrations;
    migrationCache = /* @__PURE__ */ new WeakMap();
    /**
   * Validates a record using its corresponding RecordType validator.
   *
   * This method ensures that records conform to their type definitions before
   * being stored. If validation fails and an onValidationFailure handler is
   * provided, it will be called to potentially recover from the error.
   *
   * @param store - The store instance where validation is occurring
   * @param record - The record to validate
   * @param phase - The lifecycle phase where validation is happening
   * @param recordBefore - The previous version of the record (for updates)
   * @returns The validated record, potentially modified by validation failure handler
   *
   * @example
   * ```ts
   * try {
   *   const validatedBook = schema.validateRecord(
   *     store,
   *     { id: 'book:1', typeName: 'book', title: '', author: 'Jane Doe' },
   *     'createRecord',
   *     null
   *   )
   * } catch (error) {
   *   console.error('Record validation failed:', error)
   * }
   * ```
   *
   * @public
   */ validateRecord(store, record, phase, recordBefore) {
        try {
            const recordType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(this.types, record.typeName);
            if (!recordType) {
                throw new Error(`Missing definition for record type ${record.typeName}`);
            }
            return recordType.validate(record, recordBefore ?? void 0);
        } catch (error) {
            if (this.options.onValidationFailure) {
                return this.options.onValidationFailure({
                    store,
                    record,
                    phase,
                    recordBefore,
                    error
                });
            } else {
                throw error;
            }
        }
    }
    /**
   * Gets all migrations that need to be applied to upgrade from a persisted schema
   * to the current schema version.
   *
   * This method compares the persisted schema with the current schema and determines
   * which migrations need to be applied to bring the data up to date. It handles
   * both regular migrations and retroactive migrations, and caches results for
   * performance.
   *
   * @param persistedSchema - The schema version that was previously persisted
   * @returns A Result containing the list of migrations to apply, or an error message
   *
   * @example
   * ```ts
   * const persistedSchema = {
   *   schemaVersion: 2,
   *   sequences: { 'com.tldraw.book': 1, 'com.tldraw.author': 0 }
   * }
   *
   * const migrationsResult = schema.getMigrationsSince(persistedSchema)
   * if (migrationsResult.ok) {
   *   console.log('Migrations to apply:', migrationsResult.value.length)
   *   // Apply each migration to bring data up to date
   * }
   * ```
   *
   * @public
   */ getMigrationsSince(persistedSchema) {
        const cached = this.migrationCache.get(persistedSchema);
        if (cached) {
            return cached;
        }
        const upgradeResult = upgradeSchema(persistedSchema);
        if (!upgradeResult.ok) {
            this.migrationCache.set(persistedSchema, upgradeResult);
            return upgradeResult;
        }
        const schema = upgradeResult.value;
        const sequenceIdsToInclude = new Set(// start with any shared sequences
        Object.keys(schema.sequences).filter((sequenceId)=>this.migrations[sequenceId]));
        for(const sequenceId in this.migrations){
            if (schema.sequences[sequenceId] === void 0 && this.migrations[sequenceId].retroactive) {
                sequenceIdsToInclude.add(sequenceId);
            }
        }
        if (sequenceIdsToInclude.size === 0) {
            const result2 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok([]);
            this.migrationCache.set(persistedSchema, result2);
            return result2;
        }
        const allMigrationsToInclude = /* @__PURE__ */ new Set();
        for (const sequenceId of sequenceIdsToInclude){
            const theirVersion = schema.sequences[sequenceId];
            if (typeof theirVersion !== "number" && this.migrations[sequenceId].retroactive || theirVersion === 0) {
                for (const migration of this.migrations[sequenceId].sequence){
                    allMigrationsToInclude.add(migration.id);
                }
                continue;
            }
            const theirVersionId = `${sequenceId}/${theirVersion}`;
            const idx = this.migrations[sequenceId].sequence.findIndex((m)=>m.id === theirVersionId);
            if (idx === -1) {
                const result2 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err("Incompatible schema?");
                this.migrationCache.set(persistedSchema, result2);
                return result2;
            }
            for (const migration of this.migrations[sequenceId].sequence.slice(idx + 1)){
                allMigrationsToInclude.add(migration.id);
            }
        }
        const result = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok(this.sortedMigrations.filter(({ id })=>allMigrationsToInclude.has(id)));
        this.migrationCache.set(persistedSchema, result);
        return result;
    }
    /**
   * Migrates a single persisted record to match the current schema version.
   *
   * This method applies the necessary migrations to transform a record from an
   * older (or newer) schema version to the current version. It supports both
   * forward ('up') and backward ('down') migrations.
   *
   * @param record - The record to migrate
   * @param persistedSchema - The schema version the record was persisted with
   * @param direction - Direction to migrate ('up' for newer, 'down' for older)
   * @returns A MigrationResult containing the migrated record or an error
   *
   * @example
   * ```ts
   * const oldRecord = { id: 'book:1', typeName: 'book', title: 'Old Title', publishDate: '2020-01-01' }
   * const oldSchema = { schemaVersion: 2, sequences: { 'com.tldraw.book': 1 } }
   *
   * const result = schema.migratePersistedRecord(oldRecord, oldSchema, 'up')
   * if (result.type === 'success') {
   *   console.log('Migrated record:', result.value)
   *   // Record now has publishedYear instead of publishDate
   * } else {
   *   console.error('Migration failed:', result.reason)
   * }
   * ```
   *
   * @public
   */ migratePersistedRecord(record, persistedSchema, direction = "up") {
        const migrations = this.getMigrationsSince(persistedSchema);
        if (!migrations.ok) {
            console.error("Error migrating record", migrations.error);
            return {
                type: "error",
                reason: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].MigrationError
            };
        }
        let migrationsToApply = migrations.value;
        if (migrationsToApply.length === 0) {
            return {
                type: "success",
                value: record
            };
        }
        if (!migrationsToApply.every((m)=>m.scope === "record")) {
            return {
                type: "error",
                reason: direction === "down" ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].TargetVersionTooOld : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].TargetVersionTooNew
            };
        }
        if (direction === "down") {
            if (!migrationsToApply.every((m)=>m.scope === "record" && m.down)) {
                return {
                    type: "error",
                    reason: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].TargetVersionTooOld
                };
            }
            migrationsToApply = migrationsToApply.slice().reverse();
        }
        record = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(record);
        try {
            for (const migration of migrationsToApply){
                if (migration.scope === "store") throw new Error();
                if (migration.scope === "storage") throw new Error();
                const shouldApply = migration.filter ? migration.filter(record) : true;
                if (!shouldApply) continue;
                const result = migration[direction](record);
                if (result) {
                    record = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(result);
                }
            }
        } catch (e) {
            console.error("Error migrating record", e);
            return {
                type: "error",
                reason: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].MigrationError
            };
        }
        return {
            type: "success",
            value: record
        };
    }
    migrateStorage(storage) {
        const schema = storage.getSchema();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(schema, "Schema is missing.");
        const migrations = this.getMigrationsSince(schema);
        if (!migrations.ok) {
            console.error("Error migrating store", migrations.error);
            throw new Error(migrations.error);
        }
        const migrationsToApply = migrations.value;
        if (migrationsToApply.length === 0) {
            return;
        }
        storage.setSchema(this.serialize());
        for (const migration of migrationsToApply){
            if (migration.scope === "record") {
                const updates = [];
                for (const [id, state] of storage.entries()){
                    const shouldApply = migration.filter ? migration.filter(state) : true;
                    if (!shouldApply) continue;
                    const record = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(state);
                    const result = migration.up(record) ?? record;
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"])(result, state)) {
                        updates.push([
                            id,
                            result
                        ]);
                    }
                }
                for (const [id, record] of updates){
                    storage.set(id, record);
                }
            } else if (migration.scope === "store") {
                const prevStore = Object.fromEntries(storage.entries());
                let nextStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(prevStore);
                nextStore = migration.up(nextStore) ?? nextStore;
                for (const [id, state] of Object.entries(nextStore)){
                    if (!state) continue;
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"])(state, prevStore[id])) {
                        storage.set(id, state);
                    }
                }
                for (const id of Object.keys(prevStore)){
                    if (!nextStore[id]) {
                        storage.delete(id);
                    }
                }
            } else if (migration.scope === "storage") {
                migration.up(storage);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(migration);
            }
        }
        for (const [id, state] of storage.entries()){
            if (this.getType(state.typeName).scope !== "document") {
                storage.delete(id);
            }
        }
    }
    /**
   * Migrates an entire store snapshot to match the current schema version.
   *
   * This method applies all necessary migrations to bring a persisted store
   * snapshot up to the current schema version. It handles both record-level
   * and store-level migrations, and can optionally mutate the input store
   * for performance.
   *
   * @param snapshot - The store snapshot containing data and schema information
   * @param opts - Options controlling migration behavior
   *   - mutateInputStore - Whether to modify the input store directly (default: false)
   * @returns A MigrationResult containing the migrated store or an error
   *
   * @example
   * ```ts
   * const snapshot = {
   *   schema: { schemaVersion: 2, sequences: { 'com.tldraw.book': 1 } },
   *   store: {
   *     'book:1': { id: 'book:1', typeName: 'book', title: 'Old Book', publishDate: '2020-01-01' }
   *   }
   * }
   *
   * const result = schema.migrateStoreSnapshot(snapshot)
   * if (result.type === 'success') {
   *   console.log('Migrated store:', result.value)
   *   // All records are now at current schema version
   * }
   * ```
   *
   * @public
   */ migrateStoreSnapshot(snapshot, opts) {
        const migrations = this.getMigrationsSince(snapshot.schema);
        if (!migrations.ok) {
            console.error("Error migrating store", migrations.error);
            return {
                type: "error",
                reason: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].MigrationError
            };
        }
        const migrationsToApply = migrations.value;
        if (migrationsToApply.length === 0) {
            return {
                type: "success",
                value: snapshot.store
            };
        }
        const store = Object.assign(new Map((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(snapshot.store).map(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"])), {
            getSchema: ()=>snapshot.schema,
            setSchema: (_)=>{}
        });
        try {
            this.migrateStorage(store);
            if (opts?.mutateInputStore) {
                for (const [id, record] of store.entries()){
                    snapshot.store[id] = record;
                }
                for (const id of Object.keys(snapshot.store)){
                    if (!store.has(id)) {
                        delete snapshot.store[id];
                    }
                }
                return {
                    type: "success",
                    value: snapshot.store
                };
            } else {
                return {
                    type: "success",
                    value: Object.fromEntries(store.entries())
                };
            }
        } catch (e) {
            console.error("Error migrating store", e);
            return {
                type: "error",
                reason: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"].MigrationError
            };
        }
    }
    /**
   * Creates an integrity checker function for the given store.
   *
   * This method calls the createIntegrityChecker option if provided, allowing
   * custom integrity checking logic to be set up for the store. The integrity
   * checker is used to validate store consistency and catch data corruption.
   *
   * @param store - The store instance to create an integrity checker for
   * @returns An integrity checker function, or undefined if none is configured
   *
   * @internal
   */ createIntegrityChecker(store) {
        return this.options.createIntegrityChecker?.(store) ?? void 0;
    }
    /**
   * Serializes the current schema to a SerializedSchemaV2 format.
   *
   * This method creates a serialized representation of the current schema,
   * capturing the latest version number for each migration sequence.
   * The result can be persisted and later used to determine what migrations
   * need to be applied when loading data.
   *
   * @returns A SerializedSchemaV2 object representing the current schema state
   *
   * @example
   * ```ts
   * const serialized = schema.serialize()
   * console.log(serialized)
   * // {
   * //   schemaVersion: 2,
   * //   sequences: {
   * //     'com.tldraw.book': 3,
   * //     'com.tldraw.author': 2
   * //   }
   * // }
   *
   * // Store this with your data for future migrations
   * localStorage.setItem('schema', JSON.stringify(serialized))
   * ```
   *
   * @public
   */ serialize() {
        return {
            schemaVersion: 2,
            sequences: Object.fromEntries(Object.values(this.migrations).map(({ sequenceId, sequence })=>[
                    sequenceId,
                    sequence.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMigrationId"])(sequence.at(-1).id).version : 0
                ]))
        };
    }
    /**
   * Serializes a schema representing the earliest possible version.
   *
   * This method creates a serialized schema where all migration sequences
   * are set to version 0, representing the state before any migrations
   * have been applied. This is used in specific legacy scenarios.
   *
   * @returns A SerializedSchema with all sequences set to version 0
   *
   * @deprecated This is only here for legacy reasons, don't use it unless you have david's blessing!
   * @internal
   */ serializeEarliestVersion() {
        return {
            schemaVersion: 2,
            sequences: Object.fromEntries(Object.values(this.migrations).map(({ sequenceId })=>[
                    sequenceId,
                    0
                ]))
        };
    }
    /**
   * Gets the RecordType definition for a given type name.
   *
   * This method retrieves the RecordType associated with the specified
   * type name, which contains the record's validation, creation, and
   * other behavioral logic.
   *
   * @param typeName - The name of the record type to retrieve
   * @returns The RecordType definition for the specified type
   *
   * @throws Will throw an error if the record type does not exist
   *
   * @internal
   */ getType(typeName) {
        const type = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(this.types, typeName);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(type, "record type does not exists");
        return type;
    }
}
;
 //# sourceMappingURL=StoreSchema.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/version.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomSet.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/devFreeze.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/IncrementalSetConstructor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/Store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreQueries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreQueries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSideEffects.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$version$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerTldrawLibraryVersion"])("@tldraw/store", "4.4.0", "esm");
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AtomMap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomMap"],
    "AtomSet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomSet"],
    "IncrementalSetConstructor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IncrementalSetConstructor"],
    "MigrationFailureReason",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrationFailureReason"],
    "RecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecordType"],
    "Store",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Store"],
    "StoreQueries",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreQueries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreQueries"],
    "StoreSchema",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreSchema"],
    "StoreSideEffects",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreSideEffects"],
    "assertIdType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertIdType"],
    "createComputedCache",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createComputedCache"],
    "createEmptyRecordsDiff",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyRecordsDiff"],
    "createMigrationIds",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationIds"],
    "createMigrationSequence",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMigrationSequence"],
    "createRecordMigrationSequence",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordMigrationSequence"],
    "createRecordType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecordType"],
    "devFreeze",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devFreeze"],
    "isRecordsDiffEmpty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecordsDiffEmpty"],
    "parseMigrationId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMigrationId"],
    "reverseRecordsDiff",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseRecordsDiff"],
    "squashRecordDiffs",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffs"],
    "squashRecordDiffsMutable",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffsMutable"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomSet.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$devFreeze$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/devFreeze.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/IncrementalSetConstructor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$migrate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/migrate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$Store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/Store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreQueries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreQueries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSchema$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSchema.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$StoreSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/StoreSideEffects.mjs [app-client] (ecmascript)");
}),
]);

//# debugId=97773388-622b-5076-90b7-1e334d3ead21
//# sourceMappingURL=c427b_%40tldraw_store_dist-esm_a0dd011a._.js.map