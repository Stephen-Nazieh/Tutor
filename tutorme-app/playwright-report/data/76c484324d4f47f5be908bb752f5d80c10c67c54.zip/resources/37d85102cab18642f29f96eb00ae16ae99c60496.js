;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="f3b86a4f-4084-629d-3391-49ea5c883099")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_pdfjs-dist_build_pdf_mjs_33f16c54._.js",
  "static/chunks/c427b_pdfjs-dist_build_pdf_mjs_51659610._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/mammoth/lib/index.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_underscore_modules_c63821e9._.js",
  "static/chunks/c427b_bluebird_js_release_c289a32a._.js",
  "static/chunks/c427b_mammoth_3d75a30d._.js",
  "static/chunks/c427b_next_dist_compiled_5312d3e5._.js",
  "static/chunks/c427b_jszip_lib_93b2295a._.js",
  "static/chunks/c427b_pako_8648a612._.js",
  "static/chunks/c427b_@xmldom_xmldom_lib_c99d8eb1._.js",
  "static/chunks/c427b_dingbat-to-unicode_dist_67c499b4._.js",
  "static/chunks/c427b_a69845f2._.js",
  "static/chunks/c427b_mammoth_lib_index_51659610.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/mammoth/lib/index.js [app-client] (ecmascript)");
    });
});
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tesseract.js/src/index.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_0f7d4d15._.js",
  "static/chunks/c427b_tesseract_js_src_index_51659610.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tesseract.js/src/index.js [app-client] (ecmascript)");
    });
});
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_html2canvas_dist_html2canvas_e88702bb.js",
  "static/chunks/c427b_html2canvas_dist_html2canvas_51659610.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript)");
    });
});
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_dompurify_dist_purify_es_mjs_aa44ab58._.js",
  "static/chunks/c427b_dompurify_dist_purify_es_mjs_51659610._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/canvg/lib/index.es.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/c427b_6ee93dbb._.js",
  "static/chunks/c427b_canvg_lib_index_es_51659610.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/canvg/lib/index.es.js [app-client] (ecmascript)");
    });
});
}),
]);

//# debugId=f3b86a4f-4084-629d-3391-49ea5c883099