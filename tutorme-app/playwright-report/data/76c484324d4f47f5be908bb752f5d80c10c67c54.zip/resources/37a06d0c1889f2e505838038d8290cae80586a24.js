;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="6d08de2f-227e-5d2a-6f67-ecc8e28db2c4")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 min-h-[44px] sm:min-h-0 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/input.tsx",
        lineNumber: 11,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/card.tsx",
        lineNumber: 71,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Card$React.forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$React.forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$React.forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$React.forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$React.forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$React.forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "badgeVariants",
    ()=>badgeVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/badge.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = Badge;
;
var _c;
__turbopack_context__.k.register(_c, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ScrollArea",
    ()=>ScrollArea,
    "ScrollBar",
    ()=>ScrollBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const ScrollArea = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative overflow-hidden", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
                className: "h-full w-full rounded-[inherit]",
                children: children
            }, void 0, false, {
                fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
                lineNumber: 17,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollBar, {}, void 0, false, {
                fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
                lineNumber: 20,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Corner"], {}, void 0, false, {
                fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
                lineNumber: 21,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = ScrollArea;
ScrollArea.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
const ScrollBar = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, orientation = "vertical", ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollAreaScrollbar"], {
        ref: ref,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollAreaThumb"], {
            className: "relative flex-1 rounded-full bg-border"
        }, void 0, false, {
            fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
            lineNumber: 43,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/scroll-area.tsx",
        lineNumber: 30,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c2 = ScrollBar;
ScrollBar.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollAreaScrollbar"].displayName;
;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ScrollArea$React.forwardRef");
__turbopack_context__.k.register(_c1, "ScrollArea");
__turbopack_context__.k.register(_c2, "ScrollBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/progress.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Progress",
    ()=>Progress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-progress/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Progress = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, value, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Indicator"], {
            className: "h-full w-full flex-1 bg-primary transition-all",
            style: {
                transform: `translateX(-${100 - (value || 0)}%)`
            }
        }, void 0, false, {
            fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/progress.tsx",
            lineNumber: 20,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/progress.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Progress;
Progress.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Progress$React.forwardRef");
__turbopack_context__.k.register(_c1, "Progress");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/tabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Tabs = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const TabsList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/tabs.tsx",
        lineNumber: 14,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = TabsList;
TabsList.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"].displayName;
const TabsTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/tabs.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c3 = TabsTrigger;
TabsTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const TabsContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/tabs.tsx",
        lineNumber: 44,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = TabsContent;
TabsContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "TabsList$React.forwardRef");
__turbopack_context__.k.register(_c1, "TabsList");
__turbopack_context__.k.register(_c2, "TabsTrigger$React.forwardRef");
__turbopack_context__.k.register(_c3, "TabsTrigger");
__turbopack_context__.k.register(_c4, "TabsContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "TabsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/avatar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Avatar",
    ()=>Avatar,
    "AvatarFallback",
    ()=>AvatarFallback,
    "AvatarImage",
    ()=>AvatarImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-avatar/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const Avatar = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/avatar.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Avatar;
Avatar.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
const AvatarImage = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('aspect-square h-full w-full', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/avatar.tsx",
        lineNumber: 27,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c3 = AvatarImage;
AvatarImage.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"].displayName;
const AvatarFallback = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fallback"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex h-full w-full items-center justify-center rounded-full bg-muted', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/avatar.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = AvatarFallback;
AvatarFallback.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fallback"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Avatar$React.forwardRef");
__turbopack_context__.k.register(_c1, "Avatar");
__turbopack_context__.k.register(_c2, "AvatarImage$React.forwardRef");
__turbopack_context__.k.register(_c3, "AvatarImage");
__turbopack_context__.k.register(_c4, "AvatarFallback$React.forwardRef");
__turbopack_context__.k.register(_c5, "AvatarFallback");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/checkbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-checkbox/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Checkbox = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Indicator"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/checkbox.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/checkbox.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Checkbox;
Checkbox.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Checkbox$React.forwardRef");
__turbopack_context__.k.register(_c1, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/popover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Popover",
    ()=>Popover,
    "PopoverContent",
    ()=>PopoverContent,
    "PopoverTrigger",
    ()=>PopoverTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-popover/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const Popover = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const PopoverTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"];
const PopoverContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, align = 'center', sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            ref: ref,
            align: align,
            sideOffset: sideOffset,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2', className),
            ...props
        }, void 0, false, {
            fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/popover.tsx",
            lineNumber: 17,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/popover.tsx",
        lineNumber: 16,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = PopoverContent;
PopoverContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "PopoverContent$React.forwardRef");
__turbopack_context__.k.register(_c1, "PopoverContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/calendar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Calendar",
    ()=>Calendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$react$2d$day$2d$picker$2f$dist$2f$esm$2f$DayPicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/react-day-picker/dist/esm/DayPicker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function Calendar({ className, classNames, showOutsideDays = true, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$react$2d$day$2d$picker$2f$dist$2f$esm$2f$DayPicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DayPicker"], {
        showOutsideDays: showOutsideDays,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-3", className),
        classNames: {
            months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
            month: "space-y-4",
            caption: "flex justify-center pt-1 relative items-center",
            caption_label: "text-sm font-medium",
            nav: "space-x-1 flex items-center",
            nav_button: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                variant: "outline"
            }), "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"),
            nav_button_previous: "absolute left-1",
            nav_button_next: "absolute right-1",
            table: "w-full border-collapse space-y-1",
            head_row: "flex w-full justify-between mb-2",
            head_cell: "text-muted-foreground w-10 font-normal text-[0.65rem] text-center uppercase",
            row: "flex w-full justify-between mt-2",
            cell: "w-10 h-10 text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-md [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
            day: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                variant: "ghost"
            }), "h-9 w-9 p-0 font-normal aria-selected:opacity-100"),
            day_range_end: "day-range-end",
            day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
            day_today: "bg-accent text-accent-foreground",
            day_outside: "day-outside text-muted-foreground opacity-50 aria-selected:bg-accent/50 aria-selected:text-muted-foreground aria-selected:opacity-30",
            day_disabled: "text-muted-foreground opacity-50",
            day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
            day_hidden: "invisible",
            ...classNames
        },
        components: {
            PreviousMonthButton: ({ ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                    className: "h-4 w-4"
                }, void 0, false, {
                    fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/calendar.tsx",
                    lineNumber: 57,
                    columnNumber: 48
                }, void 0),
            NextMonthButton: ({ ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                    className: "h-4 w-4"
                }, void 0, false, {
                    fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/calendar.tsx",
                    lineNumber: 58,
                    columnNumber: 44
                }, void 0)
        },
        ...props
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/calendar.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = Calendar;
Calendar.displayName = "Calendar";
;
var _c;
__turbopack_context__.k.register(_c, "Calendar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/switch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Switch",
    ()=>Switch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@radix-ui/react-switch/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Switch = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
        ...props,
        ref: ref,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Thumb"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0")
        }, void 0, false, {
            fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/switch.tsx",
            lineNumber: 20,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/components/ui/switch.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Switch;
Switch.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Switch$React.forwardRef");
__turbopack_context__.k.register(_c1, "Switch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/format-currency.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatEarnings",
    ()=>formatEarnings
]);
/**
 * Format earnings for display using the tutor's preferred currency from settings.
 */ const CURRENCY_SYMBOLS = {
    SGD: 'S$',
    USD: '$',
    EUR: '€',
    GBP: '£',
    CNY: '¥',
    JPY: '¥'
};
function formatEarnings(amount, currencyCode) {
    const code = (currencyCode || 'SGD').toUpperCase();
    const symbol = CURRENCY_SYMBOLS[code];
    const formatted = amount.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
    if (symbol) return `${symbol}${formatted}`;
    return `${formatted} ${code}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/lib/format-class-time.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatClassTime",
    ()=>formatClassTime
]);
/**
 * Format class scheduled time for display.
 * Uses browser timezone. Returns relative "Starts in X" for near-term classes (within 24 hours).
 */ const MS_MINUTE = 60 * 1000;
const MS_HOUR = 60 * MS_MINUTE;
const MS_DAY = 24 * MS_HOUR;
function formatClassTime(scheduledAt) {
    const date = typeof scheduledAt === 'string' ? new Date(scheduledAt) : scheduledAt;
    const now = new Date();
    const formatted = date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    const ms = date.getTime() - now.getTime();
    if (ms < 0) {
        return {
            formatted
        };
    }
    if (ms < MS_HOUR) {
        const minutes = Math.round(ms / MS_MINUTE);
        return {
            formatted,
            relative: minutes <= 1 ? 'Starting soon' : `Starts in ${minutes} minutes`
        };
    }
    if (ms < MS_DAY) {
        const hours = Math.round(ms / MS_HOUR);
        return {
            formatted,
            relative: hours === 1 ? 'Starts in 1 hour' : `Starts in ${hours} hours`
        };
    }
    if (ms < 2 * MS_DAY) {
        return {
            formatted,
            relative: `Tomorrow at ${date.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            })}`
        };
    }
    return {
        formatted
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/src/stores/communication-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAiReplies",
    ()=>useAiReplies,
    "useCommunicationActions",
    ()=>useCommunicationActions,
    "useCommunicationStore",
    ()=>useCommunicationStore,
    "useComposeAttachments",
    ()=>useComposeAttachments,
    "useComposeMessage",
    ()=>useComposeMessage,
    "useComposePriority",
    ()=>useComposePriority,
    "useComposeSubject",
    ()=>useComposeSubject,
    "useComposeTo",
    ()=>useComposeTo,
    "useFilter",
    ()=>useFilter,
    "useFilteredMessages",
    ()=>useFilteredMessages,
    "useIsRecordingVoice",
    ()=>useIsRecordingVoice,
    "useIsScheduling",
    ()=>useIsScheduling,
    "useIsWebSocketConnected",
    ()=>useIsWebSocketConnected,
    "useLabels",
    ()=>useLabels,
    "useMessageStats",
    ()=>useMessageStats,
    "useMessages",
    ()=>useMessages,
    "usePresenceStatus",
    ()=>usePresenceStatus,
    "usePresenceStatusForUser",
    ()=>usePresenceStatusForUser,
    "useQuickReplies",
    ()=>useQuickReplies,
    "useReplyText",
    ()=>useReplyText,
    "useScheduledDate",
    ()=>useScheduledDate,
    "useScheduledTime",
    ()=>useScheduledTime,
    "useSearchQuery",
    ()=>useSearchQuery,
    "useSelectedLabels",
    ()=>useSelectedLabels,
    "useSelectedMessage",
    ()=>useSelectedMessage,
    "useSelectedMessages",
    ()=>useSelectedMessages,
    "useShowAIReplies",
    ()=>useShowAIReplies,
    "useShowAnalytics",
    ()=>useShowAnalytics,
    "useShowAnnouncement",
    ()=>useShowAnnouncement,
    "useShowCompose",
    ()=>useShowCompose,
    "useShowFilters",
    ()=>useShowFilters,
    "useShowMultiSelect",
    ()=>useShowMultiSelect,
    "useShowQuickRepliesManager",
    ()=>useShowQuickRepliesManager,
    "useShowTemplates",
    ()=>useShowTemplates,
    "useShowThread",
    ()=>useShowThread,
    "useTemplates",
    ()=>useTemplates,
    "useThreadMessages",
    ()=>useThreadMessages,
    "useTypingIndicators",
    ()=>useTypingIndicators,
    "useVoiceRecordingDuration",
    ()=>useVoiceRecordingDuration
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature(), _s10 = __turbopack_context__.k.signature(), _s11 = __turbopack_context__.k.signature(), _s12 = __turbopack_context__.k.signature(), _s13 = __turbopack_context__.k.signature(), _s14 = __turbopack_context__.k.signature(), _s15 = __turbopack_context__.k.signature(), _s16 = __turbopack_context__.k.signature(), _s17 = __turbopack_context__.k.signature(), _s18 = __turbopack_context__.k.signature(), _s19 = __turbopack_context__.k.signature(), _s20 = __turbopack_context__.k.signature(), _s21 = __turbopack_context__.k.signature(), _s22 = __turbopack_context__.k.signature(), _s23 = __turbopack_context__.k.signature(), _s24 = __turbopack_context__.k.signature(), _s25 = __turbopack_context__.k.signature(), _s26 = __turbopack_context__.k.signature(), _s27 = __turbopack_context__.k.signature(), _s28 = __turbopack_context__.k.signature(), _s29 = __turbopack_context__.k.signature(), _s30 = __turbopack_context__.k.signature(), _s31 = __turbopack_context__.k.signature(), _s32 = __turbopack_context__.k.signature(), _s33 = __turbopack_context__.k.signature(), _s34 = __turbopack_context__.k.signature(), _s35 = __turbopack_context__.k.signature(), _s36 = __turbopack_context__.k.signature(), _s37 = __turbopack_context__.k.signature();
;
;
// ============================================
// INITIAL STATE
// ============================================
const generateDemoMessages = ()=>[
        {
            id: '1',
            studentId: 's1',
            studentName: 'Alice Zhang',
            subject: 'Question about homework',
            content: 'Hi, I\'m having trouble understanding problem 3 from yesterday\'s assignment. Could you explain the concept of derivatives again?',
            timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            isRead: false,
            isStarred: true,
            priority: 'high',
            course: 'Advanced Mathematics',
            type: 'message',
            labels: [
                'homework',
                'urgent'
            ],
            replyCount: 2,
            attachments: []
        },
        {
            id: '2',
            studentId: 's2',
            studentName: 'Bob Li',
            subject: 'Missed class notification',
            content: 'I won\'t be able to attend tomorrow\'s class due to a family event. Will there be a recording available?',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
            isRead: false,
            isStarred: false,
            priority: 'normal',
            course: 'Physics 101',
            type: 'message',
            labels: [
                'attendance'
            ],
            attachments: []
        },
        {
            id: '3',
            studentId: 's3',
            studentName: 'Carol Wang',
            subject: 'Thank you!',
            content: 'Just wanted to say thanks for the extra help yesterday. I finally understood the concept!',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
            isRead: true,
            isStarred: false,
            priority: 'low',
            course: 'English Literature',
            type: 'message',
            readAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
            labels: [
                'feedback'
            ],
            attachments: []
        },
        {
            id: '4',
            studentId: 'system',
            studentName: 'System',
            subject: 'New student enrolled',
            content: 'A new student has enrolled in your Advanced Mathematics course.',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
            isRead: true,
            isStarred: false,
            priority: 'normal',
            type: 'system',
            attachments: []
        },
        {
            id: '5',
            studentId: 's4',
            studentName: 'David Chen',
            subject: 'Assignment extension request',
            content: 'I\'m facing some technical issues with my laptop. Could I get a 2-day extension for the upcoming assignment?',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
            isRead: true,
            isStarred: true,
            priority: 'high',
            course: 'Advanced Mathematics',
            type: 'message',
            labels: [
                'extension',
                'technical'
            ],
            attachments: [
                {
                    id: 'a1',
                    name: 'error-screenshot.png',
                    type: 'image',
                    url: '#',
                    size: 1024000
                }
            ]
        },
        {
            id: '6',
            studentId: 's5',
            studentName: 'Emma Liu',
            subject: 'Voice message',
            content: '[Voice message]',
            timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
            isRead: false,
            isStarred: false,
            priority: 'normal',
            course: 'Physics 101',
            type: 'message',
            voiceUrl: '#',
            voiceDuration: 45,
            attachments: []
        }
    ];
const generateDemoTemplates = ()=>[
        {
            id: '1',
            title: 'Welcome Message',
            content: 'Welcome to the course! I\'m excited to have you join us. If you have any questions, feel free to reach out.',
            category: 'general'
        },
        {
            id: '2',
            title: 'Assignment Reminder',
            content: 'Just a friendly reminder that the assignment is due tomorrow. Let me know if you need any help!',
            category: 'reminder'
        },
        {
            id: '3',
            title: 'Great Work!',
            content: 'Excellent work on the recent assignment! Your understanding of the concepts has really improved.',
            category: 'feedback'
        },
        {
            id: '4',
            title: 'Class Cancellation',
            content: 'Unfortunately, tomorrow\'s class is cancelled due to unforeseen circumstances. We\'ll reschedule soon.',
            category: 'course'
        },
        {
            id: '5',
            title: 'Technical Support',
            content: 'I understand you\'re experiencing technical difficulties. Let\'s troubleshoot this together.',
            category: 'technical'
        }
    ];
const generateQuickReplies = ()=>[
        {
            id: '1',
            title: 'Thank you',
            content: 'Thank you for reaching out!',
            shortcut: '/ty'
        },
        {
            id: '2',
            title: 'Will check',
            content: 'I\'ll look into this and get back to you shortly.',
            shortcut: '/check'
        },
        {
            id: '3',
            title: 'Great job',
            content: 'Great work! Keep it up!',
            shortcut: '/great'
        },
        {
            id: '4',
            title: 'See you in class',
            content: 'Looking forward to seeing you in class!',
            shortcut: '/class'
        }
    ];
const LABELS = [
    {
        id: 'homework',
        name: 'Homework',
        color: 'bg-blue-100 text-blue-700 border-blue-200'
    },
    {
        id: 'urgent',
        name: 'Urgent',
        color: 'bg-red-100 text-red-700 border-red-200'
    },
    {
        id: 'feedback',
        name: 'Feedback',
        color: 'bg-green-100 text-green-700 border-green-200'
    },
    {
        id: 'technical',
        name: 'Technical',
        color: 'bg-purple-100 text-purple-700 border-purple-200'
    },
    {
        id: 'attendance',
        name: 'Attendance',
        color: 'bg-yellow-100 text-yellow-700 border-yellow-200'
    },
    {
        id: 'extension',
        name: 'Extension',
        color: 'bg-orange-100 text-orange-700 border-orange-200'
    }
];
const initialState = {
    messages: generateDemoMessages(),
    templates: generateDemoTemplates(),
    quickReplies: generateQuickReplies(),
    labels: LABELS,
    searchQuery: '',
    filter: 'all',
    selectedMessage: null,
    selectedMessages: new Set(),
    showMultiSelect: false,
    showCompose: false,
    showTemplates: false,
    showAnnouncement: false,
    showQuickRepliesManager: false,
    showAnalytics: false,
    showFilters: false,
    replyText: '',
    showAIReplies: false,
    aiReplies: [],
    isRecordingVoice: false,
    voiceRecordingDuration: 0,
    isScheduling: false,
    scheduledDate: undefined,
    scheduledTime: '09:00',
    showThread: false,
    threadMessages: [],
    typingIndicators: [],
    presenceStatus: {},
    isWebSocketConnected: false,
    composeTo: '',
    composeSubject: '',
    composeMessage: '',
    composeAttachments: [],
    selectedLabels: [],
    composePriority: 'normal'
};
const useCommunicationStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((set, get)=>({
        ...initialState,
        // Core data actions
        setMessages: (messages)=>set((state)=>{
                state.messages = messages;
            }),
        addMessage: (message)=>set((state)=>{
                state.messages.unshift(message);
            }),
        updateMessage: (messageId, updates)=>set((state)=>{
                const index = state.messages.findIndex((m)=>m.id === messageId);
                if (index !== -1) {
                    state.messages[index] = {
                        ...state.messages[index],
                        ...updates
                    };
                }
            }),
        deleteMessage: (messageId)=>set((state)=>{
                state.messages = state.messages.filter((m)=>m.id !== messageId);
            }),
        setTemplates: (templates)=>set((state)=>{
                state.templates = templates;
            }),
        setQuickReplies: (replies)=>set((state)=>{
                state.quickReplies = replies;
            }),
        // UI actions
        setSearchQuery: (query)=>set((state)=>{
                state.searchQuery = query;
            }),
        setFilter: (filter)=>set((state)=>{
                state.filter = filter;
            }),
        setSelectedMessage: (message)=>set((state)=>{
                state.selectedMessage = message;
            }),
        toggleMessageSelection: (messageId)=>set((state)=>{
                const newSet = new Set(state.selectedMessages);
                if (newSet.has(messageId)) {
                    newSet.delete(messageId);
                } else {
                    newSet.add(messageId);
                }
                state.selectedMessages = newSet;
            }),
        setSelectedMessages: (messageIds)=>set((state)=>{
                state.selectedMessages = messageIds;
            }),
        setShowMultiSelect: (show)=>set((state)=>{
                state.showMultiSelect = show;
            }),
        // Dialog actions
        setShowCompose: (show)=>set((state)=>{
                state.showCompose = show;
            }),
        setShowTemplates: (show)=>set((state)=>{
                state.showTemplates = show;
            }),
        setShowAnnouncement: (show)=>set((state)=>{
                state.showAnnouncement = show;
            }),
        setShowQuickRepliesManager: (show)=>set((state)=>{
                state.showQuickRepliesManager = show;
            }),
        setShowAnalytics: (show)=>set((state)=>{
                state.showAnalytics = show;
            }),
        setShowFilters: (show)=>set((state)=>{
                state.showFilters = show;
            }),
        // Reply actions
        setReplyText: (text)=>set((state)=>{
                state.replyText = text;
            }),
        setShowAIReplies: (show)=>set((state)=>{
                state.showAIReplies = show;
            }),
        setAiReplies: (replies)=>set((state)=>{
                state.aiReplies = replies;
            }),
        setIsRecordingVoice: (recording)=>set((state)=>{
                state.isRecordingVoice = recording;
            }),
        setVoiceRecordingDuration: (duration)=>set((state)=>{
                state.voiceRecordingDuration = duration;
            }),
        incrementVoiceDuration: ()=>set((state)=>{
                state.voiceRecordingDuration += 1;
            }),
        // Scheduling actions
        setIsScheduling: (scheduling)=>set((state)=>{
                state.isScheduling = scheduling;
            }),
        setScheduledDate: (date)=>set((state)=>{
                state.scheduledDate = date;
            }),
        setScheduledTime: (time)=>set((state)=>{
                state.scheduledTime = time;
            }),
        // Thread actions
        setShowThread: (show)=>set((state)=>{
                state.showThread = show;
            }),
        setThreadMessages: (messages)=>set((state)=>{
                state.threadMessages = messages;
            }),
        // Real-time actions
        addTypingIndicator: (indicator)=>set((state)=>{
                state.typingIndicators.push(indicator);
            }),
        removeTypingIndicator: (userId)=>set((state)=>{
                state.typingIndicators = state.typingIndicators.filter((t)=>t.userId !== userId);
            }),
        clearExpiredTypingIndicators: ()=>set((state)=>{
                const now = Date.now();
                state.typingIndicators = state.typingIndicators.filter((t)=>now - t.timestamp < 3000);
            }),
        setPresenceStatus: (statuses)=>set((state)=>{
                state.presenceStatus = statuses;
            }),
        updatePresenceStatus: (userId, status)=>set((state)=>{
                state.presenceStatus[userId] = status;
            }),
        setIsWebSocketConnected: (connected)=>set((state)=>{
                state.isWebSocketConnected = connected;
            }),
        // Compose form actions
        setComposeTo: (to)=>set((state)=>{
                state.composeTo = to;
            }),
        setComposeSubject: (subject)=>set((state)=>{
                state.composeSubject = subject;
            }),
        setComposeMessage: (message)=>set((state)=>{
                state.composeMessage = message;
            }),
        addComposeAttachment: (attachment)=>set((state)=>{
                state.composeAttachments.push(attachment);
            }),
        removeComposeAttachment: (attachmentId)=>set((state)=>{
                state.composeAttachments = state.composeAttachments.filter((a)=>a.id !== attachmentId);
            }),
        clearComposeAttachments: ()=>set((state)=>{
                state.composeAttachments = [];
            }),
        toggleSelectedLabel: (labelId)=>set((state)=>{
                if (state.selectedLabels.includes(labelId)) {
                    state.selectedLabels = state.selectedLabels.filter((l)=>l !== labelId);
                } else {
                    state.selectedLabels.push(labelId);
                }
            }),
        setSelectedLabels: (labels)=>set((state)=>{
                state.selectedLabels = labels;
            }),
        setComposePriority: (priority)=>set((state)=>{
                state.composePriority = priority;
            }),
        resetComposeForm: ()=>set((state)=>{
                state.composeTo = '';
                state.composeSubject = '';
                state.composeMessage = '';
                state.composeAttachments = [];
                state.selectedLabels = [];
                state.composePriority = 'normal';
            }),
        // Bulk actions
        bulkMarkAsRead: (messageIds)=>set((state)=>{
                state.messages.forEach((msg)=>{
                    if (messageIds.has(msg.id)) {
                        msg.isRead = true;
                        msg.readAt = new Date().toISOString();
                    }
                });
            }),
        bulkMarkAsUnread: (messageIds)=>set((state)=>{
                state.messages.forEach((msg)=>{
                    if (messageIds.has(msg.id)) {
                        msg.isRead = false;
                        msg.readAt = undefined;
                    }
                });
            }),
        bulkToggleStar: (messageIds)=>set((state)=>{
                state.messages.forEach((msg)=>{
                    if (messageIds.has(msg.id)) {
                        msg.isStarred = !msg.isStarred;
                    }
                });
            }),
        bulkDelete: (messageIds)=>set((state)=>{
                state.messages = state.messages.filter((m)=>!messageIds.has(m.id));
            }),
        bulkArchive: (messageIds)=>set((state)=>{
                state.messages.forEach((msg)=>{
                    if (messageIds.has(msg.id)) {
                        msg.type = 'message';
                    }
                });
            }),
        // Message actions
        toggleMessageStar: (messageId)=>set((state)=>{
                const msg = state.messages.find((m)=>m.id === messageId);
                if (msg) {
                    msg.isStarred = !msg.isStarred;
                }
                if (state.selectedMessage?.id === messageId) {
                    state.selectedMessage.isStarred = !state.selectedMessage.isStarred;
                }
            }),
        markMessageAsRead: (messageId)=>set((state)=>{
                const msg = state.messages.find((m)=>m.id === messageId);
                if (msg) {
                    msg.isRead = true;
                    msg.readAt = new Date().toISOString();
                }
                if (state.selectedMessage?.id === messageId) {
                    state.selectedMessage.isRead = true;
                    state.selectedMessage.readAt = new Date().toISOString();
                }
            }),
        addLabelToMessage: (messageId, labelId)=>set((state)=>{
                const msg = state.messages.find((m)=>m.id === messageId);
                if (msg) {
                    const labels = msg.labels || [];
                    if (!labels.includes(labelId)) {
                        msg.labels = [
                            ...labels,
                            labelId
                        ];
                    }
                }
                if (state.selectedMessage?.id === messageId) {
                    const labels = state.selectedMessage.labels || [];
                    if (!labels.includes(labelId)) {
                        state.selectedMessage.labels = [
                            ...labels,
                            labelId
                        ];
                    }
                }
            }),
        removeLabelFromMessage: (messageId, labelId)=>set((state)=>{
                const msg = state.messages.find((m)=>m.id === messageId);
                if (msg && msg.labels) {
                    msg.labels = msg.labels.filter((l)=>l !== labelId);
                }
                if (state.selectedMessage?.id === messageId && state.selectedMessage.labels) {
                    state.selectedMessage.labels = state.selectedMessage.labels.filter((l)=>l !== labelId);
                }
            }),
        translateMessage: (messageId, translatedContent, translatedFrom)=>set((state)=>{
                const msg = state.messages.find((m)=>m.id === messageId);
                if (msg) {
                    msg.translatedContent = translatedContent;
                    msg.translatedFrom = translatedFrom;
                }
                if (state.selectedMessage?.id === messageId) {
                    state.selectedMessage.translatedContent = translatedContent;
                    state.selectedMessage.translatedFrom = translatedFrom;
                }
            }),
        // Utility actions
        reset: ()=>set(()=>({
                    ...initialState
                }))
    })));
const useMessages = ()=>{
    _s();
    return useCommunicationStore({
        "useMessages.useCommunicationStore": (state)=>state.messages
    }["useMessages.useCommunicationStore"]);
};
_s(useMessages, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useTemplates = ()=>{
    _s1();
    return useCommunicationStore({
        "useTemplates.useCommunicationStore": (state)=>state.templates
    }["useTemplates.useCommunicationStore"]);
};
_s1(useTemplates, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useQuickReplies = ()=>{
    _s2();
    return useCommunicationStore({
        "useQuickReplies.useCommunicationStore": (state)=>state.quickReplies
    }["useQuickReplies.useCommunicationStore"]);
};
_s2(useQuickReplies, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useLabels = ()=>{
    _s3();
    return useCommunicationStore({
        "useLabels.useCommunicationStore": (state)=>state.labels
    }["useLabels.useCommunicationStore"]);
};
_s3(useLabels, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useFilteredMessages = ()=>{
    _s4();
    return useCommunicationStore({
        "useFilteredMessages.useCommunicationStore": (state)=>{
            const { messages, searchQuery, filter } = state;
            return messages.filter({
                "useFilteredMessages.useCommunicationStore": (msg)=>{
                    const matchesSearch = msg.studentName.toLowerCase().includes(searchQuery.toLowerCase()) || msg.subject.toLowerCase().includes(searchQuery.toLowerCase()) || msg.content.toLowerCase().includes(searchQuery.toLowerCase()) || msg.labels?.some({
                        "useFilteredMessages.useCommunicationStore": (l)=>l.toLowerCase().includes(searchQuery.toLowerCase())
                    }["useFilteredMessages.useCommunicationStore"]);
                    const matchesFilter = filter === 'all' || filter === 'unread' && !msg.isRead || filter === 'starred' && msg.isStarred || filter === 'high' && msg.priority === 'high' || filter === 'scheduled' && msg.isScheduled;
                    return matchesSearch && matchesFilter;
                }
            }["useFilteredMessages.useCommunicationStore"]);
        }
    }["useFilteredMessages.useCommunicationStore"]);
};
_s4(useFilteredMessages, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useMessageStats = ()=>{
    _s5();
    return useCommunicationStore({
        "useMessageStats.useCommunicationStore": (state)=>{
            const { messages } = state;
            return {
                total: messages.length,
                unread: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>!m.isRead
                }["useMessageStats.useCommunicationStore"]).length,
                unreadHighPriority: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>m.priority === 'high' && !m.isRead
                }["useMessageStats.useCommunicationStore"]).length,
                starred: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>m.isStarred
                }["useMessageStats.useCommunicationStore"]).length,
                withAttachments: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>m.attachments && m.attachments.length > 0
                }["useMessageStats.useCommunicationStore"]).length,
                scheduled: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>m.isScheduled
                }["useMessageStats.useCommunicationStore"]).length,
                responseTime: '2.5 hours',
                todayMessages: messages.filter({
                    "useMessageStats.useCommunicationStore": (m)=>new Date(m.timestamp).toDateString() === new Date().toDateString()
                }["useMessageStats.useCommunicationStore"]).length
            };
        }
    }["useMessageStats.useCommunicationStore"]);
};
_s5(useMessageStats, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useSearchQuery = ()=>{
    _s6();
    return useCommunicationStore({
        "useSearchQuery.useCommunicationStore": (state)=>state.searchQuery
    }["useSearchQuery.useCommunicationStore"]);
};
_s6(useSearchQuery, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useFilter = ()=>{
    _s7();
    return useCommunicationStore({
        "useFilter.useCommunicationStore": (state)=>state.filter
    }["useFilter.useCommunicationStore"]);
};
_s7(useFilter, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useSelectedMessage = ()=>{
    _s8();
    return useCommunicationStore({
        "useSelectedMessage.useCommunicationStore": (state)=>state.selectedMessage
    }["useSelectedMessage.useCommunicationStore"]);
};
_s8(useSelectedMessage, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useSelectedMessages = ()=>{
    _s9();
    return useCommunicationStore({
        "useSelectedMessages.useCommunicationStore": (state)=>state.selectedMessages
    }["useSelectedMessages.useCommunicationStore"]);
};
_s9(useSelectedMessages, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowMultiSelect = ()=>{
    _s10();
    return useCommunicationStore({
        "useShowMultiSelect.useCommunicationStore": (state)=>state.showMultiSelect
    }["useShowMultiSelect.useCommunicationStore"]);
};
_s10(useShowMultiSelect, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowCompose = ()=>{
    _s11();
    return useCommunicationStore({
        "useShowCompose.useCommunicationStore": (state)=>state.showCompose
    }["useShowCompose.useCommunicationStore"]);
};
_s11(useShowCompose, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowTemplates = ()=>{
    _s12();
    return useCommunicationStore({
        "useShowTemplates.useCommunicationStore": (state)=>state.showTemplates
    }["useShowTemplates.useCommunicationStore"]);
};
_s12(useShowTemplates, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowAnnouncement = ()=>{
    _s13();
    return useCommunicationStore({
        "useShowAnnouncement.useCommunicationStore": (state)=>state.showAnnouncement
    }["useShowAnnouncement.useCommunicationStore"]);
};
_s13(useShowAnnouncement, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowQuickRepliesManager = ()=>{
    _s14();
    return useCommunicationStore({
        "useShowQuickRepliesManager.useCommunicationStore": (state)=>state.showQuickRepliesManager
    }["useShowQuickRepliesManager.useCommunicationStore"]);
};
_s14(useShowQuickRepliesManager, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowAnalytics = ()=>{
    _s15();
    return useCommunicationStore({
        "useShowAnalytics.useCommunicationStore": (state)=>state.showAnalytics
    }["useShowAnalytics.useCommunicationStore"]);
};
_s15(useShowAnalytics, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowFilters = ()=>{
    _s16();
    return useCommunicationStore({
        "useShowFilters.useCommunicationStore": (state)=>state.showFilters
    }["useShowFilters.useCommunicationStore"]);
};
_s16(useShowFilters, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useReplyText = ()=>{
    _s17();
    return useCommunicationStore({
        "useReplyText.useCommunicationStore": (state)=>state.replyText
    }["useReplyText.useCommunicationStore"]);
};
_s17(useReplyText, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowAIReplies = ()=>{
    _s18();
    return useCommunicationStore({
        "useShowAIReplies.useCommunicationStore": (state)=>state.showAIReplies
    }["useShowAIReplies.useCommunicationStore"]);
};
_s18(useShowAIReplies, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useAiReplies = ()=>{
    _s19();
    return useCommunicationStore({
        "useAiReplies.useCommunicationStore": (state)=>state.aiReplies
    }["useAiReplies.useCommunicationStore"]);
};
_s19(useAiReplies, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useIsRecordingVoice = ()=>{
    _s20();
    return useCommunicationStore({
        "useIsRecordingVoice.useCommunicationStore": (state)=>state.isRecordingVoice
    }["useIsRecordingVoice.useCommunicationStore"]);
};
_s20(useIsRecordingVoice, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useVoiceRecordingDuration = ()=>{
    _s21();
    return useCommunicationStore({
        "useVoiceRecordingDuration.useCommunicationStore": (state)=>state.voiceRecordingDuration
    }["useVoiceRecordingDuration.useCommunicationStore"]);
};
_s21(useVoiceRecordingDuration, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useIsScheduling = ()=>{
    _s22();
    return useCommunicationStore({
        "useIsScheduling.useCommunicationStore": (state)=>state.isScheduling
    }["useIsScheduling.useCommunicationStore"]);
};
_s22(useIsScheduling, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useScheduledDate = ()=>{
    _s23();
    return useCommunicationStore({
        "useScheduledDate.useCommunicationStore": (state)=>state.scheduledDate
    }["useScheduledDate.useCommunicationStore"]);
};
_s23(useScheduledDate, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useScheduledTime = ()=>{
    _s24();
    return useCommunicationStore({
        "useScheduledTime.useCommunicationStore": (state)=>state.scheduledTime
    }["useScheduledTime.useCommunicationStore"]);
};
_s24(useScheduledTime, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useShowThread = ()=>{
    _s25();
    return useCommunicationStore({
        "useShowThread.useCommunicationStore": (state)=>state.showThread
    }["useShowThread.useCommunicationStore"]);
};
_s25(useShowThread, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useThreadMessages = ()=>{
    _s26();
    return useCommunicationStore({
        "useThreadMessages.useCommunicationStore": (state)=>state.threadMessages
    }["useThreadMessages.useCommunicationStore"]);
};
_s26(useThreadMessages, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useTypingIndicators = ()=>{
    _s27();
    return useCommunicationStore({
        "useTypingIndicators.useCommunicationStore": (state)=>state.typingIndicators
    }["useTypingIndicators.useCommunicationStore"]);
};
_s27(useTypingIndicators, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const usePresenceStatus = ()=>{
    _s28();
    return useCommunicationStore({
        "usePresenceStatus.useCommunicationStore": (state)=>state.presenceStatus
    }["usePresenceStatus.useCommunicationStore"]);
};
_s28(usePresenceStatus, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const usePresenceStatusForUser = (userId)=>{
    _s29();
    return useCommunicationStore({
        "usePresenceStatusForUser.useCommunicationStore": (state)=>state.presenceStatus[userId]
    }["usePresenceStatusForUser.useCommunicationStore"]);
};
_s29(usePresenceStatusForUser, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useIsWebSocketConnected = ()=>{
    _s30();
    return useCommunicationStore({
        "useIsWebSocketConnected.useCommunicationStore": (state)=>state.isWebSocketConnected
    }["useIsWebSocketConnected.useCommunicationStore"]);
};
_s30(useIsWebSocketConnected, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useComposeTo = ()=>{
    _s31();
    return useCommunicationStore({
        "useComposeTo.useCommunicationStore": (state)=>state.composeTo
    }["useComposeTo.useCommunicationStore"]);
};
_s31(useComposeTo, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useComposeSubject = ()=>{
    _s32();
    return useCommunicationStore({
        "useComposeSubject.useCommunicationStore": (state)=>state.composeSubject
    }["useComposeSubject.useCommunicationStore"]);
};
_s32(useComposeSubject, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useComposeMessage = ()=>{
    _s33();
    return useCommunicationStore({
        "useComposeMessage.useCommunicationStore": (state)=>state.composeMessage
    }["useComposeMessage.useCommunicationStore"]);
};
_s33(useComposeMessage, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useComposeAttachments = ()=>{
    _s34();
    return useCommunicationStore({
        "useComposeAttachments.useCommunicationStore": (state)=>state.composeAttachments
    }["useComposeAttachments.useCommunicationStore"]);
};
_s34(useComposeAttachments, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useSelectedLabels = ()=>{
    _s35();
    return useCommunicationStore({
        "useSelectedLabels.useCommunicationStore": (state)=>state.selectedLabels
    }["useSelectedLabels.useCommunicationStore"]);
};
_s35(useSelectedLabels, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useComposePriority = ()=>{
    _s36();
    return useCommunicationStore({
        "useComposePriority.useCommunicationStore": (state)=>state.composePriority
    }["useComposePriority.useCommunicationStore"]);
};
_s36(useComposePriority, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
const useCommunicationActions = ()=>{
    _s37();
    return useCommunicationStore({
        "useCommunicationActions.useCommunicationStore": (state)=>({
                // Core data
                setMessages: state.setMessages,
                addMessage: state.addMessage,
                updateMessage: state.updateMessage,
                deleteMessage: state.deleteMessage,
                setTemplates: state.setTemplates,
                setQuickReplies: state.setQuickReplies,
                // UI
                setSearchQuery: state.setSearchQuery,
                setFilter: state.setFilter,
                setSelectedMessage: state.setSelectedMessage,
                toggleMessageSelection: state.toggleMessageSelection,
                setSelectedMessages: state.setSelectedMessages,
                setShowMultiSelect: state.setShowMultiSelect,
                // Dialogs
                setShowCompose: state.setShowCompose,
                setShowTemplates: state.setShowTemplates,
                setShowAnnouncement: state.setShowAnnouncement,
                setShowQuickRepliesManager: state.setShowQuickRepliesManager,
                setShowAnalytics: state.setShowAnalytics,
                setShowFilters: state.setShowFilters,
                // Reply
                setReplyText: state.setReplyText,
                setShowAIReplies: state.setShowAIReplies,
                setAiReplies: state.setAiReplies,
                setIsRecordingVoice: state.setIsRecordingVoice,
                setVoiceRecordingDuration: state.setVoiceRecordingDuration,
                incrementVoiceDuration: state.incrementVoiceDuration,
                // Scheduling
                setIsScheduling: state.setIsScheduling,
                setScheduledDate: state.setScheduledDate,
                setScheduledTime: state.setScheduledTime,
                // Thread
                setShowThread: state.setShowThread,
                setThreadMessages: state.setThreadMessages,
                // Real-time
                addTypingIndicator: state.addTypingIndicator,
                removeTypingIndicator: state.removeTypingIndicator,
                clearExpiredTypingIndicators: state.clearExpiredTypingIndicators,
                setPresenceStatus: state.setPresenceStatus,
                updatePresenceStatus: state.updatePresenceStatus,
                setIsWebSocketConnected: state.setIsWebSocketConnected,
                // Compose form
                setComposeTo: state.setComposeTo,
                setComposeSubject: state.setComposeSubject,
                setComposeMessage: state.setComposeMessage,
                addComposeAttachment: state.addComposeAttachment,
                removeComposeAttachment: state.removeComposeAttachment,
                clearComposeAttachments: state.clearComposeAttachments,
                toggleSelectedLabel: state.toggleSelectedLabel,
                setSelectedLabels: state.setSelectedLabels,
                setComposePriority: state.setComposePriority,
                resetComposeForm: state.resetComposeForm,
                // Bulk actions
                bulkMarkAsRead: state.bulkMarkAsRead,
                bulkMarkAsUnread: state.bulkMarkAsUnread,
                bulkToggleStar: state.bulkToggleStar,
                bulkDelete: state.bulkDelete,
                bulkArchive: state.bulkArchive,
                // Message actions
                toggleMessageStar: state.toggleMessageStar,
                markMessageAsRead: state.markMessageAsRead,
                addLabelToMessage: state.addLabelToMessage,
                removeLabelFromMessage: state.removeLabelFromMessage,
                translateMessage: state.translateMessage,
                // Utility
                reset: state.reset
            })
    }["useCommunicationActions.useCommunicationStore"]);
};
_s37(useCommunicationActions, "Fu8FRrDLNZNlAxC3XjQsSL72ydQ=", false, function() {
    return [
        useCommunicationStore
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=6d08de2f-227e-5d2a-6f67-ecc8e28db2c4
//# sourceMappingURL=ADK_WORKSPACE_TutorMekimi_tutorme-app_src_c6045bab._.js.map