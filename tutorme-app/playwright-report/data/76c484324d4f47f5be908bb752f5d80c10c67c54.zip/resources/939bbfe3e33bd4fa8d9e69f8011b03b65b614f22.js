(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_b457534e._.js"
],
    source: "dynamic"
});
