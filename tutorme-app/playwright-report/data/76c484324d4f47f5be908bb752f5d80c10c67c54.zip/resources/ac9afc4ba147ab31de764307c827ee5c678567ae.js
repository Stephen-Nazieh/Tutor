;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="01b6a1b3-3c7d-8ee0-1121-3625c6f34aaa")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/defaultTranslation.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_TRANSLATION",
    ()=>DEFAULT_TRANSLATION
]);
const DEFAULT_TRANSLATION = {
    "action.toggle-auto-pan": "Auto (trackpad)",
    "action.toggle-auto-zoom": "Auto (mouse)",
    "action.toggle-auto-none": "Auto",
    "action.toggle-mouse": "Mouse",
    "action.toggle-trackpad": "Trackpad",
    "action.convert-to-bookmark": "Convert to bookmark",
    "action.convert-to-embed": "Convert to embed",
    "action.open-embed-link": "Open link",
    "action.align-bottom": "Align bottom",
    "action.align-center-horizontal": "Align horizontally",
    "action.align-center-vertical": "Align vertically",
    "action.align-center-horizontal.short": "Align H",
    "action.align-center-vertical.short": "Align V",
    "action.align-left": "Align left",
    "action.align-right": "Align right",
    "action.align-top": "Align top",
    "action.back-to-content": "Back to content",
    "action.bring-forward": "Bring forward",
    "action.bring-to-front": "Bring to front",
    "action.copy-as-png.short": "PNG",
    "action.copy-as-png": "Copy as PNG",
    "action.copy-as-svg.short": "SVG",
    "action.copy-as-svg": "Copy as SVG",
    "action.copy": "Copy",
    "action.cut": "Cut",
    "action.delete": "Delete",
    "action.unlock-all": "Unlock all",
    "action.distribute-horizontal": "Distribute horizontally",
    "action.distribute-vertical": "Distribute vertically",
    "action.distribute-horizontal.short": "Distribute H",
    "action.distribute-vertical.short": "Distribute V",
    "action.download-original": "Download original",
    "action.duplicate": "Duplicate",
    "action.edit-link": "Edit link\u2026",
    "action.exit-pen-mode": "Exit pen mode",
    "action.export-as-png.short": "PNG",
    "action.export-as-png": "Export as PNG",
    "action.export-as-svg.short": "SVG",
    "action.export-as-svg": "Export as SVG",
    "action.export-all-as-png.short": "PNG",
    "action.export-all-as-png": "Export as PNG",
    "action.export-all-as-svg.short": "SVG",
    "action.export-all-as-svg": "Export as SVG",
    "action.fit-frame-to-content": "Fit to content",
    "action.flip-horizontal": "Flip horizontally",
    "action.flip-vertical": "Flip vertically",
    "action.flip-horizontal.short": "Flip H",
    "action.flip-vertical.short": "Flip V",
    "action.fork-project": "Fork this project",
    "action.fork-project-on-tldraw": "Fork project on tldraw",
    "action.group": "Group",
    "action.insert-embed": "Insert embed\u2026",
    "action.insert-media": "Upload media\u2026",
    "action.leave-shared-project": "Leave shared project",
    "action.new-project": "New project",
    "action.new-shared-project": "New shared project",
    "action.open-cursor-chat": "Cursor chat",
    "action.open-kbd-shortcuts": "Keyboard shortcuts\u2026",
    "action.open-file": "Open file",
    "action.pack": "Pack",
    "action.paste": "Paste",
    "action.paste-error-title": "Pasting failed",
    "action.paste-error-description": "Could not paste due to missing clipboard permissions. Please enable the permissions and try again.",
    "action.print": "Print\u2026",
    "action.redo": "Redo",
    "action.remove-frame": "Remove frame",
    "action.rename": "Rename",
    "action.rotate-ccw": "Rotate counterclockwise",
    "action.rotate-cw": "Rotate clockwise",
    "action.save-copy": "Save a copy",
    "action.select-all": "Select all",
    "action.select-none": "Select none",
    "action.send-backward": "Send backward",
    "action.send-to-back": "Send to back",
    "action.share-project": "Share this project",
    "action.stack-horizontal": "Stack horizontally",
    "action.stack-vertical": "Stack vertically",
    "action.stack-horizontal.short": "Stack H",
    "action.stack-vertical.short": "Stack V",
    "action.stop-following": "Stop following",
    "action.stretch-horizontal": "Stretch horizontally",
    "action.stretch-vertical": "Stretch vertically",
    "action.stretch-horizontal.short": "Stretch H",
    "action.stretch-vertical.short": "Stretch V",
    "action.toggle-auto-size": "Toggle auto size",
    "action.toggle-dark-mode.menu": "Dark mode",
    "action.toggle-dark-mode": "Toggle dark mode",
    "action.toggle-paste-at-cursor.menu": "Paste at cursor",
    "action.toggle-paste-at-cursor": "Toggle paste at cursor",
    "action.toggle-wrap-mode.menu": "Select on wrap",
    "action.toggle-wrap-mode": "Toggle select on wrap",
    "action.toggle-reduce-motion.menu": "Reduce motion",
    "action.toggle-reduce-motion": "Toggle reduce motion",
    "action.toggle-keyboard-shortcuts.menu": "Enable keyboard shortcuts",
    "action.toggle-keyboard-shortcuts": "Toggle keyboard shortcuts",
    "action.enhanced-a11y-mode.menu": "Enhanced accessibility mode",
    "action.enhanced-a11y-mode": "Toggle enhanced accessibility mode",
    "action.toggle-edge-scrolling.menu": "Edge scrolling",
    "action.toggle-edge-scrolling": "Toggle edge scrolling",
    "action.toggle-invert-zoom.menu": "Invert mouse zoom",
    "action.toggle-invert-zoom": "Toggle invert mouse zoom",
    "action.toggle-debug-mode.menu": "Debug mode",
    "action.toggle-debug-mode": "Toggle debug mode",
    "action.toggle-focus-mode.menu": "Focus mode",
    "action.toggle-focus-mode": "Toggle focus mode",
    "action.toggle-dynamic-size-mode.menu": "Dynamic size",
    "action.toggle-dynamic-size-mode": "Toggle dynamic size",
    "action.toggle-grid.menu": "Show grid",
    "action.toggle-grid": "Toggle grid",
    "action.toggle-lock": "Toggle locked",
    "action.flatten-to-image": "Flatten",
    "action.toggle-snap-mode.menu": "Always snap",
    "action.toggle-snap-mode": "Toggle always snap",
    "action.toggle-tool-lock.menu": "Tool lock",
    "action.toggle-tool-lock": "Toggle tool lock",
    "action.toggle-transparent.context-menu": "Transparent",
    "action.toggle-transparent.menu": "Transparent",
    "action.toggle-transparent": "Toggle transparent background",
    "action.undo": "Undo",
    "action.ungroup": "Ungroup",
    "action.zoom-in": "Zoom in",
    "action.zoom-out": "Zoom out",
    "action.zoom-to-100": "Zoom to 100%",
    "action.zoom-to-fit": "Zoom to fit",
    "action.zoom-to-selection": "Zoom to selection",
    "action.zoom-quick": "Quick zoom",
    "action.select-zoom-tool": "Zoom",
    "assets.files.size-too-big": "File size is too big",
    "assets.files.maximum-size": "Maximum file size is {size}",
    "assets.files.type-not-allowed": "File type is not allowed",
    "assets.files.upload-failed": "Upload failed",
    "assets.files.amount-too-many": "Too many files",
    "assets.url.failed": "Couldn\u2019t load URL preview",
    "theme.dark": "Dark",
    "theme.light": "Light",
    "theme.system": "System",
    "color-style.white": "White",
    "color-style.black": "Black",
    "color-style.blue": "Blue",
    "color-style.green": "Green",
    "color-style.grey": "Grey",
    "color-style.light-blue": "Light blue",
    "color-style.light-green": "Light green",
    "color-style.light-red": "Light red",
    "color-style.light-violet": "Light violet",
    "color-style.orange": "Orange",
    "color-style.red": "Red",
    "color-style.violet": "Violet",
    "color-style.yellow": "Yellow",
    "fill-style.none": "None",
    "document.default-name": "Untitled",
    "fill-style.semi": "Semi",
    "fill-style.solid": "Solid",
    "fill-style.pattern": "Pattern",
    "fill-style.fill": "Fill",
    "fill-style.lined-fill": "Lined fill",
    "dash-style.dashed": "Dashed",
    "dash-style.dotted": "Dotted",
    "dash-style.draw": "Draw",
    "dash-style.solid": "Solid",
    "size-style.s": "Small",
    "size-style.m": "Medium",
    "size-style.l": "Large",
    "size-style.xl": "Extra large",
    "opacity-style.0.1": "10%",
    "opacity-style.0.25": "25%",
    "opacity-style.0.5": "50%",
    "opacity-style.0.75": "75%",
    "opacity-style.1": "100%",
    "font-style.draw": "Draw",
    "font-style.sans": "Sans",
    "font-style.serif": "Serif",
    "font-style.mono": "Mono",
    "align-style.start": "Start",
    "align-style.middle": "Middle",
    "align-style.end": "End",
    "align-style.justify": "Justify",
    "verticalAlign-style.start": "Top",
    "verticalAlign-style.middle": "Middle",
    "verticalAlign-style.end": "Bottom",
    "geo-style.arrow-down": "Arrow down",
    "geo-style.arrow-left": "Arrow left",
    "geo-style.arrow-right": "Arrow right",
    "geo-style.arrow-up": "Arrow up",
    "geo-style.cloud": "Cloud",
    "geo-style.diamond": "Diamond",
    "geo-style.ellipse": "Ellipse",
    "geo-style.heart": "Heart",
    "geo-style.hexagon": "Hexagon",
    "geo-style.octagon": "Octagon",
    "geo-style.oval": "Oval",
    "geo-style.pentagon": "Pentagon",
    "geo-style.rectangle": "Rectangle",
    "geo-style.rhombus": "Rhombus",
    "geo-style.rhombus-2": "Rhombus left",
    "geo-style.star": "Star",
    "geo-style.trapezoid": "Trapezoid",
    "geo-style.triangle": "Triangle",
    "geo-style.x-box": "X box",
    "geo-style.check-box": "Check box",
    "arrowheadStart-style.none": "None",
    "arrowheadStart-style.arrow": "Arrow",
    "arrowheadStart-style.bar": "Bar",
    "arrowheadStart-style.diamond": "Diamond",
    "arrowheadStart-style.dot": "Dot",
    "arrowheadStart-style.inverted": "Inverted",
    "arrowheadStart-style.pipe": "Pipe",
    "arrowheadStart-style.square": "Square",
    "arrowheadStart-style.triangle": "Triangle",
    "arrowheadEnd-style.none": "None",
    "arrowheadEnd-style.arrow": "Arrow",
    "arrowheadEnd-style.bar": "Bar",
    "arrowheadEnd-style.diamond": "Diamond",
    "arrowheadEnd-style.dot": "Dot",
    "arrowheadEnd-style.inverted": "Inverted",
    "arrowheadEnd-style.pipe": "Pipe",
    "arrowheadEnd-style.square": "Square",
    "arrowheadEnd-style.triangle": "Triangle",
    "spline-style.line": "Line",
    "spline-style.cubic": "Cubic",
    "arrow-kind-style.arc": "Arc",
    "arrow-kind-style.elbow": "Elbow",
    "tool.select": "Select",
    "tool.hand": "Hand",
    "tool.draw": "Draw",
    "tool.eraser": "Eraser",
    "tool.arrow-down": "Arrow down",
    "tool.arrow-left": "Arrow left",
    "tool.arrow-right": "Arrow right",
    "tool.arrow-up": "Arrow up",
    "tool.arrow": "Arrow",
    "tool.cloud": "Cloud",
    "tool.diamond": "Diamond",
    "tool.ellipse": "Ellipse",
    "tool.heart": "Heart",
    "tool.hexagon": "Hexagon",
    "tool.highlight": "Highlight",
    "tool.line": "Line",
    "tool.octagon": "Octagon",
    "tool.oval": "Oval",
    "tool.pentagon": "Pentagon",
    "tool.rectangle": "Rectangle",
    "tool.rhombus": "Rhombus",
    "tool.star": "Star",
    "tool.trapezoid": "Trapezoid",
    "tool.triangle": "Triangle",
    "tool.x-box": "X box",
    "tool.check-box": "Check box",
    "tool.media": "Media",
    "tool.frame": "Frame",
    "tool.note": "Note",
    "tool.laser": "Laser",
    "tool.embed": "Embed",
    "tool.text": "Text",
    "tool.pointer-down": "Pointer down",
    "tool.image-zoom": "Zoom",
    "tool.replace-media": "Replace media\u2026",
    "tool.flip-horz": "Flip horizontally",
    "tool.flip-vert": "Flip vertically",
    "tool.rotate-cw": "Rotate",
    "tool.aspect-ratio": "Aspect ratio",
    "tool.aspect-ratio.original": "Original",
    "tool.aspect-ratio.square": "Square (1:1)",
    "tool.aspect-ratio.circle": "Circle (1:1)",
    "tool.aspect-ratio.landscape": "Landscape (4:3)",
    "tool.aspect-ratio.portrait": "Portrait (3:4)",
    "tool.aspect-ratio.wide": "Wide (16:9)",
    "tool.image-toolbar-title": "Image tools",
    "tool.image-crop": "Crop image",
    "tool.image-crop-confirm": "Confirm",
    "tool.media-alt-text": "Alternative text",
    "tool.media-alt-text-desc": "Give a description\u2026",
    "tool.media-alt-text-confirm": "Confirm",
    "tool.rich-text-bold": "Bold",
    "tool.rich-text-italic": "Italic",
    "tool.rich-text-code": "Code",
    "tool.rich-text-highlight": "Highlight",
    "tool.rich-text-strikethrough": "Strikethrough",
    "tool.rich-text-link": "Link",
    "tool.rich-text-link-visit": "Visit link",
    "tool.rich-text-link-remove": "Remove link",
    "tool.rich-text-header": "Header",
    "tool.rich-text-bulletList": "Bulleted list",
    "tool.rich-text-toolbar-title": "Text formatting",
    "tool.rich-text-orderedList": "Ordered list",
    "tool.bookmark": "Bookmark",
    "a11y.status": "Status",
    "a11y.skip-to-main-content": "Move focus to canvas",
    "a11y.shape-index": "{num} of {total}",
    "a11y.shape-image": "Image",
    "a11y.shape-video": "Video",
    "a11y.multiple-shapes": "{num} shapes selected",
    "a11y.select-shape": "Select next shape",
    "a11y.select-shape-direction": "Select shape in direction",
    "a11y.enter-leave-container": "Enter/leave container",
    "a11y.repeat-shape": "Repeat shape",
    "a11y.move-shape": "Move shape",
    "a11y.move-shape-faster": "Move shape faster",
    "a11y.rotate-shape-cw": "Rotate shape clockwise",
    "a11y.rotate-shape-ccw": "Rotate shape counterclockwise",
    "a11y.rotate-shape-cw-fine": "Rotate shape clockwise (fine)",
    "a11y.rotate-shape-ccw-fine": "Rotate shape counterclockwise (fine)",
    "a11y.enlarge-shape": "Enlarge shape",
    "a11y.shrink-shape": "Shrink shape",
    "a11y.pan-camera": "Pan camera",
    "a11y.adjust-shape-styles": "Adjust shape styles",
    "a11y.open-context-menu": "Context menu\u2026",
    "a11y.open-keyboard-shortcuts": "Keyboard shortcuts\u2026",
    "menu.title": "Menu",
    "menu.theme": "Theme",
    "menu.accessibility": "Accessibility",
    "menu.copy-as": "Copy as",
    "menu.edit": "Edit",
    "menu.export-as": "Export as",
    "menu.file": "File",
    "menu.language": "Language",
    "menu.preferences": "Preferences",
    "menu.view": "View",
    "menu.input-device": "Input device",
    "context-menu.title": "Context menu",
    "context-menu.edit": "Edit",
    "context-menu.arrange": "Arrange",
    "context-menu.copy-as": "Copy as",
    "context-menu.export-as": "Export as",
    "context-menu.export-all-as": "Export",
    "context-menu.move-to-page": "Move to page",
    "context-menu.reorder": "Reorder",
    "page-menu.title": "Pages",
    "page-menu.create-new-page": "Create new page",
    "page-menu.max-page-count-reached": "Max pages reached",
    "page-menu.new-page-initial-name": "Page 1",
    "page-menu.edit-start": "Edit",
    "page-menu.edit-done": "Done",
    "page-menu.go-to-page": "Go to page",
    "page-menu.submenu.rename": "Rename",
    "page-menu.submenu.duplicate-page": "Duplicate",
    "page-menu.submenu.title": "Menu",
    "page-menu.submenu.move-down": "Move down",
    "page-menu.submenu.move-up": "Move up",
    "page-menu.submenu.delete": "Delete",
    "share-menu.title": "Share",
    "share-menu.save-note": "Download this project to your computer as a .tldr file.",
    "share-menu.fork-note": "Create a new shared project based on this snapshot.",
    "share-menu.share-project": "Share this project",
    "share-menu.copy-link": "Copy editor link",
    "share-menu.create-snapshot-link": "Copy snapshot link",
    "share-menu.snapshot-link-note": "Capture and share this project as a read-only snapshot link.",
    "share-menu.copy-readonly-link": "Copy viewer link",
    "share-menu.offline-note": "Create a new shared project based on your current project.",
    "share-menu.copy-link-note": "Anyone with the link will be able to view and edit this project.",
    "share-menu.copy-readonly-link-note": "Anyone with the link will be able to access this project.",
    "share-menu.project-too-large": "Sorry, this project can\u2019t be shared because it\u2019s too large. We\u2019re working on it!",
    "share-menu.upload-failed": "Sorry, we couldn\u2019t upload your project at the moment. Please try again or let us know if the problem persists.",
    "share-menu.creating-project": "Creating the new project\u2026",
    "share-menu.copied": "Copied link",
    "document-name-menu.copy-link": "Copy link",
    "status.offline": "Offline",
    "people-menu.title": "People",
    "people-menu.change-name": "Change name",
    "people-menu.avatar-color": "Avatar color",
    "people-menu.change-color": "Change color",
    "people-menu.follow": "Following",
    "people-menu.following": "Following",
    "people-menu.leading": "Following you",
    "people-menu.user": "(You)",
    "people-menu.invite": "Invite others",
    "people-menu.anonymous-user": "New user",
    "help-menu.import-tldr-file": "Import file\u2026",
    "help-menu.title": "Help and resources",
    "help-menu.about": "About tldraw",
    "help-menu.discord": "Discord",
    "help-menu.github": "GitHub",
    "help-menu.keyboard-shortcuts": "Keyboard shortcuts\u2026",
    "help-menu.twitter": "Twitter",
    "help-menu.terms": "Terms of service",
    "help-menu.privacy": "Privacy policy",
    "actions-menu.title": "Actions",
    "edit-link-dialog.title": "Edit link",
    "edit-link-dialog.invalid-url": "A link must be a valid URL.",
    "edit-link-dialog.detail": "Links will open in a new tab.",
    "edit-link-dialog.url": "URL",
    "edit-link-dialog.clear": "Clear",
    "edit-link-dialog.save": "Continue",
    "edit-link-dialog.cancel": "Cancel",
    "edit-link-dialog.external-link": "External link",
    "embed-dialog.title": "Insert embed",
    "embed-dialog.back": "Back",
    "embed-dialog.create": "Create",
    "embed-dialog.cancel": "Cancel",
    "embed-dialog.url": "URL",
    "embed-dialog.instruction": "Paste in the site\u2019s URL to create the embed.",
    "embed-dialog.invalid-url": "We could not create an embed from that URL.",
    "shortcuts-dialog.title": "Keyboard shortcuts",
    "shortcuts-dialog.edit": "Edit",
    "shortcuts-dialog.file": "File",
    "shortcuts-dialog.preferences": "Preferences",
    "shortcuts-dialog.tools": "Tools",
    "shortcuts-dialog.transform": "Transform",
    "shortcuts-dialog.view": "View",
    "shortcuts-dialog.collaboration": "Collaboration",
    "shortcuts-dialog.a11y": "Accessibility",
    "shortcuts-dialog.text-formatting": "Text formatting",
    "style-panel.title": "Styles",
    "style-panel.align": "Align",
    "style-panel.label-align": "Label align",
    "style-panel.vertical-align": "Vertical align",
    "style-panel.position": "Position",
    "style-panel.arrowheads": "Arrows",
    "style-panel.arrowhead-start": "Start",
    "style-panel.arrowhead-end": "End",
    "style-panel.arrow-kind": "Line",
    "style-panel.color": "Color",
    "style-panel.dash": "Dash",
    "style-panel.fill": "Fill",
    "style-panel.font": "Font",
    "style-panel.geo": "Shape",
    "style-panel.mixed": "Mixed",
    "style-panel.opacity": "Opacity",
    "style-panel.size": "Size",
    "style-panel.spline": "Spline",
    "style-panel.selected": "selected",
    "tool-panel.title": "Tools",
    "tool-panel.more": "More",
    "navigation-zone.title": "Navigation",
    "navigation-zone.minimap": "Minimap",
    "navigation-zone.toggle-minimap": "Toggle minimap",
    "navigation-zone.zoom": "Zoom",
    "focus-mode.toggle-focus-mode": "Toggle focus mode",
    "toast.close": "Close",
    "toast.success": "Success",
    "toast.error": "Error",
    "toast.info": "Info",
    "toast.warning": "Warning",
    "file-system.file-open-error.title": "Could not open file",
    "file-system.file-open-error.not-a-tldraw-file": "The file you tried to open doesn\u2019t look like a tldraw file.",
    "file-system.file-open-error.file-format-version-too-new": "The file you tried to open is from a newer version of tldraw. Please reload the page and try again.",
    "file-system.file-open-error.generic-corrupted-file": "The file you tried to open is corrupted.",
    "file-system.confirm-open.title": "Overwrite current project?",
    "file-system.confirm-open.description": "Opening a file will replace your current project and any unsaved changes will be lost. Are you sure you want to continue?",
    "file-system.confirm-open.cancel": "Cancel",
    "file-system.confirm-open.open": "Open file",
    "file-system.confirm-open.dont-show-again": "Don\u2019t ask again",
    "file-system.confirm-clear.title": "Clear current project?",
    "file-system.confirm-clear.description": "Creating a new project will clear your current project and any unsaved changes will be lost. Are you sure you want to continue?",
    "file-system.confirm-clear.cancel": "Cancel",
    "file-system.confirm-clear.continue": "Continue",
    "file-system.confirm-clear.dont-show-again": "Don\u2019t ask again",
    "file-system.shared-document-file-open-error.title": "Could not open file",
    "file-system.shared-document-file-open-error.description": "Opening files from shared projects is not supported.",
    "sharing.confirm-leave.title": "Leave current project?",
    "sharing.confirm-leave.description": "Are you sure you want to leave this shared project? You can return to it by navigating to its URL.",
    "sharing.confirm-leave.cancel": "Cancel",
    "sharing.confirm-leave.leave": "Leave",
    "sharing.confirm-leave.dont-show-again": "Don\u2019t ask again",
    "toast.error.export-fail.title": "Failed export",
    "toast.error.export-fail.desc": "Failed to export image",
    "toast.error.copy-fail.title": "Failed copy",
    "toast.error.copy-fail.desc": "Failed to copy image",
    "context.pages.new-page": "New page",
    "vscode.file-open.desc": "We\u2019ve updated this document to work with the current version of tldraw. If you\u2019d like to keep the original version (which will work on old.tldraw.com), click below to create a backup.",
    "vscode.file-open.open": "Continue",
    "vscode.file-open.backup": "Backup",
    "vscode.file-open.backup-saved": "Backup saved",
    "vscode.file-open.backup-failed": "Backup failed: this is not a .tldr file.",
    "vscode.file-open.dont-show-again": "Don\u2019t ask again",
    "cursor-chat.type-to-chat": "Type to chat\u2026",
    "app.loading": "Loading tldraw\u2026",
    "handle.resize-top": "Resize top",
    "handle.resize-bottom": "Resize bottom",
    "handle.resize-left": "Resize left",
    "handle.resize-right": "Resize right",
    "handle.resize-top-left": "Resize top left",
    "handle.resize-top-right": "Resize top right",
    "handle.resize-bottom-left": "Resize bottom left",
    "handle.resize-bottom-right": "Resize bottom right",
    "handle.rotate.top_left_rotate": "Rotate top left",
    "handle.rotate.top_right_rotate": "Rotate top right",
    "handle.rotate.bottom_left_rotate": "Rotate bottom left",
    "handle.rotate.bottom_right_rotate": "Rotate bottom right",
    "handle.rotate.mobile_rotate": "Rotate",
    "handle.crop.top": "Crop top",
    "handle.crop.bottom": "Crop bottom",
    "handle.crop.left": "Crop left",
    "handle.crop.right": "Crop right",
    "handle.crop.top-left": "Crop top left",
    "handle.crop.top-right": "Crop top right",
    "handle.crop.bottom-left": "Crop bottom left",
    "handle.crop.bottom-right": "Crop bottom right",
    "ui.close": "Close",
    "ui.checked": "Checked",
    "ui.unchecked": "Unchecked"
};
;
 //# sourceMappingURL=defaultTranslation.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/translations.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RTL_LANGUAGES",
    ()=>RTL_LANGUAGES,
    "fetchTranslation",
    ()=>fetchTranslation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$defaultTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/defaultTranslation.mjs [app-client] (ecmascript)");
;
;
const RTL_LANGUAGES = /* @__PURE__ */ new Set([
    "ar",
    "fa",
    "he",
    "ur",
    "ku"
]);
const EN_TRANSLATION = {
    locale: "en",
    label: "English",
    messages: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$defaultTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TRANSLATION"],
    dir: "ltr"
};
async function fetchTranslation(locale, assetUrls) {
    const mainRes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(assetUrls.translations.en);
    if (!mainRes.ok) {
        console.warn(`No main translations found.`);
        return EN_TRANSLATION;
    }
    if (locale === "en") {
        return EN_TRANSLATION;
    }
    const language = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LANGUAGES"].find((t)=>t.locale === locale);
    if (!language) {
        console.warn(`No translation found for locale ${locale}`);
        return EN_TRANSLATION;
    }
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(assetUrls.translations[language.locale]);
    const messages = await res.json();
    if (!messages) {
        console.warn(`No messages found for locale ${locale}`);
        return EN_TRANSLATION;
    }
    const missing = [];
    for(const key in EN_TRANSLATION.messages){
        if (!messages[key]) {
            missing.push(key);
        }
    }
    if (missing.length > 0 && ("TURBOPACK compile-time value", "development") === "development") {
        console.warn(`Language ${locale}: missing messages for keys:
${missing.join("\n")}`);
    }
    return {
        locale,
        label: language.label,
        dir: RTL_LANGUAGES.has(language.locale) ? "rtl" : "ltr",
        messages: {
            ...EN_TRANSLATION.messages,
            ...messages
        }
    };
}
;
 //# sourceMappingURL=translations.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawUiTranslationProvider",
    ()=>TldrawUiTranslationProvider,
    "TranslationsContext",
    ()=>TranslationsContext,
    "untranslated",
    ()=>untranslated,
    "useCurrentTranslation",
    ()=>useCurrentTranslation,
    "useTranslation",
    ()=>useTranslation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/asset-urls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$defaultTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/defaultTranslation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/translations.mjs [app-client] (ecmascript)");
;
;
;
;
;
const TranslationsContext = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function useCurrentTranslation() {
    const translations = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](TranslationsContext);
    if (!translations) {
        throw new Error("useCurrentTranslation must be used inside of <TldrawUiContextProvider />");
    }
    return translations;
}
function TldrawUiTranslationProvider({ overrides, locale, children }) {
    const getAssetUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAssetUrls"])();
    const [currentTranslation, setCurrentTranslation] = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "TldrawUiTranslationProvider.useState": ()=>{
            if (overrides && overrides["en"]) {
                return {
                    locale: "en",
                    label: "English",
                    dir: "ltr",
                    messages: {
                        ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$defaultTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TRANSLATION"],
                        ...overrides["en"]
                    }
                };
            }
            return {
                locale: "en",
                label: "English",
                dir: "ltr",
                messages: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$defaultTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TRANSLATION"]
            };
        }
    }["TldrawUiTranslationProvider.useState"]);
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "TldrawUiTranslationProvider.useEffect": ()=>{
            let isCancelled = false;
            async function loadTranslation() {
                const translation = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$translations$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchTranslation"])(locale, getAssetUrl);
                if (translation && !isCancelled) {
                    if (overrides && overrides[locale]) {
                        setCurrentTranslation({
                            ...translation,
                            messages: {
                                ...translation.messages,
                                ...overrides[locale]
                            }
                        });
                    } else {
                        setCurrentTranslation(translation);
                    }
                }
            }
            loadTranslation();
            return ({
                "TldrawUiTranslationProvider.useEffect": ()=>{
                    isCancelled = true;
                }
            })["TldrawUiTranslationProvider.useEffect"];
        }
    }["TldrawUiTranslationProvider.useEffect"], [
        getAssetUrl,
        locale,
        overrides
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TranslationsContext.Provider, {
        value: currentTranslation,
        children
    });
}
function useTranslation() {
    const translation = useCurrentTranslation();
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"](function msg(id) {
        return translation.messages[id] ?? id;
    }, [
        translation
    ]);
}
function untranslated(string) {
    return string;
}
;
 //# sourceMappingURL=useTranslation.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useGetEmbedDefinition.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGetEmbedDefinition",
    ()=>useGetEmbedDefinition,
    "useGetEmbedShapeUtil",
    ()=>useGetEmbedShapeUtil
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
;
function useGetEmbedShapeUtil() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    if (!editor) return void 0;
    if (editor.hasShapeUtil("embed")) {
        return editor.getShapeUtil("embed");
    }
    return void 0;
}
function useGetEmbedDefinition() {
    const embedUtil = useGetEmbedShapeUtil();
    return (url)=>{
        return embedUtil ? embedUtil.getEmbedDefinition(url) : void 0;
    };
}
;
 //# sourceMappingURL=useGetEmbedDefinition.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useGetEmbedDefinitions.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGetEmbedDefinitions",
    ()=>useGetEmbedDefinitions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useGetEmbedDefinition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useGetEmbedDefinition.mjs [app-client] (ecmascript)");
;
function useGetEmbedDefinitions() {
    const embedUtil = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useGetEmbedDefinition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetEmbedShapeUtil"])();
    return embedUtil ? embedUtil.getEmbedDefinitions() : [];
}
;
 //# sourceMappingURL=useGetEmbedDefinitions.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useCollaborationStatus.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCollaborationStatus",
    ()=>useCollaborationStatus,
    "useShowCollaborationUi",
    ()=>useShowCollaborationUi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
;
function useShowCollaborationUi() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    return editor?.store.props.collaboration !== void 0;
}
function useCollaborationStatus() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("sync status", {
        "useCollaborationStatus.useValue": ()=>{
            if (!editor?.store.props.collaboration?.status) {
                return null;
            }
            return editor.store.props.collaboration.status.get();
        }
    }["useCollaborationStatus.useValue"], [
        editor
    ]);
}
;
 //# sourceMappingURL=useCollaborationStatus.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useReadonly.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useReadonly",
    ()=>useReadonly
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
;
function useReadonly() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("isReadonlyMode", {
        "useReadonly.useValue": ()=>!!editor?.getIsReadonly()
    }["useReadonly.useValue"], [
        editor
    ]);
}
;
 //# sourceMappingURL=useReadonly.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useMenuIsOpen.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMenuIsOpen",
    ()=>useMenuIsOpen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useGlobalMenuIsOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useGlobalMenuIsOpen.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
;
;
;
function useMenuIsOpen(id, cb) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const onChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMenuIsOpen.useCallback[onChange]": (isOpen)=>{
            if (isOpen) {
                editor?.complete();
            }
            cb?.(isOpen);
        }
    }["useMenuIsOpen.useCallback[onChange]"], [
        editor,
        cb
    ]);
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const onEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMenuIsOpen.useCallback[onEvent]": (eventName)=>{
            trackEvent(eventName, {
                source: "unknown",
                id
            });
        }
    }["useMenuIsOpen.useCallback[onEvent]"], [
        id,
        trackEvent
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useGlobalMenuIsOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalMenuIsOpen"])(editor ? `${id}-${editor.contextId}` : id, onChange, onEvent);
}
;
 //# sourceMappingURL=useMenuIsOpen.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/clipboard/pasteFiles.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pasteFiles",
    ()=>pasteFiles
]);
async function pasteFiles(editor, blobs, point, sources) {
    const files = blobs.map((blob)=>blob instanceof File ? blob : new File([
            blob
        ], "tldrawFile", {
            type: blob.type
        }));
    editor.markHistoryStoppingPoint("paste");
    await editor.putExternalContent({
        type: "files",
        files,
        point,
        sources
    });
}
;
 //# sourceMappingURL=pasteFiles.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/clipboard/pasteUrl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pasteUrl",
    ()=>pasteUrl
]);
async function pasteUrl(editor, url, point, sources) {
    editor.markHistoryStoppingPoint("paste");
    return await editor.putExternalContent({
        type: "url",
        point,
        url,
        sources
    });
}
;
 //# sourceMappingURL=pasteUrl.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useClipboardEvents.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isValidHttpURL",
    ()=>isValidHttpURL,
    "useMenuClipboardEvents",
    ()=>useMenuClipboardEvents,
    "useNativeClipboardEvents",
    ()=>useNativeClipboardEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$uniq$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/uniq.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lz$2d$string$2f$libs$2f$lz$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/lz-string/libs/lz-string.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/clipboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteFiles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/clipboard/pasteFiles.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/clipboard/pasteUrl.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const expectedPasteFileMimeTypes = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLDRAW_CUSTOM_PNG_MIME_TYPE"],
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/svg+xml"
];
function stripHtml(html) {
    const doc = document.implementation.createHTMLDocument("");
    doc.documentElement.innerHTML = html.trim();
    return doc.body.textContent || doc.body.innerText || "";
}
const isValidHttpURL = (url)=>{
    try {
        const u = new URL(url);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch  {
        return false;
    }
};
const getValidHttpURLList = (url)=>{
    const urls = url.split(/[\n\s]/);
    for (const url2 of urls){
        try {
            const u = new URL(url2);
            if (!(u.protocol === "http:" || u.protocol === "https:")) {
                return;
            }
        } catch  {
            return;
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$uniq$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniq"])(urls);
};
const isSvgText = (text)=>{
    return /^<svg/.test(text);
};
const INPUTS = [
    "input",
    "select",
    "textarea"
];
function areShortcutsDisabled(editor) {
    const { activeElement } = document;
    return editor.menus.hasAnyOpenMenus() || activeElement && (activeElement.isContentEditable || INPUTS.indexOf(activeElement.tagName.toLowerCase()) > -1);
}
const handleText = (editor, data, point, sources)=>{
    const validUrlList = getValidHttpURLList(data);
    if (validUrlList) {
        for (const url of validUrlList){
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pasteUrl"])(editor, url, point);
        }
    } else if (isValidHttpURL(data)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pasteUrl"])(editor, data, point);
    } else if (isSvgText(data)) {
        editor.markHistoryStoppingPoint("paste");
        editor.putExternalContent({
            type: "svg-text",
            text: data,
            point,
            sources
        });
    } else {
        editor.markHistoryStoppingPoint("paste");
        editor.putExternalContent({
            type: "text",
            text: data,
            point,
            sources
        });
    }
};
const handlePasteFromEventClipboardData = async (editor, clipboardData, point)=>{
    if (editor.getEditingShapeId() !== null) return;
    if (!clipboardData) {
        throw Error("No clipboard data");
    }
    const things = [];
    for (const item of Object.values(clipboardData.items)){
        switch(item.kind){
            case "file":
                {
                    things.push({
                        type: "file",
                        source: new Promise((r)=>r(item.getAsFile()))
                    });
                    break;
                }
            case "string":
                {
                    if (item.type === "text/html") {
                        things.push({
                            type: "html",
                            source: new Promise((r)=>item.getAsString(r))
                        });
                    } else if (item.type === "text/plain") {
                        things.push({
                            type: "text",
                            source: new Promise((r)=>item.getAsString(r))
                        });
                    } else {
                        things.push({
                            type: item.type,
                            source: new Promise((r)=>item.getAsString(r))
                        });
                    }
                    break;
                }
        }
    }
    handleClipboardThings(editor, things, point);
};
const handlePasteFromClipboardApi = async ({ editor, clipboardItems, point, fallbackFiles })=>{
    const things = [];
    for (const item of clipboardItems){
        for (const type of expectedPasteFileMimeTypes){
            if (item.types.includes(type)) {
                const blobPromise = item.getType(type).then((blob)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].rewriteMimeType(blob, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$clipboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCanonicalClipboardReadType"])(type)));
                things.push({
                    type: "blob",
                    source: blobPromise
                });
                break;
            }
        }
        if (item.types.includes("text/html")) {
            things.push({
                type: "html",
                source: (async ()=>{
                    const blob = await item.getType("text/html");
                    return await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToText(blob);
                })()
            });
        }
        if (item.types.includes("text/uri-list")) {
            things.push({
                type: "url",
                source: (async ()=>{
                    const blob = await item.getType("text/uri-list");
                    return await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToText(blob);
                })()
            });
        }
        if (item.types.includes("text/plain")) {
            things.push({
                type: "text",
                source: (async ()=>{
                    const blob = await item.getType("text/plain");
                    return await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToText(blob);
                })()
            });
        }
    }
    if (fallbackFiles?.length && things.length === 1 && things[0].type === "text") {
        things.pop();
        things.push(...fallbackFiles.map((f)=>({
                type: "file",
                source: Promise.resolve(f)
            })));
    } else if (fallbackFiles?.length && things.length === 0) {
        things.push(...fallbackFiles.map((f)=>({
                type: "file",
                source: Promise.resolve(f)
            })));
    }
    return await handleClipboardThings(editor, things, point);
};
async function handleClipboardThings(editor, things, point) {
    const files = things.filter((t)=>(t.type === "file" || t.type === "blob") && t.source !== null);
    if (files.length) {
        if (files.length > editor.options.maxFilesAtOnce) {
            throw Error("Too many files");
        }
        const fileBlobs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(await Promise.all(files.map((t)=>t.source)));
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteFiles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pasteFiles"])(editor, fileBlobs, point);
    }
    const results = await Promise.all(things.filter((t)=>t.type !== "file").map((t)=>new Promise((r)=>{
            const thing = t;
            if (thing.type === "file") {
                r({
                    type: "error",
                    data: null,
                    reason: "unexpected file"
                });
                return;
            }
            thing.source.then((text)=>{
                const tldrawHtmlComment = text.match(/<div data-tldraw[^>]*>(.*)<\/div>/)?.[1];
                if (tldrawHtmlComment) {
                    try {
                        let json;
                        try {
                            json = JSON.parse(tldrawHtmlComment);
                        } catch  {
                            const jsonComment = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lz$2d$string$2f$libs$2f$lz$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].decompressFromBase64(tldrawHtmlComment);
                            if (jsonComment === null) {
                                r({
                                    type: "error",
                                    data: null,
                                    reason: `found tldraw data comment but could not parse`
                                });
                                return;
                            }
                            json = JSON.parse(jsonComment);
                        }
                        if (json.type !== "application/tldraw") {
                            r({
                                type: "error",
                                data: json,
                                reason: `found tldraw data comment but JSON was of a different type: ${json.type}`
                            });
                            return;
                        }
                        if (json.version === 3) {
                            try {
                                const otherData = JSON.parse(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lz$2d$string$2f$libs$2f$lz$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].decompressFromBase64(json.data.otherCompressed) || "{}");
                                const reconstructedData = {
                                    assets: json.data.assets || [],
                                    ...otherData
                                };
                                r({
                                    type: "tldraw",
                                    data: reconstructedData
                                });
                                return;
                            } catch (error) {
                                r({
                                    type: "error",
                                    data: json,
                                    reason: `failed to decompress version 2 clipboard data: ${error}`
                                });
                                return;
                            }
                        }
                        if (json.version === 2) {
                            r({
                                type: "tldraw",
                                data: json.data
                            });
                        } else {
                            if (typeof json.data === "string") {
                                r({
                                    type: "error",
                                    data: json,
                                    reason: "found tldraw json but data was a string instead of a TLClipboardModel object"
                                });
                                return;
                            }
                            r({
                                type: "tldraw",
                                data: json.data
                            });
                            return;
                        }
                    } catch  {
                        r({
                            type: "error",
                            data: tldrawHtmlComment,
                            reason: "found tldraw json but data was a string instead of a TLClipboardModel object"
                        });
                        return;
                    }
                } else {
                    if (thing.type === "html") {
                        r({
                            type: "text",
                            data: text,
                            subtype: "html"
                        });
                        return;
                    }
                    if (thing.type === "url") {
                        r({
                            type: "text",
                            data: text,
                            subtype: "url"
                        });
                        return;
                    }
                    try {
                        const json = JSON.parse(text);
                        if (json.type === "excalidraw/clipboard") {
                            r({
                                type: "excalidraw",
                                data: json
                            });
                            return;
                        } else {
                            r({
                                type: "text",
                                data: text,
                                subtype: "json"
                            });
                            return;
                        }
                    } catch  {
                        r({
                            type: "text",
                            data: text,
                            subtype: "text"
                        });
                        return;
                    }
                }
                r({
                    type: "error",
                    data: text,
                    reason: "unhandled case"
                });
            });
        })));
    for (const result of results){
        if (result.type === "tldraw") {
            editor.markHistoryStoppingPoint("paste");
            editor.putExternalContent({
                type: "tldraw",
                content: result.data,
                point
            });
            return;
        }
    }
    for (const result of results){
        if (result.type === "excalidraw") {
            editor.markHistoryStoppingPoint("paste");
            editor.putExternalContent({
                type: "excalidraw",
                content: result.data,
                point
            });
            return;
        }
    }
    for (const result of results){
        if (result.type === "text" && result.subtype === "html") {
            const rootNode = new DOMParser().parseFromString(result.data, "text/html");
            const bodyNode = rootNode.querySelector("body");
            const isHtmlSingleLink = bodyNode && Array.from(bodyNode.children).filter((el)=>el.nodeType === 1).length === 1 && bodyNode.firstElementChild && bodyNode.firstElementChild.tagName === "A" && bodyNode.firstElementChild.hasAttribute("href") && bodyNode.firstElementChild.getAttribute("href") !== "";
            if (isHtmlSingleLink) {
                const href = bodyNode.firstElementChild.getAttribute("href");
                handleText(editor, href, point, results);
                return;
            }
            if (!results.some((r)=>r.type === "text" && r.subtype !== "html") && result.data.trim()) {
                const html = stripHtml(result.data) ?? "";
                if (html) {
                    handleText(editor, stripHtml(result.data), point, results);
                    return;
                }
            }
            if (results.some((r)=>r.type === "text" && r.subtype !== "html")) {
                const html = stripHtml(result.data) ?? "";
                if (html) {
                    editor.markHistoryStoppingPoint("paste");
                    editor.putExternalContent({
                        type: "text",
                        text: html,
                        html: result.data,
                        point,
                        sources: results
                    });
                    return;
                }
            }
        }
        if (result.type === "text" && result.subtype === "text" && result.data.startsWith("<iframe ")) {
            const rootNode = new DOMParser().parseFromString(result.data, "text/html");
            const bodyNode = rootNode.querySelector("body");
            const isSingleIframe = bodyNode && Array.from(bodyNode.children).filter((el)=>el.nodeType === 1).length === 1 && bodyNode.firstElementChild && bodyNode.firstElementChild.tagName === "IFRAME" && bodyNode.firstElementChild.hasAttribute("src") && bodyNode.firstElementChild.getAttribute("src") !== "";
            if (isSingleIframe) {
                const src = bodyNode.firstElementChild.getAttribute("src");
                handleText(editor, src, point, results);
                return;
            }
        }
    }
    for (const result of results){
        if (result.type === "text" && result.subtype === "url") {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$clipboard$2f$pasteUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pasteUrl"])(editor, result.data, point, results);
            return;
        }
    }
    for (const result of results){
        if (result.type === "text" && result.subtype === "text" && result.data.trim()) {
            handleText(editor, result.data, point, results);
            return;
        }
    }
}
const handleNativeOrMenuCopy = async (editor)=>{
    const navigator2 = editor.getContainer().ownerDocument?.defaultView?.navigator ?? globalThis.navigator;
    const content = await editor.resolveAssetsInContent(editor.getContentFromCurrentPage(editor.getSelectedShapeIds()));
    if (!content) {
        if (navigator2 && navigator2.clipboard) {
            navigator2.clipboard.writeText("");
        }
        return;
    }
    const { assets, ...otherData } = content;
    const clipboardData = {
        type: "application/tldraw",
        kind: "content",
        version: 3,
        data: {
            assets: assets || [],
            // Plain JSON, no compression
            otherCompressed: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$lz$2d$string$2f$libs$2f$lz$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].compressToBase64(JSON.stringify(otherData))
        }
    };
    const stringifiedClipboard = JSON.stringify(clipboardData);
    if (typeof navigator2 === "undefined") {
        return;
    } else {
        const textItems = content.shapes.map((shape)=>{
            const util = editor.getShapeUtil(shape);
            return util.getText(shape);
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDefined"]);
        if (navigator2.clipboard?.write) {
            const htmlBlob = new Blob([
                `<div data-tldraw>${stringifiedClipboard}</div>`
            ], {
                type: "text/html"
            });
            let textContent = textItems.join(" ");
            if (textContent === "") {
                textContent = " ";
            }
            navigator2.clipboard.write([
                new ClipboardItem({
                    "text/html": htmlBlob,
                    // What is this second blob used for?
                    "text/plain": new Blob([
                        textContent
                    ], {
                        type: "text/plain"
                    })
                })
            ]);
        } else if (navigator2.clipboard.writeText) {
            navigator2.clipboard.writeText(`<div data-tldraw>${stringifiedClipboard}</div>`);
        }
    }
};
function useMenuClipboardEvents() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const copy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async function onCopy(source) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(editor, "editor is required for copy");
        if (editor.getSelectedShapeIds().length === 0) return;
        await handleNativeOrMenuCopy(editor);
        trackEvent("copy", {
            source
        });
    }, [
        editor,
        trackEvent
    ]);
    const cut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async function onCut(source) {
        if (!editor) return;
        if (editor.getSelectedShapeIds().length === 0) return;
        await handleNativeOrMenuCopy(editor);
        editor.deleteShapes(editor.getSelectedShapeIds());
        trackEvent("cut", {
            source
        });
    }, [
        editor,
        trackEvent
    ]);
    const paste = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async function onPaste(data, source, point) {
        if (!editor) return;
        if (editor.getEditingShapeId() !== null) return;
        if (Array.isArray(data) && data[0] instanceof ClipboardItem) {
            handlePasteFromClipboardApi({
                editor,
                clipboardItems: data,
                point
            });
            trackEvent("paste", {
                source: "menu"
            });
        } else {
            navigator.clipboard.read().then({
                "useMenuClipboardEvents.useCallback[paste].onPaste": (clipboardItems)=>{
                    paste(clipboardItems, source, point);
                }
            }["useMenuClipboardEvents.useCallback[paste].onPaste"]);
        }
    }, [
        editor,
        trackEvent
    ]);
    return {
        copy,
        cut,
        paste
    };
}
function useNativeClipboardEvents() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const ownerDocument = editor.getContainer().ownerDocument;
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const appIsFocused = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("editor.isFocused", {
        "useNativeClipboardEvents.useValue[appIsFocused]": ()=>editor.getInstanceState().isFocused
    }["useNativeClipboardEvents.useValue[appIsFocused]"], [
        editor
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNativeClipboardEvents.useEffect": ()=>{
            if (!appIsFocused) return;
            const copy = {
                "useNativeClipboardEvents.useEffect.copy": async (e)=>{
                    if (editor.getSelectedShapeIds().length === 0 || editor.getEditingShapeId() !== null || areShortcutsDisabled(editor)) {
                        return;
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
                    await handleNativeOrMenuCopy(editor);
                    trackEvent("copy", {
                        source: "kbd"
                    });
                }
            }["useNativeClipboardEvents.useEffect.copy"];
            async function cut(e) {
                if (editor.getSelectedShapeIds().length === 0 || editor.getEditingShapeId() !== null || areShortcutsDisabled(editor)) {
                    return;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
                await handleNativeOrMenuCopy(editor);
                editor.deleteShapes(editor.getSelectedShapeIds());
                trackEvent("cut", {
                    source: "kbd"
                });
            }
            let disablingMiddleClickPaste = false;
            const pointerUpHandler = {
                "useNativeClipboardEvents.useEffect.pointerUpHandler": (e)=>{
                    if (e.button === 1) {
                        disablingMiddleClickPaste = true;
                        editor.timers.requestAnimationFrame({
                            "useNativeClipboardEvents.useEffect.pointerUpHandler": ()=>{
                                disablingMiddleClickPaste = false;
                            }
                        }["useNativeClipboardEvents.useEffect.pointerUpHandler"]);
                    }
                }
            }["useNativeClipboardEvents.useEffect.pointerUpHandler"];
            const paste = {
                "useNativeClipboardEvents.useEffect.paste": (e)=>{
                    if (disablingMiddleClickPaste) {
                        editor.markEventAsHandled(e);
                        return;
                    }
                    if (editor.getEditingShapeId() !== null || areShortcutsDisabled(editor)) return;
                    let point = void 0;
                    let pasteAtCursor = false;
                    if (editor.inputs.getShiftKey()) pasteAtCursor = true;
                    if (editor.user.getIsPasteAtCursorMode()) pasteAtCursor = !pasteAtCursor;
                    if (pasteAtCursor) point = editor.inputs.getCurrentPagePoint();
                    const pasteFromEvent = {
                        "useNativeClipboardEvents.useEffect.paste.pasteFromEvent": ()=>{
                            if (e.clipboardData) {
                                handlePasteFromEventClipboardData(editor, e.clipboardData, point);
                            }
                        }
                    }["useNativeClipboardEvents.useEffect.paste.pasteFromEvent"];
                    if (navigator.clipboard?.read) {
                        const fallbackFiles = Array.from(e.clipboardData?.files || []);
                        navigator.clipboard.read().then({
                            "useNativeClipboardEvents.useEffect.paste": (clipboardItems)=>{
                                if (Array.isArray(clipboardItems) && clipboardItems[0] instanceof ClipboardItem) {
                                    handlePasteFromClipboardApi({
                                        editor,
                                        clipboardItems,
                                        point,
                                        fallbackFiles
                                    });
                                }
                            }
                        }["useNativeClipboardEvents.useEffect.paste"], {
                            "useNativeClipboardEvents.useEffect.paste": ()=>{
                                pasteFromEvent();
                            }
                        }["useNativeClipboardEvents.useEffect.paste"]);
                    } else {
                        pasteFromEvent();
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
                    trackEvent("paste", {
                        source: "kbd"
                    });
                }
            }["useNativeClipboardEvents.useEffect.paste"];
            ownerDocument?.addEventListener("copy", copy);
            ownerDocument?.addEventListener("cut", cut);
            ownerDocument?.addEventListener("paste", paste);
            ownerDocument?.addEventListener("pointerup", pointerUpHandler);
            return ({
                "useNativeClipboardEvents.useEffect": ()=>{
                    ownerDocument?.removeEventListener("copy", copy);
                    ownerDocument?.removeEventListener("cut", cut);
                    ownerDocument?.removeEventListener("paste", paste);
                    ownerDocument?.removeEventListener("pointerup", pointerUpHandler);
                }
            })["useNativeClipboardEvents.useEffect"];
        }
    }["useNativeClipboardEvents.useEffect"], [
        editor,
        trackEvent,
        appIsFocused,
        ownerDocument
    ]);
}
;
 //# sourceMappingURL=useClipboardEvents.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useCopyAs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCopyAs",
    ()=>useCopyAs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$copyAs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/copyAs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
;
;
;
;
;
function useCopyAs() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const { addToast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToasts"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCopyAs.useCallback": (ids, format = "svg")=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(editor, "useCopyAs: editor is required");
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$copyAs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copyAs"])(editor, ids, {
                format
            }).catch({
                "useCopyAs.useCallback": ()=>{
                    addToast({
                        id: "copy-fail",
                        severity: "warning",
                        title: msg("toast.error.copy-fail.title"),
                        description: msg("toast.error.copy-fail.desc")
                    });
                }
            }["useCopyAs.useCallback"]);
        }
    }["useCopyAs.useCallback"], [
        editor,
        addToast,
        msg
    ]);
}
;
 //# sourceMappingURL=useCopyAs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useExportAs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useExportAs",
    ()=>useExportAs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$exportAs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/export/exportAs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
;
;
;
;
;
function useExportAs() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const { addToast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToasts"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useExportAs.useCallback": (ids, opts = {})=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(editor, "useExportAs: editor is required");
            const { format = "png", name, scale = 1 } = opts;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$export$2f$exportAs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportAs"])(editor, ids, {
                format,
                name,
                scale
            }).catch({
                "useExportAs.useCallback": (e)=>{
                    console.error(e.message);
                    addToast({
                        id: "export-fail",
                        title: msg("toast.error.export-fail.title"),
                        description: msg("toast.error.export-fail.desc"),
                        severity: "error"
                    });
                }
            }["useExportAs.useCallback"]);
        }
    }["useExportAs.useCallback"], [
        editor,
        addToast,
        msg
    ]);
}
;
 //# sourceMappingURL=useExportAs.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/usePrint.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePrint",
    ()=>usePrint
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function usePrint() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const prevPrintEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const prevStyleEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async function printSelectionOrPages() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(editor, "usePrint: editor is required");
        const el = document.createElement("div");
        const style = document.createElement("style");
        const clearElements = {
            "usePrint.useCallback.printSelectionOrPages.clearElements": (printEl, styleEl)=>{
                if (printEl) printEl.innerHTML = "";
                if (styleEl && document.head.contains(styleEl)) document.head.removeChild(styleEl);
                if (printEl && document.body.contains(printEl)) {
                    document.body.removeChild(printEl);
                }
            }
        }["usePrint.useCallback.printSelectionOrPages.clearElements"];
        clearElements(prevPrintEl.current, prevStyleEl.current);
        prevPrintEl.current = el;
        prevStyleEl.current = style;
        const className = `tl-print-surface-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()}`;
        el.className = className;
        const enableMargins = false;
        const allowAllPages = false;
        style.innerHTML = `
			.${className} {
				display: none;
			}

			.${className} svg {
				max-width: 100%;
				height: 100%;
				display: block;
			}

			@media print {				  
				html, body {
					min-height: 100%;
					height: 100%;
					margin: 0;
				}

				body {
					position: relative;
				}

				body > * {
					display: none;
				}

				.tldraw__editor {
					display: none;
				}

				.${className} {
					display: block !important;
					background: white;
					min-height: 100%;
					height: 100%;
					max-width: 100%;
				}

				.${className}__item {
					padding: 10mm;
					display: flex;
					min-height: 100%;
					flex-direction: column;
					page-break-after: always;
					position: relative;
					overflow: hidden;
					height: 100%;
				}

				.${className}__item__main {
					flex: 1;
					display: flex;
					align-items: center;
					justify-content: center;
					max-height: 100%;
				}

				.${className}__item__header {
					display: none;
				}

				.${className}__item__footer {
					display: none;
					text-align: right;
				}

				.${className}__item__footer__hide {
					display: none;
				}

				${("TURBOPACK compile-time truthy", 1) ? "" : "TURBOPACK unreachable"}
			}

		`;
        const beforePrintHandler = {
            "usePrint.useCallback.printSelectionOrPages.beforePrintHandler": ()=>{
                document.head.appendChild(style);
                document.body.appendChild(el);
            }
        }["usePrint.useCallback.printSelectionOrPages.beforePrintHandler"];
        const afterPrintHandler = {
            "usePrint.useCallback.printSelectionOrPages.afterPrintHandler": ()=>{
                editor.once("tick", {
                    "usePrint.useCallback.printSelectionOrPages.afterPrintHandler": ()=>{
                        clearElements(el, style);
                    }
                }["usePrint.useCallback.printSelectionOrPages.afterPrintHandler"]);
            }
        }["usePrint.useCallback.printSelectionOrPages.afterPrintHandler"];
        window.addEventListener("beforeprint", beforePrintHandler);
        window.addEventListener("afterprint", afterPrintHandler);
        function addPageToPrint(title, footer, svg) {
            try {
                el.innerHTML += `<div class="${className}__item">
        <div class="${className}__item__header">
          ${title.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
        </div>
        <div class="${className}__item__main">
          ${svg}
        </div>
        <div class="${className}__item__footer ${className}__item__footer__${footer ? "" : "hide"}">
          ${footer ?? ""}
        </div>
      </div>`;
            } catch (e) {
                console.error(e);
            }
        }
        function triggerPrint() {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isChromeForIos) {
                beforePrintHandler();
                window.print();
            } else if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isSafari) {
                beforePrintHandler();
                document.execCommand("print", false);
            } else {
                window.print();
            }
        }
        const selectedShapeIds = editor.getSelectedShapeIds();
        const currentPageId = editor.getCurrentPageId();
        const pages = editor.getPages();
        const preserveAspectRatio = "xMidYMid meet";
        const svgOpts = {
            scale: 1,
            background: false,
            darkMode: false,
            preserveAspectRatio
        };
        if (editor.getSelectedShapeIds().length > 0) {
            const svgExport = await editor.getSvgString(selectedShapeIds, svgOpts);
            if (svgExport) {
                const page = pages.find({
                    "usePrint.useCallback.printSelectionOrPages.page": (p)=>p.id === currentPageId
                }["usePrint.useCallback.printSelectionOrPages.page"]);
                addPageToPrint(`tldraw \u2014 ${page?.name}`, null, svgExport.svg);
                triggerPrint();
            }
        } else {
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            else {
                const page = editor.getCurrentPage();
                const svgExport = await editor.getSvgString(editor.getSortedChildIdsForParent(page.id), svgOpts);
                if (svgExport) {
                    addPageToPrint(`tldraw \u2014 ${page.name}`, null, svgExport.svg);
                    triggerPrint();
                }
            }
        }
        window.removeEventListener("beforeprint", beforePrintHandler);
        window.removeEventListener("afterprint", afterPrintHandler);
    }, [
        editor
    ]);
}
;
 //# sourceMappingURL=usePrint.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTools.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToolsContext",
    ()=>ToolsContext,
    "ToolsProvider",
    ()=>ToolsProvider,
    "onDragFromToolbarToCreateShape",
    ()=>onDragFromToolbarToCreateShape,
    "useTools",
    ()=>useTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/selectHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EmbedDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/EmbedDialog.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/a11y.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/overrides.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const ToolsContext = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function ToolsProvider({ overrides, children }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaybeEditor"])();
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    const a11y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$a11y$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useA11y"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const helpers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultHelpers"])();
    const onToolSelect = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "ToolsProvider.useCallback[onToolSelect]": (source, tool, id)=>{
            a11y.announce({
                msg: msg(tool.label)
            });
            trackEvent("select-tool", {
                source,
                id: id ?? tool.id
            });
        }
    }["ToolsProvider.useCallback[onToolSelect]"], [
        a11y,
        msg,
        trackEvent
    ]);
    const tools = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "ToolsProvider.useMemo[tools]": ()=>{
            if (!editor) return {};
            const toolsArray = [
                {
                    id: "select",
                    label: "tool.select",
                    icon: "tool-pointer",
                    kbd: "v",
                    readonlyOk: true,
                    onSelect (source) {
                        if (editor.isIn("select")) {
                            const currentNode = editor.root.getCurrent();
                            currentNode.exit({}, currentNode.id);
                            currentNode.enter({}, currentNode.id);
                        }
                        editor.setCurrentTool("select");
                        onToolSelect(source, this);
                    }
                },
                {
                    id: "hand",
                    label: "tool.hand",
                    icon: "tool-hand",
                    kbd: "h",
                    readonlyOk: true,
                    onSelect (source) {
                        editor.setCurrentTool("hand");
                        onToolSelect(source, this);
                    }
                },
                {
                    id: "eraser",
                    label: "tool.eraser",
                    icon: "tool-eraser",
                    kbd: "e",
                    onSelect (source) {
                        editor.setCurrentTool("eraser");
                        onToolSelect(source, this);
                    }
                },
                {
                    id: "draw",
                    label: "tool.draw",
                    icon: "tool-pencil",
                    kbd: "d,b,x",
                    onSelect (source) {
                        editor.setCurrentTool("draw");
                        onToolSelect(source, this);
                    }
                },
                ...[
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeoShapeGeoStyle"].values
                ].map({
                    "ToolsProvider.useMemo[tools]": (geo)=>({
                            id: geo,
                            label: `tool.${geo}`,
                            meta: {
                                geo
                            },
                            kbd: geo === "rectangle" ? "r" : geo === "ellipse" ? "o" : void 0,
                            icon: "geo-" + geo,
                            onSelect (source) {
                                editor.run({
                                    "ToolsProvider.useMemo[tools]": ()=>{
                                        editor.setStyleForNextShapes(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeoShapeGeoStyle"], geo);
                                        editor.setCurrentTool("geo");
                                        onToolSelect(source, this, `geo-${geo}`);
                                    }
                                }["ToolsProvider.useMemo[tools]"]);
                            },
                            onDragStart (source, info) {
                                onDragFromToolbarToCreateShape(editor, info, {
                                    createShape: {
                                        "ToolsProvider.useMemo[tools]": (id)=>editor.createShape({
                                                id,
                                                type: "geo",
                                                props: {
                                                    w: 200,
                                                    h: 200,
                                                    geo
                                                }
                                            })
                                    }["ToolsProvider.useMemo[tools]"]
                                });
                                trackEvent("drag-tool", {
                                    source,
                                    id: "geo"
                                });
                            }
                        })
                }["ToolsProvider.useMemo[tools]"]),
                {
                    id: "arrow",
                    label: "tool.arrow",
                    icon: "tool-arrow",
                    kbd: "a",
                    onSelect (source) {
                        editor.setCurrentTool("arrow");
                        onToolSelect(source, this);
                    },
                    onDragStart (source, info) {
                        onDragFromToolbarToCreateShape(editor, info, {
                            createShape: {
                                "ToolsProvider.useMemo[tools]": (id)=>editor.createShape({
                                        id,
                                        type: "arrow",
                                        props: {
                                            start: {
                                                x: 0,
                                                y: 200
                                            },
                                            end: {
                                                x: 200,
                                                y: 0
                                            }
                                        }
                                    })
                            }["ToolsProvider.useMemo[tools]"]
                        });
                        trackEvent("drag-tool", {
                            source,
                            id: "arrow"
                        });
                    }
                },
                {
                    id: "line",
                    label: "tool.line",
                    icon: "tool-line",
                    kbd: "l",
                    onSelect (source) {
                        editor.setCurrentTool("line");
                        onToolSelect(source, this);
                    },
                    onDragStart (source, info) {
                        onDragFromToolbarToCreateShape(editor, info, {
                            createShape: {
                                "ToolsProvider.useMemo[tools]": (id)=>{
                                    const [start, end] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesBetween"])(null, null, 2);
                                    editor.createShape({
                                        id,
                                        type: "line",
                                        props: {
                                            points: {
                                                [start]: {
                                                    id: start,
                                                    index: start,
                                                    x: 0,
                                                    y: 200
                                                },
                                                [end]: {
                                                    id: end,
                                                    index: end,
                                                    x: 200,
                                                    y: 0
                                                }
                                            }
                                        }
                                    });
                                }
                            }["ToolsProvider.useMemo[tools]"]
                        });
                        trackEvent("drag-tool", {
                            source,
                            id: "line"
                        });
                    }
                },
                {
                    id: "frame",
                    label: "tool.frame",
                    icon: "tool-frame",
                    kbd: "f",
                    onSelect (source) {
                        editor.setCurrentTool("frame");
                        onToolSelect(source, this);
                    },
                    onDragStart (source, info) {
                        onDragFromToolbarToCreateShape(editor, info, {
                            createShape: {
                                "ToolsProvider.useMemo[tools]": (id)=>editor.createShape({
                                        id,
                                        type: "frame"
                                    })
                            }["ToolsProvider.useMemo[tools]"]
                        });
                        trackEvent("drag-tool", {
                            source,
                            id: "frame"
                        });
                    }
                },
                {
                    id: "text",
                    label: "tool.text",
                    icon: "tool-text",
                    kbd: "t",
                    onSelect (source) {
                        editor.setCurrentTool("text");
                        onToolSelect(source, this);
                    },
                    onDragStart (source, info) {
                        onDragFromToolbarToCreateShape(editor, info, {
                            createShape: {
                                "ToolsProvider.useMemo[tools]": (id)=>editor.createShape({
                                        id,
                                        type: "text",
                                        props: {
                                            richText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])("Text")
                                        }
                                    })
                            }["ToolsProvider.useMemo[tools]"],
                            onDragEnd: {
                                "ToolsProvider.useMemo[tools]": (id)=>{
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(editor, id, {
                                        selectAll: true
                                    });
                                }
                            }["ToolsProvider.useMemo[tools]"]
                        });
                        trackEvent("drag-tool", {
                            source,
                            id: "text"
                        });
                    }
                },
                {
                    id: "asset",
                    label: "tool.media",
                    icon: "tool-media",
                    kbd: "cmd+u,ctrl+u",
                    onSelect (source) {
                        helpers.insertMedia();
                        onToolSelect(source, this, "media");
                    }
                },
                {
                    id: "note",
                    label: "tool.note",
                    icon: "tool-note",
                    kbd: "n",
                    onSelect (source) {
                        editor.setCurrentTool("note");
                        onToolSelect(source, this);
                    },
                    onDragStart (source, info) {
                        onDragFromToolbarToCreateShape(editor, info, {
                            createShape: {
                                "ToolsProvider.useMemo[tools]": (id)=>editor.createShape({
                                        id,
                                        type: "note"
                                    })
                            }["ToolsProvider.useMemo[tools]"],
                            onDragEnd: {
                                "ToolsProvider.useMemo[tools]": (id)=>{
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$selectHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startEditingShapeWithRichText"])(editor, id, {
                                        selectAll: true
                                    });
                                }
                            }["ToolsProvider.useMemo[tools]"]
                        });
                        trackEvent("drag-tool", {
                            source,
                            id: "note"
                        });
                    }
                },
                {
                    id: "laser",
                    label: "tool.laser",
                    readonlyOk: true,
                    icon: "tool-laser",
                    kbd: "k",
                    onSelect (source) {
                        editor.setCurrentTool("laser");
                        onToolSelect(source, this);
                    }
                },
                {
                    id: "embed",
                    label: "tool.embed",
                    icon: "dot",
                    onSelect (source) {
                        helpers.addDialog({
                            component: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$EmbedDialog$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmbedDialog"]
                        });
                        onToolSelect(source, this);
                    }
                },
                {
                    id: "highlight",
                    label: "tool.highlight",
                    icon: "tool-highlight",
                    // TODO: pick a better shortcut
                    kbd: "shift+d",
                    onSelect (source) {
                        editor.setCurrentTool("highlight");
                        onToolSelect(source, this);
                    }
                }
            ];
            toolsArray.forEach({
                "ToolsProvider.useMemo[tools]": (t)=>t.onSelect = t.onSelect.bind(t)
            }["ToolsProvider.useMemo[tools]"]);
            const tools2 = Object.fromEntries(toolsArray.map({
                "ToolsProvider.useMemo[tools].tools2": (t)=>[
                        t.id,
                        t
                    ]
            }["ToolsProvider.useMemo[tools].tools2"]));
            if (overrides) {
                return overrides(editor, tools2, helpers);
            }
            return tools2;
        }
    }["ToolsProvider.useMemo[tools]"], [
        overrides,
        editor,
        helpers,
        onToolSelect,
        trackEvent
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ToolsContext.Provider, {
        value: tools,
        children
    });
}
function useTools() {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ToolsContext);
    if (!ctx) {
        throw new Error("useTools must be used within a ToolProvider");
    }
    return ctx;
}
function onDragFromToolbarToCreateShape(editor, info, opts) {
    const { x, y } = editor.inputs.getCurrentPagePoint();
    const stoppingPoint = editor.markHistoryStoppingPoint("drag shape tool");
    editor.setCurrentTool("select.translating");
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
    opts.createShape(id);
    const shape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(editor.getShape(id), "Shape not found");
    const { w, h } = editor.getShapePageBounds(id);
    editor.updateShape({
        id,
        type: shape.type,
        x: x - w / 2,
        y: y - h / 2
    });
    editor.select(id);
    editor.setCurrentTool("select.translating", {
        ...info,
        target: "shape",
        shape: editor.getShape(id),
        isCreating: true,
        creatingMarkId: stoppingPoint,
        onCreate () {
            editor.setCurrentTool("select.idle");
            editor.select(id);
            opts.onDragEnd?.(id);
        }
    });
    editor.getCurrentTool().setCurrentToolIdMask(shape.type);
}
;
 //# sourceMappingURL=useTools.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useFlatten.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "flattenShapesToImages",
    ()=>flattenShapesToImages,
    "useFlatten",
    ()=>useFlatten
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
async function flattenShapesToImages(editor, shapeIds, flattenImageBoundsExpand) {
    const shapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(shapeIds.map((id)=>{
        const shape = editor.getShape(id);
        if (!shape) return;
        const util = editor.getShapeUtil(shape.type);
        if (util.toSvg === void 0) return;
        return shape;
    }));
    if (shapes.length === 0) return;
    if (shapes.length === 1) {
        const shape = shapes[0];
        if (!shape) return;
        if (editor.isShapeOfType(shape, "image")) return;
    }
    const groups = [];
    if (flattenImageBoundsExpand !== void 0) {
        const expandedBounds = shapes.map((shape)=>{
            return {
                shape,
                bounds: editor.getShapeMaskedPageBounds(shape).clone().expandBy(flattenImageBoundsExpand)
            };
        });
        for(let i = 0; i < expandedBounds.length; i++){
            const item = expandedBounds[i];
            if (i === 0) {
                groups[0] = {
                    shapes: [
                        item.shape
                    ],
                    bounds: item.bounds
                };
                continue;
            }
            let didLand = false;
            for (const group of groups){
                if (group.bounds.includes(item.bounds)) {
                    group.shapes.push(item.shape);
                    group.bounds.expand(item.bounds);
                    didLand = true;
                    break;
                }
            }
            if (!didLand) {
                groups.push({
                    shapes: [
                        item.shape
                    ],
                    bounds: item.bounds
                });
            }
        }
    } else {
        const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(shapes.map((shape)=>editor.getShapeMaskedPageBounds(shape)));
        groups.push({
            shapes,
            bounds
        });
    }
    const padding = editor.options.flattenImageBoundsPadding;
    for (const group of groups){
        if (flattenImageBoundsExpand !== void 0) {
            group.bounds.expandBy(-flattenImageBoundsExpand);
        }
        const svgResult = await editor.getSvgString(group.shapes, {
            padding,
            background: false
        });
        if (!svgResult?.svg) continue;
        const asset = await editor.getAssetForExternalContent({
            type: "file",
            file: new File([
                svgResult.svg
            ], "asset.svg", {
                type: "image/svg+xml"
            })
        });
        if (!asset) continue;
        group.asset = asset;
    }
    const createdShapeIds = [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
        for (const group of groups){
            const { asset, bounds, shapes: shapes2 } = group;
            if (!asset) continue;
            const commonAncestorId = editor.findCommonAncestor(shapes2) ?? editor.getCurrentPageId();
            if (!commonAncestorId) continue;
            let index = "a1";
            for (const shape of shapes2){
                if (shape.parentId === commonAncestorId) {
                    if (shape.index > index) {
                        index = shape.index;
                    }
                    break;
                }
            }
            let x;
            let y;
            let rotation;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(commonAncestorId)) {
                const commonAncestor = editor.getShape(commonAncestorId);
                if (!commonAncestor) continue;
                const point = editor.getPointInShapeSpace(commonAncestor, {
                    x: bounds.x,
                    y: bounds.y
                });
                rotation = editor.getShapePageTransform(commonAncestorId).rotation();
                point.sub(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](padding, padding).rot(-rotation));
                x = point.x;
                y = point.y;
            } else {
                x = bounds.x - padding;
                y = bounds.y - padding;
                rotation = 0;
            }
            editor.deleteShapes(shapes2);
            editor.createAssets([
                {
                    ...asset,
                    id: asset.id
                }
            ]);
            const shapeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
            editor.createShape({
                id: shapeId,
                type: "image",
                index,
                parentId: commonAncestorId,
                x,
                y,
                rotation: -rotation,
                props: {
                    assetId: asset.id,
                    w: bounds.w + padding * 2,
                    h: bounds.h + padding * 2
                }
            });
            createdShapeIds.push(shapeId);
        }
    });
    return createdShapeIds;
}
function useFlatten() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useFlatten.useCallback": (ids)=>{
            return flattenShapesToImages(editor, ids);
        }
    }["useFlatten.useCallback"], [
        editor
    ]);
}
;
 //# sourceMappingURL=useFlatten.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/menu-hooks.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "showMenuPaste",
    ()=>showMenuPaste,
    "useAllowGroup",
    ()=>useAllowGroup,
    "useAllowUngroup",
    ()=>useAllowUngroup,
    "useAnySelectedShapesCount",
    ()=>useAnySelectedShapesCount,
    "useCanApplySelectionAction",
    ()=>useCanApplySelectionAction,
    "useCanRedo",
    ()=>useCanRedo,
    "useCanUndo",
    ()=>useCanUndo,
    "useHasLinkShapeSelected",
    ()=>useHasLinkShapeSelected,
    "useIsInSelectState",
    ()=>useIsInSelectState,
    "useOnlyFlippableShape",
    ()=>useOnlyFlippableShape,
    "useShowAutoSizeToggle",
    ()=>useShowAutoSizeToggle,
    "useThreeStackableItems",
    ()=>useThreeStackableItems,
    "useUnlockedSelectedShapesCount",
    ()=>useUnlockedSelectedShapesCount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/shared.mjs [app-client] (ecmascript)");
;
;
function shapesWithUnboundArrows(editor) {
    const selectedShapeIds = editor.getSelectedShapeIds();
    const selectedShapes = selectedShapeIds.map((id)=>{
        return editor.getShape(id);
    });
    return selectedShapes.filter((shape)=>{
        if (!shape) return false;
        if (editor.isShapeOfType(shape, "arrow")) {
            const bindings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, shape);
            if (bindings.start || bindings.end) return false;
        }
        return true;
    });
}
const useThreeStackableItems = ()=>{
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("threeStackableItems", {
        "useThreeStackableItems.useValue": ()=>shapesWithUnboundArrows(editor).length > 2
    }["useThreeStackableItems.useValue"], [
        editor
    ]);
};
const useIsInSelectState = ()=>{
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("isInSelectState", {
        "useIsInSelectState.useValue": ()=>editor.isIn("select")
    }["useIsInSelectState.useValue"], [
        editor
    ]);
};
const useAllowGroup = ()=>{
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("allow group", {
        "useAllowGroup.useValue": ()=>{
            const selectedShapes = editor.getSelectedShapes();
            if (selectedShapes.length < 2) return false;
            for (const shape of selectedShapes){
                if (editor.isShapeOfType(shape, "arrow")) {
                    const bindings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, shape);
                    if (bindings.start) {
                        if (!selectedShapes.some({
                            "useAllowGroup.useValue": (s)=>s.id === bindings.start.toId
                        }["useAllowGroup.useValue"])) {
                            return false;
                        }
                    }
                    if (bindings.end) {
                        if (!selectedShapes.some({
                            "useAllowGroup.useValue": (s)=>s.id === bindings.end.toId
                        }["useAllowGroup.useValue"])) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
    }["useAllowGroup.useValue"], [
        editor
    ]);
};
const useAllowUngroup = ()=>{
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("allowUngroup", {
        "useAllowUngroup.useValue": ()=>editor.getSelectedShapeIds().some({
                "useAllowUngroup.useValue": (id)=>editor.getShape(id)?.type === "group"
            }["useAllowUngroup.useValue"])
    }["useAllowUngroup.useValue"], [
        editor
    ]);
};
const showMenuPaste = typeof window !== "undefined" && "navigator" in window && Boolean(navigator.clipboard) && Boolean(navigator.clipboard.read);
function useAnySelectedShapesCount(min, max) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("selectedShapes", {
        "useAnySelectedShapesCount.useValue": ()=>{
            const len = editor.getSelectedShapes().length;
            if (min === void 0) {
                if (max === void 0) {
                    return len;
                } else {
                    return len <= max;
                }
            } else {
                if (max === void 0) {
                    return len >= min;
                } else {
                    return len >= min && len <= max;
                }
            }
        }
    }["useAnySelectedShapesCount.useValue"], [
        editor,
        min,
        max
    ]);
}
function useUnlockedSelectedShapesCount(min, max) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("selectedShapes", {
        "useUnlockedSelectedShapesCount.useValue": ()=>{
            const len = editor.getSelectedShapes().filter({
                "useUnlockedSelectedShapesCount.useValue": (s)=>!editor.isShapeOrAncestorLocked(s)
            }["useUnlockedSelectedShapesCount.useValue"]).length;
            if (min === void 0) {
                if (max === void 0) {
                    return len;
                } else {
                    return len <= max;
                }
            } else {
                if (max === void 0) {
                    return len >= min;
                } else {
                    return len >= min && len <= max;
                }
            }
        }
    }["useUnlockedSelectedShapesCount.useValue"], [
        editor
    ]);
}
function useShowAutoSizeToggle() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("showAutoSizeToggle", {
        "useShowAutoSizeToggle.useValue": ()=>{
            const selectedShapes = editor.getSelectedShapes();
            return selectedShapes.length === 1 && editor.isShapeOfType(selectedShapes[0], "text") && selectedShapes[0].props.autoSize === false;
        }
    }["useShowAutoSizeToggle.useValue"], [
        editor
    ]);
}
function useHasLinkShapeSelected() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("hasLinkShapeSelected", {
        "useHasLinkShapeSelected.useValue": ()=>{
            const onlySelectedShape = editor.getOnlySelectedShape();
            return !!(onlySelectedShape && onlySelectedShape.type !== "embed" && "url" in onlySelectedShape.props && !onlySelectedShape.isLocked);
        }
    }["useHasLinkShapeSelected.useValue"], [
        editor
    ]);
}
function useOnlyFlippableShape() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("onlyFlippableShape", {
        "useOnlyFlippableShape.useValue": ()=>{
            const shape = editor.getOnlySelectedShape();
            return shape && (editor.isShapeOfType(shape, "group") || editor.isShapeOfType(shape, "image") || editor.isShapeOfType(shape, "arrow") || editor.isShapeOfType(shape, "line") || editor.isShapeOfType(shape, "draw"));
        }
    }["useOnlyFlippableShape.useValue"], [
        editor
    ]);
}
function useCanRedo() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("useCanRedo", {
        "useCanRedo.useValue": ()=>editor.getCanRedo()
    }["useCanRedo.useValue"], [
        editor
    ]);
}
function useCanUndo() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("useCanUndo", {
        "useCanUndo.useValue": ()=>editor.getCanUndo()
    }["useCanUndo.useValue"], [
        editor
    ]);
}
function useCanApplySelectionAction() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("canApplySelectionAction", {
        "useCanApplySelectionAction.useValue": ()=>editor.isIn("select") && editor.getSelectedShapeIds().length > 0
    }["useCanApplySelectionAction.useValue"], [
        editor
    ]);
}
;
 //# sourceMappingURL=menu-hooks.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useLocalStorageState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLocalStorageState",
    ()=>useLocalStorageState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function useLocalStorageState(key, defaultValue) {
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(defaultValue);
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useLayoutEffect({
        "useLocalStorageState.useLayoutEffect": ()=>{
            const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFromLocalStorage"])(key);
            if (value) {
                try {
                    setState(JSON.parse(value));
                } catch  {
                    console.error(`Could not restore value ${key} from local storage.`);
                }
            }
        }
    }["useLocalStorageState.useLayoutEffect"], [
        key
    ]);
    const updateValue = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useLocalStorageState.useCallback[updateValue]": (setter)=>{
            setState({
                "useLocalStorageState.useCallback[updateValue]": (s)=>{
                    const value = typeof setter === "function" ? setter(s) : setter;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInLocalStorage"])(key, JSON.stringify(value));
                    return value;
                }
            }["useLocalStorageState.useCallback[updateValue]"]);
        }
    }["useLocalStorageState.useCallback[updateValue]"], [
        key
    ]);
    return [
        state,
        updateValue
    ];
}
;
 //# sourceMappingURL=useLocalStorageState.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useRelevantStyles.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRelevantStyles",
    ()=>useRelevantStyles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$SharedStylesMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/SharedStylesMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
;
const selectToolStyles = Object.freeze([
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultColorStyle"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDashStyle"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultFillStyle"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultSizeStyle"]
]);
function useRelevantStyles(stylesToCheck = selectToolStyles) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("getRelevantStyles", {
        "useRelevantStyles.useValue": ()=>{
            const styles = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$SharedStylesMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SharedStyleMap"](editor.getSharedStyles());
            const isInShapeSpecificTool = !!editor.root.getCurrent()?.shapeType;
            const hasShapesSelected = editor.isIn("select") && editor.getSelectedShapeIds().length > 0;
            if (styles.size === 0 && editor.isIn("select") && editor.getSelectedShapeIds().length === 0) {
                for (const style of stylesToCheck){
                    styles.applyValue(style, editor.getStyleForNextShape(style));
                }
            }
            if (isInShapeSpecificTool || hasShapesSelected || styles.size > 0) {
                return styles;
            }
            return null;
        }
    }["useRelevantStyles.useValue"], [
        editor
    ]);
}
;
 //# sourceMappingURL=useRelevantStyles.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useKeyboardShortcuts.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areShortcutsDisabled",
    ()=>areShortcutsDisabled,
    "useKeyboardShortcuts",
    ()=>useKeyboardShortcuts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/keyboard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$hotkeys$2d$js$2f$dist$2f$hotkeys$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/hotkeys-js/dist/hotkeys.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$actions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/actions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useReadonly$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useReadonly.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTools.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const SKIP_KBDS = [
    // we set these in useNativeClipboardEvents instead
    "copy",
    "cut",
    "paste",
    // There's also an upload asset action, so we don't want to set the kbd twice
    "asset"
];
function useKeyboardShortcuts() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const isReadonlyMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useReadonly$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadonly"])();
    const actions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$actions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActions"])();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTools"])();
    const isFocused = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("is focused", {
        "useKeyboardShortcuts.useValue[isFocused]": ()=>editor.getInstanceState().isFocused
    }["useKeyboardShortcuts.useValue[isFocused]"], [
        editor
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useKeyboardShortcuts.useEffect": ()=>{
            if (!isFocused) return;
            const disposables = new Array();
            const container = editor.getContainer();
            const hot = {
                "useKeyboardShortcuts.useEffect.hot": (keys, callback)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$hotkeys$2d$js$2f$dist$2f$hotkeys$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(keys, {
                        element: container.ownerDocument.body
                    }, callback);
                    disposables.push({
                        "useKeyboardShortcuts.useEffect.hot": ()=>{
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$hotkeys$2d$js$2f$dist$2f$hotkeys$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].unbind(keys, callback);
                        }
                    }["useKeyboardShortcuts.useEffect.hot"]);
                }
            }["useKeyboardShortcuts.useEffect.hot"];
            const hotUp = {
                "useKeyboardShortcuts.useEffect.hotUp": (keys, callback)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$hotkeys$2d$js$2f$dist$2f$hotkeys$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(keys, {
                        element: container.ownerDocument.body,
                        keyup: true,
                        keydown: false
                    }, callback);
                    disposables.push({
                        "useKeyboardShortcuts.useEffect.hotUp": ()=>{
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$hotkeys$2d$js$2f$dist$2f$hotkeys$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].unbind(keys, callback);
                        }
                    }["useKeyboardShortcuts.useEffect.hotUp"]);
                }
            }["useKeyboardShortcuts.useEffect.hotUp"];
            for (const action of Object.values(actions)){
                if (!action.kbd) continue;
                if (isReadonlyMode && !action.readonlyOk) continue;
                if (SKIP_KBDS.includes(action.id)) continue;
                hot(getHotkeysStringFromKbd(action.kbd), {
                    "useKeyboardShortcuts.useEffect": (event)=>{
                        if (areShortcutsDisabled(editor) && !action.isRequiredA11yAction) return;
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(event);
                        action.onSelect("kbd");
                    }
                }["useKeyboardShortcuts.useEffect"]);
            }
            for (const tool of Object.values(tools)){
                if (!tool.kbd || !tool.readonlyOk && editor.getIsReadonly()) {
                    continue;
                }
                if (SKIP_KBDS.includes(tool.id)) continue;
                hot(getHotkeysStringFromKbd(tool.kbd), {
                    "useKeyboardShortcuts.useEffect": (event)=>{
                        if (areShortcutsDisabled(editor)) return;
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(event);
                        tool.onSelect("kbd");
                    }
                }["useKeyboardShortcuts.useEffect"]);
            }
            hot(",", {
                "useKeyboardShortcuts.useEffect": (e)=>{
                    if (areShortcutsDisabled(editor)) return;
                    if (editor.inputs.keys.has("Comma")) return;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventDefault"])(e);
                    editor.focus();
                    editor.inputs.keys.add("Comma");
                    const { x, y, z } = editor.inputs.getCurrentPagePoint();
                    const screenpoints = editor.pageToScreen({
                        x,
                        y
                    });
                    const info = {
                        type: "pointer",
                        name: "pointer_down",
                        point: {
                            x: screenpoints.x,
                            y: screenpoints.y,
                            z
                        },
                        shiftKey: e.shiftKey,
                        altKey: e.altKey,
                        ctrlKey: e.metaKey || e.ctrlKey,
                        metaKey: e.metaKey,
                        accelKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(e),
                        pointerId: 0,
                        button: 0,
                        isPen: editor.getInstanceState().isPenMode,
                        target: "canvas"
                    };
                    editor.dispatch(info);
                }
            }["useKeyboardShortcuts.useEffect"]);
            hotUp(",", {
                "useKeyboardShortcuts.useEffect": (e)=>{
                    if (areShortcutsDisabled(editor)) return;
                    if (!editor.inputs.keys.has("Comma")) return;
                    editor.inputs.keys.delete("Comma");
                    const { x, y, z } = editor.inputs.getCurrentScreenPoint();
                    const info = {
                        type: "pointer",
                        name: "pointer_up",
                        point: {
                            x,
                            y,
                            z
                        },
                        shiftKey: e.shiftKey,
                        altKey: e.altKey,
                        ctrlKey: e.metaKey || e.ctrlKey,
                        metaKey: e.metaKey,
                        accelKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])(e),
                        pointerId: 0,
                        button: 0,
                        isPen: editor.getInstanceState().isPenMode,
                        target: "canvas"
                    };
                    editor.dispatch(info);
                }
            }["useKeyboardShortcuts.useEffect"]);
            return ({
                "useKeyboardShortcuts.useEffect": ()=>{
                    disposables.forEach({
                        "useKeyboardShortcuts.useEffect": (d)=>d()
                    }["useKeyboardShortcuts.useEffect"]);
                }
            })["useKeyboardShortcuts.useEffect"];
        }
    }["useKeyboardShortcuts.useEffect"], [
        actions,
        tools,
        isReadonlyMode,
        editor,
        isFocused
    ]);
}
function areShortcutsDisabled(editor) {
    return editor.menus.hasAnyOpenMenus() || editor.getEditingShapeId() !== null || editor.getCrashingError() || !editor.user.getAreKeyboardShortcutsEnabled();
}
function getHotkeysStringFromKbd(kbd) {
    return getKeys(kbd).map((kbd2)=>{
        let str = "";
        const shift = kbd2.includes("!");
        const alt = kbd2.includes("?");
        const cmd = kbd2.includes("$");
        const k = kbd2.replace(/[!?$]/g, "");
        if (shift && alt && cmd) {
            str = `cmd+shift+alt+${k},ctrl+shift+alt+${k}`;
        } else if (shift && cmd) {
            str = `cmd+shift+${k},ctrl+shift+${k}`;
        } else if (alt && cmd) {
            str = `cmd+alt+${k},ctrl+alt+${k}`;
        } else if (alt && shift) {
            str = `shift+alt+${k}`;
        } else if (shift) {
            str = `shift+${k}`;
        } else if (alt) {
            str = `alt+${k}`;
        } else if (cmd) {
            str = `cmd+${k},ctrl+${k}`;
        } else {
            str = k;
        }
        return str;
    }).join(",");
}
function getKeys(key) {
    if (typeof key !== "string") key = "";
    key = key.replace(/\s/g, "");
    const keys = key.split(",");
    let index = keys.lastIndexOf("");
    for(; index >= 0;){
        keys[index - 1] += ",";
        keys.splice(index, 1);
        index = keys.lastIndexOf("");
    }
    return keys;
}
;
 //# sourceMappingURL=useKeyboardShortcuts.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useEditorEvents.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useEditorEvents",
    ()=>useEditorEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)");
;
;
;
function useEditorEvents() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const { addToast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToasts"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useEditorEvents.useEffect": ()=>{
            function handleMaxShapes({ name, count }) {
                addToast({
                    title: "Maximum shapes reached",
                    description: `You've reached the maximum number of shapes allowed on ${name} (${count}). Please delete some shapes or move to a different page to continue.`,
                    severity: "warning"
                });
            }
            editor.addListener("max-shapes", handleMaxShapes);
            return ({
                "useEditorEvents.useEffect": ()=>{
                    editor.removeListener("max-shapes", handleMaxShapes);
                }
            })["useEditorEvents.useEffect"];
        }
    }["useEditorEvents.useEffect"], [
        editor,
        addToast
    ]);
}
;
 //# sourceMappingURL=useEditorEvents.mjs.map
}),
]);

//# debugId=01b6a1b3-3c7d-8ee0-1121-3625c6f34aaa
//# sourceMappingURL=c427b_tldraw_dist-esm_lib_ui_hooks_74830e9c._.js.map