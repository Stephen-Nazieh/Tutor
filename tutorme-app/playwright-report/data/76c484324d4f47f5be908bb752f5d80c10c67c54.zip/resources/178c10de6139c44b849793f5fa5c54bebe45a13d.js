(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5d466386._.js",
  "static/chunks/c427b_next_dist_compiled_react-dom_d30f3d84._.js",
  "static/chunks/c427b_next_dist_compiled_react-server-dom-turbopack_1198f657._.js",
  "static/chunks/c427b_next_dist_compiled_next-devtools_index_1a0fa0c9.js",
  "static/chunks/c427b_next_dist_compiled_d799b398._.js",
  "static/chunks/c427b_next_dist_shared_lib_29e162ca._.js",
  "static/chunks/c427b_next_dist_client_71ce798c._.js",
  "static/chunks/c427b_next_dist_f4e600b1._.js",
  "static/chunks/c427b_next_ecfb4640._.js",
  "static/chunks/04567_@sentry_core_build_esm_2a97d179._.js",
  "static/chunks/11ab0_@sentry_core_build_esm_utils_cf3b2ea8._.js",
  "static/chunks/11ab0_@sentry_core_build_esm_tracing_3579609a._.js",
  "static/chunks/11ab0_@sentry_core_build_esm_integrations_553ec06c._.js",
  "static/chunks/11ab0_@sentry_core_build_esm_fe10b13f._.js",
  "static/chunks/11ab0_@sentry_browser_build_npm_esm_dev_916d810a._.js",
  "static/chunks/11ab0_@sentry-internal_browser-utils_build_esm_53208fd9._.js",
  "static/chunks/c427b_@sentry_react_build_esm_d52848cf._.js",
  "static/chunks/c427b_@sentry_nextjs_build_esm_a8990899._.js",
  "static/chunks/11ab0_@sentry-internal_replay_build_npm_esm_index_2e983def.js",
  "static/chunks/c427b_6ebe51de._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_9d520ad5._.js"
],
    source: "entry"
});
