;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="ce43c3e0-675f-5abe-1f62-ab35b4a38d6c")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultEmbedDefinitions.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_EMBED_DEFINITIONS",
    ()=>DEFAULT_EMBED_DEFINITIONS,
    "embedShapePermissionDefaults",
    ()=>embedShapePermissionDefaults,
    "isCustomEmbedDefinition",
    ()=>isCustomEmbedDefinition,
    "isDefaultEmbedDefinitionType",
    ()=>isDefaultEmbedDefinitionType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
;
const TLDRAW_APP_RE = /(^\/[f|p|r|ro|s|v]\/[^/]+\/?$)/;
const DEFAULT_EMBED_DEFINITIONS = [
    {
        type: "tldraw",
        title: "tldraw",
        hostnames: [
            "beta.tldraw.com",
            "tldraw.com",
            "localhost:3000"
        ],
        minWidth: 300,
        minHeight: 300,
        width: 720,
        height: 500,
        doesResize: true,
        overridePermissions: {
            "allow-top-navigation": true
        },
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(TLDRAW_APP_RE)) {
                urlObj.searchParams.append("embed", "true");
                return url;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(TLDRAW_APP_RE)) {
                urlObj.searchParams.delete("embed");
                return url;
            }
            return;
        },
        embedOnPaste: false
    },
    {
        type: "figma",
        title: "Figma",
        hostnames: [
            "figma.com"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        toEmbedUrl: (url)=>{
            if (!!url.match(// eslint-disable-next-line no-useless-escape
            /https:\/\/([\w\.-]+\.)?figma.com\/(file|proto|design)\/([0-9a-zA-Z]{22,128})(?:\/.*)?$/) && !url.includes("figma.com/embed")) {
                return `https://www.figma.com/embed?embed_host=share&url=${url}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/?$/)) {
                const outUrl = urlObj.searchParams.get("url");
                if (outUrl) {
                    return outUrl;
                }
            }
            return;
        },
        embedOnPaste: true
    },
    {
        type: "google_maps",
        title: "Google Maps",
        hostnames: [
            "google.*"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        overridePermissions: {
            "allow-presentation": true
        },
        toEmbedUrl: (url)=>{
            if (url.includes("/maps/embed?")) {
                return url;
            } else if (url.includes("/maps/")) {
                const match = url.match(/@(.*?),(.*?),(.*?)(z|m)/);
                let result;
                if (match) {
                    const [, lat, lng, zoomOrMeters, mapTypeSymbol] = match;
                    const mapType = mapTypeSymbol === "z" ? "roadmap" : "satellite";
                    const z = mapType === "roadmap" ? zoomOrMeters : -Math.log2(parseInt(zoomOrMeters) / 14772321) / 0.8;
                    const host = new URL(url).host.replace("www.", "");
                    result = `https://${host}/maps/embed/v1/view?key=${__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_GC_API_KEY}&center=${lat},${lng}&zoom=${z}&maptype=${mapType}`;
                } else {
                    result = "";
                }
                return result;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (!urlObj) return;
            const matches = urlObj.pathname.match(/^\/maps\/embed\/v1\/view\/?$/);
            if (matches && urlObj.searchParams.has("center") && urlObj.searchParams.get("zoom")) {
                const zoom = urlObj.searchParams.get("zoom") ?? "12";
                const mapType = urlObj.searchParams.get("maptype") ?? "roadmap";
                const zoomOrMeters = mapType === "roadmap" ? zoom : 14772321 * Math.pow(2, parseInt(zoom) * -0.8);
                const [lat, lon] = urlObj.searchParams.get("center").split(",");
                return `https://www.google.com/maps/@${lat},${lon},${zoomOrMeters}${mapType === "roadmap" ? "z" : "m"}`;
            }
            return;
        },
        embedOnPaste: true
    },
    {
        type: "val_town",
        title: "Val Town",
        hostnames: [
            "val.town"
        ],
        minWidth: 260,
        minHeight: 100,
        width: 720,
        height: 500,
        doesResize: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/v\/(.+)\/?/);
            if (matches) {
                return `https://www.val.town/embed/${matches[1]}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/embed\/(.+)\/?/);
            if (matches) {
                return `https://www.val.town/v/${matches[1]}`;
            }
            return;
        },
        embedOnPaste: true
    },
    {
        type: "codesandbox",
        title: "CodeSandbox",
        hostnames: [
            "codesandbox.io"
        ],
        minWidth: 300,
        minHeight: 300,
        width: 720,
        height: 500,
        doesResize: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/s\/([^/]+)\/?/);
            if (matches) {
                return `https://codesandbox.io/embed/${matches[1]}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const matches = urlObj && urlObj.pathname.match(/\/embed\/([^/]+)\/?/);
            if (matches) {
                return `https://codesandbox.io/s/${matches[1]}`;
            }
            return;
        },
        embedOnPaste: true
    },
    {
        type: "codepen",
        title: "Codepen",
        hostnames: [
            "codepen.io"
        ],
        minWidth: 300,
        minHeight: 300,
        width: 520,
        height: 400,
        doesResize: true,
        toEmbedUrl: (url)=>{
            const CODEPEN_URL_REGEXP = /https:\/\/codepen.io\/([^/]+)\/pen\/([^/]+)/;
            const matches = url.match(CODEPEN_URL_REGEXP);
            if (matches) {
                const [_, user, id] = matches;
                return `https://codepen.io/${user}/embed/${id}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const CODEPEN_EMBED_REGEXP = /https:\/\/codepen.io\/([^/]+)\/embed\/([^/]+)/;
            const matches = url.match(CODEPEN_EMBED_REGEXP);
            if (matches) {
                const [_, user, id] = matches;
                return `https://codepen.io/${user}/pen/${id}`;
            }
            return;
        },
        embedOnPaste: true
    },
    {
        type: "scratch",
        title: "Scratch",
        hostnames: [
            "scratch.mit.edu"
        ],
        width: 520,
        height: 400,
        doesResize: false,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const SCRATCH_URL_REGEXP = /https?:\/\/scratch.mit.edu\/projects\/([^/]+)/;
            const matches = url.match(SCRATCH_URL_REGEXP);
            if (matches) {
                const [_, id] = matches;
                return `https://scratch.mit.edu/projects/embed/${id}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const SCRATCH_EMBED_REGEXP = /https:\/\/scratch.mit.edu\/projects\/embed\/([^/]+)/;
            const matches = url.match(SCRATCH_EMBED_REGEXP);
            if (matches) {
                const [_, id] = matches;
                return `https://scratch.mit.edu/projects/${id}`;
            }
            return;
        }
    },
    {
        type: "youtube",
        title: "YouTube",
        hostnames: [
            "*.youtube.com",
            "youtube.com",
            "youtu.be"
        ],
        width: 800,
        height: 450,
        doesResize: true,
        overridePermissions: {
            "allow-presentation": true,
            "allow-popups-to-escape-sandbox": true
        },
        isAspectRatioLocked: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (!urlObj) return;
            const hostname = urlObj.hostname.replace(/^www./, "");
            if (hostname === "youtu.be") {
                const videoId = urlObj.pathname.split("/").filter(Boolean)[0];
                const searchParams = new URLSearchParams(urlObj.search);
                const timeStart = searchParams.get("t");
                if (timeStart) {
                    searchParams.set("start", timeStart);
                    searchParams.delete("t");
                }
                const search = searchParams.toString() ? "?" + searchParams.toString() : "";
                return `https://www.youtube.com/embed/${videoId}${search}`;
            } else if ((hostname === "youtube.com" || hostname === "m.youtube.com") && urlObj.pathname.match(/^\/watch/)) {
                const videoId = urlObj.searchParams.get("v");
                const searchParams = new URLSearchParams(urlObj.search);
                searchParams.delete("v");
                const timeStart = searchParams.get("t");
                if (timeStart) {
                    searchParams.set("start", timeStart);
                    searchParams.delete("t");
                }
                const search = searchParams.toString() ? "?" + searchParams.toString() : "";
                return `https://www.youtube.com/embed/${videoId}${search}`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (!urlObj) return;
            const hostname = urlObj.hostname.replace(/^www./, "");
            if (hostname === "youtube.com") {
                const matches = urlObj.pathname.match(/^\/embed\/([^/]+)\/?/);
                if (matches) {
                    const params = new URLSearchParams(urlObj.search);
                    params.set("v", matches?.[1] ?? "");
                    const timeStart = params.get("start");
                    if (timeStart) {
                        params.set("t", timeStart);
                        params.delete("start");
                    }
                    return `https://www.youtube.com/watch?${params.toString()}`;
                }
            }
            return;
        }
    },
    {
        type: "google_calendar",
        title: "Google Calendar",
        hostnames: [
            "calendar.google.*"
        ],
        width: 720,
        height: 500,
        minWidth: 460,
        minHeight: 360,
        doesResize: true,
        instructionLink: "https://support.google.com/calendar/answer/41207?hl=en",
        overridePermissions: {
            "allow-popups-to-escape-sandbox": true
        },
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const cidQs = urlObj?.searchParams.get("cid");
            if (urlObj?.pathname.match(/\/calendar\/u\/0/) && cidQs) {
                urlObj.pathname = "/calendar/embed";
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                urlObj.searchParams.set("src", cidQs);
                return urlObj.href;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            const srcQs = urlObj?.searchParams.get("src");
            if (urlObj?.pathname.match(/\/calendar\/embed/) && srcQs) {
                urlObj.pathname = "/calendar/u/0";
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                urlObj.searchParams.set("cid", srcQs);
                return urlObj.href;
            }
            return;
        }
    },
    {
        type: "google_slides",
        title: "Google Slides",
        hostnames: [
            "docs.google.*"
        ],
        width: 720,
        height: 500,
        minWidth: 460,
        minHeight: 360,
        doesResize: true,
        overridePermissions: {
            "allow-popups-to-escape-sandbox": true
        },
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj?.pathname.match(/^\/presentation/) && urlObj?.pathname.match(/\/pub\/?$/)) {
                urlObj.pathname = urlObj.pathname.replace(/\/pub$/, "/embed");
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                return urlObj.href;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj?.pathname.match(/^\/presentation/) && urlObj?.pathname.match(/\/embed\/?$/)) {
                urlObj.pathname = urlObj.pathname.replace(/\/embed$/, "/pub");
                const keys = Array.from(urlObj.searchParams.keys());
                for (const key of keys){
                    urlObj.searchParams.delete(key);
                }
                return urlObj.href;
            }
            return;
        }
    },
    {
        type: "github_gist",
        title: "GitHub Gist",
        hostnames: [
            "gist.github.com"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        embedOnPaste: true,
        // Security warning:
        // Gists allow adding .json extensions to the URL which return JSONP.
        // Furthermore, the JSONP can include callbacks that execute arbitrary JavaScript.
        // It _is_ sandboxed by the iframe but we still want to disable it nonetheless.
        // We restrict the id to only allow hexdecimal characters to prevent this.
        // Read more:
        //   https://github.com/bhaveshk90/Content-Security-Policy-CSP-Bypass-Techniques
        //   https://github.com/renniepak/CSPBypass
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/([^/]+)\/([0-9a-f]+)$/)) {
                if (!url.split("/").pop()) return;
                return url;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/([^/]+)\/([0-9a-f]+)$/)) {
                if (!url.split("/").pop()) return;
                return url;
            }
            return;
        }
    },
    {
        type: "replit",
        title: "Replit",
        hostnames: [
            "replit.com"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/@([^/]+)\/([^/]+)/)) {
                urlObj.searchParams.append("embed", "true");
                return urlObj.href;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/\/@([^/]+)\/([^/]+)/) && urlObj.searchParams.has("embed")) {
                urlObj.searchParams.delete("embed");
                return urlObj.href;
            }
            return;
        }
    },
    {
        type: "felt",
        title: "Felt",
        hostnames: [
            "felt.com"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/map\//)) {
                return urlObj.origin + "/embed" + urlObj.pathname;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/map\//)) {
                urlObj.pathname = urlObj.pathname.replace(/^\/embed/, "");
                return urlObj.href;
            }
            return;
        }
    },
    {
        type: "spotify",
        title: "Spotify",
        hostnames: [
            "open.spotify.com"
        ],
        width: 720,
        height: 500,
        minHeight: 500,
        overrideOutlineRadius: 12,
        doesResize: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/(artist|album)\//)) {
                return urlObj.origin + "/embed" + urlObj.pathname;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/(artist|album)\//)) {
                return urlObj.origin + urlObj.pathname.replace(/^\/embed/, "");
            }
            return;
        }
    },
    {
        type: "vimeo",
        title: "Vimeo",
        hostnames: [
            "vimeo.com",
            "player.vimeo.com"
        ],
        width: 640,
        height: 360,
        doesResize: true,
        isAspectRatioLocked: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "vimeo.com") {
                if (urlObj.pathname.match(/^\/[0-9]+/)) {
                    return "https://player.vimeo.com/video/" + urlObj.pathname.split("/")[1] + "?title=0&byline=0";
                }
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "player.vimeo.com") {
                const matches = urlObj.pathname.match(/^\/video\/([^/]+)\/?$/);
                if (matches) {
                    return "https://vimeo.com/" + matches[1];
                }
            }
            return;
        }
    },
    {
        type: "observable",
        title: "Observable",
        hostnames: [
            "observablehq.com"
        ],
        width: 720,
        height: 500,
        doesResize: true,
        isAspectRatioLocked: false,
        backgroundColor: "#fff",
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/@([^/]+)\/([^/]+)\/?$/)) {
                return `${urlObj.origin}/embed${urlObj.pathname}?cell=*`;
            }
            if (urlObj && urlObj.pathname.match(/^\/d\/([^/]+)\/?$/)) {
                const pathName = urlObj.pathname.replace(/^\/d/, "");
                return `${urlObj.origin}/embed${pathName}?cell=*`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.pathname.match(/^\/embed\/@([^/]+)\/([^/]+)\/?$/)) {
                return `${urlObj.origin}${urlObj.pathname.replace("/embed", "")}#cell-*`;
            }
            if (urlObj && urlObj.pathname.match(/^\/embed\/([^/]+)\/?$/)) {
                return `${urlObj.origin}${urlObj.pathname.replace("/embed", "/d")}#cell-*`;
            }
            return;
        }
    },
    {
        type: "desmos",
        title: "Desmos",
        hostnames: [
            "desmos.com"
        ],
        width: 700,
        height: 450,
        doesResize: true,
        embedOnPaste: true,
        toEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "www.desmos.com" && urlObj.pathname.match(/^\/calculator\/([^/]+)\/?$/) && urlObj.search === "" && urlObj.hash === "") {
                return `${url}?embed`;
            }
            return;
        },
        fromEmbedUrl: (url)=>{
            const urlObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseUrl"])(url);
            if (urlObj && urlObj.hostname === "www.desmos.com" && urlObj.pathname.match(/^\/calculator\/([^/]+)\/?$/) && urlObj.search === "?embed" && urlObj.hash === "") {
                return url.replace("?embed", "");
            }
            return;
        }
    }
];
const embedShapePermissionDefaults = {
    // ========================================================================================
    // Disabled permissions
    // ========================================================================================
    // [MDN] Experimental: Allows for downloads to occur without a gesture from the user.
    // [REASON] Disabled because otherwise the <iframe/> can trick the user on behalf of us to perform an action.
    "allow-downloads-without-user-activation": false,
    // [MDN] Allows for downloads to occur with a gesture from the user.
    // [REASON] Disabled because otherwise the <iframe/> can trick the user on behalf of us to perform an action.
    "allow-downloads": false,
    // [MDN] Lets the resource open modal windows.
    // [REASON] The <iframe/> could 'window.prompt("Enter your tldraw password")'.
    "allow-modals": false,
    // [MDN] Lets the resource lock the screen orientation.
    // [REASON] Would interfere with the tldraw interface.
    "allow-orientation-lock": false,
    // [MDN] Lets the resource use the Pointer Lock API.
    // [REASON] Maybe we should allow this for games embeds (scratch/codepen/codesandbox).
    "allow-pointer-lock": false,
    // [MDN] Allows popups (such as window.open(), target="_blank", or showModalDialog()). If this keyword is not used, the popup will silently fail to open.
    // [REASON] We want to allow embeds to link back to their original sites (e.g. YouTube).
    "allow-popups": true,
    // [MDN] Lets the sandboxed document open new windows without those windows inheriting the sandboxing. For example, this can safely sandbox an advertisement without forcing the same restrictions upon the page the ad links to.
    // [REASON] We shouldn't allow popups as an embed could pretend to be us by opening a mocked version of tldraw. This is very unobvious when it is performed as an action within our app.
    "allow-popups-to-escape-sandbox": false,
    // [MDN] Lets the resource start a presentation session.
    // [REASON] Prevents embed from navigating away from tldraw and pretending to be us.
    "allow-presentation": false,
    // [MDN] Experimental: Lets the resource request access to the parent's storage capabilities with the Storage Access API.
    // [REASON] We don't want anyone else to access our storage.
    "allow-storage-access-by-user-activation": false,
    // [MDN] Lets the resource navigate the top-level browsing context (the one named _top).
    // [REASON] Prevents embed from navigating away from tldraw and pretending to be us.
    "allow-top-navigation": false,
    // [MDN] Lets the resource navigate the top-level browsing context, but only if initiated by a user gesture.
    // [REASON] Prevents embed from navigating away from tldraw and pretending to be us.
    "allow-top-navigation-by-user-activation": false,
    // ========================================================================================
    // Enabled permissions
    // ========================================================================================
    // [MDN] Lets the resource run scripts (but not create popup windows).
    "allow-scripts": true,
    // [MDN] If this token is not used, the resource is treated as being from a special origin that always fails the same-origin policy (potentially preventing access to data storage/cookies and some JavaScript APIs).
    "allow-same-origin": true,
    // [MDN] Allows the resource to submit forms. If this keyword is not used, form submission is blocked.
    "allow-forms": true
};
const DEFAULT_EMBED_DEFINITION_TYPES = DEFAULT_EMBED_DEFINITIONS.map((def)=>def.type);
function isDefaultEmbedDefinitionType(type) {
    return DEFAULT_EMBED_DEFINITION_TYPES.includes(type);
}
function isCustomEmbedDefinition(def) {
    return "icon" in def;
}
;
 //# sourceMappingURL=defaultEmbedDefinitions.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/styles.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STYLES",
    ()=>STYLES
]);
const STYLES = {
    color: [
        {
            value: "black",
            icon: "color"
        },
        {
            value: "grey",
            icon: "color"
        },
        {
            value: "light-violet",
            icon: "color"
        },
        {
            value: "violet",
            icon: "color"
        },
        {
            value: "blue",
            icon: "color"
        },
        {
            value: "light-blue",
            icon: "color"
        },
        {
            value: "yellow",
            icon: "color"
        },
        {
            value: "orange",
            icon: "color"
        },
        {
            value: "green",
            icon: "color"
        },
        {
            value: "light-green",
            icon: "color"
        },
        {
            value: "light-red",
            icon: "color"
        },
        {
            value: "red",
            icon: "color"
        }
    ],
    fill: [
        {
            value: "none",
            icon: "fill-none"
        },
        {
            value: "semi",
            icon: "fill-semi"
        },
        {
            value: "solid",
            icon: "fill-solid"
        }
    ],
    fillExtra: [
        {
            value: "pattern",
            icon: "fill-pattern"
        },
        {
            value: "lined-fill",
            icon: "fill-lined-fill"
        },
        {
            value: "fill",
            icon: "fill-fill"
        }
    ],
    dash: [
        {
            value: "draw",
            icon: "dash-draw"
        },
        {
            value: "dashed",
            icon: "dash-dashed"
        },
        {
            value: "dotted",
            icon: "dash-dotted"
        },
        {
            value: "solid",
            icon: "dash-solid"
        }
    ],
    size: [
        {
            value: "s",
            icon: "size-small"
        },
        {
            value: "m",
            icon: "size-medium"
        },
        {
            value: "l",
            icon: "size-large"
        },
        {
            value: "xl",
            icon: "size-extra-large"
        }
    ],
    font: [
        {
            value: "draw",
            icon: "font-draw"
        },
        {
            value: "sans",
            icon: "font-sans"
        },
        {
            value: "serif",
            icon: "font-serif"
        },
        {
            value: "mono",
            icon: "font-mono"
        }
    ],
    textAlign: [
        {
            value: "start",
            icon: "text-align-left"
        },
        {
            value: "middle",
            icon: "text-align-center"
        },
        {
            value: "end",
            icon: "text-align-right"
        }
    ],
    horizontalAlign: [
        {
            value: "start",
            icon: "horizontal-align-start"
        },
        {
            value: "middle",
            icon: "horizontal-align-middle"
        },
        {
            value: "end",
            icon: "horizontal-align-end"
        }
    ],
    verticalAlign: [
        {
            value: "start",
            icon: "vertical-align-start"
        },
        {
            value: "middle",
            icon: "vertical-align-middle"
        },
        {
            value: "end",
            icon: "vertical-align-end"
        }
    ],
    geo: [
        {
            value: "rectangle",
            icon: "geo-rectangle"
        },
        {
            value: "ellipse",
            icon: "geo-ellipse"
        },
        {
            value: "triangle",
            icon: "geo-triangle"
        },
        {
            value: "diamond",
            icon: "geo-diamond"
        },
        {
            value: "star",
            icon: "geo-star"
        },
        {
            value: "pentagon",
            icon: "geo-pentagon"
        },
        {
            value: "hexagon",
            icon: "geo-hexagon"
        },
        {
            value: "octagon",
            icon: "geo-octagon"
        },
        {
            value: "rhombus",
            icon: "geo-rhombus"
        },
        {
            value: "rhombus-2",
            icon: "geo-rhombus-2"
        },
        {
            value: "oval",
            icon: "geo-oval"
        },
        {
            value: "trapezoid",
            icon: "geo-trapezoid"
        },
        {
            value: "arrow-left",
            icon: "geo-arrow-left"
        },
        {
            value: "arrow-up",
            icon: "geo-arrow-up"
        },
        {
            value: "arrow-down",
            icon: "geo-arrow-down"
        },
        {
            value: "arrow-right",
            icon: "geo-arrow-right"
        },
        {
            value: "cloud",
            icon: "geo-cloud"
        },
        {
            value: "x-box",
            icon: "geo-x-box"
        },
        {
            value: "check-box",
            icon: "geo-check-box"
        },
        {
            value: "heart",
            icon: "geo-heart"
        }
    ],
    arrowKind: [
        {
            value: "arc",
            icon: "arrow-arc"
        },
        {
            value: "elbow",
            icon: "arrow-elbow"
        }
    ],
    arrowheadStart: [
        {
            value: "none",
            icon: "arrowhead-none"
        },
        {
            value: "arrow",
            icon: "arrowhead-arrow"
        },
        {
            value: "triangle",
            icon: "arrowhead-triangle"
        },
        {
            value: "square",
            icon: "arrowhead-square"
        },
        {
            value: "dot",
            icon: "arrowhead-dot"
        },
        {
            value: "diamond",
            icon: "arrowhead-diamond"
        },
        {
            value: "inverted",
            icon: "arrowhead-triangle-inverted"
        },
        {
            value: "bar",
            icon: "arrowhead-bar"
        }
    ],
    arrowheadEnd: [
        {
            value: "none",
            icon: "arrowhead-none"
        },
        {
            value: "arrow",
            icon: "arrowhead-arrow"
        },
        {
            value: "triangle",
            icon: "arrowhead-triangle"
        },
        {
            value: "square",
            icon: "arrowhead-square"
        },
        {
            value: "dot",
            icon: "arrowhead-dot"
        },
        {
            value: "diamond",
            icon: "arrowhead-diamond"
        },
        {
            value: "inverted",
            icon: "arrowhead-triangle-inverted"
        },
        {
            value: "bar",
            icon: "arrowhead-bar"
        }
    ],
    spline: [
        {
            value: "line",
            icon: "spline-line"
        },
        {
            value: "cubic",
            icon: "spline-cubic"
        }
    ]
};
;
 //# sourceMappingURL=styles.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/bindings/arrow/ArrowBindingUtil.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowBindingUtil",
    ()=>ArrowBindingUtil,
    "updateArrowTerminal",
    ()=>updateArrowTerminal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$bindings$2f$BindingUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/bindings/BindingUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/shared.mjs [app-client] (ecmascript)");
;
;
class ArrowBindingUtil extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$bindings$2f$BindingUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BindingUtil"] {
    static type = "arrow";
    static props = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingProps"];
    static migrations = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrowBindingMigrations"];
    getDefaultProps() {
        return {
            isPrecise: false,
            isExact: false,
            normalizedAnchor: {
                x: 0.5,
                y: 0.5
            },
            snap: "none"
        };
    }
    // when the binding itself changes
    onAfterCreate({ binding }) {
        const arrow = this.editor.getShape(binding.fromId);
        if (!arrow) return;
        arrowDidUpdate(this.editor, arrow);
    }
    // when the binding itself changes
    onAfterChange({ bindingAfter }) {
        const arrow = this.editor.getShape(bindingAfter.fromId);
        if (!arrow) return;
        arrowDidUpdate(this.editor, arrow);
    }
    // when the arrow itself changes
    onAfterChangeFromShape({ shapeBefore, shapeAfter, reason }) {
        if (reason !== "ancestry" && shapeBefore.parentId === shapeAfter.parentId && shapeBefore.index === shapeAfter.index) {
            return;
        }
        arrowDidUpdate(this.editor, shapeAfter);
    }
    // when the shape an arrow is bound to changes
    onAfterChangeToShape({ binding, shapeBefore, shapeAfter, reason }) {
        if (reason !== "ancestry" && shapeBefore.parentId === shapeAfter.parentId && shapeBefore.index === shapeAfter.index) {
            return;
        }
        reparentArrow(this.editor, binding.fromId);
    }
    // when the arrow is isolated we need to update it's x,y positions
    onBeforeIsolateFromShape({ binding }) {
        const arrow = this.editor.getShape(binding.fromId);
        if (!arrow) return;
        updateArrowTerminal({
            editor: this.editor,
            arrow,
            terminal: binding.props.terminal
        });
    }
}
function reparentArrow(editor, arrowId) {
    const arrow = editor.getShape(arrowId);
    if (!arrow) return;
    const bindings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, arrow);
    const { start, end } = bindings;
    const startShape = start ? editor.getShape(start.toId) : void 0;
    const endShape = end ? editor.getShape(end.toId) : void 0;
    const parentPageId = editor.getAncestorPageId(arrow);
    if (!parentPageId) return;
    let nextParentId;
    if (startShape && endShape) {
        nextParentId = editor.findCommonAncestor([
            startShape,
            endShape
        ]) ?? parentPageId;
    } else if (startShape || endShape) {
        const bindingParentId = (startShape || endShape)?.parentId;
        if (bindingParentId && bindingParentId === arrow.parentId) {
            nextParentId = arrow.parentId;
        } else {
            nextParentId = parentPageId;
        }
    } else {
        return;
    }
    if (nextParentId && nextParentId !== arrow.parentId) {
        editor.reparentShapes([
            arrowId
        ], nextParentId);
    }
    const reparentedArrow = editor.getShape(arrowId);
    if (!reparentedArrow) throw Error("no reparented arrow");
    const startSibling = editor.getShapeNearestSibling(reparentedArrow, startShape);
    const endSibling = editor.getShapeNearestSibling(reparentedArrow, endShape);
    let highestSibling;
    if (startSibling && endSibling) {
        highestSibling = startSibling.index > endSibling.index ? startSibling : endSibling;
    } else if (startSibling && !endSibling) {
        highestSibling = startSibling;
    } else if (endSibling && !startSibling) {
        highestSibling = endSibling;
    } else {
        return;
    }
    let finalIndex;
    const higherSiblings = editor.getSortedChildIdsForParent(highestSibling.parentId).map((id)=>editor.getShape(id)).filter((sibling)=>sibling.index > highestSibling.index);
    if (higherSiblings.length) {
        const nextHighestNonArrowSibling = higherSiblings.find((sibling)=>sibling.type !== "arrow");
        if (// ...then, if we're above the last shape we want to be above...
        reparentedArrow.index > highestSibling.index && // ...but below the next non-arrow sibling...
        (!nextHighestNonArrowSibling || reparentedArrow.index < nextHighestNonArrowSibling.index)) {
            return;
        }
        finalIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexBetween"])(highestSibling.index, higherSiblings[0].index);
    } else {
        finalIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(highestSibling.index);
    }
    if (finalIndex !== reparentedArrow.index) {
        editor.updateShapes([
            {
                id: arrowId,
                type: "arrow",
                index: finalIndex
            }
        ]);
    }
}
function arrowDidUpdate(editor, arrow) {
    const bindings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowBindings"])(editor, arrow);
    for (const handle of [
        "start",
        "end"
    ]){
        const binding = bindings[handle];
        if (!binding) continue;
        const boundShape = editor.getShape(binding.toId);
        const isShapeInSamePageAsArrow = editor.getAncestorPageId(arrow) === editor.getAncestorPageId(boundShape);
        if (!boundShape || !isShapeInSamePageAsArrow) {
            updateArrowTerminal({
                editor,
                arrow,
                terminal: handle,
                unbind: true
            });
        }
    }
    reparentArrow(editor, arrow.id);
}
function updateArrowTerminal({ editor, arrow, terminal, unbind = false, useHandle = false }) {
    const info = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowInfo"])(editor, arrow);
    if (!info) {
        throw new Error("expected arrow info");
    }
    const startPoint = useHandle ? info.start.handle : info.start.point;
    const endPoint = useHandle ? info.end.handle : info.end.point;
    const point = terminal === "start" ? startPoint : endPoint;
    const update = {
        id: arrow.id,
        type: "arrow",
        props: {
            [terminal]: {
                x: point.x,
                y: point.y
            },
            bend: arrow.props.bend
        }
    };
    if (info.type === "arc") {
        const newStart = terminal === "start" ? startPoint : info.start.handle;
        const newEnd = terminal === "end" ? endPoint : info.end.handle;
        const newMidPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Med(newStart, newEnd);
        const lineSegment = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(newStart, newEnd).per().uni().mul(info.handleArc.radius * 2 * Math.sign(arrow.props.bend));
        const intersections = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectLineSegmentCircle"])(info.handleArc.center, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(newMidPoint, lineSegment), info.handleArc.center, info.handleArc.radius);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(intersections?.length === 1);
        const bend = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(newMidPoint, intersections[0]) * Math.sign(arrow.props.bend);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(bend, update.props.bend)) {
            update.props.bend = bend;
        }
    }
    editor.updateShape(update);
    if (unbind) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$shared$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeArrowBinding"])(editor, arrow, terminal);
    }
}
;
 //# sourceMappingURL=ArrowBindingUtil.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawCropHandles.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawCropHandles",
    ()=>TldrawCropHandles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
;
;
;
;
function TldrawCropHandles({ size, width, height, hideAlternateHandles }) {
    const cropStrokeWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size / 3);
    const offset = cropStrokeWidth / 2;
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        className: "tl-overlays__item",
        "aria-hidden": "true",
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("polyline", {
                className: "tl-corner-crop-handle",
                points: `
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)}`,
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.top_left",
                role: "button",
                "aria-label": msg("handle.crop.top-left")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-edge-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                x1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width / 2 - size),
                y1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset),
                x2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width / 2 + size),
                y2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset),
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.top",
                role: "button",
                "aria-label": msg("handle.crop.top")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("polyline", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                points: `
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - size)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)}`,
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.top_right",
                role: "button",
                "aria-label": msg("handle.crop.top-right")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-edge-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                x1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset),
                y1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 - size),
                x2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset),
                y2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 + size),
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.right",
                role: "button",
                "aria-label": msg("handle.crop.right")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("polyline", {
                className: "tl-corner-crop-handle",
                points: `
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - size)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width + offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset)}
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - size)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset)}`,
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.bottom_right",
                role: "button",
                "aria-label": msg("handle.crop.bottom-right")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-edge-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                x1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width / 2 - size),
                y1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset),
                x2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width / 2 + size),
                y2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset),
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.bottom",
                role: "button",
                "aria-label": msg("handle.crop.bottom")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("polyline", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                points: `
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 + size)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset)} 
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height + offset)}
						${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset)},${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - size)}`,
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.bottom_left",
                role: "button",
                "aria-label": msg("handle.crop.bottom-left")
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-crop-edge-handle", {
                    "tl-hidden": hideAlternateHandles
                }),
                x1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset),
                y1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 - size),
                x2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - offset),
                y2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 + size),
                strokeWidth: cropStrokeWidth,
                "data-testid": "selection.crop.left",
                role: "button",
                "aria-label": msg("handle.crop.left")
            })
        ]
    });
}
;
 //# sourceMappingURL=TldrawCropHandles.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawHandles.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawHandles",
    ()=>TldrawHandles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
;
;
function TldrawHandles({ children }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const shouldDisplayHandles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("shouldDisplayHandles", {
        "TldrawHandles.useValue[shouldDisplayHandles]": ()=>{
            if (editor.isInAny("select.idle", "select.pointing_handle", "select.pointing_shape")) {
                return true;
            }
            if (editor.isInAny("select.editing_shape")) {
                const onlySelectedShape = editor.getOnlySelectedShape();
                return onlySelectedShape && editor.isShapeOfType(onlySelectedShape, "note");
            }
            return false;
        }
    }["TldrawHandles.useValue[shouldDisplayHandles]"], [
        editor
    ]);
    if (!shouldDisplayHandles) return null;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        className: "tl-user-handles tl-overlays__item",
        "aria-hidden": "true",
        children
    });
}
;
 //# sourceMappingURL=TldrawHandles.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawOverlays.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawArrowHints",
    ()=>TldrawArrowHints,
    "TldrawOverlays",
    ()=>TldrawOverlays
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditorComponents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/arrowTargetState.mjs [app-client] (ecmascript)");
;
;
;
function TldrawOverlays() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const shouldShowArrowHints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("should show arrow hints", {
        "TldrawOverlays.useValue[shouldShowArrowHints]": ()=>{
            if (editor.isInAny("arrow.idle", "arrow.pointing")) return true;
            if (editor.isIn("select.pointing_handle")) {
                const node = editor.getStateDescendant("select.pointing_handle");
                if (node.info.shape.type === "arrow" && (node.info.handle.id === "start" || node.info.handle.id === "end")) {
                    return true;
                }
            }
            if (editor.isIn("select.dragging_handle")) {
                const node = editor.getStateDescendant("select.dragging_handle");
                if (node.info.shape.type === "arrow" && (node.info.handle.id === "start" || node.info.handle.id === "end")) {
                    return true;
                }
            }
            return false;
        }
    }["TldrawOverlays.useValue[shouldShowArrowHints]"], [
        editor
    ]);
    if (!shouldShowArrowHints) return null;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TldrawArrowHints, {});
}
function TldrawArrowHints() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const { ShapeIndicator } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditorComponents"])();
    const targetInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("arrow target info", {
        "TldrawArrowHints.useValue[targetInfo]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$arrowTargetState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArrowTargetState"])(editor)
    }["TldrawArrowHints.useValue[targetInfo]"], [
        editor
    ]);
    if (!targetInfo) return null;
    const { handlesInPageSpace, snap, anchorInPageSpace, arrowKind, isExact, isPrecise } = targetInfo;
    const showEdgeHints = !isExact && arrowKind === "elbow";
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            ShapeIndicator && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ShapeIndicator, {
                shapeId: targetInfo.target.id
            }),
            showEdgeHints && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                className: "tl-overlays__item",
                "aria-hidden": "true",
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                        cx: anchorInPageSpace.x,
                        cy: anchorInPageSpace.y,
                        className: `tl-arrow-hint-snap tl-arrow-hint-snap__${isPrecise ? snap ?? "none" : "none"}`
                    }),
                    Object.entries(handlesInPageSpace).map(([side, handle])=>{
                        if (!handle.isEnabled) return null;
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                            cx: handle.point.x,
                            cy: handle.point.y,
                            className: "tl-arrow-hint-handle"
                        }, side);
                    })
                ]
            })
        ]
    });
}
;
 //# sourceMappingURL=TldrawOverlays.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawScribble.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawScribble",
    ()=>TldrawScribble
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$getSvgPathFromPoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/getSvgPathFromPoints.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$freehand$2f$getStroke$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/freehand/getStroke.mjs [app-client] (ecmascript)");
;
;
;
;
function TldrawScribble({ scribble, zoom, color, opacity, className }) {
    if (!scribble.points.length) return null;
    const stroke = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$freehand$2f$getStroke$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStroke"])(scribble.points, {
        size: scribble.size / zoom,
        start: {
            taper: scribble.taper,
            easing: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].linear
        },
        last: scribble.state === "complete" || scribble.state === "stopping",
        simulatePressure: false,
        streamline: 0.32
    });
    let d;
    if (stroke.length < 4) {
        const r = scribble.size / zoom / 2;
        const { x, y } = scribble.points[scribble.points.length - 1];
        d = `M ${x - r},${y} a ${r},${r} 0 1,0 ${r * 2},0 a ${r},${r} 0 1,0 ${-r * 2},0`;
    } else {
        d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$getSvgPathFromPoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSvgPathFromPoints"])(stroke);
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        className: className ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-overlays__item", className) : className,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            className: "tl-scribble",
            d,
            fill: color ?? `var(--tl-color-${scribble.color})`,
            opacity: opacity ?? scribble.opacity
        })
    });
}
;
 //# sourceMappingURL=TldrawScribble.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawSelectionForeground.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileRotateHandle",
    ()=>MobileRotateHandle,
    "ResizeHandle",
    ()=>ResizeHandle,
    "RotateCornerHandle",
    ()=>RotateCornerHandle,
    "TldrawSelectionForeground",
    ()=>TldrawSelectionForeground
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useCursor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/environment.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useSelectionEvents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useTransform$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useTransform.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useReadonly$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useReadonly.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawCropHandles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawCropHandles.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const TldrawSelectionForeground = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["track"])(function TldrawSelectionForeground2({ bounds, rotation }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const rSvg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isReadonlyMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useReadonly$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadonly"])();
    const topEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("top");
    const rightEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("right");
    const bottomEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("bottom");
    const leftEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("left");
    const topLeftEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("top_left");
    const topRightEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("top_right");
    const bottomRightEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("bottom_right");
    const bottomLeftEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("bottom_left");
    const isDefaultCursor = editor.getInstanceState().cursor.type === "default";
    const isCoarsePointer = editor.getInstanceState().isCoarsePointer;
    const onlyShape = editor.getOnlySelectedShape();
    const isLockedShape = onlyShape && editor.isShapeOrAncestorLocked(onlyShape);
    const expandOutlineBy = onlyShape ? editor.getShapeUtil(onlyShape).expandSelectionOutlinePx(onlyShape) : 0;
    const expandedBounds = expandOutlineBy instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"] ? bounds.clone().expand(expandOutlineBy).zeroFix() : bounds.clone().expandBy(expandOutlineBy).zeroFix();
    const selectionRotation = editor.getSelectionRotation();
    const isShapeTooCloseToContextualToolbar = selectionRotation / __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] > 1.6 && selectionRotation / __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HALF_PI"] < 2.4;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useTransform$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransform"])(rSvg, bounds?.x, bounds?.y, 1, selectionRotation, {
        x: expandedBounds.x - bounds.x,
        y: expandedBounds.y - bounds.y
    });
    if (onlyShape && editor.isShapeHidden(onlyShape)) return null;
    const zoom = editor.getEfficientZoomLevel();
    const isChangingStyle = editor.getInstanceState().isChangingStyle;
    const width = expandedBounds.width;
    const height = expandedBounds.height;
    const size = 8 / zoom;
    const isTinyX = width < size * 2;
    const isTinyY = height < size * 2;
    const isSmallX = width < size * 4;
    const isSmallY = height < size * 4;
    const isSmallCropX = width < size * 5;
    const isSmallCropY = height < size * 5;
    const mobileHandleMultiplier = isCoarsePointer ? 1.75 : 1;
    const targetSize = 6 / zoom * mobileHandleMultiplier;
    const targetSizeX = (isSmallX ? targetSize / 2 : targetSize) * (mobileHandleMultiplier * 0.75);
    const targetSizeY = (isSmallY ? targetSize / 2 : targetSize) * (mobileHandleMultiplier * 0.75);
    const showSelectionBounds = (onlyShape ? !editor.getShapeUtil(onlyShape).hideSelectionBoundsFg(onlyShape) : true) && !isChangingStyle;
    let shouldDisplayBox = showSelectionBounds && editor.isInAny("select.idle", "select.brushing", "select.scribble_brushing", "select.pointing_canvas", "select.pointing_selection", "select.pointing_shape", "select.crop.idle", "select.crop.pointing_crop", "select.crop.pointing_crop_handle", "select.pointing_resize_handle") || showSelectionBounds && editor.isIn("select.resizing") && onlyShape && editor.isShapeOfType(onlyShape, "text");
    if (onlyShape && shouldDisplayBox) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$environment$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlenv"].isFirefox && editor.isShapeOfType(onlyShape, "embed")) {
            shouldDisplayBox = false;
        }
    }
    const showCropHandles = editor.isInAny("select.crop.idle", "select.crop.pointing_crop", "select.crop.pointing_crop_handle") && !isChangingStyle && !isReadonlyMode;
    const shouldDisplayControls = editor.isInAny("select.idle", "select.pointing_selection", "select.pointing_shape", "select.crop.idle") && !isChangingStyle && !isReadonlyMode;
    const showCornerRotateHandles = !isCoarsePointer && !(isTinyX || isTinyY) && (shouldDisplayControls || showCropHandles) && (onlyShape ? !editor.getShapeUtil(onlyShape).hideRotateHandle(onlyShape) : true) && !isLockedShape;
    const showMobileRotateHandle = isCoarsePointer && (!isSmallX || !isSmallY) && (shouldDisplayControls || showCropHandles) && (onlyShape ? !editor.getShapeUtil(onlyShape).hideRotateHandle(onlyShape) : true) && !isLockedShape;
    const showResizeHandles = shouldDisplayControls && (onlyShape ? editor.getShapeUtil(onlyShape).canResize(onlyShape) && !editor.getShapeUtil(onlyShape).hideResizeHandles(onlyShape) : true) && !showCropHandles && !isLockedShape;
    const hideAlternateCornerHandles = isTinyX || isTinyY;
    const showOnlyOneHandle = isTinyX && isTinyY;
    const hideAlternateCropHandles = isSmallCropX || isSmallCropY;
    const showHandles = showResizeHandles || showCropHandles;
    const hideRotateCornerHandles = !showCornerRotateHandles;
    const hideMobileRotateHandle = !shouldDisplayControls || !showMobileRotateHandle;
    const hideTopLeftCorner = !shouldDisplayControls || !showHandles;
    const hideTopRightCorner = !shouldDisplayControls || !showHandles || hideAlternateCornerHandles;
    const hideBottomLeftCorner = !shouldDisplayControls || !showHandles || hideAlternateCornerHandles;
    const hideBottomRightCorner = !shouldDisplayControls || !showHandles || showOnlyOneHandle && !showCropHandles;
    let hideVerticalEdgeTargets = true;
    let hideHorizontalEdgeTargets = true;
    if (showCropHandles) {
        hideVerticalEdgeTargets = hideAlternateCropHandles;
        hideHorizontalEdgeTargets = hideAlternateCropHandles;
    } else if (showResizeHandles) {
        hideVerticalEdgeTargets = hideAlternateCornerHandles || showOnlyOneHandle || isCoarsePointer;
        const isMobileAndTextShape = isCoarsePointer && onlyShape && onlyShape.type === "text";
        hideHorizontalEdgeTargets = hideVerticalEdgeTargets && !isMobileAndTextShape;
    }
    const textHandleHeight = Math.min(24 / zoom, height - targetSizeY * 3);
    const showTextResizeHandles = shouldDisplayControls && isCoarsePointer && onlyShape && editor.isShapeOfType(onlyShape, "text") && textHandleHeight * zoom >= 4;
    const isMediaShape = onlyShape && (editor.isShapeOfType(onlyShape, "image") || editor.isShapeOfType(onlyShape, "video"));
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        className: "tl-overlays__item tl-selection__fg",
        "data-testid": "selection-foreground",
        "aria-hidden": "true",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
            ref: rSvg,
            children: [
                shouldDisplayBox && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                    className: "tl-selection__fg__outline",
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height)
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RotateCornerHandle, {
                    "data-testid": "selection.rotate.top-left",
                    cx: 0,
                    cy: 0,
                    targetSize,
                    corner: "top_left_rotate",
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nwse-rotate", rotation) : void 0,
                    isHidden: hideRotateCornerHandles
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RotateCornerHandle, {
                    "data-testid": "selection.rotate.top-right",
                    cx: width + targetSize * 3,
                    cy: 0,
                    targetSize,
                    corner: "top_right_rotate",
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nesw-rotate", rotation) : void 0,
                    isHidden: hideRotateCornerHandles
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RotateCornerHandle, {
                    "data-testid": "selection.rotate.bottom-left",
                    cx: 0,
                    cy: height + targetSize * 3,
                    targetSize,
                    corner: "bottom_left_rotate",
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("swne-rotate", rotation) : void 0,
                    isHidden: hideRotateCornerHandles
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RotateCornerHandle, {
                    "data-testid": "selection.rotate.bottom-right",
                    cx: width + targetSize * 3,
                    cy: height + targetSize * 3,
                    targetSize,
                    corner: "bottom_right_rotate",
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("senw-rotate", rotation) : void 0,
                    isHidden: hideRotateCornerHandles
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MobileRotateHandle, {
                    "data-testid": "selection.rotate.mobile",
                    cx: isSmallX ? -targetSize * 1.5 : width / 2,
                    cy: isSmallX ? height / 2 : isMediaShape && !isShapeTooCloseToContextualToolbar ? height + targetSize * 1.5 : -targetSize * 1.5,
                    size,
                    isHidden: hideMobileRotateHandle
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideVerticalEdgeTargets,
                    dataTestId: "selection.resize.top",
                    ariaLabel: msg("handle.resize-top"),
                    x: 0,
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallY ? targetSizeY * 2 : targetSizeY)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSizeY * 2)),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("ns-resize", rotation) : void 0,
                    events: topEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideHorizontalEdgeTargets,
                    dataTestId: "selection.resize.right",
                    ariaLabel: msg("handle.resize-right"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - (isSmallX ? 0 : targetSizeX)),
                    y: 0,
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSizeX * 2)),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("ew-resize", rotation) : void 0,
                    events: rightEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideVerticalEdgeTargets,
                    dataTestId: "selection.resize.bottom",
                    ariaLabel: msg("handle.resize-bottom"),
                    x: 0,
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - (isSmallY ? 0 : targetSizeY)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSizeY * 2)),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("ns-resize", rotation) : void 0,
                    events: bottomEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideHorizontalEdgeTargets,
                    dataTestId: "selection.resize.left",
                    ariaLabel: msg("handle.resize-left"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallX ? targetSizeX * 2 : targetSizeX)),
                    y: 0,
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSizeX * 2)),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("ew-resize", rotation) : void 0,
                    events: leftEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideTopLeftCorner,
                    dataTestId: "selection.target.top-left",
                    ariaLabel: msg("handle.resize-top-left"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallX ? targetSizeX * 2 : targetSizeX * 1.5)),
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallY ? targetSizeY * 2 : targetSizeY * 1.5)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeX * 3),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeY * 3),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nwse-resize", rotation) : void 0,
                    events: topLeftEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideTopRightCorner,
                    dataTestId: "selection.target.top-right",
                    ariaLabel: msg("handle.resize-top-right"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - (isSmallX ? 0 : targetSizeX * 1.5)),
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallY ? targetSizeY * 2 : targetSizeY * 1.5)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeX * 3),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeY * 3),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nesw-resize", rotation) : void 0,
                    events: topRightEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideBottomRightCorner,
                    dataTestId: "selection.target.bottom-right",
                    ariaLabel: msg("handle.resize-bottom-right"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - (isSmallX ? targetSizeX : targetSizeX * 1.5)),
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - (isSmallY ? targetSizeY : targetSizeY * 1.5)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeX * 3),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeY * 3),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nwse-resize", rotation) : void 0,
                    events: bottomRightEvents
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ResizeHandle, {
                    hide: hideBottomLeftCorner,
                    dataTestId: "selection.target.bottom-left",
                    ariaLabel: msg("handle.resize-bottom-left"),
                    x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - (isSmallX ? targetSizeX * 3 : targetSizeX * 1.5)),
                    y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - (isSmallY ? 0 : targetSizeY * 1.5)),
                    width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeX * 3),
                    height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(targetSizeY * 3),
                    cursor: isDefaultCursor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useCursor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCursor"])("nesw-resize", rotation) : void 0,
                    events: bottomLeftEvents
                }),
                showResizeHandles && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.resize.top-left",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-handle", {
                                "tl-hidden": hideTopLeftCorner
                            }),
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - size / 2),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - size / 2),
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)
                        }),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.resize.top-right",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-handle", {
                                "tl-hidden": hideTopRightCorner
                            }),
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - size / 2),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - size / 2),
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)
                        }),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.resize.bottom-right",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-handle", {
                                "tl-hidden": hideBottomRightCorner
                            }),
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - size / 2),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - size / 2),
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)
                        }),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.resize.bottom-left",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-corner-handle", {
                                "tl-hidden": hideBottomLeftCorner
                            }),
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - size / 2),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height - size / 2),
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size)
                        })
                    ]
                }),
                showTextResizeHandles && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.text-resize.left.handle",
                            className: "tl-text-handle",
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(0 - size / 4),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 - textHandleHeight / 2),
                            rx: size / 4,
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size / 2),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(textHandleHeight)
                        }),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                            "data-testid": "selection.text-resize.right.handle",
                            className: "tl-text-handle",
                            rx: size / 4,
                            x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(width - size / 4),
                            y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(height / 2 - textHandleHeight / 2),
                            width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(size / 2),
                            height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(textHandleHeight)
                        })
                    ]
                }),
                showCropHandles && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawCropHandles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawCropHandles"], {
                    ...{
                        size,
                        width,
                        height,
                        hideAlternateHandles: hideAlternateCropHandles
                    }
                })
            ]
        })
    });
});
const ResizeHandle = function ResizeHandle2({ hide, dataTestId, ariaLabel, x, y, width, height, cursor, events }) {
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-resize-handle", "tl-transparent", {
            "tl-hidden": hide
        }),
        "data-testid": dataTestId,
        role: "button",
        "aria-label": ariaLabel,
        pointerEvents: "all",
        x,
        y,
        width,
        height,
        cursor,
        ...events
    });
};
const RotateCornerHandle = function RotateCornerHandle2({ cx, cy, targetSize, corner, cursor, isHidden, "data-testid": testId }) {
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])(corner);
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const label = msg(`handle.rotate.${corner}`);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-transparent", "tl-rotate-corner", {
            "tl-hidden": isHidden
        }),
        "data-testid": testId,
        role: "button",
        "aria-label": label,
        pointerEvents: "all",
        x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(cx - targetSize * 3),
        y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(cy - targetSize * 3),
        width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSize * 3)),
        height: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDomPrecision"])(Math.max(1, targetSize * 3)),
        cursor,
        ...events
    });
};
const SQUARE_ROOT_PI = Math.sqrt(Math.PI);
const MobileRotateHandle = function RotateHandle({ cx, cy, size, isHidden, "data-testid": testId }) {
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useSelectionEvents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionEvents"])("mobile_rotate");
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("zoom level", {
        "RotateHandle.useValue[zoom]": ()=>editor.getEfficientZoomLevel()
    }["RotateHandle.useValue[zoom]"], [
        editor
    ]);
    const bgRadius = Math.max(14 * (1 / zoom), 20 / Math.max(1, zoom));
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
        role: "button",
        "aria-label": msg("handle.rotate.mobile_rotate"),
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                "data-testid": testId,
                pointerEvents: "all",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-transparent", "tl-mobile-rotate__bg", {
                    "tl-hidden": isHidden
                }),
                cx,
                cy,
                r: bgRadius,
                ...events
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("tl-mobile-rotate__fg", {
                    "tl-hidden": isHidden
                }),
                cx,
                cy,
                r: size / SQUARE_ROOT_PI
            })
        ]
    });
};
;
 //# sourceMappingURL=TldrawSelectionForeground.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawShapeIndicators.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawShapeIndicators",
    ()=>TldrawShapeIndicators
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$default$2d$components$2f$DefaultShapeIndicators$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/default-components/DefaultShapeIndicators.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript)");
;
;
function TldrawShapeIndicators() {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const isInSelectState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("is in a valid select state", {
        "TldrawShapeIndicators.useValue[isInSelectState]": ()=>{
            return editor.isInAny("select.idle", "select.brushing", "select.scribble_brushing", "select.editing_shape", "select.pointing_shape", "select.pointing_selection", "select.pointing_handle");
        }
    }["TldrawShapeIndicators.useValue[isInSelectState]"], [
        editor
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$default$2d$components$2f$DefaultShapeIndicators$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultShapeIndicators"], {
        hideAll: !isInSelectState
    });
}
;
 //# sourceMappingURL=TldrawShapeIndicators.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultBindingUtils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultBindingUtils",
    ()=>defaultBindingUtils
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$bindings$2f$arrow$2f$ArrowBindingUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/bindings/arrow/ArrowBindingUtil.mjs [app-client] (ecmascript)");
;
const defaultBindingUtils = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$bindings$2f$arrow$2f$ArrowBindingUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowBindingUtil"]
];
;
 //# sourceMappingURL=defaultBindingUtils.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultExternalContentHandlers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_MAX_ASSET_SIZE",
    ()=>DEFAULT_MAX_ASSET_SIZE,
    "DEFAULT_MAX_IMAGE_DIMENSION",
    ()=>DEFAULT_MAX_IMAGE_DIMENSION,
    "centerSelectionAroundPoint",
    ()=>centerSelectionAroundPoint,
    "createEmptyBookmarkShape",
    ()=>createEmptyBookmarkShape,
    "createShapesForAssets",
    ()=>createShapesForAssets,
    "defaultHandleExternalEmbedContent",
    ()=>defaultHandleExternalEmbedContent,
    "defaultHandleExternalExcalidrawContent",
    ()=>defaultHandleExternalExcalidrawContent,
    "defaultHandleExternalFileAsset",
    ()=>defaultHandleExternalFileAsset,
    "defaultHandleExternalFileContent",
    ()=>defaultHandleExternalFileContent,
    "defaultHandleExternalFileReplaceContent",
    ()=>defaultHandleExternalFileReplaceContent,
    "defaultHandleExternalSvgTextContent",
    ()=>defaultHandleExternalSvgTextContent,
    "defaultHandleExternalTextContent",
    ()=>defaultHandleExternalTextContent,
    "defaultHandleExternalTldrawContent",
    ()=>defaultHandleExternalTldrawContent,
    "defaultHandleExternalUrlAsset",
    ()=>defaultHandleExternalUrlAsset,
    "defaultHandleExternalUrlContent",
    ()=>defaultHandleExternalUrlContent,
    "getAssetInfo",
    ()=>getAssetInfo,
    "getMediaAssetInfoPartial",
    ()=>getMediaAssetInfoPartial,
    "notifyIfFileNotAllowed",
    ()=>notifyIfFileNotAllowed,
    "registerDefaultExternalContentHandlers",
    ()=>registerDefaultExternalContentHandlers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/children/Pointing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$bookmarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/bookmark/bookmarks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/crop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/default-shape-constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/assets/assets.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$excalidraw$2f$putExcalidrawContent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/excalidraw/putExcalidrawContent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/richText.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/text.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const DEFAULT_MAX_IMAGE_DIMENSION = 5e3;
const DEFAULT_MAX_ASSET_SIZE = 10 * 1024 * 1024;
function registerDefaultExternalContentHandlers(editor, options) {
    editor.registerExternalAssetHandler("file", async (externalAsset)=>{
        return defaultHandleExternalFileAsset(editor, externalAsset, options);
    });
    editor.registerExternalAssetHandler("url", async (externalAsset)=>{
        return defaultHandleExternalUrlAsset(editor, externalAsset, options);
    });
    editor.registerExternalContentHandler("svg-text", async (externalContent)=>{
        return defaultHandleExternalSvgTextContent(editor, externalContent);
    });
    editor.registerExternalContentHandler("embed", (externalContent)=>{
        return defaultHandleExternalEmbedContent(editor, externalContent);
    });
    editor.registerExternalContentHandler("files", async (externalContent)=>{
        return defaultHandleExternalFileContent(editor, externalContent, options);
    });
    editor.registerExternalContentHandler("file-replace", async (externalContent)=>{
        return defaultHandleExternalFileReplaceContent(editor, externalContent, options);
    });
    editor.registerExternalContentHandler("text", async (externalContent)=>{
        return defaultHandleExternalTextContent(editor, externalContent);
    });
    editor.registerExternalContentHandler("url", async (externalContent)=>{
        return defaultHandleExternalUrlContent(editor, externalContent, options);
    });
    editor.registerExternalContentHandler("tldraw", async (externalContent)=>{
        return defaultHandleExternalTldrawContent(editor, externalContent);
    });
    editor.registerExternalContentHandler("excalidraw", async (externalContent)=>{
        return defaultHandleExternalExcalidrawContent(editor, externalContent);
    });
}
async function defaultHandleExternalFileAsset(editor, { file, assetId }, options) {
    const isSuccess = notifyIfFileNotAllowed(file, options);
    if (!isSuccess) (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(false, "File checks failed");
    const assetInfo = await getAssetInfo(file, options, assetId);
    const result = await editor.uploadAsset(assetInfo, file);
    assetInfo.props.src = result.src;
    if (result.meta) assetInfo.meta = {
        ...assetInfo.meta,
        ...result.meta
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].create(assetInfo);
}
async function defaultHandleExternalFileReplaceContent(editor, { file, shapeId, isImage }, options) {
    const isSuccess = notifyIfFileNotAllowed(file, options);
    if (!isSuccess) (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(false, "File checks failed");
    const shape = editor.getShape(shapeId);
    if (!shape) (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(false, "Shape not found");
    const hash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForBuffer"])(await file.arrayBuffer());
    const assetId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId(hash);
    editor.createTemporaryAssetPreview(assetId, file);
    const assetInfoPartial = await getMediaAssetInfoPartial(file, assetId, isImage, !isImage);
    editor.createAssets([
        assetInfoPartial
    ]);
    if (shape.type === "image") {
        const imageShape = shape;
        const currentCrop = imageShape.props.crop;
        let newWidth = assetInfoPartial.props.w;
        let newHeight = assetInfoPartial.props.h;
        let newX = imageShape.x;
        let newY = imageShape.y;
        let finalCrop = currentCrop;
        if (currentCrop) {
            const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$crop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCroppedImageDataForReplacedImage"])(imageShape, assetInfoPartial.props.w, assetInfoPartial.props.h);
            finalCrop = result.crop;
            newWidth = result.w;
            newHeight = result.h;
            newX = result.x;
            newY = result.y;
        }
        editor.updateShapes([
            {
                id: imageShape.id,
                type: imageShape.type,
                props: {
                    assetId,
                    crop: finalCrop,
                    w: newWidth,
                    h: newHeight
                },
                x: newX,
                y: newY
            }
        ]);
    } else if (shape.type === "video") {
        editor.updateShapes([
            {
                id: shape.id,
                type: shape.type,
                props: {
                    assetId,
                    w: assetInfoPartial.props.w,
                    h: assetInfoPartial.props.h
                }
            }
        ]);
    }
    const asset = await editor.getAssetForExternalContent({
        type: "file",
        file,
        assetId
    });
    editor.updateAssets([
        {
            ...asset,
            id: assetId
        }
    ]);
    return asset;
}
async function defaultHandleExternalUrlAsset(editor, { url }, { toasts, msg }) {
    let meta;
    try {
        const resp = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(url, {
            method: "GET",
            mode: "no-cors"
        });
        const html = await resp.text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        meta = {
            image: doc.head.querySelector('meta[property="og:image"]')?.getAttribute("content") ?? "",
            favicon: doc.head.querySelector('link[rel="apple-touch-icon"]')?.getAttribute("href") ?? doc.head.querySelector('link[rel="icon"]')?.getAttribute("href") ?? "",
            title: doc.head.querySelector('meta[property="og:title"]')?.getAttribute("content") ?? url,
            description: doc.head.querySelector('meta[property="og:description"]')?.getAttribute("content") ?? ""
        };
        if (!meta.image.startsWith("http")) {
            meta.image = new URL(meta.image, url).href;
        }
        if (!meta.favicon.startsWith("http")) {
            meta.favicon = new URL(meta.favicon, url).href;
        }
    } catch (error) {
        console.error(error);
        toasts.addToast({
            title: msg("assets.url.failed"),
            severity: "error"
        });
        meta = {
            image: "",
            favicon: "",
            title: "",
            description: ""
        };
    }
    return {
        id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForString"])(url)),
        typeName: "asset",
        type: "bookmark",
        props: {
            src: url,
            description: meta.description,
            image: meta.image,
            favicon: meta.favicon,
            title: meta.title
        },
        meta: {}
    };
}
async function defaultHandleExternalSvgTextContent(editor, { point, text }) {
    const position = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : editor.getViewportPageBounds().center);
    const svg = new DOMParser().parseFromString(text, "image/svg+xml").querySelector("svg");
    if (!svg) {
        throw new Error("No <svg/> element present");
    }
    let width = parseFloat(svg.getAttribute("width") || "0");
    let height = parseFloat(svg.getAttribute("height") || "0");
    if (!(width && height)) {
        document.body.appendChild(svg);
        const box = svg.getBoundingClientRect();
        document.body.removeChild(svg);
        width = box.width;
        height = box.height;
    }
    const asset = await editor.getAssetForExternalContent({
        type: "file",
        file: new File([
            text
        ], "asset.svg", {
            type: "image/svg+xml"
        })
    });
    if (!asset) throw Error("Could not create an asset");
    createShapesForAssets(editor, [
        asset
    ], position);
}
function defaultHandleExternalEmbedContent(editor, { point, url, embed }) {
    const position = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : editor.getViewportPageBounds().center);
    const { width, height } = embed;
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
    const newPoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeSnapToGrid"])(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](position.x - (width || 450) / 2, position.y - (height || 450) / 2), editor);
    const shapePartial = {
        id,
        type: "embed",
        x: newPoint.x,
        y: newPoint.y,
        props: {
            w: width,
            h: height,
            url
        }
    };
    if (editor.canCreateShape(shapePartial)) {
        editor.createShape(shapePartial).select(id);
    }
}
async function defaultHandleExternalFileContent(editor, { point, files }, options) {
    const { acceptedImageMimeTypes = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_IMAGE_TYPES"], toasts, msg } = options;
    if (files.length > editor.options.maxFilesAtOnce) {
        toasts.addToast({
            title: msg("assets.files.amount-too-many"),
            severity: "error"
        });
        return;
    }
    const position = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : editor.getViewportPageBounds().center);
    const pagePoint = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](position.x, position.y);
    const assetPartials = [];
    const assetsToUpdate = [];
    for (const file of files){
        const isSuccess = notifyIfFileNotAllowed(file, options);
        if (!isSuccess) continue;
        const assetInfo = await getAssetInfo(file, options);
        if (acceptedImageMimeTypes.includes(file.type)) {
            editor.createTemporaryAssetPreview(assetInfo.id, file);
        }
        assetPartials.push(assetInfo);
        assetsToUpdate.push({
            asset: assetInfo,
            file
        });
    }
    Promise.allSettled(assetsToUpdate.map(async (assetAndFile)=>{
        try {
            const newAsset = await editor.getAssetForExternalContent({
                type: "file",
                file: assetAndFile.file
            });
            if (!newAsset) {
                throw Error("Could not create an asset");
            }
            editor.updateAssets([
                {
                    ...newAsset,
                    id: assetAndFile.asset.id
                }
            ]);
        } catch (error) {
            toasts.addToast({
                title: msg("assets.files.upload-failed"),
                severity: "error"
            });
            console.error(error);
            editor.deleteAssets([
                assetAndFile.asset.id
            ]);
            return;
        }
    }));
    createShapesForAssets(editor, assetPartials, pagePoint);
}
async function defaultHandleExternalTextContent(editor, { point, text, html }) {
    const p = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : editor.getViewportPageBounds().center);
    const defaultProps = editor.getShapeUtil("text").getDefaultProps();
    const cleanedUpPlaintext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanupText"])(text);
    const richTextToPaste = html ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderRichTextFromHTML"])(editor, html) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRichText"])(cleanedUpPlaintext);
    let w;
    let h;
    let autoSize;
    let align = "middle";
    const htmlToMeasure = html ?? cleanedUpPlaintext.replace(/\n/g, "<br>");
    const isMultiLine = html ? richTextToPaste.content.length > 1 : cleanedUpPlaintext.split("\n").length > 1;
    const isRtl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRightToLeftLanguage"])(cleanedUpPlaintext);
    if (isMultiLine) {
        align = isMultiLine ? isRtl ? "end" : "start" : "middle";
    }
    const rawSize = editor.textMeasure.measureHtml(htmlToMeasure, {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_PROPS"],
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FONT_FAMILIES"][defaultProps.font],
        fontSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FONT_SIZES"][defaultProps.size],
        maxWidth: null
    });
    const minWidth = Math.min(isMultiLine ? editor.getViewportPageBounds().width * 0.9 : 920, Math.max(200, editor.getViewportPageBounds().width * 0.9));
    if (rawSize.w > minWidth) {
        const shrunkSize = editor.textMeasure.measureHtml(htmlToMeasure, {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_PROPS"],
            fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FONT_FAMILIES"][defaultProps.font],
            fontSize: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$default$2d$shape$2d$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FONT_SIZES"][defaultProps.size],
            maxWidth: minWidth
        });
        w = shrunkSize.w;
        h = shrunkSize.h;
        autoSize = false;
        align = isRtl ? "end" : "start";
    } else {
        w = Math.max(rawSize.w, 10);
        h = Math.max(rawSize.h, 10);
        autoSize = true;
    }
    if (p.y - h / 2 < editor.getViewportPageBounds().minY + 40) {
        p.y = editor.getViewportPageBounds().minY + 40 + h / 2;
    }
    const newPoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeSnapToGrid"])(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](p.x - w / 2, p.y - h / 2), editor);
    const shapeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
    editor.createShapes([
        {
            id: shapeId,
            type: "text",
            x: newPoint.x,
            y: newPoint.y,
            props: {
                richText: richTextToPaste,
                // if the text has more than one line, align it to the left
                textAlign: align,
                autoSize,
                w
            }
        }
    ]);
}
async function defaultHandleExternalUrlContent(editor, { point, url }, { toasts, msg }) {
    const embedUtil = editor.getShapeUtil("embed");
    const embedInfo = embedUtil?.getEmbedDefinition(url);
    if (embedInfo && embedInfo.definition.embedOnPaste !== false) {
        return editor.putExternalContent({
            type: "embed",
            url: embedInfo.url,
            point,
            embed: embedInfo.definition
        });
    }
    const position = point ?? (editor.inputs.getShiftKey() ? editor.inputs.getCurrentPagePoint() : editor.getViewportPageBounds().center);
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$bookmarks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBookmarkFromUrl"])(editor, {
        url,
        center: position
    });
    if (!result.ok) {
        toasts.addToast({
            title: msg("assets.url.failed"),
            severity: "error"
        });
        return;
    }
}
async function defaultHandleExternalTldrawContent(editor, { point, content }) {
    editor.run(()=>{
        const selectionBoundsBefore = editor.getSelectionPageBounds();
        editor.markHistoryStoppingPoint("paste");
        for (const shape of content.shapes){
            if (content.rootShapeIds.includes(shape.id)) {
                shape.isLocked = false;
            }
        }
        editor.putContentOntoCurrentPage(content, {
            point,
            select: true
        });
        const selectedBoundsAfter = editor.getSelectionPageBounds();
        if (selectionBoundsBefore && selectedBoundsAfter && selectionBoundsBefore?.collides(selectedBoundsAfter)) {
            editor.updateInstanceState({
                isChangingStyle: true
            });
            editor.timers.setTimeout(()=>{
                editor.updateInstanceState({
                    isChangingStyle: false
                });
            }, 150);
        }
    });
}
async function defaultHandleExternalExcalidrawContent(editor, { point, content }) {
    editor.run(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$excalidraw$2f$putExcalidrawContent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putExcalidrawContent"])(editor, content, point);
    });
}
async function getMediaAssetInfoPartial(file, assetId, isImageType, isVideoType, maxImageDimension) {
    let fileType = file.type;
    if (file.type === "video/quicktime") {
        fileType = "video/mp4";
    }
    const size = isImageType ? await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].getImageSize(file) : await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].getVideoSize(file);
    const isAnimated = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].isAnimated(file) || isVideoType;
    const assetInfo = {
        id: assetId,
        type: isImageType ? "image" : "video",
        typeName: "asset",
        props: {
            name: file.name,
            src: "",
            w: size.w,
            h: size.h,
            fileSize: file.size,
            mimeType: fileType,
            isAnimated
        },
        meta: {}
    };
    if (maxImageDimension && isFinite(maxImageDimension)) {
        const size2 = {
            w: assetInfo.props.w,
            h: assetInfo.props.h
        };
        const resizedSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["containBoxSize"])(size2, {
            w: maxImageDimension,
            h: maxImageDimension
        });
        if (size2 !== resizedSize && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MediaHelpers"].isStaticImageType(file.type)) {
            assetInfo.props.w = resizedSize.w;
            assetInfo.props.h = resizedSize.h;
        }
    }
    return assetInfo;
}
async function createShapesForAssets(editor, assets, position) {
    if (!assets.length) return [];
    const currentPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(position);
    const partials = [];
    for(let i = 0; i < assets.length; i++){
        const asset = assets[i];
        switch(asset.type){
            case "image":
                {
                    partials.push({
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(),
                        type: "image",
                        x: currentPoint.x,
                        y: currentPoint.y,
                        opacity: 1,
                        props: {
                            assetId: asset.id,
                            w: asset.props.w,
                            h: asset.props.h
                        }
                    });
                    currentPoint.x += asset.props.w;
                    break;
                }
            case "video":
                {
                    partials.push({
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(),
                        type: "video",
                        x: currentPoint.x,
                        y: currentPoint.y,
                        opacity: 1,
                        props: {
                            assetId: asset.id,
                            w: asset.props.w,
                            h: asset.props.h
                        }
                    });
                    currentPoint.x += asset.props.w;
                }
        }
    }
    editor.run(()=>{
        const assetsToCreate = assets.filter((asset)=>!editor.getAsset(asset.id));
        editor.store.atomic(()=>{
            if (editor.canCreateShapes(partials)) {
                if (assetsToCreate.length) {
                    editor.createAssets(assetsToCreate);
                }
                editor.createShapes(partials).select(...partials.map((p)=>p.id));
                centerSelectionAroundPoint(editor, position);
            }
        });
    });
    return partials.map((p)=>p.id);
}
function centerSelectionAroundPoint(editor, position) {
    const viewportPageBounds = editor.getViewportPageBounds();
    let selectionPageBounds = editor.getSelectionPageBounds();
    if (selectionPageBounds) {
        const offset = selectionPageBounds.center.sub(position);
        editor.updateShapes(editor.getSelectedShapes().map((shape)=>{
            const localRotation = editor.getShapeParentTransform(shape).decompose().rotation;
            const localDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Rot(offset, -localRotation);
            return {
                id: shape.id,
                type: shape.type,
                x: shape.x - localDelta.x,
                y: shape.y - localDelta.y
            };
        }));
    }
    selectionPageBounds = editor.getSelectionPageBounds();
    if (selectionPageBounds && editor.getInstanceState().isGridMode) {
        const gridSize = editor.getDocumentSettings().gridSize;
        const topLeft = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](selectionPageBounds.minX, selectionPageBounds.minY);
        const gridSnappedPoint = topLeft.clone().snapToGrid(gridSize);
        const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(topLeft, gridSnappedPoint);
        editor.updateShapes(editor.getSelectedShapes().map((shape)=>{
            const newPoint = {
                x: shape.x - delta.x,
                y: shape.y - delta.y
            };
            return {
                id: shape.id,
                type: shape.type,
                x: newPoint.x,
                y: newPoint.y
            };
        }));
    }
    selectionPageBounds = editor.getSelectionPageBounds();
    if (selectionPageBounds && !viewportPageBounds.contains(selectionPageBounds)) {
        editor.zoomToSelection({
            animation: {
                duration: editor.options.animationMediumMs
            }
        });
    }
}
function createEmptyBookmarkShape(editor, url, position) {
    const partial = {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(),
        type: "bookmark",
        x: position.x - 150,
        y: position.y - 160,
        opacity: 1,
        props: {
            assetId: null,
            url
        }
    };
    editor.run(()=>{
        editor.createShape(partial);
        if (!editor.getShape(partial.id)) return;
        editor.select(partial.id);
        centerSelectionAroundPoint(editor, position);
    });
    return editor.getShape(partial.id);
}
function notifyIfFileNotAllowed(file, options) {
    const { acceptedImageMimeTypes = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_IMAGE_TYPES"], acceptedVideoMimeTypes = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORT_VIDEO_TYPES"], maxAssetSize = DEFAULT_MAX_ASSET_SIZE, toasts, msg } = options;
    const isImageType = acceptedImageMimeTypes.includes(file.type);
    const isVideoType = acceptedVideoMimeTypes.includes(file.type);
    if (!isImageType && !isVideoType) {
        toasts.addToast({
            title: msg("assets.files.type-not-allowed"),
            severity: "error"
        });
        return false;
    }
    if (file.size > maxAssetSize) {
        const formatBytes = (bytes)=>{
            if (bytes === 0) return "0 bytes";
            const units = [
                "bytes",
                "KB",
                "MB",
                "GB",
                "TB",
                "PB"
            ];
            const base = 1024;
            const unitIndex = Math.floor(Math.log(bytes) / Math.log(base));
            const value = bytes / Math.pow(base, unitIndex);
            const formatted = value % 1 === 0 ? value.toString() : value.toFixed(1);
            return `${formatted} ${units[unitIndex]}`;
        };
        toasts.addToast({
            title: msg("assets.files.size-too-big"),
            description: msg("assets.files.maximum-size").replace("{size}", formatBytes(maxAssetSize)),
            severity: "error"
        });
        return false;
    }
    if (!file.type) {
        toasts.addToast({
            title: msg("assets.files.upload-failed"),
            severity: "error"
        });
        console.error("No mime type");
        return false;
    }
    return true;
}
async function getAssetInfo(file, options, assetId) {
    const { acceptedImageMimeTypes = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_IMAGE_TYPES"], acceptedVideoMimeTypes = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORT_VIDEO_TYPES"], maxImageDimension = DEFAULT_MAX_IMAGE_DIMENSION } = options;
    const isImageType = acceptedImageMimeTypes.includes(file.type);
    const isVideoType = acceptedVideoMimeTypes.includes(file.type);
    const hash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashForBuffer"])(await file.arrayBuffer());
    assetId ??= __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetRecordType"].createId(hash);
    const assetInfo = await getMediaAssetInfoPartial(file, assetId, isImageType, isVideoType, maxImageDimension);
    return assetInfo;
}
;
 //# sourceMappingURL=defaultExternalContentHandlers.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultShapeTools.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultShapeTools",
    ()=>defaultShapeTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$ArrowShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/ArrowShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$draw$2f$DrawShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/draw/DrawShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$frame$2f$FrameShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/frame/FrameShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$geo$2f$GeoShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/geo/GeoShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$highlight$2f$HighlightShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/highlight/HighlightShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$line$2f$LineShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/line/LineShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$NoteShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/note/NoteShapeTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$text$2f$TextShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/text/TextShapeTool.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const defaultShapeTools = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$text$2f$TextShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$draw$2f$DrawShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$geo$2f$GeoShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeoShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$NoteShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NoteShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$line$2f$LineShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$frame$2f$FrameShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FrameShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$ArrowShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowShapeTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$highlight$2f$HighlightShapeTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HighlightShapeTool"]
];
;
 //# sourceMappingURL=defaultShapeTools.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultShapeUtils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultShapeUtils",
    ()=>defaultShapeUtils
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$ArrowShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/arrow/ArrowShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$BookmarkShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/bookmark/BookmarkShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$draw$2f$DrawShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/draw/DrawShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$embed$2f$EmbedShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/embed/EmbedShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$frame$2f$FrameShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/frame/FrameShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$geo$2f$GeoShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/geo/GeoShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$highlight$2f$HighlightShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/highlight/HighlightShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$image$2f$ImageShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/image/ImageShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$line$2f$LineShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/line/LineShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$NoteShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/note/NoteShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$text$2f$TextShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/text/TextShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$video$2f$VideoShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/video/VideoShapeUtil.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const defaultShapeUtils = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$text$2f$TextShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$bookmark$2f$BookmarkShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BookmarkShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$draw$2f$DrawShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$geo$2f$GeoShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeoShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$note$2f$NoteShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NoteShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$line$2f$LineShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$frame$2f$FrameShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FrameShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$arrow$2f$ArrowShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$highlight$2f$HighlightShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HighlightShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$embed$2f$EmbedShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmbedShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$image$2f$ImageShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageShapeUtil"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$video$2f$VideoShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VideoShapeUtil"]
];
;
 //# sourceMappingURL=defaultShapeUtils.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultSideEffects.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "registerDefaultSideEffects",
    ()=>registerDefaultSideEffects
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/selection-logic/updateHoveredShapeId.mjs [app-client] (ecmascript)");
;
function registerDefaultSideEffects(editor) {
    return editor.sideEffects.register({
        instance: {
            afterChange: (prev, next)=>{
                if (prev.cameraState !== next.cameraState && next.cameraState === "idle") {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$selection$2d$logic$2f$updateHoveredShapeId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateHoveredShapeId"])(editor);
                }
            }
        },
        instance_page_state: {
            afterChange: (prev, next)=>{
                if (prev.croppingShapeId !== next.croppingShapeId) {
                    const isInCroppingState = editor.isIn("select.crop");
                    if (!prev.croppingShapeId && next.croppingShapeId) {
                        if (!isInCroppingState) {
                            editor.setCurrentTool("select.crop.idle");
                        }
                    } else if (prev.croppingShapeId && !next.croppingShapeId) {
                        if (isInCroppingState) {
                            editor.setCurrentTool("select.idle");
                        }
                    }
                }
                if (prev.editingShapeId !== next.editingShapeId) {
                    if (!prev.editingShapeId && next.editingShapeId) {
                        if (!editor.isIn("select.editing_shape")) {
                            const shape = editor.getEditingShape();
                            if (shape && shape.type === "text" && editor.isInAny("text.pointing", "select.resizing") && editor.getInstanceState().isToolLocked) {
                                editor.setCurrentTool("select.editing_shape", {
                                    target: "shape",
                                    shape,
                                    isCreatingTextWhileToolLocked: true
                                });
                            } else {
                                editor.setCurrentTool("select.editing_shape", {
                                    target: "shape",
                                    shape
                                });
                            }
                        }
                    } else if (prev.editingShapeId && !next.editingShapeId) {
                        if (editor.isIn("select.editing_shape")) {
                            editor.setCurrentTool("select.idle");
                        }
                    }
                }
            }
        }
    });
}
;
 //# sourceMappingURL=defaultSideEffects.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultTools.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultTools",
    ()=>defaultTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$EraserTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/EraserTool/EraserTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$HandTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/HandTool/HandTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$LaserTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/LaserTool/LaserTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$SelectTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/SelectTool/SelectTool.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$ZoomTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/tools/ZoomTool/ZoomTool.mjs [app-client] (ecmascript)");
;
;
;
;
;
const defaultTools = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$EraserTool$2f$EraserTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EraserTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$HandTool$2f$HandTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$LaserTool$2f$LaserTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LaserTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$ZoomTool$2f$ZoomTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZoomTool"],
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$tools$2f$SelectTool$2f$SelectTool$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTool"]
];
;
 //# sourceMappingURL=defaultTools.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/Tldraw.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tldraw",
    ()=>Tldraw
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$TldrawEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/TldrawEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLUserPreferences.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditorComponents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useIdentity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawHandles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawHandles.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawOverlays$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawOverlays.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawScribble.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawSelectionForeground$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawSelectionForeground.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawShapeIndicators$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/canvas/TldrawShapeIndicators.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultBindingUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultBindingUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultExternalContentHandlers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultExternalContentHandlers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultShapeTools.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultShapeUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultSideEffects.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultTools.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$embed$2f$EmbedShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/embed/EmbedShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$defaultFonts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/shapes/shared/defaultFonts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$TldrawUi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/TldrawUi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/assetUrls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$LoadingScreen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/LoadingScreen.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Spinner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/components/Spinner.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/asset-urls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/components.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/events.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/context/toasts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/hooks/useTranslation/useTranslation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/ui/overrides.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$static$2d$assets$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/static-assets/assetUrls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/richText.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const allDefaultTools = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultTools"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeTools$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultShapeTools"]
];
function Tldraw(props) {
    const { children, maxImageDimension, maxAssetSize, acceptedImageMimeTypes, acceptedVideoMimeTypes, onMount, components = {}, shapeUtils = [], bindingUtils = [], tools = [], embeds, options, // needs to be here for backwards compatibility with TldrawEditor
    // eslint-disable-next-line @typescript-eslint/no-deprecated
    textOptions: _textOptions, ...rest } = props;
    const _components = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowObjectIdentity"])(components);
    const CustomInFrontOfTheCanvas = components?.InFrontOfTheCanvas;
    const InFrontOfTheCanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[InFrontOfTheCanvas]": ()=>{
            if (rest.hideUi) return CustomInFrontOfTheCanvas ?? null;
            if (!CustomInFrontOfTheCanvas) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$TldrawUi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiInFrontOfTheCanvas"];
            return ({
                "Tldraw.useMemo[InFrontOfTheCanvas]": ()=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$TldrawUi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiInFrontOfTheCanvas"], {}),
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CustomInFrontOfTheCanvas, {})
                        ]
                    })
            })["Tldraw.useMemo[InFrontOfTheCanvas]"];
        }
    }["Tldraw.useMemo[InFrontOfTheCanvas]"], [
        rest.hideUi,
        CustomInFrontOfTheCanvas
    ]);
    const componentsWithDefault = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[componentsWithDefault]": ()=>({
                Scribble: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawScribble"],
                ShapeIndicators: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawShapeIndicators$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawShapeIndicators"],
                CollaboratorScribble: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawScribble$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawScribble"],
                SelectionForeground: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawSelectionForeground$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawSelectionForeground"],
                Handles: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawHandles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawHandles"],
                Overlays: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$canvas$2f$TldrawOverlays$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawOverlays"],
                Spinner: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$Spinner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Spinner"],
                LoadingScreen: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$components$2f$LoadingScreen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadingScreen"],
                ..._components,
                InFrontOfTheCanvas
            })
    }["Tldraw.useMemo[componentsWithDefault]"], [
        _components,
        InFrontOfTheCanvas
    ]);
    const _shapeUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(shapeUtils);
    const shapeUtilsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[shapeUtilsWithDefaults]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"])("type", _shapeUtils, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultShapeUtils"])
    }["Tldraw.useMemo[shapeUtilsWithDefaults]"], [
        _shapeUtils
    ]);
    const _bindingUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(bindingUtils);
    const bindingUtilsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[bindingUtilsWithDefaults]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"])("type", _bindingUtils, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultBindingUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultBindingUtils"])
    }["Tldraw.useMemo[bindingUtilsWithDefaults]"], [
        _bindingUtils
    ]);
    const _tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(tools);
    const toolsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[toolsWithDefaults]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"])("id", _tools, allDefaultTools)
    }["Tldraw.useMemo[toolsWithDefaults]"], [
        _tools
    ]);
    const _imageMimeTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(acceptedImageMimeTypes ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORTED_IMAGE_TYPES"]);
    const _videoMimeTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(acceptedVideoMimeTypes ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SUPPORT_VIDEO_TYPES"]);
    const _mergedTextOptions = options?.text ?? _textOptions;
    const textOptionsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[textOptionsWithDefaults]": ()=>{
            return {
                addFontsFromNode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultAddFontsFromNode"],
                ..._mergedTextOptions,
                tipTapConfig: {
                    extensions: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tipTapDefaultExtensions"],
                    ..._mergedTextOptions?.tipTapConfig
                }
            };
        }
    }["Tldraw.useMemo[textOptionsWithDefaults]"], [
        _mergedTextOptions
    ]);
    const optionsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[optionsWithDefaults]": ()=>({
                ...options,
                text: textOptionsWithDefaults
            })
    }["Tldraw.useMemo[optionsWithDefaults]"], [
        options,
        textOptionsWithDefaults
    ]);
    const mediaMimeTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Tldraw.useMemo[mediaMimeTypes]": ()=>[
                ..._imageMimeTypes,
                ..._videoMimeTypes
            ]
    }["Tldraw.useMemo[mediaMimeTypes]"], [
        _imageMimeTypes,
        _videoMimeTypes
    ]);
    const assets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$static$2d$assets$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultEditorAssetsWithOverrides"])(rest.assetUrls);
    const embedShapeUtil = shapeUtilsWithDefaults.find((util)=>util.type === "embed");
    if (embedShapeUtil && embeds) {
        __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$embed$2f$EmbedShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmbedShapeUtil"].setEmbedDefinitions(embeds);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$asset$2d$urls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssetUrlsProvider"], {
        assetUrls: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultUiAssetUrlsWithOverrides"])(rest.assetUrls),
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUiTranslationProvider"], {
            overrides: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$overrides$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedTranslationOverrides"])(rest.overrides),
            locale: rest.user?.userPreferences.get().locale ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].locale,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$TldrawEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawEditor"], {
                initialState: "select",
                ...rest,
                components: componentsWithDefault,
                shapeUtils: shapeUtilsWithDefaults,
                bindingUtils: bindingUtilsWithDefaults,
                tools: toolsWithDefaults,
                options: optionsWithDefaults,
                assetUrls: assets,
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$TldrawUi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TldrawUi"], {
                    ...rest,
                    components: componentsWithDefault,
                    mediaMimeTypes,
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InsideOfEditorAndUiContext, {
                            maxImageDimension,
                            maxAssetSize,
                            acceptedImageMimeTypes: _imageMimeTypes,
                            acceptedVideoMimeTypes: _videoMimeTypes,
                            onMount
                        }),
                        children
                    ]
                })
            })
        })
    });
}
function InsideOfEditorAndUiContext({ maxImageDimension, maxAssetSize, acceptedImageMimeTypes, acceptedVideoMimeTypes, onMount }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const toasts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$toasts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToasts"])();
    const msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$hooks$2f$useTranslation$2f$useTranslation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$events$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUiEvents"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$TldrawEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnMount"])({
        "InsideOfEditorAndUiContext.useOnMount": ()=>{
            const unsubs = [];
            unsubs.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultSideEffects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerDefaultSideEffects"])(editor));
            editor.fonts.requestFonts(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$shapes$2f$shared$2f$defaultFonts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["allDefaultFontFaces"]);
            editor.once("edit", {
                "InsideOfEditorAndUiContext.useOnMount": ()=>trackEvent("edit", {
                        source: "unknown"
                    })
            }["InsideOfEditorAndUiContext.useOnMount"]);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultExternalContentHandlers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerDefaultExternalContentHandlers"])(editor, {
                maxImageDimension,
                maxAssetSize,
                acceptedImageMimeTypes,
                acceptedVideoMimeTypes,
                toasts,
                msg
            });
            unsubs.push(editor.store.props.onMount(editor));
            unsubs.push(onMount?.(editor));
            return ({
                "InsideOfEditorAndUiContext.useOnMount": ()=>{
                    unsubs.forEach({
                        "InsideOfEditorAndUiContext.useOnMount": (fn)=>fn?.()
                    }["InsideOfEditorAndUiContext.useOnMount"]);
                }
            })["InsideOfEditorAndUiContext.useOnMount"];
        }
    }["InsideOfEditorAndUiContext.useOnMount"]);
    const { Canvas } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditorComponents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditorComponents"])();
    const { ContextMenu } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$ui$2f$context$2f$components$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTldrawUiComponents"])();
    if (ContextMenu) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextMenu, {});
    }
    if (Canvas) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Canvas, {});
    }
    return null;
}
;
 //# sourceMappingURL=Tldraw.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/TldrawImage.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TldrawImage",
    ()=>TldrawImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/Editor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useIdentity.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useTLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useTLStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultBindingUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultBindingUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/defaultShapeUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$static$2d$assets$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/static-assets/assetUrls.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/tldraw/dist-esm/lib/utils/text/richText.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const defaultOptions = {
    text: {
        tipTapConfig: {
            extensions: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tipTapDefaultExtensions"]
        },
        addFontsFromNode: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$text$2f$richText$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultAddFontsFromNode"]
    }
};
const TldrawImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function TldrawImage2(props) {
    const [url, setUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [container, setContainer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const _shapeUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(props.shapeUtils ?? []);
    const shapeUtilsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawImage.TldrawImage2.useMemo[shapeUtilsWithDefaults]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"])("type", _shapeUtils, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultShapeUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultShapeUtils"])
    }["TldrawImage.TldrawImage2.useMemo[shapeUtilsWithDefaults]"], [
        _shapeUtils
    ]);
    const _bindingUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useIdentity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallowArrayIdentity"])(props.bindingUtils ?? []);
    const bindingUtilsWithDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawImage.TldrawImage2.useMemo[bindingUtilsWithDefaults]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeArraysAndReplaceDefaults"])("type", _bindingUtils, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$defaultBindingUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultBindingUtils"])
    }["TldrawImage.TldrawImage2.useMemo[bindingUtilsWithDefaults]"], [
        _bindingUtils
    ]);
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useTLStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTLStore"])({
        snapshot: props.snapshot,
        shapeUtils: shapeUtilsWithDefaults
    });
    const { pageId, bounds, scale, pixelRatio, background, padding, darkMode, preserveAspectRatio, format = "svg", licenseKey, assetUrls, options: _options, // eslint-disable-next-line @typescript-eslint/no-deprecated
    textOptions: _textOptions } = props;
    const options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TldrawImage.TldrawImage2.useMemo[options]": ()=>({
                ...defaultOptions,
                ..._options,
                text: {
                    ...defaultOptions.text,
                    ..._options?.text ?? _textOptions
                }
            })
    }["TldrawImage.TldrawImage2.useMemo[options]"], [
        _options,
        _textOptions
    ]);
    const assetUrlsWithOverrides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$tldraw$2f$dist$2d$esm$2f$lib$2f$utils$2f$static$2d$assets$2f$assetUrls$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultEditorAssetsWithOverrides"])(assetUrls);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "TldrawImage.TldrawImage2.useLayoutEffect": ()=>{
            if (!container) return;
            if (!store) return;
            let isCancelled = false;
            const tempElm = document.createElement("div");
            container.appendChild(tempElm);
            container.classList.add("tl-container", "tl-theme__light");
            const editor = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$Editor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Editor"]({
                store,
                shapeUtils: shapeUtilsWithDefaults,
                bindingUtils: bindingUtilsWithDefaults,
                tools: [],
                getContainer: {
                    "TldrawImage.TldrawImage2.useLayoutEffect": ()=>tempElm
                }["TldrawImage.TldrawImage2.useLayoutEffect"],
                licenseKey,
                fontAssetUrls: assetUrlsWithOverrides.fonts,
                options
            });
            if (pageId) editor.setCurrentPage(pageId);
            const shapeIds = editor.getCurrentPageShapeIds();
            async function setSvg() {
                await editor.fonts.loadRequiredFontsForCurrentPage(editor.options.maxFontsToLoadBeforeRender);
                const imageResult = await editor.toImage([
                    ...shapeIds
                ], {
                    bounds,
                    scale,
                    background,
                    padding,
                    darkMode,
                    preserveAspectRatio,
                    format
                });
                if (!imageResult || isCancelled) return;
                const url2 = URL.createObjectURL(imageResult.blob);
                setUrl(url2);
                editor.dispose();
            }
            setSvg();
            return ({
                "TldrawImage.TldrawImage2.useLayoutEffect": ()=>{
                    isCancelled = true;
                }
            })["TldrawImage.TldrawImage2.useLayoutEffect"];
        }
    }["TldrawImage.TldrawImage2.useLayoutEffect"], [
        format,
        container,
        store,
        shapeUtilsWithDefaults,
        bindingUtilsWithDefaults,
        pageId,
        bounds,
        scale,
        background,
        padding,
        darkMode,
        preserveAspectRatio,
        licenseKey,
        pixelRatio,
        assetUrlsWithOverrides,
        options
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TldrawImage.TldrawImage2.useEffect": ()=>{
            return ({
                "TldrawImage.TldrawImage2.useEffect": ()=>{
                    if (url) URL.revokeObjectURL(url);
                }
            })["TldrawImage.TldrawImage2.useEffect"];
        }
    }["TldrawImage.TldrawImage2.useEffect"], [
        url
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: setContainer,
        style: {
            position: "relative",
            width: "100%",
            height: "100%"
        },
        children: url && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
            src: url,
            referrerPolicy: "strict-origin-when-cross-origin",
            style: {
                width: "100%",
                height: "100%"
            }
        })
    });
});
;
 //# sourceMappingURL=TldrawImage.mjs.map
}),
]);

//# debugId=ce43c3e0-675f-5abe-1f62-ab35b4a38d6c
//# sourceMappingURL=c427b_tldraw_dist-esm_lib_f0762d3a._.js.map