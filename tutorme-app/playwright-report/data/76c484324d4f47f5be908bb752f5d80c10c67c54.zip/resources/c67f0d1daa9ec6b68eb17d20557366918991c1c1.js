(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/e127f_src_app_[locale]_tutor_dashboard_components_CommunicationCenter_tsx_f32b4cea._.js",
  "static/chunks/e127f_src_app_[locale]_tutor_dashboard_components_InteractiveCalendar_tsx_dd7898b4._.js",
  "static/chunks/b1c00_TutorMekimi_tutorme-app_src_app_[locale]_tutor_dashboard_components_e0b09597._.js",
  "static/chunks/b1c00_TutorMekimi_tutorme-app_src_app_[locale]_tutor_dashboard_page_tsx_877225aa._.js",
  "static/chunks/ADK_WORKSPACE_TutorMekimi_tutorme-app_src_c6045bab._.js",
  "static/chunks/c427b_896df395._.js"
],
    source: "dynamic"
});
