;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="4f8d5101-8c7f-801a-a502-f7b610229b95")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/fabric/dist/index.min.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActiveSelection",
    ()=>Ao,
    "BaseBrush",
    ()=>Gn,
    "BaseFabricObject",
    ()=>qs,
    "Canvas",
    ()=>Mn,
    "Canvas2dFilterBackend",
    ()=>jo,
    "CanvasDOMManager",
    ()=>hn,
    "Circle",
    ()=>qn,
    "CircleBrush",
    ()=>Kn,
    "ClipPathLayout",
    ()=>Mo,
    "Color",
    ()=>Je,
    "Control",
    ()=>oi,
    "Ellipse",
    ()=>io,
    "FabricImage",
    ()=>Xo,
    "FabricObject",
    ()=>ji,
    "FabricText",
    ()=>go,
    "FitContentLayout",
    ()=>br,
    "FixedLayout",
    ()=>Po,
    "Gradient",
    ()=>Vn,
    "Group",
    ()=>Or,
    "IText",
    ()=>ko,
    "Image",
    ()=>Xo,
    "InteractiveFabricObject",
    ()=>Ei,
    "Intersection",
    ()=>Ns,
    "LayoutManager",
    ()=>wr,
    "LayoutStrategy",
    ()=>Cr,
    "Line",
    ()=>to,
    "Object",
    ()=>ji,
    "Observable",
    ()=>st,
    "Path",
    ()=>Hn,
    "Pattern",
    ()=>zn,
    "PatternBrush",
    ()=>Qn,
    "PencilBrush",
    ()=>Nn,
    "Point",
    ()=>ot,
    "Polygon",
    ()=>oo,
    "Polyline",
    ()=>no,
    "Rect",
    ()=>pr,
    "Shadow",
    ()=>ks,
    "SprayBrush",
    ()=>Jn,
    "StaticCanvas",
    ()=>he,
    "StaticCanvasDOMManager",
    ()=>te,
    "Text",
    ()=>go,
    "Textbox",
    ()=>Do,
    "Triangle",
    ()=>eo,
    "WebGLFilterBackend",
    ()=>Fo,
    "cache",
    ()=>p,
    "classRegistry",
    ()=>tt,
    "config",
    ()=>s,
    "controlsUtils",
    ()=>Cn,
    "createCollectionMixin",
    ()=>lt,
    "filters",
    ()=>Xa,
    "getEnv",
    ()=>u,
    "getFabricDocument",
    ()=>d,
    "getFabricWindow",
    ()=>g,
    "getFilterBackend",
    ()=>Ro,
    "iMatrix",
    ()=>b,
    "initFilterBackend",
    ()=>Bo,
    "isPutImageFaster",
    ()=>sa,
    "isWebGLPipelineState",
    ()=>ea,
    "loadSVGFromString",
    ()=>Zo,
    "loadSVGFromURL",
    ()=>ta,
    "parseSVGDocument",
    ()=>Qo,
    "runningAnimations",
    ()=>et,
    "setEnv",
    ()=>c,
    "setFilterBackend",
    ()=>Io,
    "util",
    ()=>on,
    "version",
    ()=>m
]);
function t(t, e, s) {
    return (e = function(t) {
        var e = function(t, e) {
            if ("object" != typeof t || !t) return t;
            var s = t[Symbol.toPrimitive];
            if (void 0 !== s) {
                var i = s.call(t, e);
                if ("object" != typeof i) return i;
                throw new TypeError("@@toPrimitive must return a primitive value.");
            }
            return (("TURBOPACK compile-time truthy", 1) ? String : "TURBOPACK unreachable")(t);
        }(t, "string");
        return "symbol" == typeof e ? e : e + "";
    }(e)) in t ? Object.defineProperty(t, e, {
        value: s,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = s, t;
}
class e {
    constructor(){
        t(this, "browserShadowBlurConstant", 1), t(this, "DPI", 96), t(this, "devicePixelRatio", "undefined" != typeof window ? window.devicePixelRatio : 1), t(this, "perfLimitSizeTotal", 2097152), t(this, "maxCacheSideLimit", 4096), t(this, "minCacheSideLimit", 256), t(this, "disableStyleCopyPaste", !1), t(this, "enableGLFiltering", !0), t(this, "textureSize", 4096), t(this, "forceGLPutImageData", !1), t(this, "cachesBoundsOfCurve", !1), t(this, "fontPaths", {}), t(this, "NUM_FRACTION_DIGITS", 4);
    }
}
const s = new class extends e {
    constructor(t){
        super(), this.configure(t);
    }
    configure() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        Object.assign(this, t);
    }
    addFonts() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.fontPaths = {
            ...this.fontPaths,
            ...t
        };
    }
    removeFonts() {
        (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []).forEach((t)=>{
            delete this.fontPaths[t];
        });
    }
    clearFonts() {
        this.fontPaths = {};
    }
    restoreDefaults(t) {
        const s = new e, i = (null == t ? void 0 : t.reduce((t, e)=>(t[e] = s[e], t), {})) || s;
        this.configure(i);
    }
}, i = function(t) {
    for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
    return console[t]("fabric", ...s);
};
class r extends Error {
    constructor(t, e){
        super(`fabric: ${t}`, e);
    }
}
class n extends r {
    constructor(t){
        super(`${t} 'options.signal' is in 'aborted' state`);
    }
}
class o {
}
class a extends o {
    testPrecision(t, e) {
        const s = `precision ${e} float;\nvoid main(){}`, i = t.createShader(t.FRAGMENT_SHADER);
        return !!i && (t.shaderSource(i, s), t.compileShader(i), !!t.getShaderParameter(i, t.COMPILE_STATUS));
    }
    queryWebGL(t) {
        const e = t.getContext("webgl");
        e && (this.maxTextureSize = e.getParameter(e.MAX_TEXTURE_SIZE), this.GLPrecision = [
            "highp",
            "mediump",
            "lowp"
        ].find((t)=>this.testPrecision(e, t)), e.getExtension("WEBGL_lose_context").loseContext(), i("log", `WebGL: max texture size ${this.maxTextureSize}`));
    }
    isSupported(t) {
        return !!this.maxTextureSize && this.maxTextureSize >= t;
    }
}
const h = {};
let l;
const c = (t)=>{
    l = t;
}, u = ()=>l || (l = {
        document: document,
        window: window,
        isTouchSupported: "ontouchstart" in window || "ontouchstart" in document || window && window.navigator && window.navigator.maxTouchPoints > 0,
        WebGLProbe: new a,
        dispose () {},
        copyPasteData: h
    }), d = ()=>u().document, g = ()=>u().window, f = ()=>{
    var t;
    return Math.max(null !== (t = s.devicePixelRatio) && void 0 !== t ? t : g().devicePixelRatio, 1);
};
const p = new class {
    constructor(){
        t(this, "boundsOfCurveCache", {}), this.charWidthsCache = new Map;
    }
    getFontCache(t) {
        let { fontFamily: e, fontStyle: s, fontWeight: i } = t;
        e = e.toLowerCase();
        const r = this.charWidthsCache;
        r.has(e) || r.set(e, new Map);
        const n = r.get(e), o = `${s.toLowerCase()}_${(i + "").toLowerCase()}`;
        return n.has(o) || n.set(o, new Map), n.get(o);
    }
    clearFontCache(t) {
        t ? this.charWidthsCache.delete((t || "").toLowerCase()) : this.charWidthsCache = new Map;
    }
    limitDimsByArea(t) {
        const { perfLimitSizeTotal: e } = s, i = Math.sqrt(e * t);
        return [
            Math.floor(i),
            Math.floor(e / i)
        ];
    }
};
const m = "7.2.0";
function v() {}
const y = Math.PI / 2, _ = Math.PI / 4, x = 2 * Math.PI, C = Math.PI / 180, b = Object.freeze([
    1,
    0,
    0,
    1,
    0,
    0
]), S = 16, w = .4477152502, T = "center", O = "left", k = "top", D = "bottom", M = "right", P = "none", E = /\r?\n/, A = "moving", j = "scaling", F = "rotating", L = "rotate", B = "skewing", R = "resizing", I = "modifyPoly", $ = "modifyPath", X = "changed", Y = "scale", W = "scaleX", V = "scaleY", z = "skewX", G = "skewY", H = "fill", N = "stroke", U = "modified", q = "ltr", K = "rtl", J = "normal", Q = "json", Z = "svg";
const tt = new class {
    constructor(){
        this[Q] = new Map, this[Z] = new Map;
    }
    has(t) {
        return this[Q].has(t);
    }
    getClass(t) {
        const e = this[Q].get(t);
        if (!e) throw new r(`No class registered for ${t}`);
        return e;
    }
    setClass(t, e) {
        e ? this[Q].set(e, t) : (this[Q].set(t.type, t), this[Q].set(t.type.toLowerCase(), t));
    }
    getSVGClass(t) {
        return this[Z].get(t);
    }
    setSVGClass(t, e) {
        this[Z].set(null != e ? e : t.type.toLowerCase(), t);
    }
};
const et = new class extends Array {
    remove(t) {
        const e = this.indexOf(t);
        e > -1 && this.splice(e, 1);
    }
    cancelAll() {
        const t = this.splice(0);
        return t.forEach((t)=>t.abort()), t;
    }
    cancelByCanvas(t) {
        if (!t) return [];
        const e = this.filter((e)=>{
            var s;
            return e.target === t || "object" == typeof e.target && (null === (s = e.target) || void 0 === s ? void 0 : s.canvas) === t;
        });
        return e.forEach((t)=>t.abort()), e;
    }
    cancelByTarget(t) {
        if (!t) return [];
        const e = this.filter((e)=>e.target === t);
        return e.forEach((t)=>t.abort()), e;
    }
};
class st {
    constructor(){
        t(this, "__eventListeners", {});
    }
    on(t, e) {
        if (this.__eventListeners || (this.__eventListeners = {}), "object" == typeof t) return Object.entries(t).forEach((t)=>{
            let [e, s] = t;
            this.on(e, s);
        }), ()=>this.off(t);
        if (e) {
            const s = t;
            return this.__eventListeners[s] || (this.__eventListeners[s] = []), this.__eventListeners[s].push(e), ()=>this.off(s, e);
        }
        return ()=>!1;
    }
    once(t, e) {
        if ("object" == typeof t) {
            const e = [];
            return Object.entries(t).forEach((t)=>{
                let [s, i] = t;
                e.push(this.once(s, i));
            }), ()=>e.forEach((t)=>t());
        }
        if (e) {
            const s = this.on(t, function() {
                for(var t = arguments.length, i = new Array(t), r = 0; r < t; r++)i[r] = arguments[r];
                e.call(this, ...i), s();
            });
            return s;
        }
        return ()=>!1;
    }
    _removeEventListener(t, e) {
        if (this.__eventListeners[t]) if (e) {
            const s = this.__eventListeners[t], i = s.indexOf(e);
            i > -1 && s.splice(i, 1);
        } else this.__eventListeners[t] = [];
    }
    off(t, e) {
        if (this.__eventListeners) if (void 0 === t) for(const t in this.__eventListeners)this._removeEventListener(t);
        else "object" == typeof t ? Object.entries(t).forEach((t)=>{
            let [e, s] = t;
            this._removeEventListener(e, s);
        }) : this._removeEventListener(t, e);
    }
    fire(t, e) {
        var s;
        if (!this.__eventListeners) return;
        const i = null === (s = this.__eventListeners[t]) || void 0 === s ? void 0 : s.concat();
        if (i) for(let t = 0; t < i.length; t++)i[t].call(this, e || {});
    }
}
const it = (t, e)=>{
    const s = t.indexOf(e);
    return -1 !== s && t.splice(s, 1), t;
}, rt = (t)=>{
    if (0 === t) return 1;
    switch(Math.abs(t) / y){
        case 1:
        case 3:
            return 0;
        case 2:
            return -1;
    }
    return Math.cos(t);
}, nt = (t)=>{
    if (0 === t) return 0;
    const e = t / y, s = Math.sign(t);
    switch(e){
        case 1:
            return s;
        case 2:
            return 0;
        case 3:
            return -s;
    }
    return Math.sin(t);
};
class ot {
    constructor(){
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        "object" == typeof t ? (this.x = t.x, this.y = t.y) : (this.x = t, this.y = e);
    }
    add(t) {
        return new ot(this.x + t.x, this.y + t.y);
    }
    addEquals(t) {
        return this.x += t.x, this.y += t.y, this;
    }
    scalarAdd(t) {
        return new ot(this.x + t, this.y + t);
    }
    scalarAddEquals(t) {
        return this.x += t, this.y += t, this;
    }
    subtract(t) {
        return new ot(this.x - t.x, this.y - t.y);
    }
    subtractEquals(t) {
        return this.x -= t.x, this.y -= t.y, this;
    }
    scalarSubtract(t) {
        return new ot(this.x - t, this.y - t);
    }
    scalarSubtractEquals(t) {
        return this.x -= t, this.y -= t, this;
    }
    multiply(t) {
        return new ot(this.x * t.x, this.y * t.y);
    }
    scalarMultiply(t) {
        return new ot(this.x * t, this.y * t);
    }
    scalarMultiplyEquals(t) {
        return this.x *= t, this.y *= t, this;
    }
    divide(t) {
        return new ot(this.x / t.x, this.y / t.y);
    }
    scalarDivide(t) {
        return new ot(this.x / t, this.y / t);
    }
    scalarDivideEquals(t) {
        return this.x /= t, this.y /= t, this;
    }
    eq(t) {
        return this.x === t.x && this.y === t.y;
    }
    lt(t) {
        return this.x < t.x && this.y < t.y;
    }
    lte(t) {
        return this.x <= t.x && this.y <= t.y;
    }
    gt(t) {
        return this.x > t.x && this.y > t.y;
    }
    gte(t) {
        return this.x >= t.x && this.y >= t.y;
    }
    lerp(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .5;
        return e = Math.max(Math.min(1, e), 0), new ot(this.x + (t.x - this.x) * e, this.y + (t.y - this.y) * e);
    }
    distanceFrom(t) {
        const e = this.x - t.x, s = this.y - t.y;
        return Math.sqrt(e * e + s * s);
    }
    midPointFrom(t) {
        return this.lerp(t);
    }
    min(t) {
        return new ot(Math.min(this.x, t.x), Math.min(this.y, t.y));
    }
    max(t) {
        return new ot(Math.max(this.x, t.x), Math.max(this.y, t.y));
    }
    toString() {
        return `${this.x},${this.y}`;
    }
    setXY(t, e) {
        return this.x = t, this.y = e, this;
    }
    setX(t) {
        return this.x = t, this;
    }
    setY(t) {
        return this.y = t, this;
    }
    setFromPoint(t) {
        return this.x = t.x, this.y = t.y, this;
    }
    swap(t) {
        const e = this.x, s = this.y;
        this.x = t.x, this.y = t.y, t.x = e, t.y = s;
    }
    clone() {
        return new ot(this.x, this.y);
    }
    rotate(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : at;
        const s = nt(t), i = rt(t), r = this.subtract(e);
        return new ot(r.x * i - r.y * s, r.x * s + r.y * i).add(e);
    }
    transform(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return new ot(t[0] * this.x + t[2] * this.y + (e ? 0 : t[4]), t[1] * this.x + t[3] * this.y + (e ? 0 : t[5]));
    }
}
const at = new ot(0, 0), ht = (t)=>!!t && Array.isArray(t._objects);
function lt(e) {
    class s extends e {
        constructor(){
            super(...arguments), t(this, "_objects", []);
        }
        _onObjectAdded(t) {}
        _onObjectRemoved(t) {}
        _onStackOrderChanged(t) {}
        add() {
            for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
            const i = this._objects.push(...e);
            return e.forEach((t)=>this._onObjectAdded(t)), i;
        }
        insertAt(t) {
            for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
            return this._objects.splice(t, 0, ...s), s.forEach((t)=>this._onObjectAdded(t)), this._objects.length;
        }
        remove() {
            const t = this._objects, e = [];
            for(var s = arguments.length, i = new Array(s), r = 0; r < s; r++)i[r] = arguments[r];
            return i.forEach((s)=>{
                const i = t.indexOf(s);
                -1 !== i && (t.splice(i, 1), e.push(s), this._onObjectRemoved(s));
            }), e;
        }
        forEachObject(t) {
            this.getObjects().forEach((e, s, i)=>t(e, s, i));
        }
        getObjects() {
            for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
            return 0 === e.length ? [
                ...this._objects
            ] : this._objects.filter((t)=>t.isType(...e));
        }
        item(t) {
            return this._objects[t];
        }
        isEmpty() {
            return 0 === this._objects.length;
        }
        size() {
            return this._objects.length;
        }
        contains(t, e) {
            return !!this._objects.includes(t) || !!e && this._objects.some((e)=>e instanceof s && e.contains(t, !0));
        }
        complexity() {
            return this._objects.reduce((t, e)=>t += e.complexity ? e.complexity() : 0, 0);
        }
        sendObjectToBack(t) {
            return !(!t || t === this._objects[0]) && (it(this._objects, t), this._objects.unshift(t), this._onStackOrderChanged(t), !0);
        }
        bringObjectToFront(t) {
            return !(!t || t === this._objects[this._objects.length - 1]) && (it(this._objects, t), this._objects.push(t), this._onStackOrderChanged(t), !0);
        }
        sendObjectBackwards(t, e) {
            if (!t) return !1;
            const s = this._objects.indexOf(t);
            if (0 !== s) {
                const i = this.findNewLowerIndex(t, s, e);
                return it(this._objects, t), this._objects.splice(i, 0, t), this._onStackOrderChanged(t), !0;
            }
            return !1;
        }
        bringObjectForward(t, e) {
            if (!t) return !1;
            const s = this._objects.indexOf(t);
            if (s !== this._objects.length - 1) {
                const i = this.findNewUpperIndex(t, s, e);
                return it(this._objects, t), this._objects.splice(i, 0, t), this._onStackOrderChanged(t), !0;
            }
            return !1;
        }
        moveObjectTo(t, e) {
            return t !== this._objects[e] && (it(this._objects, t), this._objects.splice(e, 0, t), this._onStackOrderChanged(t), !0);
        }
        findNewLowerIndex(t, e, s) {
            let i;
            if (s) {
                i = e;
                for(let s = e - 1; s >= 0; --s)if (t.isOverlapping(this._objects[s])) {
                    i = s;
                    break;
                }
            } else i = e - 1;
            return i;
        }
        findNewUpperIndex(t, e, s) {
            let i;
            if (s) {
                i = e;
                for(let s = e + 1; s < this._objects.length; ++s)if (t.isOverlapping(this._objects[s])) {
                    i = s;
                    break;
                }
            } else i = e + 1;
            return i;
        }
        collectObjects(t) {
            let { left: e, top: s, width: i, height: r } = t, { includeIntersecting: n = !0 } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            const o = [], a = new ot(e, s), h = a.add(new ot(i, r));
            for(let t = this._objects.length - 1; t >= 0; t--){
                const e = this._objects[t];
                e.selectable && e.visible && (n && e.intersectsWithRect(a, h) || e.isContainedWithinRect(a, h) || n && e.containsPoint(a) || n && e.containsPoint(h)) && o.push(e);
            }
            return o;
        }
    }
    return s;
}
class ct extends st {
    _setOptions() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        for(const e in t)this.set(e, t[e]);
    }
    _setObject(t) {
        for(const e in t)this._set(e, t[e]);
    }
    set(t, e) {
        return "object" == typeof t ? this._setObject(t) : this._set(t, e), this;
    }
    _set(t, e) {
        this[t] = e;
    }
    toggle(t) {
        const e = this.get(t);
        return "boolean" == typeof e && this.set(t, !e), this;
    }
    get(t) {
        return this[t];
    }
}
function ut(t) {
    return g().requestAnimationFrame(t);
}
function dt(t) {
    return g().cancelAnimationFrame(t);
}
let gt = 0;
const ft = ()=>gt++, pt = ()=>{
    const t = d().createElement("canvas");
    if (!t || void 0 === t.getContext) throw new r("Failed to create `canvas` element");
    return t;
}, mt = ()=>d().createElement("img"), vt = (t)=>{
    const e = pt();
    return e.width = t.width, e.height = t.height, e;
}, yt = (t, e, s)=>t.toDataURL(`image/${e}`, s), _t = (t, e, s)=>new Promise((i, r)=>{
        t.toBlob(i, `image/${e}`, s);
    }), xt = (t)=>t * C, Ct = (t)=>t / C, bt = (t)=>t.every((t, e)=>t === b[e]), St = (t, e, s)=>new ot(t).transform(e, s), wt = (t)=>{
    const e = 1 / (t[0] * t[3] - t[1] * t[2]), s = [
        e * t[3],
        -e * t[1],
        -e * t[2],
        e * t[0],
        0,
        0
    ], { x: i, y: r } = new ot(t[4], t[5]).transform(s, !0);
    return s[4] = -i, s[5] = -r, s;
}, Tt = (t, e, s)=>[
        t[0] * e[0] + t[2] * e[1],
        t[1] * e[0] + t[3] * e[1],
        t[0] * e[2] + t[2] * e[3],
        t[1] * e[2] + t[3] * e[3],
        s ? 0 : t[0] * e[4] + t[2] * e[5] + t[4],
        s ? 0 : t[1] * e[4] + t[3] * e[5] + t[5]
    ], Ot = (t, e)=>t.reduceRight((t, s)=>s && t ? Tt(s, t, e) : s || t, void 0) || b.concat(), kt = (t)=>{
    let [e, s] = t;
    return Math.atan2(s, e);
}, Dt = (t)=>{
    const e = kt(t), s = Math.pow(t[0], 2) + Math.pow(t[1], 2), i = Math.sqrt(s), r = (t[0] * t[3] - t[2] * t[1]) / i, n = Math.atan2(t[0] * t[2] + t[1] * t[3], s);
    return {
        angle: Ct(e),
        scaleX: i,
        scaleY: r,
        skewX: Ct(n),
        skewY: 0,
        translateX: t[4] || 0,
        translateY: t[5] || 0
    };
}, Mt = function(t) {
    return [
        1,
        0,
        0,
        1,
        t,
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0
    ];
};
function Pt() {
    let { angle: t = 0 } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, { x: e = 0, y: s = 0 } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    const i = xt(t), r = rt(i), n = nt(i);
    return [
        r,
        n,
        -n,
        r,
        e ? e - (r * e - n * s) : 0,
        s ? s - (n * e + r * s) : 0
    ];
}
const Et = function(t) {
    return [
        t,
        0,
        0,
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : t,
        0,
        0
    ];
}, At = (t)=>Math.tan(xt(t)), jt = (t)=>[
        1,
        0,
        At(t),
        1,
        0,
        0
    ], Ft = (t)=>[
        1,
        At(t),
        0,
        1,
        0,
        0
    ], Lt = (t)=>{
    let { scaleX: e = 1, scaleY: s = 1, flipX: i = !1, flipY: r = !1, skewX: n = 0, skewY: o = 0 } = t, a = Et(i ? -e : e, r ? -s : s);
    return n && (a = Tt(a, jt(n), !0)), o && (a = Tt(a, Ft(o), !0)), a;
}, Bt = (t)=>{
    const { translateX: e = 0, translateY: s = 0, angle: i = 0 } = t;
    let r = Mt(e, s);
    i && (r = Tt(r, Pt({
        angle: i
    })));
    const n = Lt(t);
    return bt(n) || (r = Tt(r, n)), r;
}, Rt = function(t) {
    let { signal: e, crossOrigin: s = null } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    return new Promise(function(i, o) {
        if (e && e.aborted) return o(new n("loadImage"));
        const a = mt();
        let h;
        e && (h = function(t) {
            a.src = "", o(t);
        }, e.addEventListener("abort", h, {
            once: !0
        }));
        const l = function() {
            a.onload = a.onerror = null, h && (null == e || e.removeEventListener("abort", h)), i(a);
        };
        t ? (a.onload = l, a.onerror = function() {
            h && (null == e || e.removeEventListener("abort", h)), o(new r(`Error loading ${a.src}`));
        }, s && (a.crossOrigin = s), a.src = t) : l();
    });
}, It = function(t) {
    let { signal: e, reviver: s = v } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    return new Promise((i, r)=>{
        const n = [];
        e && e.addEventListener("abort", r, {
            once: !0
        }), Promise.all(t.map((t)=>tt.getClass(t.type).fromObject(t, {
                signal: e
            }).then((e)=>(s(t, e), n.push(e), e)))).then(i).catch((t)=>{
            n.forEach((t)=>{
                t.dispose && t.dispose();
            }), r(t);
        }).finally(()=>{
            e && e.removeEventListener("abort", r);
        });
    });
}, $t = function(t) {
    let { signal: e } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    return new Promise((s, i)=>{
        const r = [];
        e && e.addEventListener("abort", i, {
            once: !0
        });
        const n = Object.values(t).map((t)=>t && t.type && tt.has(t.type) ? It([
                t
            ], {
                signal: e
            }).then((t)=>{
                let [e] = t;
                return r.push(e), e;
            }) : t), o = Object.keys(t);
        Promise.all(n).then((t)=>t.reduce((t, e, s)=>(t[o[s]] = e, t), {})).then(s).catch((t)=>{
            r.forEach((t)=>{
                t.dispose && t.dispose();
            }), i(t);
        }).finally(()=>{
            e && e.removeEventListener("abort", i);
        });
    });
}, Xt = function(t) {
    return (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : []).reduce((e, s)=>(s in t && (e[s] = t[s]), e), {});
}, Yt = (t, e)=>Object.keys(t).reduce((s, i)=>(e(t[i], i, t) && (s[i] = t[i]), s), {}), Wt = (t, e)=>parseFloat(Number(t).toFixed(e)), Vt = (t)=>"matrix(" + t.map((t)=>Wt(t, s.NUM_FRACTION_DIGITS)).join(" ") + ")", zt = (t)=>!!t && void 0 !== t.toLive, Gt = (t)=>!!t && "function" == typeof t.toObject, Ht = (t)=>!!t && void 0 !== t.offsetX && "source" in t, Nt = (t)=>!!t && "multiSelectionStacking" in t;
function Ut(t) {
    const e = t && qt(t);
    let s = 0, i = 0;
    if (!t || !e) return {
        left: s,
        top: i
    };
    let r = t;
    const n = e.documentElement, o = e.body || {
        scrollLeft: 0,
        scrollTop: 0
    };
    for(; r && (r.parentNode || r.host) && (r = r.parentNode || r.host, r === e ? (s = o.scrollLeft || n.scrollLeft || 0, i = o.scrollTop || n.scrollTop || 0) : (s += r.scrollLeft || 0, i += r.scrollTop || 0), 1 !== r.nodeType || "fixed" !== r.style.position););
    return {
        left: s,
        top: i
    };
}
const qt = (t)=>t.ownerDocument || null, Kt = (t)=>{
    var e;
    return (null === (e = t.ownerDocument) || void 0 === e ? void 0 : e.defaultView) || null;
}, Jt = function(t, e, s) {
    let { width: i, height: r } = s, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
    t.width = i, t.height = r, n > 1 && (t.setAttribute("width", (i * n).toString()), t.setAttribute("height", (r * n).toString()), e.scale(n, n));
}, Qt = (t, e)=>{
    let { width: s, height: i } = e;
    s && (t.style.width = "number" == typeof s ? `${s}px` : s), i && (t.style.height = "number" == typeof i ? `${i}px` : i);
};
function Zt(t) {
    return void 0 !== t.onselectstart && (t.onselectstart = ()=>!1), t.style.userSelect = P, t;
}
class te {
    constructor(e){
        t(this, "_originalCanvasStyle", void 0), t(this, "lower", void 0);
        const s = this.createLowerCanvas(e);
        this.lower = {
            el: s,
            ctx: s.getContext("2d")
        };
    }
    createLowerCanvas(t) {
        const e = (s = t) && void 0 !== s.getContext ? t : t && d().getElementById(t) || pt();
        var s;
        if (e.hasAttribute("data-fabric")) throw new r("Trying to initialize a canvas that has already been initialized. Did you forget to dispose the canvas?");
        return this._originalCanvasStyle = e.style.cssText, e.setAttribute("data-fabric", "main"), e.classList.add("lower-canvas"), e;
    }
    cleanupDOM(t) {
        let { width: e, height: s } = t;
        const { el: i } = this.lower;
        i.classList.remove("lower-canvas"), i.removeAttribute("data-fabric"), i.setAttribute("width", `${e}`), i.setAttribute("height", `${s}`), i.style.cssText = this._originalCanvasStyle || "", this._originalCanvasStyle = void 0;
    }
    setDimensions(t, e) {
        const { el: s, ctx: i } = this.lower;
        Jt(s, i, t, e);
    }
    setCSSDimensions(t) {
        Qt(this.lower.el, t);
    }
    calcOffset() {
        return function(t) {
            var e;
            const s = t && qt(t), i = {
                left: 0,
                top: 0
            };
            if (!s) return i;
            const r = (null === (e = Kt(t)) || void 0 === e ? void 0 : e.getComputedStyle(t, null)) || {};
            i.left += parseInt(r.borderLeftWidth, 10) || 0, i.top += parseInt(r.borderTopWidth, 10) || 0, i.left += parseInt(r.paddingLeft, 10) || 0, i.top += parseInt(r.paddingTop, 10) || 0;
            let n = {
                left: 0,
                top: 0
            };
            const o = s.documentElement;
            void 0 !== t.getBoundingClientRect && (n = t.getBoundingClientRect());
            const a = Ut(t);
            return {
                left: n.left + a.left - (o.clientLeft || 0) + i.left,
                top: n.top + a.top - (o.clientTop || 0) + i.top
            };
        }(this.lower.el);
    }
    dispose() {
        u().dispose(this.lower.el), delete this.lower;
    }
}
const ee = {
    backgroundVpt: !0,
    backgroundColor: "",
    overlayVpt: !0,
    overlayColor: "",
    includeDefaultValues: !0,
    svgViewportTransformation: !0,
    renderOnAddRemove: !0,
    skipOffscreen: !0,
    enableRetinaScaling: !0,
    imageSmoothingEnabled: !0,
    controlsAboveOverlay: !1,
    allowTouchScrolling: !1,
    viewportTransform: [
        ...b
    ],
    patternQuality: "best"
}, se = (t)=>t.toString().replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
let ie;
const re = (t)=>{
    if (ie || ie || (ie = "Intl" in g() && "Segmenter" in Intl && new Intl.Segmenter(void 0, {
        granularity: "grapheme"
    })), ie) {
        const e = ie.segment(t);
        return Array.from(e).map((t)=>{
            let { segment: e } = t;
            return e;
        });
    }
    return ne(t);
}, ne = (t)=>{
    const e = [];
    for(let s, i = 0; i < t.length; i++)!1 !== (s = oe(t, i)) && e.push(s);
    return e;
}, oe = (t, e)=>{
    const s = t.charCodeAt(e);
    if (isNaN(s)) return "";
    if (s < 55296 || s > 57343) return t.charAt(e);
    if (55296 <= s && s <= 56319) {
        if (t.length <= e + 1) throw "High surrogate without following low surrogate";
        const s = t.charCodeAt(e + 1);
        if (56320 > s || s > 57343) throw "High surrogate without following low surrogate";
        return t.charAt(e) + t.charAt(e + 1);
    }
    if (0 === e) throw "Low surrogate without preceding high surrogate";
    const i = t.charCodeAt(e - 1);
    if (55296 > i || i > 56319) throw "Low surrogate without preceding high surrogate";
    return !1;
};
var ae = Object.freeze({
    __proto__: null,
    capitalize: function(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return `${t.charAt(0).toUpperCase()}${e ? t.slice(1) : t.slice(1).toLowerCase()}`;
    },
    escapeXml: se,
    graphemeSplit: re
});
class he extends lt(ct) {
    get lowerCanvasEl() {
        var t;
        return null === (t = this.elements.lower) || void 0 === t ? void 0 : t.el;
    }
    get contextContainer() {
        var t;
        return null === (t = this.elements.lower) || void 0 === t ? void 0 : t.ctx;
    }
    static getDefaults() {
        return he.ownDefaults;
    }
    constructor(t){
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), Object.assign(this, this.constructor.getDefaults()), this.set(e), this.initElements(t), this._setDimensionsImpl({
            width: this.width || this.elements.lower.el.width || 0,
            height: this.height || this.elements.lower.el.height || 0
        }), this.skipControlsDrawing = !1, this.viewportTransform = [
            ...this.viewportTransform
        ], this.calcViewportBoundaries();
    }
    initElements(t) {
        this.elements = new te(t);
    }
    add() {
        const t = super.add(...arguments);
        return arguments.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), t;
    }
    insertAt(t) {
        for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
        const r = super.insertAt(t, ...s);
        return s.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), r;
    }
    remove() {
        const t = super.remove(...arguments);
        return t.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), t;
    }
    _onObjectAdded(t) {
        t.canvas && t.canvas !== this && (i("warn", "Canvas is trying to add an object that belongs to a different canvas.\nResulting to default behavior: removing object from previous canvas and adding to new canvas"), t.canvas.remove(t)), t._set("canvas", this), t.setCoords(), this.fire("object:added", {
            target: t
        }), t.fire("added", {
            target: this
        });
    }
    _onObjectRemoved(t) {
        t._set("canvas", void 0), this.fire("object:removed", {
            target: t
        }), t.fire("removed", {
            target: this
        });
    }
    _onStackOrderChanged() {
        this.renderOnAddRemove && this.requestRenderAll();
    }
    getRetinaScaling() {
        return this.enableRetinaScaling ? f() : 1;
    }
    calcOffset() {
        return this._offset = this.elements.calcOffset();
    }
    getWidth() {
        return this.width;
    }
    getHeight() {
        return this.height;
    }
    _setDimensionsImpl(t) {
        let { cssOnly: e = !1, backstoreOnly: s = !1 } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (!e) {
            const e = {
                width: this.width,
                height: this.height,
                ...t
            };
            this.elements.setDimensions(e, this.getRetinaScaling()), this.hasLostContext = !0, this.width = e.width, this.height = e.height;
        }
        s || this.elements.setCSSDimensions(t), this.calcOffset();
    }
    setDimensions(t, e) {
        this._setDimensionsImpl(t, e), e && e.cssOnly || this.requestRenderAll();
    }
    getZoom() {
        return this.viewportTransform[0];
    }
    setViewportTransform(t) {
        this.viewportTransform = t, this.calcViewportBoundaries(), this.renderOnAddRemove && this.requestRenderAll();
    }
    zoomToPoint(t, e) {
        const s = t, i = [
            ...this.viewportTransform
        ], r = St(t, wt(i));
        i[0] = e, i[3] = e;
        const n = St(r, i);
        i[4] += s.x - n.x, i[5] += s.y - n.y, this.setViewportTransform(i);
    }
    setZoom(t) {
        this.zoomToPoint(new ot(0, 0), t);
    }
    absolutePan(t) {
        const e = [
            ...this.viewportTransform
        ];
        return e[4] = -t.x, e[5] = -t.y, this.setViewportTransform(e);
    }
    relativePan(t) {
        return this.absolutePan(new ot(-t.x - this.viewportTransform[4], -t.y - this.viewportTransform[5]));
    }
    getElement() {
        return this.elements.lower.el;
    }
    clearContext(t) {
        t.clearRect(0, 0, this.width, this.height);
    }
    getContext() {
        return this.elements.lower.ctx;
    }
    clear() {
        this.remove(...this.getObjects()), this.backgroundImage = void 0, this.overlayImage = void 0, this.backgroundColor = "", this.overlayColor = "", this.clearContext(this.getContext()), this.fire("canvas:cleared"), this.renderOnAddRemove && this.requestRenderAll();
    }
    renderAll() {
        this.cancelRequestedRender(), this.destroyed || this.renderCanvas(this.getContext(), this._objects);
    }
    renderAndReset() {
        this.nextRenderHandle = 0, this.renderAll();
    }
    requestRenderAll() {
        this.nextRenderHandle || this.disposed || this.destroyed || (this.nextRenderHandle = ut(()=>this.renderAndReset()));
    }
    calcViewportBoundaries() {
        const t = this.width, e = this.height, s = wt(this.viewportTransform), i = St({
            x: 0,
            y: 0
        }, s), r = St({
            x: t,
            y: e
        }, s), n = i.min(r), o = i.max(r);
        return this.vptCoords = {
            tl: n,
            tr: new ot(o.x, n.y),
            bl: new ot(n.x, o.y),
            br: o
        };
    }
    cancelRequestedRender() {
        this.nextRenderHandle && (dt(this.nextRenderHandle), this.nextRenderHandle = 0);
    }
    drawControls(t) {}
    renderCanvas(t, e) {
        if (this.destroyed) return;
        const s = this.viewportTransform, i = this.clipPath;
        this.calcViewportBoundaries(), this.clearContext(t), t.imageSmoothingEnabled = this.imageSmoothingEnabled, t.patternQuality = this.patternQuality, this.fire("before:render", {
            ctx: t
        }), this._renderBackground(t), t.save(), t.transform(s[0], s[1], s[2], s[3], s[4], s[5]), this._renderObjects(t, e), t.restore(), this.controlsAboveOverlay || this.skipControlsDrawing || this.drawControls(t), i && (i._set("canvas", this), i.shouldCache(), i._transformDone = !0, i.renderCache({
            forClipping: !0
        }), this.drawClipPathOnCanvas(t, i)), this._renderOverlay(t), this.controlsAboveOverlay && !this.skipControlsDrawing && this.drawControls(t), this.fire("after:render", {
            ctx: t
        }), this.__cleanupTask && (this.__cleanupTask(), this.__cleanupTask = void 0);
    }
    drawClipPathOnCanvas(t, e) {
        const s = this.viewportTransform;
        t.save(), t.transform(...s), t.globalCompositeOperation = "destination-in", e.transform(t), t.scale(1 / e.zoomX, 1 / e.zoomY), t.drawImage(e._cacheCanvas, -e.cacheTranslationX, -e.cacheTranslationY), t.restore();
    }
    _renderObjects(t, e) {
        for(let s = 0, i = e.length; s < i; ++s)e[s] && e[s].render(t);
    }
    _renderBackgroundOrOverlay(t, e) {
        const s = this[`${e}Color`], i = this[`${e}Image`], r = this.viewportTransform, n = this[`${e}Vpt`];
        if (!s && !i) return;
        const o = zt(s);
        if (s) {
            if (t.save(), t.beginPath(), t.moveTo(0, 0), t.lineTo(this.width, 0), t.lineTo(this.width, this.height), t.lineTo(0, this.height), t.closePath(), t.fillStyle = o ? s.toLive(t) : s, n && t.transform(...r), o) {
                t.transform(1, 0, 0, 1, s.offsetX || 0, s.offsetY || 0);
                const e = s.gradientTransform || s.patternTransform;
                e && t.transform(...e);
            }
            t.fill(), t.restore();
        }
        if (i) {
            t.save();
            const { skipOffscreen: e } = this;
            this.skipOffscreen = n, n && t.transform(...r), i.render(t), this.skipOffscreen = e, t.restore();
        }
    }
    _renderBackground(t) {
        this._renderBackgroundOrOverlay(t, "background");
    }
    _renderOverlay(t) {
        this._renderBackgroundOrOverlay(t, "overlay");
    }
    getCenterPoint() {
        return new ot(this.width / 2, this.height / 2);
    }
    centerObjectH(t) {
        return this._centerObject(t, new ot(this.getCenterPoint().x, t.getCenterPoint().y));
    }
    centerObjectV(t) {
        return this._centerObject(t, new ot(t.getCenterPoint().x, this.getCenterPoint().y));
    }
    centerObject(t) {
        return this._centerObject(t, this.getCenterPoint());
    }
    viewportCenterObject(t) {
        return this._centerObject(t, this.getVpCenter());
    }
    viewportCenterObjectH(t) {
        return this._centerObject(t, new ot(this.getVpCenter().x, t.getCenterPoint().y));
    }
    viewportCenterObjectV(t) {
        return this._centerObject(t, new ot(t.getCenterPoint().x, this.getVpCenter().y));
    }
    getVpCenter() {
        return St(this.getCenterPoint(), wt(this.viewportTransform));
    }
    _centerObject(t, e) {
        t.setXY(e, T, T), t.setCoords(), this.renderOnAddRemove && this.requestRenderAll();
    }
    toDatalessJSON(t) {
        return this.toDatalessObject(t);
    }
    toObject(t) {
        return this._toObjectMethod("toObject", t);
    }
    toJSON() {
        return this.toObject();
    }
    toDatalessObject(t) {
        return this._toObjectMethod("toDatalessObject", t);
    }
    _toObjectMethod(t, e) {
        const s = this.clipPath, i = s && !s.excludeFromExport ? this._toObject(s, t, e) : null;
        return {
            version: m,
            ...Xt(this, e),
            objects: this._objects.filter((t)=>!t.excludeFromExport).map((s)=>this._toObject(s, t, e)),
            ...this.__serializeBgOverlay(t, e),
            ...i ? {
                clipPath: i
            } : null
        };
    }
    _toObject(t, e, s) {
        let i;
        this.includeDefaultValues || (i = t.includeDefaultValues, t.includeDefaultValues = !1);
        const r = t[e](s);
        return this.includeDefaultValues || (t.includeDefaultValues = !!i), r;
    }
    __serializeBgOverlay(t, e) {
        const s = {}, i = this.backgroundImage, r = this.overlayImage, n = this.backgroundColor, o = this.overlayColor;
        return zt(n) ? n.excludeFromExport || (s.background = n.toObject(e)) : n && (s.background = n), zt(o) ? o.excludeFromExport || (s.overlay = o.toObject(e)) : o && (s.overlay = o), i && !i.excludeFromExport && (s.backgroundImage = this._toObject(i, t, e)), r && !r.excludeFromExport && (s.overlayImage = this._toObject(r, t, e)), s;
    }
    toSVG() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = arguments.length > 1 ? arguments[1] : void 0;
        t.reviver = e;
        const s = [];
        var i;
        (this._setSVGPreamble(s, t), this._setSVGHeader(s, t), this.clipPath) && s.push(`<g clip-path="url(#${se(null !== (i = this.clipPath.clipPathId) && void 0 !== i ? i : "")})" >\n`);
        return this._setSVGBgOverlayColor(s, "background"), this._setSVGBgOverlayImage(s, "backgroundImage", e), this._setSVGObjects(s, e), this.clipPath && s.push("</g>\n"), this._setSVGBgOverlayColor(s, "overlay"), this._setSVGBgOverlayImage(s, "overlayImage", e), s.push("</svg>"), s.join("");
    }
    _setSVGPreamble(t, e) {
        e.suppressPreamble || t.push('<?xml version="1.0" encoding="', e.encoding || "UTF-8", '" standalone="no" ?>\n', '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" ', '"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n');
    }
    _setSVGHeader(t, e) {
        const i = e.width || `${this.width}`, r = e.height || `${this.height}`, n = s.NUM_FRACTION_DIGITS, o = e.viewBox;
        let a;
        if (o) a = `viewBox="${o.x} ${o.y} ${o.width} ${o.height}" `;
        else if (this.svgViewportTransformation) {
            const t = this.viewportTransform;
            a = `viewBox="${Wt(-t[4] / t[0], n)} ${Wt(-t[5] / t[3], n)} ${Wt(this.width / t[0], n)} ${Wt(this.height / t[3], n)}" `;
        } else a = `viewBox="0 0 ${this.width} ${this.height}" `;
        t.push("<svg ", 'xmlns="http://www.w3.org/2000/svg" ', 'xmlns:xlink="http://www.w3.org/1999/xlink" ', 'version="1.1" ', 'width="', i, '" ', 'height="', r, '" ', a, 'xml:space="preserve">\n', "<desc>Created with Fabric.js ", m, "</desc>\n", "<defs>\n", this.createSVGFontFacesMarkup(), this.createSVGRefElementsMarkup(), this.createSVGClipPathMarkup(e), "</defs>\n");
    }
    createSVGClipPathMarkup(t) {
        const e = this.clipPath;
        return e ? (e.clipPathId = `CLIPPATH_${ft()}`, `<clipPath id="${e.clipPathId}" >\n${e.toClipPathSVG(t.reviver)}</clipPath>\n`) : "";
    }
    createSVGRefElementsMarkup() {
        return [
            "background",
            "overlay"
        ].map((t)=>{
            const e = this[`${t}Color`];
            if (zt(e)) {
                const s = this[`${t}Vpt`], i = this.viewportTransform, r = {
                    isType: ()=>!1,
                    width: this.width / (s ? i[0] : 1),
                    height: this.height / (s ? i[3] : 1)
                };
                return e.toSVG(r, {
                    additionalTransform: s ? Vt(i) : ""
                });
            }
        }).join("");
    }
    createSVGFontFacesMarkup() {
        const t = [], e = {}, i = s.fontPaths;
        this._objects.forEach(function e(s) {
            t.push(s), ht(s) && s._objects.forEach(e);
        }), t.forEach((t)=>{
            if (!(s = t) || "function" != typeof s._renderText) return;
            var s;
            const { styles: r, fontFamily: n } = t;
            !e[n] && i[n] && (e[n] = !0, r && Object.values(r).forEach((t)=>{
                Object.values(t).forEach((t)=>{
                    let { fontFamily: s = "" } = t;
                    !e[s] && i[s] && (e[s] = !0);
                });
            }));
        });
        const r = Object.keys(e).map((t)=>`\t\t@font-face {\n\t\t\tfont-family: '${t}';\n\t\t\tsrc: url('${i[t]}');\n\t\t}\n`).join("");
        return r ? `\t<style type="text/css"><![CDATA[\n${r}]]></style>\n` : "";
    }
    _setSVGObjects(t, e) {
        this.forEachObject((s)=>{
            s.excludeFromExport || this._setSVGObject(t, s, e);
        });
    }
    _setSVGObject(t, e, s) {
        t.push(e.toSVG(s));
    }
    _setSVGBgOverlayImage(t, e, s) {
        const i = this[e];
        i && !i.excludeFromExport && i.toSVG && t.push(i.toSVG(s));
    }
    _setSVGBgOverlayColor(t, e) {
        const s = this[`${e}Color`];
        if (s) if (zt(s)) {
            const i = s.repeat || "", r = this.width, n = this.height, o = this[`${e}Vpt`] ? Vt(wt(this.viewportTransform)) : "";
            t.push(`<rect transform="${o} translate(${r / 2},${n / 2})" x="${s.offsetX - r / 2}" y="${s.offsetY - n / 2}" width="${"repeat-y" !== i && "no-repeat" !== i || !Ht(s) ? r : s.source.width}" height="${"repeat-x" !== i && "no-repeat" !== i || !Ht(s) ? n : s.source.height}" fill="url(#SVGID_${s.id})"></rect>\n`);
        } else t.push('<rect x="0" y="0" width="100%" height="100%" ', 'fill="', s, '"', "></rect>\n");
    }
    loadFromJSON(t, e) {
        let { signal: s } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        if (!t) return Promise.reject(new r("`json` is undefined"));
        const { objects: i = [], ...n } = "string" == typeof t ? JSON.parse(t) : t, { backgroundImage: o, background: a, overlayImage: h, overlay: l, clipPath: c } = n, u = this.renderOnAddRemove;
        return this.renderOnAddRemove = !1, Promise.all([
            It(i, {
                reviver: e,
                signal: s
            }),
            $t({
                backgroundImage: o,
                backgroundColor: a,
                overlayImage: h,
                overlayColor: l,
                clipPath: c
            }, {
                signal: s
            })
        ]).then((t)=>{
            let [e, s] = t;
            return this.clear(), this.add(...e), this.set(n), this.set(s), this.renderOnAddRemove = u, this;
        });
    }
    clone(t) {
        const e = this.toObject(t);
        return this.cloneWithoutData().loadFromJSON(e);
    }
    cloneWithoutData() {
        const t = vt(this);
        return new this.constructor(t);
    }
    toDataURL() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const { format: e = "png", quality: s = 1, multiplier: i = 1, enableRetinaScaling: r = !1 } = t, n = i * (r ? this.getRetinaScaling() : 1);
        return yt(this.toCanvasElement(n, t), e, s);
    }
    toBlob() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const { format: e = "png", quality: s = 1, multiplier: i = 1, enableRetinaScaling: r = !1 } = t, n = i * (r ? this.getRetinaScaling() : 1);
        return _t(this.toCanvasElement(n, t), e, s);
    }
    toCanvasElement() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, { width: e, height: s, left: i, top: r, filter: n } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const o = (e || this.width) * t, a = (s || this.height) * t, h = this.getZoom(), l = this.width, c = this.height, u = this.skipControlsDrawing, d = h * t, g = this.viewportTransform, f = [
            d,
            0,
            0,
            d,
            (g[4] - (i || 0)) * t,
            (g[5] - (r || 0)) * t
        ], p = this.enableRetinaScaling, m = vt({
            width: o,
            height: a
        }), v = n ? this._objects.filter((t)=>n(t)) : this._objects;
        return this.enableRetinaScaling = !1, this.viewportTransform = f, this.width = o, this.height = a, this.skipControlsDrawing = !0, this.calcViewportBoundaries(), this.renderCanvas(m.getContext("2d"), v), this.viewportTransform = g, this.width = l, this.height = c, this.calcViewportBoundaries(), this.enableRetinaScaling = p, this.skipControlsDrawing = u, m;
    }
    dispose() {
        return !this.disposed && this.elements.cleanupDOM({
            width: this.width,
            height: this.height
        }), et.cancelByCanvas(this), this.disposed = !0, new Promise((t, e)=>{
            const s = ()=>{
                this.destroy(), t(!0);
            };
            s.kill = e, this.__cleanupTask && this.__cleanupTask.kill("aborted"), this.destroyed ? t(!1) : this.nextRenderHandle ? this.__cleanupTask = s : s();
        });
    }
    destroy() {
        this.destroyed = !0, this.cancelRequestedRender(), this.forEachObject((t)=>t.dispose()), this._objects = [], this.backgroundImage && this.backgroundImage.dispose(), this.backgroundImage = void 0, this.overlayImage && this.overlayImage.dispose(), this.overlayImage = void 0, this.elements.dispose();
    }
    toString() {
        return `#<Canvas (${this.complexity()}): { objects: ${this._objects.length} }>`;
    }
}
t(he, "ownDefaults", ee);
const le = [
    "touchstart",
    "touchmove",
    "touchend"
];
const ce = (t)=>{
    const e = Ut(t.target), s = function(t) {
        const e = t.changedTouches;
        return e && e[0] ? e[0] : t;
    }(t);
    return new ot(s.clientX + e.left, s.clientY + e.top);
}, ue = (t)=>le.includes(t.type) || "touch" === t.pointerType, de = (t)=>{
    t.preventDefault(), t.stopPropagation();
}, ge = (t)=>{
    let e = 0, s = 0, i = 0, r = 0;
    for(let n = 0, o = t.length; n < o; n++){
        const { x: o, y: a } = t[n];
        (o > i || !n) && (i = o), (o < e || !n) && (e = o), (a > r || !n) && (r = a), (a < s || !n) && (s = a);
    }
    return {
        left: e,
        top: s,
        width: i - e,
        height: r - s
    };
}, fe = (t, e)=>pe(t, Tt(e, t.calcOwnMatrix())), pe = (t, e)=>{
    const { translateX: s, translateY: i, scaleX: r, scaleY: n, ...o } = Dt(e), a = new ot(s, i);
    t.flipX = !1, t.flipY = !1, Object.assign(t, o), t.set({
        scaleX: r,
        scaleY: n
    }), t.setPositionByOrigin(a, T, T);
}, me = (t)=>{
    t.scaleX = 1, t.scaleY = 1, t.skewX = 0, t.skewY = 0, t.flipX = !1, t.flipY = !1, t.rotate(0);
}, ve = (t)=>({
        scaleX: t.scaleX,
        scaleY: t.scaleY,
        skewX: t.skewX,
        skewY: t.skewY,
        angle: t.angle,
        left: t.left,
        flipX: t.flipX,
        flipY: t.flipY,
        top: t.top
    }), ye = (t, e, s)=>{
    const i = t / 2, r = e / 2, n = [
        new ot(-i, -r),
        new ot(i, -r),
        new ot(-i, r),
        new ot(i, r)
    ].map((t)=>t.transform(s)), o = ge(n);
    return new ot(o.width, o.height);
}, _e = function() {
    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : b;
    return Tt(wt(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : b), t);
}, xe = function(t) {
    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : b, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : b;
    return t.transform(_e(e, s));
}, Ce = function(t) {
    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : b, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : b;
    return t.transform(_e(e, s), !0);
}, be = (t, e, s)=>{
    const i = _e(e, s);
    return pe(t, Tt(i, t.calcOwnMatrix())), i;
}, Se = {
    left: -.5,
    top: -.5,
    center: 0,
    bottom: .5,
    right: .5
}, we = (t)=>"string" == typeof t ? Se[t] : t - .5, Te = new ot(1, 0), Oe = new ot, ke = (t, e)=>t.rotate(e), De = (t, e)=>new ot(e).subtract(t), Me = (t)=>t.distanceFrom(Oe), Pe = (t, e)=>Math.atan2(Fe(t, e), Le(t, e)), Ee = (t)=>Pe(Te, t), Ae = (t)=>t.eq(Oe) ? t : t.scalarDivide(Me(t)), je = function(t) {
    let e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    return Ae(new ot(-t.y, t.x).scalarMultiply(e ? 1 : -1));
}, Fe = (t, e)=>t.x * e.y - t.y * e.x, Le = (t, e)=>t.x * e.x + t.y * e.y, Be = (t, e, s)=>{
    if (t.eq(e) || t.eq(s)) return !0;
    const i = Fe(e, s), r = Fe(e, t), n = Fe(s, t);
    return i >= 0 ? r >= 0 && n <= 0 : !(r <= 0 && n >= 0);
}, Re = "not-allowed";
function Ie(t) {
    return we(t.originX) === we(T) && we(t.originY) === we(T);
}
function $e(t) {
    return .5 - we(t);
}
const Xe = (t, e)=>t[e], Ye = (t, e, s, i)=>({
        e: t,
        transform: e,
        pointer: new ot(s, i)
    });
function We(t, e, s) {
    const i = s, r = xe(t.getCenterPoint(), t.canvas.viewportTransform, void 0), n = Ee(De(r, i)) + x;
    return Math.round(n % x / _);
}
function Ve(t, e, s, i, r) {
    var n;
    let { target: o, corner: a } = t;
    const h = o.controls[a], l = (null === (n = o.canvas) || void 0 === n ? void 0 : n.getZoom()) || 1, c = o.padding / l, u = function(t, e, s, i) {
        const r = t.getRelativeCenterPoint(), n = void 0 !== s && void 0 !== i ? t.translateToGivenOrigin(r, T, T, s, i) : new ot(t.left, t.top);
        return (t.angle ? e.rotate(-xt(t.angle), r) : e).subtract(n);
    }(o, new ot(i, r), e, s);
    return u.x >= c && (u.x -= c), u.x <= -c && (u.x += c), u.y >= c && (u.y -= c), u.y <= c && (u.y += c), u.x -= h.offsetX, u.y -= h.offsetY, u;
}
const ze = (t)=>t.replace(/\s+/g, " "), Ge = {
    aliceblue: "#F0F8FF",
    antiquewhite: "#FAEBD7",
    aqua: "#0FF",
    aquamarine: "#7FFFD4",
    azure: "#F0FFFF",
    beige: "#F5F5DC",
    bisque: "#FFE4C4",
    black: "#000",
    blanchedalmond: "#FFEBCD",
    blue: "#00F",
    blueviolet: "#8A2BE2",
    brown: "#A52A2A",
    burlywood: "#DEB887",
    cadetblue: "#5F9EA0",
    chartreuse: "#7FFF00",
    chocolate: "#D2691E",
    coral: "#FF7F50",
    cornflowerblue: "#6495ED",
    cornsilk: "#FFF8DC",
    crimson: "#DC143C",
    cyan: "#0FF",
    darkblue: "#00008B",
    darkcyan: "#008B8B",
    darkgoldenrod: "#B8860B",
    darkgray: "#A9A9A9",
    darkgrey: "#A9A9A9",
    darkgreen: "#006400",
    darkkhaki: "#BDB76B",
    darkmagenta: "#8B008B",
    darkolivegreen: "#556B2F",
    darkorange: "#FF8C00",
    darkorchid: "#9932CC",
    darkred: "#8B0000",
    darksalmon: "#E9967A",
    darkseagreen: "#8FBC8F",
    darkslateblue: "#483D8B",
    darkslategray: "#2F4F4F",
    darkslategrey: "#2F4F4F",
    darkturquoise: "#00CED1",
    darkviolet: "#9400D3",
    deeppink: "#FF1493",
    deepskyblue: "#00BFFF",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1E90FF",
    firebrick: "#B22222",
    floralwhite: "#FFFAF0",
    forestgreen: "#228B22",
    fuchsia: "#F0F",
    gainsboro: "#DCDCDC",
    ghostwhite: "#F8F8FF",
    gold: "#FFD700",
    goldenrod: "#DAA520",
    gray: "#808080",
    grey: "#808080",
    green: "#008000",
    greenyellow: "#ADFF2F",
    honeydew: "#F0FFF0",
    hotpink: "#FF69B4",
    indianred: "#CD5C5C",
    indigo: "#4B0082",
    ivory: "#FFFFF0",
    khaki: "#F0E68C",
    lavender: "#E6E6FA",
    lavenderblush: "#FFF0F5",
    lawngreen: "#7CFC00",
    lemonchiffon: "#FFFACD",
    lightblue: "#ADD8E6",
    lightcoral: "#F08080",
    lightcyan: "#E0FFFF",
    lightgoldenrodyellow: "#FAFAD2",
    lightgray: "#D3D3D3",
    lightgrey: "#D3D3D3",
    lightgreen: "#90EE90",
    lightpink: "#FFB6C1",
    lightsalmon: "#FFA07A",
    lightseagreen: "#20B2AA",
    lightskyblue: "#87CEFA",
    lightslategray: "#789",
    lightslategrey: "#789",
    lightsteelblue: "#B0C4DE",
    lightyellow: "#FFFFE0",
    lime: "#0F0",
    limegreen: "#32CD32",
    linen: "#FAF0E6",
    magenta: "#F0F",
    maroon: "#800000",
    mediumaquamarine: "#66CDAA",
    mediumblue: "#0000CD",
    mediumorchid: "#BA55D3",
    mediumpurple: "#9370DB",
    mediumseagreen: "#3CB371",
    mediumslateblue: "#7B68EE",
    mediumspringgreen: "#00FA9A",
    mediumturquoise: "#48D1CC",
    mediumvioletred: "#C71585",
    midnightblue: "#191970",
    mintcream: "#F5FFFA",
    mistyrose: "#FFE4E1",
    moccasin: "#FFE4B5",
    navajowhite: "#FFDEAD",
    navy: "#000080",
    oldlace: "#FDF5E6",
    olive: "#808000",
    olivedrab: "#6B8E23",
    orange: "#FFA500",
    orangered: "#FF4500",
    orchid: "#DA70D6",
    palegoldenrod: "#EEE8AA",
    palegreen: "#98FB98",
    paleturquoise: "#AFEEEE",
    palevioletred: "#DB7093",
    papayawhip: "#FFEFD5",
    peachpuff: "#FFDAB9",
    peru: "#CD853F",
    pink: "#FFC0CB",
    plum: "#DDA0DD",
    powderblue: "#B0E0E6",
    purple: "#800080",
    rebeccapurple: "#639",
    red: "#F00",
    rosybrown: "#BC8F8F",
    royalblue: "#4169E1",
    saddlebrown: "#8B4513",
    salmon: "#FA8072",
    sandybrown: "#F4A460",
    seagreen: "#2E8B57",
    seashell: "#FFF5EE",
    sienna: "#A0522D",
    silver: "#C0C0C0",
    skyblue: "#87CEEB",
    slateblue: "#6A5ACD",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#FFFAFA",
    springgreen: "#00FF7F",
    steelblue: "#4682B4",
    tan: "#D2B48C",
    teal: "#008080",
    thistle: "#D8BFD8",
    tomato: "#FF6347",
    turquoise: "#40E0D0",
    violet: "#EE82EE",
    wheat: "#F5DEB3",
    white: "#FFF",
    whitesmoke: "#F5F5F5",
    yellow: "#FF0",
    yellowgreen: "#9ACD32"
}, He = (t, e, s)=>(s < 0 && (s += 1), s > 1 && (s -= 1), s < 1 / 6 ? t + 6 * (e - t) * s : s < .5 ? e : s < 2 / 3 ? t + (e - t) * (2 / 3 - s) * 6 : t), Ne = (t, e, s, i)=>{
    t /= 255, e /= 255, s /= 255;
    const r = Math.max(t, e, s), n = Math.min(t, e, s);
    let o, a;
    const h = (r + n) / 2;
    if (r === n) o = a = 0;
    else {
        const i = r - n;
        switch(a = h > .5 ? i / (2 - r - n) : i / (r + n), r){
            case t:
                o = (e - s) / i + (e < s ? 6 : 0);
                break;
            case e:
                o = (s - t) / i + 2;
                break;
            case s:
                o = (t - e) / i + 4;
        }
        o /= 6;
    }
    return [
        Math.round(360 * o),
        Math.round(100 * a),
        Math.round(100 * h),
        i
    ];
}, Ue = function() {
    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "1";
    return parseFloat(t) / (t.endsWith("%") ? 100 : 1);
}, qe = (t)=>Math.min(Math.round(t), 255).toString(16).toUpperCase().padStart(2, "0"), Ke = (t)=>{
    let [e, s, i, r = 1] = t;
    const n = Math.round(.3 * e + .59 * s + .11 * i);
    return [
        n,
        n,
        n,
        r
    ];
};
class Je {
    constructor(e){
        if (t(this, "isUnrecognised", !1), e) if (e instanceof Je) this.setSource([
            ...e._source
        ]);
        else if (Array.isArray(e)) {
            const [t, s, i, r = 1] = e;
            this.setSource([
                t,
                s,
                i,
                r
            ]);
        } else this.setSource(this._tryParsingColor(e));
        else this.setSource([
            0,
            0,
            0,
            1
        ]);
    }
    _tryParsingColor(t) {
        return (t = t.toLowerCase()) in Ge && (t = Ge[t]), "transparent" === t ? [
            255,
            255,
            255,
            0
        ] : Je.sourceFromHex(t) || Je.sourceFromRgb(t) || Je.sourceFromHsl(t) || (this.isUnrecognised = !0) && [
            0,
            0,
            0,
            1
        ];
    }
    getSource() {
        return this._source;
    }
    setSource(t) {
        this._source = t;
    }
    toRgb() {
        const [t, e, s] = this.getSource();
        return `rgb(${t},${e},${s})`;
    }
    toRgba() {
        return `rgba(${this.getSource().join(",")})`;
    }
    toHsl() {
        const [t, e, s] = Ne(...this.getSource());
        return `hsl(${t},${e}%,${s}%)`;
    }
    toHsla() {
        const [t, e, s, i] = Ne(...this.getSource());
        return `hsla(${t},${e}%,${s}%,${i})`;
    }
    toHex() {
        return this.toHexa().slice(0, 6);
    }
    toHexa() {
        const [t, e, s, i] = this.getSource();
        return `${qe(t)}${qe(e)}${qe(s)}${qe(Math.round(255 * i))}`;
    }
    getAlpha() {
        return this.getSource()[3];
    }
    setAlpha(t) {
        return this._source[3] = t, this;
    }
    toGrayscale() {
        return this.setSource(Ke(this.getSource())), this;
    }
    toBlackWhite(t) {
        const [e, , , s] = Ke(this.getSource()), i = e < (t || 127) ? 0 : 255;
        return this.setSource([
            i,
            i,
            i,
            s
        ]), this;
    }
    overlayWith(t) {
        t instanceof Je || (t = new Je(t));
        const e = this.getSource(), s = t.getSource(), [i, r, n] = e.map((t, e)=>Math.round(.5 * t + .5 * s[e]));
        return this.setSource([
            i,
            r,
            n,
            e[3]
        ]), this;
    }
    static fromRgb(t) {
        return Je.fromRgba(t);
    }
    static fromRgba(t) {
        return new Je(Je.sourceFromRgb(t));
    }
    static sourceFromRgb(t) {
        const e = ze(t).match(/^rgba?\(\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?(?:\s?[,/]\s?(\d{0,3}(?:\.\d+)?%?)\s?)?\)$/i);
        if (e) {
            const [t, s, i] = e.slice(1, 4).map((t)=>{
                const e = parseFloat(t);
                return t.endsWith("%") ? Math.round(2.55 * e) : e;
            });
            return [
                t,
                s,
                i,
                Ue(e[4])
            ];
        }
    }
    static fromHsl(t) {
        return Je.fromHsla(t);
    }
    static fromHsla(t) {
        return new Je(Je.sourceFromHsl(t));
    }
    static sourceFromHsl(t) {
        const e = ze(t).match(/^hsla?\(\s?([+-]?\d{0,3}(?:\.\d+)?(?:deg|turn|rad)?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?(?:\s?[,/]\s?(\d*(?:\.\d+)?%?)\s?)?\)$/i);
        if (!e) return;
        const s = (Je.parseAngletoDegrees(e[1]) % 360 + 360) % 360 / 360, i = parseFloat(e[2]) / 100, r = parseFloat(e[3]) / 100;
        let n, o, a;
        if (0 === i) n = o = a = r;
        else {
            const t = r <= .5 ? r * (i + 1) : r + i - r * i, e = 2 * r - t;
            n = He(e, t, s + 1 / 3), o = He(e, t, s), a = He(e, t, s - 1 / 3);
        }
        return [
            Math.round(255 * n),
            Math.round(255 * o),
            Math.round(255 * a),
            Ue(e[4])
        ];
    }
    static fromHex(t) {
        return new Je(Je.sourceFromHex(t));
    }
    static sourceFromHex(t) {
        if (t.match(/^#?(([0-9a-f]){3,4}|([0-9a-f]{2}){3,4})$/i)) {
            const e = t.slice(t.indexOf("#") + 1);
            let s;
            s = e.length <= 4 ? e.split("").map((t)=>t + t) : e.match(/.{2}/g);
            const [i, r, n, o = 255] = s.map((t)=>parseInt(t, 16));
            return [
                i,
                r,
                n,
                o / 255
            ];
        }
    }
    static parseAngletoDegrees(t) {
        const e = t.toLowerCase(), s = parseFloat(e);
        return e.includes("rad") ? Ct(s) : e.includes("turn") ? 360 * s : s;
    }
}
const Qe = function(t) {
    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : S;
    const i = /\D{0,2}$/.exec(t), r = parseFloat(t), n = s.DPI;
    switch(null == i ? void 0 : i[0]){
        case "mm":
            return r * n / 25.4;
        case "cm":
            return r * n / 2.54;
        case "in":
            return r * n;
        case "pt":
            return r * n / 72;
        case "pc":
            return r * n / 72 * 12;
        case "em":
            return r * e;
        default:
            return r;
    }
}, Ze = (t)=>{
    const [e, s] = t.trim().split(" "), [i, r] = (n = e) && n !== P ? [
        n.slice(1, 4),
        n.slice(5, 8)
    ] : n === P ? [
        n,
        n
    ] : [
        "Mid",
        "Mid"
    ];
    var n;
    return {
        meetOrSlice: s || "meet",
        alignX: i,
        alignY: r
    };
}, ts = function(t, e) {
    let s, i, r = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
    if (e) if (e.toLive) s = `url(#SVGID_${se(e.id)})`;
    else {
        const t = new Je(e), r = t.getAlpha();
        s = t.toRgb(), 1 !== r && (i = r.toString());
    }
    else s = "none";
    return r ? `${t}: ${s}; ${i ? `${t}-opacity: ${i}; ` : ""}` : `${t}="${s}" ${i ? `${t}-opacity="${i}" ` : ""}`;
};
class es {
    getSvgStyles(t) {
        const e = this.fillRule ? this.fillRule : "nonzero", s = this.strokeWidth ? this.strokeWidth : "0", i = this.strokeDashArray ? this.strokeDashArray.join(" ") : P, r = this.strokeDashOffset ? this.strokeDashOffset : "0", n = this.strokeLineCap ? this.strokeLineCap : "butt", o = this.strokeLineJoin ? this.strokeLineJoin : "miter", a = this.strokeMiterLimit ? this.strokeMiterLimit : "4", h = void 0 !== this.opacity ? this.opacity : "1", l = this.visible ? "" : " visibility: hidden;", c = t ? "" : this.getSvgFilter(), u = ts(H, this.fill);
        return [
            ts(N, this.stroke),
            "stroke-width: ",
            s,
            "; ",
            "stroke-dasharray: ",
            i,
            "; ",
            "stroke-linecap: ",
            n,
            "; ",
            "stroke-dashoffset: ",
            r,
            "; ",
            "stroke-linejoin: ",
            o,
            "; ",
            "stroke-miterlimit: ",
            a,
            "; ",
            u,
            "fill-rule: ",
            e,
            "; ",
            "opacity: ",
            h,
            ";",
            c,
            l
        ].map((t)=>se(t)).join("");
    }
    getSvgFilter() {
        return this.shadow ? `filter: url(#SVGID_${se(this.shadow.id)});` : "";
    }
    getSvgCommons() {
        return [
            this.id ? `id="${se(String(this.id))}" ` : "",
            this.clipPath ? `clip-path="url(#${this.clipPath.clipPathId})" ` : ""
        ].join("");
    }
    getSvgTransform(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        const s = t ? this.calcTransformMatrix() : this.calcOwnMatrix();
        return `${`transform="${Vt(s)}`}${e}" `;
    }
    _toSVG(t) {
        return [
            ""
        ];
    }
    toSVG(t) {
        return this._createBaseSVGMarkup(this._toSVG(t), {
            reviver: t
        });
    }
    toClipPathSVG(t) {
        return "\t" + this._createBaseClipPathSVGMarkup(this._toSVG(t), {
            reviver: t
        });
    }
    _createBaseClipPathSVGMarkup(t) {
        let { reviver: e, additionalTransform: s = "" } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const i = [
            this.getSvgTransform(!0, s),
            this.getSvgCommons()
        ].join(""), r = t.indexOf("COMMON_PARTS");
        return t[r] = i, e ? e(t.join("")) : t.join("");
    }
    _createBaseSVGMarkup(t) {
        let { noStyle: e, reviver: s, withShadow: i, additionalTransform: r } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const n = e ? "" : `style="${this.getSvgStyles()}" `, o = i ? `style="${this.getSvgFilter()}" ` : "", a = this.clipPath, h = this.strokeUniform ? 'vector-effect="non-scaling-stroke" ' : "", l = a && a.absolutePositioned, c = this.stroke, u = this.fill, d = this.shadow, g = [], f = t.indexOf("COMMON_PARTS");
        let p;
        a && (a.clipPathId = `CLIPPATH_${ft()}`, p = `<clipPath id="${a.clipPathId}" >\n${a.toClipPathSVG(s)}</clipPath>\n`), l && g.push("<g ", o, this.getSvgCommons(), " >\n"), g.push("<g ", this.getSvgTransform(!1), l ? "" : o + this.getSvgCommons(), " >\n");
        const m = [
            n,
            h,
            e ? "" : this.addPaintOrder(),
            " ",
            r ? `transform="${r}" ` : ""
        ].join("");
        return t[f] = m, zt(u) && g.push(u.toSVG(this)), zt(c) && g.push(c.toSVG(this)), d && g.push(d.toSVG(this)), a && g.push(p), g.push(t.join("")), g.push("</g>\n"), l && g.push("</g>\n"), s ? s(g.join("")) : g.join("");
    }
    addPaintOrder() {
        return this.paintFirst !== H ? ` paint-order="${se(this.paintFirst)}" ` : "";
    }
}
function ss(t) {
    return new RegExp("^(" + t.join("|") + ")\\b", "i");
}
const is = "textDecorationThickness", rs = [
    "fontSize",
    "fontWeight",
    "fontFamily",
    "fontStyle"
], ns = [
    "underline",
    "overline",
    "linethrough"
], os = [
    ...rs,
    "lineHeight",
    "text",
    "charSpacing",
    "textAlign",
    "styles",
    "path",
    "pathStartOffset",
    "pathSide",
    "pathAlign"
], as = [
    ...os,
    ...ns,
    "textBackgroundColor",
    "direction",
    is
], hs = [
    ...rs,
    ...ns,
    N,
    "strokeWidth",
    H,
    "deltaY",
    "textBackgroundColor",
    is
], ls = {
    _reNewline: E,
    _reSpacesAndTabs: /[ \t\r]/g,
    _reSpaceAndTab: /[ \t\r]/,
    _reWords: /\S+/g,
    fontSize: 40,
    fontWeight: J,
    fontFamily: "Times New Roman",
    underline: !1,
    overline: !1,
    linethrough: !1,
    textAlign: O,
    fontStyle: J,
    lineHeight: 1.16,
    textBackgroundColor: "",
    stroke: null,
    shadow: null,
    path: void 0,
    pathStartOffset: 0,
    pathSide: O,
    pathAlign: "baseline",
    charSpacing: 0,
    deltaY: 0,
    direction: q,
    CACHE_FONT_SIZE: 400,
    MIN_TEXT_WIDTH: 2,
    superscript: {
        size: .6,
        baseline: -.35
    },
    subscript: {
        size: .6,
        baseline: .11
    },
    _fontSizeFraction: .222,
    offsets: {
        underline: .1,
        linethrough: -.28167,
        overline: -.81333
    },
    _fontSizeMult: 1.13,
    [is]: 66.667
}, cs = "justify", us = "justify-left", ds = "justify-right", gs = "justify-center", fs = String.raw`[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?`, ps = String.raw`(?:\s*,?\s+|\s*,\s*)`, ms = "http://www.w3.org/2000/svg", vs = new RegExp("(normal|italic)?\\s*(normal|small-caps)?\\s*(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)?\\s*(" + fs + "(?:px|cm|mm|em|pt|pc|in)*)(?:\\/(normal|" + fs + "))?\\s+(.*)"), ys = {
    cx: O,
    x: O,
    r: "radius",
    cy: k,
    y: k,
    display: "visible",
    visibility: "visible",
    transform: "transformMatrix",
    "fill-opacity": "fillOpacity",
    "fill-rule": "fillRule",
    "font-family": "fontFamily",
    "font-size": "fontSize",
    "font-style": "fontStyle",
    "font-weight": "fontWeight",
    "letter-spacing": "charSpacing",
    "paint-order": "paintFirst",
    "stroke-dasharray": "strokeDashArray",
    "stroke-dashoffset": "strokeDashOffset",
    "stroke-linecap": "strokeLineCap",
    "stroke-linejoin": "strokeLineJoin",
    "stroke-miterlimit": "strokeMiterLimit",
    "stroke-opacity": "strokeOpacity",
    "stroke-width": "strokeWidth",
    "text-decoration": "textDecoration",
    "text-anchor": "textAnchor",
    opacity: "opacity",
    "clip-path": "clipPath",
    "clip-rule": "clipRule",
    "vector-effect": "strokeUniform",
    "image-rendering": "imageSmoothing",
    "text-decoration-thickness": is
}, _s = "font-size", xs = "clip-path", Cs = ss([
    "path",
    "circle",
    "polygon",
    "polyline",
    "ellipse",
    "rect",
    "line",
    "image",
    "text"
]), bs = ss([
    "symbol",
    "image",
    "marker",
    "pattern",
    "view",
    "svg"
]), Ss = ss([
    "symbol",
    "g",
    "a",
    "svg",
    "clipPath",
    "defs"
]), ws = new RegExp(String.raw`^\s*(${fs})${ps}(${fs})${ps}(${fs})${ps}(${fs})\s*$`), Ts = "(-?\\d+(?:\\.\\d*)?(?:px)?(?:\\s?|$))?", Os = new RegExp("(?:\\s|^)" + Ts + Ts + "(" + fs + "?(?:px)?)?(?:\\s?|$)(?:$|\\s)");
class ks {
    constructor(){
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const e = "string" == typeof t ? ks.parseShadow(t) : t;
        Object.assign(this, ks.ownDefaults, e), this.id = ft();
    }
    static parseShadow(t) {
        const e = t.trim(), [, s = 0, i = 0, r = 0] = (Os.exec(e) || []).map((t)=>parseFloat(t) || 0);
        return {
            color: (e.replace(Os, "") || "rgb(0,0,0)").trim(),
            offsetX: s,
            offsetY: i,
            blur: r
        };
    }
    toString() {
        return [
            this.offsetX,
            this.offsetY,
            this.blur,
            this.color
        ].join("px ");
    }
    toSVG(t) {
        const e = ke(new ot(this.offsetX, this.offsetY), xt(-t.angle)), i = s.NUM_FRACTION_DIGITS, r = new Je(this.color);
        let n = 40, o = 40;
        return t.width && t.height && (n = 100 * Wt((Math.abs(e.x) + this.blur) / t.width, i) + 20, o = 100 * Wt((Math.abs(e.y) + this.blur) / t.height, i) + 20), t.flipX && (e.x *= -1), t.flipY && (e.y *= -1), `<filter id="SVGID_${se(this.id)}" y="-${o}%" height="${100 + 2 * o}%" x="-${n}%" width="${100 + 2 * n}%" >\n\t<feGaussianBlur in="SourceAlpha" stdDeviation="${Wt(this.blur ? this.blur / 2 : 0, i)}"></feGaussianBlur>\n\t<feOffset dx="${Wt(e.x, i)}" dy="${Wt(e.y, i)}" result="oBlur" ></feOffset>\n\t<feFlood flood-color="${r.toRgb()}" flood-opacity="${r.getAlpha()}"/>\n\t<feComposite in2="oBlur" operator="in" />\n\t<feMerge>\n\t\t<feMergeNode></feMergeNode>\n\t\t<feMergeNode in="SourceGraphic"></feMergeNode>\n\t</feMerge>\n</filter>\n`;
    }
    toObject() {
        const t = {
            color: this.color,
            blur: this.blur,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            affectStroke: this.affectStroke,
            nonScaling: this.nonScaling,
            type: this.constructor.type
        }, e = ks.ownDefaults;
        return this.includeDefaultValues ? t : Yt(t, (t, s)=>t !== e[s]);
    }
    static async fromObject(t) {
        return new this(t);
    }
}
t(ks, "ownDefaults", {
    color: "rgb(0,0,0)",
    blur: 0,
    offsetX: 0,
    offsetY: 0,
    affectStroke: !1,
    includeDefaultValues: !0,
    nonScaling: !1
}), t(ks, "type", "shadow"), tt.setClass(ks, "shadow");
const Ds = (t, e, s)=>Math.max(t, Math.min(e, s)), Ms = [
    k,
    O,
    W,
    V,
    "flipX",
    "flipY",
    "originX",
    "originY",
    "angle",
    "opacity",
    "globalCompositeOperation",
    "shadow",
    "visible",
    z,
    G
], Ps = [
    H,
    N,
    "strokeWidth",
    "strokeDashArray",
    "width",
    "height",
    "paintFirst",
    "strokeUniform",
    "strokeLineCap",
    "strokeDashOffset",
    "strokeLineJoin",
    "strokeMiterLimit",
    "backgroundColor",
    "clipPath"
], Es = {
    top: 0,
    left: 0,
    width: 0,
    height: 0,
    angle: 0,
    flipX: !1,
    flipY: !1,
    scaleX: 1,
    scaleY: 1,
    minScaleLimit: 0,
    skewX: 0,
    skewY: 0,
    originX: T,
    originY: T,
    strokeWidth: 1,
    strokeUniform: !1,
    padding: 0,
    opacity: 1,
    paintFirst: H,
    fill: "rgb(0,0,0)",
    fillRule: "nonzero",
    stroke: null,
    strokeDashArray: null,
    strokeDashOffset: 0,
    strokeLineCap: "butt",
    strokeLineJoin: "miter",
    strokeMiterLimit: 4,
    globalCompositeOperation: "source-over",
    backgroundColor: "",
    shadow: null,
    visible: !0,
    includeDefaultValues: !0,
    excludeFromExport: !1,
    objectCaching: !0,
    clipPath: void 0,
    inverted: !1,
    absolutePositioned: !1,
    centeredRotation: !0,
    centeredScaling: !1,
    dirty: !0
}, As = (t, e, s, i)=>(t < Math.abs(e) ? (t = e, i = s / 4) : i = 0 === e && 0 === t ? s / x * Math.asin(1) : s / x * Math.asin(e / t), {
        a: t,
        c: e,
        p: s,
        s: i
    }), js = (t, e, s, i, r)=>t * Math.pow(2, 10 * (i -= 1)) * Math.sin((i * r - e) * x / s), Fs = (t, e, s, i)=>-s * Math.cos(t / i * y) + s + e, Ls = (t, e, s, i)=>(t /= i) < 1 / 2.75 ? s * (7.5625 * t * t) + e : t < 2 / 2.75 ? s * (7.5625 * (t -= 1.5 / 2.75) * t + .75) + e : t < 2.5 / 2.75 ? s * (7.5625 * (t -= 2.25 / 2.75) * t + .9375) + e : s * (7.5625 * (t -= 2.625 / 2.75) * t + .984375) + e, Bs = (t, e, s, i)=>s - Ls(i - t, 0, s, i) + e;
var Rs = Object.freeze({
    __proto__: null,
    defaultEasing: Fs,
    easeInBack: function(t, e, s, i) {
        let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1.70158;
        return s * (t /= i) * t * ((r + 1) * t - r) + e;
    },
    easeInBounce: Bs,
    easeInCirc: (t, e, s, i)=>-s * (Math.sqrt(1 - (t /= i) * t) - 1) + e,
    easeInCubic: (t, e, s, i)=>s * (t / i) ** 3 + e,
    easeInElastic: (t, e, s, i)=>{
        const r = s;
        let n = 0;
        if (0 === t) return e;
        if (1 === (t /= i)) return e + s;
        n || (n = .3 * i);
        const { a: o, s: a, p: h } = As(r, s, n, 1.70158);
        return -js(o, a, h, t, i) + e;
    },
    easeInExpo: (t, e, s, i)=>0 === t ? e : s * 2 ** (10 * (t / i - 1)) + e,
    easeInOutBack: function(t, e, s, i) {
        let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1.70158;
        return (t /= i / 2) < 1 ? s / 2 * (t * t * ((1 + (r *= 1.525)) * t - r)) + e : s / 2 * ((t -= 2) * t * ((1 + (r *= 1.525)) * t + r) + 2) + e;
    },
    easeInOutBounce: (t, e, s, i)=>t < i / 2 ? .5 * Bs(2 * t, 0, s, i) + e : .5 * Ls(2 * t - i, 0, s, i) + .5 * s + e,
    easeInOutCirc: (t, e, s, i)=>(t /= i / 2) < 1 ? -s / 2 * (Math.sqrt(1 - t ** 2) - 1) + e : s / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + e,
    easeInOutCubic: (t, e, s, i)=>(t /= i / 2) < 1 ? s / 2 * t ** 3 + e : s / 2 * ((t - 2) ** 3 + 2) + e,
    easeInOutElastic: (t, e, s, i)=>{
        const r = s;
        let n = 0;
        if (0 === t) return e;
        if (2 === (t /= i / 2)) return e + s;
        n || (n = i * (.3 * 1.5));
        const { a: o, s: a, p: h, c: l } = As(r, s, n, 1.70158);
        return t < 1 ? -.5 * js(o, a, h, t, i) + e : o * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * i - a) * x / h) * .5 + l + e;
    },
    easeInOutExpo: (t, e, s, i)=>0 === t ? e : t === i ? e + s : (t /= i / 2) < 1 ? s / 2 * 2 ** (10 * (t - 1)) + e : s / 2 * -(2 ** (-10 * --t) + 2) + e,
    easeInOutQuad: (t, e, s, i)=>(t /= i / 2) < 1 ? s / 2 * t ** 2 + e : -s / 2 * (--t * (t - 2) - 1) + e,
    easeInOutQuart: (t, e, s, i)=>(t /= i / 2) < 1 ? s / 2 * t ** 4 + e : -s / 2 * ((t -= 2) * t ** 3 - 2) + e,
    easeInOutQuint: (t, e, s, i)=>(t /= i / 2) < 1 ? s / 2 * t ** 5 + e : s / 2 * ((t - 2) ** 5 + 2) + e,
    easeInOutSine: (t, e, s, i)=>-s / 2 * (Math.cos(Math.PI * t / i) - 1) + e,
    easeInQuad: (t, e, s, i)=>s * (t /= i) * t + e,
    easeInQuart: (t, e, s, i)=>s * (t /= i) * t ** 3 + e,
    easeInQuint: (t, e, s, i)=>s * (t / i) ** 5 + e,
    easeInSine: (t, e, s, i)=>-s * Math.cos(t / i * y) + s + e,
    easeOutBack: function(t, e, s, i) {
        let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1.70158;
        return s * ((t = t / i - 1) * t * ((r + 1) * t + r) + 1) + e;
    },
    easeOutBounce: Ls,
    easeOutCirc: (t, e, s, i)=>s * Math.sqrt(1 - (t = t / i - 1) * t) + e,
    easeOutCubic: (t, e, s, i)=>s * ((t / i - 1) ** 3 + 1) + e,
    easeOutElastic: (t, e, s, i)=>{
        const r = s;
        let n = 0;
        if (0 === t) return e;
        if (1 === (t /= i)) return e + s;
        n || (n = .3 * i);
        const { a: o, s: a, p: h, c: l } = As(r, s, n, 1.70158);
        return o * 2 ** (-10 * t) * Math.sin((t * i - a) * x / h) + l + e;
    },
    easeOutExpo: (t, e, s, i)=>t === i ? e + s : s * -(2 ** (-10 * t / i) + 1) + e,
    easeOutQuad: (t, e, s, i)=>-s * (t /= i) * (t - 2) + e,
    easeOutQuart: (t, e, s, i)=>-s * ((t = t / i - 1) * t ** 3 - 1) + e,
    easeOutQuint: (t, e, s, i)=>s * ((t / i - 1) ** 5 + 1) + e,
    easeOutSine: (t, e, s, i)=>s * Math.sin(t / i * y) + e
});
const Is = ()=>!1;
class $s {
    constructor(e){
        let { startValue: s, byValue: i, duration: r = 500, delay: n = 0, easing: o = Fs, onStart: a = v, onChange: h = v, onComplete: l = v, abort: c = Is, target: u } = e;
        t(this, "_state", "pending"), t(this, "durationProgress", 0), t(this, "valueProgress", 0), this.tick = this.tick.bind(this), this.duration = r, this.delay = n, this.easing = o, this._onStart = a, this._onChange = h, this._onComplete = l, this._abort = c, this.target = u, this.startValue = s, this.byValue = i, this.value = this.startValue, this.endValue = Object.freeze(this.calculate(this.duration).value);
    }
    get state() {
        return this._state;
    }
    isDone() {
        return "aborted" === this._state || "completed" === this._state;
    }
    start() {
        const t = (t)=>{
            "pending" === this._state && (this.startTime = t || +new Date, this._state = "running", this._onStart(), this.tick(this.startTime));
        };
        this.register(), this.delay > 0 ? setTimeout(()=>ut(t), this.delay) : ut(t);
    }
    tick(t) {
        const e = (t || +new Date) - this.startTime, s = Math.min(e, this.duration);
        this.durationProgress = s / this.duration;
        const { value: i, valueProgress: r } = this.calculate(s);
        this.value = Object.freeze(i), this.valueProgress = r, "aborted" !== this._state && (this._abort(this.value, this.valueProgress, this.durationProgress) ? (this._state = "aborted", this.unregister()) : e >= this.duration ? (this.durationProgress = this.valueProgress = 1, this._onChange(this.endValue, this.valueProgress, this.durationProgress), this._state = "completed", this._onComplete(this.endValue, this.valueProgress, this.durationProgress), this.unregister()) : (this._onChange(this.value, this.valueProgress, this.durationProgress), ut(this.tick)));
    }
    register() {
        et.push(this);
    }
    unregister() {
        et.remove(this);
    }
    abort() {
        this._state = "aborted", this.unregister();
    }
}
class Xs extends $s {
    constructor(t){
        let { startValue: e = 0, endValue: s = 100, ...i } = t;
        super({
            ...i,
            startValue: e,
            byValue: s - e
        });
    }
    calculate(t) {
        const e = this.easing(t, this.startValue, this.byValue, this.duration);
        return {
            value: e,
            valueProgress: Math.abs((e - this.startValue) / this.byValue)
        };
    }
}
class Ys extends $s {
    constructor(t){
        let { startValue: e = [
            0
        ], endValue: s = [
            100
        ], ...i } = t;
        super({
            ...i,
            startValue: e,
            byValue: s.map((t, s)=>t - e[s])
        });
    }
    calculate(t) {
        const e = this.startValue.map((e, s)=>this.easing(t, e, this.byValue[s], this.duration, s));
        return {
            value: e,
            valueProgress: Math.abs((e[0] - this.startValue[0]) / this.byValue[0])
        };
    }
}
const Ws = (t, e, s, i)=>e + s * (1 - Math.cos(t / i * y)), Vs = (t)=>t && ((e, s, i)=>t(new Je(e).toRgba(), s, i));
class zs extends $s {
    constructor(t){
        let { startValue: e, endValue: s, easing: i = Ws, onChange: r, onComplete: n, abort: o, ...a } = t;
        const h = new Je(e).getSource(), l = new Je(s).getSource();
        super({
            ...a,
            startValue: h,
            byValue: l.map((t, e)=>t - h[e]),
            easing: i,
            onChange: Vs(r),
            onComplete: Vs(n),
            abort: Vs(o)
        });
    }
    calculate(t) {
        const [e, s, i, r] = this.startValue.map((e, s)=>this.easing(t, e, this.byValue[s], this.duration, s)), n = [
            ...[
                e,
                s,
                i
            ].map(Math.round),
            Ds(0, r, 1)
        ];
        return {
            value: n,
            valueProgress: n.map((t, e)=>0 !== this.byValue[e] ? Math.abs((t - this.startValue[e]) / this.byValue[e]) : 0).find((t)=>0 !== t) || 0
        };
    }
}
function Gs(t) {
    const e = ((t)=>Array.isArray(t.startValue) || Array.isArray(t.endValue))(t) ? new Ys(t) : new Xs(t);
    return e.start(), e;
}
function Hs(t) {
    const e = new zs(t);
    return e.start(), e;
}
class Ns {
    constructor(t){
        this.status = t, this.points = [];
    }
    includes(t) {
        return this.points.some((e)=>e.eq(t));
    }
    append() {
        for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
        return this.points = this.points.concat(e.filter((t)=>!this.includes(t))), this;
    }
    static isPointContained(t, e, s) {
        let i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (e.eq(s)) return t.eq(e);
        if (e.x === s.x) return t.x === e.x && (i || t.y >= Math.min(e.y, s.y) && t.y <= Math.max(e.y, s.y));
        if (e.y === s.y) return t.y === e.y && (i || t.x >= Math.min(e.x, s.x) && t.x <= Math.max(e.x, s.x));
        {
            const r = De(e, s), n = De(e, t).divide(r);
            return i ? Math.abs(n.x) === Math.abs(n.y) : n.x === n.y && n.x >= 0 && n.x <= 1;
        }
    }
    static isPointInPolygon(t, e) {
        const s = new ot(t).setX(Math.min(t.x - 1, ...e.map((t)=>t.x)));
        let i = 0;
        for(let r = 0; r < e.length; r++){
            const n = this.intersectSegmentSegment(e[r], e[(r + 1) % e.length], t, s);
            if (n.includes(t)) return !0;
            i += Number("Intersection" === n.status);
        }
        return i % 2 == 1;
    }
    static intersectLineLine(t, e, s, i) {
        let r = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], n = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
        const o = e.x - t.x, a = e.y - t.y, h = i.x - s.x, l = i.y - s.y, c = t.x - s.x, u = t.y - s.y, d = h * u - l * c, g = o * u - a * c, f = l * o - h * a;
        if (0 !== f) {
            const e = d / f, s = g / f;
            return (r || 0 <= e && e <= 1) && (n || 0 <= s && s <= 1) ? new Ns("Intersection").append(new ot(t.x + e * o, t.y + e * a)) : new Ns;
        }
        if (0 === d || 0 === g) {
            const o = r || n || Ns.isPointContained(t, s, i) || Ns.isPointContained(e, s, i) || Ns.isPointContained(s, t, e) || Ns.isPointContained(i, t, e);
            return new Ns(o ? "Coincident" : void 0);
        }
        return new Ns("Parallel");
    }
    static intersectSegmentLine(t, e, s, i) {
        return Ns.intersectLineLine(t, e, s, i, !1, !0);
    }
    static intersectSegmentSegment(t, e, s, i) {
        return Ns.intersectLineLine(t, e, s, i, !1, !1);
    }
    static intersectLinePolygon(t, e, s) {
        let i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const r = new Ns, n = s.length;
        for(let o, a, h, l = 0; l < n; l++){
            if (o = s[l], a = s[(l + 1) % n], h = Ns.intersectLineLine(t, e, o, a, i, !1), "Coincident" === h.status) return h;
            r.append(...h.points);
        }
        return r.points.length > 0 && (r.status = "Intersection"), r;
    }
    static intersectSegmentPolygon(t, e, s) {
        return Ns.intersectLinePolygon(t, e, s, !1);
    }
    static intersectPolygonPolygon(t, e) {
        const s = new Ns, i = t.length, r = [];
        for(let n = 0; n < i; n++){
            const o = t[n], a = t[(n + 1) % i], h = Ns.intersectSegmentPolygon(o, a, e);
            "Coincident" === h.status ? (r.push(h), s.append(o, a)) : s.append(...h.points);
        }
        return r.length > 0 && r.length === t.length ? new Ns("Coincident") : (s.points.length > 0 && (s.status = "Intersection"), s);
    }
    static intersectPolygonRectangle(t, e, s) {
        const i = e.min(s), r = e.max(s), n = new ot(r.x, i.y), o = new ot(i.x, r.y);
        return Ns.intersectPolygonPolygon(t, [
            i,
            n,
            r,
            o
        ]);
    }
}
class Us extends ct {
    getX() {
        return this.getXY().x;
    }
    setX(t) {
        this.setXY(this.getXY().setX(t));
    }
    getY() {
        return this.getXY().y;
    }
    setY(t) {
        this.setXY(this.getXY().setY(t));
    }
    getRelativeX() {
        return this.left;
    }
    setRelativeX(t) {
        this.left = t;
    }
    getRelativeY() {
        return this.top;
    }
    setRelativeY(t) {
        this.top = t;
    }
    getXY() {
        const t = this.getRelativeXY();
        return this.group ? St(t, this.group.calcTransformMatrix()) : t;
    }
    setXY(t, e, s) {
        this.group && (t = St(t, wt(this.group.calcTransformMatrix()))), this.setRelativeXY(t, e, s);
    }
    getRelativeXY() {
        return new ot(this.left, this.top);
    }
    setRelativeXY(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.originX, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.originY;
        this.setPositionByOrigin(t, e, s);
    }
    isStrokeAccountedForInDimensions() {
        return !1;
    }
    getCoords() {
        const { tl: t, tr: e, br: s, bl: i } = this.aCoords || (this.aCoords = this.calcACoords()), r = [
            t,
            e,
            s,
            i
        ];
        if (this.group) {
            const t = this.group.calcTransformMatrix();
            return r.map((e)=>St(e, t));
        }
        return r;
    }
    intersectsWithRect(t, e) {
        return "Intersection" === Ns.intersectPolygonRectangle(this.getCoords(), t, e).status;
    }
    intersectsWithObject(t) {
        const e = Ns.intersectPolygonPolygon(this.getCoords(), t.getCoords());
        return "Intersection" === e.status || "Coincident" === e.status || t.isContainedWithinObject(this) || this.isContainedWithinObject(t);
    }
    isContainedWithinObject(t) {
        return this.getCoords().every((e)=>t.containsPoint(e));
    }
    isContainedWithinRect(t, e) {
        const { left: s, top: i, width: r, height: n } = this.getBoundingRect();
        return s >= t.x && s + r <= e.x && i >= t.y && i + n <= e.y;
    }
    isOverlapping(t) {
        return this.intersectsWithObject(t) || this.isContainedWithinObject(t) || t.isContainedWithinObject(this);
    }
    containsPoint(t) {
        return Ns.isPointInPolygon(t, this.getCoords());
    }
    isOnScreen() {
        if (!this.canvas) return !1;
        const { tl: t, br: e } = this.canvas.vptCoords;
        return !!this.getCoords().some((s)=>s.x <= e.x && s.x >= t.x && s.y <= e.y && s.y >= t.y) || !!this.intersectsWithRect(t, e) || this.containsPoint(t.midPointFrom(e));
    }
    isPartiallyOnScreen() {
        if (!this.canvas) return !1;
        const { tl: t, br: e } = this.canvas.vptCoords;
        if (this.intersectsWithRect(t, e)) return !0;
        return this.getCoords().every((s)=>(s.x >= e.x || s.x <= t.x) && (s.y >= e.y || s.y <= t.y)) && this.containsPoint(t.midPointFrom(e));
    }
    getBoundingRect() {
        return ge(this.getCoords());
    }
    getScaledWidth() {
        return this._getTransformedDimensions().x;
    }
    getScaledHeight() {
        return this._getTransformedDimensions().y;
    }
    scale(t) {
        this._set(W, t), this._set(V, t), this.setCoords();
    }
    scaleToWidth(t) {
        const e = this.getBoundingRect().width / this.getScaledWidth();
        return this.scale(t / this.width / e);
    }
    scaleToHeight(t) {
        const e = this.getBoundingRect().height / this.getScaledHeight();
        return this.scale(t / this.height / e);
    }
    getCanvasRetinaScaling() {
        var t;
        return (null === (t = this.canvas) || void 0 === t ? void 0 : t.getRetinaScaling()) || 1;
    }
    getTotalAngle() {
        return this.group ? Ct(kt(this.calcTransformMatrix())) : this.angle;
    }
    getViewportTransform() {
        var t;
        return (null === (t = this.canvas) || void 0 === t ? void 0 : t.viewportTransform) || b.concat();
    }
    calcACoords() {
        const t = Pt({
            angle: this.angle
        }), { x: e, y: s } = this.getRelativeCenterPoint(), i = Mt(e, s), r = Tt(i, t), n = this._getTransformedDimensions(), o = n.x / 2, a = n.y / 2;
        return {
            tl: St({
                x: -o,
                y: -a
            }, r),
            tr: St({
                x: o,
                y: -a
            }, r),
            bl: St({
                x: -o,
                y: a
            }, r),
            br: St({
                x: o,
                y: a
            }, r)
        };
    }
    setCoords() {
        this.aCoords = this.calcACoords();
    }
    transformMatrixKey() {
        let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = [];
        return !t && this.group && (e = this.group.transformMatrixKey(t)), e.push(this.top, this.left, this.width, this.height, this.scaleX, this.scaleY, this.angle, this.strokeWidth, this.skewX, this.skewY, +this.flipX, +this.flipY, we(this.originX), we(this.originY)), e;
    }
    calcTransformMatrix() {
        let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this.calcOwnMatrix();
        if (t || !this.group) return e;
        const s = this.transformMatrixKey(t), i = this.matrixCache;
        return i && i.key.every((t, e)=>t === s[e]) ? i.value : (this.group && (e = Tt(this.group.calcTransformMatrix(!1), e)), this.matrixCache = {
            key: s,
            value: e
        }, e);
    }
    calcOwnMatrix() {
        const t = this.transformMatrixKey(!0), e = this.ownMatrixCache;
        if (e && e.key.every((e, s)=>e === t[s])) return e.value;
        const s = this.getRelativeCenterPoint(), i = {
            angle: this.angle,
            translateX: s.x,
            translateY: s.y,
            scaleX: this.scaleX,
            scaleY: this.scaleY,
            skewX: this.skewX,
            skewY: this.skewY,
            flipX: this.flipX,
            flipY: this.flipY
        }, r = Bt(i);
        return this.ownMatrixCache = {
            key: t,
            value: r
        }, r;
    }
    _getNonTransformedDimensions() {
        return new ot(this.width, this.height).scalarAdd(this.strokeWidth);
    }
    _calculateCurrentDimensions(t) {
        return this._getTransformedDimensions(t).transform(this.getViewportTransform(), !0).scalarAdd(2 * this.padding);
    }
    _getTransformedDimensions() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const e = {
            scaleX: this.scaleX,
            scaleY: this.scaleY,
            skewX: this.skewX,
            skewY: this.skewY,
            width: this.width,
            height: this.height,
            strokeWidth: this.strokeWidth,
            ...t
        }, s = e.strokeWidth;
        let i = s, r = 0;
        this.strokeUniform && (i = 0, r = s);
        const n = e.width + i, o = e.height + i;
        let a;
        return a = 0 === e.skewX && 0 === e.skewY ? new ot(n * e.scaleX, o * e.scaleY) : ye(n, o, Lt(e)), a.scalarAdd(r);
    }
    translateToGivenOrigin(t, e, s, i, r) {
        let n = t.x, o = t.y;
        const a = we(i) - we(e), h = we(r) - we(s);
        if (a || h) {
            const t = this._getTransformedDimensions();
            n += a * t.x, o += h * t.y;
        }
        return new ot(n, o);
    }
    translateToCenterPoint(t, e, s) {
        if (e === T && s === T) return t;
        const i = this.translateToGivenOrigin(t, e, s, T, T);
        return this.angle ? i.rotate(xt(this.angle), t) : i;
    }
    translateToOriginPoint(t, e, s) {
        const i = this.translateToGivenOrigin(t, T, T, e, s);
        return this.angle ? i.rotate(xt(this.angle), t) : i;
    }
    getCenterPoint() {
        const t = this.getRelativeCenterPoint();
        return this.group ? St(t, this.group.calcTransformMatrix()) : t;
    }
    getRelativeCenterPoint() {
        return this.translateToCenterPoint(new ot(this.left, this.top), this.originX, this.originY);
    }
    getPointByOrigin(t, e) {
        return this.getPositionByOrigin(t, e);
    }
    getPositionByOrigin(t, e) {
        return this.translateToOriginPoint(this.getRelativeCenterPoint(), t, e);
    }
    setPositionByOrigin(t, e, s) {
        const i = this.translateToCenterPoint(t, e, s), r = this.translateToOriginPoint(i, this.originX, this.originY);
        this.set({
            left: r.x,
            top: r.y
        });
    }
    _getLeftTopCoords() {
        return this.getPositionByOrigin(O, k);
    }
    positionByLeftTop(t) {
        return this.setPositionByOrigin(t, O, k);
    }
}
let qs = class e extends Us {
    static getDefaults() {
        return e.ownDefaults;
    }
    get type() {
        const t = this.constructor.type;
        return "FabricObject" === t ? "object" : t.toLowerCase();
    }
    set type(t) {
        i("warn", "Setting type has no effect", t);
    }
    constructor(s){
        super(), t(this, "_cacheContext", null), Object.assign(this, e.ownDefaults), this.setOptions(s);
    }
    _createCacheCanvas() {
        this._cacheCanvas = pt(), this._cacheContext = this._cacheCanvas.getContext("2d"), this._updateCacheCanvas(), this.dirty = !0;
    }
    _limitCacheSize(t) {
        const e = t.width, i = t.height, r = s.maxCacheSideLimit, n = s.minCacheSideLimit;
        if (e <= r && i <= r && e * i <= s.perfLimitSizeTotal) return e < n && (t.width = n), i < n && (t.height = n), t;
        const o = e / i, [a, h] = p.limitDimsByArea(o), l = Ds(n, a, r), c = Ds(n, h, r);
        return e > l && (t.zoomX /= e / l, t.width = l, t.capped = !0), i > c && (t.zoomY /= i / c, t.height = c, t.capped = !0), t;
    }
    _getCacheCanvasDimensions() {
        const t = this.getTotalObjectScaling(), e = this._getTransformedDimensions({
            skewX: 0,
            skewY: 0
        }), s = e.x * t.x / this.scaleX, i = e.y * t.y / this.scaleY;
        return {
            width: Math.ceil(s + 2),
            height: Math.ceil(i + 2),
            zoomX: t.x,
            zoomY: t.y,
            x: s,
            y: i
        };
    }
    _updateCacheCanvas() {
        const t = this._cacheCanvas, e = this._cacheContext, { width: s, height: i, zoomX: r, zoomY: n, x: o, y: a } = this._limitCacheSize(this._getCacheCanvasDimensions()), h = s !== t.width || i !== t.height, l = this.zoomX !== r || this.zoomY !== n;
        if (!t || !e) return !1;
        if (h || l) {
            s !== t.width || i !== t.height ? (t.width = s, t.height = i) : (e.setTransform(1, 0, 0, 1, 0, 0), e.clearRect(0, 0, t.width, t.height));
            const h = o / 2, l = a / 2;
            return this.cacheTranslationX = Math.round(t.width / 2 - h) + h, this.cacheTranslationY = Math.round(t.height / 2 - l) + l, e.translate(this.cacheTranslationX, this.cacheTranslationY), e.scale(r, n), this.zoomX = r, this.zoomY = n, !0;
        }
        return !1;
    }
    setOptions() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this._setOptions(t);
    }
    transform(t) {
        const e = this.group && !this.group._transformDone || this.group && this.canvas && t === this.canvas.contextTop, s = this.calcTransformMatrix(!e);
        t.transform(s[0], s[1], s[2], s[3], s[4], s[5]);
    }
    getObjectScaling() {
        if (!this.group) return new ot(Math.abs(this.scaleX), Math.abs(this.scaleY));
        const t = Dt(this.calcTransformMatrix());
        return new ot(Math.abs(t.scaleX), Math.abs(t.scaleY));
    }
    getTotalObjectScaling() {
        const t = this.getObjectScaling();
        if (this.canvas) {
            const e = this.canvas.getZoom(), s = this.getCanvasRetinaScaling();
            return t.scalarMultiply(e * s);
        }
        return t;
    }
    getObjectOpacity() {
        let t = this.opacity;
        return this.group && (t *= this.group.getObjectOpacity()), t;
    }
    _constrainScale(t) {
        return Math.abs(t) < this.minScaleLimit ? t < 0 ? -this.minScaleLimit : this.minScaleLimit : 0 === t ? 1e-4 : t;
    }
    _set(t, e) {
        t !== W && t !== V || (e = this._constrainScale(e)), t === W && e < 0 ? (this.flipX = !this.flipX, e *= -1) : "scaleY" === t && e < 0 ? (this.flipY = !this.flipY, e *= -1) : "shadow" !== t || !e || e instanceof ks || (e = new ks(e));
        const s = this[t] !== e;
        return this[t] = e, s && this.constructor.cacheProperties.includes(t) && (this.dirty = !0), this.parent && (this.dirty || s && this.constructor.stateProperties.includes(t)) && this.parent._set("dirty", !0), this;
    }
    isNotVisible() {
        return 0 === this.opacity || !this.width && !this.height && 0 === this.strokeWidth || !this.visible;
    }
    render(t) {
        this.isNotVisible() || this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (t.save(), this._setupCompositeOperation(t), this.drawSelectionBackground(t), this.transform(t), this._setOpacity(t), this._setShadow(t), this.shouldCache() ? (this.renderCache(), this.drawCacheOnCanvas(t)) : (this._removeCacheCanvas(), this.drawObject(t, !1, {}), this.dirty = !1), t.restore());
    }
    drawSelectionBackground(t) {}
    renderCache(t) {
        if (t = t || {}, this._cacheCanvas && this._cacheContext || this._createCacheCanvas(), this.isCacheDirty() && this._cacheContext) {
            const { zoomX: e, zoomY: s, cacheTranslationX: i, cacheTranslationY: r } = this, { width: n, height: o } = this._cacheCanvas;
            this.drawObject(this._cacheContext, t.forClipping, {
                zoomX: e,
                zoomY: s,
                cacheTranslationX: i,
                cacheTranslationY: r,
                width: n,
                height: o,
                parentClipPaths: []
            }), this.dirty = !1;
        }
    }
    _removeCacheCanvas() {
        this._cacheCanvas = void 0, this._cacheContext = null;
    }
    hasStroke() {
        return !!this.stroke && "transparent" !== this.stroke && 0 !== this.strokeWidth;
    }
    hasFill() {
        return !!this.fill && "transparent" !== this.fill;
    }
    needsItsOwnCache() {
        return !!(this.paintFirst === N && this.hasFill() && this.hasStroke() && this.shadow) || !!this.clipPath;
    }
    shouldCache() {
        return this.ownCaching = this.objectCaching && (!this.parent || !this.parent.isOnACache()) || this.needsItsOwnCache(), this.ownCaching;
    }
    willDrawShadow() {
        return !!this.shadow && (0 !== this.shadow.offsetX || 0 !== this.shadow.offsetY);
    }
    drawClipPathOnCache(t, e, s) {
        t.save(), e.inverted ? t.globalCompositeOperation = "destination-out" : t.globalCompositeOperation = "destination-in", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s, 0, 0), t.restore();
    }
    drawObject(t, e, s) {
        const i = this.fill, r = this.stroke;
        e ? (this.fill = "black", this.stroke = "", this._setClippingProperties(t)) : this._renderBackground(t), this.fire("before:render", {
            ctx: t
        }), this._render(t), this._drawClipPath(t, this.clipPath, s), this.fill = i, this.stroke = r;
    }
    createClipPathLayer(t, e) {
        const s = vt(e), i = s.getContext("2d");
        if (i.translate(e.cacheTranslationX, e.cacheTranslationY), i.scale(e.zoomX, e.zoomY), t._cacheCanvas = s, e.parentClipPaths.forEach((t)=>{
            t.transform(i);
        }), e.parentClipPaths.push(t), t.absolutePositioned) {
            const t = wt(this.calcTransformMatrix());
            i.transform(t[0], t[1], t[2], t[3], t[4], t[5]);
        }
        return t.transform(i), t.drawObject(i, !0, e), s;
    }
    _drawClipPath(t, e, s) {
        if (!e) return;
        e._transformDone = !0;
        const i = this.createClipPathLayer(e, s);
        this.drawClipPathOnCache(t, e, i);
    }
    drawCacheOnCanvas(t) {
        t.scale(1 / this.zoomX, 1 / this.zoomY), t.drawImage(this._cacheCanvas, -this.cacheTranslationX, -this.cacheTranslationY);
    }
    isCacheDirty() {
        let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this.isNotVisible()) return !1;
        const e = this._cacheCanvas, s = this._cacheContext;
        return !(!e || !s || t || !this._updateCacheCanvas()) || !!(this.dirty || this.clipPath && this.clipPath.absolutePositioned) && (e && s && !t && (s.save(), s.setTransform(1, 0, 0, 1, 0, 0), s.clearRect(0, 0, e.width, e.height), s.restore()), !0);
    }
    _renderBackground(t) {
        if (!this.backgroundColor) return;
        const e = this._getNonTransformedDimensions();
        t.fillStyle = this.backgroundColor, t.fillRect(-e.x / 2, -e.y / 2, e.x, e.y), this._removeShadow(t);
    }
    _setOpacity(t) {
        this.group && !this.group._transformDone ? t.globalAlpha = this.getObjectOpacity() : t.globalAlpha *= this.opacity;
    }
    _setStrokeStyles(t, e) {
        const s = e.stroke;
        s && (t.lineWidth = e.strokeWidth, t.lineCap = e.strokeLineCap, t.lineDashOffset = e.strokeDashOffset, t.lineJoin = e.strokeLineJoin, t.miterLimit = e.strokeMiterLimit, zt(s) ? "percentage" === s.gradientUnits || s.gradientTransform || s.patternTransform ? this._applyPatternForTransformedGradient(t, s) : (t.strokeStyle = s.toLive(t), this._applyPatternGradientTransform(t, s)) : t.strokeStyle = e.stroke);
    }
    _setFillStyles(t, e) {
        let { fill: s } = e;
        s && (zt(s) ? (t.fillStyle = s.toLive(t), this._applyPatternGradientTransform(t, s)) : t.fillStyle = s);
    }
    _setClippingProperties(t) {
        t.globalAlpha = 1, t.strokeStyle = "transparent", t.fillStyle = "#000000";
    }
    _setLineDash(t, e) {
        e && 0 !== e.length && t.setLineDash(e);
    }
    _setShadow(t) {
        if (!this.shadow) return;
        const e = this.shadow, i = this.canvas, r = this.getCanvasRetinaScaling(), [n, , , o] = (null == i ? void 0 : i.viewportTransform) || b, a = n * r, h = o * r, l = e.nonScaling ? new ot(1, 1) : this.getObjectScaling();
        t.shadowColor = e.color, t.shadowBlur = e.blur * s.browserShadowBlurConstant * (a + h) * (l.x + l.y) / 4, t.shadowOffsetX = e.offsetX * a * l.x, t.shadowOffsetY = e.offsetY * h * l.y;
    }
    _removeShadow(t) {
        this.shadow && (t.shadowColor = "", t.shadowBlur = t.shadowOffsetX = t.shadowOffsetY = 0);
    }
    _applyPatternGradientTransform(t, e) {
        if (!zt(e)) return {
            offsetX: 0,
            offsetY: 0
        };
        const s = e.gradientTransform || e.patternTransform, i = -this.width / 2 + e.offsetX || 0, r = -this.height / 2 + e.offsetY || 0;
        return "percentage" === e.gradientUnits ? t.transform(this.width, 0, 0, this.height, i, r) : t.transform(1, 0, 0, 1, i, r), s && t.transform(s[0], s[1], s[2], s[3], s[4], s[5]), {
            offsetX: i,
            offsetY: r
        };
    }
    _renderPaintInOrder(t) {
        this.paintFirst === N ? (this._renderStroke(t), this._renderFill(t)) : (this._renderFill(t), this._renderStroke(t));
    }
    _render(t) {}
    _renderFill(t) {
        this.fill && (t.save(), this._setFillStyles(t, this), "evenodd" === this.fillRule ? t.fill("evenodd") : t.fill(), t.restore());
    }
    _renderStroke(t) {
        if (this.stroke && 0 !== this.strokeWidth) {
            if (this.shadow && !this.shadow.affectStroke && this._removeShadow(t), t.save(), this.strokeUniform) {
                const e = this.getObjectScaling();
                t.scale(1 / e.x, 1 / e.y);
            }
            this._setLineDash(t, this.strokeDashArray), this._setStrokeStyles(t, this), t.stroke(), t.restore();
        }
    }
    _applyPatternForTransformedGradient(t, e) {
        var s;
        const i = this._limitCacheSize(this._getCacheCanvasDimensions()), r = this.getCanvasRetinaScaling(), n = i.x / this.scaleX / r, o = i.y / this.scaleY / r, a = vt({
            width: Math.ceil(n),
            height: Math.ceil(o)
        }), h = a.getContext("2d");
        h && (h.beginPath(), h.moveTo(0, 0), h.lineTo(n, 0), h.lineTo(n, o), h.lineTo(0, o), h.closePath(), h.translate(n / 2, o / 2), h.scale(i.zoomX / this.scaleX / r, i.zoomY / this.scaleY / r), this._applyPatternGradientTransform(h, e), h.fillStyle = e.toLive(t), h.fill(), t.translate(-this.width / 2 - this.strokeWidth / 2, -this.height / 2 - this.strokeWidth / 2), t.scale(r * this.scaleX / i.zoomX, r * this.scaleY / i.zoomY), t.strokeStyle = null !== (s = h.createPattern(a, "no-repeat")) && void 0 !== s ? s : "");
    }
    _findCenterFromElement() {
        return new ot(this.left + this.width / 2, this.top + this.height / 2);
    }
    clone(t) {
        const e = this.toObject(t);
        return this.constructor.fromObject(e);
    }
    cloneAsImage(t) {
        const e = this.toCanvasElement(t);
        return new (tt.getClass("image"))(e);
    }
    toCanvasElement() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const e = ve(this), s = this.group, i = this.shadow, r = Math.abs, n = t.enableRetinaScaling ? f() : 1, o = (t.multiplier || 1) * n, a = t.canvasProvider || ((t)=>new he(t, {
                enableRetinaScaling: !1,
                renderOnAddRemove: !1,
                skipOffscreen: !1
            }));
        delete this.group, t.withoutTransform && me(this), t.withoutShadow && (this.shadow = null), t.viewportTransform && be(this, this.getViewportTransform()), this.setCoords();
        const h = pt(), l = this.getBoundingRect(), c = this.shadow, u = new ot;
        if (c) {
            const t = c.blur, e = c.nonScaling ? new ot(1, 1) : this.getObjectScaling();
            u.x = 2 * Math.round(r(c.offsetX) + t) * r(e.x), u.y = 2 * Math.round(r(c.offsetY) + t) * r(e.y);
        }
        const d = l.width + u.x, g = l.height + u.y;
        h.width = Math.ceil(d), h.height = Math.ceil(g);
        const p = a(h);
        "jpeg" === t.format && (p.backgroundColor = "#fff"), this.setPositionByOrigin(new ot(p.width / 2, p.height / 2), T, T);
        const m = this.canvas;
        p._objects = [
            this
        ], this.set("canvas", p), this.setCoords();
        const v = p.toCanvasElement(o || 1, t);
        return this.set("canvas", m), this.shadow = i, s && (this.group = s), this.set(e), this.setCoords(), p._objects = [], p.destroy(), v;
    }
    toDataURL() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return yt(this.toCanvasElement(t), t.format || "png", t.quality || 1);
    }
    toBlob() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return _t(this.toCanvasElement(t), t.format || "png", t.quality || 1);
    }
    isType() {
        for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
        return e.includes(this.constructor.type) || e.includes(this.type);
    }
    complexity() {
        return 1;
    }
    toJSON() {
        return this.toObject();
    }
    rotate(t) {
        const { centeredRotation: e, originX: s, originY: i } = this;
        if (e) {
            const { x: t, y: e } = this.getRelativeCenterPoint();
            this.originX = T, this.originY = T, this.left = t, this.top = e;
        }
        if (this.set("angle", t), e) {
            const { x: t, y: e } = this.getPositionByOrigin(s, i);
            this.left = t, this.top = e, this.originX = s, this.originY = i;
        }
    }
    setOnGroup() {}
    _setupCompositeOperation(t) {
        this.globalCompositeOperation && (t.globalCompositeOperation = this.globalCompositeOperation);
    }
    dispose() {
        et.cancelByTarget(this), this.off(), this._set("canvas", void 0), this._cacheCanvas && u().dispose(this._cacheCanvas), this._cacheCanvas = void 0, this._cacheContext = null;
    }
    animate(t, e) {
        return Object.entries(t).reduce((t, s)=>{
            let [i, r] = s;
            return t[i] = this._animate(i, r, e), t;
        }, {});
    }
    _animate(t, e) {
        let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        const i = t.split("."), r = this.constructor.colorProperties.includes(i[i.length - 1]), { abort: n, startValue: o, onChange: a, onComplete: h } = s, l = {
            ...s,
            target: this,
            startValue: null != o ? o : i.reduce((t, e)=>t[e], this),
            endValue: e,
            abort: null == n ? void 0 : n.bind(this),
            onChange: (t, e, s)=>{
                i.reduce((e, s, r)=>(r === i.length - 1 && (e[s] = t), e[s]), this), a && a(t, e, s);
            },
            onComplete: (t, e, s)=>{
                this.setCoords(), h && h(t, e, s);
            }
        };
        return r ? Hs(l) : Gs(l);
    }
    isDescendantOf(t) {
        const { parent: e, group: s } = this;
        return e === t || s === t || !!e && e.isDescendantOf(t) || !!s && s !== e && s.isDescendantOf(t);
    }
    getAncestors() {
        const t = [];
        let e = this;
        do {
            e = e.parent, e && t.push(e);
        }while (e)
        return t;
    }
    findCommonAncestors(t) {
        if (this === t) return {
            fork: [],
            otherFork: [],
            common: [
                this,
                ...this.getAncestors()
            ]
        };
        const e = this.getAncestors(), s = t.getAncestors();
        if (0 === e.length && s.length > 0 && this === s[s.length - 1]) return {
            fork: [],
            otherFork: [
                t,
                ...s.slice(0, s.length - 1)
            ],
            common: [
                this
            ]
        };
        for(let i, r = 0; r < e.length; r++){
            if (i = e[r], i === t) return {
                fork: [
                    this,
                    ...e.slice(0, r)
                ],
                otherFork: [],
                common: e.slice(r)
            };
            for(let n = 0; n < s.length; n++){
                if (this === s[n]) return {
                    fork: [],
                    otherFork: [
                        t,
                        ...s.slice(0, n)
                    ],
                    common: [
                        this,
                        ...e
                    ]
                };
                if (i === s[n]) return {
                    fork: [
                        this,
                        ...e.slice(0, r)
                    ],
                    otherFork: [
                        t,
                        ...s.slice(0, n)
                    ],
                    common: e.slice(r)
                };
            }
        }
        return {
            fork: [
                this,
                ...e
            ],
            otherFork: [
                t,
                ...s
            ],
            common: []
        };
    }
    hasCommonAncestors(t) {
        const e = this.findCommonAncestors(t);
        return e && !!e.common.length;
    }
    isInFrontOf(t) {
        if (this === t) return;
        const e = this.findCommonAncestors(t);
        if (e.fork.includes(t)) return !0;
        if (e.otherFork.includes(this)) return !1;
        const s = e.common[0] || this.canvas;
        if (!s) return;
        const i = e.fork.pop(), r = e.otherFork.pop(), n = s._objects.indexOf(i), o = s._objects.indexOf(r);
        return n > -1 && n > o;
    }
    toObject() {
        const t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []).concat(e.customProperties, this.constructor.customProperties || []);
        let i;
        const r = s.NUM_FRACTION_DIGITS, { clipPath: n, fill: o, stroke: a, shadow: h, strokeDashArray: l, left: c, top: u, originX: d, originY: g, width: f, height: p, strokeWidth: v, strokeLineCap: y, strokeDashOffset: _, strokeLineJoin: x, strokeUniform: C, strokeMiterLimit: b, scaleX: S, scaleY: w, angle: T, flipX: O, flipY: k, opacity: D, visible: M, backgroundColor: P, fillRule: E, paintFirst: A, globalCompositeOperation: j, skewX: F, skewY: L } = this;
        n && !n.excludeFromExport && (i = n.toObject(t.concat("inverted", "absolutePositioned")));
        const B = (t)=>Wt(t, r), R = {
            ...Xt(this, t),
            type: this.constructor.type,
            version: m,
            originX: d,
            originY: g,
            left: B(c),
            top: B(u),
            width: B(f),
            height: B(p),
            fill: Gt(o) ? o.toObject() : o,
            stroke: Gt(a) ? a.toObject() : a,
            strokeWidth: B(v),
            strokeDashArray: l ? l.concat() : l,
            strokeLineCap: y,
            strokeDashOffset: _,
            strokeLineJoin: x,
            strokeUniform: C,
            strokeMiterLimit: B(b),
            scaleX: B(S),
            scaleY: B(w),
            angle: B(T),
            flipX: O,
            flipY: k,
            opacity: B(D),
            shadow: h ? h.toObject() : h,
            visible: M,
            backgroundColor: P,
            fillRule: E,
            paintFirst: A,
            globalCompositeOperation: j,
            skewX: B(F),
            skewY: B(L),
            ...i ? {
                clipPath: i
            } : null
        };
        return this.includeDefaultValues ? R : this._removeDefaultValues(R);
    }
    toDatalessObject(t) {
        return this.toObject(t);
    }
    _removeDefaultValues(t) {
        const e = this.constructor.getDefaults(), s = Object.keys(e).length > 0 ? e : Object.getPrototypeOf(this);
        return Yt(t, (t, e)=>{
            if (e === O || e === k || "type" === e) return !0;
            const i = s[e];
            return t !== i && !(Array.isArray(t) && Array.isArray(i) && 0 === t.length && 0 === i.length);
        });
    }
    toString() {
        return `#<${this.constructor.type}>`;
    }
    static _fromObject(t) {
        let { type: e, ...s } = t, { extraParam: i, ...r } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return $t(s, r).then((t)=>i ? (delete t[i], new this(s[i], t)) : new this(t));
    }
    static fromObject(t, e) {
        return this._fromObject(t, e);
    }
};
t(qs, "stateProperties", Ms), t(qs, "cacheProperties", Ps), t(qs, "ownDefaults", Es), t(qs, "type", "FabricObject"), t(qs, "colorProperties", [
    H,
    N,
    "backgroundColor"
]), t(qs, "customProperties", []), tt.setClass(qs), tt.setClass(qs, "object");
const Ks = (t, e)=>{
    var s;
    const { transform: { target: i } } = e;
    null === (s = i.canvas) || void 0 === s || s.fire(`object:${t}`, {
        ...e,
        target: i
    }), i.fire(t, e);
}, Js = (t, e, s)=>(i, r, n, o)=>{
        const a = e(i, r, n, o);
        return a && Ks(t, {
            ...Ye(i, r, n, o),
            ...s
        }), a;
    };
function Qs(t) {
    return (e, s, i, r)=>{
        const { target: n, originX: o, originY: a } = s, h = n.getPositionByOrigin(o, a), l = t(e, s, i, r);
        return n.setPositionByOrigin(h, s.originX, s.originY), l;
    };
}
const Zs = (t, e, s, i)=>(r, n, o, a)=>{
        const h = Ve(n, n.originX, n.originY, o, a)[s], l = we(n[e]);
        if (0 === l || l > 0 && h < 0 || l < 0 && h > 0) {
            const { target: e } = n, s = e.strokeWidth / (e.strokeUniform ? e[i] : 1), r = Ie(n) ? 2 : 1, o = e[t], a = Math.abs(h * r / e[i]) - s;
            return e.set(t, Math.max(a, 1)), o !== e[t];
        }
        return !1;
    }, ti = Zs("width", "originX", "x", "scaleX"), ei = Zs("height", "originY", "y", "scaleY"), si = Js(R, Qs(ti)), ii = Js(R, Qs(ei));
function ri(t, e, s, i, r) {
    t.save();
    const { stroke: n, xSize: o, ySize: a, opName: h } = this.commonRenderProps(t, e, s, r, i);
    let l = o;
    o > a ? t.scale(1, a / o) : a > o && (l = a, t.scale(o / a, 1)), t.beginPath(), t.arc(0, 0, l / 2, 0, x, !1), t[h](), n && t.stroke(), t.restore();
}
function ni(t, e, s, i, r) {
    t.save();
    const { stroke: n, xSize: o, ySize: a, opName: h } = this.commonRenderProps(t, e, s, r, i), l = o / 2, c = a / 2;
    t[`${h}Rect`](-l, -c, o, a), n && t.strokeRect(-l, -c, o, a), t.restore();
}
class oi {
    constructor(e){
        t(this, "visible", !0), t(this, "actionName", Y), t(this, "angle", 0), t(this, "x", 0), t(this, "y", 0), t(this, "offsetX", 0), t(this, "offsetY", 0), t(this, "sizeX", 0), t(this, "sizeY", 0), t(this, "touchSizeX", 0), t(this, "touchSizeY", 0), t(this, "cursorStyle", "crosshair"), t(this, "withConnection", !1), Object.assign(this, e);
    }
    getTransformAnchorPoint() {
        var t;
        return null !== (t = this.transformAnchorPoint) && void 0 !== t ? t : new ot(.5 - this.x, .5 - this.y);
    }
    shouldActivate(t, e, s, i) {
        var r;
        let { tl: n, tr: o, br: a, bl: h } = i;
        return (null === (r = e.canvas) || void 0 === r ? void 0 : r.getActiveObject()) === e && e.isControlVisible(t) && Ns.isPointInPolygon(s, [
            n,
            o,
            a,
            h
        ]);
    }
    getActionHandler(t, e, s) {
        return this.actionHandler;
    }
    getMouseDownHandler(t, e, s) {
        return this.mouseDownHandler;
    }
    getMouseUpHandler(t, e, s) {
        return this.mouseUpHandler;
    }
    cursorStyleHandler(t, e, s, i) {
        return e.cursorStyle;
    }
    getActionName(t, e, s) {
        return e.actionName;
    }
    getVisibility(t, e) {
        var s, i;
        return null !== (s = null === (i = t._controlsVisibility) || void 0 === i ? void 0 : i[e]) && void 0 !== s ? s : this.visible;
    }
    setVisibility(t, e, s) {
        this.visible = t;
    }
    positionHandler(t, e, s, i) {
        return new ot(this.x * t.x + this.offsetX, this.y * t.y + this.offsetY).transform(e);
    }
    calcCornerCoords(t, e, s, i, r, n) {
        const o = Ot([
            Mt(s, i),
            Pt({
                angle: t
            }),
            Et((r ? this.touchSizeX : this.sizeX) || e, (r ? this.touchSizeY : this.sizeY) || e)
        ]);
        return {
            tl: new ot(-.5, -.5).transform(o),
            tr: new ot(.5, -.5).transform(o),
            br: new ot(.5, .5).transform(o),
            bl: new ot(-.5, .5).transform(o)
        };
    }
    commonRenderProps(t, e, s, i) {
        let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
        const { cornerSize: n, cornerColor: o, transparentCorners: a, cornerStrokeColor: h } = r, l = n || i.cornerSize, c = this.sizeX || l, u = this.sizeY || l, d = void 0 !== a ? a : i.transparentCorners, g = d ? N : H, f = h || i.cornerStrokeColor, p = !d && !!f;
        return t.fillStyle = o || i.cornerColor || "", t.strokeStyle = f || "", t.translate(e, s), t.rotate(xt(i.getTotalAngle())), {
            stroke: p,
            xSize: c,
            ySize: u,
            transparentCorners: d,
            opName: g
        };
    }
    render(t, e, s, i, r) {
        if ("circle" === ((i = i || {}).cornerStyle || r.cornerStyle)) ri.call(this, t, e, s, i, r);
        else ni.call(this, t, e, s, i, r);
    }
}
const ai = (t, e, s)=>s.lockRotation ? Re : e.cursorStyle, hi = Js(F, Qs((t, e, s, i)=>{
    let { target: r, ex: n, ey: o, theta: a, originX: h, originY: l } = e;
    const c = r.getPositionByOrigin(h, l);
    if (Xe(r, "lockRotation")) return !1;
    const u = Math.atan2(o - c.y, n - c.x), d = Math.atan2(i - c.y, s - c.x);
    let g = Ct(d - u + a);
    if (r.snapAngle && r.snapAngle > 0) {
        const t = r.snapAngle, e = r.snapThreshold || t, s = Math.ceil(g / t) * t, i = Math.floor(g / t) * t;
        Math.abs(g - i) < e ? g = i : Math.abs(g - s) < e && (g = s);
    }
    g < 0 && (g = 360 + g), g %= 360;
    const f = r.angle !== g;
    return r.angle = g, f;
}));
function li(t, e) {
    const s = e.canvas, i = t[s.uniScaleKey];
    return s.uniformScaling && !i || !s.uniformScaling && i;
}
function ci(t, e, s) {
    const i = Xe(t, "lockScalingX"), r = Xe(t, "lockScalingY");
    if (i && r) return !0;
    if (!e && (i || r) && s) return !0;
    if (i && "x" === e) return !0;
    if (r && "y" === e) return !0;
    const { width: n, height: o, strokeWidth: a } = t;
    return 0 === n && 0 === a && "y" !== e || 0 === o && 0 === a && "x" !== e;
}
const ui = [
    "e",
    "se",
    "s",
    "sw",
    "w",
    "nw",
    "n",
    "ne",
    "e"
], di = (t, e, s, i)=>{
    const r = li(t, s);
    if (ci(s, 0 !== e.x && 0 === e.y ? "x" : 0 === e.x && 0 !== e.y ? "y" : "", r)) return Re;
    const n = We(s, 0, i);
    return `${ui[n]}-resize`;
};
function gi(t, e, s, i) {
    let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
    const n = e.target, o = r.by, a = li(t, n);
    let h, l, c, u, d, g;
    if (ci(n, o, a)) return !1;
    if (e.gestureScale) l = e.scaleX * e.gestureScale, c = e.scaleY * e.gestureScale;
    else {
        if (h = Ve(e, e.originX, e.originY, s, i), d = "y" !== o ? Math.sign(h.x || e.signX || 1) : 1, g = "x" !== o ? Math.sign(h.y || e.signY || 1) : 1, e.signX || (e.signX = d), e.signY || (e.signY = g), Xe(n, "lockScalingFlip") && (e.signX !== d || e.signY !== g)) return !1;
        if (u = n._getTransformedDimensions(), a && !o) {
            const t = Math.abs(h.x) + Math.abs(h.y), { original: s } = e, i = t / (Math.abs(u.x * s.scaleX / n.scaleX) + Math.abs(u.y * s.scaleY / n.scaleY));
            l = s.scaleX * i, c = s.scaleY * i;
        } else l = Math.abs(h.x * n.scaleX / u.x), c = Math.abs(h.y * n.scaleY / u.y);
        Ie(e) && (l *= 2, c *= 2), e.signX !== d && "y" !== o && (e.originX = $e(e.originX), l *= -1, e.signX = d), e.signY !== g && "x" !== o && (e.originY = $e(e.originY), c *= -1, e.signY = g);
    }
    const f = n.scaleX, p = n.scaleY;
    return o ? ("x" === o && n.set(W, l), "y" === o && n.set(V, c)) : (!Xe(n, "lockScalingX") && n.set(W, l), !Xe(n, "lockScalingY") && n.set(V, c)), f !== n.scaleX || p !== n.scaleY;
}
const fi = Js(j, Qs((t, e, s, i)=>gi(t, e, s, i))), pi = Js(j, Qs((t, e, s, i)=>gi(t, e, s, i, {
        by: "x"
    }))), mi = Js(j, Qs((t, e, s, i)=>gi(t, e, s, i, {
        by: "y"
    }))), vi = {
    x: {
        counterAxis: "y",
        scale: W,
        skew: z,
        lockSkewing: "lockSkewingX",
        origin: "originX",
        flip: "flipX"
    },
    y: {
        counterAxis: "x",
        scale: V,
        skew: G,
        lockSkewing: "lockSkewingY",
        origin: "originY",
        flip: "flipY"
    }
}, yi = [
    "ns",
    "nesw",
    "ew",
    "nwse"
], _i = (t, e, s, i)=>{
    if (0 !== e.x && Xe(s, "lockSkewingY")) return Re;
    if (0 !== e.y && Xe(s, "lockSkewingX")) return Re;
    const r = We(s, 0, i) % 4;
    return `${yi[r]}-resize`;
};
function xi(t, e, s, i, r) {
    const { target: n } = s, { counterAxis: o, origin: a, lockSkewing: h, skew: l, flip: c } = vi[t];
    if (Xe(n, h)) return !1;
    const { origin: u, flip: d } = vi[o], g = we(s[u]) * (n[d] ? -1 : 1), f = -Math.sign(g) * (n[c] ? -1 : 1), p = .5 * -((0 === n[l] && Ve(s, T, T, i, r)[t] > 0 || n[l] > 0 ? 1 : -1) * f) + .5, m = Js(B, Qs((e, s, i, r)=>(function(t, e, s) {
            let { target: i, ex: r, ey: n, skewingSide: o, ...a } = e;
            const { skew: h } = vi[t], l = s.subtract(new ot(r, n)).divide(new ot(i.scaleX, i.scaleY))[t], c = i[h], u = a[h], d = Math.tan(xt(u)), g = "y" === t ? i._getTransformedDimensions({
                scaleX: 1,
                scaleY: 1,
                skewX: 0
            }).x : i._getTransformedDimensions({
                scaleX: 1,
                scaleY: 1
            }).y, f = 2 * l * o / Math.max(g, 1) + d, p = Ct(Math.atan(f));
            i.set(h, p);
            const m = c !== i[h];
            if (m && "y" === t) {
                const { skewX: t, scaleX: e } = i, s = i._getTransformedDimensions({
                    skewY: c
                }), r = i._getTransformedDimensions(), n = 0 !== t ? s.x / r.x : 1;
                1 !== n && i.set(W, n * e);
            }
            return m;
        })(t, s, new ot(i, r))));
    return m(e, {
        ...s,
        [a]: p,
        skewingSide: f
    }, i, r);
}
const Ci = (t, e, s, i)=>xi("x", t, e, s, i), bi = (t, e, s, i)=>xi("y", t, e, s, i);
function Si(t, e) {
    return t[e.canvas.altActionKey];
}
const wi = (t, e, s)=>{
    const i = Si(t, s);
    return 0 === e.x ? i ? z : V : 0 === e.y ? i ? G : W : "";
}, Ti = (t, e, s, i)=>Si(t, s) ? _i(0, e, s, i) : di(t, e, s, i), Oi = (t, e, s, i)=>Si(t, e.target) ? bi(t, e, s, i) : pi(t, e, s, i), ki = (t, e, s, i)=>Si(t, e.target) ? Ci(t, e, s, i) : mi(t, e, s, i), Di = ()=>({
        ml: new oi({
            x: -.5,
            y: 0,
            cursorStyleHandler: Ti,
            actionHandler: Oi,
            getActionName: wi
        }),
        mr: new oi({
            x: .5,
            y: 0,
            cursorStyleHandler: Ti,
            actionHandler: Oi,
            getActionName: wi
        }),
        mb: new oi({
            x: 0,
            y: .5,
            cursorStyleHandler: Ti,
            actionHandler: ki,
            getActionName: wi
        }),
        mt: new oi({
            x: 0,
            y: -.5,
            cursorStyleHandler: Ti,
            actionHandler: ki,
            getActionName: wi
        }),
        tl: new oi({
            x: -.5,
            y: -.5,
            cursorStyleHandler: di,
            actionHandler: fi
        }),
        tr: new oi({
            x: .5,
            y: -.5,
            cursorStyleHandler: di,
            actionHandler: fi
        }),
        bl: new oi({
            x: -.5,
            y: .5,
            cursorStyleHandler: di,
            actionHandler: fi
        }),
        br: new oi({
            x: .5,
            y: .5,
            cursorStyleHandler: di,
            actionHandler: fi
        }),
        mtr: new oi({
            x: 0,
            y: -.5,
            actionHandler: hi,
            cursorStyleHandler: ai,
            offsetY: -40,
            withConnection: !0,
            actionName: L
        })
    }), Mi = ()=>({
        mr: new oi({
            x: .5,
            y: 0,
            actionHandler: si,
            cursorStyleHandler: Ti,
            actionName: R
        }),
        ml: new oi({
            x: -.5,
            y: 0,
            actionHandler: si,
            cursorStyleHandler: Ti,
            actionName: R
        })
    }), Pi = ()=>({
        ...Di(),
        ...Mi()
    });
class Ei extends qs {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...Ei.ownDefaults
        };
    }
    constructor(t){
        super(), Object.assign(this, this.constructor.createControls(), Ei.ownDefaults), this.setOptions(t);
    }
    static createControls() {
        return {
            controls: Di()
        };
    }
    _updateCacheCanvas() {
        const t = this.canvas;
        if (this.noScaleCache && t && t._currentTransform) {
            const e = t._currentTransform, s = e.target, i = e.action;
            if (this === s && i && i.startsWith(Y)) return !1;
        }
        return super._updateCacheCanvas();
    }
    getActiveControl() {
        const t = this.__corner;
        return t ? {
            key: t,
            control: this.controls[t],
            coord: this.oCoords[t]
        } : void 0;
    }
    findControl(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (!this.hasControls || !this.canvas) return;
        this.__corner = void 0;
        const s = Object.entries(this.oCoords);
        for(let i = s.length - 1; i >= 0; i--){
            const [r, n] = s[i], o = this.controls[r];
            if (o.shouldActivate(r, this, t, e ? n.touchCorner : n.corner)) return this.__corner = r, {
                key: r,
                control: o,
                coord: this.oCoords[r]
            };
        }
    }
    calcOCoords() {
        const t = this.getViewportTransform(), e = this.getCenterPoint(), s = Mt(e.x, e.y), i = Pt({
            angle: this.getTotalAngle() - (this.group && this.flipX ? 180 : 0)
        }), r = Tt(s, i), n = Tt(t, r), o = Tt(n, [
            1 / t[0],
            0,
            0,
            1 / t[3],
            0,
            0
        ]), a = this.group ? Dt(this.calcTransformMatrix()) : void 0;
        a && (a.scaleX = Math.abs(a.scaleX), a.scaleY = Math.abs(a.scaleY));
        const h = this._calculateCurrentDimensions(a), l = {};
        return this.forEachControl((t, e)=>{
            const s = t.positionHandler(h, o, this, t);
            l[e] = Object.assign(s, this._calcCornerCoords(t, s));
        }), l;
    }
    _calcCornerCoords(t, e) {
        const s = this.getTotalAngle();
        return {
            corner: t.calcCornerCoords(s, this.cornerSize, e.x, e.y, !1, this),
            touchCorner: t.calcCornerCoords(s, this.touchCornerSize, e.x, e.y, !0, this)
        };
    }
    setCoords() {
        super.setCoords(), this.canvas && (this.oCoords = this.calcOCoords());
    }
    forEachControl(t) {
        for(const e in this.controls)t(this.controls[e], e, this);
    }
    drawSelectionBackground(t) {
        if (!this.selectionBackgroundColor || this.canvas && this.canvas._activeObject !== this) return;
        t.save();
        const e = this.getRelativeCenterPoint(), s = this._calculateCurrentDimensions(), i = this.getViewportTransform();
        t.translate(e.x, e.y), t.scale(1 / i[0], 1 / i[3]), t.rotate(xt(this.angle)), t.fillStyle = this.selectionBackgroundColor, t.fillRect(-s.x / 2, -s.y / 2, s.x, s.y), t.restore();
    }
    strokeBorders(t, e) {
        t.strokeRect(-e.x / 2, -e.y / 2, e.x, e.y);
    }
    _drawBorders(t, e) {
        let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        const i = {
            hasControls: this.hasControls,
            borderColor: this.borderColor,
            borderDashArray: this.borderDashArray,
            ...s
        };
        t.save(), t.strokeStyle = i.borderColor, this._setLineDash(t, i.borderDashArray), this.strokeBorders(t, e), i.hasControls && this.drawControlsConnectingLines(t, e), t.restore();
    }
    _renderControls(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const { hasBorders: s, hasControls: i } = this, r = {
            hasBorders: s,
            hasControls: i,
            ...e
        }, n = this.getViewportTransform(), o = r.hasBorders, a = r.hasControls, h = Tt(n, this.calcTransformMatrix()), l = Dt(h);
        t.save(), t.translate(l.translateX, l.translateY), t.lineWidth = this.borderScaleFactor, this.group === this.parent && (t.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1), this.flipX && (l.angle -= 180), t.rotate(xt(this.group ? l.angle : this.angle)), o && this.drawBorders(t, l, e), a && this.drawControls(t, e), t.restore();
    }
    drawBorders(t, e, s) {
        let i;
        if (s && s.forActiveSelection || this.group) {
            const t = ye(this.width, this.height, Lt(e)), s = this.isStrokeAccountedForInDimensions() ? at : (this.strokeUniform ? (new ot).scalarAdd(this.canvas ? this.canvas.getZoom() : 1) : new ot(e.scaleX, e.scaleY)).scalarMultiply(this.strokeWidth);
            i = t.add(s).scalarAdd(this.borderScaleFactor).scalarAdd(2 * this.padding);
        } else i = this._calculateCurrentDimensions().scalarAdd(this.borderScaleFactor);
        this._drawBorders(t, i, s);
    }
    drawControlsConnectingLines(t, e) {
        let s = !1;
        t.beginPath(), this.forEachControl((i, r)=>{
            i.withConnection && i.getVisibility(this, r) && (s = !0, t.moveTo(i.x * e.x, i.y * e.y), t.lineTo(i.x * e.x + i.offsetX, i.y * e.y + i.offsetY));
        }), s && t.stroke();
    }
    drawControls(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        t.save();
        const s = this.getCanvasRetinaScaling(), { cornerStrokeColor: i, cornerDashArray: r, cornerColor: n } = this, o = {
            cornerStrokeColor: i,
            cornerDashArray: r,
            cornerColor: n,
            ...e
        };
        t.setTransform(s, 0, 0, s, 0, 0), t.strokeStyle = t.fillStyle = o.cornerColor, this.transparentCorners || (t.strokeStyle = o.cornerStrokeColor), this._setLineDash(t, o.cornerDashArray), this.forEachControl((e, s)=>{
            if (e.getVisibility(this, s)) {
                const i = this.oCoords[s];
                e.render(t, i.x, i.y, o, this);
            }
        }), t.restore();
    }
    isControlVisible(t) {
        return this.controls[t] && this.controls[t].getVisibility(this, t);
    }
    setControlVisible(t, e) {
        this._controlsVisibility || (this._controlsVisibility = {}), this._controlsVisibility[t] = e;
    }
    setControlsVisibility() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        Object.entries(t).forEach((t)=>{
            let [e, s] = t;
            return this.setControlVisible(e, s);
        });
    }
    clearContextTop(t) {
        if (!this.canvas) return;
        const e = this.canvas.contextTop;
        if (!e) return;
        const s = this.canvas.viewportTransform;
        e.save(), e.transform(s[0], s[1], s[2], s[3], s[4], s[5]), this.transform(e);
        const i = this.width + 4, r = this.height + 4;
        return e.clearRect(-i / 2, -r / 2, i, r), t || e.restore(), e;
    }
    onDeselect(t) {
        return !1;
    }
    onSelect(t) {
        return !1;
    }
    shouldStartDragging(t) {
        return !1;
    }
    onDragStart(t) {
        return !1;
    }
    canDrop(t) {
        return !1;
    }
    renderDragSourceEffect(t) {}
    renderDropTargetEffect(t) {}
}
function Ai(t, e) {
    return e.forEach((e)=>{
        Object.getOwnPropertyNames(e.prototype).forEach((s)=>{
            "constructor" !== s && Object.defineProperty(t.prototype, s, Object.getOwnPropertyDescriptor(e.prototype, s) || Object.create(null));
        });
    }), t;
}
t(Ei, "ownDefaults", {
    noScaleCache: !0,
    lockMovementX: !1,
    lockMovementY: !1,
    lockRotation: !1,
    lockScalingX: !1,
    lockScalingY: !1,
    lockSkewingX: !1,
    lockSkewingY: !1,
    lockScalingFlip: !1,
    cornerSize: 13,
    touchCornerSize: 24,
    transparentCorners: !0,
    cornerColor: "rgb(178,204,255)",
    cornerStrokeColor: "",
    cornerStyle: "rect",
    cornerDashArray: null,
    hasControls: !0,
    borderColor: "rgb(178,204,255)",
    borderDashArray: null,
    borderOpacityWhenMoving: .4,
    borderScaleFactor: 1,
    hasBorders: !0,
    selectionBackgroundColor: "",
    selectable: !0,
    evented: !0,
    perPixelTargetFind: !1,
    activeOn: "down",
    hoverCursor: null,
    moveCursor: null
});
class ji extends Ei {
}
Ai(ji, [
    es
]), tt.setClass(ji), tt.setClass(ji, "object");
const Fi = (t, e, s, i)=>{
    const r = 2 * (i = Math.round(i)) + 1, { data: n } = t.getImageData(e - i, s - i, r, r);
    for(let t = 3; t < n.length; t += 4){
        if (n[t] > 0) return !1;
    }
    return !0;
};
class Li {
    constructor(t){
        this.options = t, this.strokeProjectionMagnitude = this.options.strokeWidth / 2, this.scale = new ot(this.options.scaleX, this.options.scaleY), this.strokeUniformScalar = this.options.strokeUniform ? new ot(1 / this.options.scaleX, 1 / this.options.scaleY) : new ot(1, 1);
    }
    createSideVector(t, e) {
        const s = De(t, e);
        return this.options.strokeUniform ? s.multiply(this.scale) : s;
    }
    projectOrthogonally(t, e, s) {
        return this.applySkew(t.add(this.calcOrthogonalProjection(t, e, s)));
    }
    isSkewed() {
        return 0 !== this.options.skewX || 0 !== this.options.skewY;
    }
    applySkew(t) {
        const e = new ot(t);
        return e.y += e.x * Math.tan(xt(this.options.skewY)), e.x += e.y * Math.tan(xt(this.options.skewX)), e;
    }
    scaleUnitVector(t, e) {
        return t.multiply(this.strokeUniformScalar).scalarMultiply(e);
    }
}
const Bi = new ot;
class Ri extends Li {
    static getOrthogonalRotationFactor(t, e) {
        const s = e ? Pe(t, e) : Ee(t);
        return Math.abs(s) < y ? -1 : 1;
    }
    constructor(e, s, i, r){
        super(r), t(this, "AB", void 0), t(this, "AC", void 0), t(this, "alpha", void 0), t(this, "bisector", void 0), this.A = new ot(e), this.B = new ot(s), this.C = new ot(i), this.AB = this.createSideVector(this.A, this.B), this.AC = this.createSideVector(this.A, this.C), this.alpha = Pe(this.AB, this.AC), this.bisector = Ae(ke(this.AB.eq(Bi) ? this.AC : this.AB, this.alpha / 2));
    }
    calcOrthogonalProjection(t, e) {
        let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.strokeProjectionMagnitude;
        const i = this.createSideVector(t, e), r = je(i), n = Ri.getOrthogonalRotationFactor(r, this.bisector);
        return this.scaleUnitVector(r, s * n);
    }
    projectBevel() {
        const t = [];
        return (this.alpha % x === 0 ? [
            this.B
        ] : [
            this.B,
            this.C
        ]).forEach((e)=>{
            t.push(this.projectOrthogonally(this.A, e)), t.push(this.projectOrthogonally(this.A, e, -this.strokeProjectionMagnitude));
        }), t;
    }
    projectMiter() {
        const t = [], e = Math.abs(this.alpha), s = 1 / Math.sin(e / 2), i = this.scaleUnitVector(this.bisector, -this.strokeProjectionMagnitude * s), r = this.options.strokeUniform ? Me(this.scaleUnitVector(this.bisector, this.options.strokeMiterLimit)) : this.options.strokeMiterLimit;
        return Me(i) / this.strokeProjectionMagnitude <= r && t.push(this.applySkew(this.A.add(i))), t.push(...this.projectBevel()), t;
    }
    projectRoundNoSkew(t, e) {
        const s = [], i = new ot(Ri.getOrthogonalRotationFactor(this.bisector), Ri.getOrthogonalRotationFactor(new ot(this.bisector.y, this.bisector.x)));
        return [
            new ot(1, 0).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar).multiply(i),
            new ot(0, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar).multiply(i)
        ].forEach((i)=>{
            Be(i, t, e) && s.push(this.A.add(i));
        }), s;
    }
    projectRoundWithSkew(t, e) {
        const s = [], { skewX: i, skewY: r, scaleX: n, scaleY: o, strokeUniform: a } = this.options, h = new ot(Math.tan(xt(i)), Math.tan(xt(r))), l = this.strokeProjectionMagnitude, c = a ? l / o / Math.sqrt(1 / o ** 2 + 1 / n ** 2 * h.y ** 2) : l / Math.sqrt(1 + h.y ** 2), u = new ot(Math.sqrt(Math.max(l ** 2 - c ** 2, 0)), c), d = a ? l / Math.sqrt(1 + h.x ** 2 * (1 / o) ** 2 / (1 / n + 1 / n * h.x * h.y) ** 2) : l / Math.sqrt(1 + h.x ** 2 / (1 + h.x * h.y) ** 2), g = new ot(d, Math.sqrt(Math.max(l ** 2 - d ** 2, 0)));
        return [
            g,
            g.scalarMultiply(-1),
            u,
            u.scalarMultiply(-1)
        ].map((t)=>this.applySkew(a ? t.multiply(this.strokeUniformScalar) : t)).forEach((i)=>{
            Be(i, t, e) && s.push(this.applySkew(this.A).add(i));
        }), s;
    }
    projectRound() {
        const t = [];
        t.push(...this.projectBevel());
        const e = this.alpha % x === 0, s = this.applySkew(this.A), i = t[e ? 0 : 2].subtract(s), r = t[e ? 1 : 0].subtract(s), n = e ? this.applySkew(this.AB.scalarMultiply(-1)) : this.applySkew(this.bisector.multiply(this.strokeUniformScalar).scalarMultiply(-1)), o = Fe(i, n) > 0, a = o ? i : r, h = o ? r : i;
        return this.isSkewed() ? t.push(...this.projectRoundWithSkew(a, h)) : t.push(...this.projectRoundNoSkew(a, h)), t;
    }
    projectPoints() {
        switch(this.options.strokeLineJoin){
            case "miter":
                return this.projectMiter();
            case "round":
                return this.projectRound();
            default:
                return this.projectBevel();
        }
    }
    project() {
        return this.projectPoints().map((t)=>({
                originPoint: this.A,
                projectedPoint: t,
                angle: this.alpha,
                bisector: this.bisector
            }));
    }
}
class Ii extends Li {
    constructor(t, e, s){
        super(s), this.A = new ot(t), this.T = new ot(e);
    }
    calcOrthogonalProjection(t, e) {
        let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.strokeProjectionMagnitude;
        const i = this.createSideVector(t, e);
        return this.scaleUnitVector(je(i), s);
    }
    projectButt() {
        return [
            this.projectOrthogonally(this.A, this.T, this.strokeProjectionMagnitude),
            this.projectOrthogonally(this.A, this.T, -this.strokeProjectionMagnitude)
        ];
    }
    projectRound() {
        const t = [];
        if (!this.isSkewed() && this.A.eq(this.T)) {
            const e = new ot(1, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar);
            t.push(this.applySkew(this.A.add(e)), this.applySkew(this.A.subtract(e)));
        } else t.push(...new Ri(this.A, this.T, this.T, this.options).projectRound());
        return t;
    }
    projectSquare() {
        const t = [];
        if (this.A.eq(this.T)) {
            const e = new ot(1, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar);
            t.push(this.A.add(e), this.A.subtract(e));
        } else {
            const e = this.calcOrthogonalProjection(this.A, this.T, this.strokeProjectionMagnitude), s = this.scaleUnitVector(Ae(this.createSideVector(this.A, this.T)), -this.strokeProjectionMagnitude), i = this.A.add(s);
            t.push(i.add(e), i.subtract(e));
        }
        return t.map((t)=>this.applySkew(t));
    }
    projectPoints() {
        switch(this.options.strokeLineCap){
            case "round":
                return this.projectRound();
            case "square":
                return this.projectSquare();
            default:
                return this.projectButt();
        }
    }
    project() {
        return this.projectPoints().map((t)=>({
                originPoint: this.A,
                projectedPoint: t
            }));
    }
}
const $i = function(t, e) {
    let s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    const i = [];
    if (0 === t.length) return i;
    const r = t.reduce((t, e)=>(t[t.length - 1].eq(e) || t.push(new ot(e)), t), [
        new ot(t[0])
    ]);
    if (1 === r.length) s = !0;
    else if (!s) {
        const t = r[0], e = ((t, e)=>{
            for(let s = t.length - 1; s >= 0; s--)if (e(t[s], s, t)) return s;
            return -1;
        })(r, (e)=>!e.eq(t));
        r.splice(e + 1);
    }
    return r.forEach((t, r, n)=>{
        let o, a;
        0 === r ? (a = n[1], o = s ? t : n[n.length - 1]) : r === n.length - 1 ? (o = n[r - 1], a = s ? t : n[0]) : (o = n[r - 1], a = n[r + 1]), s && 1 === n.length ? i.push(...new Ii(t, t, e).project()) : !s || 0 !== r && r !== n.length - 1 ? i.push(...new Ri(t, o, a, e).project()) : i.push(...new Ii(t, 0 === r ? a : o, e).project());
    }), i;
}, Xi = (t)=>{
    const e = {};
    return Object.keys(t).forEach((s)=>{
        e[s] = {}, Object.keys(t[s]).forEach((i)=>{
            e[s][i] = {
                ...t[s][i]
            };
        });
    }), e;
}, Yi = function(t, e) {
    let s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    return t.fill !== e.fill || t.stroke !== e.stroke || t.strokeWidth !== e.strokeWidth || t.fontSize !== e.fontSize || t.fontFamily !== e.fontFamily || t.fontWeight !== e.fontWeight || t.fontStyle !== e.fontStyle || t.textDecorationThickness !== e.textDecorationThickness || t.textBackgroundColor !== e.textBackgroundColor || t.deltaY !== e.deltaY || s && (t.overline !== e.overline || t.underline !== e.underline || t.linethrough !== e.linethrough);
}, Wi = (t, e)=>{
    const s = e.split("\n"), i = [];
    let r = -1, n = {};
    t = Xi(t);
    for(let e = 0; e < s.length; e++){
        const o = re(s[e]);
        if (t[e]) for(let s = 0; s < o.length; s++){
            r++;
            const o = t[e][s];
            o && Object.keys(o).length > 0 && (Yi(n, o, !0) ? i.push({
                start: r,
                end: r + 1,
                style: o
            }) : i[i.length - 1].end++), n = o || {};
        }
        else r += o.length, n = {};
    }
    return i;
}, Vi = (t, e)=>{
    if (!Array.isArray(t)) return Xi(t);
    const s = e.split(E), i = {};
    let r = -1, n = 0;
    for(let e = 0; e < s.length; e++){
        const o = re(s[e]);
        for(let s = 0; s < o.length; s++)r++, t[n] && t[n].start <= r && r < t[n].end && (i[e] = i[e] || {}, i[e][s] = {
            ...t[n].style
        }, r === t[n].end - 1 && n++);
    }
    return i;
}, zi = [
    "display",
    "transform",
    H,
    "fill-opacity",
    "fill-rule",
    "opacity",
    N,
    "stroke-dasharray",
    "stroke-linecap",
    "stroke-dashoffset",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke-width",
    "id",
    "paint-order",
    "vector-effect",
    "instantiated_by_use",
    "clip-path"
];
function Gi(t, e) {
    const s = t.nodeName, i = t.getAttribute("class"), r = t.getAttribute("id"), n = "(?![a-zA-Z\\-]+)";
    let o;
    if (o = new RegExp("^" + s, "i"), e = e.replace(o, ""), r && e.length && (o = new RegExp("#" + r + n, "i"), e = e.replace(o, "")), i && e.length) {
        const t = i.split(" ");
        for(let s = t.length; s--;)o = new RegExp("\\." + t[s] + n, "i"), e = e.replace(o, "");
    }
    return 0 === e.length;
}
function Hi(t, e) {
    let s = !0;
    const i = Gi(t, e.pop());
    return i && e.length && (s = function(t, e) {
        let s, i = !0;
        for(; t.parentElement && 1 === t.parentElement.nodeType && e.length;)i && (s = e.pop()), i = Gi(t = t.parentElement, s);
        return 0 === e.length;
    }(t, e)), i && s && 0 === e.length;
}
function Ni(t) {
    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = {};
    for(const i in e)Hi(t, i.split(" ")) && (s = {
        ...s,
        ...e[i]
    });
    return s;
}
const Ui = (t)=>{
    var e;
    return null !== (e = ys[t]) && void 0 !== e ? e : t;
}, qi = new RegExp(`(${fs})`, "gi"), Ki = `(${fs})`, Ji = String.raw`(skewX)\(${Ki}\)`, Qi = String.raw`(skewY)\(${Ki}\)`, Zi = String.raw`(rotate)\(${Ki}(?: ${Ki} ${Ki})?\)`, tr = String.raw`(scale)\(${Ki}(?: ${Ki})?\)`, er = String.raw`(translate)\(${Ki}(?: ${Ki})?\)`, sr = `(?:${String.raw`(matrix)\(${Ki} ${Ki} ${Ki} ${Ki} ${Ki} ${Ki}\)`}|${er}|${Zi}|${tr}|${Ji}|${Qi})`, ir = `(?:${sr}*)`, rr = String.raw`^\s*(?:${ir}?)\s*$`, nr = new RegExp(rr), or = new RegExp(sr), ar = new RegExp(sr, "g");
function hr(t) {
    const e = [];
    if (!(t = ((t)=>ze(t.replace(qi, " $1 ").replace(/,/gi, " ")))(t).replace(/\s*([()])\s*/gi, "$1")) || t && !nr.test(t)) return [
        ...b
    ];
    for (const s of t.matchAll(ar)){
        const t = or.exec(s[0]);
        if (!t) continue;
        let i = b;
        const r = t.filter((t)=>!!t), [, n, ...o] = r, [a, h, l, c, u, d] = o.map((t)=>parseFloat(t));
        switch(n){
            case "translate":
                i = Mt(a, h);
                break;
            case L:
                i = Pt({
                    angle: a
                }, {
                    x: h,
                    y: l
                });
                break;
            case Y:
                i = Et(a, h);
                break;
            case z:
                i = jt(a);
                break;
            case G:
                i = Ft(a);
                break;
            case "matrix":
                i = [
                    a,
                    h,
                    l,
                    c,
                    u,
                    d
                ];
        }
        e.push(i);
    }
    return Ot(e);
}
function lr(t, e, s, i) {
    const r = Array.isArray(e);
    let n, o = e;
    if (t !== H && t !== N || e !== P) {
        if ("strokeUniform" === t) return "non-scaling-stroke" === e;
        if ("strokeDashArray" === t) o = e === P ? null : e.replace(/,/g, " ").split(/\s+/).map(parseFloat);
        else if ("transformMatrix" === t) o = s && s.transformMatrix ? Tt(s.transformMatrix, hr(e)) : hr(e);
        else if ("visible" === t) o = e !== P && "hidden" !== e, s && !1 === s.visible && (o = !1);
        else if ("opacity" === t) o = parseFloat(e), s && void 0 !== s.opacity && (o *= s.opacity);
        else if ("textAnchor" === t) o = "start" === e ? O : "end" === e ? M : T;
        else if ("charSpacing" === t || t === is) n = Qe(e, i) / i * 1e3;
        else if ("paintFirst" === t) {
            const t = e.indexOf(H), s = e.indexOf(N);
            o = H, (t > -1 && s > -1 && s < t || -1 === t && s > -1) && (o = N);
        } else {
            if ("href" === t || "xlink:href" === t || "font" === t || "id" === t) return e;
            if ("imageSmoothing" === t) return "optimizeQuality" === e;
            n = r ? e.map(Qe) : Qe(e, i);
        }
    } else o = "";
    return !r && isNaN(n) ? o : n;
}
function cr(t, e) {
    t.replace(/;\s*$/, "").split(";").forEach((t)=>{
        if (!t) return;
        const [s, i] = t.split(":");
        e[s.trim().toLowerCase()] = i.trim();
    });
}
function ur(t) {
    const e = {}, s = t.getAttribute("style");
    return s ? ("string" == typeof s ? cr(s, e) : function(t, e) {
        Object.entries(t).forEach((t)=>{
            let [s, i] = t;
            void 0 !== i && (e[s.toLowerCase()] = i);
        });
    }(s, e), e) : e;
}
const dr = {
    stroke: "strokeOpacity",
    fill: "fillOpacity"
};
function gr(t, e, s) {
    if (!t) return {};
    let i, r = {}, n = S;
    t.parentNode && Ss.test(t.parentNode.nodeName) && (r = gr(t.parentElement, e, s), r.fontSize && (i = n = Qe(r.fontSize)));
    const o = {
        ...e.reduce((e, s)=>{
            const i = t.getAttribute(s);
            return i && (e[s] = i), e;
        }, {}),
        ...Ni(t, s),
        ...ur(t)
    };
    o[xs] && t.setAttribute(xs, o[xs]), o[_s] && (i = Qe(o[_s], n), o[_s] = `${i}`);
    const a = {};
    for(const t in o){
        const e = Ui(t), s = lr(e, o[t], r, i);
        a[e] = s;
    }
    a && a.font && function(t, e) {
        const s = t.match(vs);
        if (!s) return;
        const i = s[1], r = s[3], n = s[4], o = s[5], a = s[6];
        i && (e.fontStyle = i), r && (e.fontWeight = isNaN(parseFloat(r)) ? r : parseFloat(r)), n && (e.fontSize = Qe(n)), a && (e.fontFamily = a), o && (e.lineHeight = o === J ? 1 : o);
    }(a.font, a);
    const h = {
        ...r,
        ...a
    };
    return Ss.test(t.nodeName) ? h : function(t) {
        const e = ji.getDefaults();
        return Object.entries(dr).forEach((s)=>{
            let [i, r] = s;
            if (void 0 === t[r] || "" === t[i]) return;
            if (void 0 === t[i]) {
                if (!e[i]) return;
                t[i] = e[i];
            }
            if (0 === t[i].indexOf("url(")) return;
            const n = new Je(t[i]);
            t[i] = n.setAlpha(Wt(n.getAlpha() * t[r], 2)).toRgba();
        }), t;
    }(h);
}
const fr = [
    "rx",
    "ry"
];
class pr extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...pr.ownDefaults
        };
    }
    constructor(t){
        super(), Object.assign(this, pr.ownDefaults), this.setOptions(t), this._initRxRy();
    }
    _initRxRy() {
        const { rx: t, ry: e } = this;
        t && !e ? this.ry = t : e && !t && (this.rx = e);
    }
    _render(t) {
        const { width: e, height: s } = this, i = -e / 2, r = -s / 2, n = this.rx ? Math.min(this.rx, e / 2) : 0, o = this.ry ? Math.min(this.ry, s / 2) : 0, a = 0 !== n || 0 !== o;
        t.beginPath(), t.moveTo(i + n, r), t.lineTo(i + e - n, r), a && t.bezierCurveTo(i + e - w * n, r, i + e, r + w * o, i + e, r + o), t.lineTo(i + e, r + s - o), a && t.bezierCurveTo(i + e, r + s - w * o, i + e - w * n, r + s, i + e - n, r + s), t.lineTo(i + n, r + s), a && t.bezierCurveTo(i + w * n, r + s, i, r + s - w * o, i, r + s - o), t.lineTo(i, r + o), a && t.bezierCurveTo(i, r + w * o, i + w * n, r, i + n, r), t.closePath(), this._renderPaintInOrder(t);
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return super.toObject([
            ...fr,
            ...t
        ]);
    }
    _toSVG() {
        const { width: t, height: e, rx: s, ry: i } = this;
        return [
            "<rect ",
            "COMMON_PARTS",
            `x="${-t / 2}" y="${-e / 2}" rx="${se(s)}" ry="${se(i)}" width="${se(t)}" height="${se(e)}" />\n`
        ];
    }
    static async fromElement(t, e, s) {
        const { left: i = 0, top: r = 0, width: n = 0, height: o = 0, visible: a = !0, ...h } = gr(t, this.ATTRIBUTE_NAMES, s);
        return new this({
            ...e,
            ...h,
            left: i,
            top: r,
            width: n,
            height: o,
            visible: Boolean(a && n && o)
        });
    }
}
t(pr, "type", "Rect"), t(pr, "cacheProperties", [
    ...Ps,
    ...fr
]), t(pr, "ownDefaults", {
    rx: 0,
    ry: 0
}), t(pr, "ATTRIBUTE_NAMES", [
    ...zi,
    "x",
    "y",
    "rx",
    "ry",
    "width",
    "height"
]), tt.setClass(pr), tt.setSVGClass(pr);
const mr = "initialization", vr = "added", yr = "removed", _r = "imperative", xr = (t, e)=>{
    const { strokeUniform: s, strokeWidth: i, width: r, height: n, group: o } = e, a = o && o !== t ? _e(o.calcTransformMatrix(), t.calcTransformMatrix()) : null, h = a ? e.getRelativeCenterPoint().transform(a) : e.getRelativeCenterPoint(), l = !e.isStrokeAccountedForInDimensions(), c = s && l ? Ce(new ot(i, i), void 0, t.calcTransformMatrix()) : at, u = !s && l ? i : 0, d = ye(r + u, n + u, Ot([
        a,
        e.calcOwnMatrix()
    ], !0)).add(c).scalarDivide(2);
    return [
        h.subtract(d),
        h.add(d)
    ];
};
class Cr {
    calcLayoutResult(t, e) {
        if (this.shouldPerformLayout(t)) return this.calcBoundingBox(e, t);
    }
    shouldPerformLayout(t) {
        let { type: e, prevStrategy: s, strategy: i } = t;
        return e === mr || e === _r || !!s && i !== s;
    }
    shouldLayoutClipPath(t) {
        let { type: e, target: { clipPath: s } } = t;
        return e !== mr && s && !s.absolutePositioned;
    }
    getInitialSize(t, e) {
        return e.size;
    }
    calcBoundingBox(t, e) {
        const { type: s, target: i } = e;
        if (s === _r && e.overrides) return e.overrides;
        if (0 === t.length) return;
        const { left: r, top: n, width: o, height: a } = ge(t.map((t)=>xr(i, t)).reduce((t, e)=>t.concat(e), [])), h = new ot(o, a), l = new ot(r, n).add(h.scalarDivide(2));
        if (s === mr) {
            const t = this.getInitialSize(e, {
                size: h,
                center: l
            });
            return {
                center: l,
                relativeCorrection: new ot(0, 0),
                size: t
            };
        }
        return {
            center: l.transform(i.calcOwnMatrix()),
            size: h
        };
    }
}
t(Cr, "type", "strategy");
class br extends Cr {
    shouldPerformLayout(t) {
        return !0;
    }
}
t(br, "type", "fit-content"), tt.setClass(br);
const Sr = "layoutManager";
class wr {
    constructor(){
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new br;
        t(this, "strategy", void 0), this.strategy = e, this._subscriptions = new Map;
    }
    performLayout(t) {
        const e = {
            bubbles: !0,
            strategy: this.strategy,
            ...t,
            prevStrategy: this._prevLayoutStrategy,
            stopPropagation () {
                this.bubbles = !1;
            }
        };
        this.onBeforeLayout(e);
        const s = this.getLayoutResult(e);
        s && this.commitLayout(e, s), this.onAfterLayout(e, s), this._prevLayoutStrategy = e.strategy;
    }
    attachHandlers(t, e) {
        const { target: s } = e;
        return [
            U,
            A,
            R,
            F,
            j,
            B,
            X,
            I,
            $
        ].map((e)=>t.on(e, (t)=>this.performLayout(e === U ? {
                    type: "object_modified",
                    trigger: e,
                    e: t,
                    target: s
                } : {
                    type: "object_modifying",
                    trigger: e,
                    e: t,
                    target: s
                })));
    }
    subscribe(t, e) {
        this.unsubscribe(t, e);
        const s = this.attachHandlers(t, e);
        this._subscriptions.set(t, s);
    }
    unsubscribe(t, e) {
        (this._subscriptions.get(t) || []).forEach((t)=>t()), this._subscriptions.delete(t);
    }
    unsubscribeTargets(t) {
        t.targets.forEach((e)=>this.unsubscribe(e, t));
    }
    subscribeTargets(t) {
        t.targets.forEach((e)=>this.subscribe(e, t));
    }
    onBeforeLayout(t) {
        const { target: e, type: s } = t, { canvas: i } = e;
        if (s === mr || s === vr ? this.subscribeTargets(t) : s === yr && this.unsubscribeTargets(t), e.fire("layout:before", {
            context: t
        }), i && i.fire("object:layout:before", {
            target: e,
            context: t
        }), s === _r && t.deep) {
            const { strategy: s, ...i } = t;
            e.forEachObject((t)=>t.layoutManager && t.layoutManager.performLayout({
                    ...i,
                    bubbles: !1,
                    target: t
                }));
        }
    }
    getLayoutResult(t) {
        const { target: e, strategy: s, type: i } = t, r = s.calcLayoutResult(t, e.getObjects());
        if (!r) return;
        const n = i === mr ? new ot : e.getRelativeCenterPoint(), { center: o, correction: a = new ot, relativeCorrection: h = new ot } = r, l = n.subtract(o).add(a).transform(i === mr ? b : wt(e.calcOwnMatrix()), !0).add(h);
        return {
            result: r,
            prevCenter: n,
            nextCenter: o,
            offset: l
        };
    }
    commitLayout(t, e) {
        const { target: s } = t, { result: { size: i }, nextCenter: r } = e;
        var n, o;
        (s.set({
            width: i.x,
            height: i.y
        }), this.layoutObjects(t, e), t.type === mr) ? s.set({
            left: null !== (n = t.x) && void 0 !== n ? n : r.x + i.x * we(s.originX),
            top: null !== (o = t.y) && void 0 !== o ? o : r.y + i.y * we(s.originY)
        }) : (s.setPositionByOrigin(r, T, T), s.setCoords(), s.set("dirty", !0));
    }
    layoutObjects(t, e) {
        const { target: s } = t;
        s.forEachObject((i)=>{
            i.group === s && this.layoutObject(t, e, i);
        }), t.strategy.shouldLayoutClipPath(t) && this.layoutObject(t, e, s.clipPath);
    }
    layoutObject(t, e, s) {
        let { offset: i } = e;
        s.set({
            left: s.left + i.x,
            top: s.top + i.y
        });
    }
    onAfterLayout(t, e) {
        const { target: s, strategy: i, bubbles: r, prevStrategy: n, ...o } = t, { canvas: a } = s;
        s.fire("layout:after", {
            context: t,
            result: e
        }), a && a.fire("object:layout:after", {
            context: t,
            result: e,
            target: s
        });
        const h = s.parent;
        r && null != h && h.layoutManager && ((o.path || (o.path = [])).push(s), h.layoutManager.performLayout({
            ...o,
            target: h
        })), s.set("dirty", !0);
    }
    dispose() {
        const { _subscriptions: t } = this;
        t.forEach((t)=>t.forEach((t)=>t())), t.clear();
    }
    toObject() {
        return {
            type: Sr,
            strategy: this.strategy.constructor.type
        };
    }
    toJSON() {
        return this.toObject();
    }
}
tt.setClass(wr, Sr);
class Tr extends wr {
    performLayout() {}
}
class Or extends lt(ji) {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...Or.ownDefaults
        };
    }
    constructor(){
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), t(this, "_activeObjects", []), t(this, "__objectSelectionTracker", void 0), t(this, "__objectSelectionDisposer", void 0), Object.assign(this, Or.ownDefaults), this.setOptions(s), this.groupInit(e, s);
    }
    groupInit(t, e) {
        var s;
        this._objects = [
            ...t
        ], this.__objectSelectionTracker = this.__objectSelectionMonitor.bind(this, !0), this.__objectSelectionDisposer = this.__objectSelectionMonitor.bind(this, !1), this.forEachObject((t)=>{
            this.enterGroup(t, !1);
        }), this.layoutManager = null !== (s = e.layoutManager) && void 0 !== s ? s : new wr, this.layoutManager.performLayout({
            type: mr,
            target: this,
            targets: [
                ...t
            ],
            x: e.left,
            y: e.top
        });
    }
    canEnterGroup(t) {
        return t === this || this.isDescendantOf(t) ? (i("error", "Group: circular object trees are not supported, this call has no effect"), !1) : -1 === this._objects.indexOf(t) || (i("error", "Group: duplicate objects are not supported inside group, this call has no effect"), !1);
    }
    _filterObjectsBeforeEnteringGroup(t) {
        return t.filter((t, e, s)=>this.canEnterGroup(t) && s.indexOf(t) === e);
    }
    add() {
        for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
        const i = this._filterObjectsBeforeEnteringGroup(e), r = super.add(...i);
        return this._onAfterObjectsChange(vr, i), r;
    }
    insertAt(t) {
        for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
        const r = this._filterObjectsBeforeEnteringGroup(s), n = super.insertAt(t, ...r);
        return this._onAfterObjectsChange(vr, r), n;
    }
    remove() {
        const t = super.remove(...arguments);
        return this._onAfterObjectsChange(yr, t), t;
    }
    _onObjectAdded(t) {
        this.enterGroup(t, !0), this.fire("object:added", {
            target: t
        }), t.fire("added", {
            target: this
        });
    }
    _onObjectRemoved(t, e) {
        this.exitGroup(t, e), this.fire("object:removed", {
            target: t
        }), t.fire("removed", {
            target: this
        });
    }
    _onAfterObjectsChange(t, e) {
        this.layoutManager.performLayout({
            type: t,
            targets: e,
            target: this
        });
    }
    _onStackOrderChanged() {
        this._set("dirty", !0);
    }
    _set(t, e) {
        const s = this[t];
        return super._set(t, e), "canvas" === t && s !== e && (this._objects || []).forEach((s)=>{
            s._set(t, e);
        }), this;
    }
    _shouldSetNestedCoords() {
        return this.subTargetCheck;
    }
    removeAll() {
        return this._activeObjects = [], this.remove(...this._objects);
    }
    __objectSelectionMonitor(t, e) {
        let { target: s } = e;
        const i = this._activeObjects;
        if (t) i.push(s), this._set("dirty", !0);
        else if (i.length > 0) {
            const t = i.indexOf(s);
            t > -1 && (i.splice(t, 1), this._set("dirty", !0));
        }
    }
    _watchObject(t, e) {
        t && this._watchObject(!1, e), t ? (e.on("selected", this.__objectSelectionTracker), e.on("deselected", this.__objectSelectionDisposer)) : (e.off("selected", this.__objectSelectionTracker), e.off("deselected", this.__objectSelectionDisposer));
    }
    enterGroup(t, e) {
        t.group && t.group.remove(t), t._set("parent", this), this._enterGroup(t, e);
    }
    _enterGroup(t, e) {
        e && pe(t, Tt(wt(this.calcTransformMatrix()), t.calcTransformMatrix())), this._shouldSetNestedCoords() && t.setCoords(), t._set("group", this), t._set("canvas", this.canvas), this._watchObject(!0, t);
        const s = this.canvas && this.canvas.getActiveObject && this.canvas.getActiveObject();
        s && (s === t || t.isDescendantOf(s)) && this._activeObjects.push(t);
    }
    exitGroup(t, e) {
        this._exitGroup(t, e), t._set("parent", void 0), t._set("canvas", void 0);
    }
    _exitGroup(t, e) {
        t._set("group", void 0), e || (pe(t, Tt(this.calcTransformMatrix(), t.calcTransformMatrix())), t.setCoords()), this._watchObject(!1, t);
        const s = this._activeObjects.length > 0 ? this._activeObjects.indexOf(t) : -1;
        s > -1 && this._activeObjects.splice(s, 1);
    }
    shouldCache() {
        const t = ji.prototype.shouldCache.call(this);
        if (t) {
            for(let t = 0; t < this._objects.length; t++)if (this._objects[t].willDrawShadow()) return this.ownCaching = !1, !1;
        }
        return t;
    }
    willDrawShadow() {
        if (super.willDrawShadow()) return !0;
        for(let t = 0; t < this._objects.length; t++)if (this._objects[t].willDrawShadow()) return !0;
        return !1;
    }
    isOnACache() {
        return this.ownCaching || !!this.parent && this.parent.isOnACache();
    }
    drawObject(t, e, s) {
        this._renderBackground(t);
        for(let e = 0; e < this._objects.length; e++){
            var i;
            const s = this._objects[e];
            null !== (i = this.canvas) && void 0 !== i && i.preserveObjectStacking && s.group !== this ? (t.save(), t.transform(...wt(this.calcTransformMatrix())), s.render(t), t.restore()) : s.group === this && s.render(t);
        }
        this._drawClipPath(t, this.clipPath, s);
    }
    setCoords() {
        super.setCoords(), this._shouldSetNestedCoords() && this.forEachObject((t)=>t.setCoords());
    }
    triggerLayout() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.layoutManager.performLayout({
            target: this,
            type: _r,
            ...t
        });
    }
    render(t) {
        this._transformDone = !0, super.render(t), this._transformDone = !1;
    }
    __serializeObjects(t, e) {
        const s = this.includeDefaultValues;
        return this._objects.filter(function(t) {
            return !t.excludeFromExport;
        }).map(function(i) {
            const r = i.includeDefaultValues;
            i.includeDefaultValues = s;
            const n = i[t || "toObject"](e);
            return i.includeDefaultValues = r, n;
        });
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        const e = this.layoutManager.toObject();
        return {
            ...super.toObject([
                "subTargetCheck",
                "interactive",
                ...t
            ]),
            ..."fit-content" !== e.strategy || this.includeDefaultValues ? {
                layoutManager: e
            } : {},
            objects: this.__serializeObjects("toObject", t)
        };
    }
    toString() {
        return `#<Group: (${this.complexity()})>`;
    }
    dispose() {
        this.layoutManager.unsubscribeTargets({
            targets: this.getObjects(),
            target: this
        }), this._activeObjects = [], this.forEachObject((t)=>{
            this._watchObject(!1, t), t.dispose();
        }), super.dispose();
    }
    _createSVGBgRect(t) {
        if (!this.backgroundColor) return "";
        const e = pr.prototype._toSVG.call(this), s = e.indexOf("COMMON_PARTS");
        e[s] = 'for="group" ';
        const i = e.join("");
        return t ? t(i) : i;
    }
    _toSVG(t) {
        const e = [
            "<g ",
            "COMMON_PARTS",
            " >\n"
        ], s = this._createSVGBgRect(t);
        s && e.push("\t\t", s);
        for(let s = 0; s < this._objects.length; s++)e.push("\t\t", this._objects[s].toSVG(t));
        return e.push("</g>\n"), e;
    }
    getSvgStyles() {
        const t = void 0 !== this.opacity && 1 !== this.opacity ? `opacity: ${se(this.opacity)};` : "", e = this.visible ? "" : " visibility: hidden;";
        return [
            t,
            this.getSvgFilter(),
            e
        ].join("");
    }
    toClipPathSVG(t) {
        const e = [], s = this._createSVGBgRect(t);
        s && e.push("\t", s);
        for(let s = 0; s < this._objects.length; s++)e.push("\t", this._objects[s].toClipPathSVG(t));
        return this._createBaseClipPathSVGMarkup(e, {
            reviver: t
        });
    }
    static fromObject(t, e) {
        let { type: s, objects: i = [], layoutManager: r, ...n } = t;
        return Promise.all([
            It(i, e),
            $t(n, e)
        ]).then((t)=>{
            let [e, s] = t;
            const i = new this(e, {
                ...n,
                ...s,
                layoutManager: new Tr
            });
            if (r) {
                const t = tt.getClass(r.type), e = tt.getClass(r.strategy);
                i.layoutManager = new t(new e);
            } else i.layoutManager = new wr;
            return i.layoutManager.subscribeTargets({
                type: mr,
                target: i,
                targets: i.getObjects()
            }), i.setCoords(), i;
        });
    }
}
t(Or, "type", "Group"), t(Or, "ownDefaults", {
    strokeWidth: 0,
    subTargetCheck: !1,
    interactive: !1
}), tt.setClass(Or);
const kr = (t, e)=>Math.min(e.width / t.width, e.height / t.height), Dr = (t, e)=>Math.max(e.width / t.width, e.height / t.height), Mr = "\\s*,?\\s*", Pr = `${Mr}(${fs})`, Er = `${Pr}${Pr}${Pr}${Mr}([01])${Mr}([01])${Pr}${Pr}`, Ar = {
    m: "l",
    M: "L"
}, jr = (t, e, s, i, r, n, o, a, h, l, c)=>{
    const u = rt(t), d = nt(t), g = rt(e), f = nt(e), p = s * r * g - i * n * f + o, m = i * r * g + s * n * f + a;
    return [
        "C",
        l + h * (-s * r * d - i * n * u),
        c + h * (-i * r * d + s * n * u),
        p + h * (s * r * f + i * n * g),
        m + h * (i * r * f - s * n * g),
        p,
        m
    ];
}, Fr = (t, e, s, i)=>{
    const r = Math.atan2(e, t), n = Math.atan2(i, s);
    return n >= r ? n - r : 2 * Math.PI - (r - n);
};
function Lr(t, e, i, r, n, o, a, h) {
    let l;
    if (s.cachesBoundsOfCurve && (l = [
        ...arguments
    ].join(), p.boundsOfCurveCache[l])) return p.boundsOfCurveCache[l];
    const c = Math.sqrt, u = Math.abs, d = [], g = [
        [
            0,
            0
        ],
        [
            0,
            0
        ]
    ];
    let f = 6 * t - 12 * i + 6 * n, m = -3 * t + 9 * i - 9 * n + 3 * a, v = 3 * i - 3 * t;
    for(let t = 0; t < 2; ++t){
        if (t > 0 && (f = 6 * e - 12 * r + 6 * o, m = -3 * e + 9 * r - 9 * o + 3 * h, v = 3 * r - 3 * e), u(m) < 1e-12) {
            if (u(f) < 1e-12) continue;
            const t = -v / f;
            0 < t && t < 1 && d.push(t);
            continue;
        }
        const s = f * f - 4 * v * m;
        if (s < 0) continue;
        const i = c(s), n = (-f + i) / (2 * m);
        0 < n && n < 1 && d.push(n);
        const a = (-f - i) / (2 * m);
        0 < a && a < 1 && d.push(a);
    }
    let y = d.length;
    const _ = y, x = $r(t, e, i, r, n, o, a, h);
    for(; y--;){
        const { x: t, y: e } = x(d[y]);
        g[0][y] = t, g[1][y] = e;
    }
    g[0][_] = t, g[1][_] = e, g[0][_ + 1] = a, g[1][_ + 1] = h;
    const C = [
        new ot(Math.min(...g[0]), Math.min(...g[1])),
        new ot(Math.max(...g[0]), Math.max(...g[1]))
    ];
    return s.cachesBoundsOfCurve && (p.boundsOfCurveCache[l] = C), C;
}
const Br = (t, e, s)=>{
    let [i, r, n, o, a, h, l, c] = s;
    const u = ((t, e, s, i, r, n, o)=>{
        if (0 === s || 0 === i) return [];
        let a = 0, h = 0, l = 0;
        const c = Math.PI, u = o * C, d = nt(u), g = rt(u), f = .5 * (-g * t - d * e), p = .5 * (-g * e + d * t), m = s ** 2, v = i ** 2, y = p ** 2, _ = f ** 2, x = m * v - m * y - v * _;
        let b = Math.abs(s), S = Math.abs(i);
        if (x < 0) {
            const t = Math.sqrt(1 - x / (m * v));
            b *= t, S *= t;
        } else l = (r === n ? -1 : 1) * Math.sqrt(x / (m * y + v * _));
        const w = l * b * p / S, T = -l * S * f / b, O = g * w - d * T + .5 * t, k = d * w + g * T + .5 * e;
        let D = Fr(1, 0, (f - w) / b, (p - T) / S), M = Fr((f - w) / b, (p - T) / S, (-f - w) / b, (-p - T) / S);
        0 === n && M > 0 ? M -= 2 * c : 1 === n && M < 0 && (M += 2 * c);
        const P = Math.ceil(Math.abs(M / c * 2)), E = [], A = M / P, j = 8 / 3 * Math.sin(A / 4) * Math.sin(A / 4) / Math.sin(A / 2);
        let F = D + A;
        for(let t = 0; t < P; t++)E[t] = jr(D, F, g, d, b, S, O, k, j, a, h), a = E[t][5], h = E[t][6], D = F, F += A;
        return E;
    })(l - t, c - e, r, n, a, h, o);
    for(let s = 0, i = u.length; s < i; s++)u[s][1] += t, u[s][2] += e, u[s][3] += t, u[s][4] += e, u[s][5] += t, u[s][6] += e;
    return u;
}, Rr = (t)=>{
    let e = 0, s = 0, i = 0, r = 0;
    const n = [];
    let o, a = 0, h = 0;
    for (const l of t){
        const t = [
            ...l
        ];
        let c;
        switch(t[0]){
            case "l":
                t[1] += e, t[2] += s;
            case "L":
                e = t[1], s = t[2], c = [
                    "L",
                    e,
                    s
                ];
                break;
            case "h":
                t[1] += e;
            case "H":
                e = t[1], c = [
                    "L",
                    e,
                    s
                ];
                break;
            case "v":
                t[1] += s;
            case "V":
                s = t[1], c = [
                    "L",
                    e,
                    s
                ];
                break;
            case "m":
                t[1] += e, t[2] += s;
            case "M":
                e = t[1], s = t[2], i = t[1], r = t[2], c = [
                    "M",
                    e,
                    s
                ];
                break;
            case "c":
                t[1] += e, t[2] += s, t[3] += e, t[4] += s, t[5] += e, t[6] += s;
            case "C":
                a = t[3], h = t[4], e = t[5], s = t[6], c = [
                    "C",
                    t[1],
                    t[2],
                    a,
                    h,
                    e,
                    s
                ];
                break;
            case "s":
                t[1] += e, t[2] += s, t[3] += e, t[4] += s;
            case "S":
                "C" === o ? (a = 2 * e - a, h = 2 * s - h) : (a = e, h = s), e = t[3], s = t[4], c = [
                    "C",
                    a,
                    h,
                    t[1],
                    t[2],
                    e,
                    s
                ], a = c[3], h = c[4];
                break;
            case "q":
                t[1] += e, t[2] += s, t[3] += e, t[4] += s;
            case "Q":
                a = t[1], h = t[2], e = t[3], s = t[4], c = [
                    "Q",
                    a,
                    h,
                    e,
                    s
                ];
                break;
            case "t":
                t[1] += e, t[2] += s;
            case "T":
                "Q" === o ? (a = 2 * e - a, h = 2 * s - h) : (a = e, h = s), e = t[1], s = t[2], c = [
                    "Q",
                    a,
                    h,
                    e,
                    s
                ];
                break;
            case "a":
                t[6] += e, t[7] += s;
            case "A":
                Br(e, s, t).forEach((t)=>n.push(t)), e = t[6], s = t[7];
                break;
            case "z":
            case "Z":
                e = i, s = r, c = [
                    "Z"
                ];
        }
        c ? (n.push(c), o = c[0]) : o = "";
    }
    return n;
}, Ir = (t, e, s, i)=>Math.sqrt((s - t) ** 2 + (i - e) ** 2), $r = (t, e, s, i, r, n, o, a)=>(h)=>{
        const l = h ** 3, c = ((t)=>3 * t ** 2 * (1 - t))(h), u = ((t)=>3 * t * (1 - t) ** 2)(h), d = ((t)=>(1 - t) ** 3)(h);
        return new ot(o * l + r * c + s * u + t * d, a * l + n * c + i * u + e * d);
    }, Xr = (t)=>t ** 2, Yr = (t)=>2 * t * (1 - t), Wr = (t)=>(1 - t) ** 2, Vr = (t, e, s, i, r, n, o, a)=>(h)=>{
        const l = Xr(h), c = Yr(h), u = Wr(h), d = 3 * (u * (s - t) + c * (r - s) + l * (o - r)), g = 3 * (u * (i - e) + c * (n - i) + l * (a - n));
        return Math.atan2(g, d);
    }, zr = (t, e, s, i, r, n)=>(o)=>{
        const a = Xr(o), h = Yr(o), l = Wr(o);
        return new ot(r * a + s * h + t * l, n * a + i * h + e * l);
    }, Gr = (t, e, s, i, r, n)=>(o)=>{
        const a = 1 - o, h = 2 * (a * (s - t) + o * (r - s)), l = 2 * (a * (i - e) + o * (n - i));
        return Math.atan2(l, h);
    }, Hr = (t, e, s)=>{
    let i = new ot(e, s), r = 0;
    for(let e = 1; e <= 100; e += 1){
        const s = t(e / 100);
        r += Ir(i.x, i.y, s.x, s.y), i = s;
    }
    return r;
}, Nr = (t, e)=>{
    let s, i = 0, r = 0, n = {
        x: t.x,
        y: t.y
    }, o = {
        ...n
    }, a = .01, h = 0;
    const l = t.iterator, c = t.angleFinder;
    for(; r < e && a > 1e-4;)o = l(i), h = i, s = Ir(n.x, n.y, o.x, o.y), s + r > e ? (i -= a, a /= 2) : (n = o, i += a, r += s);
    return {
        ...o,
        angle: c(h)
    };
}, Ur = (t)=>{
    let e, s, i = 0, r = 0, n = 0, o = 0, a = 0;
    const h = [];
    for (const l of t){
        const t = {
            x: r,
            y: n,
            command: l[0],
            length: 0
        };
        switch(l[0]){
            case "M":
                s = t, s.x = o = r = l[1], s.y = a = n = l[2];
                break;
            case "L":
                s = t, s.length = Ir(r, n, l[1], l[2]), r = l[1], n = l[2];
                break;
            case "C":
                e = $r(r, n, l[1], l[2], l[3], l[4], l[5], l[6]), s = t, s.iterator = e, s.angleFinder = Vr(r, n, l[1], l[2], l[3], l[4], l[5], l[6]), s.length = Hr(e, r, n), r = l[5], n = l[6];
                break;
            case "Q":
                e = zr(r, n, l[1], l[2], l[3], l[4]), s = t, s.iterator = e, s.angleFinder = Gr(r, n, l[1], l[2], l[3], l[4]), s.length = Hr(e, r, n), r = l[3], n = l[4];
                break;
            case "Z":
                s = t, s.destX = o, s.destY = a, s.length = Ir(r, n, o, a), r = o, n = a;
        }
        i += s.length, h.push(s);
    }
    return h.push({
        length: i,
        x: r,
        y: n
    }), h;
}, qr = function(t, e) {
    let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Ur(t), i = 0;
    for(; e - s[i].length > 0 && i < s.length - 2;)e -= s[i].length, i++;
    const r = s[i], n = e / r.length, o = t[i];
    switch(r.command){
        case "M":
            return {
                x: r.x,
                y: r.y,
                angle: 0
            };
        case "Z":
            return {
                ...new ot(r.x, r.y).lerp(new ot(r.destX, r.destY), n),
                angle: Math.atan2(r.destY - r.y, r.destX - r.x)
            };
        case "L":
            return {
                ...new ot(r.x, r.y).lerp(new ot(o[1], o[2]), n),
                angle: Math.atan2(o[2] - r.y, o[1] - r.x)
            };
        case "C":
        case "Q":
            return Nr(r, e);
    }
}, Kr = new RegExp("[mzlhvcsqta][^mzlhvcsqta]*", "gi"), Jr = new RegExp(Er, "g"), Qr = new RegExp(fs, "gi"), Zr = {
    m: 2,
    l: 2,
    h: 1,
    v: 1,
    c: 6,
    s: 4,
    q: 4,
    t: 2,
    a: 7
}, tn = (t)=>{
    var e;
    const s = [], i = null !== (e = t.match(Kr)) && void 0 !== e ? e : [];
    for (const t of i){
        const e = t[0];
        if ("z" === e || "Z" === e) {
            s.push([
                e
            ]);
            continue;
        }
        const i = Zr[e.toLowerCase()];
        let r = [];
        if ("a" === e || "A" === e) {
            Jr.lastIndex = 0;
            for(let e = null; e = Jr.exec(t);)r.push(...e.slice(1));
        } else r = t.match(Qr) || [];
        for(let t = 0; t < r.length; t += i){
            const n = new Array(i), o = Ar[e];
            n[0] = t > 0 && o ? o : e;
            for(let e = 0; e < i; e++)n[e + 1] = parseFloat(r[t + e]);
            s.push(n);
        }
    }
    return s;
}, en = function(t) {
    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, s = new ot(t[0]), i = new ot(t[1]), r = 1, n = 0;
    const o = [], a = t.length, h = a > 2;
    let l;
    for(h && (r = t[2].x < i.x ? -1 : t[2].x === i.x ? 0 : 1, n = t[2].y < i.y ? -1 : t[2].y === i.y ? 0 : 1), o.push([
        "M",
        s.x - r * e,
        s.y - n * e
    ]), l = 1; l < a; l++){
        if (!s.eq(i)) {
            const t = s.midPointFrom(i);
            o.push([
                "Q",
                s.x,
                s.y,
                t.x,
                t.y
            ]);
        }
        s = t[l], l + 1 < t.length && (i = t[l + 1]);
    }
    return h && (r = s.x > t[l - 2].x ? 1 : s.x === t[l - 2].x ? 0 : -1, n = s.y > t[l - 2].y ? 1 : s.y === t[l - 2].y ? 0 : -1), o.push([
        "L",
        s.x + r * e,
        s.y + n * e
    ]), o;
}, sn = (t, e)=>t.map((t)=>t.map((t, s)=>0 === s || void 0 === e ? t : Wt(t, e)).join(" ")).join(" "), rn = (t, e)=>Math.floor(Math.random() * (e - t + 1)) + t, nn = (t, e)=>{
    let s = t._findCenterFromElement();
    t.transformMatrix && (((t)=>{
        if (t.transformMatrix) {
            const { scaleX: e, scaleY: s, angle: i, skewX: r } = Dt(t.transformMatrix);
            t.flipX = !1, t.flipY = !1, t.set(W, e), t.set(V, s), t.angle = i, t.skewX = r, t.skewY = 0;
        }
    })(t), s = s.transform(t.transformMatrix)), delete t.transformMatrix, e && (t.scaleX *= e.scaleX, t.scaleY *= e.scaleY, t.cropX = e.cropX, t.cropY = e.cropY, s.x += e.offsetLeft, s.y += e.offsetTop, t.width = e.width, t.height = e.height), t.setPositionByOrigin(s, T, T);
};
var on = Object.freeze({
    __proto__: null,
    addTransformToObject: fe,
    animate: Gs,
    animateColor: Hs,
    applyTransformToObject: pe,
    calcAngleBetweenVectors: Pe,
    calcDimensionsMatrix: Lt,
    calcPlaneChangeMatrix: _e,
    calcVectorRotation: Ee,
    cancelAnimFrame: dt,
    capValue: Ds,
    composeMatrix: Bt,
    copyCanvasElement: (t)=>{
        var e;
        const s = vt(t);
        return null === (e = s.getContext("2d")) || void 0 === e || e.drawImage(t, 0, 0), s;
    },
    cos: rt,
    createCanvasElement: pt,
    createImage: mt,
    createRotateMatrix: Pt,
    createScaleMatrix: Et,
    createSkewXMatrix: jt,
    createSkewYMatrix: Ft,
    createTranslateMatrix: Mt,
    createVector: De,
    crossProduct: Fe,
    degreesToRadians: xt,
    dotProduct: Le,
    ease: Rs,
    enlivenObjectEnlivables: $t,
    enlivenObjects: It,
    findScaleToCover: Dr,
    findScaleToFit: kr,
    getBoundsOfCurve: Lr,
    getOrthonormalVector: je,
    getPathSegmentsInfo: Ur,
    getPointOnPath: qr,
    getPointer: ce,
    getRandomInt: rn,
    getRegularPolygonPath: (t, e)=>{
        const s = 2 * Math.PI / t;
        let i = -y;
        t % 2 == 0 && (i += s / 2);
        const r = new Array(t + 1);
        for(let n = 0; n < t; n++){
            const t = n * s + i, { x: o, y: a } = new ot(rt(t), nt(t)).scalarMultiply(e);
            r[n] = [
                0 === n ? "M" : "L",
                o,
                a
            ];
        }
        return r[t] = [
            "Z"
        ], r;
    },
    getSmoothPathFromPoints: en,
    getSvgAttributes: (t)=>{
        const e = [
            "instantiated_by_use",
            "style",
            "id",
            "class"
        ];
        switch(t){
            case "linearGradient":
                return e.concat([
                    "x1",
                    "y1",
                    "x2",
                    "y2",
                    "gradientUnits",
                    "gradientTransform"
                ]);
            case "radialGradient":
                return e.concat([
                    "gradientUnits",
                    "gradientTransform",
                    "cx",
                    "cy",
                    "r",
                    "fx",
                    "fy",
                    "fr"
                ]);
            case "stop":
                return e.concat([
                    "offset",
                    "stop-color",
                    "stop-opacity"
                ]);
        }
        return e;
    },
    getUnitVector: Ae,
    groupSVGElements: (t, e)=>t && 1 === t.length ? t[0] : new Or(t, e),
    hasStyleChanged: Yi,
    invertTransform: wt,
    isBetweenVectors: Be,
    isIdentityMatrix: bt,
    isTouchEvent: ue,
    isTransparent: Fi,
    joinPath: sn,
    loadImage: Rt,
    magnitude: Me,
    makeBoundingBoxFromPoints: ge,
    makePathSimpler: Rr,
    matrixToSVG: Vt,
    mergeClipPaths: (t, e)=>{
        var s;
        let i = t, r = e;
        i.inverted && !r.inverted && (i = e, r = t), be(r, null === (s = r.group) || void 0 === s ? void 0 : s.calcTransformMatrix(), i.calcTransformMatrix());
        const n = i.inverted && r.inverted;
        return n && (i.inverted = r.inverted = !1), new Or([
            i
        ], {
            clipPath: r,
            inverted: n
        });
    },
    multiplyTransformMatrices: Tt,
    multiplyTransformMatrixArray: Ot,
    parsePath: tn,
    parsePreserveAspectRatioAttribute: Ze,
    parseUnit: Qe,
    pick: Xt,
    projectStrokeOnPoints: $i,
    qrDecompose: Dt,
    radiansToDegrees: Ct,
    removeFromArray: it,
    removeTransformFromObject: (t, e)=>{
        const s = wt(e), i = Tt(s, t.calcOwnMatrix());
        pe(t, i);
    },
    removeTransformMatrixForSvgParsing: nn,
    requestAnimFrame: ut,
    resetObjectTransform: me,
    rotateVector: ke,
    saveObjectTransform: ve,
    sendObjectToPlane: be,
    sendPointToPlane: xe,
    sendVectorToPlane: Ce,
    sin: nt,
    sizeAfterTransform: ye,
    string: ae,
    stylesFromArray: Vi,
    stylesToArray: Wi,
    toBlob: _t,
    toDataURL: yt,
    toFixed: Wt,
    transformPath: (t, e, s)=>(s && (e = Tt(e, [
            1,
            0,
            0,
            1,
            -s.x,
            -s.y
        ])), t.map((t)=>{
            const s = [
                ...t
            ];
            for(let i = 1; i < t.length - 1; i += 2){
                const { x: r, y: n } = St({
                    x: t[i],
                    y: t[i + 1]
                }, e);
                s[i] = r, s[i + 1] = n;
            }
            return s;
        })),
    transformPoint: St
});
function an(t, e) {
    const s = t.style;
    s && Object.entries(e).forEach((t)=>{
        let [e, i] = t;
        return s.setProperty(e, i);
    });
}
class hn extends te {
    constructor(e){
        let { allowTouchScrolling: s = !1, containerClass: i = "" } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(e), t(this, "upper", void 0), t(this, "container", void 0);
        const { el: r } = this.lower, n = this.createUpperCanvas();
        this.upper = {
            el: n,
            ctx: n.getContext("2d")
        }, this.applyCanvasStyle(r, {
            allowTouchScrolling: s
        }), this.applyCanvasStyle(n, {
            allowTouchScrolling: s,
            styles: {
                position: "absolute",
                left: "0",
                top: "0"
            }
        });
        const o = this.createContainerElement();
        o.classList.add(i), r.parentNode && r.parentNode.replaceChild(o, r), o.append(r, n), this.container = o;
    }
    createUpperCanvas() {
        const { el: t } = this.lower, e = pt();
        return e.className = t.className, e.classList.remove("lower-canvas"), e.classList.add("upper-canvas"), e.setAttribute("data-fabric", "top"), e.style.cssText = t.style.cssText, e.setAttribute("draggable", "true"), e;
    }
    createContainerElement() {
        const t = d().createElement("div");
        return t.setAttribute("data-fabric", "wrapper"), an(t, {
            position: "relative"
        }), Zt(t), t;
    }
    applyCanvasStyle(t, e) {
        const { styles: s, allowTouchScrolling: i } = e;
        an(t, {
            ...s,
            "touch-action": i ? "manipulation" : P
        }), Zt(t);
    }
    setDimensions(t, e) {
        super.setDimensions(t, e);
        const { el: s, ctx: i } = this.upper;
        Jt(s, i, t, e);
    }
    setCSSDimensions(t) {
        super.setCSSDimensions(t), Qt(this.upper.el, t), Qt(this.container, t);
    }
    cleanupDOM(t) {
        const e = this.container, { el: s } = this.lower, { el: i } = this.upper;
        super.cleanupDOM(t), e.removeChild(i), e.removeChild(s), e.parentNode && e.parentNode.replaceChild(s, e);
    }
    dispose() {
        super.dispose(), u().dispose(this.upper.el), delete this.upper, delete this.container;
    }
}
const ln = (t, e, s, i)=>{
    const { target: r, offsetX: n, offsetY: o } = e, a = s - n, h = i - o, l = !Xe(r, "lockMovementX") && r.left !== a, c = !Xe(r, "lockMovementY") && r.top !== h;
    return l && r.set(O, a), c && r.set(k, h), (l || c) && Ks(A, Ye(t, e, s, i)), l || c;
}, cn = I, un = (t)=>function(e, s, i) {
        const { points: r, pathOffset: n } = i;
        return new ot(r[t]).subtract(n).transform(Tt(i.getViewportTransform(), i.calcTransformMatrix()));
    }, dn = (t, e, s, i)=>{
    const { target: r, pointIndex: n } = e, o = r, a = xe(new ot(s, i), void 0, o.calcOwnMatrix());
    return o.points[n] = a.add(o.pathOffset), o.setDimensions(), o.set("dirty", !0), !0;
}, gn = (t, e)=>function(s, i, r, n) {
        const o = i.target, a = new ot(o.points[(t > 0 ? t : o.points.length) - 1]), h = a.subtract(o.pathOffset).transform(o.calcOwnMatrix()), l = e(s, {
            ...i,
            pointIndex: t
        }, r, n), c = a.subtract(o.pathOffset).transform(o.calcOwnMatrix()).subtract(h);
        return o.left -= c.x, o.top -= c.y, l;
    }, fn = (t)=>Js(cn, gn(t, dn));
const pn = (t, e, s)=>{
    const { path: i, pathOffset: r } = t, n = i[e];
    return new ot(n[s] - r.x, n[s + 1] - r.y).transform(Tt(t.getViewportTransform(), t.calcTransformMatrix()));
};
function mn(t, e, s) {
    const { commandIndex: i, pointIndex: r } = this;
    return pn(s, i, r);
}
function vn(t, e, s, i) {
    const { target: r } = e, { commandIndex: n, pointIndex: o } = this, a = ((t, e, s, i, r)=>{
        const { path: n, pathOffset: o } = t, a = n[(i > 0 ? i : n.length) - 1], h = new ot(a[r], a[r + 1]), l = h.subtract(o).transform(t.calcOwnMatrix()), c = xe(new ot(e, s), void 0, t.calcOwnMatrix());
        n[i][r] = c.x + o.x, n[i][r + 1] = c.y + o.y, t.setDimensions();
        const u = h.subtract(t.pathOffset).transform(t.calcOwnMatrix()).subtract(l);
        return t.left -= u.x, t.top -= u.y, t.set("dirty", !0), !0;
    })(r, s, i, n, o);
    return Ks(this.actionName, {
        ...Ye(t, e, s, i),
        commandIndex: n,
        pointIndex: o
    }), a;
}
class yn extends oi {
    constructor(t){
        super(t);
    }
    render(t, e, s, i, r) {
        const n = {
            ...i,
            cornerColor: this.controlFill,
            cornerStrokeColor: this.controlStroke,
            transparentCorners: !this.controlFill
        };
        super.render(t, e, s, n, r);
    }
}
class _n extends yn {
    constructor(t){
        super(t);
    }
    render(t, e, s, i, r) {
        const { path: n } = r, { commandIndex: o, pointIndex: a, connectToCommandIndex: h, connectToPointIndex: l } = this;
        t.save(), t.strokeStyle = this.controlStroke, this.connectionDashArray && t.setLineDash(this.connectionDashArray);
        const [c] = n[o], u = pn(r, h, l);
        if ("Q" === c) {
            const i = pn(r, o, a + 2);
            t.moveTo(i.x, i.y), t.lineTo(e, s);
        } else t.moveTo(e, s);
        t.lineTo(u.x, u.y), t.stroke(), t.restore(), super.render(t, e, s, i, r);
    }
}
const xn = (t, e, s, i, r, n)=>new (s ? _n : yn)({
        commandIndex: t,
        pointIndex: e,
        actionName: "modifyPath",
        positionHandler: mn,
        actionHandler: vn,
        connectToCommandIndex: r,
        connectToPointIndex: n,
        ...i,
        ...s ? i.controlPointStyle : i.pointStyle
    });
var Cn = Object.freeze({
    __proto__: null,
    changeHeight: ii,
    changeObjectHeight: ei,
    changeObjectWidth: ti,
    changeWidth: si,
    createObjectDefaultControls: Di,
    createPathControls: function(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const s = {};
        let i = "M";
        return t.path.forEach((t, r)=>{
            const n = t[0];
            switch("Z" !== n && (s[`c_${r}_${n}`] = xn(r, t.length - 2, !1, e)), n){
                case "C":
                    s[`c_${r}_C_CP_1`] = xn(r, 1, !0, e, r - 1, ((t)=>"C" === t ? 5 : "Q" === t ? 3 : 1)(i)), s[`c_${r}_C_CP_2`] = xn(r, 3, !0, e, r, 5);
                    break;
                case "Q":
                    s[`c_${r}_Q_CP_1`] = xn(r, 1, !0, e, r, 3);
            }
            i = n;
        }), s;
    },
    createPolyActionHandler: fn,
    createPolyControls: function(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const s = {};
        for(let i = 0; i < ("number" == typeof t ? t : t.points.length); i++)s[`p${i}`] = new oi({
            actionName: cn,
            positionHandler: un(i),
            actionHandler: fn(i),
            ...e
        });
        return s;
    },
    createPolyPositionHandler: un,
    createResizeControls: Mi,
    createTextboxDefaultControls: Pi,
    dragHandler: ln,
    factoryPolyActionHandler: gn,
    getLocalPoint: Ve,
    polyActionHandler: dn,
    renderCircleControl: ri,
    renderSquareControl: ni,
    rotationStyleHandler: ai,
    rotationWithSnapping: hi,
    scaleCursorStyleHandler: di,
    scaleOrSkewActionName: wi,
    scaleSkewCursorStyleHandler: Ti,
    scalingEqually: fi,
    scalingX: pi,
    scalingXOrSkewingY: Oi,
    scalingY: mi,
    scalingYOrSkewingX: ki,
    skewCursorStyleHandler: _i,
    skewHandlerX: Ci,
    skewHandlerY: bi,
    wrapWithFireEvent: Js,
    wrapWithFixedAnchor: Qs
});
class bn extends he {
    constructor(){
        super(...arguments), t(this, "_hoveredTargets", []), t(this, "_currentTransform", null), t(this, "_groupSelector", null), t(this, "contextTopDirty", !1);
    }
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...bn.ownDefaults
        };
    }
    get upperCanvasEl() {
        var t;
        return null === (t = this.elements.upper) || void 0 === t ? void 0 : t.el;
    }
    get contextTop() {
        var t;
        return null === (t = this.elements.upper) || void 0 === t ? void 0 : t.ctx;
    }
    get wrapperEl() {
        return this.elements.container;
    }
    initElements(t) {
        this.elements = new hn(t, {
            allowTouchScrolling: this.allowTouchScrolling,
            containerClass: this.containerClass
        }), this._createCacheCanvas();
    }
    _onObjectAdded(t) {
        this._objectsToRender = void 0, super._onObjectAdded(t);
    }
    _onObjectRemoved(t) {
        this._objectsToRender = void 0, t === this._activeObject && (this.fire("before:selection:cleared", {
            deselected: [
                t
            ]
        }), this._discardActiveObject(), this.fire("selection:cleared", {
            deselected: [
                t
            ]
        }), t.fire("deselected", {
            target: t
        })), t === this._hoveredTarget && (this._hoveredTarget = void 0, this._hoveredTargets = []), super._onObjectRemoved(t);
    }
    _onStackOrderChanged() {
        this._objectsToRender = void 0, super._onStackOrderChanged();
    }
    _chooseObjectsToRender() {
        const t = this._activeObject;
        return !this.preserveObjectStacking && t ? this._objects.filter((e)=>!e.group && e !== t).concat(t) : this._objects;
    }
    renderAll() {
        this.cancelRequestedRender(), this.destroyed || (!this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), this.hasLostContext && (this.renderTopLayer(this.contextTop), this.hasLostContext = !1), !this._objectsToRender && (this._objectsToRender = this._chooseObjectsToRender()), this.renderCanvas(this.getContext(), this._objectsToRender));
    }
    renderTopLayer(t) {
        t.save(), this.isDrawingMode && this._isCurrentlyDrawing && (this.freeDrawingBrush && this.freeDrawingBrush._render(), this.contextTopDirty = !0), this.selection && this._groupSelector && (this._drawSelection(t), this.contextTopDirty = !0), t.restore();
    }
    renderTop() {
        const t = this.contextTop;
        this.clearContext(t), this.renderTopLayer(t), this.fire("after:render", {
            ctx: t
        });
    }
    setTargetFindTolerance(t) {
        t = Math.round(t), this.targetFindTolerance = t;
        const e = this.getRetinaScaling(), s = Math.ceil((2 * t + 1) * e);
        this.pixelFindCanvasEl.width = this.pixelFindCanvasEl.height = s, this.pixelFindContext.scale(e, e);
    }
    isTargetTransparent(t, e, s) {
        const i = this.targetFindTolerance, r = this.pixelFindContext;
        this.clearContext(r), r.save(), r.translate(-e + i, -s + i), r.transform(...this.viewportTransform);
        const n = t.selectionBackgroundColor;
        t.selectionBackgroundColor = "", t.render(r), t.selectionBackgroundColor = n, r.restore();
        const o = Math.round(i * this.getRetinaScaling());
        return Fi(r, o, o, o);
    }
    _isSelectionKeyPressed(t) {
        const e = this.selectionKey;
        return !!e && (Array.isArray(e) ? !!e.find((e)=>!!e && !0 === t[e]) : t[e]);
    }
    _shouldClearSelection(t, e) {
        const s = this.getActiveObjects(), i = this._activeObject;
        return !!(!e || e && i && s.length > 1 && -1 === s.indexOf(e) && i !== e && !this._isSelectionKeyPressed(t) || e && !e.evented || e && !e.selectable && i && i !== e);
    }
    _shouldCenterTransform(t, e, s) {
        if (!t) return;
        let i;
        return e === Y || e === W || e === V || e === R ? i = this.centeredScaling || t.centeredScaling : e === L && (i = this.centeredRotation || t.centeredRotation), i ? !s : s;
    }
    _getOriginFromCorner(t, e) {
        const s = e ? t.controls[e].getTransformAnchorPoint() : {
            x: t.originX,
            y: t.originY
        };
        return e ? ([
            "ml",
            "tl",
            "bl"
        ].includes(e) ? s.x = M : [
            "mr",
            "tr",
            "br"
        ].includes(e) && (s.x = O), [
            "tl",
            "mt",
            "tr"
        ].includes(e) ? s.y = D : [
            "bl",
            "mb",
            "br"
        ].includes(e) && (s.y = k), s) : s;
    }
    _setupCurrentTransform(t, e, s) {
        var i;
        const r = e.group ? xe(this.getScenePoint(t), void 0, e.group.calcTransformMatrix()) : this.getScenePoint(t), { key: n = "", control: o } = e.getActiveControl() || {}, a = s && o ? null === (i = o.getActionHandler(t, e, o)) || void 0 === i ? void 0 : i.bind(o) : ln, h = ((t, e, s, i)=>{
            if (!e || !t) return "drag";
            const r = i.controls[e];
            return r.getActionName(s, r, i);
        })(s, n, t, e), l = t[this.centeredKey], c = this._shouldCenterTransform(e, h, l) ? {
            x: T,
            y: T
        } : this._getOriginFromCorner(e, n), { scaleX: u, scaleY: d, skewX: g, skewY: f, left: p, top: m, angle: v, width: y, height: _, cropX: x, cropY: C } = e, b = {
            target: e,
            action: h,
            actionHandler: a,
            actionPerformed: !1,
            corner: n,
            scaleX: u,
            scaleY: d,
            skewX: g,
            skewY: f,
            offsetX: r.x - p,
            offsetY: r.y - m,
            originX: c.x,
            originY: c.y,
            ex: r.x,
            ey: r.y,
            lastX: r.x,
            lastY: r.y,
            theta: xt(v),
            width: y,
            height: _,
            shiftKey: t.shiftKey,
            altKey: l,
            original: {
                ...ve(e),
                originX: c.x,
                originY: c.y,
                cropX: x,
                cropY: C
            }
        };
        this._currentTransform = b, this.fire("before:transform", {
            e: t,
            transform: b
        });
    }
    setCursor(t) {
        this.upperCanvasEl.style.cursor = t;
    }
    _drawSelection(t) {
        const { x: e, y: s, deltaX: i, deltaY: r } = this._groupSelector, n = new ot(e, s).transform(this.viewportTransform), o = new ot(e + i, s + r).transform(this.viewportTransform), a = this.selectionLineWidth / 2;
        let h = Math.min(n.x, o.x), l = Math.min(n.y, o.y), c = Math.max(n.x, o.x), u = Math.max(n.y, o.y);
        this.selectionColor && (t.fillStyle = this.selectionColor, t.fillRect(h, l, c - h, u - l)), this.selectionLineWidth && this.selectionBorderColor && (t.lineWidth = this.selectionLineWidth, t.strokeStyle = this.selectionBorderColor, h += a, l += a, c -= a, u -= a, ji.prototype._setLineDash.call(this, t, this.selectionDashArray), t.strokeRect(h, l, c - h, u - l));
    }
    findTarget(t) {
        if (this._targetInfo) return this._targetInfo;
        if (this.skipTargetFind) return {
            subTargets: [],
            currentSubTargets: []
        };
        const e = this.getScenePoint(t), s = this._activeObject, i = this.getActiveObjects(), r = this.searchPossibleTargets(this._objects, e), { subTargets: n, container: o, target: a } = r, h = {
            ...r,
            currentSubTargets: n,
            currentContainer: o,
            currentTarget: a
        };
        if (!s) return h;
        const l = {
            ...this.searchPossibleTargets([
                s
            ], e),
            currentSubTargets: n,
            currentContainer: o,
            currentTarget: a
        };
        if (s.findControl(this.getViewportPoint(t), ue(t))) return {
            ...l,
            target: s
        };
        if (l.target) {
            if (i.length > 1) return l;
            if (!this.preserveObjectStacking) return l;
            if (this.preserveObjectStacking && t[this.altSelectionKey]) return l;
        }
        return h;
    }
    _pointIsInObjectSelectionArea(t, e) {
        let s = t.getCoords();
        const i = this.getZoom(), r = t.padding / i;
        if (r) {
            const [t, e, i, n] = s, o = Math.atan2(e.y - t.y, e.x - t.x), a = rt(o) * r, h = nt(o) * r, l = a + h, c = a - h;
            s = [
                new ot(t.x - c, t.y - l),
                new ot(e.x + l, e.y - c),
                new ot(i.x + c, i.y + l),
                new ot(n.x - l, n.y + c)
            ];
        }
        return Ns.isPointInPolygon(e, s);
    }
    _checkTarget(t, e) {
        if (t && t.visible && t.evented && this._pointIsInObjectSelectionArea(t, e)) {
            if (!this.perPixelTargetFind && !t.perPixelTargetFind || t.isEditing) return !0;
            {
                const s = e.transform(this.viewportTransform);
                if (!this.isTargetTransparent(t, s.x, s.y)) return !0;
            }
        }
        return !1;
    }
    _searchPossibleTargets(t, e, s) {
        let i = t.length;
        for(; i--;){
            const r = t[i];
            if (this._checkTarget(r, e)) {
                if (ht(r) && r.subTargetCheck) {
                    const { target: t } = this._searchPossibleTargets(r._objects, e, s);
                    t && s.push(t);
                }
                return {
                    target: r,
                    subTargets: s
                };
            }
        }
        return {
            subTargets: []
        };
    }
    searchPossibleTargets(t, e) {
        const s = this._searchPossibleTargets(t, e, []);
        s.container = s.target;
        const { container: i, subTargets: r } = s;
        if (i && ht(i) && i.interactive && r[0]) {
            for(let t = r.length - 1; t > 0; t--){
                const e = r[t];
                if (!ht(e) || !e.interactive) return s.target = e, s;
            }
            return s.target = r[0], s;
        }
        return s;
    }
    getViewportPoint(t) {
        return this._viewportPoint ? this._viewportPoint : this._getPointerImpl(t, !0);
    }
    getScenePoint(t) {
        return this._scenePoint ? this._scenePoint : this._getPointerImpl(t);
    }
    _getPointerImpl(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const s = this.upperCanvasEl, i = s.getBoundingClientRect();
        let r = ce(t), n = i.width || 0, o = i.height || 0;
        n && o || (k in i && D in i && (o = Math.abs(i.top - i.bottom)), M in i && O in i && (n = Math.abs(i.right - i.left))), this.calcOffset(), r.x = r.x - this._offset.left, r.y = r.y - this._offset.top, e || (r = xe(r, void 0, this.viewportTransform));
        const a = this.getRetinaScaling();
        1 !== a && (r.x /= a, r.y /= a);
        const h = 0 === n || 0 === o ? new ot(1, 1) : new ot(s.width / n, s.height / o);
        return r.multiply(h);
    }
    _setDimensionsImpl(t, e) {
        this._resetTransformEventData(), super._setDimensionsImpl(t, e), this._isCurrentlyDrawing && this.freeDrawingBrush && this.freeDrawingBrush._setBrushStyles(this.contextTop);
    }
    _createCacheCanvas() {
        this.pixelFindCanvasEl = pt(), this.pixelFindContext = this.pixelFindCanvasEl.getContext("2d", {
            willReadFrequently: !0
        }), this.setTargetFindTolerance(this.targetFindTolerance);
    }
    getTopContext() {
        return this.elements.upper.ctx;
    }
    getSelectionContext() {
        return this.elements.upper.ctx;
    }
    getSelectionElement() {
        return this.elements.upper.el;
    }
    getActiveObject() {
        return this._activeObject;
    }
    getActiveObjects() {
        const t = this._activeObject;
        return Nt(t) ? t.getObjects() : t ? [
            t
        ] : [];
    }
    _fireSelectionEvents(t, e) {
        let s = !1, i = !1;
        const r = this.getActiveObjects(), n = [], o = [];
        t.forEach((t)=>{
            r.includes(t) || (s = !0, t.fire("deselected", {
                e: e,
                target: t
            }), o.push(t));
        }), r.forEach((i)=>{
            t.includes(i) || (s = !0, i.fire("selected", {
                e: e,
                target: i
            }), n.push(i));
        }), t.length > 0 && r.length > 0 ? (i = !0, s && this.fire("selection:updated", {
            e: e,
            selected: n,
            deselected: o
        })) : r.length > 0 ? (i = !0, this.fire("selection:created", {
            e: e,
            selected: n
        })) : t.length > 0 && (i = !0, this.fire("selection:cleared", {
            e: e,
            deselected: o
        })), i && (this._objectsToRender = void 0);
    }
    setActiveObject(t, e) {
        const s = this.getActiveObjects(), i = this._setActiveObject(t, e);
        return this._fireSelectionEvents(s, e), i;
    }
    _setActiveObject(t, e) {
        const s = this._activeObject;
        return s !== t && !(!this._discardActiveObject(e, t) && this._activeObject) && !t.onSelect({
            e: e
        }) && (this._activeObject = t, Nt(t) && s !== t && t.set("canvas", this), t.setCoords(), !0);
    }
    _discardActiveObject(t, e) {
        const s = this._activeObject;
        return !!s && !s.onDeselect({
            e: t,
            object: e
        }) && (this._currentTransform && this._currentTransform.target === s && this.endCurrentTransform(t), Nt(s) && s === this._hoveredTarget && (this._hoveredTarget = void 0), this._activeObject = void 0, !0);
    }
    discardActiveObject(t) {
        const e = this.getActiveObjects(), s = this.getActiveObject();
        e.length && this.fire("before:selection:cleared", {
            e: t,
            deselected: [
                s
            ]
        });
        const i = this._discardActiveObject(t);
        return this._fireSelectionEvents(e, t), i;
    }
    endCurrentTransform(t) {
        const e = this._currentTransform;
        this._finalizeCurrentTransform(t), e && e.target && (e.target.isMoving = !1), this._currentTransform = null;
    }
    _finalizeCurrentTransform(t) {
        const e = this._currentTransform, s = e.target, i = {
            e: t,
            target: s,
            transform: e,
            action: e.action
        };
        s._scaling && (s._scaling = !1), s.setCoords(), e.actionPerformed && (this.fire("object:modified", i), s.fire(U, i));
    }
    setViewportTransform(t) {
        super.setViewportTransform(t);
        const e = this._activeObject;
        e && e.setCoords();
    }
    destroy() {
        const t = this._activeObject;
        Nt(t) && (t.removeAll(), t.dispose()), delete this._activeObject, super.destroy(), this.pixelFindContext = null, this.pixelFindCanvasEl = void 0;
    }
    clear() {
        this.discardActiveObject(), this._activeObject = void 0, this.clearContext(this.contextTop), super.clear();
    }
    drawControls(t) {
        const e = this._activeObject;
        e && e._renderControls(t);
    }
    _toObject(t, e, s) {
        const i = this._realizeGroupTransformOnObject(t), r = super._toObject(t, e, s);
        return t.set(i), r;
    }
    _realizeGroupTransformOnObject(t) {
        const { group: e } = t;
        if (e && Nt(e) && this._activeObject === e) {
            const s = Xt(t, [
                "angle",
                "flipX",
                "flipY",
                O,
                W,
                V,
                z,
                G,
                k
            ]);
            return fe(t, e.calcOwnMatrix()), s;
        }
        return {};
    }
    _setSVGObject(t, e, s) {
        const i = this._realizeGroupTransformOnObject(e);
        super._setSVGObject(t, e, s), e.set(i);
    }
}
t(bn, "ownDefaults", {
    uniformScaling: !0,
    uniScaleKey: "shiftKey",
    centeredScaling: !1,
    centeredRotation: !1,
    centeredKey: "altKey",
    altActionKey: "shiftKey",
    selection: !0,
    selectionKey: "shiftKey",
    selectionColor: "rgba(100, 100, 255, 0.3)",
    selectionDashArray: [],
    selectionBorderColor: "rgba(255, 255, 255, 0.3)",
    selectionLineWidth: 1,
    selectionFullyContained: !1,
    hoverCursor: "move",
    moveCursor: "move",
    defaultCursor: "default",
    freeDrawingCursor: "crosshair",
    notAllowedCursor: "not-allowed",
    perPixelTargetFind: !1,
    targetFindTolerance: 0,
    skipTargetFind: !1,
    stopContextMenu: !0,
    fireRightClick: !0,
    fireMiddleClick: !0,
    enablePointerEvents: !1,
    containerClass: "canvas-container",
    preserveObjectStacking: !0
});
class Sn {
    constructor(e){
        t(this, "targets", []), t(this, "__disposer", void 0);
        const s = ()=>{
            const { hiddenTextarea: t } = e.getActiveObject() || {};
            t && t.focus();
        }, i = e.upperCanvasEl;
        i.addEventListener("click", s), this.__disposer = ()=>i.removeEventListener("click", s);
    }
    exitTextEditing() {
        this.target = void 0, this.targets.forEach((t)=>{
            t.isEditing && t.exitEditing();
        });
    }
    add(t) {
        this.targets.push(t);
    }
    remove(t) {
        this.unregister(t), it(this.targets, t);
    }
    register(t) {
        this.target = t;
    }
    unregister(t) {
        t === this.target && (this.target = void 0);
    }
    onMouseMove(t) {
        var e;
        (null === (e = this.target) || void 0 === e ? void 0 : e.isEditing) && this.target.updateSelectionOnMouseMove(t);
    }
    clear() {
        this.targets = [], this.target = void 0;
    }
    dispose() {
        this.clear(), this.__disposer(), delete this.__disposer;
    }
}
const wn = {
    passive: !1
}, Tn = (t, e)=>({
        viewportPoint: t.getViewportPoint(e),
        scenePoint: t.getScenePoint(e)
    }), On = function(t) {
    for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
    return t.addEventListener(...s);
}, kn = function(t) {
    for(var e = arguments.length, s = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)s[i - 1] = arguments[i];
    return t.removeEventListener(...s);
}, Dn = {
    mouse: {
        in: "over",
        out: "out",
        targetIn: "mouseover",
        targetOut: "mouseout",
        canvasIn: "mouse:over",
        canvasOut: "mouse:out"
    },
    drag: {
        in: "enter",
        out: "leave",
        targetIn: "dragenter",
        targetOut: "dragleave",
        canvasIn: "drag:enter",
        canvasOut: "drag:leave"
    }
};
class Mn extends bn {
    constructor(e){
        super(e, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}), t(this, "_isClick", void 0), t(this, "textEditingManager", new Sn(this)), [
            "_onMouseDown",
            "_onTouchStart",
            "_onMouseMove",
            "_onMouseUp",
            "_onTouchEnd",
            "_onResize",
            "_onMouseWheel",
            "_onMouseOut",
            "_onMouseEnter",
            "_onContextMenu",
            "_onClick",
            "_onDragStart",
            "_onDragEnd",
            "_onDragProgress",
            "_onDragOver",
            "_onDragEnter",
            "_onDragLeave",
            "_onDrop"
        ].forEach((t)=>{
            this[t] = this[t].bind(this);
        }), this.addOrRemove(On);
    }
    _getEventPrefix() {
        return this.enablePointerEvents ? "pointer" : "mouse";
    }
    addOrRemove(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const s = this.upperCanvasEl, i = this._getEventPrefix();
        t(Kt(s), "resize", this._onResize), t(s, i + "down", this._onMouseDown), t(s, `${i}move`, this._onMouseMove, wn), t(s, `${i}out`, this._onMouseOut), t(s, `${i}enter`, this._onMouseEnter), t(s, "wheel", this._onMouseWheel, {
            passive: !1
        }), t(s, "contextmenu", this._onContextMenu), e || (t(s, "click", this._onClick), t(s, "dblclick", this._onClick)), t(s, "dragstart", this._onDragStart), t(s, "dragend", this._onDragEnd), t(s, "dragover", this._onDragOver), t(s, "dragenter", this._onDragEnter), t(s, "dragleave", this._onDragLeave), t(s, "drop", this._onDrop), this.enablePointerEvents || t(s, "touchstart", this._onTouchStart, wn);
    }
    removeListeners() {
        this.addOrRemove(kn);
        const t = this._getEventPrefix(), e = qt(this.upperCanvasEl);
        kn(e, `${t}up`, this._onMouseUp), kn(e, "touchend", this._onTouchEnd, wn), kn(e, `${t}move`, this._onMouseMove, wn), kn(e, "touchmove", this._onMouseMove, wn), clearTimeout(this._willAddMouseDown);
    }
    _onMouseWheel(t) {
        this._cacheTransformEventData(t), this._handleEvent(t, "wheel"), this._resetTransformEventData();
    }
    _onMouseOut(t) {
        const e = this._hoveredTarget, s = {
            e: t,
            ...Tn(this, t)
        };
        this.fire("mouse:out", {
            ...s,
            target: e
        }), this._hoveredTarget = void 0, e && e.fire("mouseout", {
            ...s
        }), this._hoveredTargets.forEach((t)=>{
            this.fire("mouse:out", {
                ...s,
                target: t
            }), t && t.fire("mouseout", {
                ...s
            });
        }), this._hoveredTargets = [];
    }
    _onMouseEnter(t) {
        const { target: e } = this.findTarget(t);
        this._currentTransform || e || (this.fire("mouse:over", {
            e: t,
            ...Tn(this, t)
        }), this._hoveredTarget = void 0, this._hoveredTargets = []);
    }
    _onDragStart(t) {
        this._isClick = !1;
        const e = this.getActiveObject();
        if (e && e.onDragStart(t)) {
            this._dragSource = e;
            const s = {
                e: t,
                target: e
            };
            return this.fire("dragstart", s), e.fire("dragstart", s), void On(this.upperCanvasEl, "drag", this._onDragProgress);
        }
        de(t);
    }
    _renderDragEffects(t, e, s) {
        let i = !1;
        const r = this._dropTarget;
        r && r !== e && r !== s && (r.clearContextTop(), i = !0), null == e || e.clearContextTop(), s !== e && (null == s || s.clearContextTop());
        const n = this.contextTop;
        n.save(), n.transform(...this.viewportTransform), e && (n.save(), e.transform(n), e.renderDragSourceEffect(t), n.restore(), i = !0), s && (n.save(), s.transform(n), s.renderDropTargetEffect(t), n.restore(), i = !0), n.restore(), i && (this.contextTopDirty = !0);
    }
    _onDragEnd(t) {
        const { currentSubTargets: e } = this.findTarget(t), s = !!t.dataTransfer && t.dataTransfer.dropEffect !== P, i = s ? this._activeObject : void 0, r = {
            e: t,
            target: this._dragSource,
            subTargets: e,
            dragSource: this._dragSource,
            didDrop: s,
            dropTarget: i
        };
        kn(this.upperCanvasEl, "drag", this._onDragProgress), this.fire("dragend", r), this._dragSource && this._dragSource.fire("dragend", r), delete this._dragSource, this._onMouseUp(t);
    }
    _onDragProgress(t) {
        const e = {
            e: t,
            target: this._dragSource,
            dragSource: this._dragSource,
            dropTarget: this._draggedoverTarget
        };
        this.fire("drag", e), this._dragSource && this._dragSource.fire("drag", e);
    }
    _onDragOver(t) {
        const e = "dragover", { currentContainer: s, currentSubTargets: i } = this.findTarget(t), r = this._dragSource, n = {
            e: t,
            target: s,
            subTargets: i,
            dragSource: r,
            canDrop: !1,
            dropTarget: void 0
        };
        let o;
        this.fire(e, n), this._fireEnterLeaveEvents(t, s, n), s && (s.canDrop(t) && (o = s), s.fire(e, n));
        for(let s = 0; s < i.length; s++){
            const r = i[s];
            r.canDrop(t) && (o = r), r.fire(e, n);
        }
        this._renderDragEffects(t, r, o), this._dropTarget = o;
    }
    _onDragEnter(t) {
        const { currentContainer: e, currentSubTargets: s } = this.findTarget(t), i = {
            e: t,
            target: e,
            subTargets: s,
            dragSource: this._dragSource
        };
        this.fire("dragenter", i), this._fireEnterLeaveEvents(t, e, i);
    }
    _onDragLeave(t) {
        const { currentSubTargets: e } = this.findTarget(t), s = {
            e: t,
            target: this._draggedoverTarget,
            subTargets: e,
            dragSource: this._dragSource
        };
        this.fire("dragleave", s), this._fireEnterLeaveEvents(t, void 0, s), this._renderDragEffects(t, this._dragSource), this._dropTarget = void 0, this._hoveredTargets = [];
    }
    _onDrop(t) {
        const { currentContainer: e, currentSubTargets: s } = this.findTarget(t), i = this._basicEventHandler("drop:before", {
            e: t,
            target: e,
            subTargets: s,
            dragSource: this._dragSource,
            ...Tn(this, t)
        });
        i.didDrop = !1, i.dropTarget = void 0, this._basicEventHandler("drop", i), this.fire("drop:after", i);
    }
    _onContextMenu(t) {
        const { target: e, subTargets: s } = this.findTarget(t), i = this._basicEventHandler("contextmenu:before", {
            e: t,
            target: e,
            subTargets: s
        });
        return this.stopContextMenu && de(t), this._basicEventHandler("contextmenu", i), !1;
    }
    _onClick(t) {
        const e = t.detail;
        e > 3 || e < 2 || (this._cacheTransformEventData(t), 2 == e && "dblclick" === t.type && this._handleEvent(t, "dblclick"), 3 == e && this._handleEvent(t, "tripleclick"), this._resetTransformEventData());
    }
    fireEventFromPointerEvent(t, e, s) {
        let i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        this._cacheTransformEventData(t);
        const { target: r, subTargets: n } = this.findTarget(t), o = {
            e: t,
            target: r,
            subTargets: n,
            ...Tn(this, t),
            transform: this._currentTransform,
            ...i
        };
        this.fire(e, o), r && r.fire(s, o);
        for(let t = 0; t < n.length; t++)n[t] !== r && n[t].fire(s, o);
        this._resetTransformEventData();
    }
    getPointerId(t) {
        const e = t.changedTouches;
        return e ? e[0] && e[0].identifier : this.enablePointerEvents ? t.pointerId : -1;
    }
    _isMainEvent(t) {
        return !0 === t.isPrimary || !1 !== t.isPrimary && ("touchend" === t.type && 0 === t.touches.length || !t.changedTouches || t.changedTouches[0].identifier === this.mainTouchId);
    }
    _onTouchStart(t) {
        this._cacheTransformEventData(t);
        let e = !this.allowTouchScrolling;
        const s = this._activeObject;
        void 0 === this.mainTouchId && (this.mainTouchId = this.getPointerId(t)), this.__onMouseDown(t);
        const { target: i } = this.findTarget(t);
        (this.isDrawingMode || s && i === s) && (e = !0), e && t.preventDefault();
        const r = this.upperCanvasEl, n = this._getEventPrefix(), o = qt(r);
        On(o, "touchend", this._onTouchEnd, wn), e && On(o, "touchmove", this._onMouseMove, wn), kn(r, `${n}down`, this._onMouseDown), this._resetTransformEventData();
    }
    _onMouseDown(t) {
        this._cacheTransformEventData(t), this.__onMouseDown(t);
        const e = this.upperCanvasEl, s = this._getEventPrefix();
        kn(e, `${s}move`, this._onMouseMove, wn);
        const i = qt(e);
        On(i, `${s}up`, this._onMouseUp), On(i, `${s}move`, this._onMouseMove, wn), this._resetTransformEventData();
    }
    _onTouchEnd(t) {
        if (t.touches.length > 0) return;
        this._cacheTransformEventData(t), this.__onMouseUp(t), this._resetTransformEventData(), delete this.mainTouchId;
        const e = this._getEventPrefix(), s = qt(this.upperCanvasEl);
        kn(s, "touchend", this._onTouchEnd, wn), kn(s, "touchmove", this._onMouseMove, wn), this._willAddMouseDown && clearTimeout(this._willAddMouseDown), this._willAddMouseDown = setTimeout(()=>{
            On(this.upperCanvasEl, `${e}down`, this._onMouseDown), this._willAddMouseDown = 0;
        }, 400);
    }
    _onMouseUp(t) {
        this._cacheTransformEventData(t), this.__onMouseUp(t);
        const e = this.upperCanvasEl, s = this._getEventPrefix();
        if (this._isMainEvent(t)) {
            const t = qt(this.upperCanvasEl);
            kn(t, `${s}up`, this._onMouseUp), kn(t, `${s}move`, this._onMouseMove, wn), On(e, `${s}move`, this._onMouseMove, wn);
        }
        this._resetTransformEventData();
    }
    _onMouseMove(t) {
        this._cacheTransformEventData(t);
        const e = this.getActiveObject();
        !this.allowTouchScrolling && (!e || !e.shouldStartDragging(t)) && t.preventDefault && t.preventDefault(), this.__onMouseMove(t), this._resetTransformEventData();
    }
    _onResize() {
        this.calcOffset(), this._resetTransformEventData();
    }
    _shouldRender(t) {
        const e = this.getActiveObject();
        return !!e != !!t || e && t && e !== t;
    }
    __onMouseUp(t) {
        var e;
        this._handleEvent(t, "up:before");
        const s = this._currentTransform, i = this._isClick, { target: r } = this.findTarget(t), { button: n } = t;
        if (n) return void ((this.fireMiddleClick && 1 === n || this.fireRightClick && 2 === n) && this._handleEvent(t, "up"));
        if (this.isDrawingMode && this._isCurrentlyDrawing) return void this._onMouseUpInDrawingMode(t);
        if (!this._isMainEvent(t)) return;
        let o, a, h = !1;
        if (s && (this._finalizeCurrentTransform(t), h = s.actionPerformed), !i) {
            const e = r === this._activeObject;
            this.handleSelection(t), h || (h = this._shouldRender(r) || !e && r === this._activeObject);
        }
        if (r) {
            const e = r.findControl(this.getViewportPoint(t), ue(t)), { key: i, control: n } = e || {};
            if (a = i, r.selectable && r !== this._activeObject && "up" === r.activeOn) this.setActiveObject(r, t), h = !0;
            else if (n) {
                const e = n.getMouseUpHandler(t, r, n);
                e && (o = this.getScenePoint(t), e.call(n, t, s, o.x, o.y));
            }
            r.isMoving = !1;
        }
        if (s && (s.target !== r || s.corner !== a)) {
            const e = s.target && s.target.controls[s.corner], i = e && e.getMouseUpHandler(t, s.target, e);
            o = o || this.getScenePoint(t), i && i.call(e, t, s, o.x, o.y);
        }
        this._setCursorFromEvent(t, r), this._handleEvent(t, "up"), this._groupSelector = null, this._currentTransform = null, r && (r.__corner = void 0), h ? this.requestRenderAll() : i || null !== (e = this._activeObject) && void 0 !== e && e.isEditing || this.renderTop();
    }
    _basicEventHandler(t, e) {
        const { target: s, subTargets: i = [] } = e;
        this.fire(t, e), s && s.fire(t, e);
        for(let r = 0; r < i.length; r++)i[r] !== s && i[r].fire(t, e);
        return e;
    }
    _handleEvent(t, e, s) {
        const { target: i, subTargets: r } = this.findTarget(t), n = {
            e: t,
            target: i,
            subTargets: r,
            ...Tn(this, t),
            transform: this._currentTransform,
            ..."down:before" === e || "down" === e ? s : {}
        };
        "up:before" !== e && "up" !== e || (n.isClick = this._isClick), this.fire(`mouse:${e}`, n), i && i.fire(`mouse${e}`, n);
        for(let t = 0; t < r.length; t++)r[t] !== i && r[t].fire(`mouse${e}`, n);
    }
    _onMouseDownInDrawingMode(t) {
        this._isCurrentlyDrawing = !0, this.getActiveObject() && (this.discardActiveObject(t), this.requestRenderAll());
        const e = this.getScenePoint(t);
        this.freeDrawingBrush && this.freeDrawingBrush.onMouseDown(e, {
            e: t,
            pointer: e
        }), this._handleEvent(t, "down", {
            alreadySelected: !1
        });
    }
    _onMouseMoveInDrawingMode(t) {
        if (this._isCurrentlyDrawing) {
            const e = this.getScenePoint(t);
            this.freeDrawingBrush && this.freeDrawingBrush.onMouseMove(e, {
                e: t,
                pointer: e
            });
        }
        this.setCursor(this.freeDrawingCursor), this._handleEvent(t, "move");
    }
    _onMouseUpInDrawingMode(t) {
        const e = this.getScenePoint(t);
        this.freeDrawingBrush ? this._isCurrentlyDrawing = !!this.freeDrawingBrush.onMouseUp({
            e: t,
            pointer: e
        }) : this._isCurrentlyDrawing = !1, this._handleEvent(t, "up");
    }
    __onMouseDown(t) {
        this._isClick = !0, this._handleEvent(t, "down:before");
        let { target: e } = this.findTarget(t), s = !!e && e === this._activeObject;
        const { button: i } = t;
        if (i) return void ((this.fireMiddleClick && 1 === i || this.fireRightClick && 2 === i) && this._handleEvent(t, "down", {
            alreadySelected: s
        }));
        if (this.isDrawingMode) return void this._onMouseDownInDrawingMode(t);
        if (!this._isMainEvent(t)) return;
        if (this._currentTransform) return;
        let r = this._shouldRender(e), n = !1;
        if (this.handleMultiSelection(t, e) ? (e = this._activeObject, n = !0, r = !0) : this._shouldClearSelection(t, e) && this.discardActiveObject(t), this.selection && (!e || !e.selectable && !e.isEditing && e !== this._activeObject)) {
            const e = this.getScenePoint(t);
            this._groupSelector = {
                x: e.x,
                y: e.y,
                deltaY: 0,
                deltaX: 0
            };
        }
        if (s = !!e && e === this._activeObject, e) {
            e.selectable && "down" === e.activeOn && this.setActiveObject(e, t);
            const i = e.findControl(this.getViewportPoint(t), ue(t));
            if (e === this._activeObject && (i || !n)) {
                this._setupCurrentTransform(t, e, s);
                const r = i ? i.control : void 0, n = this.getScenePoint(t), o = r && r.getMouseDownHandler(t, e, r);
                o && o.call(r, t, this._currentTransform, n.x, n.y);
            }
        }
        r && (this._objectsToRender = void 0), this._handleEvent(t, "down", {
            alreadySelected: s
        }), r && this.requestRenderAll();
    }
    _resetTransformEventData() {
        this._targetInfo = this._viewportPoint = this._scenePoint = void 0;
    }
    _cacheTransformEventData(t) {
        this._resetTransformEventData(), this._viewportPoint = this.getViewportPoint(t), this._scenePoint = xe(this._viewportPoint, void 0, this.viewportTransform), this._targetInfo = this.findTarget(t), this._currentTransform && (this._targetInfo.target = this._currentTransform.target);
    }
    __onMouseMove(t) {
        if (this._isClick = !1, this._handleEvent(t, "move:before"), this.isDrawingMode) return void this._onMouseMoveInDrawingMode(t);
        if (!this._isMainEvent(t)) return;
        const e = this._groupSelector;
        if (e) {
            const s = this.getScenePoint(t);
            e.deltaX = s.x - e.x, e.deltaY = s.y - e.y, this.renderTop();
        } else if (this._currentTransform) this._transformObject(t);
        else {
            const { target: e } = this.findTarget(t);
            this._setCursorFromEvent(t, e), this._fireOverOutEvents(t, e);
        }
        this.textEditingManager.onMouseMove(t), this._handleEvent(t, "move");
    }
    _fireOverOutEvents(t, e) {
        const { _hoveredTarget: s, _hoveredTargets: i } = this, { subTargets: r } = this.findTarget(t), n = Math.max(i.length, r.length);
        this.fireSyntheticInOutEvents("mouse", {
            e: t,
            target: e,
            oldTarget: s,
            fireCanvas: !0
        });
        for(let o = 0; o < n; o++)r[o] === e || i[o] && i[o] === s || this.fireSyntheticInOutEvents("mouse", {
            e: t,
            target: r[o],
            oldTarget: i[o]
        });
        this._hoveredTarget = e, this._hoveredTargets = r;
    }
    _fireEnterLeaveEvents(t, e, s) {
        const i = this._draggedoverTarget, r = this._hoveredTargets, { subTargets: n } = this.findTarget(t), o = Math.max(r.length, n.length);
        this.fireSyntheticInOutEvents("drag", {
            ...s,
            target: e,
            oldTarget: i,
            fireCanvas: !0
        });
        for(let t = 0; t < o; t++)this.fireSyntheticInOutEvents("drag", {
            ...s,
            target: n[t],
            oldTarget: r[t]
        });
        this._draggedoverTarget = e;
    }
    fireSyntheticInOutEvents(t, e) {
        let { target: s, oldTarget: i, fireCanvas: r, e: n, ...o } = e;
        const { targetIn: a, targetOut: h, canvasIn: l, canvasOut: c } = Dn[t], u = i !== s;
        if (i && u) {
            const t = {
                ...o,
                e: n,
                target: i,
                nextTarget: s,
                ...Tn(this, n)
            };
            r && this.fire(c, t), i.fire(h, t);
        }
        if (s && u) {
            const t = {
                ...o,
                e: n,
                target: s,
                previousTarget: i,
                ...Tn(this, n)
            };
            r && this.fire(l, t), s.fire(a, t);
        }
    }
    _transformObject(t) {
        const e = this.getScenePoint(t), s = this._currentTransform, i = s.target, r = i.group ? xe(e, void 0, i.group.calcTransformMatrix()) : e;
        s.shiftKey = t.shiftKey, s.altKey = !!this.centeredKey && t[this.centeredKey], this._performTransformAction(t, s, r), s.actionPerformed && this.requestRenderAll();
    }
    _performTransformAction(t, e, s) {
        const { action: i, actionHandler: r, target: n } = e, o = !!r && r(t, e, s.x, s.y);
        o && n.setCoords(), "drag" === i && o && (e.target.isMoving = !0, this.setCursor(e.target.moveCursor || this.moveCursor)), e.actionPerformed = e.actionPerformed || o;
    }
    _setCursorFromEvent(t, e) {
        if (!e) return void this.setCursor(this.defaultCursor);
        let s = e.hoverCursor || this.hoverCursor;
        const i = Nt(this._activeObject) ? this._activeObject : null, r = (!i || e.group !== i) && e.findControl(this.getViewportPoint(t));
        if (r) {
            const { control: s, coord: i } = r;
            this.setCursor(s.cursorStyleHandler(t, s, e, i));
        } else {
            if (e.subTargetCheck) {
                const { subTargets: e } = this.findTarget(t);
                e.concat().reverse().forEach((t)=>{
                    s = t.hoverCursor || s;
                });
            }
            this.setCursor(s);
        }
    }
    handleMultiSelection(t, e) {
        const s = this._activeObject, i = Nt(s);
        if (s && this._isSelectionKeyPressed(t) && this.selection && e && e.selectable && (s !== e || i) && (i || !e.isDescendantOf(s) && !s.isDescendantOf(e)) && !e.onSelect({
            e: t
        }) && !s.getActiveControl()) {
            if (i) {
                const i = s.getObjects();
                let r = [];
                if (e === s) {
                    const s = this.getScenePoint(t);
                    let n = this.searchPossibleTargets(i, s);
                    if (n.target ? (e = n.target, r = n.subTargets) : (n = this.searchPossibleTargets(this._objects, s), e = n.target, r = n.subTargets), !e || !e.selectable) return !1;
                }
                e.group === s ? (s.remove(e), this._hoveredTarget = e, this._hoveredTargets = r, 1 === s.size() && this._setActiveObject(s.item(0), t)) : (s.multiSelectAdd(e), this._hoveredTarget = s, this._hoveredTargets = r), this._fireSelectionEvents(i, t);
            } else {
                s.isEditing && s.exitEditing();
                const i = new (tt.getClass("ActiveSelection"))([], {
                    canvas: this
                });
                i.multiSelectAdd(s, e), this._hoveredTarget = i, this._setActiveObject(i, t), this._fireSelectionEvents([
                    s
                ], t);
            }
            return !0;
        }
        return !1;
    }
    handleSelection(t) {
        if (!this.selection || !this._groupSelector) return !1;
        const { x: e, y: s, deltaX: i, deltaY: r } = this._groupSelector, n = new ot(e, s), o = n.add(new ot(i, r)), a = n.min(o), h = n.max(o).subtract(a), l = this.collectObjects({
            left: a.x,
            top: a.y,
            width: h.x,
            height: h.y
        }, {
            includeIntersecting: !this.selectionFullyContained
        }), c = n.eq(o) ? l[0] ? [
            l[0]
        ] : [] : l.length > 1 ? l.filter((e)=>!e.onSelect({
                e: t
            })).reverse() : l;
        if (1 === c.length) this.setActiveObject(c[0], t);
        else if (c.length > 1) {
            const e = tt.getClass("ActiveSelection");
            this.setActiveObject(new e(c, {
                canvas: this
            }), t);
        }
        return this._groupSelector = null, !0;
    }
    toCanvasElement() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, e = arguments.length > 1 ? arguments[1] : void 0;
        const { upper: s } = this.elements;
        s.ctx = void 0;
        const i = super.toCanvasElement(t, e);
        return s.ctx = s.el.getContext("2d"), i;
    }
    clear() {
        this.textEditingManager.clear(), super.clear();
    }
    destroy() {
        this.removeListeners(), this.textEditingManager.dispose(), super.destroy();
    }
}
const Pn = {
    x1: 0,
    y1: 0,
    x2: 0,
    y2: 0
}, En = {
    ...Pn,
    r1: 0,
    r2: 0
}, An = (t, e)=>isNaN(t) && "number" == typeof e ? e : t;
function jn(t) {
    return t && /%$/.test(t) && Number.isFinite(parseFloat(t));
}
function Fn(t, e) {
    const s = "number" == typeof t ? t : "string" == typeof t ? parseFloat(t) / (jn(t) ? 100 : 1) : NaN;
    return Ds(0, An(s, e), 1);
}
const Ln = /\s*;\s*/, Bn = /\s*:\s*/;
function Rn(t, e) {
    let s, i;
    const r = t.getAttribute("style");
    if (r) {
        const t = r.split(Ln);
        "" === t[t.length - 1] && t.pop();
        for(let e = t.length; e--;){
            const [r, n] = t[e].split(Bn).map((t)=>t.trim());
            "stop-color" === r ? s = n : "stop-opacity" === r && (i = n);
        }
    }
    s = s || t.getAttribute("stop-color") || "rgb(0,0,0)", i = An(parseFloat(i || t.getAttribute("stop-opacity") || ""), 1);
    const n = new Je(s);
    return n.setAlpha(n.getAlpha() * i * e), {
        offset: Fn(t.getAttribute("offset"), 0),
        color: n.toRgba()
    };
}
function In(t, e) {
    const s = [], i = t.getElementsByTagName("stop"), r = Fn(e, 1);
    for(let t = i.length; t--;)s.push(Rn(i[t], r));
    return s;
}
function $n(t) {
    return "linearGradient" === t.nodeName || "LINEARGRADIENT" === t.nodeName ? "linear" : "radial";
}
function Xn(t) {
    return "userSpaceOnUse" === t.getAttribute("gradientUnits") ? "pixels" : "percentage";
}
function Yn(t, e) {
    return t.getAttribute(e);
}
function Wn(t, e) {
    return function(t, e) {
        let s, { width: i, height: r, gradientUnits: n } = e;
        return Object.entries(t).reduce((t, e)=>{
            let [o, a] = e;
            if ("Infinity" === a) s = 1;
            else if ("-Infinity" === a) s = 0;
            else {
                const t = "string" == typeof a;
                s = t ? parseFloat(a) : a, t && jn(a) && (s *= .01, "pixels" === n && ("x1" !== o && "x2" !== o && "r2" !== o || (s *= i), "y1" !== o && "y2" !== o || (s *= r)));
            }
            return t[o] = s, t;
        }, {});
    }("linear" === $n(t) ? function(t) {
        return {
            x1: Yn(t, "x1") || 0,
            y1: Yn(t, "y1") || 0,
            x2: Yn(t, "x2") || "100%",
            y2: Yn(t, "y2") || 0
        };
    }(t) : function(t) {
        return {
            x1: Yn(t, "fx") || Yn(t, "cx") || "50%",
            y1: Yn(t, "fy") || Yn(t, "cy") || "50%",
            r1: 0,
            x2: Yn(t, "cx") || "50%",
            y2: Yn(t, "cy") || "50%",
            r2: Yn(t, "r") || "50%"
        };
    }(t), {
        ...e,
        gradientUnits: Xn(t)
    });
}
class Vn {
    constructor(t){
        const { type: e = "linear", gradientUnits: s = "pixels", coords: i = {}, colorStops: r = [], offsetX: n = 0, offsetY: o = 0, gradientTransform: a, id: h } = t || {};
        Object.assign(this, {
            type: e,
            gradientUnits: s,
            coords: {
                ..."radial" === e ? En : Pn,
                ...i
            },
            colorStops: r,
            offsetX: n,
            offsetY: o,
            gradientTransform: a,
            id: h ? `${h}_${ft()}` : ft()
        });
    }
    addColorStop(t) {
        for(const e in t)this.colorStops.push({
            offset: parseFloat(e),
            color: t[e]
        });
        return this;
    }
    toObject(t) {
        return {
            ...Xt(this, t),
            type: this.type,
            coords: {
                ...this.coords
            },
            colorStops: this.colorStops.map((t)=>({
                    ...t
                })),
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            gradientUnits: this.gradientUnits,
            gradientTransform: this.gradientTransform ? [
                ...this.gradientTransform
            ] : void 0
        };
    }
    toSVG(t) {
        let { additionalTransform: e } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const s = [], i = this.gradientTransform ? this.gradientTransform.concat() : b.concat(), r = "pixels" === this.gradientUnits ? "userSpaceOnUse" : "objectBoundingBox", n = this.colorStops.map((t)=>({
                ...t
            })).sort((t, e)=>t.offset - e.offset);
        let o = -this.offsetX, a = -this.offsetY;
        var h;
        "objectBoundingBox" === r ? (o /= t.width, a /= t.height) : (o += t.width / 2, a += t.height / 2), (h = t) && "function" == typeof h._renderPathCommands && "percentage" !== this.gradientUnits && (o -= t.pathOffset.x, a -= t.pathOffset.y), i[4] -= o, i[5] -= a;
        const l = [
            `id="SVGID_${se(String(this.id))}"`,
            `gradientUnits="${r}"`,
            `gradientTransform="${e ? e + " " : ""}${Vt(i)}"`,
            ""
        ].join(" "), c = (t)=>parseFloat(String(t));
        if ("linear" === this.type) {
            const { x1: t, y1: e, x2: i, y2: r } = this.coords, n = c(t), o = c(e), a = c(i), h = c(r);
            s.push("<linearGradient ", l, ' x1="', n, '" y1="', o, '" x2="', a, '" y2="', h, '">\n');
        } else if ("radial" === this.type) {
            const { x1: t, y1: e, x2: i, y2: r, r1: o, r2: a } = this.coords, h = c(t), u = c(e), d = c(i), g = c(r), f = c(o), p = c(a), m = f > p;
            s.push("<radialGradient ", l, ' cx="', m ? h : d, '" cy="', m ? u : g, '" r="', m ? f : p, '" fx="', m ? d : h, '" fy="', m ? g : u, '">\n'), m && (n.reverse(), n.forEach((t)=>{
                t.offset = 1 - t.offset;
            }));
            const v = Math.min(f, p);
            if (v > 0) {
                const t = v / Math.max(f, p);
                n.forEach((e)=>{
                    e.offset += t * (1 - e.offset);
                });
            }
        }
        return n.forEach((t)=>{
            let { color: e, offset: i } = t;
            s.push(`<stop offset="${100 * i}%" style="stop-color:${e};"/>\n`);
        }), s.push("linear" === this.type ? "</linearGradient>" : "</radialGradient>", "\n"), s.join("");
    }
    toLive(t) {
        const { x1: e, y1: s, x2: i, y2: r, r1: n, r2: o } = this.coords, a = "linear" === this.type ? t.createLinearGradient(e, s, i, r) : t.createRadialGradient(e, s, n, i, r, o);
        return this.colorStops.forEach((t)=>{
            let { color: e, offset: s } = t;
            a.addColorStop(s, e);
        }), a;
    }
    static async fromObject(t) {
        const { colorStops: e, gradientTransform: s } = t;
        return new this({
            ...t,
            colorStops: e ? e.map((t)=>({
                    ...t
                })) : void 0,
            gradientTransform: s ? [
                ...s
            ] : void 0
        });
    }
    static fromElement(t, e, s) {
        const i = Xn(t), r = e._findCenterFromElement();
        return new this({
            id: t.getAttribute("id") || void 0,
            type: $n(t),
            coords: Wn(t, {
                width: s.viewBoxWidth || s.width,
                height: s.viewBoxHeight || s.height
            }),
            colorStops: In(t, s.opacity),
            gradientUnits: i,
            gradientTransform: hr(t.getAttribute("gradientTransform") || ""),
            ..."pixels" === i ? {
                offsetX: e.width / 2 - r.x,
                offsetY: e.height / 2 - r.y
            } : {
                offsetX: 0,
                offsetY: 0
            }
        });
    }
}
t(Vn, "type", "Gradient"), tt.setClass(Vn, "gradient"), tt.setClass(Vn, "linear"), tt.setClass(Vn, "radial");
class zn {
    get type() {
        return "pattern";
    }
    set type(t) {
        i("warn", "Setting type has no effect", t);
    }
    constructor(e){
        t(this, "repeat", "repeat"), t(this, "offsetX", 0), t(this, "offsetY", 0), t(this, "crossOrigin", ""), this.id = ft(), Object.assign(this, e);
    }
    isImageSource() {
        return !!this.source && "string" == typeof this.source.src;
    }
    isCanvasSource() {
        return !!this.source && !!this.source.toDataURL;
    }
    sourceToString() {
        return this.isImageSource() ? this.source.src : this.isCanvasSource() ? this.source.toDataURL() : "";
    }
    toLive(t) {
        return this.source && (!this.isImageSource() || this.source.complete && 0 !== this.source.naturalWidth && 0 !== this.source.naturalHeight) ? t.createPattern(this.source, this.repeat) : null;
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        const { repeat: e, crossOrigin: i } = this;
        return {
            ...Xt(this, t),
            type: "pattern",
            source: this.sourceToString(),
            repeat: e,
            crossOrigin: i,
            offsetX: Wt(this.offsetX, s.NUM_FRACTION_DIGITS),
            offsetY: Wt(this.offsetY, s.NUM_FRACTION_DIGITS),
            patternTransform: this.patternTransform ? [
                ...this.patternTransform
            ] : null
        };
    }
    toSVG(t) {
        let { width: e, height: s } = t;
        const { source: i, repeat: r, id: n } = this, o = An(this.offsetX / e, 0), a = An(this.offsetY / s, 0), h = "repeat-y" === r || "no-repeat" === r ? 1 + Math.abs(o || 0) : An(i.width / e, 0), l = "repeat-x" === r || "no-repeat" === r ? 1 + Math.abs(a || 0) : An(i.height / s, 0);
        return [
            `<pattern id="SVGID_${se(n)}" x="${o}" y="${a}" width="${h}" height="${l}">`,
            `<image x="0" y="0" width="${i.width}" height="${i.height}" xlink:href="${se(this.sourceToString())}"></image>`,
            "</pattern>",
            ""
        ].join("\n");
    }
    static async fromObject(t, e) {
        let { type: s, source: i, patternTransform: r, ...n } = t;
        const o = await Rt(i, {
            ...e,
            crossOrigin: n.crossOrigin
        });
        return new this({
            ...n,
            patternTransform: r && r.slice(0),
            source: o
        });
    }
}
t(zn, "type", "Pattern"), tt.setClass(zn), tt.setClass(zn, "pattern");
class Gn {
    constructor(e){
        t(this, "color", "rgb(0, 0, 0)"), t(this, "width", 1), t(this, "shadow", null), t(this, "strokeLineCap", "round"), t(this, "strokeLineJoin", "round"), t(this, "strokeMiterLimit", 10), t(this, "strokeDashArray", null), t(this, "limitedToCanvasSize", !1), this.canvas = e;
    }
    _setBrushStyles(t) {
        t.strokeStyle = this.color, t.lineWidth = this.width, t.lineCap = this.strokeLineCap, t.miterLimit = this.strokeMiterLimit, t.lineJoin = this.strokeLineJoin, t.setLineDash(this.strokeDashArray || []);
    }
    _saveAndTransform(t) {
        const e = this.canvas.viewportTransform;
        t.save(), t.transform(e[0], e[1], e[2], e[3], e[4], e[5]);
    }
    needsFullRender() {
        return new Je(this.color).getAlpha() < 1 || !!this.shadow;
    }
    _setShadow() {
        if (!this.shadow || !this.canvas) return;
        const t = this.canvas, e = this.shadow, s = t.contextTop, i = t.getZoom() * t.getRetinaScaling();
        s.shadowColor = e.color, s.shadowBlur = e.blur * i, s.shadowOffsetX = e.offsetX * i, s.shadowOffsetY = e.offsetY * i;
    }
    _resetShadow() {
        const t = this.canvas.contextTop;
        t.shadowColor = "", t.shadowBlur = t.shadowOffsetX = t.shadowOffsetY = 0;
    }
    _isOutSideCanvas(t) {
        return t.x < 0 || t.x > this.canvas.getWidth() || t.y < 0 || t.y > this.canvas.getHeight();
    }
}
class Hn extends ji {
    constructor(t){
        let { path: e, left: s, top: i, ...r } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), Object.assign(this, Hn.ownDefaults), this.setOptions(r), this._setPath(t || [], !0), "number" == typeof s && this.set(O, s), "number" == typeof i && this.set(k, i);
    }
    _setPath(t, e) {
        this.path = Rr(Array.isArray(t) ? t : tn(t)), this.setBoundingBox(e);
    }
    _findCenterFromElement() {
        const t = this._calcBoundsFromPath();
        return new ot(t.left + t.width / 2, t.top + t.height / 2);
    }
    _renderPathCommands(t) {
        const e = -this.pathOffset.x, s = -this.pathOffset.y;
        t.beginPath();
        for (const i of this.path)switch(i[0]){
            case "L":
                t.lineTo(i[1] + e, i[2] + s);
                break;
            case "M":
                t.moveTo(i[1] + e, i[2] + s);
                break;
            case "C":
                t.bezierCurveTo(i[1] + e, i[2] + s, i[3] + e, i[4] + s, i[5] + e, i[6] + s);
                break;
            case "Q":
                t.quadraticCurveTo(i[1] + e, i[2] + s, i[3] + e, i[4] + s);
                break;
            case "Z":
                t.closePath();
        }
    }
    _render(t) {
        this._renderPathCommands(t), this._renderPaintInOrder(t);
    }
    toString() {
        return `#<Path (${this.complexity()}): { "top": ${this.top}, "left": ${this.left} }>`;
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
            ...super.toObject(t),
            path: this.path.map((t)=>t.slice())
        };
    }
    toDatalessObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        const e = this.toObject(t);
        return this.sourcePath && (delete e.path, e.sourcePath = this.sourcePath), e;
    }
    _toSVG() {
        return [
            "<path ",
            "COMMON_PARTS",
            `d="${sn(this.path, s.NUM_FRACTION_DIGITS)}" stroke-linecap="round" />\n`
        ];
    }
    _getOffsetTransform() {
        const t = s.NUM_FRACTION_DIGITS;
        return ` translate(${Wt(-this.pathOffset.x, t)}, ${Wt(-this.pathOffset.y, t)})`;
    }
    toClipPathSVG(t) {
        const e = this._getOffsetTransform();
        return "\t" + this._createBaseClipPathSVGMarkup(this._toSVG(), {
            reviver: t,
            additionalTransform: e
        });
    }
    toSVG(t) {
        const e = this._getOffsetTransform();
        return this._createBaseSVGMarkup(this._toSVG(), {
            reviver: t,
            additionalTransform: e
        });
    }
    complexity() {
        return this.path.length;
    }
    setDimensions() {
        this.setBoundingBox();
    }
    setBoundingBox(t) {
        const { width: e, height: s, pathOffset: i } = this._calcDimensions();
        this.set({
            width: e,
            height: s,
            pathOffset: i
        }), t && this.setPositionByOrigin(i, T, T);
    }
    _calcBoundsFromPath() {
        const t = [];
        let e = 0, s = 0, i = 0, r = 0;
        for (const n of this.path)switch(n[0]){
            case "L":
                i = n[1], r = n[2], t.push({
                    x: e,
                    y: s
                }, {
                    x: i,
                    y: r
                });
                break;
            case "M":
                i = n[1], r = n[2], e = i, s = r;
                break;
            case "C":
                t.push(...Lr(i, r, n[1], n[2], n[3], n[4], n[5], n[6])), i = n[5], r = n[6];
                break;
            case "Q":
                t.push(...Lr(i, r, n[1], n[2], n[1], n[2], n[3], n[4])), i = n[3], r = n[4];
                break;
            case "Z":
                i = e, r = s;
        }
        return ge(t);
    }
    _calcDimensions() {
        const t = this._calcBoundsFromPath();
        return {
            ...t,
            pathOffset: new ot(t.left + t.width / 2, t.top + t.height / 2)
        };
    }
    static fromObject(t) {
        return this._fromObject(t, {
            extraParam: "path"
        });
    }
    static async fromElement(t, e, s) {
        const { d: i, ...r } = gr(t, this.ATTRIBUTE_NAMES, s);
        return new this(i, {
            ...r,
            ...e,
            left: void 0,
            top: void 0
        });
    }
}
t(Hn, "type", "Path"), t(Hn, "cacheProperties", [
    ...Ps,
    "path",
    "fillRule"
]), t(Hn, "ATTRIBUTE_NAMES", [
    ...zi,
    "d"
]), tt.setClass(Hn), tt.setSVGClass(Hn);
class Nn extends Gn {
    constructor(e){
        super(e), t(this, "decimate", .4), t(this, "drawStraightLine", !1), t(this, "straightLineKey", "shiftKey"), this._points = [], this._hasStraightLine = !1;
    }
    needsFullRender() {
        return super.needsFullRender() || this._hasStraightLine;
    }
    static drawSegment(t, e, s) {
        const i = e.midPointFrom(s);
        return t.quadraticCurveTo(e.x, e.y, i.x, i.y), i;
    }
    onMouseDown(t, e) {
        let { e: s } = e;
        this.canvas._isMainEvent(s) && (this.drawStraightLine = !!this.straightLineKey && s[this.straightLineKey], this._prepareForDrawing(t), this._addPoint(t), this._render());
    }
    onMouseMove(t, e) {
        let { e: s } = e;
        if (this.canvas._isMainEvent(s) && (this.drawStraightLine = !!this.straightLineKey && s[this.straightLineKey], (!0 !== this.limitedToCanvasSize || !this._isOutSideCanvas(t)) && this._addPoint(t) && this._points.length > 1)) if (this.needsFullRender()) this.canvas.clearContext(this.canvas.contextTop), this._render();
        else {
            const t = this._points, e = t.length, s = this.canvas.contextTop;
            this._saveAndTransform(s), this.oldEnd && (s.beginPath(), s.moveTo(this.oldEnd.x, this.oldEnd.y)), this.oldEnd = Nn.drawSegment(s, t[e - 2], t[e - 1]), s.stroke(), s.restore();
        }
    }
    onMouseUp(t) {
        let { e: e } = t;
        return !this.canvas._isMainEvent(e) || (this.drawStraightLine = !1, this.oldEnd = void 0, this._finalizeAndAddPath(), !1);
    }
    _prepareForDrawing(t) {
        this._reset(), this._addPoint(t), this.canvas.contextTop.moveTo(t.x, t.y);
    }
    _addPoint(t) {
        return !(this._points.length > 1 && t.eq(this._points[this._points.length - 1])) && (this.drawStraightLine && this._points.length > 1 && (this._hasStraightLine = !0, this._points.pop()), this._points.push(t), !0);
    }
    _reset() {
        this._points = [], this._setBrushStyles(this.canvas.contextTop), this._setShadow(), this._hasStraightLine = !1;
    }
    _render() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.canvas.contextTop, e = this._points[0], s = this._points[1];
        if (this._saveAndTransform(t), t.beginPath(), 2 === this._points.length && e.x === s.x && e.y === s.y) {
            const t = this.width / 1e3;
            e.x -= t, s.x += t;
        }
        t.moveTo(e.x, e.y);
        for(let i = 1; i < this._points.length; i++)Nn.drawSegment(t, e, s), e = this._points[i], s = this._points[i + 1];
        t.lineTo(e.x, e.y), t.stroke(), t.restore();
    }
    convertPointsToSVGPath(t) {
        const e = this.width / 1e3;
        return en(t, e);
    }
    createPath(t) {
        const e = new Hn(t, {
            fill: null,
            stroke: this.color,
            strokeWidth: this.width,
            strokeLineCap: this.strokeLineCap,
            strokeMiterLimit: this.strokeMiterLimit,
            strokeLineJoin: this.strokeLineJoin,
            strokeDashArray: this.strokeDashArray
        });
        return this.shadow && (this.shadow.affectStroke = !0, e.shadow = new ks(this.shadow)), e;
    }
    decimatePoints(t, e) {
        if (t.length <= 2) return t;
        let s, i = t[0];
        const r = this.canvas.getZoom(), n = Math.pow(e / r, 2), o = t.length - 1, a = [
            i
        ];
        for(let e = 1; e < o - 1; e++)s = Math.pow(i.x - t[e].x, 2) + Math.pow(i.y - t[e].y, 2), s >= n && (i = t[e], a.push(i));
        return a.push(t[o]), a;
    }
    _finalizeAndAddPath() {
        this.canvas.contextTop.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate));
        const t = this.convertPointsToSVGPath(this._points);
        if (function(t) {
            return "M 0 0 Q 0 0 0 0 L 0 0" === sn(t);
        }(t)) return void this.canvas.requestRenderAll();
        const e = this.createPath(t);
        this.canvas.clearContext(this.canvas.contextTop), this.canvas.fire("before:path:created", {
            path: e
        }), this.canvas.add(e), this.canvas.requestRenderAll(), e.setCoords(), this._resetShadow(), this.canvas.fire("path:created", {
            path: e
        });
    }
}
const Un = [
    "radius",
    "startAngle",
    "endAngle",
    "counterClockwise"
];
class qn extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...qn.ownDefaults
        };
    }
    constructor(t){
        super(), Object.assign(this, qn.ownDefaults), this.setOptions(t);
    }
    _set(t, e) {
        return super._set(t, e), "radius" === t && this.setRadius(e), this;
    }
    _render(t) {
        t.beginPath(), t.arc(0, 0, this.radius, xt(this.startAngle), xt(this.endAngle), this.counterClockwise), this._renderPaintInOrder(t);
    }
    getRadiusX() {
        return this.get("radius") * this.get(W);
    }
    getRadiusY() {
        return this.get("radius") * this.get(V);
    }
    setRadius(t) {
        this.radius = t, this.set({
            width: 2 * t,
            height: 2 * t
        });
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return super.toObject([
            ...Un,
            ...t
        ]);
    }
    _toSVG() {
        const { radius: t, startAngle: e, endAngle: s } = this, i = (s - e) % 360;
        if (0 === i) return [
            "<circle ",
            "COMMON_PARTS",
            'cx="0" cy="0" ',
            'r="',
            `${se(t)}`,
            '" />\n'
        ];
        {
            const r = xt(e), n = xt(s), o = rt(r) * t, a = nt(r) * t, h = rt(n) * t, l = nt(n) * t;
            return [
                `<path d="M ${o} ${a} A ${t} ${t} 0 ${i > 180 ? 1 : 0} ${this.counterClockwise ? 0 : 1} ${h} ${l}" `,
                "COMMON_PARTS",
                " />\n"
            ];
        }
    }
    static async fromElement(t, e, s) {
        const { left: i = 0, top: r = 0, radius: n = 0, ...o } = gr(t, this.ATTRIBUTE_NAMES, s);
        return new this({
            ...o,
            radius: n,
            left: i - n,
            top: r - n
        });
    }
    static fromObject(t) {
        return super._fromObject(t);
    }
}
t(qn, "type", "Circle"), t(qn, "cacheProperties", [
    ...Ps,
    ...Un
]), t(qn, "ownDefaults", {
    radius: 0,
    startAngle: 0,
    endAngle: 360,
    counterClockwise: !1
}), t(qn, "ATTRIBUTE_NAMES", [
    "cx",
    "cy",
    "r",
    ...zi
]), tt.setClass(qn), tt.setSVGClass(qn);
class Kn extends Gn {
    constructor(e){
        super(e), t(this, "width", 10), this.points = [];
    }
    drawDot(t) {
        const e = this.addPoint(t), s = this.canvas.contextTop;
        this._saveAndTransform(s), this.dot(s, e), s.restore();
    }
    dot(t, e) {
        t.fillStyle = e.fill, t.beginPath(), t.arc(e.x, e.y, e.radius, 0, 2 * Math.PI, !1), t.closePath(), t.fill();
    }
    onMouseDown(t) {
        this.points = [], this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.drawDot(t);
    }
    _render() {
        const t = this.canvas.contextTop, e = this.points;
        this._saveAndTransform(t);
        for(let s = 0; s < e.length; s++)this.dot(t, e[s]);
        t.restore();
    }
    onMouseMove(t) {
        !0 === this.limitedToCanvasSize && this._isOutSideCanvas(t) || (this.needsFullRender() ? (this.canvas.clearContext(this.canvas.contextTop), this.addPoint(t), this._render()) : this.drawDot(t));
    }
    onMouseUp() {
        const t = this.canvas.renderOnAddRemove;
        this.canvas.renderOnAddRemove = !1;
        const e = [];
        for(let t = 0; t < this.points.length; t++){
            const s = this.points[t], i = new qn({
                radius: s.radius,
                left: s.x,
                top: s.y,
                originX: T,
                originY: T,
                fill: s.fill
            });
            this.shadow && (i.shadow = new ks(this.shadow)), e.push(i);
        }
        const s = new Or(e, {
            canvas: this.canvas
        });
        this.canvas.fire("before:path:created", {
            path: s
        }), this.canvas.add(s), this.canvas.fire("path:created", {
            path: s
        }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = t, this.canvas.requestRenderAll();
    }
    addPoint(t) {
        let { x: e, y: s } = t;
        const i = {
            x: e,
            y: s,
            radius: rn(Math.max(0, this.width - 20), this.width + 20) / 2,
            fill: new Je(this.color).setAlpha(rn(0, 100) / 100).toRgba()
        };
        return this.points.push(i), i;
    }
}
class Jn extends Gn {
    constructor(e){
        super(e), t(this, "width", 10), t(this, "density", 20), t(this, "dotWidth", 1), t(this, "dotWidthVariance", 1), t(this, "randomOpacity", !1), t(this, "optimizeOverlapping", !0), this.sprayChunks = [], this.sprayChunk = [];
    }
    onMouseDown(t) {
        this.sprayChunks = [], this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.addSprayChunk(t), this.renderChunck(this.sprayChunk);
    }
    onMouseMove(t) {
        !0 === this.limitedToCanvasSize && this._isOutSideCanvas(t) || (this.addSprayChunk(t), this.renderChunck(this.sprayChunk));
    }
    onMouseUp() {
        const t = this.canvas.renderOnAddRemove;
        this.canvas.renderOnAddRemove = !1;
        const e = [];
        for(let t = 0; t < this.sprayChunks.length; t++){
            const s = this.sprayChunks[t];
            for(let t = 0; t < s.length; t++){
                const i = s[t], r = new pr({
                    width: i.width,
                    height: i.width,
                    left: i.x + 1,
                    top: i.y + 1,
                    originX: T,
                    originY: T,
                    fill: this.color
                });
                e.push(r);
            }
        }
        const s = new Or(this.optimizeOverlapping ? function(t) {
            const e = {}, s = [];
            for(let i, r = 0; r < t.length; r++)i = `${t[r].left}${t[r].top}`, e[i] || (e[i] = !0, s.push(t[r]));
            return s;
        }(e) : e, {
            objectCaching: !0,
            subTargetCheck: !1,
            interactive: !1
        });
        this.shadow && s.set("shadow", new ks(this.shadow)), this.canvas.fire("before:path:created", {
            path: s
        }), this.canvas.add(s), this.canvas.fire("path:created", {
            path: s
        }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = t, this.canvas.requestRenderAll();
    }
    renderChunck(t) {
        const e = this.canvas.contextTop;
        e.fillStyle = this.color, this._saveAndTransform(e);
        for(let s = 0; s < t.length; s++){
            const i = t[s];
            e.globalAlpha = i.opacity, e.fillRect(i.x, i.y, i.width, i.width);
        }
        e.restore();
    }
    _render() {
        const t = this.canvas.contextTop;
        t.fillStyle = this.color, this._saveAndTransform(t);
        for(let t = 0; t < this.sprayChunks.length; t++)this.renderChunck(this.sprayChunks[t]);
        t.restore();
    }
    addSprayChunk(t) {
        this.sprayChunk = [];
        const e = this.width / 2;
        for(let s = 0; s < this.density; s++)this.sprayChunk.push({
            x: rn(t.x - e, t.x + e),
            y: rn(t.y - e, t.y + e),
            width: this.dotWidthVariance ? rn(Math.max(1, this.dotWidth - this.dotWidthVariance), this.dotWidth + this.dotWidthVariance) : this.dotWidth,
            opacity: this.randomOpacity ? rn(0, 100) / 100 : 1
        });
        this.sprayChunks.push(this.sprayChunk);
    }
}
class Qn extends Nn {
    constructor(t){
        super(t);
    }
    getPatternSrc() {
        const t = pt(), e = t.getContext("2d");
        return t.width = t.height = 25, e && (e.fillStyle = this.color, e.beginPath(), e.arc(10, 10, 10, 0, 2 * Math.PI, !1), e.closePath(), e.fill()), t;
    }
    getPattern(t) {
        return t.createPattern(this.source || this.getPatternSrc(), "repeat");
    }
    _setBrushStyles(t) {
        super._setBrushStyles(t);
        const e = this.getPattern(t);
        e && (t.strokeStyle = e);
    }
    createPath(t) {
        const e = super.createPath(t), s = e._getLeftTopCoords().scalarAdd(e.strokeWidth / 2);
        return e.stroke = new zn({
            source: this.source || this.getPatternSrc(),
            offsetX: -s.x,
            offsetY: -s.y
        }), e;
    }
}
const Zn = [
    "x1",
    "x2",
    "y1",
    "y2"
];
class to extends ji {
    constructor(){
        let [t, e, s, i] = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [
            0,
            0,
            0,
            0
        ], r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), Object.assign(this, to.ownDefaults), this.setOptions(r), this.x1 = t, this.x2 = s, this.y1 = e, this.y2 = i, this._setWidthHeight();
        const { left: n, top: o } = r;
        "number" == typeof n && this.set(O, n), "number" == typeof o && this.set(k, o);
    }
    _setWidthHeight() {
        const { x1: t, y1: e, x2: s, y2: i } = this;
        this.width = Math.abs(s - t), this.height = Math.abs(i - e);
        const { left: r, top: n, width: o, height: a } = ge([
            {
                x: t,
                y: e
            },
            {
                x: s,
                y: i
            }
        ]), h = new ot(r + o / 2, n + a / 2);
        this.setPositionByOrigin(h, T, T);
    }
    _set(t, e) {
        return super._set(t, e), Zn.includes(t) && this._setWidthHeight(), this;
    }
    _render(t) {
        t.beginPath();
        const e = this.calcLinePoints();
        t.moveTo(e.x1, e.y1), t.lineTo(e.x2, e.y2), t.lineWidth = this.strokeWidth;
        const s = t.strokeStyle;
        var i;
        zt(this.stroke) ? t.strokeStyle = this.stroke.toLive(t) : t.strokeStyle = null !== (i = this.stroke) && void 0 !== i ? i : t.fillStyle;
        this.stroke && this._renderStroke(t), t.strokeStyle = s;
    }
    _findCenterFromElement() {
        return new ot((this.x1 + this.x2) / 2, (this.y1 + this.y2) / 2);
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
            ...super.toObject(t),
            ...this.calcLinePoints()
        };
    }
    _getNonTransformedDimensions() {
        const t = super._getNonTransformedDimensions();
        return "butt" === this.strokeLineCap && (0 === this.width && (t.y -= this.strokeWidth), 0 === this.height && (t.x -= this.strokeWidth)), t;
    }
    calcLinePoints() {
        const { x1: t, x2: e, y1: s, y2: i, width: r, height: n } = this, o = t <= e ? -.5 : .5, a = s <= i ? -.5 : .5;
        return {
            x1: o * r,
            x2: o * -r,
            y1: a * n,
            y2: a * -n
        };
    }
    _toSVG() {
        const { x1: t, x2: e, y1: s, y2: i } = this.calcLinePoints();
        return [
            "<line ",
            "COMMON_PARTS",
            `x1="${t}" y1="${s}" x2="${e}" y2="${i}" />\n`
        ];
    }
    static async fromElement(t, e, s) {
        const { x1: i = 0, y1: r = 0, x2: n = 0, y2: o = 0, ...a } = gr(t, this.ATTRIBUTE_NAMES, s);
        return new this([
            i,
            r,
            n,
            o
        ], a);
    }
    static fromObject(t) {
        let { x1: e, y1: s, x2: i, y2: r, ...n } = t;
        return this._fromObject({
            ...n,
            points: [
                e,
                s,
                i,
                r
            ]
        }, {
            extraParam: "points"
        });
    }
}
t(to, "type", "Line"), t(to, "cacheProperties", [
    ...Ps,
    ...Zn
]), t(to, "ATTRIBUTE_NAMES", zi.concat(Zn)), tt.setClass(to), tt.setSVGClass(to);
class eo extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...eo.ownDefaults
        };
    }
    constructor(t){
        super(), Object.assign(this, eo.ownDefaults), this.setOptions(t);
    }
    _render(t) {
        const e = this.width / 2, s = this.height / 2;
        t.beginPath(), t.moveTo(-e, s), t.lineTo(0, -s), t.lineTo(e, s), t.closePath(), this._renderPaintInOrder(t);
    }
    _toSVG() {
        const t = this.width / 2, e = this.height / 2;
        return [
            "<polygon ",
            "COMMON_PARTS",
            'points="',
            `${-t} ${e},0 ${-e},${t} ${e}`,
            '" />'
        ];
    }
}
t(eo, "type", "Triangle"), t(eo, "ownDefaults", {
    width: 100,
    height: 100
}), tt.setClass(eo), tt.setSVGClass(eo);
const so = [
    "rx",
    "ry"
];
class io extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...io.ownDefaults
        };
    }
    constructor(t){
        super(), Object.assign(this, io.ownDefaults), this.setOptions(t);
    }
    _set(t, e) {
        switch(super._set(t, e), t){
            case "rx":
                this.rx = e, this.set("width", 2 * e);
                break;
            case "ry":
                this.ry = e, this.set("height", 2 * e);
        }
        return this;
    }
    getRx() {
        return this.get("rx") * this.get(W);
    }
    getRy() {
        return this.get("ry") * this.get(V);
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return super.toObject([
            ...so,
            ...t
        ]);
    }
    _toSVG() {
        return [
            "<ellipse ",
            "COMMON_PARTS",
            `cx="0" cy="0" rx="${se(this.rx)}" ry="${se(this.ry)}" />\n`
        ];
    }
    _render(t) {
        t.beginPath(), t.save(), t.transform(1, 0, 0, this.ry / this.rx, 0, 0), t.arc(0, 0, this.rx, 0, x, !1), t.restore(), this._renderPaintInOrder(t);
    }
    static async fromElement(t, e, s) {
        const i = gr(t, this.ATTRIBUTE_NAMES, s);
        return i.left = (i.left || 0) - i.rx, i.top = (i.top || 0) - i.ry, new this(i);
    }
}
t(io, "type", "Ellipse"), t(io, "cacheProperties", [
    ...Ps,
    ...so
]), t(io, "ownDefaults", {
    rx: 0,
    ry: 0
}), t(io, "ATTRIBUTE_NAMES", [
    ...zi,
    "cx",
    "cy",
    "rx",
    "ry"
]), tt.setClass(io), tt.setSVGClass(io);
const ro = {
    exactBoundingBox: !1
};
class no extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...no.ownDefaults
        };
    }
    constructor(){
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), t(this, "strokeDiff", void 0), Object.assign(this, no.ownDefaults), this.setOptions(s), this.points = e;
        const { left: i, top: r } = s;
        this.initialized = !0, this.setBoundingBox(!0), "number" == typeof i && this.set(O, i), "number" == typeof r && this.set(k, r);
    }
    isOpen() {
        return !0;
    }
    _projectStrokeOnPoints(t) {
        return $i(this.points, t, this.isOpen());
    }
    _calcDimensions(t) {
        t = {
            scaleX: this.scaleX,
            scaleY: this.scaleY,
            skewX: this.skewX,
            skewY: this.skewY,
            strokeLineCap: this.strokeLineCap,
            strokeLineJoin: this.strokeLineJoin,
            strokeMiterLimit: this.strokeMiterLimit,
            strokeUniform: this.strokeUniform,
            strokeWidth: this.strokeWidth,
            ...t || {}
        };
        const e = this.exactBoundingBox ? this._projectStrokeOnPoints(t).map((t)=>t.projectedPoint) : this.points;
        if (0 === e.length) return {
            left: 0,
            top: 0,
            width: 0,
            height: 0,
            pathOffset: new ot,
            strokeOffset: new ot,
            strokeDiff: new ot
        };
        const s = ge(e), i = Lt({
            ...t,
            scaleX: 1,
            scaleY: 1
        }), r = ge(this.points.map((t)=>St(t, i, !0))), n = new ot(this.scaleX, this.scaleY);
        let o = s.left + s.width / 2, a = s.top + s.height / 2;
        return this.exactBoundingBox && (o -= a * Math.tan(xt(this.skewX)), a -= o * Math.tan(xt(this.skewY))), {
            ...s,
            pathOffset: new ot(o, a),
            strokeOffset: new ot(r.left, r.top).subtract(new ot(s.left, s.top)).multiply(n),
            strokeDiff: new ot(s.width, s.height).subtract(new ot(r.width, r.height)).multiply(n)
        };
    }
    _findCenterFromElement() {
        const t = ge(this.points);
        return new ot(t.left + t.width / 2, t.top + t.height / 2);
    }
    setDimensions() {
        this.setBoundingBox();
    }
    setBoundingBox(t) {
        const { left: e, top: s, width: i, height: r, pathOffset: n, strokeOffset: o, strokeDiff: a } = this._calcDimensions();
        this.set({
            width: i,
            height: r,
            pathOffset: n,
            strokeOffset: o,
            strokeDiff: a
        }), t && this.setPositionByOrigin(new ot(e + i / 2, s + r / 2), T, T);
    }
    isStrokeAccountedForInDimensions() {
        return this.exactBoundingBox;
    }
    _getNonTransformedDimensions() {
        return this.exactBoundingBox ? new ot(this.width, this.height) : super._getNonTransformedDimensions();
    }
    _getTransformedDimensions() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (this.exactBoundingBox) {
            let n;
            if (Object.keys(t).some((t)=>this.strokeUniform || this.constructor.layoutProperties.includes(t))) {
                var e, s;
                const { width: i, height: r } = this._calcDimensions(t);
                n = new ot(null !== (e = t.width) && void 0 !== e ? e : i, null !== (s = t.height) && void 0 !== s ? s : r);
            } else {
                var i, r;
                n = new ot(null !== (i = t.width) && void 0 !== i ? i : this.width, null !== (r = t.height) && void 0 !== r ? r : this.height);
            }
            return n.multiply(new ot(t.scaleX || this.scaleX, t.scaleY || this.scaleY));
        }
        return super._getTransformedDimensions(t);
    }
    _set(t, e) {
        const s = this.initialized && this[t] !== e, i = super._set(t, e);
        return this.exactBoundingBox && s && ((t === W || t === V) && this.strokeUniform && this.constructor.layoutProperties.includes("strokeUniform") || this.constructor.layoutProperties.includes(t)) && this.setDimensions(), i;
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
            ...super.toObject(t),
            points: this.points.map((t)=>{
                let { x: e, y: s } = t;
                return {
                    x: e,
                    y: s
                };
            })
        };
    }
    _toSVG() {
        const t = this.pathOffset.x, e = this.pathOffset.y, i = s.NUM_FRACTION_DIGITS, r = this.points.map((s)=>{
            let { x: r, y: n } = s;
            return `${Wt(r - t, i)},${Wt(n - e, i)}`;
        }).join(" ");
        return [
            `<${se(this.constructor.type).toLowerCase()} `,
            "COMMON_PARTS",
            `points="${r}" />\n`
        ];
    }
    _render(t) {
        const e = this.points.length, s = this.pathOffset.x, i = this.pathOffset.y;
        if (e && !isNaN(this.points[e - 1].y)) {
            t.beginPath(), t.moveTo(this.points[0].x - s, this.points[0].y - i);
            for(let r = 0; r < e; r++){
                const e = this.points[r];
                t.lineTo(e.x - s, e.y - i);
            }
            !this.isOpen() && t.closePath(), this._renderPaintInOrder(t);
        }
    }
    complexity() {
        return this.points.length;
    }
    static async fromElement(t, e, s) {
        const i = function(t) {
            if (!t) return [];
            const e = t.replace(/,/g, " ").trim().split(/\s+/), s = [];
            for(let t = 0; t < e.length; t += 2)s.push({
                x: parseFloat(e[t]),
                y: parseFloat(e[t + 1])
            });
            return s;
        }(t.getAttribute("points")), { left: r, top: n, ...o } = gr(t, this.ATTRIBUTE_NAMES, s);
        return new this(i, {
            ...o,
            ...e
        });
    }
    static fromObject(t) {
        return this._fromObject(t, {
            extraParam: "points"
        });
    }
}
t(no, "ownDefaults", ro), t(no, "type", "Polyline"), t(no, "layoutProperties", [
    z,
    G,
    "strokeLineCap",
    "strokeLineJoin",
    "strokeMiterLimit",
    "strokeWidth",
    "strokeUniform",
    "points"
]), t(no, "cacheProperties", [
    ...Ps,
    "points"
]), t(no, "ATTRIBUTE_NAMES", [
    ...zi
]), tt.setClass(no), tt.setSVGClass(no);
class oo extends no {
    isOpen() {
        return !1;
    }
}
t(oo, "ownDefaults", ro), t(oo, "type", "Polygon"), tt.setClass(oo), tt.setSVGClass(oo);
class ao extends ji {
    isEmptyStyles(t) {
        if (!this.styles) return !0;
        if (void 0 !== t && !this.styles[t]) return !0;
        const e = void 0 === t ? this.styles : {
            line: this.styles[t]
        };
        for(const t in e)for(const s in e[t])for(const i in e[t][s])return !1;
        return !0;
    }
    styleHas(t, e) {
        if (!this.styles) return !1;
        if (void 0 !== e && !this.styles[e]) return !1;
        const s = void 0 === e ? this.styles : {
            0: this.styles[e]
        };
        for(const e in s)for(const i in s[e])if (void 0 !== s[e][i][t]) return !0;
        return !1;
    }
    cleanStyle(t) {
        if (!this.styles) return !1;
        const e = this.styles;
        let s, i, r = 0, n = !0, o = 0;
        for(const o in e){
            s = 0;
            for(const a in e[o]){
                const h = e[o][a] || {};
                r++, void 0 !== h[t] ? (i ? h[t] !== i && (n = !1) : i = h[t], h[t] === this[t] && delete h[t]) : n = !1, 0 !== Object.keys(h).length ? s++ : delete e[o][a];
            }
            0 === s && delete e[o];
        }
        for(let t = 0; t < this._textLines.length; t++)o += this._textLines[t].length;
        n && r === o && (this[t] = i, this.removeStyle(t));
    }
    removeStyle(t) {
        if (!this.styles) return;
        const e = this.styles;
        let s, i, r;
        for(i in e){
            for(r in s = e[i], s)delete s[r][t], 0 === Object.keys(s[r]).length && delete s[r];
            0 === Object.keys(s).length && delete e[i];
        }
    }
    _extendStyles(t, e) {
        const { lineIndex: s, charIndex: i } = this.get2DCursorLocation(t);
        this._getLineStyle(s) || this._setLineStyle(s);
        const r = Yt({
            ...this._getStyleDeclaration(s, i),
            ...e
        }, (t)=>void 0 !== t);
        this._setStyleDeclaration(s, i, r);
    }
    getSelectionStyles(t, e, s) {
        const i = [];
        for(let r = t; r < (e || t); r++)i.push(this.getStyleAtPosition(r, s));
        return i;
    }
    getStyleAtPosition(t, e) {
        const { lineIndex: s, charIndex: i } = this.get2DCursorLocation(t);
        return e ? this.getCompleteStyleDeclaration(s, i) : this._getStyleDeclaration(s, i);
    }
    setSelectionStyles(t, e, s) {
        for(let i = e; i < (s || e); i++)this._extendStyles(i, t);
        this._forceClearCache = !0;
    }
    _getStyleDeclaration(t, e) {
        var s;
        const i = this.styles && this.styles[t];
        return i && null !== (s = i[e]) && void 0 !== s ? s : {};
    }
    getCompleteStyleDeclaration(t, e) {
        return {
            ...Xt(this, this.constructor._styleProperties),
            ...this._getStyleDeclaration(t, e)
        };
    }
    _setStyleDeclaration(t, e, s) {
        this.styles[t][e] = s;
    }
    _deleteStyleDeclaration(t, e) {
        delete this.styles[t][e];
    }
    _getLineStyle(t) {
        return !!this.styles[t];
    }
    _setLineStyle(t) {
        this.styles[t] = {};
    }
    _deleteLineStyle(t) {
        delete this.styles[t];
    }
}
t(ao, "_styleProperties", hs);
const ho = /  +/g, lo = /"/g;
function co(t, e, i, r, n) {
    return `\t\t${function(t, e) {
        let { left: i, top: r, width: n, height: o } = e, a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : s.NUM_FRACTION_DIGITS;
        const h = ts(H, t, !1), [l, c, u, d] = [
            i,
            r,
            n,
            o
        ].map((t)=>Wt(t, a));
        return `<rect ${h} x="${l}" y="${c}" width="${u}" height="${d}"></rect>`;
    }(t, {
        left: e,
        top: i,
        width: r,
        height: n
    })}\n`;
}
let uo;
class go extends ao {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...go.ownDefaults
        };
    }
    constructor(e, s){
        super(), t(this, "__charBounds", []), Object.assign(this, go.ownDefaults), this.setOptions(s), this.styles || (this.styles = {}), this.text = e, this.initialized = !0, this.path && this.setPathInfo(), this.initDimensions(), this.setCoords();
    }
    setPathInfo() {
        const t = this.path;
        t && (t.segmentsInfo = Ur(t.path));
    }
    _splitText() {
        const t = this._splitTextIntoLines(this.text);
        return this.textLines = t.lines, this._textLines = t.graphemeLines, this._unwrappedTextLines = t._unwrappedLines, this._text = t.graphemeText, t;
    }
    initDimensions() {
        this._splitText(), this._clearCache(), this.dirty = !0, this.path ? (this.width = this.path.width, this.height = this.path.height) : (this.width = this.calcTextWidth() || this.cursorWidth || this.MIN_TEXT_WIDTH, this.height = this.calcTextHeight()), this.textAlign.includes(cs) && this.enlargeSpaces();
    }
    enlargeSpaces() {
        let t, e, s, i, r, n, o;
        for(let a = 0, h = this._textLines.length; a < h; a++)if ((this.textAlign === cs || a !== h - 1 && !this.isEndOfWrapping(a)) && (i = 0, r = this._textLines[a], e = this.getLineWidth(a), e < this.width && (o = this.textLines[a].match(this._reSpacesAndTabs)))) {
            s = o.length, t = (this.width - e) / s;
            for(let e = 0; e <= r.length; e++)n = this.__charBounds[a][e], this._reSpaceAndTab.test(r[e]) ? (n.width += t, n.kernedWidth += t, n.left += i, i += t) : n.left += i;
        }
    }
    isEndOfWrapping(t) {
        return t === this._textLines.length - 1;
    }
    missingNewlineOffset(t) {
        return 1;
    }
    get2DCursorLocation(t, e) {
        const s = e ? this._unwrappedTextLines : this._textLines;
        let i;
        for(i = 0; i < s.length; i++){
            if (t <= s[i].length) return {
                lineIndex: i,
                charIndex: t
            };
            t -= s[i].length + this.missingNewlineOffset(i, e);
        }
        return {
            lineIndex: i - 1,
            charIndex: s[i - 1].length < t ? s[i - 1].length : t
        };
    }
    toString() {
        return `#<Text (${this.complexity()}): { "text": "${this.text}", "fontFamily": "${this.fontFamily}" }>`;
    }
    _getCacheCanvasDimensions() {
        const t = super._getCacheCanvasDimensions(), e = this.fontSize;
        return t.width += e * t.zoomX, t.height += e * t.zoomY, t;
    }
    _render(t) {
        const e = this.path;
        e && !e.isNotVisible() && e._render(t), this._setTextStyles(t), this._renderTextLinesBackground(t), this._renderTextDecoration(t, "underline"), this._renderText(t), this._renderTextDecoration(t, "overline"), this._renderTextDecoration(t, "linethrough");
    }
    _renderText(t) {
        this.paintFirst === N ? (this._renderTextStroke(t), this._renderTextFill(t)) : (this._renderTextFill(t), this._renderTextStroke(t));
    }
    _setTextStyles(t, e, s) {
        if (t.textBaseline = "alphabetic", this.path) switch(this.pathAlign){
            case T:
                t.textBaseline = "middle";
                break;
            case "ascender":
                t.textBaseline = k;
                break;
            case "descender":
                t.textBaseline = D;
        }
        t.font = this._getFontDeclaration(e, s);
    }
    calcTextWidth() {
        let t = this.getLineWidth(0);
        for(let e = 1, s = this._textLines.length; e < s; e++){
            const s = this.getLineWidth(e);
            s > t && (t = s);
        }
        return t;
    }
    _renderTextLine(t, e, s, i, r, n) {
        this._renderChars(t, e, s, i, r, n);
    }
    _renderTextLinesBackground(t) {
        if (!this.textBackgroundColor && !this.styleHas("textBackgroundColor")) return;
        const e = t.fillStyle, s = this._getLeftOffset();
        let i = this._getTopOffset();
        for(let e = 0, r = this._textLines.length; e < r; e++){
            const r = this.getHeightOfLine(e);
            if (!this.textBackgroundColor && !this.styleHas("textBackgroundColor", e)) {
                i += r;
                continue;
            }
            const n = this._textLines[e].length, o = this._getLineLeftOffset(e);
            let a, h, l = 0, c = 0, u = this.getValueOfPropertyAt(e, 0, "textBackgroundColor");
            const d = this.getHeightOfLineImpl(e);
            for(let r = 0; r < n; r++){
                const n = this.__charBounds[e][r];
                h = this.getValueOfPropertyAt(e, r, "textBackgroundColor"), this.path ? (t.save(), t.translate(n.renderLeft, n.renderTop), t.rotate(n.angle), t.fillStyle = h, h && t.fillRect(-n.width / 2, -d * (1 - this._fontSizeFraction), n.width, d), t.restore()) : h !== u ? (a = s + o + c, this.direction === K && (a = this.width - a - l), t.fillStyle = u, u && t.fillRect(a, i, l, d), c = n.left, l = n.width, u = h) : l += n.kernedWidth;
            }
            h && !this.path && (a = s + o + c, this.direction === K && (a = this.width - a - l), t.fillStyle = h, t.fillRect(a, i, l, d)), i += r;
        }
        t.fillStyle = e, this._removeShadow(t);
    }
    _measureChar(t, e, s, i) {
        const r = p.getFontCache(e), n = this._getFontDeclaration(e), o = s ? s + t : t, a = s && n === this._getFontDeclaration(i), h = e.fontSize / this.CACHE_FONT_SIZE;
        let l, c, u, d;
        if (s && r.has(s) && (u = r.get(s)), r.has(t) && (d = l = r.get(t)), a && r.has(o) && (c = r.get(o), d = c - u), void 0 === l || void 0 === u || void 0 === c) {
            const i = function() {
                if (!uo) {
                    const t = vt({
                        width: 0,
                        height: 0
                    });
                    uo = t.getContext("2d");
                }
                return uo;
            }();
            this._setTextStyles(i, e, !0), void 0 === l && (d = l = i.measureText(t).width, r.set(t, l)), void 0 === u && a && s && (u = i.measureText(s).width, r.set(s, u)), a && void 0 === c && (c = i.measureText(o).width, r.set(o, c), d = c - u);
        }
        return {
            width: l * h,
            kernedWidth: d * h
        };
    }
    getHeightOfChar(t, e) {
        return this.getValueOfPropertyAt(t, e, "fontSize");
    }
    measureLine(t) {
        const e = this._measureLine(t);
        return 0 !== this.charSpacing && (e.width -= this._getWidthOfCharSpacing()), e.width < 0 && (e.width = 0), e;
    }
    _measureLine(t) {
        let e, s, i = 0;
        const r = this.pathSide === M, n = this.path, o = this._textLines[t], a = o.length, h = new Array(a);
        this.__charBounds[t] = h;
        for(let r = 0; r < a; r++){
            const n = o[r];
            s = this._getGraphemeBox(n, t, r, e), h[r] = s, i += s.kernedWidth, e = n;
        }
        if (h[a] = {
            left: s ? s.left + s.width : 0,
            width: 0,
            kernedWidth: 0,
            height: this.fontSize,
            deltaY: 0
        }, n && n.segmentsInfo) {
            let t = 0;
            const e = n.segmentsInfo[n.segmentsInfo.length - 1].length;
            switch(this.textAlign){
                case O:
                    t = r ? e - i : 0;
                    break;
                case T:
                    t = (e - i) / 2;
                    break;
                case M:
                    t = r ? 0 : e - i;
            }
            t += this.pathStartOffset * (r ? -1 : 1);
            for(let i = r ? a - 1 : 0; r ? i >= 0 : i < a; r ? i-- : i++)s = h[i], t > e ? t %= e : t < 0 && (t += e), this._setGraphemeOnPath(t, s), t += s.kernedWidth;
        }
        return {
            width: i,
            numOfSpaces: 0
        };
    }
    _setGraphemeOnPath(t, e) {
        const s = t + e.kernedWidth / 2, i = this.path, r = qr(i.path, s, i.segmentsInfo);
        e.renderLeft = r.x - i.pathOffset.x, e.renderTop = r.y - i.pathOffset.y, e.angle = r.angle + (this.pathSide === M ? Math.PI : 0);
    }
    _getGraphemeBox(t, e, s, i, r) {
        const n = this.getCompleteStyleDeclaration(e, s), o = i ? this.getCompleteStyleDeclaration(e, s - 1) : {}, a = this._measureChar(t, n, i, o);
        let h, l = a.kernedWidth, c = a.width;
        0 !== this.charSpacing && (h = this._getWidthOfCharSpacing(), c += h, l += h);
        const u = {
            width: c,
            left: 0,
            height: n.fontSize,
            kernedWidth: l,
            deltaY: n.deltaY
        };
        if (s > 0 && !r) {
            const t = this.__charBounds[e][s - 1];
            u.left = t.left + t.width + a.kernedWidth - a.width;
        }
        return u;
    }
    getHeightOfLineImpl(t) {
        const e = this.__lineHeights;
        if (e[t]) return e[t];
        let s = this.getHeightOfChar(t, 0);
        for(let e = 1, i = this._textLines[t].length; e < i; e++)s = Math.max(this.getHeightOfChar(t, e), s);
        return e[t] = s * this._fontSizeMult;
    }
    getHeightOfLine(t) {
        return this.getHeightOfLineImpl(t) * this.lineHeight;
    }
    calcTextHeight() {
        let t = 0;
        for(let e = 0, s = this._textLines.length; e < s; e++)t += e === s - 1 ? this.getHeightOfLineImpl(e) : this.getHeightOfLine(e);
        return t;
    }
    _getLeftOffset() {
        return this.direction === q ? -this.width / 2 : this.width / 2;
    }
    _getTopOffset() {
        return -this.height / 2;
    }
    _renderTextCommon(t, e) {
        t.save();
        let s = 0;
        const i = this._getLeftOffset(), r = this._getTopOffset();
        for(let n = 0, o = this._textLines.length; n < o; n++)this._renderTextLine(e, t, this._textLines[n], i + this._getLineLeftOffset(n), r + s + this.getHeightOfLineImpl(n), n), s += this.getHeightOfLine(n);
        t.restore();
    }
    _renderTextFill(t) {
        (this.fill || this.styleHas(H)) && this._renderTextCommon(t, "fillText");
    }
    _renderTextStroke(t) {
        (this.stroke && 0 !== this.strokeWidth || !this.isEmptyStyles()) && (this.shadow && !this.shadow.affectStroke && this._removeShadow(t), t.save(), this._setLineDash(t, this.strokeDashArray), t.beginPath(), this._renderTextCommon(t, "strokeText"), t.closePath(), t.restore());
    }
    _renderChars(t, e, s, i, r, n) {
        const o = this.textAlign.includes(cs), a = this.path, h = !o && 0 === this.charSpacing && this.isEmptyStyles(n) && !a, l = this.direction === q, c = this.direction === q ? 1 : -1, u = e.direction;
        let d, g, f, p, m, v = "", y = 0;
        if (e.save(), u !== this.direction && (e.canvas.setAttribute("dir", l ? q : K), e.direction = l ? q : K, e.textAlign = l ? O : M), r -= this.getHeightOfLineImpl(n) * this._fontSizeFraction, h) return this._renderChar(t, e, n, 0, s.join(""), i, r), void e.restore();
        for(let h = 0, l = s.length - 1; h <= l; h++)p = h === l || this.charSpacing || a, v += s[h], f = this.__charBounds[n][h], 0 === y ? (i += c * (f.kernedWidth - f.width), y += f.width) : y += f.kernedWidth, o && !p && this._reSpaceAndTab.test(s[h]) && (p = !0), p || (d = d || this.getCompleteStyleDeclaration(n, h), g = this.getCompleteStyleDeclaration(n, h + 1), p = Yi(d, g, !1)), p && (a ? (e.save(), e.translate(f.renderLeft, f.renderTop), e.rotate(f.angle), this._renderChar(t, e, n, h, v, -y / 2, 0), e.restore()) : (m = i, this._renderChar(t, e, n, h, v, m, r)), v = "", d = g, i += c * y, y = 0);
        e.restore();
    }
    _applyPatternGradientTransformText(t) {
        const e = this.width + this.strokeWidth, s = this.height + this.strokeWidth, i = vt({
            width: e,
            height: s
        }), r = i.getContext("2d");
        return i.width = e, i.height = s, r.beginPath(), r.moveTo(0, 0), r.lineTo(e, 0), r.lineTo(e, s), r.lineTo(0, s), r.closePath(), r.translate(e / 2, s / 2), r.fillStyle = t.toLive(r), this._applyPatternGradientTransform(r, t), r.fill(), r.createPattern(i, "no-repeat");
    }
    handleFiller(t, e, s) {
        let i, r;
        return zt(s) ? "percentage" === s.gradientUnits || s.gradientTransform || s.patternTransform ? (i = -this.width / 2, r = -this.height / 2, t.translate(i, r), t[e] = this._applyPatternGradientTransformText(s), {
            offsetX: i,
            offsetY: r
        }) : (t[e] = s.toLive(t), this._applyPatternGradientTransform(t, s)) : (t[e] = s, {
            offsetX: 0,
            offsetY: 0
        });
    }
    _setStrokeStyles(t, e) {
        let { stroke: s, strokeWidth: i } = e;
        return t.lineWidth = i, t.lineCap = this.strokeLineCap, t.lineDashOffset = this.strokeDashOffset, t.lineJoin = this.strokeLineJoin, t.miterLimit = this.strokeMiterLimit, this.handleFiller(t, "strokeStyle", s);
    }
    _setFillStyles(t, e) {
        let { fill: s } = e;
        return this.handleFiller(t, "fillStyle", s);
    }
    _renderChar(t, e, s, i, r, n, o) {
        const a = this._getStyleDeclaration(s, i), h = this.getCompleteStyleDeclaration(s, i), l = "fillText" === t && h.fill, c = "strokeText" === t && h.stroke && h.strokeWidth;
        if (c || l) {
            if (e.save(), e.font = this._getFontDeclaration(h), a.textBackgroundColor && this._removeShadow(e), a.deltaY && (o += a.deltaY), l) {
                const t = this._setFillStyles(e, h);
                e.fillText(r, n - t.offsetX, o - t.offsetY);
            }
            if (c) {
                const t = this._setStrokeStyles(e, h);
                e.strokeText(r, n - t.offsetX, o - t.offsetY);
            }
            e.restore();
        }
    }
    setSuperscript(t, e) {
        this._setScript(t, e, this.superscript);
    }
    setSubscript(t, e) {
        this._setScript(t, e, this.subscript);
    }
    _setScript(t, e, s) {
        const i = this.get2DCursorLocation(t, !0), r = this.getValueOfPropertyAt(i.lineIndex, i.charIndex, "fontSize"), n = this.getValueOfPropertyAt(i.lineIndex, i.charIndex, "deltaY"), o = {
            fontSize: r * s.size,
            deltaY: n + r * s.baseline
        };
        this.setSelectionStyles(o, t, e);
    }
    _getLineLeftOffset(t) {
        const e = this.getLineWidth(t), s = this.width - e, i = this.textAlign, r = this.direction, n = this.isEndOfWrapping(t);
        let o = 0;
        return i === cs || i === gs && !n || i === ds && !n || i === us && !n ? 0 : (i === T && (o = s / 2), i === M && (o = s), i === gs && (o = s / 2), i === ds && (o = s), r === K && (i === M || i === ds ? o = 0 : i === O || i === us ? o = -s : i !== T && i !== gs || (o = -s / 2)), o);
    }
    _clearCache() {
        this._forceClearCache = !1, this.__lineWidths = [], this.__lineHeights = [], this.__charBounds = [];
    }
    getLineWidth(t) {
        if (void 0 !== this.__lineWidths[t]) return this.__lineWidths[t];
        const { width: e } = this.measureLine(t);
        return this.__lineWidths[t] = e, e;
    }
    _getWidthOfCharSpacing() {
        return 0 !== this.charSpacing ? this.fontSize * this.charSpacing / 1e3 : 0;
    }
    getValueOfPropertyAt(t, e, s) {
        var i;
        return null !== (i = this._getStyleDeclaration(t, e)[s]) && void 0 !== i ? i : this[s];
    }
    _renderTextDecoration(t, e) {
        if (!this[e] && !this.styleHas(e)) return;
        let s = this._getTopOffset();
        const i = this._getLeftOffset(), r = this.path, n = this._getWidthOfCharSpacing(), o = "linethrough" === e ? .5 : "overline" === e ? 1 : 0, a = this.offsets[e];
        for(let h = 0, l = this._textLines.length; h < l; h++){
            const l = this.getHeightOfLine(h);
            if (!this[e] && !this.styleHas(e, h)) {
                s += l;
                continue;
            }
            const c = this._textLines[h], u = l / this.lineHeight, d = this._getLineLeftOffset(h);
            let g = 0, f = 0, p = this.getValueOfPropertyAt(h, 0, e), m = this.getValueOfPropertyAt(h, 0, H), v = this.getValueOfPropertyAt(h, 0, is), y = p, _ = m, x = v;
            const C = s + u * (1 - this._fontSizeFraction);
            let b = this.getHeightOfChar(h, 0), S = this.getValueOfPropertyAt(h, 0, "deltaY");
            for(let s = 0, n = c.length; s < n; s++){
                const n = this.__charBounds[h][s];
                y = this.getValueOfPropertyAt(h, s, e), _ = this.getValueOfPropertyAt(h, s, H), x = this.getValueOfPropertyAt(h, s, is);
                const l = this.getHeightOfChar(h, s), c = this.getValueOfPropertyAt(h, s, "deltaY");
                if (r && y && _) {
                    const e = this.fontSize * x / 1e3;
                    t.save(), t.fillStyle = m, t.translate(n.renderLeft, n.renderTop), t.rotate(n.angle), t.fillRect(-n.kernedWidth / 2, a * l + c - o * e, n.kernedWidth, e), t.restore();
                } else if ((y !== p || _ !== m || l !== b || x !== v || c !== S) && f > 0) {
                    const e = this.fontSize * v / 1e3;
                    let s = i + d + g;
                    this.direction === K && (s = this.width - s - f), p && m && v && (t.fillStyle = m, t.fillRect(s, C + a * b + S - o * e, f, e)), g = n.left, f = n.width, p = y, v = x, m = _, b = l, S = c;
                } else f += n.kernedWidth;
            }
            let w = i + d + g;
            this.direction === K && (w = this.width - w - f), t.fillStyle = _;
            const T = this.fontSize * x / 1e3;
            y && _ && x && t.fillRect(w, C + a * b + S - o * T, f - n, T), s += l;
        }
        this._removeShadow(t);
    }
    _getFontDeclaration() {
        let { fontFamily: t = this.fontFamily, fontStyle: e = this.fontStyle, fontWeight: s = this.fontWeight, fontSize: i = this.fontSize } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0;
        const n = t.includes("'") || t.includes('"') || t.includes(",") || go.genericFonts.includes(t.toLowerCase()) ? t : `"${t}"`;
        return [
            e,
            s,
            `${r ? this.CACHE_FONT_SIZE : i}px`,
            n
        ].join(" ");
    }
    render(t) {
        this.visible && (this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (this._forceClearCache && this.initDimensions(), super.render(t)));
    }
    graphemeSplit(t) {
        return re(t);
    }
    _splitTextIntoLines(t) {
        const e = t.split(this._reNewline), s = new Array(e.length), i = [
            "\n"
        ];
        let r = [];
        for(let t = 0; t < e.length; t++)s[t] = this.graphemeSplit(e[t]), r = r.concat(s[t], i);
        return r.pop(), {
            _unwrappedLines: s,
            lines: e,
            graphemeText: r,
            graphemeLines: s
        };
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
            ...super.toObject([
                ...as,
                ...t
            ]),
            styles: Wi(this.styles, this.text),
            ...this.path ? {
                path: this.path.toObject()
            } : {}
        };
    }
    set(t, e) {
        const { textLayoutProperties: s } = this.constructor;
        super.set(t, e);
        let i = !1, r = !1;
        if ("object" == typeof t) for(const e in t)"path" === e && this.setPathInfo(), i = i || s.includes(e), r = r || "path" === e;
        else i = s.includes(t), r = "path" === t;
        return r && this.setPathInfo(), i && this.initialized && (this.initDimensions(), this.setCoords()), this;
    }
    complexity() {
        return 1;
    }
    static async fromElement(t, e, s) {
        const i = gr(t, go.ATTRIBUTE_NAMES, s), { textAnchor: r = O, textDecoration: n = "", dx: o = 0, dy: a = 0, top: h = 0, left: l = 0, fontSize: c = S, strokeWidth: u = 1, ...d } = {
            ...e,
            ...i
        }, g = new this(ze(t.textContent || "").trim(), {
            left: l + o,
            top: h + a,
            underline: n.includes("underline"),
            overline: n.includes("overline"),
            linethrough: n.includes("line-through"),
            strokeWidth: 0,
            fontSize: c,
            ...d
        }), f = g.getScaledHeight() / g.height, p = ((g.height + g.strokeWidth) * g.lineHeight - g.height) * f, m = g.getScaledHeight() + p;
        let v = 0;
        return r === T && (v = g.getScaledWidth() / 2), r === M && (v = g.getScaledWidth()), g.set({
            left: g.left - v,
            top: g.top - (m - g.fontSize * (.07 + g._fontSizeFraction)) / g.lineHeight,
            strokeWidth: u
        }), g;
    }
    static fromObject(t) {
        return this._fromObject({
            ...t,
            styles: Vi(t.styles || {}, t.text)
        }, {
            extraParam: "text"
        });
    }
}
t(go, "textLayoutProperties", os), t(go, "cacheProperties", [
    ...Ps,
    ...as
]), t(go, "ownDefaults", ls), t(go, "type", "Text"), t(go, "genericFonts", [
    "serif",
    "sans-serif",
    "monospace",
    "cursive",
    "fantasy",
    "system-ui",
    "ui-serif",
    "ui-sans-serif",
    "ui-monospace",
    "ui-rounded",
    "math",
    "emoji",
    "fangsong"
]), t(go, "ATTRIBUTE_NAMES", zi.concat("x", "y", "dx", "dy", "font-family", "font-style", "font-weight", "font-size", "letter-spacing", "text-decoration", "text-anchor")), Ai(go, [
    class extends es {
        _toSVG() {
            const t = this._getSVGLeftTopOffsets(), e = this._getSVGTextAndBg(t.textTop, t.textLeft);
            return this._wrapSVGTextAndBg(e);
        }
        toSVG(t) {
            const e = this._createBaseSVGMarkup(this._toSVG(), {
                reviver: t,
                noStyle: !0,
                withShadow: !0
            }), s = this.path;
            return s ? e + s._createBaseSVGMarkup(s._toSVG(), {
                reviver: t,
                withShadow: !0,
                additionalTransform: Vt(this.calcOwnMatrix())
            }) : e;
        }
        _getSVGLeftTopOffsets() {
            return {
                textLeft: -this.width / 2,
                textTop: -this.height / 2,
                lineTop: this.getHeightOfLine(0)
            };
        }
        _wrapSVGTextAndBg(t) {
            let { textBgRects: e, textSpans: s } = t;
            const i = this.getSvgTextDecoration(this);
            return [
                e.join(""),
                '\t\t<text xml:space="preserve" ',
                `font-family="${se(this.fontFamily.replace(lo, "'"))}" `,
                `font-size="${se(this.fontSize)}" `,
                this.fontStyle ? `font-style="${se(this.fontStyle)}" ` : "",
                this.fontWeight ? `font-weight="${se(this.fontWeight)}" ` : "",
                i ? `text-decoration="${i}" ` : "",
                "rtl" === this.direction ? 'direction="rtl" ' : "",
                'style="',
                this.getSvgStyles(!0),
                '"',
                this.addPaintOrder(),
                " >",
                s.join(""),
                "</text>\n"
            ];
        }
        _getSVGTextAndBg(t, e) {
            const s = [], i = [];
            let r, n = t;
            this.backgroundColor && i.push(co(this.backgroundColor, -this.width / 2, -this.height / 2, this.width, this.height));
            for(let t = 0, o = this._textLines.length; t < o; t++)r = this._getLineLeftOffset(t), "rtl" === this.direction && (r += this.width), (this.textBackgroundColor || this.styleHas("textBackgroundColor", t)) && this._setSVGTextLineBg(i, t, e + r, n), this._setSVGTextLineText(s, t, e + r, n), n += this.getHeightOfLine(t);
            return {
                textSpans: s,
                textBgRects: i
            };
        }
        _createTextCharSpan(t, e, i, r, n) {
            const o = s.NUM_FRACTION_DIGITS, a = this.getSvgSpanStyles(e, t !== t.trim() || !!t.match(ho)), h = a ? `style="${a}"` : "", l = e.deltaY, c = l ? ` dy="${Wt(l, o)}" ` : "", { angle: u, renderLeft: d, renderTop: g, width: f } = n;
            let p = "";
            if (void 0 !== d) {
                const t = f / 2;
                u && (p = ` rotate="${Wt(Ct(u), o)}"`);
                const e = Pt({
                    angle: Ct(u)
                });
                e[4] = d, e[5] = g;
                const s = new ot(-t, 0).transform(e);
                i = s.x, r = s.y;
            }
            return `<tspan x="${Wt(i, o)}" y="${Wt(r, o)}" ${c}${p}${h}>${se(t)}</tspan>`;
        }
        _setSVGTextLineText(t, e, s, i) {
            const r = this.getHeightOfLine(e), n = this.textAlign.includes(cs), o = this._textLines[e];
            let a, h, l, c, u, d = "", g = 0;
            i += r * (1 - this._fontSizeFraction) / this.lineHeight;
            for(let r = 0, f = o.length - 1; r <= f; r++)u = r === f || this.charSpacing || this.path, d += o[r], l = this.__charBounds[e][r], 0 === g ? (s += l.kernedWidth - l.width, g += l.width) : g += l.kernedWidth, n && !u && this._reSpaceAndTab.test(o[r]) && (u = !0), u || (a = a || this.getCompleteStyleDeclaration(e, r), h = this.getCompleteStyleDeclaration(e, r + 1), u = Yi(a, h, !0)), u && (c = this._getStyleDeclaration(e, r), t.push(this._createTextCharSpan(d, c, s, i, l)), d = "", a = h, "rtl" === this.direction ? s -= g : s += g, g = 0);
        }
        _setSVGTextLineBg(t, e, s, i) {
            const r = this._textLines[e], n = this.getHeightOfLine(e) / this.lineHeight;
            let o, a = 0, h = 0, l = this.getValueOfPropertyAt(e, 0, "textBackgroundColor");
            for(let c = 0; c < r.length; c++){
                const { left: r, width: u, kernedWidth: d } = this.__charBounds[e][c];
                o = this.getValueOfPropertyAt(e, c, "textBackgroundColor"), o !== l ? (l && t.push(co(l, s + h, i, a, n)), h = r, a = u, l = o) : a += d;
            }
            o && t.push(co(l, s + h, i, a, n));
        }
        getSvgStyles(t) {
            return `${super.getSvgStyles(t)} text-decoration-thickness: ${Wt(this.textDecorationThickness * this.getObjectScaling().y / 10, s.NUM_FRACTION_DIGITS)}%; white-space: pre;`;
        }
        getSvgSpanStyles(t, e) {
            const { fontFamily: i, strokeWidth: r, stroke: n, fill: o, fontSize: a, fontStyle: h, fontWeight: l, textDecorationThickness: c, linethrough: u, overline: d, underline: g } = t, f = this.getSvgTextDecoration({
                underline: null != g ? g : this.underline,
                overline: null != d ? d : this.overline,
                linethrough: null != u ? u : this.linethrough
            }), p = c || this.textDecorationThickness;
            return [
                n ? ts(N, n) : "",
                r ? `stroke-width: ${se(r)}; ` : "",
                i ? `font-family: ${i.includes("'") || i.includes('"') ? se(i) : `'${se(i)}'`}; ` : "",
                a ? `font-size: ${se(a)}px; ` : "",
                h ? `font-style: ${se(h)}; ` : "",
                l ? `font-weight: ${se(l)}; ` : "",
                f ? `text-decoration: ${f}; text-decoration-thickness: ${Wt(p * this.getObjectScaling().y / 10, s.NUM_FRACTION_DIGITS)}%; ` : "",
                o ? ts(H, o) : "",
                e ? "white-space: pre; " : ""
            ].join("");
        }
        getSvgTextDecoration(t) {
            return [
                "overline",
                "underline",
                "line-through"
            ].filter((e)=>t[e.replace("-", "")]).join(" ");
        }
    }
]), tt.setClass(go), tt.setSVGClass(go);
class fo {
    constructor(e){
        t(this, "target", void 0), t(this, "__mouseDownInPlace", !1), t(this, "__dragStartFired", !1), t(this, "__isDraggingOver", !1), t(this, "__dragStartSelection", void 0), t(this, "__dragImageDisposer", void 0), t(this, "_dispose", void 0), this.target = e;
        const s = [
            this.target.on("dragenter", this.dragEnterHandler.bind(this)),
            this.target.on("dragover", this.dragOverHandler.bind(this)),
            this.target.on("dragleave", this.dragLeaveHandler.bind(this)),
            this.target.on("dragend", this.dragEndHandler.bind(this)),
            this.target.on("drop", this.dropHandler.bind(this))
        ];
        this._dispose = ()=>{
            s.forEach((t)=>t()), this._dispose = void 0;
        };
    }
    isPointerOverSelection(t) {
        const e = this.target, s = e.getSelectionStartFromPointer(t);
        return e.isEditing && s >= e.selectionStart && s <= e.selectionEnd && e.selectionStart < e.selectionEnd;
    }
    start(t) {
        return this.__mouseDownInPlace = this.isPointerOverSelection(t);
    }
    isActive() {
        return this.__mouseDownInPlace;
    }
    end(t) {
        const e = this.isActive();
        return e && !this.__dragStartFired && (this.target.setCursorByClick(t), this.target.initDelayedCursor(!0)), this.__mouseDownInPlace = !1, this.__dragStartFired = !1, this.__isDraggingOver = !1, e;
    }
    getDragStartSelection() {
        return this.__dragStartSelection;
    }
    setDragImage(t, e) {
        var s;
        let { selectionStart: i, selectionEnd: r } = e;
        const n = this.target, o = n.canvas, a = new ot(n.flipX ? -1 : 1, n.flipY ? -1 : 1), h = n._getCursorBoundaries(i), l = new ot(h.left + h.leftOffset, h.top + h.topOffset).multiply(a).transform(n.calcTransformMatrix()), c = o.getScenePoint(t).subtract(l), u = n.getCanvasRetinaScaling(), d = n.getBoundingRect(), g = l.subtract(new ot(d.left, d.top)), f = o.viewportTransform, p = g.add(c).transform(f, !0), m = n.backgroundColor, v = Xi(n.styles);
        n.backgroundColor = "";
        const y = {
            stroke: "transparent",
            fill: "transparent",
            textBackgroundColor: "transparent"
        };
        n.setSelectionStyles(y, 0, i), n.setSelectionStyles(y, r, n.text.length), n.dirty = !0;
        const _ = n.toCanvasElement({
            enableRetinaScaling: o.enableRetinaScaling,
            viewportTransform: !0
        });
        n.backgroundColor = m, n.styles = v, n.dirty = !0, an(_, {
            position: "fixed",
            left: -_.width + "px",
            border: P,
            width: _.width / u + "px",
            height: _.height / u + "px"
        }), this.__dragImageDisposer && this.__dragImageDisposer(), this.__dragImageDisposer = ()=>{
            _.remove();
        }, qt(t.target || this.target.hiddenTextarea).body.appendChild(_), null === (s = t.dataTransfer) || void 0 === s || s.setDragImage(_, p.x, p.y);
    }
    onDragStart(t) {
        this.__dragStartFired = !0;
        const e = this.target, s = this.isActive();
        if (s && t.dataTransfer) {
            const s = this.__dragStartSelection = {
                selectionStart: e.selectionStart,
                selectionEnd: e.selectionEnd
            }, i = e._text.slice(s.selectionStart, s.selectionEnd).join(""), r = {
                text: e.text,
                value: i,
                ...s
            };
            t.dataTransfer.setData("text/plain", i), t.dataTransfer.setData("application/fabric", JSON.stringify({
                value: i,
                styles: e.getSelectionStyles(s.selectionStart, s.selectionEnd, !0)
            })), t.dataTransfer.effectAllowed = "copyMove", this.setDragImage(t, r);
        }
        return e.abortCursorAnimation(), s;
    }
    canDrop(t) {
        if (this.target.editable && !this.target.getActiveControl() && !t.defaultPrevented) {
            if (this.isActive() && this.__dragStartSelection) {
                const e = this.target.getSelectionStartFromPointer(t), s = this.__dragStartSelection;
                return e < s.selectionStart || e > s.selectionEnd;
            }
            return !0;
        }
        return !1;
    }
    targetCanDrop(t) {
        return this.target.canDrop(t);
    }
    dragEnterHandler(t) {
        let { e: e } = t;
        const s = this.targetCanDrop(e);
        !this.__isDraggingOver && s && (this.__isDraggingOver = !0);
    }
    dragOverHandler(t) {
        const { e: e } = t, s = this.targetCanDrop(e);
        !this.__isDraggingOver && s ? this.__isDraggingOver = !0 : this.__isDraggingOver && !s && (this.__isDraggingOver = !1), this.__isDraggingOver && (e.preventDefault(), t.canDrop = !0, t.dropTarget = this.target);
    }
    dragLeaveHandler() {
        (this.__isDraggingOver || this.isActive()) && (this.__isDraggingOver = !1);
    }
    dropHandler(t) {
        var e;
        const { e: s } = t, i = s.defaultPrevented;
        this.__isDraggingOver = !1, s.preventDefault();
        let r = null === (e = s.dataTransfer) || void 0 === e ? void 0 : e.getData("text/plain");
        if (r && !i) {
            const e = this.target, i = e.canvas;
            let n = e.getSelectionStartFromPointer(s);
            const { styles: o } = s.dataTransfer.types.includes("application/fabric") ? JSON.parse(s.dataTransfer.getData("application/fabric")) : {}, a = r[Math.max(0, r.length - 1)], h = 0;
            if (this.__dragStartSelection) {
                const t = this.__dragStartSelection.selectionStart, s = this.__dragStartSelection.selectionEnd;
                n > t && n <= s ? n = t : n > s && (n -= s - t), e.removeChars(t, s), delete this.__dragStartSelection;
            }
            e._reNewline.test(a) && (e._reNewline.test(e._text[n]) || n === e._text.length) && (r = r.trimEnd()), t.didDrop = !0, t.dropTarget = e, e.insertChars(r, o, n), i.setActiveObject(e), e.enterEditing(s), e.selectionStart = Math.min(n + h, e._text.length), e.selectionEnd = Math.min(e.selectionStart + r.length, e._text.length), e.hiddenTextarea.value = e.text, e._updateTextarea(), e.hiddenTextarea.focus(), e.fire(X, {
                index: n + h,
                action: "drop"
            }), i.fire("text:changed", {
                target: e
            }), i.contextTopDirty = !0, i.requestRenderAll();
        }
    }
    dragEndHandler(t) {
        let { e: e } = t;
        if (this.isActive() && this.__dragStartFired && this.__dragStartSelection) {
            var s;
            const t = this.target, i = this.target.canvas, { selectionStart: r, selectionEnd: n } = this.__dragStartSelection, o = (null === (s = e.dataTransfer) || void 0 === s ? void 0 : s.dropEffect) || P;
            o === P ? (t.selectionStart = r, t.selectionEnd = n, t._updateTextarea(), t.hiddenTextarea.focus()) : (t.clearContextTop(), "move" === o && (t.removeChars(r, n), t.selectionStart = t.selectionEnd = r, t.hiddenTextarea && (t.hiddenTextarea.value = t.text), t._updateTextarea(), t.fire(X, {
                index: r,
                action: "dragend"
            }), i.fire("text:changed", {
                target: t
            }), i.requestRenderAll()), t.exitEditing());
        }
        this.__dragImageDisposer && this.__dragImageDisposer(), delete this.__dragImageDisposer, delete this.__dragStartSelection, this.__isDraggingOver = !1;
    }
    dispose() {
        this._dispose && this._dispose();
    }
}
const po = /[ \n\.,;!\?\-]/;
class mo extends go {
    constructor(){
        super(...arguments), t(this, "_currentCursorOpacity", 1);
    }
    initBehavior() {
        this._tick = this._tick.bind(this), this._onTickComplete = this._onTickComplete.bind(this), this.updateSelectionOnMouseMove = this.updateSelectionOnMouseMove.bind(this);
    }
    onDeselect(t) {
        return this.isEditing && this.exitEditing(), this.selected = !1, super.onDeselect(t);
    }
    _animateCursor(t) {
        let { toValue: e, duration: s, delay: i, onComplete: r } = t;
        return Gs({
            startValue: this._currentCursorOpacity,
            endValue: e,
            duration: s,
            delay: i,
            onComplete: r,
            abort: ()=>!this.canvas || this.selectionStart !== this.selectionEnd,
            onChange: (t)=>{
                this._currentCursorOpacity = t, this.renderCursorOrSelection();
            }
        });
    }
    _tick(t) {
        this._currentTickState = this._animateCursor({
            toValue: 0,
            duration: this.cursorDuration / 2,
            delay: Math.max(t || 0, 100),
            onComplete: this._onTickComplete
        });
    }
    _onTickComplete() {
        var t;
        null === (t = this._currentTickCompleteState) || void 0 === t || t.abort(), this._currentTickCompleteState = this._animateCursor({
            toValue: 1,
            duration: this.cursorDuration,
            onComplete: this._tick
        });
    }
    initDelayedCursor(t) {
        this.abortCursorAnimation(), this._tick(t ? 0 : this.cursorDelay);
    }
    abortCursorAnimation() {
        let t = !1;
        [
            this._currentTickState,
            this._currentTickCompleteState
        ].forEach((e)=>{
            e && !e.isDone() && (t = !0, e.abort());
        }), this._currentCursorOpacity = 1, t && this.clearContextTop();
    }
    restartCursorIfNeeded() {
        [
            this._currentTickState,
            this._currentTickCompleteState
        ].some((t)=>!t || t.isDone()) && this.initDelayedCursor();
    }
    selectAll() {
        return this.selectionStart = 0, this.selectionEnd = this._text.length, this._fireSelectionChanged(), this._updateTextarea(), this;
    }
    cmdAll() {
        this.selectAll(), this.renderCursorOrSelection();
    }
    getSelectedText() {
        return this._text.slice(this.selectionStart, this.selectionEnd).join("");
    }
    findWordBoundaryLeft(t) {
        let e = 0, s = t - 1;
        if (this._reSpace.test(this._text[s])) for(; this._reSpace.test(this._text[s]);)e++, s--;
        for(; /\S/.test(this._text[s]) && s > -1;)e++, s--;
        return t - e;
    }
    findWordBoundaryRight(t) {
        let e = 0, s = t;
        if (this._reSpace.test(this._text[s])) for(; this._reSpace.test(this._text[s]);)e++, s++;
        for(; /\S/.test(this._text[s]) && s < this._text.length;)e++, s++;
        return t + e;
    }
    findLineBoundaryLeft(t) {
        let e = 0, s = t - 1;
        for(; !/\n/.test(this._text[s]) && s > -1;)e++, s--;
        return t - e;
    }
    findLineBoundaryRight(t) {
        let e = 0, s = t;
        for(; !/\n/.test(this._text[s]) && s < this._text.length;)e++, s++;
        return t + e;
    }
    searchWordBoundary(t, e) {
        const s = this._text;
        let i = t > 0 && this._reSpace.test(s[t]) && (-1 === e || !E.test(s[t - 1])) ? t - 1 : t, r = s[i];
        for(; i > 0 && i < s.length && !po.test(r);)i += e, r = s[i];
        return -1 === e && po.test(r) && i++, i;
    }
    selectWord(t) {
        t = null != t ? t : this.selectionStart;
        const e = this.searchWordBoundary(t, -1), s = Math.max(e, this.searchWordBoundary(t, 1));
        this.selectionStart = e, this.selectionEnd = s, this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection();
    }
    selectLine(t) {
        t = null != t ? t : this.selectionStart;
        const e = this.findLineBoundaryLeft(t), s = this.findLineBoundaryRight(t);
        this.selectionStart = e, this.selectionEnd = s, this._fireSelectionChanged(), this._updateTextarea();
    }
    enterEditing(t) {
        !this.isEditing && this.editable && (this.enterEditingImpl(), this.fire("editing:entered", t ? {
            e: t
        } : void 0), this._fireSelectionChanged(), this.canvas && (this.canvas.fire("text:editing:entered", {
            target: this,
            e: t
        }), this.canvas.requestRenderAll()));
    }
    enterEditingImpl() {
        this.canvas && (this.canvas.calcOffset(), this.canvas.textEditingManager.exitTextEditing()), this.isEditing = !0, this.initHiddenTextarea(), this.hiddenTextarea.focus(), this.hiddenTextarea.value = this.text, this._updateTextarea(), this._saveEditingProps(), this._setEditingProps(), this._textBeforeEdit = this.text, this._tick();
    }
    updateSelectionOnMouseMove(t) {
        if (this.getActiveControl()) return;
        const e = this.hiddenTextarea;
        qt(e).activeElement !== e && e.focus();
        const s = this.getSelectionStartFromPointer(t), i = this.selectionStart, r = this.selectionEnd;
        (s === this.__selectionStartOnMouseDown && i !== r || i !== s && r !== s) && (s > this.__selectionStartOnMouseDown ? (this.selectionStart = this.__selectionStartOnMouseDown, this.selectionEnd = s) : (this.selectionStart = s, this.selectionEnd = this.__selectionStartOnMouseDown), this.selectionStart === i && this.selectionEnd === r || (this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection()));
    }
    _setEditingProps() {
        this.hoverCursor = "text", this.canvas && (this.canvas.defaultCursor = this.canvas.moveCursor = "text"), this.borderColor = this.editingBorderColor, this.hasControls = this.selectable = !1, this.lockMovementX = this.lockMovementY = !0;
    }
    fromStringToGraphemeSelection(t, e, s) {
        const i = s.slice(0, t), r = this.graphemeSplit(i).length;
        if (t === e) return {
            selectionStart: r,
            selectionEnd: r
        };
        const n = s.slice(t, e);
        return {
            selectionStart: r,
            selectionEnd: r + this.graphemeSplit(n).length
        };
    }
    fromGraphemeToStringSelection(t, e, s) {
        const i = s.slice(0, t).join("").length;
        if (t === e) return {
            selectionStart: i,
            selectionEnd: i
        };
        return {
            selectionStart: i,
            selectionEnd: i + s.slice(t, e).join("").length
        };
    }
    _updateTextarea() {
        if (this.cursorOffsetCache = {}, this.hiddenTextarea) {
            if (!this.inCompositionMode) {
                const t = this.fromGraphemeToStringSelection(this.selectionStart, this.selectionEnd, this._text);
                this.hiddenTextarea.selectionStart = t.selectionStart, this.hiddenTextarea.selectionEnd = t.selectionEnd;
            }
            this.updateTextareaPosition();
        }
    }
    updateFromTextArea() {
        const { hiddenTextarea: t, direction: e, textAlign: s, inCompositionMode: i } = this;
        if (!t) return;
        const r = s !== cs ? s.replace("justify-", "") : e === q ? O : M, n = this.getPositionByOrigin(r, "top");
        this.cursorOffsetCache = {}, this.text = t.value, this.set("dirty", !0), this.initDimensions(), this.setPositionByOrigin(n, r, "top"), this.setCoords();
        const o = this.fromStringToGraphemeSelection(t.selectionStart, t.selectionEnd, t.value);
        this.selectionEnd = this.selectionStart = o.selectionEnd, i || (this.selectionStart = o.selectionStart), this.updateTextareaPosition();
    }
    updateTextareaPosition() {
        if (this.selectionStart === this.selectionEnd) {
            const t = this._calcTextareaPosition();
            this.hiddenTextarea.style.left = t.left, this.hiddenTextarea.style.top = t.top;
        }
    }
    _calcTextareaPosition() {
        if (!this.canvas) return {
            left: "1px",
            top: "1px"
        };
        const t = this.inCompositionMode ? this.compositionStart : this.selectionStart, e = this._getCursorBoundaries(t), s = this.get2DCursorLocation(t), i = s.lineIndex, r = s.charIndex, n = this.getValueOfPropertyAt(i, r, "fontSize") * this.lineHeight, o = e.leftOffset, a = this.getCanvasRetinaScaling(), h = this.canvas.upperCanvasEl, l = h.width / a, c = h.height / a, u = l - n, d = c - n, g = new ot(e.left + o, e.top + e.topOffset + n).transform(this.calcTransformMatrix()).transform(this.canvas.viewportTransform).multiply(new ot(h.clientWidth / l, h.clientHeight / c));
        return g.x < 0 && (g.x = 0), g.x > u && (g.x = u), g.y < 0 && (g.y = 0), g.y > d && (g.y = d), g.x += this.canvas._offset.left, g.y += this.canvas._offset.top, {
            left: `${g.x}px`,
            top: `${g.y}px`,
            fontSize: `${n}px`,
            charHeight: n
        };
    }
    _saveEditingProps() {
        this._savedProps = {
            hasControls: this.hasControls,
            borderColor: this.borderColor,
            lockMovementX: this.lockMovementX,
            lockMovementY: this.lockMovementY,
            hoverCursor: this.hoverCursor,
            selectable: this.selectable,
            defaultCursor: this.canvas && this.canvas.defaultCursor,
            moveCursor: this.canvas && this.canvas.moveCursor
        };
    }
    _restoreEditingProps() {
        this._savedProps && (this.hoverCursor = this._savedProps.hoverCursor, this.hasControls = this._savedProps.hasControls, this.borderColor = this._savedProps.borderColor, this.selectable = this._savedProps.selectable, this.lockMovementX = this._savedProps.lockMovementX, this.lockMovementY = this._savedProps.lockMovementY, this.canvas && (this.canvas.defaultCursor = this._savedProps.defaultCursor || this.canvas.defaultCursor, this.canvas.moveCursor = this._savedProps.moveCursor || this.canvas.moveCursor), delete this._savedProps);
    }
    exitEditingImpl() {
        const t = this.hiddenTextarea;
        this.selected = !1, this.isEditing = !1, t && (t.blur && t.blur(), t.parentNode && t.parentNode.removeChild(t)), this.hiddenTextarea = null, this.abortCursorAnimation(), this.selectionStart !== this.selectionEnd && this.clearContextTop(), this.selectionEnd = this.selectionStart, this._restoreEditingProps(), this._forceClearCache && (this.initDimensions(), this.setCoords());
    }
    exitEditing() {
        const t = this._textBeforeEdit !== this.text;
        return this.exitEditingImpl(), this.fire("editing:exited"), t && this.fire(U), this.canvas && (this.canvas.fire("text:editing:exited", {
            target: this
        }), t && this.canvas.fire("object:modified", {
            target: this
        })), this;
    }
    _removeExtraneousStyles() {
        for(const t in this.styles)this._textLines[t] || delete this.styles[t];
    }
    removeStyleFromTo(t, e) {
        const { lineIndex: s, charIndex: i } = this.get2DCursorLocation(t, !0), { lineIndex: r, charIndex: n } = this.get2DCursorLocation(e, !0);
        if (s !== r) {
            if (this.styles[s]) for(let t = i; t < this._unwrappedTextLines[s].length; t++)delete this.styles[s][t];
            if (this.styles[r]) for(let t = n; t < this._unwrappedTextLines[r].length; t++){
                const e = this.styles[r][t];
                e && (this.styles[s] || (this.styles[s] = {}), this.styles[s][i + t - n] = e);
            }
            for(let t = s + 1; t <= r; t++)delete this.styles[t];
            this.shiftLineStyles(r, s - r);
        } else if (this.styles[s]) {
            const t = this.styles[s], e = n - i;
            for(let e = i; e < n; e++)delete t[e];
            for(const i in this.styles[s]){
                const s = parseInt(i, 10);
                s >= n && (t[s - e] = t[i], delete t[i]);
            }
        }
    }
    shiftLineStyles(t, e) {
        const s = Object.assign({}, this.styles);
        for(const i in this.styles){
            const r = parseInt(i, 10);
            r > t && (this.styles[r + e] = s[r], s[r - e] || delete this.styles[r]);
        }
    }
    insertNewlineStyleObject(t, e, s, i) {
        const r = {}, n = this._unwrappedTextLines[t].length, o = n === e;
        let a = !1;
        s || (s = 1), this.shiftLineStyles(t, s);
        const h = this.styles[t] ? this.styles[t][0 === e ? e : e - 1] : void 0;
        for(const s in this.styles[t]){
            const i = parseInt(s, 10);
            i >= e && (a = !0, r[i - e] = this.styles[t][s], o && 0 === e || delete this.styles[t][s]);
        }
        let l = !1;
        for(a && !o && (this.styles[t + s] = r, l = !0), (l || n > e) && s--; s > 0;)i && i[s - 1] ? this.styles[t + s] = {
            0: {
                ...i[s - 1]
            }
        } : h ? this.styles[t + s] = {
            0: {
                ...h
            }
        } : delete this.styles[t + s], s--;
        this._forceClearCache = !0;
    }
    insertCharStyleObject(t, e, s, i) {
        this.styles || (this.styles = {});
        const r = this.styles[t], n = r ? {
            ...r
        } : {};
        s || (s = 1);
        for(const t in n){
            const i = parseInt(t, 10);
            i >= e && (r[i + s] = n[i], n[i - s] || delete r[i]);
        }
        if (this._forceClearCache = !0, i) {
            for(; s--;)Object.keys(i[s]).length && (this.styles[t] || (this.styles[t] = {}), this.styles[t][e + s] = {
                ...i[s]
            });
            return;
        }
        if (!r) return;
        const o = r[e ? e - 1 : 1];
        for(; o && s--;)this.styles[t][e + s] = {
            ...o
        };
    }
    insertNewStyleBlock(t, e, s) {
        const i = this.get2DCursorLocation(e, !0), r = [
            0
        ];
        let n, o = 0;
        for(let e = 0; e < t.length; e++)"\n" === t[e] ? (o++, r[o] = 0) : r[o]++;
        for(r[0] > 0 && (this.insertCharStyleObject(i.lineIndex, i.charIndex, r[0], s), s = s && s.slice(r[0] + 1)), o && this.insertNewlineStyleObject(i.lineIndex, i.charIndex + r[0], o), n = 1; n < o; n++)r[n] > 0 ? this.insertCharStyleObject(i.lineIndex + n, 0, r[n], s) : s && this.styles[i.lineIndex + n] && s[0] && (this.styles[i.lineIndex + n][0] = s[0]), s = s && s.slice(r[n] + 1);
        r[n] > 0 && this.insertCharStyleObject(i.lineIndex + n, 0, r[n], s);
    }
    removeChars(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : t + 1;
        this.removeStyleFromTo(t, e), this._text.splice(t, e - t), this.text = this._text.join(""), this.set("dirty", !0), this.initDimensions(), this.setCoords(), this._removeExtraneousStyles();
    }
    insertChars(t, e, s) {
        let i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : s;
        i > s && this.removeStyleFromTo(s, i);
        const r = this.graphemeSplit(t);
        this.insertNewStyleBlock(r, s, e), this._text = [
            ...this._text.slice(0, s),
            ...r,
            ...this._text.slice(i)
        ], this.text = this._text.join(""), this.set("dirty", !0), this.initDimensions(), this.setCoords(), this._removeExtraneousStyles();
    }
    setSelectionStartEndWithShift(t, e, s) {
        s <= t ? (e === t ? this._selectionDirection = O : this._selectionDirection === M && (this._selectionDirection = O, this.selectionEnd = t), this.selectionStart = s) : s > t && s < e ? this._selectionDirection === M ? this.selectionEnd = s : this.selectionStart = s : (e === t ? this._selectionDirection = M : this._selectionDirection === O && (this._selectionDirection = M, this.selectionStart = e), this.selectionEnd = s);
    }
}
class vo extends mo {
    initHiddenTextarea() {
        const t = this.canvas && qt(this.canvas.getElement()) || d(), e = t.createElement("textarea");
        Object.entries({
            autocapitalize: "off",
            autocorrect: "off",
            autocomplete: "off",
            spellcheck: "false",
            "data-fabric": "textarea",
            wrap: "off",
            name: "fabricTextarea"
        }).map((t)=>{
            let [s, i] = t;
            return e.setAttribute(s, i);
        });
        const { top: s, left: i, fontSize: r } = this._calcTextareaPosition();
        e.style.cssText = `position: absolute; top: ${s}; left: ${i}; z-index: -999; opacity: 0; width: 1px; height: 1px; font-size: 1px; padding-top: ${r};`, (this.hiddenTextareaContainer || t.body).appendChild(e), Object.entries({
            blur: "blur",
            keydown: "onKeyDown",
            keyup: "onKeyUp",
            input: "onInput",
            copy: "copy",
            cut: "copy",
            paste: "paste",
            compositionstart: "onCompositionStart",
            compositionupdate: "onCompositionUpdate",
            compositionend: "onCompositionEnd"
        }).map((t)=>{
            let [s, i] = t;
            return e.addEventListener(s, this[i].bind(this));
        }), this.hiddenTextarea = e;
    }
    blur() {
        this.abortCursorAnimation();
    }
    onKeyDown(t) {
        if (!this.isEditing) return;
        const e = "rtl" === this.direction ? this.keysMapRtl : this.keysMap;
        if (t.keyCode in e) this[e[t.keyCode]](t);
        else {
            if (!(t.keyCode in this.ctrlKeysMapDown) || !t.ctrlKey && !t.metaKey) return;
            this[this.ctrlKeysMapDown[t.keyCode]](t);
        }
        t.stopImmediatePropagation(), t.preventDefault(), t.keyCode >= 33 && t.keyCode <= 40 ? (this.inCompositionMode = !1, this.clearContextTop(), this.renderCursorOrSelection()) : this.canvas && this.canvas.requestRenderAll();
    }
    onKeyUp(t) {
        !this.isEditing || this._copyDone || this.inCompositionMode ? this._copyDone = !1 : t.keyCode in this.ctrlKeysMapUp && (t.ctrlKey || t.metaKey) && (this[this.ctrlKeysMapUp[t.keyCode]](t), t.stopImmediatePropagation(), t.preventDefault(), this.canvas && this.canvas.requestRenderAll());
    }
    onInput(t) {
        const e = this.fromPaste, { value: i, selectionStart: r, selectionEnd: n } = this.hiddenTextarea;
        if (this.fromPaste = !1, t && t.stopPropagation(), !this.isEditing) return;
        const o = ()=>{
            this.updateFromTextArea(), this.fire(X), this.canvas && (this.canvas.fire("text:changed", {
                target: this
            }), this.canvas.requestRenderAll());
        };
        if ("" === this.hiddenTextarea.value) return this.styles = {}, void o();
        const a = this._splitTextIntoLines(i).graphemeText, h = this._text.length, l = a.length, c = this.selectionStart, d = this.selectionEnd, g = c !== d;
        let f, p, m, v, y = l - h;
        const _ = this.fromStringToGraphemeSelection(r, n, i), x = c > _.selectionStart;
        g ? (p = this._text.slice(c, d), y += d - c) : l < h && (p = x ? this._text.slice(d + y, d) : this._text.slice(c, c - y));
        const C = a.slice(_.selectionEnd - y, _.selectionEnd);
        if (p && p.length && (C.length && (f = this.getSelectionStyles(c, c + 1, !1), f = C.map(()=>f[0])), g ? (m = c, v = d) : x ? (m = d - p.length, v = d) : (m = d, v = d + p.length), this.removeStyleFromTo(m, v)), C.length) {
            const { copyPasteData: t } = u();
            e && C.join("") === t.copiedText && !s.disableStyleCopyPaste && (f = t.copiedTextStyle), this.insertNewStyleBlock(C, c, f);
        }
        o();
    }
    onCompositionStart() {
        this.inCompositionMode = !0;
    }
    onCompositionEnd() {
        this.inCompositionMode = !1;
    }
    onCompositionUpdate(t) {
        let { target: e } = t;
        const { selectionStart: s, selectionEnd: i } = e;
        this.compositionStart = s, this.compositionEnd = i, this.updateTextareaPosition();
    }
    copy() {
        if (this.selectionStart === this.selectionEnd) return;
        const { copyPasteData: t } = u();
        t.copiedText = this.getSelectedText(), s.disableStyleCopyPaste ? t.copiedTextStyle = void 0 : t.copiedTextStyle = this.getSelectionStyles(this.selectionStart, this.selectionEnd, !0), this._copyDone = !0;
    }
    paste() {
        this.fromPaste = !0;
    }
    _getWidthBeforeCursor(t, e) {
        let s, i = this._getLineLeftOffset(t);
        return e > 0 && (s = this.__charBounds[t][e - 1], i += s.left + s.width), i;
    }
    getDownCursorOffset(t, e) {
        const s = this._getSelectionForOffset(t, e), i = this.get2DCursorLocation(s), r = i.lineIndex;
        if (r === this._textLines.length - 1 || t.metaKey || 34 === t.keyCode) return this._text.length - s;
        const n = i.charIndex, o = this._getWidthBeforeCursor(r, n), a = this._getIndexOnLine(r + 1, o);
        return this._textLines[r].slice(n).length + a + 1 + this.missingNewlineOffset(r);
    }
    _getSelectionForOffset(t, e) {
        return t.shiftKey && this.selectionStart !== this.selectionEnd && e ? this.selectionEnd : this.selectionStart;
    }
    getUpCursorOffset(t, e) {
        const s = this._getSelectionForOffset(t, e), i = this.get2DCursorLocation(s), r = i.lineIndex;
        if (0 === r || t.metaKey || 33 === t.keyCode) return -s;
        const n = i.charIndex, o = this._getWidthBeforeCursor(r, n), a = this._getIndexOnLine(r - 1, o), h = this._textLines[r].slice(0, n), l = this.missingNewlineOffset(r - 1);
        return -this._textLines[r - 1].length + a - h.length + (1 - l);
    }
    _getIndexOnLine(t, e) {
        const s = this._textLines[t];
        let i, r, n = this._getLineLeftOffset(t), o = 0;
        for(let a = 0, h = s.length; a < h; a++)if (i = this.__charBounds[t][a].width, n += i, n > e) {
            r = !0;
            const t = n - i, s = n, h = Math.abs(t - e);
            o = Math.abs(s - e) < h ? a : a - 1;
            break;
        }
        return r || (o = s.length - 1), o;
    }
    moveCursorDown(t) {
        this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorUpOrDown("Down", t);
    }
    moveCursorUp(t) {
        0 === this.selectionStart && 0 === this.selectionEnd || this._moveCursorUpOrDown("Up", t);
    }
    _moveCursorUpOrDown(t, e) {
        const s = this[`get${t}CursorOffset`](e, this._selectionDirection === M);
        if (e.shiftKey ? this.moveCursorWithShift(s) : this.moveCursorWithoutShift(s), 0 !== s) {
            const t = this.text.length;
            this.selectionStart = Ds(0, this.selectionStart, t), this.selectionEnd = Ds(0, this.selectionEnd, t), this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea();
        }
    }
    moveCursorWithShift(t) {
        const e = this._selectionDirection === O ? this.selectionStart + t : this.selectionEnd + t;
        return this.setSelectionStartEndWithShift(this.selectionStart, this.selectionEnd, e), 0 !== t;
    }
    moveCursorWithoutShift(t) {
        return t < 0 ? (this.selectionStart += t, this.selectionEnd = this.selectionStart) : (this.selectionEnd += t, this.selectionStart = this.selectionEnd), 0 !== t;
    }
    moveCursorLeft(t) {
        0 === this.selectionStart && 0 === this.selectionEnd || this._moveCursorLeftOrRight("Left", t);
    }
    _move(t, e, s) {
        let i;
        if (t.altKey) i = this[`findWordBoundary${s}`](this[e]);
        else {
            if (!t.metaKey && 35 !== t.keyCode && 36 !== t.keyCode) return this[e] += "Left" === s ? -1 : 1, !0;
            i = this[`findLineBoundary${s}`](this[e]);
        }
        return void 0 !== i && this[e] !== i && (this[e] = i, !0);
    }
    _moveLeft(t, e) {
        return this._move(t, e, "Left");
    }
    _moveRight(t, e) {
        return this._move(t, e, "Right");
    }
    moveCursorLeftWithoutShift(t) {
        let e = !0;
        return this._selectionDirection = O, this.selectionEnd === this.selectionStart && 0 !== this.selectionStart && (e = this._moveLeft(t, "selectionStart")), this.selectionEnd = this.selectionStart, e;
    }
    moveCursorLeftWithShift(t) {
        return this._selectionDirection === M && this.selectionStart !== this.selectionEnd ? this._moveLeft(t, "selectionEnd") : 0 !== this.selectionStart ? (this._selectionDirection = O, this._moveLeft(t, "selectionStart")) : void 0;
    }
    moveCursorRight(t) {
        this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorLeftOrRight("Right", t);
    }
    _moveCursorLeftOrRight(t, e) {
        const s = `moveCursor${t}${e.shiftKey ? "WithShift" : "WithoutShift"}`;
        this._currentCursorOpacity = 1, this[s](e) && (this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
    }
    moveCursorRightWithShift(t) {
        return this._selectionDirection === O && this.selectionStart !== this.selectionEnd ? this._moveRight(t, "selectionStart") : this.selectionEnd !== this._text.length ? (this._selectionDirection = M, this._moveRight(t, "selectionEnd")) : void 0;
    }
    moveCursorRightWithoutShift(t) {
        let e = !0;
        return this._selectionDirection = M, this.selectionStart === this.selectionEnd ? (e = this._moveRight(t, "selectionStart"), this.selectionEnd = this.selectionStart) : this.selectionStart = this.selectionEnd, e;
    }
}
const yo = (t)=>!!t.button;
class _o extends vo {
    constructor(){
        super(...arguments), t(this, "draggableTextDelegate", void 0);
    }
    initBehavior() {
        this.on("mousedown", this._mouseDownHandler), this.on("mouseup", this.mouseUpHandler), this.on("mousedblclick", this.doubleClickHandler), this.on("mousetripleclick", this.tripleClickHandler), this.draggableTextDelegate = new fo(this), super.initBehavior();
    }
    shouldStartDragging() {
        return this.draggableTextDelegate.isActive();
    }
    onDragStart(t) {
        return this.draggableTextDelegate.onDragStart(t);
    }
    canDrop(t) {
        return this.draggableTextDelegate.canDrop(t);
    }
    doubleClickHandler(t) {
        this.isEditing && (this.selectWord(this.getSelectionStartFromPointer(t.e)), this.renderCursorOrSelection());
    }
    tripleClickHandler(t) {
        this.isEditing && (this.selectLine(this.getSelectionStartFromPointer(t.e)), this.renderCursorOrSelection());
    }
    _mouseDownHandler(t) {
        let { e: e, alreadySelected: s } = t;
        this.canvas && this.editable && !yo(e) && !this.getActiveControl() && (this.draggableTextDelegate.start(e) || (this.canvas.textEditingManager.register(this), s && (this.inCompositionMode = !1, this.setCursorByClick(e)), this.isEditing && (this.__selectionStartOnMouseDown = this.selectionStart, this.selectionStart === this.selectionEnd && this.abortCursorAnimation(), this.renderCursorOrSelection()), this.selected || (this.selected = s || this.isEditing)));
    }
    mouseUpHandler(t) {
        let { e: e, transform: s } = t;
        const i = this.draggableTextDelegate.end(e);
        if (this.canvas) {
            this.canvas.textEditingManager.unregister(this);
            const t = this.canvas._activeObject;
            if (t && t !== this) return;
        }
        !this.editable || this.group && !this.group.interactive || s && s.actionPerformed || yo(e) || i || this.selected && !this.getActiveControl() && (this.enterEditing(e), this.selectionStart === this.selectionEnd ? this.initDelayedCursor(!0) : this.renderCursorOrSelection());
    }
    setCursorByClick(t) {
        const e = this.getSelectionStartFromPointer(t), s = this.selectionStart, i = this.selectionEnd;
        t.shiftKey ? this.setSelectionStartEndWithShift(s, i, e) : (this.selectionStart = e, this.selectionEnd = e), this.isEditing && (this._fireSelectionChanged(), this._updateTextarea());
    }
    getSelectionStartFromPointer(t) {
        const e = this.canvas.getScenePoint(t).transform(wt(this.calcTransformMatrix())).add(new ot(-this._getLeftOffset(), -this._getTopOffset()));
        let s = 0, i = 0, r = 0;
        for(let t = 0; t < this._textLines.length && s <= e.y; t++)s += this.getHeightOfLine(t), r = t, t > 0 && (i += this._textLines[t - 1].length + this.missingNewlineOffset(t - 1));
        let n = Math.abs(this._getLineLeftOffset(r));
        const o = this._textLines[r].length, a = this.__charBounds[r];
        for(let t = 0; t < o; t++){
            const s = n + a[t].kernedWidth;
            if (e.x <= s) {
                Math.abs(e.x - s) <= Math.abs(e.x - n) && i++;
                break;
            }
            n = s, i++;
        }
        return Math.min(this.flipX ? o - i : i, this._text.length);
    }
}
const xo = "moveCursorUp", Co = "moveCursorDown", bo = "moveCursorLeft", So = "moveCursorRight", wo = "exitEditing", To = (t, e)=>{
    const s = e.getRetinaScaling();
    t.setTransform(s, 0, 0, s, 0, 0);
    const i = e.viewportTransform;
    t.transform(i[0], i[1], i[2], i[3], i[4], i[5]);
}, Oo = {
    selectionStart: 0,
    selectionEnd: 0,
    selectionColor: "rgba(17,119,255,0.3)",
    isEditing: !1,
    editable: !0,
    editingBorderColor: "rgba(102,153,255,0.25)",
    cursorWidth: 2,
    cursorColor: "",
    cursorDelay: 1e3,
    cursorDuration: 600,
    caching: !0,
    hiddenTextareaContainer: null,
    keysMap: {
        9: wo,
        27: wo,
        33: xo,
        34: Co,
        35: So,
        36: bo,
        37: bo,
        38: xo,
        39: So,
        40: Co
    },
    keysMapRtl: {
        9: wo,
        27: wo,
        33: xo,
        34: Co,
        35: bo,
        36: So,
        37: So,
        38: xo,
        39: bo,
        40: Co
    },
    ctrlKeysMapDown: {
        65: "cmdAll"
    },
    ctrlKeysMapUp: {
        67: "copy",
        88: "cut"
    },
    _selectionDirection: null,
    _reSpace: /\s|\r?\n/,
    inCompositionMode: !1
};
class ko extends _o {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...ko.ownDefaults
        };
    }
    get type() {
        const t = super.type;
        return "itext" === t ? "i-text" : t;
    }
    constructor(t, e){
        super(t, {
            ...ko.ownDefaults,
            ...e
        }), this.initBehavior();
    }
    _set(t, e) {
        return this.isEditing && this._savedProps && t in this._savedProps ? (this._savedProps[t] = e, this) : ("canvas" === t && (this.canvas instanceof Mn && this.canvas.textEditingManager.remove(this), e instanceof Mn && e.textEditingManager.add(this)), super._set(t, e));
    }
    setSelectionStart(t) {
        t = Math.max(t, 0), this._updateAndFire("selectionStart", t);
    }
    setSelectionEnd(t) {
        t = Math.min(t, this.text.length), this._updateAndFire("selectionEnd", t);
    }
    _updateAndFire(t, e) {
        this[t] !== e && (this._fireSelectionChanged(), this[t] = e), this._updateTextarea();
    }
    _fireSelectionChanged() {
        this.fire("selection:changed"), this.canvas && this.canvas.fire("text:selection:changed", {
            target: this
        });
    }
    initDimensions() {
        this.isEditing && this.initDelayedCursor(), super.initDimensions();
    }
    getSelectionStyles() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.selectionStart || 0, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.selectionEnd, s = arguments.length > 2 ? arguments[2] : void 0;
        return super.getSelectionStyles(t, e, s);
    }
    setSelectionStyles(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.selectionStart || 0, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.selectionEnd;
        return super.setSelectionStyles(t, e, s);
    }
    get2DCursorLocation() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.selectionStart, e = arguments.length > 1 ? arguments[1] : void 0;
        return super.get2DCursorLocation(t, e);
    }
    render(t) {
        super.render(t), this.cursorOffsetCache = {}, this.renderCursorOrSelection();
    }
    toCanvasElement(t) {
        const e = this.isEditing;
        this.isEditing = !1;
        const s = super.toCanvasElement(t);
        return this.isEditing = e, s;
    }
    renderCursorOrSelection() {
        if (!this.isEditing || !this.canvas) return;
        const t = this.clearContextTop(!0);
        if (!t) return;
        const e = this._getCursorBoundaries(), s = this.findAncestorsWithClipPath(), i = s.length > 0;
        let r, n = t;
        if (i) {
            r = vt(t.canvas), n = r.getContext("2d"), To(n, this.canvas);
            const e = this.calcTransformMatrix();
            n.transform(e[0], e[1], e[2], e[3], e[4], e[5]);
        }
        if (this.selectionStart !== this.selectionEnd || this.inCompositionMode ? this.renderSelection(n, e) : this.renderCursor(n, e), i) for (const e of s){
            const s = e.clipPath, i = vt(t.canvas), r = i.getContext("2d");
            if (To(r, this.canvas), !s.absolutePositioned) {
                const t = e.calcTransformMatrix();
                r.transform(t[0], t[1], t[2], t[3], t[4], t[5]);
            }
            s.transform(r), s.drawObject(r, !0, {}), this.drawClipPathOnCache(n, s, i);
        }
        i && (t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(r, 0, 0)), this.canvas.contextTopDirty = !0, t.restore();
    }
    findAncestorsWithClipPath() {
        const t = [];
        let e = this;
        for(; e;)e.clipPath && t.push(e), e = e.parent;
        return t;
    }
    _getCursorBoundaries() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.selectionStart, e = arguments.length > 1 ? arguments[1] : void 0;
        const s = this._getLeftOffset(), i = this._getTopOffset(), r = this._getCursorBoundariesOffsets(t, e);
        return {
            left: s,
            top: i,
            leftOffset: r.left,
            topOffset: r.top
        };
    }
    _getCursorBoundariesOffsets(t, e) {
        return e ? this.__getCursorBoundariesOffsets(t) : this.cursorOffsetCache && "top" in this.cursorOffsetCache ? this.cursorOffsetCache : this.cursorOffsetCache = this.__getCursorBoundariesOffsets(t);
    }
    __getCursorBoundariesOffsets(t) {
        let e = 0, s = 0;
        const { charIndex: i, lineIndex: r } = this.get2DCursorLocation(t), { textAlign: n, direction: o } = this;
        for(let t = 0; t < r; t++)e += this.getHeightOfLine(t);
        const a = this._getLineLeftOffset(r), h = this.__charBounds[r][i];
        h && (s = h.left), 0 !== this.charSpacing && i === this._textLines[r].length && (s -= this._getWidthOfCharSpacing());
        let l = a + (s > 0 ? s : 0);
        return o === K && (n === M || n === cs || n === ds ? l *= -1 : n === O || n === us ? l = a - (s > 0 ? s : 0) : n !== T && n !== gs || (l = a - (s > 0 ? s : 0))), {
            top: e,
            left: l
        };
    }
    renderCursorAt(t) {
        this._renderCursor(this.canvas.contextTop, this._getCursorBoundaries(t, !0), t);
    }
    renderCursor(t, e) {
        this._renderCursor(t, e, this.selectionStart);
    }
    getCursorRenderingData() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.selectionStart, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this._getCursorBoundaries(t);
        const s = this.get2DCursorLocation(t), i = s.lineIndex, r = s.charIndex > 0 ? s.charIndex - 1 : 0, n = this.getValueOfPropertyAt(i, r, "fontSize"), o = this.getObjectScaling().x * this.canvas.getZoom(), a = this.cursorWidth / o, h = this.getValueOfPropertyAt(i, r, "deltaY"), l = e.topOffset + (1 - this._fontSizeFraction) * this.getHeightOfLine(i) / this.lineHeight - n * (1 - this._fontSizeFraction);
        return {
            color: this.cursorColor || this.getValueOfPropertyAt(i, r, "fill"),
            opacity: this._currentCursorOpacity,
            left: e.left + e.leftOffset - a / 2,
            top: l + e.top + h,
            width: a,
            height: n
        };
    }
    _renderCursor(t, e, s) {
        const { color: i, opacity: r, left: n, top: o, width: a, height: h } = this.getCursorRenderingData(s, e);
        t.fillStyle = i, t.globalAlpha = r, t.fillRect(n, o, a, h);
    }
    renderSelection(t, e) {
        const s = {
            selectionStart: this.inCompositionMode ? this.hiddenTextarea.selectionStart : this.selectionStart,
            selectionEnd: this.inCompositionMode ? this.hiddenTextarea.selectionEnd : this.selectionEnd
        };
        this._renderSelection(t, s, e);
    }
    renderDragSourceEffect() {
        const t = this.draggableTextDelegate.getDragStartSelection();
        this._renderSelection(this.canvas.contextTop, t, this._getCursorBoundaries(t.selectionStart, !0));
    }
    renderDropTargetEffect(t) {
        const e = this.getSelectionStartFromPointer(t);
        this.renderCursorAt(e);
    }
    _renderSelection(t, e, s) {
        const { textAlign: i, direction: r } = this, n = e.selectionStart, o = e.selectionEnd, a = i.includes(cs), h = this.get2DCursorLocation(n), l = this.get2DCursorLocation(o), c = h.lineIndex, u = l.lineIndex, d = h.charIndex < 0 ? 0 : h.charIndex, g = l.charIndex < 0 ? 0 : l.charIndex;
        for(let e = c; e <= u; e++){
            const n = this._getLineLeftOffset(e) || 0;
            let o = this.getHeightOfLine(e), h = 0, l = 0, f = 0;
            if (e === c && (l = this.__charBounds[c][d].left), e >= c && e < u) f = a && !this.isEndOfWrapping(e) ? this.width : this.getLineWidth(e) || 5;
            else if (e === u) if (0 === g) f = this.__charBounds[u][g].left;
            else {
                const t = this._getWidthOfCharSpacing();
                f = this.__charBounds[u][g - 1].left + this.__charBounds[u][g - 1].width - t;
            }
            h = o, (this.lineHeight < 1 || e === u && this.lineHeight > 1) && (o /= this.lineHeight);
            let p = s.left + n + l, m = o, v = 0;
            const y = f - l;
            this.inCompositionMode ? (t.fillStyle = this.compositionColor || "black", m = 1, v = o) : t.fillStyle = this.selectionColor, r === K && (i === M || i === cs || i === ds ? p = this.width - p - y : i === O || i === us ? p = s.left + n - f : i !== T && i !== gs || (p = s.left + n - f)), t.fillRect(p, s.top + s.topOffset + v, y, m), s.topOffset += h;
        }
    }
    getCurrentCharFontSize() {
        const t = this._getCurrentCharIndex();
        return this.getValueOfPropertyAt(t.l, t.c, "fontSize");
    }
    getCurrentCharColor() {
        const t = this._getCurrentCharIndex();
        return this.getValueOfPropertyAt(t.l, t.c, H);
    }
    _getCurrentCharIndex() {
        const t = this.get2DCursorLocation(this.selectionStart, !0), e = t.charIndex > 0 ? t.charIndex - 1 : 0;
        return {
            l: t.lineIndex,
            c: e
        };
    }
    dispose() {
        this.exitEditingImpl(), this.draggableTextDelegate.dispose(), super.dispose();
    }
}
t(ko, "ownDefaults", Oo), t(ko, "type", "IText"), tt.setClass(ko), tt.setClass(ko, "i-text");
class Do extends ko {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...Do.ownDefaults
        };
    }
    constructor(t, e){
        super(t, {
            ...Do.ownDefaults,
            ...e
        });
    }
    static createControls() {
        return {
            controls: Pi()
        };
    }
    initDimensions() {
        this.initialized && (this.isEditing && this.initDelayedCursor(), this._clearCache(), this.dynamicMinWidth = 0, this._styleMap = this._generateStyleMap(this._splitText()), this.dynamicMinWidth > this.width && this._set("width", this.dynamicMinWidth), this.textAlign.includes(cs) && this.enlargeSpaces(), this.height = this.calcTextHeight());
    }
    _generateStyleMap(t) {
        let e = 0, s = 0, i = 0;
        const r = {};
        for(let n = 0; n < t.graphemeLines.length; n++)"\n" === t.graphemeText[i] && n > 0 ? (s = 0, i++, e++) : !this.splitByGrapheme && this._reSpaceAndTab.test(t.graphemeText[i]) && n > 0 && (s++, i++), r[n] = {
            line: e,
            offset: s
        }, i += t.graphemeLines[n].length, s += t.graphemeLines[n].length;
        return r;
    }
    styleHas(t, e) {
        if (this._styleMap && !this.isWrapping) {
            const t = this._styleMap[e];
            t && (e = t.line);
        }
        return super.styleHas(t, e);
    }
    isEmptyStyles(t) {
        if (!this.styles) return !0;
        let e, s = 0, i = t + 1, r = !1;
        const n = this._styleMap[t], o = this._styleMap[t + 1];
        n && (t = n.line, s = n.offset), o && (i = o.line, r = i === t, e = o.offset);
        const a = void 0 === t ? this.styles : {
            line: this.styles[t]
        };
        for(const t in a)for(const i in a[t]){
            const n = parseInt(i, 10);
            if (n >= s && (!r || n < e)) for(const e in a[t][i])return !1;
        }
        return !0;
    }
    _getStyleDeclaration(t, e) {
        if (this._styleMap && !this.isWrapping) {
            const s = this._styleMap[t];
            if (!s) return {};
            t = s.line, e = s.offset + e;
        }
        return super._getStyleDeclaration(t, e);
    }
    _setStyleDeclaration(t, e, s) {
        const i = this._styleMap[t];
        super._setStyleDeclaration(i.line, i.offset + e, s);
    }
    _deleteStyleDeclaration(t, e) {
        const s = this._styleMap[t];
        super._deleteStyleDeclaration(s.line, s.offset + e);
    }
    _getLineStyle(t) {
        const e = this._styleMap[t];
        return !!this.styles[e.line];
    }
    _setLineStyle(t) {
        const e = this._styleMap[t];
        super._setLineStyle(e.line);
    }
    _wrapText(t, e) {
        this.isWrapping = !0;
        const s = this.getGraphemeDataForRender(t), i = [];
        for(let t = 0; t < s.wordsData.length; t++)i.push(...this._wrapLine(t, e, s));
        return this.isWrapping = !1, i;
    }
    getGraphemeDataForRender(t) {
        const e = this.splitByGrapheme, s = e ? "" : " ";
        let i = 0;
        return {
            wordsData: t.map((t, r)=>{
                let n = 0;
                const o = e ? this.graphemeSplit(t) : this.wordSplit(t);
                return 0 === o.length ? [
                    {
                        word: [],
                        width: 0
                    }
                ] : o.map((t)=>{
                    const o = e ? [
                        t
                    ] : this.graphemeSplit(t), a = this._measureWord(o, r, n);
                    return i = Math.max(a, i), n += o.length + s.length, {
                        word: o,
                        width: a
                    };
                });
            }),
            largestWordWidth: i
        };
    }
    _measureWord(t, e) {
        let s, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, r = 0;
        for(let n = 0, o = t.length; n < o; n++){
            r += this._getGraphemeBox(t[n], e, n + i, s, true).kernedWidth, s = t[n];
        }
        return r;
    }
    wordSplit(t) {
        return t.split(this._wordJoiners);
    }
    _wrapLine(t, e, s) {
        let { largestWordWidth: i, wordsData: r } = s, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const o = this._getWidthOfCharSpacing(), a = this.splitByGrapheme, h = [], l = a ? "" : " ";
        let c = 0, u = [], d = 0, g = 0, f = !0;
        e -= n;
        const p = Math.max(e, i, this.dynamicMinWidth), m = r[t];
        let v;
        for(d = 0, v = 0; v < m.length; v++){
            const { word: e, width: s } = m[v];
            d += e.length, c += g + s - o, c > p && !f ? (h.push(u), u = [], c = s, f = !0) : c += o, f || a || u.push(l), u = u.concat(e), g = a ? 0 : this._measureWord([
                l
            ], t, d), d++, f = !1;
        }
        return v && h.push(u), i + n > this.dynamicMinWidth && (this.dynamicMinWidth = i - o + n), h;
    }
    isEndOfWrapping(t) {
        return !this._styleMap[t + 1] || this._styleMap[t + 1].line !== this._styleMap[t].line;
    }
    missingNewlineOffset(t, e) {
        return this.splitByGrapheme && !e ? this.isEndOfWrapping(t) ? 1 : 0 : 1;
    }
    _splitTextIntoLines(t) {
        const e = super._splitTextIntoLines(t), s = this._wrapText(e.lines, this.width), i = new Array(s.length);
        for(let t = 0; t < s.length; t++)i[t] = s[t].join("");
        return e.lines = i, e.graphemeLines = s, e;
    }
    getMinWidth() {
        return Math.max(this.minWidth, this.dynamicMinWidth);
    }
    _removeExtraneousStyles() {
        const t = new Map;
        for(const e in this._styleMap){
            const s = parseInt(e, 10);
            if (this._textLines[s]) {
                const s = this._styleMap[e].line;
                t.set(`${s}`, !0);
            }
        }
        for(const e in this.styles)t.has(e) || delete this.styles[e];
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return super.toObject([
            "minWidth",
            "splitByGrapheme",
            ...t
        ]);
    }
}
t(Do, "type", "Textbox"), t(Do, "textLayoutProperties", [
    ...ko.textLayoutProperties,
    "width"
]), t(Do, "ownDefaults", {
    minWidth: 20,
    dynamicMinWidth: 2,
    lockScalingFlip: !0,
    noScaleCache: !1,
    _wordJoiners: /[ \t\r]/,
    splitByGrapheme: !1
}), tt.setClass(Do);
class Mo extends Cr {
    shouldPerformLayout(t) {
        return !!t.target.clipPath && super.shouldPerformLayout(t);
    }
    shouldLayoutClipPath() {
        return !1;
    }
    calcLayoutResult(t, e) {
        const { target: s } = t, { clipPath: i, group: r } = s;
        if (!i || !this.shouldPerformLayout(t)) return;
        const { width: n, height: o } = ge(xr(s, i)), a = new ot(n, o);
        if (i.absolutePositioned) {
            return {
                center: xe(i.getRelativeCenterPoint(), void 0, r ? r.calcTransformMatrix() : void 0),
                size: a
            };
        }
        {
            const r = i.getRelativeCenterPoint().transform(s.calcOwnMatrix(), !0);
            if (this.shouldPerformLayout(t)) {
                const { center: s = new ot, correction: i = new ot } = this.calcBoundingBox(e, t) || {};
                return {
                    center: s.add(r),
                    correction: i.subtract(r),
                    size: a
                };
            }
            return {
                center: s.getRelativeCenterPoint().add(r),
                size: a
            };
        }
    }
}
t(Mo, "type", "clip-path"), tt.setClass(Mo);
class Po extends Cr {
    getInitialSize(t, e) {
        let { target: s } = t, { size: i } = e;
        return new ot(s.width || i.x, s.height || i.y);
    }
}
t(Po, "type", "fixed"), tt.setClass(Po);
class Eo extends wr {
    subscribeTargets(t) {
        const e = t.target;
        t.targets.reduce((t, e)=>(e.parent && t.add(e.parent), t), new Set).forEach((t)=>{
            t.layoutManager.subscribeTargets({
                target: t,
                targets: [
                    e
                ]
            });
        });
    }
    unsubscribeTargets(t) {
        const e = t.target, s = e.getObjects();
        t.targets.reduce((t, e)=>(e.parent && t.add(e.parent), t), new Set).forEach((t)=>{
            !s.some((e)=>e.parent === t) && t.layoutManager.unsubscribeTargets({
                target: t,
                targets: [
                    e
                ]
            });
        });
    }
}
class Ao extends Or {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...Ao.ownDefaults
        };
    }
    constructor(){
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(), Object.assign(this, Ao.ownDefaults), this.setOptions(e);
        const { left: s, top: i, layoutManager: r } = e;
        this.groupInit(t, {
            left: s,
            top: i,
            layoutManager: null != r ? r : new Eo
        });
    }
    _shouldSetNestedCoords() {
        return !0;
    }
    __objectSelectionMonitor() {}
    multiSelectAdd() {
        for(var t = arguments.length, e = new Array(t), s = 0; s < t; s++)e[s] = arguments[s];
        "selection-order" === this.multiSelectionStacking ? this.add(...e) : e.forEach((t)=>{
            const e = this._objects.findIndex((e)=>e.isInFrontOf(t)), s = -1 === e ? this.size() : e;
            this.insertAt(s, t);
        });
    }
    canEnterGroup(t) {
        return this.getObjects().some((e)=>e.isDescendantOf(t) || t.isDescendantOf(e)) ? (i("error", "ActiveSelection: circular object trees are not supported, this call has no effect"), !1) : super.canEnterGroup(t);
    }
    enterGroup(t, e) {
        t.parent && t.parent === t.group ? t.parent._exitGroup(t) : t.group && t.parent !== t.group && t.group.remove(t), this._enterGroup(t, e);
    }
    exitGroup(t, e) {
        this._exitGroup(t, e), t.parent && t.parent._enterGroup(t, !0);
    }
    _onAfterObjectsChange(t, e) {
        super._onAfterObjectsChange(t, e);
        const s = new Set;
        e.forEach((t)=>{
            const { parent: e } = t;
            e && s.add(e);
        }), t === yr ? s.forEach((t)=>{
            t._onAfterObjectsChange(vr, e);
        }) : s.forEach((t)=>{
            t._set("dirty", !0);
        });
    }
    onDeselect() {
        return this.removeAll(), !1;
    }
    toString() {
        return `#<ActiveSelection: (${this.complexity()})>`;
    }
    shouldCache() {
        return !1;
    }
    isOnACache() {
        return !1;
    }
    _renderControls(t, e, s) {
        t.save(), t.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1;
        const i = {
            hasControls: !1,
            ...s,
            forActiveSelection: !0
        };
        for(let e = 0; e < this._objects.length; e++)this._objects[e]._renderControls(t, i);
        super._renderControls(t, e), t.restore();
    }
}
t(Ao, "type", "ActiveSelection"), t(Ao, "ownDefaults", {
    multiSelectionStacking: "canvas-stacking"
}), tt.setClass(Ao), tt.setClass(Ao, "activeSelection");
class jo {
    constructor(){
        t(this, "resources", {});
    }
    applyFilters(t, e, s, i, r) {
        const n = r.getContext("2d", {
            willReadFrequently: !0,
            desynchronized: !0
        });
        if (!n) return;
        n.drawImage(e, 0, 0, s, i);
        const o = {
            sourceWidth: s,
            sourceHeight: i,
            imageData: n.getImageData(0, 0, s, i),
            originalEl: e,
            originalImageData: n.getImageData(0, 0, s, i),
            canvasEl: r,
            ctx: n,
            filterBackend: this
        };
        t.forEach((t)=>{
            t.applyTo(o);
        });
        const { imageData: a } = o;
        return a.width === s && a.height === i || (r.width = a.width, r.height = a.height), n.putImageData(a, 0, 0), o;
    }
}
class Fo {
    constructor(){
        let { tileSize: e = s.textureSize } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        t(this, "aPosition", new Float32Array([
            0,
            0,
            0,
            1,
            1,
            0,
            1,
            1
        ])), t(this, "resources", {}), this.tileSize = e, this.setupGLContext(e, e), this.captureGPUInfo();
    }
    setupGLContext(t, e) {
        this.dispose(), this.createWebGLCanvas(t, e);
    }
    createWebGLCanvas(t, e) {
        const s = vt({
            width: t,
            height: e
        }), i = s.getContext("webgl", {
            alpha: !0,
            premultipliedAlpha: !1,
            depth: !1,
            stencil: !1,
            antialias: !1
        });
        i && (i.clearColor(0, 0, 0, 0), this.canvas = s, this.gl = i);
    }
    applyFilters(t, e, s, i, r, n) {
        const o = this.gl, a = r.getContext("2d");
        if (!o || !a) return;
        let h;
        n && (h = this.getCachedTexture(n, e));
        const l = {
            originalWidth: e.width || e.naturalWidth || 0,
            originalHeight: e.height || e.naturalHeight || 0,
            sourceWidth: s,
            sourceHeight: i,
            destinationWidth: s,
            destinationHeight: i,
            context: o,
            sourceTexture: this.createTexture(o, s, i, h ? void 0 : e),
            targetTexture: this.createTexture(o, s, i),
            originalTexture: h || this.createTexture(o, s, i, h ? void 0 : e),
            passes: t.length,
            webgl: !0,
            aPosition: this.aPosition,
            programCache: this.programCache,
            pass: 0,
            filterBackend: this,
            targetCanvas: r
        }, c = o.createFramebuffer();
        return o.bindFramebuffer(o.FRAMEBUFFER, c), t.forEach((t)=>{
            t && t.applyTo(l);
        }), function(t) {
            const e = t.targetCanvas, s = e.width, i = e.height, r = t.destinationWidth, n = t.destinationHeight;
            s === r && i === n || (e.width = r, e.height = n);
        }(l), this.copyGLTo2D(o, l), o.bindTexture(o.TEXTURE_2D, null), o.deleteTexture(l.sourceTexture), o.deleteTexture(l.targetTexture), o.deleteFramebuffer(c), a.setTransform(1, 0, 0, 1, 0, 0), l;
    }
    dispose() {
        this.canvas && (this.canvas = null, this.gl = null), this.clearWebGLCaches();
    }
    clearWebGLCaches() {
        this.programCache = {}, this.textureCache = {};
    }
    createTexture(t, e, s, i, r) {
        const { NEAREST: n, TEXTURE_2D: o, RGBA: a, UNSIGNED_BYTE: h, CLAMP_TO_EDGE: l, TEXTURE_MAG_FILTER: c, TEXTURE_MIN_FILTER: u, TEXTURE_WRAP_S: d, TEXTURE_WRAP_T: g } = t, f = t.createTexture();
        return t.bindTexture(o, f), t.texParameteri(o, c, r || n), t.texParameteri(o, u, r || n), t.texParameteri(o, d, l), t.texParameteri(o, g, l), i ? t.texImage2D(o, 0, a, a, h, i) : t.texImage2D(o, 0, a, e, s, 0, a, h, null), f;
    }
    getCachedTexture(t, e, s) {
        const { textureCache: i } = this;
        if (i[t]) return i[t];
        {
            const r = this.createTexture(this.gl, e.width, e.height, e, s);
            return r && (i[t] = r), r;
        }
    }
    evictCachesForKey(t) {
        this.textureCache[t] && (this.gl.deleteTexture(this.textureCache[t]), delete this.textureCache[t]);
    }
    copyGLTo2D(t, e) {
        const s = t.canvas, i = e.targetCanvas, r = i.getContext("2d");
        if (!r) return;
        r.translate(0, i.height), r.scale(1, -1);
        const n = s.height - i.height;
        r.drawImage(s, 0, n, i.width, i.height, 0, 0, i.width, i.height);
    }
    copyGLTo2DPutImageData(t, e) {
        const s = e.targetCanvas.getContext("2d"), i = e.destinationWidth, r = e.destinationHeight, n = i * r * 4;
        if (!s) return;
        const o = new Uint8Array(this.imageBuffer, 0, n), a = new Uint8ClampedArray(this.imageBuffer, 0, n);
        t.readPixels(0, 0, i, r, t.RGBA, t.UNSIGNED_BYTE, o);
        const h = new ImageData(a, i, r);
        s.putImageData(h, 0, 0);
    }
    captureGPUInfo() {
        if (this.gpuInfo) return this.gpuInfo;
        const t = this.gl, e = {
            renderer: "",
            vendor: ""
        };
        if (!t) return e;
        const s = t.getExtension("WEBGL_debug_renderer_info");
        if (s) {
            const i = t.getParameter(s.UNMASKED_RENDERER_WEBGL), r = t.getParameter(s.UNMASKED_VENDOR_WEBGL);
            i && (e.renderer = i.toLowerCase()), r && (e.vendor = r.toLowerCase());
        }
        return this.gpuInfo = e, e;
    }
}
let Lo;
function Bo() {
    const { WebGLProbe: t } = u();
    return t.queryWebGL(pt()), s.enableGLFiltering && t.isSupported(s.textureSize) ? new Fo({
        tileSize: s.textureSize
    }) : new jo;
}
function Ro() {
    return !Lo && (!(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0]) && (Lo = Bo()), Lo;
}
function Io(t) {
    Lo = t;
}
const $o = [
    "cropX",
    "cropY"
];
class Xo extends ji {
    static getDefaults() {
        return {
            ...super.getDefaults(),
            ...Xo.ownDefaults
        };
    }
    constructor(e, s){
        super(), t(this, "_lastScaleX", 1), t(this, "_lastScaleY", 1), t(this, "_filterScalingX", 1), t(this, "_filterScalingY", 1), this.filters = [], Object.assign(this, Xo.ownDefaults), this.setOptions(s), this.cacheKey = `texture${ft()}`, this.setElement("string" == typeof e ? (this.canvas && qt(this.canvas.getElement()) || d()).getElementById(e) : e, s);
    }
    getElement() {
        return this._element;
    }
    setElement(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this.removeTexture(this.cacheKey), this.removeTexture(`${this.cacheKey}_filtered`), this._element = t, this._originalElement = t, this._setWidthHeight(e), 0 !== this.filters.length && this.applyFilters(), this.resizeFilter && this.applyResizeFilters();
    }
    removeTexture(t) {
        const e = Ro(!1);
        e instanceof Fo && e.evictCachesForKey(t);
    }
    dispose() {
        super.dispose(), this.removeTexture(this.cacheKey), this.removeTexture(`${this.cacheKey}_filtered`), this._cacheContext = null, [
            "_originalElement",
            "_element",
            "_filteredEl",
            "_cacheCanvas"
        ].forEach((t)=>{
            const e = this[t];
            e && u().dispose(e), this[t] = void 0;
        });
    }
    getCrossOrigin() {
        return this._originalElement && (this._originalElement.crossOrigin || null);
    }
    getOriginalSize() {
        const t = this.getElement();
        return t ? {
            width: t.naturalWidth || t.width,
            height: t.naturalHeight || t.height
        } : {
            width: 0,
            height: 0
        };
    }
    _stroke(t) {
        if (!this.stroke || 0 === this.strokeWidth) return;
        const e = this.width / 2, s = this.height / 2;
        t.beginPath(), t.moveTo(-e, -s), t.lineTo(e, -s), t.lineTo(e, s), t.lineTo(-e, s), t.lineTo(-e, -s), t.closePath();
    }
    toObject() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        const e = [];
        return this.filters.forEach((t)=>{
            t && e.push(t.toObject());
        }), {
            ...super.toObject([
                ...$o,
                ...t
            ]),
            src: this.getSrc(),
            crossOrigin: this.getCrossOrigin(),
            filters: e,
            ...this.resizeFilter ? {
                resizeFilter: this.resizeFilter.toObject()
            } : {}
        };
    }
    hasCrop() {
        return !!this.cropX || !!this.cropY || this.width < this._element.width || this.height < this._element.height;
    }
    _toSVG() {
        const t = [], e = this._element, s = -this.width / 2, i = -this.height / 2;
        let r = [], n = [], o = "", a = "";
        if (!e) return [];
        if (this.hasCrop()) {
            const t = ft();
            r.push('<clipPath id="imageCrop_' + t + '">\n', '\t<rect x="' + s + '" y="' + i + '" width="' + se(this.width) + '" height="' + se(this.height) + '" />\n', "</clipPath>\n"), o = ' clip-path="url(#imageCrop_' + t + ')" ';
        }
        if (this.imageSmoothing || (a = ' image-rendering="optimizeSpeed"'), t.push("\t<image ", "COMMON_PARTS", `xlink:href="${se(this.getSrc(!0))}" x="${s - this.cropX}" y="${i - this.cropY}" width="${e.width || e.naturalWidth}" height="${e.height || e.naturalHeight}"${a}${o}></image>\n`), this.stroke || this.strokeDashArray) {
            const t = this.fill;
            this.fill = null, n = [
                `\t<rect x="${s}" y="${i}" width="${se(this.width)}" height="${se(this.height)}" style="${this.getSvgStyles()}" />\n`
            ], this.fill = t;
        }
        return r = this.paintFirst !== H ? r.concat(n, t) : r.concat(t, n), r;
    }
    getSrc(t) {
        const e = t ? this._element : this._originalElement;
        return e ? e.toDataURL ? e.toDataURL() : this.srcFromAttribute ? e.getAttribute("src") || "" : e.src : this.src || "";
    }
    getSvgSrc(t) {
        return this.getSrc(t);
    }
    setSrc(t) {
        let { crossOrigin: e, signal: s } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return Rt(t, {
            crossOrigin: e,
            signal: s
        }).then((t)=>{
            void 0 !== e && this.set({
                crossOrigin: e
            }), this.setElement(t);
        });
    }
    toString() {
        return `#<Image: { src: "${this.getSrc()}" }>`;
    }
    applyResizeFilters() {
        const t = this.resizeFilter, e = this.minimumScaleTrigger, s = this.getTotalObjectScaling(), i = s.x, r = s.y, n = this._filteredEl || this._originalElement;
        if (this.group && this.set("dirty", !0), !t || i > e && r > e) return this._element = n, this._filterScalingX = 1, this._filterScalingY = 1, this._lastScaleX = i, void (this._lastScaleY = r);
        const o = vt(n), { width: a, height: h } = n;
        this._element = o, this._lastScaleX = t.scaleX = i, this._lastScaleY = t.scaleY = r, Ro().applyFilters([
            t
        ], n, a, h, this._element), this._filterScalingX = o.width / this._originalElement.width, this._filterScalingY = o.height / this._originalElement.height;
    }
    applyFilters() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.filters || [];
        if (t = t.filter((t)=>t && !t.isNeutralState()), this.set("dirty", !0), this.removeTexture(`${this.cacheKey}_filtered`), 0 === t.length) return this._element = this._originalElement, this._filteredEl = void 0, this._filterScalingX = 1, void (this._filterScalingY = 1);
        const e = this._originalElement, s = e.naturalWidth || e.width, i = e.naturalHeight || e.height;
        if (this._element === this._originalElement) {
            const t = vt({
                width: s,
                height: i
            });
            this._element = t, this._filteredEl = t;
        } else this._filteredEl && (this._element = this._filteredEl, this._filteredEl.getContext("2d").clearRect(0, 0, s, i), this._lastScaleX = 1, this._lastScaleY = 1);
        Ro().applyFilters(t, this._originalElement, s, i, this._element, this.cacheKey), this._originalElement.width === this._element.width && this._originalElement.height === this._element.height || (this._filterScalingX = this._element.width / this._originalElement.width, this._filterScalingY = this._element.height / this._originalElement.height);
    }
    _render(t) {
        t.imageSmoothingEnabled = this.imageSmoothing, !0 !== this.isMoving && this.resizeFilter && this._needsResize() && this.applyResizeFilters(), this._stroke(t), this._renderPaintInOrder(t);
    }
    drawCacheOnCanvas(t) {
        t.imageSmoothingEnabled = this.imageSmoothing, super.drawCacheOnCanvas(t);
    }
    shouldCache() {
        return this.needsItsOwnCache();
    }
    _renderFill(t) {
        const e = this._element;
        if (!e) return;
        const s = this._filterScalingX, i = this._filterScalingY, r = this.width, n = this.height, o = Math.max(this.cropX, 0), a = Math.max(this.cropY, 0), h = e.naturalWidth || e.width, l = e.naturalHeight || e.height, c = o * s, u = a * i, d = Math.min(r * s, h - c), g = Math.min(n * i, l - u), f = -r / 2, p = -n / 2, m = Math.min(r, h / s - o), v = Math.min(n, l / i - a);
        e && t.drawImage(e, c, u, d, g, f, p, m, v);
    }
    _needsResize() {
        const t = this.getTotalObjectScaling();
        return t.x !== this._lastScaleX || t.y !== this._lastScaleY;
    }
    _resetWidthHeight() {
        this.set(this.getOriginalSize());
    }
    _setWidthHeight() {
        let { width: t, height: e } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const s = this.getOriginalSize();
        this.width = t || s.width, this.height = e || s.height;
    }
    parsePreserveAspectRatioAttribute() {
        const t = Ze(this.preserveAspectRatio || ""), e = this.width, s = this.height, i = {
            width: e,
            height: s
        };
        let r, n = this._element.width, o = this._element.height, a = 1, h = 1, l = 0, c = 0, u = 0, d = 0;
        return !t || t.alignX === P && t.alignY === P ? (a = e / n, h = s / o) : ("meet" === t.meetOrSlice && (a = h = kr(this._element, i), r = (e - n * a) / 2, "Min" === t.alignX && (l = -r), "Max" === t.alignX && (l = r), r = (s - o * h) / 2, "Min" === t.alignY && (c = -r), "Max" === t.alignY && (c = r)), "slice" === t.meetOrSlice && (a = h = Dr(this._element, i), r = n - e / a, "Mid" === t.alignX && (u = r / 2), "Max" === t.alignX && (u = r), r = o - s / h, "Mid" === t.alignY && (d = r / 2), "Max" === t.alignY && (d = r), n = e / a, o = s / h)), {
            width: n,
            height: o,
            scaleX: a,
            scaleY: h,
            offsetLeft: l,
            offsetTop: c,
            cropX: u,
            cropY: d
        };
    }
    static fromObject(t, e) {
        let { filters: s, resizeFilter: i, src: r, crossOrigin: n, type: o, ...a } = t;
        return Promise.all([
            Rt(r, {
                ...e,
                crossOrigin: n
            }),
            s && It(s, e),
            i ? It([
                i
            ], e) : [],
            $t(a, e)
        ]).then((t)=>{
            let [e, s = [], [i], n = {}] = t;
            return new this(e, {
                ...a,
                src: r,
                filters: s,
                resizeFilter: i,
                ...n
            });
        });
    }
    static fromURL(t) {
        let { crossOrigin: e = null, signal: s } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, i = arguments.length > 2 ? arguments[2] : void 0;
        return Rt(t, {
            crossOrigin: e,
            signal: s
        }).then((t)=>new this(t, i));
    }
    static async fromElement(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = arguments.length > 2 ? arguments[2] : void 0;
        const r = gr(t, this.ATTRIBUTE_NAMES, s);
        return this.fromURL(r["xlink:href"] || r.href, e, r).catch((t)=>(i("log", "Unable to parse Image", t), null));
    }
}
function Yo(t) {
    if (!bs.test(t.nodeName)) return {};
    const e = t.getAttribute("viewBox");
    let s, i, r = 1, n = 1, o = 0, a = 0;
    const h = t.getAttribute("width"), l = t.getAttribute("height"), c = t.getAttribute("x") || 0, u = t.getAttribute("y") || 0, d = !(e && ws.test(e)), g = !h || !l || "100%" === h || "100%" === l;
    let f = "", p = 0, m = 0;
    if (d && (c || u) && t.parentNode && "#document" !== t.parentNode.nodeName && (f = " translate(" + Qe(c || "0") + " " + Qe(u || "0") + ") ", s = (t.getAttribute("transform") || "") + f, t.setAttribute("transform", s), t.removeAttribute("x"), t.removeAttribute("y")), d && g) return {
        width: 0,
        height: 0
    };
    const v = {
        width: 0,
        height: 0
    };
    if (d) return v.width = Qe(h), v.height = Qe(l), v;
    const y = e.match(ws);
    o = -parseFloat(y[1]), a = -parseFloat(y[2]);
    const _ = parseFloat(y[3]), x = parseFloat(y[4]);
    v.minX = o, v.minY = a, v.viewBoxWidth = _, v.viewBoxHeight = x, g ? (v.width = _, v.height = x) : (v.width = Qe(h), v.height = Qe(l), r = v.width / _, n = v.height / x);
    const C = Ze(t.getAttribute("preserveAspectRatio") || "");
    if (C.alignX !== P && ("meet" === C.meetOrSlice && (n = r = r > n ? n : r), "slice" === C.meetOrSlice && (n = r = r > n ? r : n), p = v.width - _ * r, m = v.height - x * r, "Mid" === C.alignX && (p /= 2), "Mid" === C.alignY && (m /= 2), "Min" === C.alignX && (p = 0), "Min" === C.alignY && (m = 0)), 1 === r && 1 === n && 0 === o && 0 === a && 0 === c && 0 === u) return v;
    if ((c || u) && "#document" !== t.parentNode.nodeName && (f = " translate(" + Qe(c || "0") + " " + Qe(u || "0") + ") "), s = f + " matrix(" + r + " 0 0 " + n + " " + (o * r + p) + " " + (a * n + m) + ") ", "svg" === t.nodeName) {
        for(i = t.ownerDocument.createElementNS(ms, "g"); t.firstChild;)i.appendChild(t.firstChild);
        t.appendChild(i);
    } else i = t, i.removeAttribute("x"), i.removeAttribute("y"), s = i.getAttribute("transform") + s;
    return i.setAttribute("transform", s), v;
}
t(Xo, "type", "Image"), t(Xo, "cacheProperties", [
    ...Ps,
    ...$o
]), t(Xo, "ownDefaults", {
    strokeWidth: 0,
    srcFromAttribute: !1,
    minimumScaleTrigger: .5,
    cropX: 0,
    cropY: 0,
    imageSmoothing: !0
}), t(Xo, "ATTRIBUTE_NAMES", [
    ...zi,
    "x",
    "y",
    "width",
    "height",
    "preserveAspectRatio",
    "xlink:href",
    "href",
    "crossOrigin",
    "image-rendering"
]), tt.setClass(Xo), tt.setSVGClass(Xo);
const Wo = (t)=>t.tagName.replace("svg:", ""), Vo = ss([
    "pattern",
    "defs",
    "symbol",
    "metadata",
    "clipPath",
    "mask",
    "desc"
]);
function zo(t, e) {
    let s, i, r, n, o = [];
    for(r = 0, n = e.length; r < n; r++)s = e[r], i = t.getElementsByTagNameNS("http://www.w3.org/2000/svg", s), o = o.concat(Array.from(i));
    return o;
}
const Go = [
    "gradientTransform",
    "x1",
    "x2",
    "y1",
    "y2",
    "gradientUnits",
    "cx",
    "cy",
    "r",
    "fx",
    "fy"
], Ho = "xlink:href";
function No(t, e) {
    var s;
    const i = (null === (s = e.getAttribute(Ho)) || void 0 === s ? void 0 : s.slice(1)) || "", r = t.getElementById(i);
    if (r && r.getAttribute(Ho) && No(t, r), r && (Go.forEach((t)=>{
        const s = r.getAttribute(t);
        !e.hasAttribute(t) && s && e.setAttribute(t, s);
    }), !e.children.length)) {
        const t = r.cloneNode(!0);
        for(; t.firstChild;)e.appendChild(t.firstChild);
    }
    e.removeAttribute(Ho);
}
const Uo = [
    "linearGradient",
    "radialGradient",
    "svg:linearGradient",
    "svg:radialGradient"
];
const qo = (t)=>tt.getSVGClass(Wo(t).toLowerCase());
class Ko {
    constructor(t, e, s, i, r){
        this.elements = t, this.options = e, this.reviver = s, this.regexUrl = /^url\(['"]?#([^'"]+)['"]?\)/g, this.doc = i, this.clipPaths = r, this.gradientDefs = function(t) {
            const e = zo(t, Uo), s = {};
            let i = e.length;
            for(; i--;){
                const r = e[i];
                r.getAttribute("xlink:href") && No(t, r);
                const n = r.getAttribute("id");
                n && (s[n] = r);
            }
            return s;
        }(i), this.cssRules = function(t) {
            const e = t.getElementsByTagName("style"), s = {};
            for(let t = 0; t < e.length; t++){
                const i = (e[t].textContent || "").replace(/\/\*[\s\S]*?\*\//g, "");
                "" !== i.trim() && i.split("}").filter((t, e, s)=>s.length > 1 && t.trim()).forEach((t)=>{
                    if ((t.match(/{/g) || []).length > 1 && t.trim().startsWith("@")) return;
                    const e = t.split("{"), i = {}, r = e[1].trim().split(";").filter(function(t) {
                        return t.trim();
                    });
                    for(let t = 0; t < r.length; t++){
                        const e = r[t].split(":"), s = e[0].trim(), n = e[1].trim();
                        i[s] = n;
                    }
                    (t = e[0].trim()).split(",").forEach((t)=>{
                        "" !== (t = t.replace(/^svg/i, "").trim()) && (s[t] = {
                            ...s[t] || {},
                            ...i
                        });
                    });
                });
            }
            return s;
        }(i);
    }
    parse() {
        return Promise.all(this.elements.map((t)=>this.createObject(t)));
    }
    async createObject(t) {
        const e = qo(t);
        if (e) {
            const s = await e.fromElement(t, this.options, this.cssRules);
            return this.resolveGradient(s, t, H), this.resolveGradient(s, t, N), s instanceof Xo && s._originalElement ? nn(s, s.parsePreserveAspectRatioAttribute()) : nn(s), await this.resolveClipPath(s, t), this.reviver && this.reviver(t, s), s;
        }
        return null;
    }
    extractPropertyDefinition(t, e, s) {
        const i = t[e], r = this.regexUrl;
        if (!r.test(i)) return;
        r.lastIndex = 0;
        const n = r.exec(i)[1];
        return r.lastIndex = 0, s[n];
    }
    resolveGradient(t, e, s) {
        const i = this.extractPropertyDefinition(t, s, this.gradientDefs);
        if (i) {
            const r = e.getAttribute(s + "-opacity"), n = Vn.fromElement(i, t, {
                ...this.options,
                opacity: r
            });
            t.set(s, n);
        }
    }
    async resolveClipPath(t, e, s) {
        const i = this.extractPropertyDefinition(t, "clipPath", this.clipPaths);
        if (i) {
            const r = wt(t.calcTransformMatrix()), n = i[0].parentElement;
            let o = e;
            for(; !s && o.parentElement && o.getAttribute("clip-path") !== t.clipPath;)o = o.parentElement;
            o.parentElement.appendChild(n);
            const a = hr(`${o.getAttribute("transform") || ""} ${n.getAttribute("originalTransform") || ""}`);
            n.setAttribute("transform", `matrix(${a.join(",")})`);
            const h = await Promise.all(i.map((t)=>qo(t).fromElement(t, this.options, this.cssRules).then((t)=>(nn(t), t.fillRule = t.clipRule, delete t.clipRule, t)))), l = 1 === h.length ? h[0] : new Or(h), c = Tt(r, l.calcTransformMatrix());
            l.clipPath && await this.resolveClipPath(l, o, n.getAttribute("clip-path") ? o : void 0);
            const { scaleX: u, scaleY: d, angle: g, skewX: f, translateX: p, translateY: m } = Dt(c);
            l.set({
                flipX: !1,
                flipY: !1
            }), l.set({
                scaleX: u,
                scaleY: d,
                angle: g,
                skewX: f,
                skewY: 0
            }), l.setPositionByOrigin(new ot(p, m), T, T), t.clipPath = l;
        } else delete t.clipPath;
    }
}
const Jo = (t)=>Cs.test(Wo(t));
async function Qo(t, e) {
    let { crossOrigin: s, signal: r } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    if (r && r.aborted) return i("log", new n("parseSVGDocument")), {
        objects: [],
        elements: [],
        options: {},
        allElements: []
    };
    const o = t.documentElement;
    !function(t) {
        const e = zo(t, [
            "use",
            "svg:use"
        ]), s = [
            "x",
            "y",
            "xlink:href",
            "href",
            "transform"
        ];
        for (const i of e){
            const e = i.attributes, r = {};
            for (const t of e)t.value && (r[t.name] = t.value);
            const n = (r["xlink:href"] || r.href || "").slice(1);
            if ("" === n) return;
            const o = t.getElementById(n);
            if (null === o) return;
            let a = o.cloneNode(!0);
            const h = a.attributes, l = {};
            for (const t of h)t.value && (l[t.name] = t.value);
            const { x: c = 0, y: u = 0, transform: d = "" } = r, g = `${d} ${l.transform || ""} translate(${c}, ${u})`;
            if (Yo(a), /^svg$/i.test(a.nodeName)) {
                const t = a.ownerDocument.createElementNS(ms, "g");
                Object.entries(l).forEach((e)=>{
                    let [s, i] = e;
                    return t.setAttributeNS(ms, s, i);
                }), t.append(...a.childNodes), a = t;
            }
            for (const t of e){
                if (!t) continue;
                const { name: e, value: i } = t;
                if (!s.includes(e)) if ("style" === e) {
                    const t = {};
                    cr(i, t), Object.entries(l).forEach((e)=>{
                        let [s, i] = e;
                        t[s] = i;
                    }), cr(l.style || "", t);
                    const s = Object.entries(t).map((t)=>t.join(":")).join(";");
                    a.setAttribute(e, s);
                } else !l[e] && a.setAttribute(e, i);
            }
            a.setAttribute("transform", g), a.setAttribute("instantiated_by_use", "1"), a.removeAttribute("id"), i.parentNode.replaceChild(a, i);
        }
    }(t);
    const a = Array.from(o.getElementsByTagName("*")), h = {
        ...Yo(o),
        crossOrigin: s,
        signal: r
    }, l = a.filter((t)=>(Yo(t), Jo(t) && !function(t) {
            let e = t;
            for(; e && (e = e.parentElement);)if (e && e.nodeName && Vo.test(Wo(e)) && !e.getAttribute("instantiated_by_use")) return !0;
            return !1;
        }(t)));
    if (!l || l && !l.length) return {
        objects: [],
        elements: [],
        options: {},
        allElements: [],
        options: h,
        allElements: a
    };
    const c = {};
    a.filter((t)=>"clipPath" === Wo(t)).forEach((t)=>{
        t.setAttribute("originalTransform", t.getAttribute("transform") || "");
        const e = t.getAttribute("id");
        c[e] = Array.from(t.getElementsByTagName("*")).filter((t)=>Jo(t));
    });
    const u = new Ko(l, h, e, t, c);
    return {
        objects: await u.parse(),
        elements: l,
        options: h,
        allElements: a
    };
}
function Zo(t, e, s) {
    return Qo((new (g()).DOMParser).parseFromString(t.trim(), "text/xml"), e, s);
}
function ta(t, e) {
    let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    return fetch(t.replace(/^\n\s*/, "").trim(), {
        signal: s.signal
    }).then((t)=>{
        if (!t.ok) throw new r(`HTTP error! status: ${t.status}`);
        return t.text();
    }).then((t)=>Zo(t, e, s)).catch(()=>({
            objects: [],
            elements: [],
            options: {},
            allElements: []
        }));
}
const ea = (t)=>void 0 !== t.webgl, sa = (t, e)=>{
    const s = vt({
        width: t,
        height: e
    }), i = pt().getContext("webgl"), r = {
        imageBuffer: new ArrayBuffer(t * e * 4)
    }, n = {
        destinationWidth: t,
        destinationHeight: e,
        targetCanvas: s
    };
    let o;
    o = g().performance.now(), Fo.prototype.copyGLTo2D.call(r, i, n);
    const a = g().performance.now() - o;
    o = g().performance.now(), Fo.prototype.copyGLTo2DPutImageData.call(r, i, n);
    return a > g().performance.now() - o;
}, ia = "precision highp float", ra = `\n    ${ia};\n    varying vec2 vTexCoord;\n    uniform sampler2D uTexture;\n    void main() {\n      gl_FragColor = texture2D(uTexture, vTexCoord);\n    }`, na = new RegExp(ia, "g");
class oa {
    get type() {
        return this.constructor.type;
    }
    constructor(){
        let { type: t, ...e } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        Object.assign(this, this.constructor.defaults, e);
    }
    getFragmentSource() {
        return ra;
    }
    getVertexSource() {
        return "\n    attribute vec2 aPosition;\n    varying vec2 vTexCoord;\n    void main() {\n      vTexCoord = aPosition;\n      gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);\n    }";
    }
    createProgram(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.getFragmentSource(), s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.getVertexSource();
        const { WebGLProbe: { GLPrecision: i = "highp" } } = u();
        "highp" !== i && (e = e.replace(na, ia.replace("highp", i)));
        const n = t.createShader(t.VERTEX_SHADER), o = t.createShader(t.FRAGMENT_SHADER), a = t.createProgram();
        if (!n || !o || !a) throw new r("Vertex, fragment shader or program creation error");
        if (t.shaderSource(n, s), t.compileShader(n), !t.getShaderParameter(n, t.COMPILE_STATUS)) throw new r(`Vertex shader compile error for ${this.type}: ${t.getShaderInfoLog(n)}`);
        if (t.shaderSource(o, e), t.compileShader(o), !t.getShaderParameter(o, t.COMPILE_STATUS)) throw new r(`Fragment shader compile error for ${this.type}: ${t.getShaderInfoLog(o)}`);
        if (t.attachShader(a, n), t.attachShader(a, o), t.linkProgram(a), !t.getProgramParameter(a, t.LINK_STATUS)) throw new r(`Shader link error for "${this.type}" ${t.getProgramInfoLog(a)}`);
        const h = this.getUniformLocations(t, a) || {};
        return h.uStepW = t.getUniformLocation(a, "uStepW"), h.uStepH = t.getUniformLocation(a, "uStepH"), {
            program: a,
            attributeLocations: this.getAttributeLocations(t, a),
            uniformLocations: h
        };
    }
    getAttributeLocations(t, e) {
        return {
            aPosition: t.getAttribLocation(e, "aPosition")
        };
    }
    getUniformLocations(t, e) {
        const s = this.constructor.uniformLocations, i = {};
        for(let r = 0; r < s.length; r++)i[s[r]] = t.getUniformLocation(e, s[r]);
        return i;
    }
    sendAttributeData(t, e, s) {
        const i = e.aPosition, r = t.createBuffer();
        t.bindBuffer(t.ARRAY_BUFFER, r), t.enableVertexAttribArray(i), t.vertexAttribPointer(i, 2, t.FLOAT, !1, 0, 0), t.bufferData(t.ARRAY_BUFFER, s, t.STATIC_DRAW);
    }
    _setupFrameBuffer(t) {
        const e = t.context;
        if (t.passes > 1) {
            const s = t.destinationWidth, i = t.destinationHeight;
            t.sourceWidth === s && t.sourceHeight === i || (e.deleteTexture(t.targetTexture), t.targetTexture = t.filterBackend.createTexture(e, s, i)), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, t.targetTexture, 0);
        } else e.bindFramebuffer(e.FRAMEBUFFER, null), e.finish();
    }
    _swapTextures(t) {
        t.passes--, t.pass++;
        const e = t.targetTexture;
        t.targetTexture = t.sourceTexture, t.sourceTexture = e;
    }
    isNeutralState(t) {
        return !1;
    }
    applyTo(t) {
        ea(t) ? (this._setupFrameBuffer(t), this.applyToWebGL(t), this._swapTextures(t)) : this.applyTo2d(t);
    }
    applyTo2d(t) {}
    getCacheKey() {
        return this.type;
    }
    retrieveShader(t) {
        const e = this.getCacheKey();
        return t.programCache[e] || (t.programCache[e] = this.createProgram(t.context)), t.programCache[e];
    }
    applyToWebGL(t) {
        const e = t.context, s = this.retrieveShader(t);
        0 === t.pass && t.originalTexture ? e.bindTexture(e.TEXTURE_2D, t.originalTexture) : e.bindTexture(e.TEXTURE_2D, t.sourceTexture), e.useProgram(s.program), this.sendAttributeData(e, s.attributeLocations, t.aPosition), e.uniform1f(s.uniformLocations.uStepW, 1 / t.sourceWidth), e.uniform1f(s.uniformLocations.uStepH, 1 / t.sourceHeight), this.sendUniformData(e, s.uniformLocations), e.viewport(0, 0, t.destinationWidth, t.destinationHeight), e.drawArrays(e.TRIANGLE_STRIP, 0, 4);
    }
    bindAdditionalTexture(t, e, s) {
        t.activeTexture(s), t.bindTexture(t.TEXTURE_2D, e), t.activeTexture(t.TEXTURE0);
    }
    unbindAdditionalTexture(t, e) {
        t.activeTexture(e), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE0);
    }
    sendUniformData(t, e) {}
    createHelpLayer(t) {
        if (!t.helpLayer) {
            const { sourceWidth: e, sourceHeight: s } = t, i = vt({
                width: e,
                height: s
            });
            t.helpLayer = i;
        }
    }
    toObject() {
        const t = Object.keys(this.constructor.defaults || {});
        return {
            type: this.type,
            ...t.reduce((t, e)=>(t[e] = this[e], t), {})
        };
    }
    toJSON() {
        return this.toObject();
    }
    static async fromObject(t, e) {
        let { type: s, ...i } = t;
        return new this(i);
    }
}
t(oa, "type", "BaseFilter"), t(oa, "uniformLocations", []);
const aa = {
    multiply: "gl_FragColor.rgb *= uColor.rgb;\n",
    screen: "gl_FragColor.rgb = 1.0 - (1.0 - gl_FragColor.rgb) * (1.0 - uColor.rgb);\n",
    add: "gl_FragColor.rgb += uColor.rgb;\n",
    difference: "gl_FragColor.rgb = abs(gl_FragColor.rgb - uColor.rgb);\n",
    subtract: "gl_FragColor.rgb -= uColor.rgb;\n",
    lighten: "gl_FragColor.rgb = max(gl_FragColor.rgb, uColor.rgb);\n",
    darken: "gl_FragColor.rgb = min(gl_FragColor.rgb, uColor.rgb);\n",
    exclusion: "gl_FragColor.rgb += uColor.rgb - 2.0 * (uColor.rgb * gl_FragColor.rgb);\n",
    overlay: "\n    if (uColor.r < 0.5) {\n      gl_FragColor.r *= 2.0 * uColor.r;\n    } else {\n      gl_FragColor.r = 1.0 - 2.0 * (1.0 - gl_FragColor.r) * (1.0 - uColor.r);\n    }\n    if (uColor.g < 0.5) {\n      gl_FragColor.g *= 2.0 * uColor.g;\n    } else {\n      gl_FragColor.g = 1.0 - 2.0 * (1.0 - gl_FragColor.g) * (1.0 - uColor.g);\n    }\n    if (uColor.b < 0.5) {\n      gl_FragColor.b *= 2.0 * uColor.b;\n    } else {\n      gl_FragColor.b = 1.0 - 2.0 * (1.0 - gl_FragColor.b) * (1.0 - uColor.b);\n    }\n    ",
    tint: "\n    gl_FragColor.rgb *= (1.0 - uColor.a);\n    gl_FragColor.rgb += uColor.rgb;\n    "
};
class ha extends oa {
    getCacheKey() {
        return `${this.type}_${this.mode}`;
    }
    getFragmentSource() {
        return `\n      precision highp float;\n      uniform sampler2D uTexture;\n      uniform vec4 uColor;\n      varying vec2 vTexCoord;\n      void main() {\n        vec4 color = texture2D(uTexture, vTexCoord);\n        gl_FragColor = color;\n        if (color.a > 0.0) {\n          ${aa[this.mode]}\n        }\n      }\n      `;
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = new Je(this.color).getSource(), i = this.alpha, r = s[0] * i, n = s[1] * i, o = s[2] * i, a = 1 - i;
        for(let t = 0; t < e.length; t += 4){
            const s = e[t], i = e[t + 1], h = e[t + 2];
            let l, c, u;
            switch(this.mode){
                case "multiply":
                    l = s * r / 255, c = i * n / 255, u = h * o / 255;
                    break;
                case "screen":
                    l = 255 - (255 - s) * (255 - r) / 255, c = 255 - (255 - i) * (255 - n) / 255, u = 255 - (255 - h) * (255 - o) / 255;
                    break;
                case "add":
                    l = s + r, c = i + n, u = h + o;
                    break;
                case "difference":
                    l = Math.abs(s - r), c = Math.abs(i - n), u = Math.abs(h - o);
                    break;
                case "subtract":
                    l = s - r, c = i - n, u = h - o;
                    break;
                case "darken":
                    l = Math.min(s, r), c = Math.min(i, n), u = Math.min(h, o);
                    break;
                case "lighten":
                    l = Math.max(s, r), c = Math.max(i, n), u = Math.max(h, o);
                    break;
                case "overlay":
                    l = r < 128 ? 2 * s * r / 255 : 255 - 2 * (255 - s) * (255 - r) / 255, c = n < 128 ? 2 * i * n / 255 : 255 - 2 * (255 - i) * (255 - n) / 255, u = o < 128 ? 2 * h * o / 255 : 255 - 2 * (255 - h) * (255 - o) / 255;
                    break;
                case "exclusion":
                    l = r + s - 2 * r * s / 255, c = n + i - 2 * n * i / 255, u = o + h - 2 * o * h / 255;
                    break;
                case "tint":
                    l = r + s * a, c = n + i * a, u = o + h * a;
            }
            e[t] = l, e[t + 1] = c, e[t + 2] = u;
        }
    }
    sendUniformData(t, e) {
        const s = new Je(this.color).getSource();
        s[0] = this.alpha * s[0] / 255, s[1] = this.alpha * s[1] / 255, s[2] = this.alpha * s[2] / 255, s[3] = this.alpha, t.uniform4fv(e.uColor, s);
    }
}
t(ha, "defaults", {
    color: "#F95C63",
    mode: "multiply",
    alpha: 1
}), t(ha, "type", "BlendColor"), t(ha, "uniformLocations", [
    "uColor"
]), tt.setClass(ha);
const la = {
    multiply: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform sampler2D uImage;\n    uniform vec4 uColor;\n    varying vec2 vTexCoord;\n    varying vec2 vTexCoord2;\n    void main() {\n      vec4 color = texture2D(uTexture, vTexCoord);\n      vec4 color2 = texture2D(uImage, vTexCoord2);\n      color.rgba *= color2.rgba;\n      gl_FragColor = color;\n    }\n    ",
    mask: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform sampler2D uImage;\n    uniform vec4 uColor;\n    varying vec2 vTexCoord;\n    varying vec2 vTexCoord2;\n    void main() {\n      vec4 color = texture2D(uTexture, vTexCoord);\n      vec4 color2 = texture2D(uImage, vTexCoord2);\n      color.a = color2.a;\n      gl_FragColor = color;\n    }\n    "
};
class ca extends oa {
    getCacheKey() {
        return `${this.type}_${this.mode}`;
    }
    getFragmentSource() {
        return la[this.mode];
    }
    getVertexSource() {
        return "\n    attribute vec2 aPosition;\n    varying vec2 vTexCoord;\n    varying vec2 vTexCoord2;\n    uniform mat3 uTransformMatrix;\n    void main() {\n      vTexCoord = aPosition;\n      vTexCoord2 = (uTransformMatrix * vec3(aPosition, 1.0)).xy;\n      gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);\n    }\n    ";
    }
    applyToWebGL(t) {
        const e = t.context, s = this.createTexture(t.filterBackend, this.image);
        this.bindAdditionalTexture(e, s, e.TEXTURE1), super.applyToWebGL(t), this.unbindAdditionalTexture(e, e.TEXTURE1);
    }
    createTexture(t, e) {
        return t.getCachedTexture(e.cacheKey, e.getElement());
    }
    calculateMatrix() {
        const t = this.image, { width: e, height: s } = t.getElement();
        return [
            1 / t.scaleX,
            0,
            0,
            0,
            1 / t.scaleY,
            0,
            -t.left / e,
            -t.top / s,
            1
        ];
    }
    applyTo2d(t) {
        let { imageData: { data: e, width: s, height: i }, filterBackend: { resources: r } } = t;
        const n = this.image;
        r.blendImage || (r.blendImage = pt());
        const o = r.blendImage, a = o.getContext("2d");
        o.width !== s || o.height !== i ? (o.width = s, o.height = i) : a.clearRect(0, 0, s, i), a.setTransform(n.scaleX, 0, 0, n.scaleY, n.left, n.top), a.drawImage(n.getElement(), 0, 0, s, i);
        const h = a.getImageData(0, 0, s, i).data;
        for(let t = 0; t < e.length; t += 4){
            const s = e[t], i = e[t + 1], r = e[t + 2], n = e[t + 3], o = h[t], a = h[t + 1], l = h[t + 2], c = h[t + 3];
            switch(this.mode){
                case "multiply":
                    e[t] = s * o / 255, e[t + 1] = i * a / 255, e[t + 2] = r * l / 255, e[t + 3] = n * c / 255;
                    break;
                case "mask":
                    e[t + 3] = c;
            }
        }
    }
    sendUniformData(t, e) {
        const s = this.calculateMatrix();
        t.uniform1i(e.uImage, 1), t.uniformMatrix3fv(e.uTransformMatrix, !1, s);
    }
    toObject() {
        return {
            ...super.toObject(),
            image: this.image && this.image.toObject()
        };
    }
    static async fromObject(t, e) {
        let { type: s, image: i, ...r } = t;
        return Xo.fromObject(i, e).then((t)=>new this({
                ...r,
                image: t
            }));
    }
}
t(ca, "type", "BlendImage"), t(ca, "defaults", {
    mode: "multiply",
    alpha: 1
}), t(ca, "uniformLocations", [
    "uTransformMatrix",
    "uImage"
]), tt.setClass(ca);
class ua extends oa {
    getFragmentSource() {
        return "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform vec2 uDelta;\n    varying vec2 vTexCoord;\n    const float nSamples = 15.0;\n    vec3 v3offset = vec3(12.9898, 78.233, 151.7182);\n    float random(vec3 scale) {\n      /* use the fragment position for a different seed per-pixel */\n      return fract(sin(dot(gl_FragCoord.xyz, scale)) * 43758.5453);\n    }\n    void main() {\n      vec4 color = vec4(0.0);\n      float totalC = 0.0;\n      float totalA = 0.0;\n      float offset = random(v3offset);\n      for (float t = -nSamples; t <= nSamples; t++) {\n        float percent = (t + offset - 0.5) / nSamples;\n        vec4 sample = texture2D(uTexture, vTexCoord + uDelta * percent);\n        float weight = 1.0 - abs(percent);\n        float alpha = weight * sample.a;\n        color.rgb += sample.rgb * alpha;\n        color.a += alpha;\n        totalA += weight;\n        totalC += alpha;\n      }\n      gl_FragColor.rgb = color.rgb / totalC;\n      gl_FragColor.a = color.a / totalA;\n    }\n  ";
    }
    applyTo(t) {
        ea(t) ? (this.aspectRatio = t.sourceWidth / t.sourceHeight, t.passes++, this._setupFrameBuffer(t), this.horizontal = !0, this.applyToWebGL(t), this._swapTextures(t), this._setupFrameBuffer(t), this.horizontal = !1, this.applyToWebGL(t), this._swapTextures(t)) : this.applyTo2d(t);
    }
    applyTo2d(t) {
        let { imageData: { data: e, width: s, height: i } } = t;
        this.aspectRatio = s / i, this.horizontal = !0;
        let r = this.getBlurValue() * s;
        const n = new Uint8ClampedArray(e), o = 15, a = 4 * s;
        for(let t = 0; t < e.length; t += 4){
            let s = 0, i = 0, h = 0, l = 0, c = 0;
            const u = t - t % a, d = u + a;
            for(let n = -14; n < o; n++){
                const a = n / o, g = 4 * Math.floor(r * a), f = 1 - Math.abs(a);
                let p = t + g;
                p < u ? p = u : p > d && (p = d);
                const m = e[p + 3] * f;
                s += e[p] * m, i += e[p + 1] * m, h += e[p + 2] * m, l += m, c += f;
            }
            n[t] = s / l, n[t + 1] = i / l, n[t + 2] = h / l, n[t + 3] = l / c;
        }
        this.horizontal = !1, r = this.getBlurValue() * i;
        for(let t = 0; t < n.length; t += 4){
            let s = 0, i = 0, h = 0, l = 0, c = 0;
            const u = t % a, d = n.length - a + u;
            for(let e = -14; e < o; e++){
                const g = e / o, f = Math.floor(r * g) * a, p = 1 - Math.abs(g);
                let m = t + f;
                m < u ? m = u : m > d && (m = d);
                const v = n[m + 3] * p;
                s += n[m] * v, i += n[m + 1] * v, h += n[m + 2] * v, l += v, c += p;
            }
            e[t] = s / l, e[t + 1] = i / l, e[t + 2] = h / l, e[t + 3] = l / c;
        }
    }
    sendUniformData(t, e) {
        const s = this.chooseRightDelta();
        t.uniform2fv(e.uDelta, s);
    }
    isNeutralState() {
        return 0 === this.blur;
    }
    getBlurValue() {
        let t = 1;
        const { horizontal: e, aspectRatio: s } = this;
        return e ? s > 1 && (t = 1 / s) : s < 1 && (t = s), t * this.blur * .12;
    }
    chooseRightDelta() {
        const t = this.getBlurValue();
        return this.horizontal ? [
            t,
            0
        ] : [
            0,
            t
        ];
    }
}
t(ua, "type", "Blur"), t(ua, "defaults", {
    blur: 0
}), t(ua, "uniformLocations", [
    "uDelta"
]), tt.setClass(ua);
class da extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uBrightness;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    color.rgb += uBrightness;\n    gl_FragColor = color;\n  }\n";
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = Math.round(255 * this.brightness);
        for(let t = 0; t < e.length; t += 4)e[t] += s, e[t + 1] += s, e[t + 2] += s;
    }
    isNeutralState() {
        return 0 === this.brightness;
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uBrightness, this.brightness);
    }
}
t(da, "type", "Brightness"), t(da, "defaults", {
    brightness: 0
}), t(da, "uniformLocations", [
    "uBrightness"
]), tt.setClass(da);
const ga = {
    matrix: [
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0
    ],
    colorsOnly: !0
};
class fa extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  varying vec2 vTexCoord;\n  uniform mat4 uColorMatrix;\n  uniform vec4 uConstants;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    color *= uColorMatrix;\n    color += uConstants;\n    gl_FragColor = color;\n  }";
    }
    applyTo2d(t) {
        const e = t.imageData.data, s = this.matrix, i = this.colorsOnly;
        for(let t = 0; t < e.length; t += 4){
            const r = e[t], n = e[t + 1], o = e[t + 2];
            if (e[t] = r * s[0] + n * s[1] + o * s[2] + 255 * s[4], e[t + 1] = r * s[5] + n * s[6] + o * s[7] + 255 * s[9], e[t + 2] = r * s[10] + n * s[11] + o * s[12] + 255 * s[14], !i) {
                const i = e[t + 3];
                e[t] += i * s[3], e[t + 1] += i * s[8], e[t + 2] += i * s[13], e[t + 3] = r * s[15] + n * s[16] + o * s[17] + i * s[18] + 255 * s[19];
            }
        }
    }
    sendUniformData(t, e) {
        const s = this.matrix, i = [
            s[0],
            s[1],
            s[2],
            s[3],
            s[5],
            s[6],
            s[7],
            s[8],
            s[10],
            s[11],
            s[12],
            s[13],
            s[15],
            s[16],
            s[17],
            s[18]
        ], r = [
            s[4],
            s[9],
            s[14],
            s[19]
        ];
        t.uniformMatrix4fv(e.uColorMatrix, !1, i), t.uniform4fv(e.uConstants, r);
    }
    toObject() {
        return {
            ...super.toObject(),
            matrix: [
                ...this.matrix
            ]
        };
    }
}
function pa(e, s) {
    var i;
    const r = (t(i = class extends fa {
        toObject() {
            return {
                type: this.type,
                colorsOnly: this.colorsOnly
            };
        }
    }, "type", e), t(i, "defaults", {
        colorsOnly: !1,
        matrix: s
    }), i);
    return tt.setClass(r, e), r;
}
t(fa, "type", "ColorMatrix"), t(fa, "defaults", ga), t(fa, "uniformLocations", [
    "uColorMatrix",
    "uConstants"
]), tt.setClass(fa);
const ma = pa("Brownie", [
    .5997,
    .34553,
    -.27082,
    0,
    .186,
    -.0377,
    .86095,
    .15059,
    0,
    -.1449,
    .24113,
    -.07441,
    .44972,
    0,
    -.02965,
    0,
    0,
    0,
    1,
    0
]), va = pa("Vintage", [
    .62793,
    .32021,
    -.03965,
    0,
    .03784,
    .02578,
    .64411,
    .03259,
    0,
    .02926,
    .0466,
    -.08512,
    .52416,
    0,
    .02023,
    0,
    0,
    0,
    1,
    0
]), ya = pa("Kodachrome", [
    1.12855,
    -.39673,
    -.03992,
    0,
    .24991,
    -.16404,
    1.08352,
    -.05498,
    0,
    .09698,
    -.16786,
    -.56034,
    1.60148,
    0,
    .13972,
    0,
    0,
    0,
    1,
    0
]), _a = pa("Technicolor", [
    1.91252,
    -.85453,
    -.09155,
    0,
    .04624,
    -.30878,
    1.76589,
    -.10601,
    0,
    -.27589,
    -.2311,
    -.75018,
    1.84759,
    0,
    .12137,
    0,
    0,
    0,
    1,
    0
]), xa = pa("Polaroid", [
    1.438,
    -.062,
    -.062,
    0,
    0,
    -.122,
    1.378,
    -.122,
    0,
    0,
    -.016,
    -.016,
    1.483,
    0,
    0,
    0,
    0,
    0,
    1,
    0
]), Ca = pa("Sepia", [
    .393,
    .769,
    .189,
    0,
    0,
    .349,
    .686,
    .168,
    0,
    0,
    .272,
    .534,
    .131,
    0,
    0,
    0,
    0,
    0,
    1,
    0
]), ba = pa("BlackWhite", [
    1.5,
    1.5,
    1.5,
    0,
    -1,
    1.5,
    1.5,
    1.5,
    0,
    -1,
    1.5,
    1.5,
    1.5,
    0,
    -1,
    0,
    0,
    0,
    1,
    0
]);
class Sa extends oa {
    constructor(){
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        super(t), this.subFilters = t.subFilters || [];
    }
    applyTo(t) {
        ea(t) && (t.passes += this.subFilters.length - 1), this.subFilters.forEach((e)=>{
            e.applyTo(t);
        });
    }
    toObject() {
        return {
            type: this.type,
            subFilters: this.subFilters.map((t)=>t.toObject())
        };
    }
    isNeutralState() {
        return !this.subFilters.some((t)=>!t.isNeutralState());
    }
    static fromObject(t, e) {
        return Promise.all((t.subFilters || []).map((t)=>tt.getClass(t.type).fromObject(t, e))).then((t)=>new this({
                subFilters: t
            }));
    }
}
t(Sa, "type", "Composed"), tt.setClass(Sa);
class wa extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uContrast;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    float contrastF = 1.015 * (uContrast + 1.0) / (1.0 * (1.015 - uContrast));\n    color.rgb = contrastF * (color.rgb - 0.5) + 0.5;\n    gl_FragColor = color;\n  }";
    }
    isNeutralState() {
        return 0 === this.contrast;
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = Math.floor(255 * this.contrast), i = 259 * (s + 255) / (255 * (259 - s));
        for(let t = 0; t < e.length; t += 4)e[t] = i * (e[t] - 128) + 128, e[t + 1] = i * (e[t + 1] - 128) + 128, e[t + 2] = i * (e[t + 2] - 128) + 128;
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uContrast, this.contrast);
    }
}
t(wa, "type", "Contrast"), t(wa, "defaults", {
    contrast: 0
}), t(wa, "uniformLocations", [
    "uContrast"
]), tt.setClass(wa);
const Ta = {
    Convolute_3_1: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[9];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 0);\n      for (float h = 0.0; h < 3.0; h+=1.0) {\n        for (float w = 0.0; w < 3.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 1), uStepH * (h - 1));\n          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 3.0 + w)];\n        }\n      }\n      gl_FragColor = color;\n    }\n    ",
    Convolute_3_0: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[9];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 1);\n      for (float h = 0.0; h < 3.0; h+=1.0) {\n        for (float w = 0.0; w < 3.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 1.0), uStepH * (h - 1.0));\n          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 3.0 + w)];\n        }\n      }\n      float alpha = texture2D(uTexture, vTexCoord).a;\n      gl_FragColor = color;\n      gl_FragColor.a = alpha;\n    }\n    ",
    Convolute_5_1: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[25];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 0);\n      for (float h = 0.0; h < 5.0; h+=1.0) {\n        for (float w = 0.0; w < 5.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));\n          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 5.0 + w)];\n        }\n      }\n      gl_FragColor = color;\n    }\n    ",
    Convolute_5_0: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[25];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 1);\n      for (float h = 0.0; h < 5.0; h+=1.0) {\n        for (float w = 0.0; w < 5.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));\n          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 5.0 + w)];\n        }\n      }\n      float alpha = texture2D(uTexture, vTexCoord).a;\n      gl_FragColor = color;\n      gl_FragColor.a = alpha;\n    }\n    ",
    Convolute_7_1: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[49];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 0);\n      for (float h = 0.0; h < 7.0; h+=1.0) {\n        for (float w = 0.0; w < 7.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));\n          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 7.0 + w)];\n        }\n      }\n      gl_FragColor = color;\n    }\n    ",
    Convolute_7_0: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[49];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 1);\n      for (float h = 0.0; h < 7.0; h+=1.0) {\n        for (float w = 0.0; w < 7.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));\n          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 7.0 + w)];\n        }\n      }\n      float alpha = texture2D(uTexture, vTexCoord).a;\n      gl_FragColor = color;\n      gl_FragColor.a = alpha;\n    }\n    ",
    Convolute_9_1: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[81];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 0);\n      for (float h = 0.0; h < 9.0; h+=1.0) {\n        for (float w = 0.0; w < 9.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));\n          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 9.0 + w)];\n        }\n      }\n      gl_FragColor = color;\n    }\n    ",
    Convolute_9_0: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform float uMatrix[81];\n    uniform float uStepW;\n    uniform float uStepH;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = vec4(0, 0, 0, 1);\n      for (float h = 0.0; h < 9.0; h+=1.0) {\n        for (float w = 0.0; w < 9.0; w+=1.0) {\n          vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));\n          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 9.0 + w)];\n        }\n      }\n      float alpha = texture2D(uTexture, vTexCoord).a;\n      gl_FragColor = color;\n      gl_FragColor.a = alpha;\n    }\n    "
};
class Oa extends oa {
    getCacheKey() {
        return `${this.type}_${Math.sqrt(this.matrix.length)}_${this.opaque ? 1 : 0}`;
    }
    getFragmentSource() {
        return Ta[this.getCacheKey()];
    }
    applyTo2d(t) {
        const e = t.imageData, s = e.data, i = this.matrix, r = Math.round(Math.sqrt(i.length)), n = Math.floor(r / 2), o = e.width, a = e.height, h = t.ctx.createImageData(o, a), l = h.data, c = this.opaque ? 1 : 0;
        let u, d, g, f, p, m, v, y, _, x, C, b, S;
        for(C = 0; C < a; C++)for(x = 0; x < o; x++){
            for(p = 4 * (C * o + x), u = 0, d = 0, g = 0, f = 0, S = 0; S < r; S++)for(b = 0; b < r; b++)v = C + S - n, m = x + b - n, v < 0 || v >= a || m < 0 || m >= o || (y = 4 * (v * o + m), _ = i[S * r + b], u += s[y] * _, d += s[y + 1] * _, g += s[y + 2] * _, c || (f += s[y + 3] * _));
            l[p] = u, l[p + 1] = d, l[p + 2] = g, l[p + 3] = c ? s[p + 3] : f;
        }
        t.imageData = h;
    }
    sendUniformData(t, e) {
        t.uniform1fv(e.uMatrix, this.matrix);
    }
    toObject() {
        return {
            ...super.toObject(),
            opaque: this.opaque,
            matrix: [
                ...this.matrix
            ]
        };
    }
}
t(Oa, "type", "Convolute"), t(Oa, "defaults", {
    opaque: !1,
    matrix: [
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0
    ]
}), t(Oa, "uniformLocations", [
    "uMatrix",
    "uOpaque",
    "uHalfSize",
    "uSize"
]), tt.setClass(Oa);
const ka = "Gamma";
class Da extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform vec3 uGamma;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    vec3 correction = (1.0 / uGamma);\n    color.r = pow(color.r, correction.r);\n    color.g = pow(color.g, correction.g);\n    color.b = pow(color.b, correction.b);\n    gl_FragColor = color;\n    gl_FragColor.rgb *= color.a;\n  }\n";
    }
    constructor(){
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        super(t), this.gamma = t.gamma || this.constructor.defaults.gamma.concat();
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = this.gamma, i = 1 / s[0], r = 1 / s[1], n = 1 / s[2];
        this.rgbValues || (this.rgbValues = {
            r: new Uint8Array(256),
            g: new Uint8Array(256),
            b: new Uint8Array(256)
        });
        const o = this.rgbValues;
        for(let t = 0; t < 256; t++)o.r[t] = 255 * Math.pow(t / 255, i), o.g[t] = 255 * Math.pow(t / 255, r), o.b[t] = 255 * Math.pow(t / 255, n);
        for(let t = 0; t < e.length; t += 4)e[t] = o.r[e[t]], e[t + 1] = o.g[e[t + 1]], e[t + 2] = o.b[e[t + 2]];
    }
    sendUniformData(t, e) {
        t.uniform3fv(e.uGamma, this.gamma);
    }
    isNeutralState() {
        const { gamma: t } = this;
        return 1 === t[0] && 1 === t[1] && 1 === t[2];
    }
    toObject() {
        return {
            type: ka,
            gamma: this.gamma.concat()
        };
    }
}
t(Da, "type", ka), t(Da, "defaults", {
    gamma: [
        1,
        1,
        1
    ]
}), t(Da, "uniformLocations", [
    "uGamma"
]), tt.setClass(Da);
const Ma = {
    average: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 color = texture2D(uTexture, vTexCoord);\n      float average = (color.r + color.b + color.g) / 3.0;\n      gl_FragColor = vec4(average, average, average, color.a);\n    }\n    ",
    lightness: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform int uMode;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 col = texture2D(uTexture, vTexCoord);\n      float average = (max(max(col.r, col.g),col.b) + min(min(col.r, col.g),col.b)) / 2.0;\n      gl_FragColor = vec4(average, average, average, col.a);\n    }\n    ",
    luminosity: "\n    precision highp float;\n    uniform sampler2D uTexture;\n    uniform int uMode;\n    varying vec2 vTexCoord;\n    void main() {\n      vec4 col = texture2D(uTexture, vTexCoord);\n      float average = 0.21 * col.r + 0.72 * col.g + 0.07 * col.b;\n      gl_FragColor = vec4(average, average, average, col.a);\n    }\n    "
};
class Pa extends oa {
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        for(let t, s = 0; s < e.length; s += 4){
            const i = e[s], r = e[s + 1], n = e[s + 2];
            switch(this.mode){
                case "average":
                    t = (i + r + n) / 3;
                    break;
                case "lightness":
                    t = (Math.min(i, r, n) + Math.max(i, r, n)) / 2;
                    break;
                case "luminosity":
                    t = .21 * i + .72 * r + .07 * n;
            }
            e[s + 2] = e[s + 1] = e[s] = t;
        }
    }
    getCacheKey() {
        return `${this.type}_${this.mode}`;
    }
    getFragmentSource() {
        return Ma[this.mode];
    }
    sendUniformData(t, e) {
        t.uniform1i(e.uMode, 1);
    }
    isNeutralState() {
        return !1;
    }
}
t(Pa, "type", "Grayscale"), t(Pa, "defaults", {
    mode: "average"
}), t(Pa, "uniformLocations", [
    "uMode"
]), tt.setClass(Pa);
const Ea = {
    ...ga,
    rotation: 0
};
class Aa extends fa {
    calculateMatrix() {
        const t = this.rotation * Math.PI, e = rt(t), s = nt(t), i = 1 / 3, r = Math.sqrt(i) * s, n = 1 - e;
        this.matrix = [
            e + n / 3,
            i * n - r,
            i * n + r,
            0,
            0,
            i * n + r,
            e + i * n,
            i * n - r,
            0,
            0,
            i * n - r,
            i * n + r,
            e + i * n,
            0,
            0,
            0,
            0,
            0,
            1,
            0
        ];
    }
    isNeutralState() {
        return 0 === this.rotation;
    }
    applyTo(t) {
        this.calculateMatrix(), super.applyTo(t);
    }
    toObject() {
        return {
            type: this.type,
            rotation: this.rotation
        };
    }
}
t(Aa, "type", "HueRotation"), t(Aa, "defaults", Ea), tt.setClass(Aa);
class ja extends oa {
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        for(let t = 0; t < e.length; t += 4)e[t] = 255 - e[t], e[t + 1] = 255 - e[t + 1], e[t + 2] = 255 - e[t + 2], this.alpha && (e[t + 3] = 255 - e[t + 3]);
    }
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform int uInvert;\n  uniform int uAlpha;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    if (uInvert == 1) {\n      if (uAlpha == 1) {\n        gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,1.0 -color.a);\n      } else {\n        gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,color.a);\n      }\n    } else {\n      gl_FragColor = color;\n    }\n  }\n";
    }
    isNeutralState() {
        return !this.invert;
    }
    sendUniformData(t, e) {
        t.uniform1i(e.uInvert, Number(this.invert)), t.uniform1i(e.uAlpha, Number(this.alpha));
    }
}
t(ja, "type", "Invert"), t(ja, "defaults", {
    alpha: !1,
    invert: !0
}), t(ja, "uniformLocations", [
    "uInvert",
    "uAlpha"
]), tt.setClass(ja);
class Fa extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uStepH;\n  uniform float uNoise;\n  uniform float uSeed;\n  varying vec2 vTexCoord;\n  float rand(vec2 co, float seed, float vScale) {\n    return fract(sin(dot(co.xy * vScale ,vec2(12.9898 , 78.233))) * 43758.5453 * (seed + 0.01) / 2.0);\n  }\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    color.rgb += (0.5 - rand(vTexCoord, uSeed, 0.1 / uStepH)) * uNoise;\n    gl_FragColor = color;\n  }\n";
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = this.noise;
        for(let t = 0; t < e.length; t += 4){
            const i = (.5 - Math.random()) * s;
            e[t] += i, e[t + 1] += i, e[t + 2] += i;
        }
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uNoise, this.noise / 255), t.uniform1f(e.uSeed, Math.random());
    }
    isNeutralState() {
        return 0 === this.noise;
    }
}
t(Fa, "type", "Noise"), t(Fa, "defaults", {
    noise: 0
}), t(Fa, "uniformLocations", [
    "uNoise",
    "uSeed"
]), tt.setClass(Fa);
class La extends oa {
    applyTo2d(t) {
        let { imageData: { data: e, width: s, height: i } } = t;
        for(let t = 0; t < i; t += this.blocksize)for(let r = 0; r < s; r += this.blocksize){
            const n = 4 * t * s + 4 * r, o = e[n], a = e[n + 1], h = e[n + 2], l = e[n + 3];
            for(let n = t; n < Math.min(t + this.blocksize, i); n++)for(let t = r; t < Math.min(r + this.blocksize, s); t++){
                const i = 4 * n * s + 4 * t;
                e[i] = o, e[i + 1] = a, e[i + 2] = h, e[i + 3] = l;
            }
        }
    }
    isNeutralState() {
        return 1 === this.blocksize;
    }
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uBlocksize;\n  uniform float uStepW;\n  uniform float uStepH;\n  varying vec2 vTexCoord;\n  void main() {\n    float blockW = uBlocksize * uStepW;\n    float blockH = uBlocksize * uStepH;\n    int posX = int(vTexCoord.x / blockW);\n    int posY = int(vTexCoord.y / blockH);\n    float fposX = float(posX);\n    float fposY = float(posY);\n    vec2 squareCoords = vec2(fposX * blockW, fposY * blockH);\n    vec4 color = texture2D(uTexture, squareCoords);\n    gl_FragColor = color;\n  }\n";
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uBlocksize, this.blocksize);
    }
}
t(La, "type", "Pixelate"), t(La, "defaults", {
    blocksize: 4
}), t(La, "uniformLocations", [
    "uBlocksize"
]), tt.setClass(La);
class Ba extends oa {
    getFragmentSource() {
        return "\nprecision highp float;\nuniform sampler2D uTexture;\nuniform vec4 uLow;\nuniform vec4 uHigh;\nvarying vec2 vTexCoord;\nvoid main() {\n  gl_FragColor = texture2D(uTexture, vTexCoord);\n  if(all(greaterThan(gl_FragColor.rgb,uLow.rgb)) && all(greaterThan(uHigh.rgb,gl_FragColor.rgb))) {\n    gl_FragColor.a = 0.0;\n  }\n}\n";
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = 255 * this.distance, i = new Je(this.color).getSource(), r = [
            i[0] - s,
            i[1] - s,
            i[2] - s
        ], n = [
            i[0] + s,
            i[1] + s,
            i[2] + s
        ];
        for(let t = 0; t < e.length; t += 4){
            const s = e[t], i = e[t + 1], o = e[t + 2];
            s > r[0] && i > r[1] && o > r[2] && s < n[0] && i < n[1] && o < n[2] && (e[t + 3] = 0);
        }
    }
    sendUniformData(t, e) {
        const s = new Je(this.color).getSource(), i = this.distance, r = [
            0 + s[0] / 255 - i,
            0 + s[1] / 255 - i,
            0 + s[2] / 255 - i,
            1
        ], n = [
            s[0] / 255 + i,
            s[1] / 255 + i,
            s[2] / 255 + i,
            1
        ];
        t.uniform4fv(e.uLow, r), t.uniform4fv(e.uHigh, n);
    }
}
t(Ba, "type", "RemoveColor"), t(Ba, "defaults", {
    color: "#FFFFFF",
    distance: .02,
    useAlpha: !1
}), t(Ba, "uniformLocations", [
    "uLow",
    "uHigh"
]), tt.setClass(Ba);
class Ra extends oa {
    sendUniformData(t, e) {
        t.uniform2fv(e.uDelta, this.horizontal ? [
            1 / this.width,
            0
        ] : [
            0,
            1 / this.height
        ]), t.uniform1fv(e.uTaps, this.taps);
    }
    getFilterWindow() {
        const t = this.tempScale;
        return Math.ceil(this.lanczosLobes / t);
    }
    getCacheKey() {
        const t = this.getFilterWindow();
        return `${this.type}_${t}`;
    }
    getFragmentSource() {
        const t = this.getFilterWindow();
        return this.generateShader(t);
    }
    getTaps() {
        const t = this.lanczosCreate(this.lanczosLobes), e = this.tempScale, s = this.getFilterWindow(), i = new Array(s);
        for(let r = 1; r <= s; r++)i[r - 1] = t(r * e);
        return i;
    }
    generateShader(t) {
        const e = new Array(t);
        for(let s = 1; s <= t; s++)e[s - 1] = `${s}.0 * uDelta`;
        return `\n      precision highp float;\n      uniform sampler2D uTexture;\n      uniform vec2 uDelta;\n      varying vec2 vTexCoord;\n      uniform float uTaps[${t}];\n      void main() {\n        vec4 color = texture2D(uTexture, vTexCoord);\n        float sum = 1.0;\n        ${e.map((t, e)=>`\n              color += texture2D(uTexture, vTexCoord + ${t}) * uTaps[${e}] + texture2D(uTexture, vTexCoord - ${t}) * uTaps[${e}];\n              sum += 2.0 * uTaps[${e}];\n            `).join("\n")}\n        gl_FragColor = color / sum;\n      }\n    `;
    }
    applyToForWebgl(t) {
        t.passes++, this.width = t.sourceWidth, this.horizontal = !0, this.dW = Math.round(this.width * this.scaleX), this.dH = t.sourceHeight, this.tempScale = this.dW / this.width, this.taps = this.getTaps(), t.destinationWidth = this.dW, super.applyTo(t), t.sourceWidth = t.destinationWidth, this.height = t.sourceHeight, this.horizontal = !1, this.dH = Math.round(this.height * this.scaleY), this.tempScale = this.dH / this.height, this.taps = this.getTaps(), t.destinationHeight = this.dH, super.applyTo(t), t.sourceHeight = t.destinationHeight;
    }
    applyTo(t) {
        ea(t) ? this.applyToForWebgl(t) : this.applyTo2d(t);
    }
    isNeutralState() {
        return 1 === this.scaleX && 1 === this.scaleY;
    }
    lanczosCreate(t) {
        return (e)=>{
            if (e >= t || e <= -t) return 0;
            if (e < 1.1920929e-7 && e > -1.1920929e-7) return 1;
            const s = (e *= Math.PI) / t;
            return Math.sin(e) / e * Math.sin(s) / s;
        };
    }
    applyTo2d(t) {
        const e = t.imageData, s = this.scaleX, i = this.scaleY;
        this.rcpScaleX = 1 / s, this.rcpScaleY = 1 / i;
        const r = e.width, n = e.height, o = Math.round(r * s), a = Math.round(n * i);
        let h;
        h = "sliceHack" === this.resizeType ? this.sliceByTwo(t, r, n, o, a) : "hermite" === this.resizeType ? this.hermiteFastResize(t, r, n, o, a) : "bilinear" === this.resizeType ? this.bilinearFiltering(t, r, n, o, a) : "lanczos" === this.resizeType ? this.lanczosResize(t, r, n, o, a) : new ImageData(o, a), t.imageData = h;
    }
    sliceByTwo(t, e, s, i, r) {
        const n = t.imageData, o = .5;
        let a = !1, h = !1, l = e * o, c = s * o;
        const u = t.filterBackend.resources;
        let d = 0, g = 0;
        const f = e;
        let p = 0;
        u.sliceByTwo || (u.sliceByTwo = pt());
        const m = u.sliceByTwo;
        (m.width < 1.5 * e || m.height < s) && (m.width = 1.5 * e, m.height = s);
        const v = m.getContext("2d");
        for(v.clearRect(0, 0, 1.5 * e, s), v.putImageData(n, 0, 0), i = Math.floor(i), r = Math.floor(r); !a || !h;)e = l, s = c, i < Math.floor(l * o) ? l = Math.floor(l * o) : (l = i, a = !0), r < Math.floor(c * o) ? c = Math.floor(c * o) : (c = r, h = !0), v.drawImage(m, d, g, e, s, f, p, l, c), d = f, g = p, p += c;
        return v.getImageData(d, g, i, r);
    }
    lanczosResize(t, e, s, i, r) {
        const n = t.imageData.data, o = t.ctx.createImageData(i, r), a = o.data, h = this.lanczosCreate(this.lanczosLobes), l = this.rcpScaleX, c = this.rcpScaleY, u = 2 / this.rcpScaleX, d = 2 / this.rcpScaleY, g = Math.ceil(l * this.lanczosLobes / 2), f = Math.ceil(c * this.lanczosLobes / 2), p = {}, m = {
            x: 0,
            y: 0
        }, v = {
            x: 0,
            y: 0
        };
        return function t(y) {
            let _, x, C, b, S, w, T, O, k, D, M;
            for(m.x = (y + .5) * l, v.x = Math.floor(m.x), _ = 0; _ < r; _++){
                for(m.y = (_ + .5) * c, v.y = Math.floor(m.y), S = 0, w = 0, T = 0, O = 0, k = 0, x = v.x - g; x <= v.x + g; x++)if (!(x < 0 || x >= e)) {
                    D = Math.floor(1e3 * Math.abs(x - m.x)), p[D] || (p[D] = {});
                    for(let t = v.y - f; t <= v.y + f; t++)t < 0 || t >= s || (M = Math.floor(1e3 * Math.abs(t - m.y)), p[D][M] || (p[D][M] = h(Math.sqrt(Math.pow(D * u, 2) + Math.pow(M * d, 2)) / 1e3)), C = p[D][M], C > 0 && (b = 4 * (t * e + x), S += C, w += C * n[b], T += C * n[b + 1], O += C * n[b + 2], k += C * n[b + 3]));
                }
                b = 4 * (_ * i + y), a[b] = w / S, a[b + 1] = T / S, a[b + 2] = O / S, a[b + 3] = k / S;
            }
            return ++y < i ? t(y) : o;
        }(0);
    }
    bilinearFiltering(t, e, s, i, r) {
        let n, o, a, h, l, c, u, d, g, f, p, m, v, y = 0;
        const _ = this.rcpScaleX, x = this.rcpScaleY, C = 4 * (e - 1), b = t.imageData.data, S = t.ctx.createImageData(i, r), w = S.data;
        for(u = 0; u < r; u++)for(d = 0; d < i; d++)for(l = Math.floor(_ * d), c = Math.floor(x * u), g = _ * d - l, f = x * u - c, v = 4 * (c * e + l), p = 0; p < 4; p++)n = b[v + p], o = b[v + 4 + p], a = b[v + C + p], h = b[v + C + 4 + p], m = n * (1 - g) * (1 - f) + o * g * (1 - f) + a * f * (1 - g) + h * g * f, w[y++] = m;
        return S;
    }
    hermiteFastResize(t, e, s, i, r) {
        const n = this.rcpScaleX, o = this.rcpScaleY, a = Math.ceil(n / 2), h = Math.ceil(o / 2), l = t.imageData.data, c = t.ctx.createImageData(i, r), u = c.data;
        for(let t = 0; t < r; t++)for(let s = 0; s < i; s++){
            const r = 4 * (s + t * i);
            let c = 0, d = 0, g = 0, f = 0, p = 0, m = 0, v = 0;
            const y = (t + .5) * o;
            for(let i = Math.floor(t * o); i < (t + 1) * o; i++){
                const t = Math.abs(y - (i + .5)) / h, r = (s + .5) * n, o = t * t;
                for(let t = Math.floor(s * n); t < (s + 1) * n; t++){
                    let s = Math.abs(r - (t + .5)) / a;
                    const n = Math.sqrt(o + s * s);
                    n > 1 && n < -1 || (c = 2 * n * n * n - 3 * n * n + 1, c > 0 && (s = 4 * (t + i * e), v += c * l[s + 3], g += c, l[s + 3] < 255 && (c = c * l[s + 3] / 250), f += c * l[s], p += c * l[s + 1], m += c * l[s + 2], d += c));
                }
            }
            u[r] = f / d, u[r + 1] = p / d, u[r + 2] = m / d, u[r + 3] = v / g;
        }
        return c;
    }
}
t(Ra, "type", "Resize"), t(Ra, "defaults", {
    resizeType: "hermite",
    scaleX: 1,
    scaleY: 1,
    lanczosLobes: 3
}), t(Ra, "uniformLocations", [
    "uDelta",
    "uTaps"
]), tt.setClass(Ra);
class Ia extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uSaturation;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    float rgMax = max(color.r, color.g);\n    float rgbMax = max(rgMax, color.b);\n    color.r += rgbMax != color.r ? (rgbMax - color.r) * uSaturation : 0.00;\n    color.g += rgbMax != color.g ? (rgbMax - color.g) * uSaturation : 0.00;\n    color.b += rgbMax != color.b ? (rgbMax - color.b) * uSaturation : 0.00;\n    gl_FragColor = color;\n  }\n";
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = -this.saturation;
        for(let t = 0; t < e.length; t += 4){
            const i = e[t], r = e[t + 1], n = e[t + 2], o = Math.max(i, r, n);
            e[t] += o !== i ? (o - i) * s : 0, e[t + 1] += o !== r ? (o - r) * s : 0, e[t + 2] += o !== n ? (o - n) * s : 0;
        }
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uSaturation, -this.saturation);
    }
    isNeutralState() {
        return 0 === this.saturation;
    }
}
t(Ia, "type", "Saturation"), t(Ia, "defaults", {
    saturation: 0
}), t(Ia, "uniformLocations", [
    "uSaturation"
]), tt.setClass(Ia);
class $a extends oa {
    getFragmentSource() {
        return "\n  precision highp float;\n  uniform sampler2D uTexture;\n  uniform float uVibrance;\n  varying vec2 vTexCoord;\n  void main() {\n    vec4 color = texture2D(uTexture, vTexCoord);\n    float max = max(color.r, max(color.g, color.b));\n    float avg = (color.r + color.g + color.b) / 3.0;\n    float amt = (abs(max - avg) * 2.0) * uVibrance;\n    color.r += max != color.r ? (max - color.r) * amt : 0.00;\n    color.g += max != color.g ? (max - color.g) * amt : 0.00;\n    color.b += max != color.b ? (max - color.b) * amt : 0.00;\n    gl_FragColor = color;\n  }\n";
    }
    applyTo2d(t) {
        let { imageData: { data: e } } = t;
        const s = -this.vibrance;
        for(let t = 0; t < e.length; t += 4){
            const i = e[t], r = e[t + 1], n = e[t + 2], o = Math.max(i, r, n), a = (i + r + n) / 3, h = 2 * Math.abs(o - a) / 255 * s;
            e[t] += o !== i ? (o - i) * h : 0, e[t + 1] += o !== r ? (o - r) * h : 0, e[t + 2] += o !== n ? (o - n) * h : 0;
        }
    }
    sendUniformData(t, e) {
        t.uniform1f(e.uVibrance, -this.vibrance);
    }
    isNeutralState() {
        return 0 === this.vibrance;
    }
}
t($a, "type", "Vibrance"), t($a, "defaults", {
    vibrance: 0
}), t($a, "uniformLocations", [
    "uVibrance"
]), tt.setClass($a);
var Xa = Object.freeze({
    __proto__: null,
    BaseFilter: oa,
    BlackWhite: ba,
    BlendColor: ha,
    BlendImage: ca,
    Blur: ua,
    Brightness: da,
    Brownie: ma,
    ColorMatrix: fa,
    Composed: Sa,
    Contrast: wa,
    Convolute: Oa,
    Gamma: Da,
    Grayscale: Pa,
    HueRotation: Aa,
    Invert: ja,
    Kodachrome: ya,
    Noise: Fa,
    Pixelate: La,
    Polaroid: xa,
    RemoveColor: Ba,
    Resize: Ra,
    Saturation: Ia,
    Sepia: Ca,
    Technicolor: _a,
    Vibrance: $a,
    Vintage: va
});
;
 //# sourceMappingURL=index.min.mjs.map
}),
]);

//# debugId=4f8d5101-8c7f-801a-a502-f7b610229b95
//# sourceMappingURL=c427b_fabric_dist_index_min_mjs_7d7f5397._.js.map