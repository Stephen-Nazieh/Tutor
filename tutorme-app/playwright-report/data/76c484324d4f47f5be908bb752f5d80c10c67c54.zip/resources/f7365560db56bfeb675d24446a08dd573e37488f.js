;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="1d8516f6-3439-f858-45c1-9d801461f56a")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/ShapeUtil.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShapeUtil",
    ()=>ShapeUtil
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
;
class ShapeUtil {
    constructor(editor){
        this.editor = editor;
    }
    /** Configure this shape utils {@link ShapeUtil.options | `options`}. */ static configure(options) {
        return class extends this {
            // @ts-expect-error
            options = {
                ...this.options,
                ...options
            };
        };
    }
    /**
   * Options for this shape util. If you're implementing a custom shape util, you can override
   * this to provide customization options for your shape. If using an existing shape util, you
   * can customizing this by calling {@link ShapeUtil.configure}.
   */ options = {};
    /**
   * Props allow you to define the shape's properties in a way that the editor can understand.
   * This has two main uses:
   *
   * 1. Validation. Shapes will be validated using these props to stop bad data from being saved.
   * 2. Styles. Each {@link @tldraw/tlschema#StyleProp} in the props can be set on many shapes at
   *    once, and will be remembered from one shape to the next.
   *
   * @example
   * ```tsx
   * import {T, TLBaseShape, TLDefaultColorStyle, DefaultColorStyle, ShapeUtil} from 'tldraw'
   *
   * type MyShape = TLBaseShape<'mine', {
   *      color: TLDefaultColorStyle,
   *      text: string,
   * }>
   *
   * class MyShapeUtil extends ShapeUtil<MyShape> {
   *     static props = {
   *         // we use tldraw's built-in color style:
   *         color: DefaultColorStyle,
   *         // validate that the text prop is a string:
   *         text: T.string,
   *     }
   * }
   * ```
   */ static props;
    /**
   * Migrations allow you to make changes to a shape's props over time. Read the
   * {@link https://www.tldraw.dev/docs/persistence#Shape-props-migrations | shape prop migrations}
   * guide for more information.
   */ static migrations;
    /**
   * The type of the shape util, which should match the shape's type.
   *
   * @public
   */ static type;
    /**
   * Whether to use the legacy React-based indicator rendering.
   *
   * Override this to return `false` if your shape implements {@link ShapeUtil.getIndicatorPath}
   * for canvas-based indicator rendering.
   *
   * @returns `true` to use SVG indicators (default), `false` to use canvas indicators.
   * @public
   */ useLegacyIndicator() {
        return true;
    }
    /**
   * Get a Path2D for rendering the shape's indicator on the canvas.
   *
   * When implemented, this is used instead of {@link ShapeUtil.indicator} for more
   * efficient canvas-based indicator rendering. Shapes that return `undefined` will
   * fall back to SVG-based rendering via {@link ShapeUtil.indicator}.
   *
   * For complex indicators that need clipping (e.g., arrows with labels), return an
   * object with `path`, `clipPath`, and `additionalPaths` properties.
   *
   * @param shape - The shape.
   * @returns A Path2D to stroke, or an object with clipping info, or undefined to use SVG fallback.
   * @public
   */ getIndicatorPath(shape) {
        return void 0;
    }
    /**
   * Get the font faces that should be rendered in the document in order for this shape to render
   * correctly.
   *
   * @param shape - The shape.
   * @public
   */ getFontFaces(shape) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
    }
    /**
   * Whether the shape can be snapped to by another shape.
   *
   * @param shape - The shape.
   * @public
   */ canSnap(shape) {
        return true;
    }
    /**
   * Whether the shape can be tabbed to.
   *
   * @param shape - The shape.
   * @public
   */ canTabTo(shape) {
        return true;
    }
    /**
   * Whether the shape can be scrolled while editing.
   *
   * @public
   */ canScroll(shape) {
        return false;
    }
    /**
   * Whether the shape can be bound to. See {@link TLShapeUtilCanBindOpts} for details.
   *
   * @public
   */ canBind(_opts) {
        return true;
    }
    /**
   * Whether the shape can be double clicked to edit.
   *
   * @public
   */ canEdit(shape, info) {
        return false;
    }
    /**
   * Whether the shape can be resized.
   *
   * @public
   */ canResize(shape) {
        return true;
    }
    /**
   * When the shape is resized, whether the shape's children should also be resized.
   *
   * @public
   */ canResizeChildren(shape) {
        return true;
    }
    /**
   * Whether the shape can be edited in read-only mode.
   *
   * @public
   */ canEditInReadonly(shape) {
        return false;
    }
    /**
   * Whether the shape can be edited while locked or while an ancestor is locked.
   *
   * @public
   */ canEditWhileLocked(shape) {
        return false;
    }
    /**
   * Whether the shape can be cropped.
   *
   * @public
   */ canCrop(shape) {
        return false;
    }
    /**
   * Whether the shape can participate in layout functions such as alignment or distribution.
   *
   * @param shape - The shape.
   * @param info - Additional context information: the type of action causing the layout and the
   * @public
   *
   * @public
   */ canBeLaidOut(shape, info) {
        return true;
    }
    /**
   * Whether this shape can be culled. By default, shapes are culled for
   * performance reasons when they are outside of the viewport. Culled shapes are still rendered
   * to the DOM, but have their `display` property set to `none`.
   *
   * @param shape - The shape.
   */ canCull(shape) {
        return true;
    }
    /**
   * Does this shape provide a background for its children? If this is true,
   * then any children with a `renderBackground` method will have their
   * backgrounds rendered _above_ this shape. Otherwise, the children's
   * backgrounds will be rendered above either the next ancestor that provides
   * a background, or the canvas background.
   *
   * @internal
   */ providesBackgroundForChildren(shape) {
        return false;
    }
    /**
   * Whether the shape should hide its resize handles when selected.
   *
   * @public
   */ hideResizeHandles(shape) {
        return false;
    }
    /**
   * Whether the shape should hide its rotation handles when selected.
   *
   * @public
   */ hideRotateHandle(shape) {
        return false;
    }
    /**
   * Whether the shape should hide its selection bounds background when selected.
   *
   * @public
   */ hideSelectionBoundsBg(shape) {
        return false;
    }
    /**
   * Whether the shape should hide its selection bounds foreground when selected.
   *
   * @public
   */ hideSelectionBoundsFg(shape) {
        return false;
    }
    /**
   * Whether the shape's aspect ratio is locked.
   *
   * @public
   */ isAspectRatioLocked(shape) {
        return false;
    }
    /**
   * By default, the bounds of an image export are the bounds of all the shapes it contains, plus
   * some padding. If an export includes a shape where `isExportBoundsContainer` is true, then the
   * padding is skipped _if the bounds of that shape contains all the other shapes_. This is
   * useful in cases like annotating on top of an image, where you usually want to avoid extra
   * padding around the image if you don't need it.
   *
   * @param shape - The shape to check
   * @returns True if this shape should be treated as an export bounds container
   */ isExportBoundsContainer(shape) {
        return false;
    }
    /**
   * Get whether the shape can receive children of a given type.
   *
   * @param shape - The shape.
   * @param type - The shape type.
   * @public
   */ canReceiveNewChildrenOfType(shape, _type) {
        return false;
    }
    /** @internal */ expandSelectionOutlinePx(shape) {
        return 0;
    }
    /**
   * Return elements to be added to the \<defs\> section of the canvases SVG context. This can be
   * used to define SVG content (e.g. patterns & masks) that can be referred to by ID from svg
   * elements returned by `component`.
   *
   * Each def should have a unique `key`. If multiple defs from different shapes all have the same
   * key, only one will be used.
   */ getCanvasSvgDefs() {
        return [];
    }
    /**
   * Get the geometry to use when snapping to this this shape in translate/resize operations. See
   * {@link BoundsSnapGeometry} for details.
   */ getBoundsSnapGeometry(shape) {
        return {};
    }
    /**
   * Get the geometry to use when snapping handles to this shape. See {@link HandleSnapGeometry}
   * for details.
   */ getHandleSnapGeometry(shape) {
        return {};
    }
    getText(shape) {
        return void 0;
    }
    getAriaDescriptor(shape) {
        return void 0;
    }
}
;
 //# sourceMappingURL=ShapeUtil.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/shared/getPerfectDashProps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPerfectDashProps",
    ()=>getPerfectDashProps
]);
function getPerfectDashProps(totalLength, strokeWidth, opts = {}) {
    const { closed = false, snap = 1, start = "outset", end = "outset", lengthRatio = 2, style = "dashed", forceSolid = false } = opts;
    let dashLength = 0;
    let dashCount = 0;
    let ratio = 1;
    let gapLength = 0;
    let strokeDashoffset = 0;
    if (forceSolid) {
        return {
            strokeDasharray: "none",
            strokeDashoffset: "none"
        };
    }
    switch(style){
        case "dashed":
            {
                ratio = 1;
                dashLength = Math.min(strokeWidth * lengthRatio, totalLength / 4);
                break;
            }
        case "dotted":
            {
                ratio = 100;
                dashLength = strokeWidth / ratio;
                break;
            }
        default:
            {
                return {
                    strokeDasharray: "none",
                    strokeDashoffset: "none"
                };
            }
    }
    if (!closed) {
        if (start === "outset") {
            totalLength += dashLength / 2;
            strokeDashoffset += dashLength / 2;
        } else if (start === "skip") {
            totalLength -= dashLength;
            strokeDashoffset -= dashLength;
        }
        if (end === "outset") {
            totalLength += dashLength / 2;
        } else if (end === "skip") {
            totalLength -= dashLength;
        }
    }
    dashCount = Math.floor(totalLength / dashLength / (2 * ratio));
    dashCount -= dashCount % snap;
    if (dashCount < 3 && style === "dashed") {
        if (totalLength / strokeWidth < 4) {
            dashLength = totalLength;
            dashCount = 1;
            gapLength = 0;
        } else {
            dashLength = totalLength * (1 / 3);
            gapLength = totalLength * (1 / 3);
        }
    } else {
        dashLength = totalLength / dashCount / (2 * ratio);
        if (closed) {
            strokeDashoffset = dashLength / 2;
            gapLength = (totalLength - dashCount * dashLength) / dashCount;
        } else {
            gapLength = (totalLength - dashCount * dashLength) / Math.max(1, dashCount - 1);
        }
    }
    return {
        strokeDasharray: [
            dashLength,
            gapLength
        ].join(" "),
        strokeDashoffset: strokeDashoffset.toString()
    };
}
;
 //# sourceMappingURL=getPerfectDashProps.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/group/DashedOutlineBox.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DashedOutlineBox",
    ()=>DashedOutlineBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state-react/dist-esm/lib/useValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$shared$2f$getPerfectDashProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/shared/getPerfectDashProps.mjs [app-client] (ecmascript)");
;
;
;
;
function DashedOutlineBox({ bounds, className }) {
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEditor"])();
    const zoomLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2d$react$2f$dist$2d$esm$2f$lib$2f$useValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValue"])("zoom level", {
        "DashedOutlineBox.useValue[zoomLevel]": ()=>editor.getEfficientZoomLevel()
    }["DashedOutlineBox.useValue[zoomLevel]"], [
        editor
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
        className,
        pointerEvents: "none",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        children: bounds.sides.map((side, i)=>{
            const { strokeDasharray, strokeDashoffset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$shared$2f$getPerfectDashProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerfectDashProps"])(side[0].dist(side[1]), 1 / zoomLevel, {
                style: "dashed",
                lengthRatio: 4
            });
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", {
                x1: side[0].x,
                y1: side[0].y,
                x2: side[1].x,
                y2: side[1].y,
                strokeDasharray,
                strokeDashoffset
            }, i);
        })
    });
}
;
 //# sourceMappingURL=DashedOutlineBox.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/group/GroupShapeUtil.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GroupShapeUtil",
    ()=>GroupShapeUtil
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/shapes/TLGroupShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$SVGContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/components/SVGContainer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Group2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Rectangle2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Rectangle2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$ShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/ShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$group$2f$DashedOutlineBox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/group/DashedOutlineBox.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
class GroupShapeUtil extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$ShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShapeUtil"] {
    static type = "group";
    static props = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeProps"];
    static migrations = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$shapes$2f$TLGroupShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupShapeMigrations"];
    hideSelectionBoundsFg() {
        return true;
    }
    canBind() {
        return false;
    }
    canResize() {
        return true;
    }
    canResizeChildren() {
        return true;
    }
    getDefaultProps() {
        return {};
    }
    getGeometry(shape) {
        const children = this.editor.getSortedChildIdsForParent(shape.id);
        if (children.length === 0) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Rectangle2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Rectangle2d"]({
                width: 1,
                height: 1,
                isFilled: false
            });
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group2d"]({
            children: children.map((childId)=>{
                const shape2 = this.editor.getShape(childId);
                return this.editor.getShapeGeometry(childId).transform(this.editor.getShapeLocalTransform(shape2), {
                    isLabel: false
                });
            })
        });
    }
    component(shape) {
        const isErasing = this.editor.getErasingShapeIds().includes(shape.id);
        const { hintingShapeIds } = this.editor.getCurrentPageState();
        const isHintingOtherGroup = hintingShapeIds.length > 0 && hintingShapeIds.some((id)=>id !== shape.id && this.editor.isShapeOfType(this.editor.getShape(id), "group"));
        const isFocused = this.editor.getCurrentPageState().focusedGroupId !== shape.id;
        if (!isErasing && // always show the outline while we're erasing the group
        // show the outline while the group is focused unless something outside of the group is being hinted
        // this happens dropping shapes from a group onto some outside group
        (isFocused || isHintingOtherGroup)) {
            return null;
        }
        const bounds = this.editor.getShapeGeometry(shape).bounds;
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$components$2f$SVGContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SVGContainer"], {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$group$2f$DashedOutlineBox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashedOutlineBox"], {
                className: "tl-group",
                bounds
            })
        });
    }
    indicator(shape) {
        const bounds = this.editor.getShapeGeometry(shape).bounds;
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$group$2f$DashedOutlineBox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashedOutlineBox"], {
            className: "",
            bounds
        });
    }
    onChildrenChange(group) {
        const children = this.editor.getSortedChildIdsForParent(group.id);
        if (children.length === 0) {
            if (this.editor.getCurrentPageState().focusedGroupId === group.id) {
                this.editor.popFocusedGroupId();
            }
            this.editor.deleteShapes([
                group.id
            ]);
            return;
        } else if (children.length === 1) {
            if (this.editor.getCurrentPageState().focusedGroupId === group.id) {
                this.editor.popFocusedGroupId();
            }
            this.editor.reparentShapes(children, group.parentId);
            this.editor.deleteShapes([
                group.id
            ]);
            return;
        }
    }
}
;
 //# sourceMappingURL=GroupShapeUtil.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/types/SvgExportContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SvgExportContextProvider",
    ()=>SvgExportContextProvider,
    "useDelaySvgExport",
    ()=>useDelaySvgExport,
    "useSvgExportContext",
    ()=>useSvgExportContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useContainer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEditor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/hooks/useEvent.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const Context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function SvgExportContextProvider({ context, editor, children }) {
    const Provider = editor.options.exportProvider;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEditor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorProvider"], {
        editor,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useContainer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContainerProvider"], {
            container: editor.getContainer(),
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Context.Provider, {
                value: context,
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Provider, {
                    children
                })
            })
        })
    });
}
function useSvgExportContext() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Context);
}
function useDelaySvgExport() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Context);
    const [promise] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["promiseWithResolve"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDelaySvgExport.useEffect": ()=>{
            ctx?.waitUntil(promise);
            return ({
                "useDelaySvgExport.useEffect": ()=>{
                    promise.resolve();
                }
            })["useDelaySvgExport.useEffect"];
        }
    }["useDelaySvgExport.useEffect"], [
        promise,
        ctx
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$hooks$2f$useEvent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])({
        "useDelaySvgExport.useEvent": ()=>{
            promise.resolve();
        }
    }["useDelaySvgExport.useEvent"]);
}
;
 //# sourceMappingURL=SvgExportContext.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/bindingsIndex.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bindingsIndex",
    ()=>bindingsIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
;
function fromScratch(bindingsQuery) {
    const allBindings = bindingsQuery.get();
    const shapesToBindings = /* @__PURE__ */ new Map();
    for (const binding of allBindings){
        const { fromId, toId } = binding;
        const bindingsForFromShape = shapesToBindings.get(fromId);
        if (!bindingsForFromShape) {
            shapesToBindings.set(fromId, [
                binding
            ]);
        } else {
            bindingsForFromShape.push(binding);
        }
        const bindingsForToShape = shapesToBindings.get(toId);
        if (!bindingsForToShape) {
            shapesToBindings.set(toId, [
                binding
            ]);
        } else {
            bindingsForToShape.push(binding);
        }
    }
    return shapesToBindings;
}
const bindingsIndex = (editor)=>{
    const { store } = editor;
    const bindingsHistory = store.query.filterHistory("binding");
    const bindingsQuery = store.query.records("binding");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("arrowBindingsIndex", (_lastValue, lastComputedEpoch)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(_lastValue)) {
            return fromScratch(bindingsQuery);
        }
        const lastValue = _lastValue;
        const diff = bindingsHistory.getDiffSince(lastComputedEpoch);
        if (diff === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
            return fromScratch(bindingsQuery);
        }
        let nextValue = void 0;
        function removingBinding(binding) {
            nextValue ??= new Map(lastValue);
            const prevFrom = nextValue.get(binding.fromId);
            const nextFrom = prevFrom?.filter((b)=>b.id !== binding.id);
            if (!nextFrom?.length) {
                nextValue.delete(binding.fromId);
            } else {
                nextValue.set(binding.fromId, nextFrom);
            }
            const prevTo = nextValue.get(binding.toId);
            const nextTo = prevTo?.filter((b)=>b.id !== binding.id);
            if (!nextTo?.length) {
                nextValue.delete(binding.toId);
            } else {
                nextValue.set(binding.toId, nextTo);
            }
        }
        function ensureNewArray(shapeId) {
            nextValue ??= new Map(lastValue);
            let result = nextValue.get(shapeId);
            if (!result) {
                result = [];
                nextValue.set(shapeId, result);
            } else if (result === lastValue.get(shapeId)) {
                result = result.slice(0);
                nextValue.set(shapeId, result);
            }
            return result;
        }
        function addBinding(binding) {
            ensureNewArray(binding.fromId).push(binding);
            ensureNewArray(binding.toId).push(binding);
        }
        for (const changes of diff){
            for (const newBinding of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.added)){
                addBinding(newBinding);
            }
            for (const [prev, next] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.updated)){
                removingBinding(prev);
                addBinding(next);
            }
            for (const prev of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.removed)){
                removingBinding(prev);
            }
        }
        return nextValue ?? lastValue;
    });
};
;
 //# sourceMappingURL=bindingsIndex.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/notVisibleShapes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "notVisibleShapes",
    ()=>notVisibleShapes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
;
function notVisibleShapes(editor) {
    const emptySet = /* @__PURE__ */ new Set();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("notVisibleShapes", function(prevValue) {
        const allShapes = editor.getCurrentPageShapes();
        const viewportPageBounds = editor.getViewportPageBounds();
        const visibleIds = editor.getShapeIdsInsideBounds(viewportPageBounds);
        let shape;
        if (visibleIds.size === allShapes.length) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(prevValue) || prevValue.size > 0) {
                return emptySet;
            }
            return prevValue;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(prevValue)) {
            const nextValue = /* @__PURE__ */ new Set();
            for(let i = 0; i < allShapes.length; i++){
                shape = allShapes[i];
                if (visibleIds.has(shape.id)) continue;
                if (!editor.getShapeUtil(shape.type).canCull(shape)) continue;
                nextValue.add(shape.id);
            }
            return nextValue;
        }
        const notVisibleIds = [];
        for(let i = 0; i < allShapes.length; i++){
            shape = allShapes[i];
            if (visibleIds.has(shape.id)) continue;
            if (!editor.getShapeUtil(shape.type).canCull(shape)) continue;
            notVisibleIds.push(shape.id);
        }
        if (notVisibleIds.length === prevValue.size) {
            let same = true;
            for(let i = 0; i < notVisibleIds.length; i++){
                if (!prevValue.has(notVisibleIds[i])) {
                    same = false;
                    break;
                }
            }
            if (same) return prevValue;
        }
        return new Set(notVisibleIds);
    });
}
;
 //# sourceMappingURL=notVisibleShapes.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/parentsToChildren.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parentsToChildren",
    ()=>parentsToChildren
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
;
;
;
function fromScratch(shapeIdsQuery, store) {
    const result = {};
    const shapeIds = shapeIdsQuery.get();
    const sortedShapes = Array.from(shapeIds, (id)=>store.get(id)).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
    sortedShapes.forEach((shape)=>{
        result[shape.parentId] ??= [];
        result[shape.parentId].push(shape.id);
    });
    return result;
}
const parentsToChildren = (store)=>{
    const shapeIdsQuery = store.query.ids("shape");
    const shapeHistory = store.query.filterHistory("shape");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("parentsToChildrenWithIndexes", (lastValue, lastComputedEpoch)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(lastValue)) {
            return fromScratch(shapeIdsQuery, store);
        }
        const diff = shapeHistory.getDiffSince(lastComputedEpoch);
        if (diff === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
            return fromScratch(shapeIdsQuery, store);
        }
        if (diff.length === 0) return lastValue;
        let newValue = null;
        const ensureNewArray = (parentId)=>{
            if (!newValue) {
                newValue = {
                    ...lastValue
                };
            }
            if (!newValue[parentId]) {
                newValue[parentId] = [];
            } else if (newValue[parentId] === lastValue[parentId]) {
                newValue[parentId] = [
                    ...newValue[parentId]
                ];
            }
        };
        const toSort = /* @__PURE__ */ new Set();
        let changes;
        for(let i = 0, n = diff.length; i < n; i++){
            changes = diff[i];
            for (const record of Object.values(changes.added)){
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(record)) continue;
                ensureNewArray(record.parentId);
                newValue[record.parentId].push(record.id);
                toSort.add(newValue[record.parentId]);
            }
            for (const [from, to] of Object.values(changes.updated)){
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(to)) continue;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(from)) continue;
                if (from.parentId !== to.parentId) {
                    ensureNewArray(from.parentId);
                    ensureNewArray(to.parentId);
                    newValue[from.parentId].splice(newValue[from.parentId].indexOf(to.id), 1);
                    newValue[to.parentId].push(to.id);
                    toSort.add(newValue[to.parentId]);
                } else if (from.index !== to.index) {
                    ensureNewArray(to.parentId);
                    const idx = newValue[to.parentId].indexOf(to.id);
                    newValue[to.parentId][idx] = to.id;
                    toSort.add(newValue[to.parentId]);
                }
            }
            for (const record of Object.values(changes.removed)){
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(record)) continue;
                ensureNewArray(record.parentId);
                newValue[record.parentId].splice(newValue[record.parentId].indexOf(record.id), 1);
            }
        }
        for (const arr of toSort){
            let writeIdx = 0;
            for(let readIdx = 0; readIdx < arr.length; readIdx++){
                if (store.get(arr[readIdx])) {
                    arr[writeIdx++] = arr[readIdx];
                }
            }
            arr.length = writeIdx;
            arr.sort((a, b)=>{
                const shapeA = store.get(a);
                const shapeB = store.get(b);
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"])(shapeA, shapeB);
            });
        }
        return newValue ?? lastValue;
    });
};
;
 //# sourceMappingURL=parentsToChildren.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/shapeIdsInCurrentPage.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deriveShapeIdsInCurrentPage",
    ()=>deriveShapeIdsInCurrentPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/IncrementalSetConstructor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
;
;
;
const isShapeInPage = (store, pageId, shape)=>{
    while(!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape.parentId)){
        const parent = store.get(shape.parentId);
        if (!parent) return false;
        shape = parent;
    }
    return shape.parentId === pageId;
};
const deriveShapeIdsInCurrentPage = (store, getCurrentPageId)=>{
    const shapesIndex = store.query.ids("shape");
    let lastPageId = null;
    function fromScratch() {
        const currentPageId = getCurrentPageId();
        lastPageId = currentPageId;
        return new Set([
            ...shapesIndex.get()
        ].filter((id)=>isShapeInPage(store, currentPageId, store.get(id))));
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("_shapeIdsInCurrentPage", (prevValue, lastComputedEpoch)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(prevValue)) {
            return fromScratch();
        }
        const currentPageId = getCurrentPageId();
        if (currentPageId !== lastPageId) {
            return fromScratch();
        }
        const diff = store.history.getDiffSince(lastComputedEpoch);
        if (diff === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
            return fromScratch();
        }
        const builder = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$IncrementalSetConstructor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IncrementalSetConstructor"](prevValue);
        for (const changes of diff){
            for (const record of Object.values(changes.added)){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(record) && isShapeInPage(store, currentPageId, record)) {
                    builder.add(record.id);
                }
            }
            for (const [_from, to] of Object.values(changes.updated)){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(to)) {
                    if (isShapeInPage(store, currentPageId, to)) {
                        builder.add(to.id);
                    } else {
                        builder.remove(to.id);
                    }
                }
            }
            for (const id of Object.keys(changes.removed)){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(id)) {
                    builder.remove(id);
                }
            }
        }
        const result = builder.get();
        if (!result) {
            return prevValue;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withDiff"])(result.value, result.diff);
    });
};
;
 //# sourceMappingURL=shapeIdsInCurrentPage.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/ClickManager/ClickManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ClickManager",
    ()=>ClickManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _cancelDoubleClickTimeout_dec, __getClickTimeout_dec, _init;
;
;
const MAX_CLICK_DISTANCE = 40;
__getClickTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], _cancelDoubleClickTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
];
class ClickManager {
    constructor(editor){
        this.editor = editor;
        __runInitializers(_init, 5, this);
        __publicField(this, "_clickId", "");
        __publicField(this, "_clickTimeout");
        __publicField(this, "_clickScreenPoint");
        __publicField(this, "_previousScreenPoint");
        /**
     * The current click state.
     *
     * @internal
     */ __publicField(this, "_clickState", "idle");
        __publicField(this, "lastPointerInfo", {});
    }
    _getClickTimeout(state, id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()) {
        this._clickId = id;
        clearTimeout(this._clickTimeout);
        this._clickTimeout = this.editor.timers.setTimeout(()=>{
            if (this._clickState === state && this._clickId === id) {
                switch(this._clickState){
                    case "pendingTriple":
                        {
                            this.editor.dispatch({
                                ...this.lastPointerInfo,
                                type: "click",
                                name: "double_click",
                                phase: "settle"
                            });
                            break;
                        }
                    case "pendingQuadruple":
                        {
                            this.editor.dispatch({
                                ...this.lastPointerInfo,
                                type: "click",
                                name: "triple_click",
                                phase: "settle"
                            });
                            break;
                        }
                    case "pendingOverflow":
                        {
                            this.editor.dispatch({
                                ...this.lastPointerInfo,
                                type: "click",
                                name: "quadruple_click",
                                phase: "settle"
                            });
                            break;
                        }
                    default:
                        {}
                }
                this._clickState = "idle";
            }
        }, state === "idle" || state === "pendingDouble" ? this.editor.options.doubleClickDurationMs : this.editor.options.multiClickDurationMs);
    }
    /**
   * The current click state.
   *
   * @public
   */ // eslint-disable-next-line no-restricted-syntax
    get clickState() {
        return this._clickState;
    }
    handlePointerEvent(info) {
        switch(info.name){
            case "pointer_down":
                {
                    if (!this._clickState) return info;
                    this._clickScreenPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(info.point);
                    if (this._previousScreenPoint && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(this._previousScreenPoint, this._clickScreenPoint) > MAX_CLICK_DISTANCE ** 2) {
                        this._clickState = "idle";
                    }
                    this._previousScreenPoint = this._clickScreenPoint;
                    this.lastPointerInfo = info;
                    switch(this._clickState){
                        case "pendingDouble":
                            {
                                this._clickState = "pendingTriple";
                                this._clickTimeout = this._getClickTimeout(this._clickState);
                                return {
                                    ...info,
                                    type: "click",
                                    name: "double_click",
                                    phase: "down"
                                };
                            }
                        case "pendingTriple":
                            {
                                this._clickState = "pendingQuadruple";
                                this._clickTimeout = this._getClickTimeout(this._clickState);
                                return {
                                    ...info,
                                    type: "click",
                                    name: "triple_click",
                                    phase: "down"
                                };
                            }
                        case "pendingQuadruple":
                            {
                                this._clickState = "pendingOverflow";
                                this._clickTimeout = this._getClickTimeout(this._clickState);
                                return {
                                    ...info,
                                    type: "click",
                                    name: "quadruple_click",
                                    phase: "down"
                                };
                            }
                        case "idle":
                            {
                                this._clickState = "pendingDouble";
                                break;
                            }
                        case "pendingOverflow":
                            {
                                this._clickState = "overflow";
                                break;
                            }
                        default:
                            {}
                    }
                    this._clickTimeout = this._getClickTimeout(this._clickState);
                    return info;
                }
            case "pointer_up":
                {
                    if (!this._clickState) return info;
                    this._clickScreenPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(info.point);
                    switch(this._clickState){
                        case "pendingTriple":
                            {
                                return {
                                    ...this.lastPointerInfo,
                                    type: "click",
                                    name: "double_click",
                                    phase: "up"
                                };
                            }
                        case "pendingQuadruple":
                            {
                                return {
                                    ...this.lastPointerInfo,
                                    type: "click",
                                    name: "triple_click",
                                    phase: "up"
                                };
                            }
                        case "pendingOverflow":
                            {
                                return {
                                    ...this.lastPointerInfo,
                                    type: "click",
                                    name: "quadruple_click",
                                    phase: "up"
                                };
                            }
                        default:
                            {}
                    }
                    return info;
                }
            case "pointer_move":
                {
                    if (this._clickState !== "idle" && this._clickScreenPoint && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(this._clickScreenPoint, this.editor.inputs.getCurrentScreenPoint()) > (this.editor.getInstanceState().isCoarsePointer ? this.editor.options.coarseDragDistanceSquared : this.editor.options.dragDistanceSquared)) {
                        this.cancelDoubleClickTimeout();
                    }
                    return info;
                }
        }
        return info;
    }
    cancelDoubleClickTimeout() {
        this._clickTimeout = clearTimeout(this._clickTimeout);
        this._clickState = "idle";
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "_getClickTimeout", __getClickTimeout_dec, ClickManager);
__decorateElement(_init, 1, "cancelDoubleClickTimeout", _cancelDoubleClickTimeout_dec, ClickManager);
__decoratorMetadata(_init, ClickManager);
;
 //# sourceMappingURL=ClickManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/EdgeScrollManager/EdgeScrollManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EdgeScrollManager",
    ()=>EdgeScrollManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
;
;
class EdgeScrollManager {
    constructor(editor){
        this.editor = editor;
    }
    _isEdgeScrolling = false;
    _edgeScrollDuration = -1;
    getIsEdgeScrolling() {
        return this._isEdgeScrolling;
    }
    /**
   * Update the camera position when the mouse is close to the edge of the screen.
   * Run this on every tick when in a state where edge scrolling is enabled.
   *
   * @public
   */ updateEdgeScrolling(elapsed) {
        const { editor } = this;
        if (editor.getCameraOptions().isLocked) return;
        const edgeScrollProximityFactor = this.getEdgeScroll();
        if (edgeScrollProximityFactor.x === 0 && edgeScrollProximityFactor.y === 0) {
            if (this._isEdgeScrolling) {
                this._isEdgeScrolling = false;
                this._edgeScrollDuration = 0;
            }
        } else {
            if (!this._isEdgeScrolling) {
                this._isEdgeScrolling = true;
                this._edgeScrollDuration = 0;
            }
            this._edgeScrollDuration += elapsed;
            if (this._edgeScrollDuration > editor.options.edgeScrollDelay) {
                const eased = editor.options.edgeScrollEaseDuration > 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeInCubic(Math.min(1, this._edgeScrollDuration / (editor.options.edgeScrollDelay + editor.options.edgeScrollEaseDuration))) : 1;
                this.moveCameraWhenCloseToEdge({
                    x: edgeScrollProximityFactor.x * eased,
                    y: edgeScrollProximityFactor.y * eased
                });
            }
        }
    }
    /**
   * Helper function to get the scroll proximity factor for a given position.
   * @param position - The mouse position on the axis.
   * @param dimension - The component dimension on the axis.
   * @param isCoarse - Whether the pointer is coarse.
   * @param insetStart - Whether the pointer is inset at the start of the axis.
   * @param insetEnd - Whether the pointer is inset at the end of the axis.
   * @internal
   */ getEdgeProximityFactors(position, dimension, isCoarse, insetStart, insetEnd) {
        const { editor } = this;
        const dist = editor.options.edgeScrollDistance;
        const pw = isCoarse ? editor.options.coarsePointerWidth : 0;
        const pMin = position - pw;
        const pMax = position + pw;
        const min = insetStart ? 0 : dist;
        const max = insetEnd ? dimension : dimension - dist;
        if (pMin < min) {
            return Math.min(1, (min - pMin) / dist);
        } else if (pMax > max) {
            return -Math.min(1, (pMax - max) / dist);
        }
        return 0;
    }
    getEdgeScroll() {
        const { editor } = this;
        const { x, y } = editor.inputs.getCurrentScreenPoint();
        const screenBounds = editor.getViewportScreenBounds();
        const { isCoarsePointer, insets: [t, r, b, l] } = editor.getInstanceState();
        const proximityFactorX = this.getEdgeProximityFactors(x, screenBounds.w, isCoarsePointer, l, r);
        const proximityFactorY = this.getEdgeProximityFactors(y, screenBounds.h, isCoarsePointer, t, b);
        return {
            x: proximityFactorX,
            y: proximityFactorY
        };
    }
    /**
   * Moves the camera when the mouse is close to the edge of the screen.
   * @public
   */ moveCameraWhenCloseToEdge(proximityFactor) {
        if (proximityFactor.x === 0 && proximityFactor.y === 0) return;
        const { editor } = this;
        const screenBounds = editor.getViewportScreenBounds();
        const screenSizeFactorX = screenBounds.w < 1e3 ? 0.612 : 1;
        const screenSizeFactorY = screenBounds.h < 1e3 ? 0.612 : 1;
        const zoomLevel = editor.getZoomLevel();
        const pxSpeed = editor.user.getEdgeScrollSpeed() * editor.options.edgeScrollSpeed;
        const scrollDeltaX = pxSpeed * proximityFactor.x * screenSizeFactorX / zoomLevel;
        const scrollDeltaY = pxSpeed * proximityFactor.y * screenSizeFactorY / zoomLevel;
        const { x, y, z } = editor.getCamera();
        editor.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](x + scrollDeltaX, y + scrollDeltaY, z));
    }
}
;
 //# sourceMappingURL=EdgeScrollManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/FocusManager/FocusManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FocusManager",
    ()=>FocusManager
]);
class FocusManager {
    constructor(editor, autoFocus){
        this.editor = editor;
        this.disposeSideEffectListener = editor.sideEffects.registerAfterChangeHandler("instance", (prev, next)=>{
            if (prev.isFocused !== next.isFocused) {
                this.updateContainerClass();
            }
        });
        const currentFocusState = editor.getInstanceState().isFocused;
        if (autoFocus !== currentFocusState) {
            editor.updateInstanceState({
                isFocused: !!autoFocus
            });
        }
        this.updateContainerClass();
        document.body.addEventListener("keydown", this.handleKeyDown.bind(this));
        document.body.addEventListener("mousedown", this.handleMouseDown.bind(this));
    }
    disposeSideEffectListener;
    /**
   * The editor's focus state and the container's focus state
   * are not necessarily always in sync. For that reason we
   * can't rely on the css `:focus` or `:focus-within` selectors to style the
   * editor when it is in focus.
   *
   * For that reason we synchronize the editor's focus state with a
   * special class on the container: tl-container__focused
   */ updateContainerClass() {
        const container = this.editor.getContainer();
        const instanceState = this.editor.getInstanceState();
        if (instanceState.isFocused) {
            container.classList.add("tl-container__focused");
        } else {
            container.classList.remove("tl-container__focused");
        }
        container.classList.add("tl-container__no-focus-ring");
    }
    handleKeyDown(keyEvent) {
        const container = this.editor.getContainer();
        const activeEl = document.activeElement;
        if (this.editor.isIn("select.editing_shape") && !activeEl?.closest(".tlui-contextual-toolbar")) return;
        if (activeEl === container && this.editor.getSelectedShapeIds().length > 0) return;
        if ([
            "Tab",
            "ArrowUp",
            "ArrowDown"
        ].includes(keyEvent.key)) {
            container.classList.remove("tl-container__no-focus-ring");
        }
    }
    handleMouseDown() {
        const container = this.editor.getContainer();
        container.classList.add("tl-container__no-focus-ring");
    }
    focus() {
        this.editor.getContainer().focus();
    }
    blur() {
        this.editor.complete();
        this.editor.getContainer().blur();
    }
    dispose() {
        document.body.removeEventListener("keydown", this.handleKeyDown.bind(this));
        document.body.removeEventListener("mousedown", this.handleMouseDown.bind(this));
        this.disposeSideEffectListener?.();
    }
}
;
 //# sourceMappingURL=FocusManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/FontManager/FontManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FontManager",
    ()=>FontManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/transactions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
;
;
class FontManager {
    constructor(editor, assetUrls){
        this.editor = editor;
        this.assetUrls = assetUrls;
        this.shapeFontFacesCache = editor.store.createComputedCache("shape font faces", (shape)=>{
            const shapeUtil = this.editor.getShapeUtil(shape);
            return shapeUtil.getFontFaces(shape);
        }, {
            areResultsEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysShallowEqual"],
            areRecordsEqual: (a, b)=>a.props === b.props && a.meta === b.meta
        });
        this.shapeFontLoadStateCache = editor.store.createCache((id)=>{
            const fontFacesComputed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("font faces", ()=>this.getShapeFontFaces(id));
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("font load state", ()=>{
                const states = fontFacesComputed.get().map((face)=>this.getFontState(face));
                return states;
            }, {
                isEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysShallowEqual"]
            });
        });
    }
    shapeFontFacesCache;
    shapeFontLoadStateCache;
    getShapeFontFaces(shape) {
        const shapeId = typeof shape === "string" ? shape : shape.id;
        return this.shapeFontFacesCache.get(shapeId) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
    }
    trackFontsForShape(shape) {
        const shapeId = typeof shape === "string" ? shape : shape.id;
        this.shapeFontLoadStateCache.get(shapeId);
    }
    async loadRequiredFontsForCurrentPage(limit = Infinity) {
        const neededFonts = /* @__PURE__ */ new Set();
        for (const shapeId of this.editor.getCurrentPageShapeIds()){
            for (const font of this.getShapeFontFaces(this.editor.getShape(shapeId))){
                neededFonts.add(font);
            }
        }
        if (neededFonts.size > limit) {
            return;
        }
        const promises = Array.from(neededFonts, (font)=>this.ensureFontIsLoaded(font));
        await Promise.all(promises);
    }
    fontStates = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomMap"]("font states");
    getFontState(font) {
        return this.fontStates.get(font) ?? null;
    }
    ensureFontIsLoaded(font) {
        const existingState = this.getFontState(font);
        if (existingState) return existingState.loadingPromise;
        const instance = this.findOrCreateFontFace(font);
        const state = {
            state: "loading",
            instance,
            loadingPromise: instance.load().then(()=>{
                document.fonts.add(instance);
                this.fontStates.update(font, (s)=>({
                        ...s,
                        state: "ready"
                    }));
            }).catch((err)=>{
                console.error(err);
                this.fontStates.update(font, (s)=>({
                        ...s,
                        state: "error"
                    }));
            })
        };
        this.fontStates.set(font, state);
        return state.loadingPromise;
    }
    fontsToLoad = /* @__PURE__ */ new Set();
    requestFonts(fonts) {
        if (!this.fontsToLoad.size) {
            queueMicrotask(()=>{
                if (this.editor.isDisposed) return;
                const toLoad = this.fontsToLoad;
                this.fontsToLoad = /* @__PURE__ */ new Set();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
                    for (const font of toLoad){
                        this.ensureFontIsLoaded(font);
                    }
                });
            });
        }
        for (const font of fonts){
            this.fontsToLoad.add(font);
        }
    }
    findOrCreateFontFace(font) {
        for (const existing of document.fonts){
            if (existing.family === font.family && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapEntries"])(defaultFontFaceDescriptors).every(([key, defaultValue])=>existing[key] === (font[key] ?? defaultValue))) {
                return existing;
            }
        }
        const url = this.assetUrls?.[font.src.url] ?? font.src.url;
        const instance = new FontFace(font.family, `url(${JSON.stringify(url)})`, {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapObjectMapValues"])(defaultFontFaceDescriptors, (key)=>font[key]),
            display: "swap"
        });
        document.fonts.add(instance);
        return instance;
    }
    async toEmbeddedCssDeclaration(font) {
        const url = this.assetUrls?.[font.src.url] ?? font.src.url;
        const dataUrl = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].urlToDataUrl(url);
        const src = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])([
            `url("${dataUrl}")`,
            font.src.format ? `format(${font.src.format})` : null,
            font.src.tech ? `tech(${font.src.tech})` : null
        ]).join(" ");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])([
            `@font-face {`,
            `  font-family: "${font.family}";`,
            font.ascentOverride ? `  ascent-override: ${font.ascentOverride};` : null,
            font.descentOverride ? `  descent-override: ${font.descentOverride};` : null,
            font.stretch ? `  font-stretch: ${font.stretch};` : null,
            font.style ? `  font-style: ${font.style};` : null,
            font.weight ? `  font-weight: ${font.weight};` : null,
            font.featureSettings ? `  font-feature-settings: ${font.featureSettings};` : null,
            font.lineGapOverride ? `  line-gap-override: ${font.lineGapOverride};` : null,
            font.unicodeRange ? `  unicode-range: ${font.unicodeRange};` : null,
            `  src: ${src};`,
            `}`
        ]).join("\n");
    }
}
const defaultFontFaceDescriptors = {
    style: "normal",
    weight: "normal",
    stretch: "normal",
    unicodeRange: "U+0-10FFFF",
    featureSettings: "normal",
    ascentOverride: "normal",
    descentOverride: "normal",
    lineGapOverride: "normal"
};
;
 //# sourceMappingURL=FontManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/HistoryManager/HistoryManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HistoryManager",
    ()=>HistoryManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/transactions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/function.mjs [app-client] (ecmascript)");
;
;
;
var HistoryRecorderState = /* @__PURE__ */ ((HistoryRecorderState2)=>{
    HistoryRecorderState2["Recording"] = "recording";
    HistoryRecorderState2["RecordingPreserveRedoStack"] = "recordingPreserveRedoStack";
    HistoryRecorderState2["Paused"] = "paused";
    return HistoryRecorderState2;
})(HistoryRecorderState || {});
class HistoryManager {
    store;
    dispose;
    state = "recording" /* Recording */ ;
    pendingDiff = new PendingDiff();
    stacks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("HistoryManager.stacks", {
        undos: stack(),
        redos: stack()
    }, {
        isEqual: (a, b)=>a.undos === b.undos && a.redos === b.redos
    });
    annotateError;
    constructor(opts){
        this.store = opts.store;
        this.annotateError = opts.annotateError ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$function$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"];
        this.dispose = this.store.addHistoryInterceptor((entry, source)=>{
            if (source !== "user") return;
            switch(this.state){
                case "recording" /* Recording */ :
                    this.pendingDiff.apply(entry.changes);
                    this.stacks.update(({ undos })=>({
                            undos,
                            redos: stack()
                        }));
                    break;
                case "recordingPreserveRedoStack" /* RecordingPreserveRedoStack */ :
                    this.pendingDiff.apply(entry.changes);
                    break;
                case "paused" /* Paused */ :
                    break;
                default:
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(this.state);
            }
        });
    }
    flushPendingDiff() {
        if (this.pendingDiff.isEmpty()) return;
        const diff = this.pendingDiff.clear();
        this.stacks.update(({ undos, redos })=>({
                undos: undos.push({
                    type: "diff",
                    diff
                }),
                redos
            }));
    }
    getNumUndos() {
        return this.stacks.get().undos.length + (this.pendingDiff.isEmpty() ? 0 : 1);
    }
    getNumRedos() {
        return this.stacks.get().redos.length;
    }
    /** @internal */ _isInBatch = false;
    batch(fn, opts) {
        const previousState = this.state;
        if (previousState !== "paused" /* Paused */  && opts?.history) {
            this.state = modeToState[opts.history];
        }
        try {
            if (this._isInBatch) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(fn);
                return this;
            }
            this._isInBatch = true;
            try {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(fn);
            } catch (error) {
                this.annotateError(error);
                throw error;
            } finally{
                this._isInBatch = false;
            }
            return this;
        } finally{
            this.state = previousState;
        }
    }
    // History
    _undo({ pushToRedoStack, toMark = void 0 }) {
        const previousState = this.state;
        this.state = "paused" /* Paused */ ;
        try {
            let { undos, redos } = this.stacks.get();
            const pendingDiff = this.pendingDiff.clear();
            const isPendingDiffEmpty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecordsDiffEmpty"])(pendingDiff);
            const diffToUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseRecordsDiff"])(pendingDiff);
            if (pushToRedoStack && !isPendingDiffEmpty) {
                redos = redos.push({
                    type: "diff",
                    diff: pendingDiff
                });
            }
            let didFindMark = false;
            if (isPendingDiffEmpty) {
                while(undos.head?.type === "stop"){
                    const mark = undos.head;
                    undos = undos.tail;
                    if (pushToRedoStack) {
                        redos = redos.push(mark);
                    }
                    if (mark.id === toMark) {
                        didFindMark = true;
                        break;
                    }
                }
            }
            if (!didFindMark) {
                loop: while(undos.head){
                    const undo = undos.head;
                    undos = undos.tail;
                    if (pushToRedoStack) {
                        redos = redos.push(undo);
                    }
                    switch(undo.type){
                        case "diff":
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffsMutable"])(diffToUndo, [
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseRecordsDiff"])(undo.diff)
                            ]);
                            break;
                        case "stop":
                            if (!toMark) break loop;
                            if (undo.id === toMark) {
                                didFindMark = true;
                                break loop;
                            }
                            break;
                        default:
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(undo);
                    }
                }
            }
            if (!didFindMark && toMark) {
                return this;
            }
            this.store.applyDiff(diffToUndo, {
                ignoreEphemeralKeys: true
            });
            this.store.ensureStoreIsUsable();
            this.stacks.set({
                undos,
                redos
            });
        } finally{
            this.state = previousState;
        }
        return this;
    }
    undo() {
        this._undo({
            pushToRedoStack: true
        });
        return this;
    }
    redo() {
        const previousState = this.state;
        this.state = "paused" /* Paused */ ;
        try {
            this.flushPendingDiff();
            let { undos, redos } = this.stacks.get();
            if (redos.length === 0) {
                return this;
            }
            while(redos.head?.type === "stop"){
                undos = undos.push(redos.head);
                redos = redos.tail;
            }
            const diffToRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyRecordsDiff"])();
            while(redos.head){
                const redo = redos.head;
                undos = undos.push(redo);
                redos = redos.tail;
                if (redo.type === "diff") {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffsMutable"])(diffToRedo, [
                        redo.diff
                    ]);
                } else {
                    break;
                }
            }
            this.store.applyDiff(diffToRedo, {
                ignoreEphemeralKeys: true
            });
            this.store.ensureStoreIsUsable();
            this.stacks.set({
                undos,
                redos
            });
        } finally{
            this.state = previousState;
        }
        return this;
    }
    bail() {
        this._undo({
            pushToRedoStack: false
        });
        return this;
    }
    bailToMark(id) {
        if (id) {
            this._undo({
                pushToRedoStack: false,
                toMark: id
            });
        }
        return this;
    }
    squashToMark(id) {
        let top = this.stacks.get().undos;
        const popped = [];
        while(top.head && !(top.head.type === "stop" && top.head.id === id)){
            if (top.head.type === "diff") {
                popped.push(top.head.diff);
            }
            top = top.tail;
        }
        if (!top.head || top.head?.id !== id) {
            console.error("Could not find mark to squash to: ", id);
            return this;
        }
        if (popped.length === 0) {
            return this;
        }
        const diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyRecordsDiff"])();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffsMutable"])(diff, popped.reverse());
        this.stacks.update(({ redos })=>({
                undos: top.push({
                    type: "diff",
                    diff
                }),
                redos
            }));
        return this;
    }
    /** @internal */ _mark(id) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            this.flushPendingDiff();
            this.stacks.update(({ undos, redos })=>({
                    undos: undos.push({
                        type: "stop",
                        id
                    }),
                    redos
                }));
        });
    }
    clear() {
        this.stacks.set({
            undos: stack(),
            redos: stack()
        });
        this.pendingDiff.clear();
    }
    /** @internal */ getMarkIdMatching(idSubstring) {
        let top = this.stacks.get().undos;
        while(top.head){
            if (top.head.type === "stop" && top.head.id.includes(idSubstring)) {
                return top.head.id;
            }
            top = top.tail;
        }
        return null;
    }
    /** @internal */ debug() {
        const { undos, redos } = this.stacks.get();
        return {
            undos: stackToArray(undos),
            redos: stackToArray(redos),
            pendingDiff: this.pendingDiff.debug(),
            state: this.state
        };
    }
}
const modeToState = {
    record: "recording" /* Recording */ ,
    "record-preserveRedoStack": "recordingPreserveRedoStack" /* RecordingPreserveRedoStack */ ,
    ignore: "paused" /* Paused */ 
};
class PendingDiff {
    diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyRecordsDiff"])();
    isEmptyAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("PendingDiff.isEmpty", true);
    clear() {
        const diff = this.diff;
        this.diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyRecordsDiff"])();
        this.isEmptyAtom.set(true);
        return diff;
    }
    isEmpty() {
        return this.isEmptyAtom.get();
    }
    apply(diff) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashRecordDiffsMutable"])(this.diff, [
            diff
        ]);
        this.isEmptyAtom.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecordsDiffEmpty"])(this.diff));
    }
    debug() {
        return {
            diff: this.diff,
            isEmpty: this.isEmpty()
        };
    }
}
function stack() {
    return EMPTY_STACK_ITEM;
}
class EmptyStackItem {
    length = 0;
    head = null;
    tail = this;
    push(head) {
        return new StackItem(head, this);
    }
}
const EMPTY_STACK_ITEM = new EmptyStackItem();
class StackItem {
    constructor(head, tail){
        this.head = head;
        this.tail = tail;
        this.length = tail.length + 1;
    }
    length;
    push(head) {
        return new StackItem(head, this);
    }
}
function stackToArray(stack2) {
    if (!stack2.length) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
    }
    const arr = [];
    while(stack2.length){
        arr.push(stack2.head);
        stack2 = stack2.tail;
    }
    return arr;
}
;
 //# sourceMappingURL=HistoryManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/InputsManager/InputsManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputsManager",
    ()=>InputsManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/capture.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/AtomSet.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPointer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/keyboard.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var __getHasCollaborators_dec, _init;
;
;
;
;
;
;
__getHasCollaborators_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
];
class InputsManager {
    constructor(editor){
        this.editor = editor;
        __runInitializers(_init, 5, this);
        __publicField(this, "_originPagePoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("originPagePoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_originScreenPoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("originScreenPoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_previousPagePoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("previousPagePoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_previousScreenPoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("previousScreenPoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_currentPagePoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("currentPagePoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_currentScreenPoint", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("currentScreenPoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        __publicField(this, "_pointerVelocity", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("pointerVelocity", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]()));
        /**
     * A set containing the currently pressed keys.
     */ __publicField(this, "keys", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomSet"]("keys"));
        /**
     * A set containing the currently pressed buttons.
     */ __publicField(this, "buttons", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$AtomSet$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtomSet"]("buttons"));
        __publicField(this, "_isPen", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isPen", false));
        __publicField(this, "_shiftKey", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("shiftKey", false));
        __publicField(this, "_metaKey", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("metaKey", false));
        __publicField(this, "_ctrlKey", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("ctrlKey", false));
        __publicField(this, "_altKey", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("altKey", false));
        __publicField(this, "_isDragging", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isDragging", false));
        __publicField(this, "_isPointing", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isPointing", false));
        __publicField(this, "_isPinching", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isPinching", false));
        __publicField(this, "_isEditing", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isEditing", false));
        __publicField(this, "_isPanning", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isPanning", false));
        __publicField(this, "_isSpacebarPanning", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isSpacebarPanning", false));
        /**
     * The previous point used for velocity calculation (updated each tick, not each pointer event).
     * @internal
     */ __publicField(this, "_velocityPrevPoint", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]());
    }
    /**
   * The most recent pointer down's position in the current page space.
   */ getOriginPagePoint() {
        return this._originPagePoint.get();
    }
    /**
   * @deprecated Use `getOriginPagePoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get originPagePoint() {
        return this.getOriginPagePoint();
    }
    /**
   * The most recent pointer down's position in screen space.
   */ getOriginScreenPoint() {
        return this._originScreenPoint.get();
    }
    /**
   * @deprecated Use `getOriginScreenPoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get originScreenPoint() {
        return this.getOriginScreenPoint();
    }
    /**
   * The previous pointer position in the current page space.
   */ getPreviousPagePoint() {
        return this._previousPagePoint.get();
    }
    /**
   * @deprecated Use `getPreviousPagePoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get previousPagePoint() {
        return this.getPreviousPagePoint();
    }
    /**
   * The previous pointer position in screen space.
   */ getPreviousScreenPoint() {
        return this._previousScreenPoint.get();
    }
    /**
   * @deprecated Use `getPreviousScreenPoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get previousScreenPoint() {
        return this.getPreviousScreenPoint();
    }
    /**
   * The most recent pointer position in the current page space.
   */ getCurrentPagePoint() {
        return this._currentPagePoint.get();
    }
    /**
   * @deprecated Use `getCurrentPagePoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get currentPagePoint() {
        return this.getCurrentPagePoint();
    }
    /**
   * The most recent pointer position in screen space.
   */ getCurrentScreenPoint() {
        return this._currentScreenPoint.get();
    }
    /**
   * @deprecated Use `getCurrentScreenPoint()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get currentScreenPoint() {
        return this.getCurrentScreenPoint();
    }
    /**
   * Velocity of mouse pointer, in pixels per millisecond.
   */ getPointerVelocity() {
        return this._pointerVelocity.get();
    }
    /**
   * @deprecated Use `getPointerVelocity()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get pointerVelocity() {
        return this.getPointerVelocity();
    }
    /**
   * Normally you shouldn't need to set the pointer velocity directly, this is set by the tick manager.
   * However, this is currently used in tests to fake pointer velocity.
   * @param pointerVelocity - The pointer velocity.
   * @internal
   */ setPointerVelocity(pointerVelocity) {
        this._pointerVelocity.set(pointerVelocity);
    }
    /**
   * Whether the input is from a pen.
   */ getIsPen() {
        return this._isPen.get();
    }
    /**
   * @deprecated Use `getIsPen()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isPen() {
        return this.getIsPen();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isPen(isPen) {
        this.setIsPen(isPen);
    }
    /**
   * @param isPen - Whether the input is from a pen.
   */ setIsPen(isPen) {
        this._isPen.set(isPen);
    }
    /**
   * Whether the shift key is currently pressed.
   */ getShiftKey() {
        return this._shiftKey.get();
    }
    /**
   * @deprecated Use `getShiftKey()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get shiftKey() {
        return this.getShiftKey();
    }
    // eslint-disable-next-line no-restricted-syntax
    set shiftKey(shiftKey) {
        this.setShiftKey(shiftKey);
    }
    /**
   * @param shiftKey - Whether the shift key is pressed.
   * @internal
   */ setShiftKey(shiftKey) {
        this._shiftKey.set(shiftKey);
    }
    /**
   * Whether the meta key is currently pressed.
   */ getMetaKey() {
        return this._metaKey.get();
    }
    /**
   * @deprecated Use `getMetaKey()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get metaKey() {
        return this.getMetaKey();
    }
    // eslint-disable-next-line no-restricted-syntax
    set metaKey(metaKey) {
        this.setMetaKey(metaKey);
    }
    /**
   * @param metaKey - Whether the meta key is pressed.
   * @internal
   */ setMetaKey(metaKey) {
        this._metaKey.set(metaKey);
    }
    /**
   * Whether the ctrl or command key is currently pressed.
   */ getCtrlKey() {
        return this._ctrlKey.get();
    }
    /**
   * @deprecated Use `getCtrlKey()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get ctrlKey() {
        return this.getCtrlKey();
    }
    // eslint-disable-next-line no-restricted-syntax
    set ctrlKey(ctrlKey) {
        this.setCtrlKey(ctrlKey);
    }
    /**
   * @param ctrlKey - Whether the ctrl key is pressed.
   * @internal
   */ setCtrlKey(ctrlKey) {
        this._ctrlKey.set(ctrlKey);
    }
    /**
   * Whether the alt or option key is currently pressed.
   */ getAltKey() {
        return this._altKey.get();
    }
    /**
   * @deprecated Use `getAltKey()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get altKey() {
        return this.getAltKey();
    }
    // eslint-disable-next-line no-restricted-syntax
    set altKey(altKey) {
        this.setAltKey(altKey);
    }
    /**
   * @param altKey - Whether the alt key is pressed.
   * @internal
   */ setAltKey(altKey) {
        this._altKey.set(altKey);
    }
    /**
   * Is the accelerator key (cmd on mac, ctrl elsewhere) currently pressed.
   */ getAccelKey() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$keyboard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAccelKey"])({
            metaKey: this.getMetaKey(),
            ctrlKey: this.getCtrlKey()
        });
    }
    /**
   * @deprecated Use `getAccelKey()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get accelKey() {
        return this.getAccelKey();
    }
    /**
   * Whether the user is dragging.
   */ getIsDragging() {
        return this._isDragging.get();
    }
    /**
   * Soon to be deprecated, use `getIsDragging()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isDragging() {
        return this.getIsDragging();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isDragging(isDragging) {
        this.setIsDragging(isDragging);
    }
    /**
   * @param isDragging - Whether the user is dragging.
   */ setIsDragging(isDragging) {
        this._isDragging.set(isDragging);
    }
    /**
   * Whether the user is pointing.
   */ getIsPointing() {
        return this._isPointing.get();
    }
    /**
   * @deprecated Use `getIsPointing()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isPointing() {
        return this.getIsPointing();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isPointing(isPointing) {
        this.setIsPointing(isPointing);
    }
    /**
   * @param isPointing - Whether the user is pointing.
   * @internal
   */ setIsPointing(isPointing) {
        this._isPointing.set(isPointing);
    }
    /**
   * Whether the user is pinching.
   */ getIsPinching() {
        return this._isPinching.get();
    }
    /**
   * @deprecated Use `getIsPinching()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isPinching() {
        return this.getIsPinching();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isPinching(isPinching) {
        this.setIsPinching(isPinching);
    }
    /**
   * @param isPinching - Whether the user is pinching.
   * @internal
   */ setIsPinching(isPinching) {
        this._isPinching.set(isPinching);
    }
    /**
   * Whether the user is editing.
   */ getIsEditing() {
        return this._isEditing.get();
    }
    /**
   * @deprecated Use `getIsEditing()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isEditing() {
        return this.getIsEditing();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isEditing(isEditing) {
        this.setIsEditing(isEditing);
    }
    /**
   * @param isEditing - Whether the user is editing.
   */ setIsEditing(isEditing) {
        this._isEditing.set(isEditing);
    }
    /**
   * Whether the user is panning.
   */ getIsPanning() {
        return this._isPanning.get();
    }
    /**
   * @deprecated Use `getIsPanning()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isPanning() {
        return this.getIsPanning();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isPanning(isPanning) {
        this.setIsPanning(isPanning);
    }
    /**
   * @param isPanning - Whether the user is panning.
   * @internal
   */ setIsPanning(isPanning) {
        this._isPanning.set(isPanning);
    }
    /**
   * Whether the user is spacebar panning.
   */ getIsSpacebarPanning() {
        return this._isSpacebarPanning.get();
    }
    /**
   * @deprecated Use `getIsSpacebarPanning()` instead.
   */ // eslint-disable-next-line no-restricted-syntax
    get isSpacebarPanning() {
        return this.getIsSpacebarPanning();
    }
    // eslint-disable-next-line no-restricted-syntax
    set isSpacebarPanning(isSpacebarPanning) {
        this.setIsSpacebarPanning(isSpacebarPanning);
    }
    /**
   * @param isSpacebarPanning - Whether the user is spacebar panning.
   * @internal
   */ setIsSpacebarPanning(isSpacebarPanning) {
        this._isSpacebarPanning.set(isSpacebarPanning);
    }
    _getHasCollaborators() {
        return this.editor.getCollaborators().length > 0;
    }
    /**
   * Update the pointer velocity based on elapsed time. Called by the tick manager.
   * @param elapsed - The time elapsed since the last tick in milliseconds.
   * @internal
   */ updatePointerVelocity(elapsed) {
        const currentScreenPoint = this.getCurrentScreenPoint();
        const pointerVelocity = this.getPointerVelocity();
        if (elapsed === 0) return;
        const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentScreenPoint, this._velocityPrevPoint);
        this._velocityPrevPoint = currentScreenPoint.clone();
        const length = delta.len();
        const direction = length ? delta.div(length) : new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
        const next = pointerVelocity.clone().lrp(direction.mul(length / elapsed), 0.5);
        if (Math.abs(next.x) < 0.01) next.x = 0;
        if (Math.abs(next.y) < 0.01) next.y = 0;
        if (!pointerVelocity.equals(next)) {
            this._pointerVelocity.set(next);
        }
    }
    /**
   * Update the input points from a pointer, pinch, or wheel event.
   *
   * @param info - The event info.
   * @internal
   */ updateFromEvent(info) {
        const currentScreenPoint = this._currentScreenPoint.__unsafe__getWithoutCapture();
        const currentPagePoint = this._currentPagePoint.__unsafe__getWithoutCapture();
        const isPinching = this._isPinching.__unsafe__getWithoutCapture();
        const { screenBounds } = this.editor.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        const { x: cx, y: cy, z: cz } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafe__withoutCapture"])(()=>this.editor.getCamera());
        const sx = info.point.x - screenBounds.x;
        const sy = info.point.y - screenBounds.y;
        const sz = info.point.z ?? 0.5;
        this._previousScreenPoint.set(currentScreenPoint);
        this._previousPagePoint.set(currentPagePoint);
        this._currentScreenPoint.set(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](sx, sy));
        const nx = sx / cz - cx;
        const ny = sy / cz - cy;
        if (isFinite(nx) && isFinite(ny)) {
            this._currentPagePoint.set(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](nx, ny, sz));
        }
        this._isPen.set(info.type === "pointer" && info.isPen);
        if (info.name === "pointer_down" || isPinching) {
            this._pointerVelocity.set(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]());
            this._originScreenPoint.set(this._currentScreenPoint.__unsafe__getWithoutCapture());
            this._originPagePoint.set(this._currentPagePoint.__unsafe__getWithoutCapture());
        }
        if (this._getHasCollaborators()) {
            this.editor.run(()=>{
                const pagePoint = this._currentPagePoint.__unsafe__getWithoutCapture();
                this.editor.store.put([
                    {
                        id: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"],
                        typeName: "pointer",
                        x: pagePoint.x,
                        y: pagePoint.y,
                        lastActivityTimestamp: info.type === "pointer" && info.pointerId === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INTERNAL_POINTER_IDS"].CAMERA_MOVE ? this.editor.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPointer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLPOINTER_ID"])?.lastActivityTimestamp ?? Date.now() : Date.now(),
                        meta: {}
                    }
                ]);
            }, {
                history: "ignore"
            });
        }
    }
    toJson() {
        return {
            originPagePoint: this._originPagePoint.get().toJson(),
            originScreenPoint: this._originScreenPoint.get().toJson(),
            previousPagePoint: this._previousPagePoint.get().toJson(),
            previousScreenPoint: this._previousScreenPoint.get().toJson(),
            currentPagePoint: this._currentPagePoint.get().toJson(),
            currentScreenPoint: this._currentScreenPoint.get().toJson(),
            pointerVelocity: this._pointerVelocity.get().toJson(),
            shiftKey: this._shiftKey.get(),
            metaKey: this._metaKey.get(),
            ctrlKey: this._ctrlKey.get(),
            altKey: this._altKey.get(),
            isPen: this._isPen.get(),
            isDragging: this._isDragging.get(),
            isPointing: this._isPointing.get(),
            isPinching: this._isPinching.get(),
            isEditing: this._isEditing.get(),
            isPanning: this._isPanning.get(),
            isSpacebarPanning: this._isSpacebarPanning.get(),
            keys: Array.from(this.keys.keys()),
            buttons: Array.from(this.buttons.keys())
        };
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "_getHasCollaborators", __getHasCollaborators_dec, InputsManager);
__decoratorMetadata(_init, InputsManager);
;
 //# sourceMappingURL=InputsManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/ScribbleManager/ScribbleManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ScribbleManager",
    ()=>ScribbleManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
;
class ScribbleManager {
    constructor(editor){
        this.editor = editor;
    }
    sessions = /* @__PURE__ */ new Map();
    // ==================== SESSION API ====================
    /**
   * Start a new session for grouping scribbles.
   * Returns a session ID that can be used with other session methods.
   *
   * @param options - Session configuration
   * @returns Session ID
   * @public
   */ startSession(options = {}) {
        const id = options.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
        const session = {
            id,
            items: [],
            state: "active",
            options: {
                selfConsume: options.selfConsume ?? true,
                idleTimeoutMs: options.idleTimeoutMs ?? 0,
                fadeMode: options.fadeMode ?? "individual",
                fadeEasing: options.fadeEasing ?? (options.fadeMode === "grouped" ? "ease-in" : "linear"),
                fadeDurationMs: options.fadeDurationMs ?? this.editor.options.laserFadeoutMs
            },
            fadeElapsed: 0,
            totalPointsAtFadeStart: 0
        };
        this.sessions.set(id, session);
        if (session.options.idleTimeoutMs > 0) {
            this.resetIdleTimeout(session);
        }
        return id;
    }
    /**
   * Add a scribble to a session.
   *
   * @param sessionId - The session ID
   * @param scribble - Partial scribble properties
   * @param scribbleId - Optional scribble ID
   * @public
   */ addScribbleToSession(sessionId, scribble, scribbleId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()) {
        const session = this.sessions.get(sessionId);
        if (!session) throw Error(`Session ${sessionId} not found`);
        const item = {
            id: scribbleId,
            scribble: {
                id: scribbleId,
                size: 20,
                color: "accent",
                opacity: 0.8,
                delay: 0,
                points: [],
                shrink: 0.1,
                taper: true,
                ...scribble,
                state: "starting"
            },
            timeoutMs: 0,
            delayRemaining: scribble.delay ?? 0,
            prev: null,
            next: null
        };
        session.items.push(item);
        if (session.options.idleTimeoutMs > 0) {
            this.resetIdleTimeout(session);
        }
        return item;
    }
    /**
   * Add a point to a scribble in a session.
   *
   * @param sessionId - The session ID
   * @param scribbleId - The scribble ID
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param z - Z coordinate (pressure)
   * @public
   */ addPointToSession(sessionId, scribbleId, x, y, z = 0.5) {
        const session = this.sessions.get(sessionId);
        if (!session) throw Error(`Session ${sessionId} not found`);
        const item = session.items.find((i)=>i.id === scribbleId);
        if (!item) throw Error(`Scribble ${scribbleId} not found in session ${sessionId}`);
        const point = {
            x,
            y,
            z
        };
        if (!item.prev || __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(item.prev, point) >= 1) {
            item.next = point;
        }
        if (session.options.idleTimeoutMs > 0) {
            this.resetIdleTimeout(session);
        }
        return item;
    }
    /**
   * Extend a session, resetting its idle timeout.
   *
   * @param sessionId - The session ID
   * @public
   */ extendSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        if (session.options.idleTimeoutMs > 0) {
            this.resetIdleTimeout(session);
        }
    }
    /**
   * Stop a session, triggering fade-out.
   *
   * @param sessionId - The session ID
   * @public
   */ stopSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session || session.state !== "active") return;
        this.clearIdleTimeout(session);
        session.state = "stopping";
        if (session.options.fadeMode === "grouped") {
            session.totalPointsAtFadeStart = session.items.reduce((sum, item)=>sum + item.scribble.points.length, 0);
            session.fadeElapsed = 0;
            for (const item of session.items){
                item.scribble.state = "stopping";
            }
        } else {
            for (const item of session.items){
                item.delayRemaining = Math.min(item.delayRemaining, 200);
                item.scribble.state = "stopping";
            }
        }
    }
    /**
   * Clear all scribbles in a session immediately.
   *
   * @param sessionId - The session ID
   * @public
   */ clearSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        this.clearIdleTimeout(session);
        for (const item of session.items){
            item.scribble.points.length = 0;
        }
        session.state = "complete";
    }
    /**
   * Check if a session is active.
   *
   * @param sessionId - The session ID
   * @public
   */ isSessionActive(sessionId) {
        const session = this.sessions.get(sessionId);
        return session?.state === "active";
    }
    // ==================== SIMPLE API (for eraser, select, etc.) ====================
    /**
   * Add a scribble using the default self-consuming behavior.
   * Creates an implicit session for the scribble.
   *
   * @param scribble - Partial scribble properties
   * @param id - Optional scribble id
   * @returns The created scribble item
   * @public
   */ addScribble(scribble, id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()) {
        const sessionId = this.startSession();
        return this.addScribbleToSession(sessionId, scribble, id);
    }
    /**
   * Add a point to a scribble. Searches all sessions.
   *
   * @param id - The scribble id
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param z - Z coordinate (pressure)
   * @public
   */ addPoint(id, x, y, z = 0.5) {
        for (const session of this.sessions.values()){
            const item = session.items.find((i)=>i.id === id);
            if (item) {
                const point = {
                    x,
                    y,
                    z
                };
                if (!item.prev || __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(item.prev, point) >= 1) {
                    item.next = point;
                }
                if (session.options.idleTimeoutMs > 0) {
                    this.resetIdleTimeout(session);
                }
                return item;
            }
        }
        throw Error(`Scribble with id ${id} not found`);
    }
    /**
   * Mark a scribble as complete (done being drawn but not yet fading).
   * Searches all sessions.
   *
   * @param id - The scribble id
   * @public
   */ complete(id) {
        for (const session of this.sessions.values()){
            const item = session.items.find((i)=>i.id === id);
            if (item) {
                if (item.scribble.state === "starting" || item.scribble.state === "active") {
                    item.scribble.state = "complete";
                }
                return item;
            }
        }
        throw Error(`Scribble with id ${id} not found`);
    }
    /**
   * Stop a scribble. Searches all sessions.
   *
   * @param id - The scribble id
   * @public
   */ stop(id) {
        for (const session of this.sessions.values()){
            const item = session.items.find((i)=>i.id === id);
            if (item) {
                item.delayRemaining = Math.min(item.delayRemaining, 200);
                item.scribble.state = "stopping";
                return item;
            }
        }
        throw Error(`Scribble with id ${id} not found`);
    }
    /**
   * Stop and remove all sessions.
   *
   * @public
   */ reset() {
        for (const session of this.sessions.values()){
            this.clearIdleTimeout(session);
        }
        this.sessions.clear();
        this.editor.updateInstanceState({
            scribbles: []
        });
    }
    /**
   * Update on each animation frame.
   *
   * @param elapsed - The number of milliseconds since the last tick.
   * @public
   */ tick(elapsed) {
        const currentScribbles = this.editor.getInstanceState().scribbles;
        if (this.sessions.size === 0 && currentScribbles.length === 0) return;
        this.editor.run(()=>{
            for (const session of this.sessions.values()){
                this.tickSession(session, elapsed);
            }
            for (const [id, session] of this.sessions){
                if (session.state === "complete") {
                    this.clearIdleTimeout(session);
                    this.sessions.delete(id);
                }
            }
            const scribbles = [];
            for (const session of this.sessions.values()){
                for (const item of session.items){
                    if (item.scribble.points.length > 0) {
                        scribbles.push({
                            ...item.scribble,
                            points: [
                                ...item.scribble.points
                            ]
                        });
                    }
                }
            }
            this.editor.updateInstanceState({
                scribbles
            });
        });
    }
    // ==================== PRIVATE HELPERS ====================
    resetIdleTimeout(session) {
        this.clearIdleTimeout(session);
        session.idleTimeoutHandle = this.editor.timers.setTimeout(()=>{
            this.stopSession(session.id);
        }, session.options.idleTimeoutMs);
    }
    clearIdleTimeout(session) {
        if (session.idleTimeoutHandle !== void 0) {
            clearTimeout(session.idleTimeoutHandle);
            session.idleTimeoutHandle = void 0;
        }
    }
    tickSession(session, elapsed) {
        if (session.state === "complete") return;
        if (session.state === "stopping" && session.options.fadeMode === "grouped") {
            this.tickGroupedFade(session, elapsed);
        } else {
            this.tickSessionItems(session, elapsed);
        }
        const hasContent = session.items.some((item)=>item.scribble.points.length > 0);
        if (!hasContent && (session.state === "stopping" || session.items.length === 0)) {
            session.state = "complete";
        }
    }
    tickSessionItems(session, elapsed) {
        for (const item of session.items){
            const shouldSelfConsume = session.options.selfConsume || session.state === "stopping" || item.scribble.state === "stopping";
            if (shouldSelfConsume) {
                this.tickSelfConsumingItem(item, elapsed);
            } else {
                this.tickPersistentItem(item);
            }
        }
        if (session.options.fadeMode === "individual") {
            for(let i = session.items.length - 1; i >= 0; i--){
                if (session.items[i].scribble.points.length === 0) {
                    session.items.splice(i, 1);
                }
            }
        }
    }
    tickPersistentItem(item) {
        const { scribble } = item;
        if (scribble.state === "starting") {
            const { next, prev } = item;
            if (next && next !== prev) {
                item.prev = next;
                scribble.points.push(next);
            }
            if (scribble.points.length > 8) {
                scribble.state = "active";
            }
            return;
        }
        if (scribble.state === "active") {
            const { next, prev } = item;
            if (next && next !== prev) {
                item.prev = next;
                scribble.points.push(next);
            }
        }
    }
    tickSelfConsumingItem(item, elapsed) {
        const { scribble } = item;
        if (scribble.state === "starting") {
            const { next: next2, prev: prev2 } = item;
            if (next2 && next2 !== prev2) {
                item.prev = next2;
                scribble.points.push(next2);
            }
            if (scribble.points.length > 8) {
                scribble.state = "active";
            }
            return;
        }
        if (item.delayRemaining > 0) {
            item.delayRemaining = Math.max(0, item.delayRemaining - elapsed);
        }
        item.timeoutMs += elapsed;
        if (item.timeoutMs >= 16) {
            item.timeoutMs = 0;
        }
        const { delayRemaining, timeoutMs, prev, next } = item;
        switch(scribble.state){
            case "active":
                {
                    if (next && next !== prev) {
                        item.prev = next;
                        scribble.points.push(next);
                        if (delayRemaining === 0 && scribble.points.length > 8) {
                            scribble.points.shift();
                        }
                    } else {
                        if (timeoutMs === 0) {
                            if (scribble.points.length > 1) {
                                scribble.points.shift();
                            } else {
                                item.delayRemaining = scribble.delay;
                            }
                        }
                    }
                    break;
                }
            case "stopping":
                {
                    if (delayRemaining === 0 && timeoutMs === 0) {
                        if (scribble.points.length <= 1) {
                            scribble.points.length = 0;
                            return;
                        }
                        if (scribble.shrink) {
                            scribble.size = Math.max(1, scribble.size * (1 - scribble.shrink));
                        }
                        scribble.points.shift();
                    }
                    break;
                }
            case "paused":
                {
                    break;
                }
        }
    }
    tickGroupedFade(session, elapsed) {
        session.fadeElapsed += elapsed;
        let remainingPoints = 0;
        for (const item of session.items){
            remainingPoints += item.scribble.points.length;
        }
        if (remainingPoints === 0) return;
        if (session.fadeElapsed >= session.options.fadeDurationMs) {
            for (const item of session.items){
                item.scribble.points.length = 0;
            }
            return;
        }
        const progress = session.fadeElapsed / session.options.fadeDurationMs;
        const easedProgress = session.options.fadeEasing === "ease-in" ? progress * progress : progress;
        const targetRemoved = Math.floor(easedProgress * session.totalPointsAtFadeStart);
        const actuallyRemoved = session.totalPointsAtFadeStart - remainingPoints;
        const pointsToRemove = Math.max(1, targetRemoved - actuallyRemoved);
        let removed = 0;
        let itemIndex = 0;
        while(removed < pointsToRemove && itemIndex < session.items.length){
            const item = session.items[itemIndex];
            if (item.scribble.points.length > 0) {
                item.scribble.points.shift();
                removed++;
            } else {
                itemIndex++;
            }
        }
    }
}
;
 //# sourceMappingURL=ScribbleManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/BoundsSnaps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BoundsSnaps",
    ()=>BoundsSnaps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _getVisibleGaps_dec, _getSnappableGapNodes_dec, _getSnappablePoints_dec, _getSnapPointsCache_dec, _init;
;
;
;
;
;
;
const round = (x1)=>{
    const decimalPlacesTolerance = 8;
    return Math.round(x1 * 10 ** decimalPlacesTolerance) / 10 ** decimalPlacesTolerance;
};
function findAdjacentGaps(gaps, shapeId, gapLength, direction, intersection) {
    const matches = gaps.filter((gap)=>(direction === "forward" ? gap.startNode.id === shapeId : gap.endNode.id === shapeId) && round(gap.length) === round(gapLength) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(gap.breadthIntersection[0], gap.breadthIntersection[1], intersection[0], intersection[1]));
    if (matches.length === 0) return [];
    const nextNodes = /* @__PURE__ */ new Set();
    matches.forEach((match)=>{
        const node = direction === "forward" ? match.endNode.id : match.startNode.id;
        if (!nextNodes.has(node)) {
            nextNodes.add(node);
            const foundGaps = findAdjacentGaps(gaps, node, gapLength, direction, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(match.breadthIntersection[0], match.breadthIntersection[1], intersection[0], intersection[1]));
            matches.push(...foundGaps);
        }
    });
    return matches;
}
function dedupeGapSnaps(snaps) {
    snaps.sort((a, b)=>b.gaps.length - a.gaps.length);
    for(let i = snaps.length - 1; i > 0; i--){
        const snap = snaps[i];
        for(let j = i - 1; j >= 0; j--){
            const otherSnap = snaps[j];
            if (otherSnap.direction === snap.direction && snap.gaps.every((gap)=>otherSnap.gaps.some((otherGap)=>round(gap.startEdge[0].x) === round(otherGap.startEdge[0].x) && round(gap.startEdge[0].y) === round(otherGap.startEdge[0].y) && round(gap.startEdge[1].x) === round(otherGap.startEdge[1].x) && round(gap.startEdge[1].y) === round(otherGap.startEdge[1].y)) && otherSnap.gaps.some((otherGap)=>round(gap.endEdge[0].x) === round(otherGap.endEdge[0].x) && round(gap.endEdge[0].y) === round(otherGap.endEdge[0].y) && round(gap.endEdge[1].x) === round(otherGap.endEdge[1].x) && round(gap.endEdge[1].y) === round(otherGap.endEdge[1].y)))) {
                snaps.splice(i, 1);
                break;
            }
        }
    }
}
_getSnapPointsCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSnappablePoints_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSnappableGapNodes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getVisibleGaps_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
];
class BoundsSnaps {
    constructor(manager){
        this.manager = manager;
        __runInitializers(_init, 5, this);
        __publicField(this, "editor");
        this.editor = manager.editor;
    }
    getSnapPointsCache() {
        const { editor } = this;
        return editor.store.createComputedCache("snapPoints", (shape)=>{
            const pageTransform = editor.getShapePageTransform(shape.id);
            if (!pageTransform) return void 0;
            const boundsSnapGeometry = editor.getShapeUtil(shape).getBoundsSnapGeometry(shape);
            const snapPoints = boundsSnapGeometry.points ?? editor.getShapeGeometry(shape).bounds.cornersAndCenter;
            if (!pageTransform || !snapPoints) return void 0;
            return snapPoints.map((point, i)=>{
                const { x: x1, y } = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(pageTransform, point);
                return {
                    x: x1,
                    y,
                    id: `${shape.id}:${i}`
                };
            });
        });
    }
    getSnapPoints(shapeId) {
        return this.getSnapPointsCache().get(shapeId) ?? [];
    }
    getSnappablePoints() {
        const snapPointsCache = this.getSnapPointsCache();
        const snappableShapes = this.manager.getSnappableShapes();
        const result = [];
        for (const shapeId of snappableShapes){
            const snapPoints = snapPointsCache.get(shapeId);
            if (snapPoints) {
                result.push(...snapPoints);
            }
        }
        return result;
    }
    getSnappableGapNodes() {
        return Array.from(this.manager.getSnappableShapes(), (shapeId)=>({
                id: shapeId,
                pageBounds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageBounds(shapeId))
            }));
    }
    getVisibleGaps() {
        const horizontal = [];
        const vertical = [];
        let startNode, endNode;
        const sortedShapesOnCurrentPageHorizontal = this.getSnappableGapNodes().sort((a, b)=>{
            return a.pageBounds.minX - b.pageBounds.minX;
        });
        for(let i = 0; i < sortedShapesOnCurrentPageHorizontal.length; i++){
            startNode = sortedShapesOnCurrentPageHorizontal[i];
            for(let j = i + 1; j < sortedShapesOnCurrentPageHorizontal.length; j++){
                endNode = sortedShapesOnCurrentPageHorizontal[j];
                if (// is there space between the boxes
                startNode.pageBounds.maxX < endNode.pageBounds.minX && // and they overlap in the y axis
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangesOverlap"])(startNode.pageBounds.minY, startNode.pageBounds.maxY, endNode.pageBounds.minY, endNode.pageBounds.maxY)) {
                    horizontal.push({
                        startNode,
                        endNode,
                        startEdge: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](startNode.pageBounds.maxX, startNode.pageBounds.minY),
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](startNode.pageBounds.maxX, startNode.pageBounds.maxY)
                        ],
                        endEdge: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](endNode.pageBounds.minX, endNode.pageBounds.minY),
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](endNode.pageBounds.minX, endNode.pageBounds.maxY)
                        ],
                        length: endNode.pageBounds.minX - startNode.pageBounds.maxX,
                        breadthIntersection: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(startNode.pageBounds.minY, startNode.pageBounds.maxY, endNode.pageBounds.minY, endNode.pageBounds.maxY)
                    });
                }
            }
        }
        const sortedShapesOnCurrentPageVertical = sortedShapesOnCurrentPageHorizontal.sort((a, b)=>{
            return a.pageBounds.minY - b.pageBounds.minY;
        });
        for(let i = 0; i < sortedShapesOnCurrentPageVertical.length; i++){
            startNode = sortedShapesOnCurrentPageVertical[i];
            for(let j = i + 1; j < sortedShapesOnCurrentPageVertical.length; j++){
                endNode = sortedShapesOnCurrentPageVertical[j];
                if (// is there space between the boxes
                startNode.pageBounds.maxY < endNode.pageBounds.minY && // do they overlap in the x axis
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangesOverlap"])(startNode.pageBounds.minX, startNode.pageBounds.maxX, endNode.pageBounds.minX, endNode.pageBounds.maxX)) {
                    vertical.push({
                        startNode,
                        endNode,
                        startEdge: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](startNode.pageBounds.minX, startNode.pageBounds.maxY),
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](startNode.pageBounds.maxX, startNode.pageBounds.maxY)
                        ],
                        endEdge: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](endNode.pageBounds.minX, endNode.pageBounds.minY),
                            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](endNode.pageBounds.maxX, endNode.pageBounds.minY)
                        ],
                        length: endNode.pageBounds.minY - startNode.pageBounds.maxY,
                        breadthIntersection: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(startNode.pageBounds.minX, startNode.pageBounds.maxX, endNode.pageBounds.minX, endNode.pageBounds.maxX)
                    });
                }
            }
        }
        return {
            horizontal,
            vertical
        };
    }
    snapTranslateShapes({ lockedAxis, initialSelectionPageBounds, initialSelectionSnapPoints, dragDelta }) {
        const snapThreshold = this.manager.getSnapThreshold();
        const visibleSnapPointsNotInSelection = this.getSnappablePoints();
        const selectionPageBounds = initialSelectionPageBounds.clone().translate(dragDelta);
        const selectionSnapPoints = initialSelectionSnapPoints.map(({ x: x1, y }, i)=>({
                id: "selection:" + i,
                x: x1 + dragDelta.x,
                y: y + dragDelta.y
            }));
        const otherNodeSnapPoints = visibleSnapPointsNotInSelection;
        const nearestSnapsX = [];
        const nearestSnapsY = [];
        const minOffset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](snapThreshold, snapThreshold);
        this.collectPointSnaps({
            minOffset,
            nearestSnapsX,
            nearestSnapsY,
            otherNodeSnapPoints,
            selectionSnapPoints
        });
        this.collectGapSnaps({
            selectionPageBounds,
            nearestSnapsX,
            nearestSnapsY,
            minOffset
        });
        const nudge = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](lockedAxis === "x" ? 0 : nearestSnapsX[0]?.nudge ?? 0, lockedAxis === "y" ? 0 : nearestSnapsY[0]?.nudge ?? 0);
        minOffset.x = 0;
        minOffset.y = 0;
        nearestSnapsX.length = 0;
        nearestSnapsY.length = 0;
        selectionSnapPoints.forEach((s)=>{
            s.x += nudge.x;
            s.y += nudge.y;
        });
        selectionPageBounds.translate(nudge);
        this.collectPointSnaps({
            minOffset,
            nearestSnapsX,
            nearestSnapsY,
            otherNodeSnapPoints,
            selectionSnapPoints
        });
        this.collectGapSnaps({
            selectionPageBounds,
            nearestSnapsX,
            nearestSnapsY,
            minOffset
        });
        const pointSnapsLines = this.getPointSnapLines({
            nearestSnapsX,
            nearestSnapsY
        });
        const gapSnapLines = this.getGapSnapLines({
            selectionPageBounds,
            nearestSnapsX,
            nearestSnapsY
        });
        this.manager.setIndicators([
            ...gapSnapLines,
            ...pointSnapsLines
        ]);
        return {
            nudge
        };
    }
    snapResizeShapes({ initialSelectionPageBounds, dragDelta, handle: originalHandle, isAspectRatioLocked, isResizingFromCenter }) {
        const snapThreshold = this.manager.getSnapThreshold();
        const { box: unsnappedResizedPageBounds, scaleX, scaleY } = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Resize(initialSelectionPageBounds, originalHandle, isResizingFromCenter ? dragDelta.x * 2 : dragDelta.x, isResizingFromCenter ? dragDelta.y * 2 : dragDelta.y, isAspectRatioLocked);
        let handle = originalHandle;
        if (scaleX < 0) {
            handle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flipSelectionHandleX"])(handle);
        }
        if (scaleY < 0) {
            handle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flipSelectionHandleY"])(handle);
        }
        if (isResizingFromCenter) {
            unsnappedResizedPageBounds.center = initialSelectionPageBounds.center;
        }
        const isXLocked = handle === "top" || handle === "bottom";
        const isYLocked = handle === "left" || handle === "right";
        const selectionSnapPoints = getResizeSnapPointsForHandle(handle, unsnappedResizedPageBounds);
        const otherNodeSnapPoints = this.getSnappablePoints();
        const nearestSnapsX = [];
        const nearestSnapsY = [];
        const minOffset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](snapThreshold, snapThreshold);
        this.collectPointSnaps({
            minOffset,
            nearestSnapsX,
            nearestSnapsY,
            otherNodeSnapPoints,
            selectionSnapPoints
        });
        const nudge = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](isXLocked ? 0 : nearestSnapsX[0]?.nudge ?? 0, isYLocked ? 0 : nearestSnapsY[0]?.nudge ?? 0);
        if (isAspectRatioLocked && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSelectionCorner"])(handle) && nudge.len() !== 0) {
            const primaryNudgeAxis = nearestSnapsX.length && nearestSnapsY.length ? Math.abs(nudge.x) < Math.abs(nudge.y) ? "x" : "y" : nearestSnapsX.length ? "x" : "y";
            const ratio = initialSelectionPageBounds.aspectRatio;
            if (primaryNudgeAxis === "x") {
                nearestSnapsY.length = 0;
                nudge.y = nudge.x / ratio;
                if (handle === "bottom_left" || handle === "top_right") {
                    nudge.y = -nudge.y;
                }
            } else {
                nearestSnapsX.length = 0;
                nudge.x = nudge.y * ratio;
                if (handle === "bottom_left" || handle === "top_right") {
                    nudge.x = -nudge.x;
                }
            }
        }
        const snappedDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(dragDelta, nudge);
        const { box: snappedResizedPageBounds } = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Resize(initialSelectionPageBounds, originalHandle, isResizingFromCenter ? snappedDelta.x * 2 : snappedDelta.x, isResizingFromCenter ? snappedDelta.y * 2 : snappedDelta.y, isAspectRatioLocked);
        if (isResizingFromCenter) {
            snappedResizedPageBounds.center = initialSelectionPageBounds.center;
        }
        const snappedSelectionPoints = getResizeSnapPointsForHandle("any", snappedResizedPageBounds);
        nearestSnapsX.length = 0;
        nearestSnapsY.length = 0;
        minOffset.x = 0;
        minOffset.y = 0;
        this.collectPointSnaps({
            minOffset,
            nearestSnapsX,
            nearestSnapsY,
            otherNodeSnapPoints,
            selectionSnapPoints: snappedSelectionPoints
        });
        const pointSnaps = this.getPointSnapLines({
            nearestSnapsX,
            nearestSnapsY
        });
        this.manager.setIndicators([
            ...pointSnaps
        ]);
        return {
            nudge
        };
    }
    collectPointSnaps({ selectionSnapPoints, otherNodeSnapPoints, minOffset, nearestSnapsX, nearestSnapsY }) {
        for (const thisSnapPoint of selectionSnapPoints){
            for (const otherSnapPoint of otherNodeSnapPoints){
                const offset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(thisSnapPoint, otherSnapPoint);
                const offsetX = Math.abs(offset.x);
                const offsetY = Math.abs(offset.y);
                if (round(offsetX) <= round(minOffset.x)) {
                    if (round(offsetX) < round(minOffset.x)) {
                        nearestSnapsX.length = 0;
                    }
                    nearestSnapsX.push({
                        type: "points",
                        points: {
                            thisPoint: thisSnapPoint,
                            otherPoint: otherSnapPoint
                        },
                        nudge: otherSnapPoint.x - thisSnapPoint.x
                    });
                    minOffset.x = offsetX;
                }
                if (round(offsetY) <= round(minOffset.y)) {
                    if (round(offsetY) < round(minOffset.y)) {
                        nearestSnapsY.length = 0;
                    }
                    nearestSnapsY.push({
                        type: "points",
                        points: {
                            thisPoint: thisSnapPoint,
                            otherPoint: otherSnapPoint
                        },
                        nudge: otherSnapPoint.y - thisSnapPoint.y
                    });
                    minOffset.y = offsetY;
                }
            }
        }
    }
    collectGapSnaps({ selectionPageBounds, minOffset, nearestSnapsX, nearestSnapsY }) {
        const { horizontal, vertical } = this.getVisibleGaps();
        for (const gap of horizontal){
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangesOverlap"])(gap.breadthIntersection[0], gap.breadthIntersection[1], selectionPageBounds.minY, selectionPageBounds.maxY)) {
                continue;
            }
            const gapMidX = gap.startEdge[0].x + gap.length / 2;
            const centerNudge = gapMidX - selectionPageBounds.center.x;
            const gapIsLargerThanSelection = gap.length > selectionPageBounds.width;
            if (gapIsLargerThanSelection && round(Math.abs(centerNudge)) <= round(minOffset.x)) {
                if (round(Math.abs(centerNudge)) < round(minOffset.x)) {
                    nearestSnapsX.length = 0;
                }
                minOffset.x = Math.abs(centerNudge);
                const snap = {
                    type: "gap_center",
                    gap,
                    nudge: centerNudge
                };
                const otherCenterSnap = nearestSnapsX.find(({ type })=>type === "gap_center");
                const gapBreadthsOverlap = otherCenterSnap && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(gap.breadthIntersection[0], gap.breadthIntersection[1], otherCenterSnap.gap.breadthIntersection[0], otherCenterSnap.gap.breadthIntersection[1]);
                if (otherCenterSnap && otherCenterSnap.gap.length > gap.length && gapBreadthsOverlap) {
                    nearestSnapsX[nearestSnapsX.indexOf(otherCenterSnap)] = snap;
                } else if (!otherCenterSnap || !gapBreadthsOverlap) {
                    nearestSnapsX.push(snap);
                }
            }
            const duplicationLeftX = gap.startNode.pageBounds.minX - gap.length;
            const selectionRightX = selectionPageBounds.maxX;
            const duplicationLeftNudge = duplicationLeftX - selectionRightX;
            if (round(Math.abs(duplicationLeftNudge)) <= round(minOffset.x)) {
                if (round(Math.abs(duplicationLeftNudge)) < round(minOffset.x)) {
                    nearestSnapsX.length = 0;
                }
                minOffset.x = Math.abs(duplicationLeftNudge);
                nearestSnapsX.push({
                    type: "gap_duplicate",
                    gap,
                    protrusionDirection: "left",
                    nudge: duplicationLeftNudge
                });
            }
            const duplicationRightX = gap.endNode.pageBounds.maxX + gap.length;
            const selectionLeftX = selectionPageBounds.minX;
            const duplicationRightNudge = duplicationRightX - selectionLeftX;
            if (round(Math.abs(duplicationRightNudge)) <= round(minOffset.x)) {
                if (round(Math.abs(duplicationRightNudge)) < round(minOffset.x)) {
                    nearestSnapsX.length = 0;
                }
                minOffset.x = Math.abs(duplicationRightNudge);
                nearestSnapsX.push({
                    type: "gap_duplicate",
                    gap,
                    protrusionDirection: "right",
                    nudge: duplicationRightNudge
                });
            }
        }
        for (const gap of vertical){
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangesOverlap"])(gap.breadthIntersection[0], gap.breadthIntersection[1], selectionPageBounds.minX, selectionPageBounds.maxX)) {
                continue;
            }
            const gapMidY = gap.startEdge[0].y + gap.length / 2;
            const centerNudge = gapMidY - selectionPageBounds.center.y;
            const gapIsLargerThanSelection = gap.length > selectionPageBounds.height;
            if (gapIsLargerThanSelection && round(Math.abs(centerNudge)) <= round(minOffset.y)) {
                if (round(Math.abs(centerNudge)) < round(minOffset.y)) {
                    nearestSnapsY.length = 0;
                }
                minOffset.y = Math.abs(centerNudge);
                const snap = {
                    type: "gap_center",
                    gap,
                    nudge: centerNudge
                };
                const otherCenterSnap = nearestSnapsY.find(({ type })=>type === "gap_center");
                const gapBreadthsOverlap = otherCenterSnap && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangesOverlap"])(otherCenterSnap.gap.breadthIntersection[0], otherCenterSnap.gap.breadthIntersection[1], gap.breadthIntersection[0], gap.breadthIntersection[1]);
                if (otherCenterSnap && otherCenterSnap.gap.length > gap.length && gapBreadthsOverlap) {
                    nearestSnapsY[nearestSnapsY.indexOf(otherCenterSnap)] = snap;
                } else if (!otherCenterSnap || !gapBreadthsOverlap) {
                    nearestSnapsY.push(snap);
                }
                continue;
            }
            const duplicationTopY = gap.startNode.pageBounds.minY - gap.length;
            const selectionBottomY = selectionPageBounds.maxY;
            const duplicationTopNudge = duplicationTopY - selectionBottomY;
            if (round(Math.abs(duplicationTopNudge)) <= round(minOffset.y)) {
                if (round(Math.abs(duplicationTopNudge)) < round(minOffset.y)) {
                    nearestSnapsY.length = 0;
                }
                minOffset.y = Math.abs(duplicationTopNudge);
                nearestSnapsY.push({
                    type: "gap_duplicate",
                    gap,
                    protrusionDirection: "top",
                    nudge: duplicationTopNudge
                });
            }
            const duplicationBottomY = gap.endNode.pageBounds.maxY + gap.length;
            const selectionTopY = selectionPageBounds.minY;
            const duplicationBottomNudge = duplicationBottomY - selectionTopY;
            if (round(Math.abs(duplicationBottomNudge)) <= round(minOffset.y)) {
                if (round(Math.abs(duplicationBottomNudge)) < round(minOffset.y)) {
                    nearestSnapsY.length = 0;
                }
                minOffset.y = Math.abs(duplicationBottomNudge);
                nearestSnapsY.push({
                    type: "gap_duplicate",
                    gap,
                    protrusionDirection: "bottom",
                    nudge: duplicationBottomNudge
                });
            }
        }
    }
    getPointSnapLines({ nearestSnapsX, nearestSnapsY }) {
        const snapGroupsX = {};
        const snapGroupsY = {};
        if (nearestSnapsX.length > 0) {
            for (const snap of nearestSnapsX){
                if (snap.type === "points") {
                    const key = round(snap.points.otherPoint.x);
                    if (!snapGroupsX[key]) {
                        snapGroupsX[key] = [];
                    }
                    snapGroupsX[key].push(snap.points);
                }
            }
        }
        if (nearestSnapsY.length > 0) {
            for (const snap of nearestSnapsY){
                if (snap.type === "points") {
                    const key = round(snap.points.otherPoint.y);
                    if (!snapGroupsY[key]) {
                        snapGroupsY[key] = [];
                    }
                    snapGroupsY[key].push(snap.points);
                }
            }
        }
        return Object.values(snapGroupsX).concat(Object.values(snapGroupsY)).map((snapGroup)=>({
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                type: "points",
                points: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dedupe"])(snapGroup.map((snap)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(snap.otherPoint)).concat(snapGroup.map((snap)=>__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(snap.thisPoint))), (a, b)=>a.equals(b))
            }));
    }
    getGapSnapLines({ selectionPageBounds, nearestSnapsX, nearestSnapsY }) {
        const { vertical, horizontal } = this.getVisibleGaps();
        const selectionSides = {
            top: selectionPageBounds.sides[0],
            right: selectionPageBounds.sides[1],
            // need bottom and left to be sorted asc, which .sides is not.
            bottom: [
                selectionPageBounds.corners[3],
                selectionPageBounds.corners[2]
            ],
            left: [
                selectionPageBounds.corners[0],
                selectionPageBounds.corners[3]
            ]
        };
        const result = [];
        if (nearestSnapsX.length > 0) {
            for (const snap of nearestSnapsX){
                if (snap.type === "points") continue;
                const { gap: { breadthIntersection, startEdge, startNode, endNode, length, endEdge } } = snap;
                switch(snap.type){
                    case "gap_center":
                        {
                            const newGapsLength = (length - selectionPageBounds.width) / 2;
                            const gapBreadthIntersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(breadthIntersection[0], breadthIntersection[1], selectionPageBounds.minY, selectionPageBounds.maxY);
                            result.push({
                                type: "gaps",
                                direction: "horizontal",
                                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                                gaps: [
                                    ...findAdjacentGaps(horizontal, startNode.id, newGapsLength, "backward", gapBreadthIntersection),
                                    {
                                        startEdge,
                                        endEdge: selectionSides.left
                                    },
                                    {
                                        startEdge: selectionSides.right,
                                        endEdge
                                    },
                                    ...findAdjacentGaps(horizontal, endNode.id, newGapsLength, "forward", gapBreadthIntersection)
                                ]
                            });
                            break;
                        }
                    case "gap_duplicate":
                        {
                            const gapBreadthIntersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(breadthIntersection[0], breadthIntersection[1], selectionPageBounds.minY, selectionPageBounds.maxY);
                            result.push({
                                type: "gaps",
                                direction: "horizontal",
                                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                                gaps: snap.protrusionDirection === "left" ? [
                                    {
                                        startEdge: selectionSides.right,
                                        endEdge: startEdge.map((v)=>v.clone().addXY(-startNode.pageBounds.width, 0))
                                    },
                                    {
                                        startEdge,
                                        endEdge
                                    },
                                    ...findAdjacentGaps(horizontal, endNode.id, length, "forward", gapBreadthIntersection)
                                ] : [
                                    ...findAdjacentGaps(horizontal, startNode.id, length, "backward", gapBreadthIntersection),
                                    {
                                        startEdge,
                                        endEdge
                                    },
                                    {
                                        startEdge: endEdge.map((v)=>v.clone().addXY(snap.gap.endNode.pageBounds.width, 0)),
                                        endEdge: selectionSides.left
                                    }
                                ]
                            });
                            break;
                        }
                }
            }
        }
        if (nearestSnapsY.length > 0) {
            for (const snap of nearestSnapsY){
                if (snap.type === "points") continue;
                const { gap: { breadthIntersection, startEdge, startNode, endNode, length, endEdge } } = snap;
                switch(snap.type){
                    case "gap_center":
                        {
                            const newGapsLength = (length - selectionPageBounds.height) / 2;
                            const gapBreadthIntersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(breadthIntersection[0], breadthIntersection[1], selectionPageBounds.minX, selectionPageBounds.maxX);
                            result.push({
                                type: "gaps",
                                direction: "vertical",
                                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                                gaps: [
                                    ...findAdjacentGaps(vertical, startNode.id, newGapsLength, "backward", gapBreadthIntersection),
                                    {
                                        startEdge,
                                        endEdge: selectionSides.top
                                    },
                                    {
                                        startEdge: selectionSides.bottom,
                                        endEdge
                                    },
                                    ...findAdjacentGaps(vertical, snap.gap.endNode.id, newGapsLength, "forward", gapBreadthIntersection)
                                ]
                            });
                            break;
                        }
                    case "gap_duplicate":
                        {
                            const gapBreadthIntersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rangeIntersection"])(breadthIntersection[0], breadthIntersection[1], selectionPageBounds.minX, selectionPageBounds.maxX);
                            result.push({
                                type: "gaps",
                                direction: "vertical",
                                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                                gaps: snap.protrusionDirection === "top" ? [
                                    {
                                        startEdge: selectionSides.bottom,
                                        endEdge: startEdge.map((v)=>v.clone().addXY(0, -startNode.pageBounds.height))
                                    },
                                    {
                                        startEdge,
                                        endEdge
                                    },
                                    ...findAdjacentGaps(vertical, endNode.id, length, "forward", gapBreadthIntersection)
                                ] : [
                                    ...findAdjacentGaps(vertical, startNode.id, length, "backward", gapBreadthIntersection),
                                    {
                                        startEdge,
                                        endEdge
                                    },
                                    {
                                        startEdge: endEdge.map((v)=>v.clone().addXY(0, endNode.pageBounds.height)),
                                        endEdge: selectionSides.top
                                    }
                                ]
                            });
                        }
                        break;
                }
            }
        }
        dedupeGapSnaps(result);
        return result;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "getSnapPointsCache", _getSnapPointsCache_dec, BoundsSnaps);
__decorateElement(_init, 1, "getSnappablePoints", _getSnappablePoints_dec, BoundsSnaps);
__decorateElement(_init, 1, "getSnappableGapNodes", _getSnappableGapNodes_dec, BoundsSnaps);
__decorateElement(_init, 1, "getVisibleGaps", _getVisibleGaps_dec, BoundsSnaps);
__decoratorMetadata(_init, BoundsSnaps);
function getResizeSnapPointsForHandle(handle, selectionPageBounds) {
    const { minX, maxX, minY, maxY } = selectionPageBounds;
    const result = [];
    switch(handle){
        case "top":
        case "left":
        case "top_left":
        case "any":
            result.push({
                id: "top_left",
                handle: "top_left",
                x: minX,
                y: minY
            });
    }
    switch(handle){
        case "top":
        case "right":
        case "top_right":
        case "any":
            result.push({
                id: "top_right",
                handle: "top_right",
                x: maxX,
                y: minY
            });
    }
    switch(handle){
        case "bottom":
        case "right":
        case "bottom_right":
        case "any":
            result.push({
                id: "bottom_right",
                handle: "bottom_right",
                x: maxX,
                y: maxY
            });
    }
    switch(handle){
        case "bottom":
        case "left":
        case "bottom_left":
        case "any":
            result.push({
                id: "bottom_left",
                handle: "bottom_left",
                x: minX,
                y: maxY
            });
    }
    return result;
}
;
 //# sourceMappingURL=BoundsSnaps.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/HandleSnaps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HandleSnaps",
    ()=>HandleSnaps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _getSnapGeometryCache_dec, _init;
;
;
;
const defaultGetSelfSnapOutline = ()=>null;
const defaultGetSelfSnapPoints = ()=>[];
_getSnapGeometryCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
];
class HandleSnaps {
    constructor(manager){
        this.manager = manager;
        __runInitializers(_init, 5, this);
        __publicField(this, "editor");
        this.editor = manager.editor;
    }
    getSnapGeometryCache() {
        const { editor } = this;
        return editor.store.createComputedCache("handle snap geometry", (shape)=>{
            const snapGeometry = editor.getShapeUtil(shape).getHandleSnapGeometry(shape);
            const getSelfSnapOutline = snapGeometry.getSelfSnapOutline ? snapGeometry.getSelfSnapOutline.bind(snapGeometry) : defaultGetSelfSnapOutline;
            const getSelfSnapPoints = snapGeometry.getSelfSnapPoints ? snapGeometry.getSelfSnapPoints.bind(snapGeometry) : defaultGetSelfSnapPoints;
            return {
                outline: snapGeometry.outline === void 0 ? editor.getShapeGeometry(shape) : snapGeometry.outline,
                points: snapGeometry.points ?? [],
                getSelfSnapOutline,
                getSelfSnapPoints
            };
        });
    }
    *iterateSnapPointsInPageSpace(currentShapeId, currentHandle) {
        const selfSnapPoints = this.getSnapGeometryCache().get(currentShapeId)?.getSelfSnapPoints(currentHandle);
        if (selfSnapPoints && selfSnapPoints.length) {
            const shapePageTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageTransform(currentShapeId));
            for (const point of selfSnapPoints){
                yield shapePageTransform.applyToPoint(point);
            }
        }
        for (const shapeId of this.manager.getSnappableShapes()){
            if (shapeId === currentShapeId) continue;
            const snapPoints = this.getSnapGeometryCache().get(shapeId)?.points;
            if (!snapPoints || !snapPoints.length) continue;
            const shapePageTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageTransform(shapeId));
            for (const point of snapPoints){
                yield shapePageTransform.applyToPoint(point);
            }
        }
    }
    *iterateSnapOutlines(currentShapeId, currentHandle) {
        const selfSnapOutline = this.getSnapGeometryCache().get(currentShapeId)?.getSelfSnapOutline(currentHandle);
        if (selfSnapOutline) {
            yield {
                shapeId: currentShapeId,
                outline: selfSnapOutline
            };
        }
        for (const shapeId of this.manager.getSnappableShapes()){
            if (shapeId === currentShapeId) continue;
            const snapOutline = this.getSnapGeometryCache().get(shapeId)?.outline;
            if (!snapOutline) continue;
            yield {
                shapeId,
                outline: snapOutline
            };
        }
    }
    getHandleSnapPosition({ currentShapeId, handle, handleInPageSpace }) {
        const snapThreshold = this.manager.getSnapThreshold();
        let minDistanceForSnapPoint = snapThreshold;
        let nearestSnapPoint = null;
        for (const snapPoint of this.iterateSnapPointsInPageSpace(currentShapeId, handle)){
            if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].DistMin(handleInPageSpace, snapPoint, minDistanceForSnapPoint)) {
                minDistanceForSnapPoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(handleInPageSpace, snapPoint);
                nearestSnapPoint = snapPoint;
            }
        }
        if (nearestSnapPoint) return nearestSnapPoint;
        let minDistanceForOutline = snapThreshold;
        let nearestPointOnOutline = null;
        for (const { shapeId, outline } of this.iterateSnapOutlines(currentShapeId, handle)){
            const shapePageTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageTransform(shapeId));
            const pointInShapeSpace = this.editor.getPointInShapeSpace(shapeId, handleInPageSpace);
            const nearestShapePointInShapeSpace = outline.nearestPoint(pointInShapeSpace);
            const nearestInPageSpace = shapePageTransform.applyToPoint(nearestShapePointInShapeSpace);
            if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].DistMin(handleInPageSpace, nearestInPageSpace, minDistanceForOutline)) {
                minDistanceForOutline = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist(handleInPageSpace, nearestInPageSpace);
                nearestPointOnOutline = nearestInPageSpace;
            }
        }
        if (nearestPointOnOutline) return nearestPointOnOutline;
        return null;
    }
    getHandleSnapData({ handle, currentShapeId }) {
        const snapThreshold = this.manager.getSnapThreshold();
        const currentShapeTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageTransform(currentShapeId));
        const handleInPageSpace = currentShapeTransform.applyToPoint(handle);
        let nearestXSnap = null;
        let nearestYSnap = null;
        let minOffsetX = snapThreshold;
        let minOffsetY = snapThreshold;
        for (const snapPoint of this.iterateSnapPointsInPageSpace(currentShapeId, handle)){
            const offsetX = Math.abs(handleInPageSpace.x - snapPoint.x);
            const offsetY = Math.abs(handleInPageSpace.y - snapPoint.y);
            if (offsetX < minOffsetX) {
                minOffsetX = offsetX;
                nearestXSnap = snapPoint;
            }
            if (offsetY < minOffsetY) {
                minOffsetY = offsetY;
                nearestYSnap = snapPoint;
            }
        }
        if (!nearestXSnap && !nearestYSnap) {
            return null;
        }
        const nudge = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](nearestXSnap ? nearestXSnap.x - handleInPageSpace.x : 0, nearestYSnap ? nearestYSnap.y - handleInPageSpace.y : 0);
        const snappedHandle = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(handleInPageSpace, nudge);
        const snaps = [];
        if (nearestXSnap) {
            const snappedHandleOnX = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](nearestXSnap.x, snappedHandle.y);
            snaps.push({
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                type: "points",
                points: [
                    nearestXSnap,
                    snappedHandleOnX
                ]
            });
        }
        if (nearestYSnap) {
            const snappedHandleOnY = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](snappedHandle.x, nearestYSnap.y);
            snaps.push({
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                type: "points",
                points: [
                    nearestYSnap,
                    snappedHandleOnY
                ]
            });
        }
        return {
            snaps,
            nudge
        };
    }
    snapHandle({ currentShapeId, handle }) {
        const currentShapeTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this.editor.getShapePageTransform(currentShapeId));
        const handleInPageSpace = currentShapeTransform.applyToPoint(handle);
        const snapType = handle.canSnap ? "point" : handle.snapType;
        if (snapType === "point") {
            const snapPosition = this.getHandleSnapPosition({
                currentShapeId,
                handle,
                handleInPageSpace
            });
            if (!snapPosition) {
                return null;
            }
            this.manager.setIndicators([
                {
                    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])(),
                    type: "points",
                    points: [
                        snapPosition
                    ]
                }
            ]);
            return {
                nudge: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(snapPosition, handleInPageSpace)
            };
        }
        if (snapType === "align") {
            const snapData = this.getHandleSnapData({
                handle,
                currentShapeId
            });
            if (!snapData) {
                return null;
            }
            this.manager.setIndicators(snapData.snaps);
            return {
                nudge: snapData.nudge
            };
        }
        return null;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "getSnapGeometryCache", _getSnapGeometryCache_dec, HandleSnaps);
__decoratorMetadata(_init, HandleSnaps);
;
 //# sourceMappingURL=HandleSnaps.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/SnapManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SnapManager",
    ()=>SnapManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$BoundsSnaps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/BoundsSnaps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$HandleSnaps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/HandleSnaps.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _getCurrentCommonAncestor_dec, _getSnappableShapes_dec, _getSnapThreshold_dec, _init;
;
;
;
;
_getSnapThreshold_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSnappableShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentCommonAncestor_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
];
class SnapManager {
    constructor(editor){
        this.editor = editor;
        __runInitializers(_init, 5, this);
        __publicField(this, "shapeBounds");
        __publicField(this, "handles");
        __publicField(this, "_snapIndicators", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("snapLines", void 0));
        this.shapeBounds = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$BoundsSnaps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BoundsSnaps"](this);
        this.handles = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$HandleSnaps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandleSnaps"](this);
    }
    getIndicators() {
        return this._snapIndicators.get() ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
    }
    clearIndicators() {
        if (this.getIndicators().length) {
            this._snapIndicators.set(void 0);
        }
    }
    setIndicators(indicators) {
        this._snapIndicators.set(indicators);
    }
    getSnapThreshold() {
        return this.editor.options.snapThreshold / this.editor.getZoomLevel();
    }
    getSnappableShapes() {
        const { editor } = this;
        const renderingBounds = editor.getViewportPageBounds();
        const selectedShapeIds = editor.getSelectedShapeIds();
        const snappableShapes = /* @__PURE__ */ new Set();
        const collectSnappableShapesFromParent = (parentId)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(parentId)) {
                const parent = editor.getShape(parentId);
                if (parent && editor.isShapeOfType(parent, "frame")) {
                    snappableShapes.add(parentId);
                }
            }
            const sortedChildIds = editor.getSortedChildIdsForParent(parentId);
            for (const childId of sortedChildIds){
                if (selectedShapeIds.includes(childId)) continue;
                const childShape = editor.getShape(childId);
                if (!childShape) continue;
                const util = editor.getShapeUtil(childShape);
                if (!util.canSnap(childShape)) continue;
                const pageBounds = editor.getShapePageBounds(childId);
                if (!(pageBounds && renderingBounds.includes(pageBounds))) continue;
                if (editor.isShapeOfType(childShape, "group")) {
                    collectSnappableShapesFromParent(childId);
                    continue;
                }
                snappableShapes.add(childId);
            }
        };
        collectSnappableShapesFromParent(this.getCurrentCommonAncestor() ?? editor.getCurrentPageId());
        return snappableShapes;
    }
    getCurrentCommonAncestor() {
        return this.editor.findCommonAncestor(this.editor.getSelectedShapes());
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "getSnapThreshold", _getSnapThreshold_dec, SnapManager);
__decorateElement(_init, 1, "getSnappableShapes", _getSnappableShapes_dec, SnapManager);
__decorateElement(_init, 1, "getCurrentCommonAncestor", _getCurrentCommonAncestor_dec, SnapManager);
__decoratorMetadata(_init, SnapManager);
;
 //# sourceMappingURL=SnapManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SpatialIndexManager/RBushIndex.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RBushIndex",
    ()=>RBushIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$rbush$2f$rbush$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/rbush/rbush.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
;
;
class TldrawRBush extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$rbush$2f$rbush$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] {
}
class RBushIndex {
    rBush;
    elementsInTree;
    constructor(){
        this.rBush = new TldrawRBush();
        this.elementsInTree = /* @__PURE__ */ new Map();
    }
    /**
   * Search for shapes within the given bounds.
   * Returns set of shape IDs that intersect with the bounds.
   */ search(bounds) {
        const results = this.rBush.search({
            minX: bounds.minX,
            minY: bounds.minY,
            maxX: bounds.maxX,
            maxY: bounds.maxY
        });
        return new Set(results.map((e)=>e.id));
    }
    /**
   * Insert or update a shape in the spatial index.
   * If the shape already exists, it will be removed first to prevent duplicates.
   */ upsert(id, bounds) {
        const existing = this.elementsInTree.get(id);
        if (existing) {
            this.rBush.remove(existing);
        }
        const element = {
            minX: bounds.minX,
            minY: bounds.minY,
            maxX: bounds.maxX,
            maxY: bounds.maxY,
            id
        };
        this.rBush.insert(element);
        this.elementsInTree.set(id, element);
    }
    /**
   * Remove a shape from the spatial index.
   */ remove(id) {
        const element = this.elementsInTree.get(id);
        if (element) {
            this.rBush.remove(element);
            this.elementsInTree.delete(id);
        }
    }
    /**
   * Bulk load elements into the spatial index.
   * More efficient than individual inserts for initial loading.
   */ bulkLoad(elements) {
        this.rBush.load(elements);
        for (const element of elements){
            this.elementsInTree.set(element.id, element);
        }
    }
    /**
   * Clear all elements from the spatial index.
   */ clear() {
        this.rBush.clear();
        this.elementsInTree.clear();
    }
    /**
   * Check if a shape is in the spatial index.
   */ has(id) {
        return this.elementsInTree.has(id);
    }
    /**
   * Get the number of elements in the spatial index.
   */ getSize() {
        return this.elementsInTree.size;
    }
    /**
   * Get all shape IDs currently in the spatial index.
   */ getAllShapeIds() {
        return Array.from(this.elementsInTree.keys());
    }
    /**
   * Get the bounds currently stored in the spatial index for a shape.
   * Returns undefined if the shape is not in the index.
   */ getBounds(id) {
        const element = this.elementsInTree.get(id);
        if (!element) return void 0;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](element.minX, element.minY, element.maxX - element.minX, element.maxY - element.minY);
    }
    /**
   * Dispose of the spatial index.
   * Clears all data structures to prevent memory leaks.
   */ dispose() {
        this.clear();
    }
}
;
 //# sourceMappingURL=RBushIndex.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SpatialIndexManager/SpatialIndexManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SpatialIndexManager",
    ()=>SpatialIndexManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SpatialIndexManager$2f$RBushIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SpatialIndexManager/RBushIndex.mjs [app-client] (ecmascript)");
;
;
;
;
;
class SpatialIndexManager {
    constructor(editor){
        this.editor = editor;
        this.rbush = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SpatialIndexManager$2f$RBushIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RBushIndex"]();
        this.spatialIndexComputed = this.createSpatialIndexComputed();
    }
    rbush;
    spatialIndexComputed;
    lastPageId = null;
    createSpatialIndexComputed() {
        const shapeHistory = this.editor.store.query.filterHistory("shape");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("spatialIndex", (_prevValue, lastComputedEpoch)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUninitialized"])(_prevValue)) {
                return this.buildFromScratch(lastComputedEpoch);
            }
            const shapeDiff = shapeHistory.getDiffSince(lastComputedEpoch);
            if (shapeDiff === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET_VALUE"]) {
                return this.buildFromScratch(lastComputedEpoch);
            }
            const currentPageId = this.editor.getCurrentPageId();
            if (this.lastPageId !== currentPageId) {
                return this.buildFromScratch(lastComputedEpoch);
            }
            if (shapeDiff.length === 0) {
                return lastComputedEpoch;
            }
            this.processIncrementalUpdate(shapeDiff);
            return lastComputedEpoch;
        });
    }
    buildFromScratch(epoch) {
        this.rbush.clear();
        this.lastPageId = this.editor.getCurrentPageId();
        const shapes = this.editor.getCurrentPageShapes();
        const elements = [];
        for (const shape of shapes){
            const bounds = this.editor.getShapePageBounds(shape.id);
            if (bounds) {
                elements.push({
                    minX: bounds.minX,
                    minY: bounds.minY,
                    maxX: bounds.maxX,
                    maxY: bounds.maxY,
                    id: shape.id
                });
            }
        }
        this.rbush.bulkLoad(elements);
        return epoch;
    }
    processIncrementalUpdate(shapeDiff) {
        const processedShapeIds = /* @__PURE__ */ new Set();
        for (const changes of shapeDiff){
            for (const shape of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.added)){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(shape) && this.editor.getAncestorPageId(shape) === this.lastPageId) {
                    const bounds = this.editor.getShapePageBounds(shape.id);
                    if (bounds) {
                        this.rbush.upsert(shape.id, bounds);
                    }
                    processedShapeIds.add(shape.id);
                }
            }
            for (const shape of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.removed)){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(shape)) {
                    this.rbush.remove(shape.id);
                    processedShapeIds.add(shape.id);
                }
            }
            for (const [, to] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapValues"])(changes.updated)){
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShape"])(to)) continue;
                processedShapeIds.add(to.id);
                const isOnPage = this.editor.getAncestorPageId(to) === this.lastPageId;
                if (isOnPage) {
                    const bounds = this.editor.getShapePageBounds(to.id);
                    if (bounds) {
                        this.rbush.upsert(to.id, bounds);
                    }
                } else {
                    this.rbush.remove(to.id);
                }
            }
        }
        const allShapeIds = this.rbush.getAllShapeIds();
        for (const shapeId of allShapeIds){
            if (processedShapeIds.has(shapeId)) continue;
            const currentBounds = this.editor.getShapePageBounds(shapeId);
            const indexedBounds = this.rbush.getBounds(shapeId);
            if (!this.areBoundsEqual(currentBounds, indexedBounds)) {
                if (currentBounds) {
                    this.rbush.upsert(shapeId, currentBounds);
                } else {
                    this.rbush.remove(shapeId);
                }
            }
        }
    }
    areBoundsEqual(a, b) {
        if (!a && !b) return true;
        if (!a || !b) return false;
        return a.minX === b.minX && a.minY === b.minY && a.maxX === b.maxX && a.maxY === b.maxY;
    }
    /**
   * Get shape IDs within the given bounds.
   * Optimized for viewport culling queries.
   *
   * Note: Results are unordered. If you need z-order, combine with sorted shapes:
   * ```ts
   * const candidates = editor.spatialIndex.getShapeIdsInsideBounds(bounds)
   * const sorted = editor.getCurrentPageShapesSorted().filter(s => candidates.has(s.id))
   * ```
   *
   * @param bounds - The bounds to search within
   * @returns Unordered set of shape IDs within the bounds
   *
   * @public
   */ getShapeIdsInsideBounds(bounds) {
        this.spatialIndexComputed.get();
        return this.rbush.search(bounds);
    }
    /**
   * Get shape IDs at a point (with optional margin).
   * Creates a small bounding box around the point and searches the spatial index.
   *
   * Note: Results are unordered. If you need z-order, combine with sorted shapes:
   * ```ts
   * const candidates = editor.spatialIndex.getShapeIdsAtPoint(point, margin)
   * const sorted = editor.getCurrentPageShapesSorted().filter(s => candidates.has(s.id))
   * ```
   *
   * @param point - The point to search at
   * @param margin - The margin around the point to search (default: 0)
   * @returns Unordered set of shape IDs that could potentially contain the point
   *
   * @public
   */ getShapeIdsAtPoint(point, margin = 0) {
        this.spatialIndexComputed.get();
        return this.rbush.search(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](point.x - margin, point.y - margin, margin * 2, margin * 2));
    }
    /**
   * Dispose of the spatial index manager.
   * Clears the R-tree to prevent memory leaks.
   *
   * @public
   */ dispose() {
        this.rbush.dispose();
        this.lastPageId = null;
    }
}
;
 //# sourceMappingURL=SpatialIndexManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/TextManager/TextManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TextManager",
    ()=>TextManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
;
const fixNewLines = /\r?\n|\r/g;
function normalizeTextForDom(text) {
    return text.replace(fixNewLines, "\n").split("\n").map((x)=>x || " ").join("\n");
}
const textAlignmentsForLtr = {
    start: "left",
    "start-legacy": "left",
    middle: "center",
    "middle-legacy": "center",
    end: "right",
    "end-legacy": "right"
};
const spaceCharacterRegex = /\s/;
const initialDefaultStyles = Object.freeze({
    "overflow-wrap": "break-word",
    "word-break": "auto",
    width: null,
    height: null,
    "max-width": null,
    "min-width": null
});
class TextManager {
    constructor(editor){
        this.editor = editor;
        const elm = document.createElement("div");
        elm.classList.add("tl-text");
        elm.classList.add("tl-text-measure");
        elm.setAttribute("dir", "auto");
        elm.tabIndex = -1;
        this.editor.getContainer().appendChild(elm);
        this.elm = elm;
        for (const key of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapKeys"])(initialDefaultStyles)){
            elm.style.setProperty(key, initialDefaultStyles[key]);
        }
    }
    elm;
    setElementStyles(styles) {
        const stylesToReinstate = {};
        for (const key of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapKeys"])(styles)){
            if (typeof styles[key] === "string") {
                const oldValue = this.elm.style.getPropertyValue(key);
                if (oldValue === styles[key]) continue;
                stylesToReinstate[key] = oldValue;
                this.elm.style.setProperty(key, styles[key]);
            }
        }
        return ()=>{
            for (const key of (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objectMapKeys"])(stylesToReinstate)){
                this.elm.style.setProperty(key, stylesToReinstate[key]);
            }
        };
    }
    dispose() {
        return this.elm.remove();
    }
    measureText(textToMeasure, opts) {
        const div = document.createElement("div");
        div.textContent = normalizeTextForDom(textToMeasure);
        return this.measureHtml(div.innerHTML, opts);
    }
    measureHtml(html, opts) {
        const { elm } = this;
        const newStyles = {
            "font-family": opts.fontFamily,
            "font-style": opts.fontStyle,
            "font-weight": opts.fontWeight,
            "font-size": opts.fontSize + "px",
            "line-height": opts.lineHeight.toString(),
            padding: opts.padding,
            "max-width": opts.maxWidth ? opts.maxWidth + "px" : void 0,
            "min-width": opts.minWidth ? opts.minWidth + "px" : void 0,
            "overflow-wrap": opts.disableOverflowWrapBreaking ? "normal" : void 0,
            ...opts.otherStyles
        };
        const restoreStyles = this.setElementStyles(newStyles);
        try {
            elm.innerHTML = html;
            const scrollWidth = opts.measureScrollWidth ? elm.scrollWidth : 0;
            const rect = elm.getBoundingClientRect();
            return {
                x: 0,
                y: 0,
                w: rect.width,
                h: rect.height,
                scrollWidth
            };
        } finally{
            restoreStyles();
        }
    }
    /**
   * Given an html element, measure the position of each span of unbroken
   * word/white-space characters within any text nodes it contains.
   */ measureElementTextNodeSpans(element, { shouldTruncateToFirstLine = false } = {}) {
        const spans = [];
        const elmBounds = element.getBoundingClientRect();
        const offsetX = -elmBounds.left;
        const offsetY = -elmBounds.top;
        const range = new Range();
        const textNode = element.childNodes[0];
        let idx = 0;
        let currentSpan = null;
        let prevCharWasSpaceCharacter = null;
        let prevCharTop = 0;
        let prevCharLeftForRTLTest = 0;
        let didTruncate = false;
        for (const childNode of element.childNodes){
            if (childNode.nodeType !== Node.TEXT_NODE) continue;
            for (const char of childNode.textContent ?? ""){
                range.setStart(textNode, idx);
                range.setEnd(textNode, idx + char.length);
                const rects = range.getClientRects();
                const rect = rects[rects.length - 1];
                const top = rect.top + offsetY;
                const left = rect.left + offsetX;
                const right = rect.right + offsetX;
                const isRTL = left < prevCharLeftForRTLTest;
                const isSpaceCharacter = spaceCharacterRegex.test(char);
                if (// If we're at a word boundary...
                isSpaceCharacter !== prevCharWasSpaceCharacter || // ...or we're on a different line...
                top !== prevCharTop || // ...or we're at the start of the text and haven't created a span yet...
                !currentSpan) {
                    if (currentSpan) {
                        if (shouldTruncateToFirstLine && top !== prevCharTop) {
                            didTruncate = true;
                            break;
                        }
                        spans.push(currentSpan);
                    }
                    currentSpan = {
                        box: {
                            x: left,
                            y: top,
                            w: rect.width,
                            h: rect.height
                        },
                        text: char
                    };
                    prevCharLeftForRTLTest = left;
                } else {
                    if (isRTL) {
                        currentSpan.box.x = left;
                    }
                    currentSpan.box.w = isRTL ? currentSpan.box.w + rect.width : right - currentSpan.box.x;
                    currentSpan.text += char;
                }
                if (char === "\n") {
                    prevCharLeftForRTLTest = 0;
                }
                prevCharWasSpaceCharacter = isSpaceCharacter;
                prevCharTop = top;
                idx += char.length;
            }
        }
        if (currentSpan) {
            spans.push(currentSpan);
        }
        return {
            spans,
            didTruncate
        };
    }
    /**
   * Measure text into individual spans. Spans are created by rendering the
   * text, then dividing it up according to line breaks and word boundaries.
   *
   * It works by having the browser render the text, then measuring the
   * position of each character. You can use this to replicate the text-layout
   * algorithm of the current browser in e.g. an SVG export.
   */ measureTextSpans(textToMeasure, opts) {
        if (textToMeasure === "") return [];
        const { elm } = this;
        const shouldTruncateToFirstLine = opts.overflow === "truncate-ellipsis" || opts.overflow === "truncate-clip";
        const elementWidth = Math.ceil(opts.width - opts.padding * 2);
        const newStyles = {
            "font-family": opts.fontFamily,
            "font-style": opts.fontStyle,
            "font-weight": opts.fontWeight,
            "font-size": opts.fontSize + "px",
            "line-height": opts.lineHeight.toString(),
            width: `${elementWidth}px`,
            height: "min-content",
            "text-align": textAlignmentsForLtr[opts.textAlign],
            "overflow-wrap": shouldTruncateToFirstLine ? "anywhere" : void 0,
            "word-break": shouldTruncateToFirstLine ? "break-all" : void 0,
            ...opts.otherStyles
        };
        const restoreStyles = this.setElementStyles(newStyles);
        try {
            const normalizedText = normalizeTextForDom(textToMeasure);
            elm.textContent = normalizedText;
            const { spans, didTruncate } = this.measureElementTextNodeSpans(elm, {
                shouldTruncateToFirstLine
            });
            if (opts.overflow === "truncate-ellipsis" && didTruncate) {
                elm.textContent = "\u2026";
                const ellipsisWidth = Math.ceil(this.measureElementTextNodeSpans(elm).spans[0].box.w);
                elm.style.setProperty("width", `${elementWidth - ellipsisWidth}px`);
                elm.textContent = normalizedText;
                const truncatedSpans = this.measureElementTextNodeSpans(elm, {
                    shouldTruncateToFirstLine: true
                }).spans;
                const lastSpan = truncatedSpans[truncatedSpans.length - 1];
                truncatedSpans.push({
                    text: "\u2026",
                    box: {
                        x: Math.min(lastSpan.box.x + lastSpan.box.w, opts.width - opts.padding - ellipsisWidth),
                        y: lastSpan.box.y,
                        w: ellipsisWidth,
                        h: lastSpan.box.h
                    }
                });
                return truncatedSpans;
            }
            return spans;
        } finally{
            restoreStyles();
        }
    }
}
;
 //# sourceMappingURL=TextManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/TickManager/TickManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TickManager",
    ()=>TickManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/throttle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _dispose_dec, _tick_dec, _init;
;
const throttleToNextFrame = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$throttle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throttleToNextFrame"];
_tick_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], _dispose_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
];
class TickManager {
    constructor(editor){
        this.editor = editor;
        __runInitializers(_init, 5, this);
        __publicField(this, "cancelRaf");
        __publicField(this, "isPaused", true);
        __publicField(this, "now", 0);
        this.editor.disposables.add(this.dispose);
        this.start();
    }
    start() {
        this.isPaused = false;
        this.cancelRaf?.();
        this.cancelRaf = throttleToNextFrame(this.tick);
        this.now = Date.now();
    }
    tick() {
        if (this.isPaused) {
            return;
        }
        const now = Date.now();
        const elapsed = now - this.now;
        this.now = now;
        this.editor.inputs.updatePointerVelocity(elapsed);
        this.editor.emit("frame", elapsed);
        this.editor.emit("tick", elapsed);
        this.cancelRaf = throttleToNextFrame(this.tick);
    }
    dispose() {
        this.isPaused = true;
        this.cancelRaf?.();
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "tick", _tick_dec, TickManager);
__decorateElement(_init, 1, "dispose", _dispose_dec, TickManager);
__decoratorMetadata(_init, TickManager);
;
 //# sourceMappingURL=TickManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/UserPreferencesManager/UserPreferencesManager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UserPreferencesManager",
    ()=>UserPreferencesManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLUserPreferences.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var _getIsZoomDirectionInverted_dec, _getInputMode_dec, _getEnhancedA11yMode_dec, _getIsPasteAtCursorMode_dec, _getIsDynamicResizeMode_dec, _getIsWrapMode_dec, _getIsSnapMode_dec, _getColor_dec, _getLocale_dec, _getName_dec, _getId_dec, _getAreKeyboardShortcutsEnabled_dec, _getAnimationSpeed_dec, _getEdgeScrollSpeed_dec, _getIsDarkMode_dec, _getUserPreferences_dec, _init;
;
;
_getUserPreferences_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsDarkMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getEdgeScrollSpeed_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getAnimationSpeed_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getAreKeyboardShortcutsEnabled_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getName_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getLocale_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getColor_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsSnapMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsWrapMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsDynamicResizeMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsPasteAtCursorMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getEnhancedA11yMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getInputMode_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsZoomDirectionInverted_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
];
class UserPreferencesManager {
    constructor(user, inferDarkMode){
        this.user = user;
        this.inferDarkMode = inferDarkMode;
        __runInitializers(_init, 5, this);
        __publicField(this, "systemColorScheme", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("systemColorScheme", "light"));
        __publicField(this, "disposables", /* @__PURE__ */ new Set());
        if (typeof window === "undefined" || !window.matchMedia) return;
        const darkModeMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
        if (darkModeMediaQuery?.matches) {
            this.systemColorScheme.set("dark");
        }
        const handleChange = (e)=>{
            if (e.matches) {
                this.systemColorScheme.set("dark");
            } else {
                this.systemColorScheme.set("light");
            }
        };
        darkModeMediaQuery?.addEventListener("change", handleChange);
        this.disposables.add(()=>darkModeMediaQuery?.removeEventListener("change", handleChange));
    }
    dispose() {
        this.disposables.forEach((d)=>d());
    }
    updateUserPreferences(userPreferences) {
        this.user.setUserPreferences({
            ...this.user.userPreferences.get(),
            ...userPreferences
        });
    }
    getUserPreferences() {
        return {
            id: this.getId(),
            name: this.getName(),
            locale: this.getLocale(),
            color: this.getColor(),
            animationSpeed: this.getAnimationSpeed(),
            areKeyboardShortcutsEnabled: this.getAreKeyboardShortcutsEnabled(),
            isSnapMode: this.getIsSnapMode(),
            colorScheme: this.user.userPreferences.get().colorScheme,
            isDarkMode: this.getIsDarkMode(),
            isWrapMode: this.getIsWrapMode(),
            isDynamicResizeMode: this.getIsDynamicResizeMode(),
            enhancedA11yMode: this.getEnhancedA11yMode(),
            inputMode: this.getInputMode(),
            isZoomDirectionInverted: this.getIsZoomDirectionInverted()
        };
    }
    getIsDarkMode() {
        switch(this.user.userPreferences.get().colorScheme){
            case "dark":
                return true;
            case "light":
                return false;
            case "system":
                return this.systemColorScheme.get() === "dark";
            default:
                return this.inferDarkMode ? this.systemColorScheme.get() === "dark" : false;
        }
    }
    getEdgeScrollSpeed() {
        return this.user.userPreferences.get().edgeScrollSpeed ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].edgeScrollSpeed;
    }
    getAnimationSpeed() {
        return this.user.userPreferences.get().animationSpeed ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].animationSpeed;
    }
    getAreKeyboardShortcutsEnabled() {
        return this.user.userPreferences.get().areKeyboardShortcutsEnabled ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].areKeyboardShortcutsEnabled;
    }
    getId() {
        return this.user.userPreferences.get().id;
    }
    getName() {
        return this.user.userPreferences.get().name?.trim() ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].name;
    }
    getLocale() {
        return this.user.userPreferences.get().locale ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].locale;
    }
    getColor() {
        return this.user.userPreferences.get().color ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].color;
    }
    getIsSnapMode() {
        return this.user.userPreferences.get().isSnapMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].isSnapMode;
    }
    getIsWrapMode() {
        return this.user.userPreferences.get().isWrapMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].isWrapMode;
    }
    getIsDynamicResizeMode() {
        return this.user.userPreferences.get().isDynamicSizeMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].isDynamicSizeMode;
    }
    getIsPasteAtCursorMode() {
        return this.user.userPreferences.get().isPasteAtCursorMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].isPasteAtCursorMode;
    }
    getEnhancedA11yMode() {
        return this.user.userPreferences.get().enhancedA11yMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].enhancedA11yMode;
    }
    getInputMode() {
        return this.user.userPreferences.get().inputMode ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].inputMode;
    }
    getIsZoomDirectionInverted() {
        return this.user.userPreferences.get().isZoomDirectionInverted ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLUserPreferences$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultUserPreferences"].isZoomDirectionInverted;
    }
}
_init = __decoratorStart(null);
__decorateElement(_init, 1, "getUserPreferences", _getUserPreferences_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsDarkMode", _getIsDarkMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getEdgeScrollSpeed", _getEdgeScrollSpeed_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getAnimationSpeed", _getAnimationSpeed_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getAreKeyboardShortcutsEnabled", _getAreKeyboardShortcutsEnabled_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getId", _getId_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getName", _getName_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getLocale", _getLocale_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getColor", _getColor_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsSnapMode", _getIsSnapMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsWrapMode", _getIsWrapMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsDynamicResizeMode", _getIsDynamicResizeMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsPasteAtCursorMode", _getIsPasteAtCursorMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getEnhancedA11yMode", _getEnhancedA11yMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getInputMode", _getInputMode_dec, UserPreferencesManager);
__decorateElement(_init, 1, "getIsZoomDirectionInverted", _getIsZoomDirectionInverted_dec, UserPreferencesManager);
__decoratorMetadata(_init, UserPreferencesManager);
;
 //# sourceMappingURL=UserPreferencesManager.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/types/event-types.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EVENT_NAME_MAP",
    ()=>EVENT_NAME_MAP
]);
const EVENT_NAME_MAP = {
    wheel: "onWheel",
    pointer_down: "onPointerDown",
    pointer_move: "onPointerMove",
    long_press: "onLongPress",
    pointer_up: "onPointerUp",
    right_click: "onRightClick",
    middle_click: "onMiddleClick",
    key_down: "onKeyDown",
    key_up: "onKeyUp",
    key_repeat: "onKeyRepeat",
    cancel: "onCancel",
    complete: "onComplete",
    interrupt: "onInterrupt",
    double_click: "onDoubleClick",
    triple_click: "onTripleClick",
    quadruple_click: "onQuadrupleClick",
    tick: "onTick"
};
;
 //# sourceMappingURL=event-types.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StateNode",
    ()=>StateNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/PerformanceTracker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/debug-flags.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$types$2f$event$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/types/event-types.mjs [app-client] (ecmascript)");
;
;
;
;
const STATE_NODES_TO_MEASURE = [
    "brushing",
    "cropping",
    "dragging",
    "dragging_handle",
    "drawing",
    "erasing",
    "lasering",
    "resizing",
    "rotating",
    "scribble_brushing",
    "translating"
];
class StateNode {
    constructor(editor, parent){
        this.editor = editor;
        const { id, children, initial, isLockable, useCoalescedEvents } = this.constructor;
        this.id = id;
        this._isActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("toolIsActive" + this.id, false);
        this._current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("toolState" + this.id, void 0);
        this._path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("toolPath" + this.id, ()=>{
            const current = this.getCurrent();
            return this.id + (current ? `.${current.getPath()}` : "");
        });
        this.parent = parent ?? {};
        if (parent) {
            if (children && initial) {
                this.type = "branch";
                this.initial = initial;
                this.children = Object.fromEntries(children().map((Ctor)=>[
                        Ctor.id,
                        new Ctor(this.editor, this)
                    ]));
                this._current.set(this.children[this.initial]);
            } else {
                this.type = "leaf";
            }
        } else {
            this.type = "root";
            if (children && initial) {
                this.initial = initial;
                this.children = Object.fromEntries(children().map((Ctor)=>[
                        Ctor.id,
                        new Ctor(this.editor, this)
                    ]));
                this._current.set(this.children[this.initial]);
            }
        }
        this.isLockable = isLockable;
        this.useCoalescedEvents = useCoalescedEvents;
        this.performanceTracker = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PerformanceTracker"]();
    }
    performanceTracker;
    static id;
    static initial;
    static children;
    static isLockable = true;
    static useCoalescedEvents = false;
    id;
    type;
    shapeType;
    initial;
    children;
    isLockable;
    useCoalescedEvents;
    parent;
    /**
   * This node's path of active state nodes
   *
   * @public
   */ getPath() {
        return this._path.get();
    }
    _path;
    /**
   * This node's current active child node, if any.
   *
   * @public
   */ getCurrent() {
        return this._current.get();
    }
    _current;
    /**
   * Whether this node is active.
   *
   * @public
   */ getIsActive() {
        return this._isActive.get();
    }
    _isActive;
    /**
   * Transition to a new active child state node.
   *
   * @example
   * ```ts
   * parentState.transition('childStateA')
   * parentState.transition('childStateB', { myData: 4 })
   *```
   *
   * @param id - The id of the child state node to transition to.
   * @param info - Any data to pass to the `onEnter` and `onExit` handlers.
   *
   * @public
   */ transition(id, info = {}) {
        const path = id.split(".");
        let currState = this;
        for(let i = 0; i < path.length; i++){
            const id2 = path[i];
            const prevChildState = currState.getCurrent();
            const nextChildState = currState.children?.[id2];
            if (!nextChildState) {
                throw Error(`${currState.id} - no child state exists with the id ${id2}.`);
            }
            if (prevChildState?.id !== nextChildState.id) {
                prevChildState?.exit(info, id2);
                currState._current.set(nextChildState);
                nextChildState.enter(info, prevChildState?.id || "initial");
                if (!nextChildState.getIsActive()) break;
            }
            currState = nextChildState;
        }
        return this;
    }
    handleEvent(info) {
        const cbName = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$types$2f$event$2d$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVENT_NAME_MAP"][info.name];
        const currentActiveChild = this._current.__unsafe__getWithoutCapture();
        this[cbName]?.(info);
        if (this._isActive.__unsafe__getWithoutCapture() && currentActiveChild && currentActiveChild === this._current.__unsafe__getWithoutCapture()) {
            currentActiveChild.handleEvent(info);
        }
    }
    // todo: move this logic into transition
    enter(info, from) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugFlags"].measurePerformance.get() && STATE_NODES_TO_MEASURE.includes(this.id)) {
            this.performanceTracker.start(this.id);
        }
        this._isActive.set(true);
        this.onEnter?.(info, from);
        if (this.children && this.initial && this.getIsActive()) {
            const initial = this.children[this.initial];
            this._current.set(initial);
            initial.enter(info, from);
        }
    }
    // todo: move this logic into transition
    exit(info, to) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugFlags"].measurePerformance.get() && this.performanceTracker.isStarted()) {
            this.performanceTracker.stop();
        }
        this._isActive.set(false);
        this.onExit?.(info, to);
        if (!this.getIsActive()) {
            this.getCurrent()?.exit(info, to);
        }
    }
    /**
   * This is a hack / escape hatch that will tell the editor to
   * report a different state as active (in `getCurrentToolId()`) when
   * this state is active. This is usually used when a tool transitions
   * to a child of a different state for a certain interaction and then
   * returns to the original tool when that interaction completes; and
   * where we would want to show the original tool as active in the UI.
   *
   * @public
   */ _currentToolIdMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("curent tool id mask", void 0);
    getCurrentToolIdMask() {
        return this._currentToolIdMask.get();
    }
    setCurrentToolIdMask(id) {
        this._currentToolIdMask.set(id);
    }
    /**
   * Add a child node to this state node.
   *
   * @public
   */ addChild(childConstructor) {
        if (this.type === "leaf") {
            throw new Error("StateNode.addChild: cannot add child to a leaf node");
        }
        if (!this.children) {
            this.children = {};
        }
        const child = new childConstructor(this.editor, this);
        if (this.children[child.id]) {
            throw new Error(`StateNode.addChild: a child with id '${child.id}' already exists`);
        }
        this.children[child.id] = child;
        return this;
    }
}
;
 //# sourceMappingURL=StateNode.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/RootState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RootState",
    ()=>RootState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class RootState extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "root";
    static initial = "";
    static children() {
        return [];
    }
}
;
 //# sourceMappingURL=RootState.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/Editor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Editor",
    ()=>Editor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Atom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/Computed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/EffectScheduler.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/transactions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/state/dist-esm/lib/capture.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/store/dist-esm/lib/RecordsDiff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLCamera.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPageState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLDocument.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLInstance.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLBinding.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/file.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/PerformanceTracker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/reordering.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/error.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/bind.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/array.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$debounce$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/debounce.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/network.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/object.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$sort$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/sort.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/id.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$node_modules$2f$eventemitter3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/node_modules/eventemitter3/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLEditorSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/TLEditorSnapshot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/createTLUser.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultBindings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultBindings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/config/defaultShapes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$exportToSvg$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/exportToSvg.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$getSvgAsImage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/exports/getSvgAsImage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/menus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$time$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/globals/time.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$options$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/options.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Mat.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/easings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Group2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/intersect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$SharedStylesMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/SharedStylesMap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$areShapesContentEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/areShapesContentEqual.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/assets.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/debug-flags.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$deepLinks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/deepLinks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$getIncrementedName$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/getIncrementedName.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reorderShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/reorderShapes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/utils/rotation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$bindingsIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/bindingsIndex.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$notVisibleShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/notVisibleShapes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$parentsToChildren$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/parentsToChildren.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$shapeIdsInCurrentPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/derivations/shapeIdsInCurrentPage.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$ClickManager$2f$ClickManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/ClickManager/ClickManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$EdgeScrollManager$2f$EdgeScrollManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/EdgeScrollManager/EdgeScrollManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$FocusManager$2f$FocusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/FocusManager/FocusManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$FontManager$2f$FontManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/FontManager/FontManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$HistoryManager$2f$HistoryManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/HistoryManager/HistoryManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$InputsManager$2f$InputsManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/InputsManager/InputsManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$ScribbleManager$2f$ScribbleManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/ScribbleManager/ScribbleManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$SnapManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SnapManager/SnapManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SpatialIndexManager$2f$SpatialIndexManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/SpatialIndexManager/SpatialIndexManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$TextManager$2f$TextManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/TextManager/TextManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$TickManager$2f$TickManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/TickManager/TickManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$UserPreferencesManager$2f$UserPreferencesManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/managers/UserPreferencesManager/UserPreferencesManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$RootState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/RootState.mjs [app-client] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol)=>(symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg)=>{
    throw TypeError(msg);
};
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
var __decoratorStart = (base)=>[
        ,
        ,
        ,
        __create(base?.[__knownSymbol("metadata")] ?? null)
    ];
var __decoratorStrings = [
    "class",
    "method",
    "getter",
    "setter",
    "accessor",
    "field",
    "value",
    "get",
    "set"
];
var __expectFn = (fn)=>fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns)=>({
        kind: __decoratorStrings[kind],
        name,
        metadata,
        addInitializer: (fn)=>done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null))
    });
var __decoratorMetadata = (array, target)=>__defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value)=>{
    for(var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++)flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
    return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra)=>{
    var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
    var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
    var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
    var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : {
        get [name] () {
            return __privateGet(this, extra);
        },
        set [name] (x){
            return __privateSet(this, extra, x);
        }
    }, name));
    k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
    for(var i = decorators.length - 1; i >= 0; i--){
        ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
        if (k) {
            ctx.static = s, ctx.private = p, access = ctx.access = {
                has: p ? (x1)=>__privateIn(target, x1) : (x1)=>name in x1
            };
            if (k ^ 3) access.get = p ? (x1)=>(k ^ 1 ? __privateGet : __privateMethod)(x1, target, k ^ 4 ? extra : desc.get) : (x1)=>x1[name];
            if (k > 2) access.set = p ? (x1, y)=>__privateSet(x1, target, y, k ^ 4 ? extra : desc.set) : (x1, y)=>x1[name] = y;
        }
        it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : {
            get: desc.get,
            set: desc.set
        } : target, ctx), done._ = 1;
        if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
        else if (typeof it !== "object" || it === null) __typeError("Object expected");
        else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
    }
    return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg)=>member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj)=>Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter)=>(__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter)=>(__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method)=>(__accessCheck(obj, member, "access private method"), method);
var __setMetaKeyTimeout_dec, __setCtrlKeyTimeout_dec, __setAltKeyTimeout_dec, __setShiftKeyTimeout_dec, _getIsReadonly_dec, _getIsFocused_dec, _getSharedOpacity_dec, _getSharedStyles_dec, __getSelectionSharedStyles_dec, __getBindingsIndexCache_dec, _getCurrentPageRenderingShapesSorted_dec, _getCurrentPageShapesSorted_dec, _getCurrentPageShapes_dec, _getCurrentPageBounds_dec, _getCulledShapes_dec, _getNotVisibleShapes_dec, __getShapeMaskedPageBoundsCache_dec, __getShapeMaskCache_dec, __getShapeClipPathCache_dec, __getShapePageBoundsCache_dec, __getShapePageTransformCache_dec, __getShapeHandlesCache_dec, __getAllAssetsQuery_dec, _getCurrentPageShapeIdsSorted_dec, _getCurrentPageId_dec, _getPages_dec, __getAllPagesQuery_dec, _getRenderingShapes_dec, _getCollaboratorsOnCurrentPage_dec, _getCollaborators_dec, __getCollaboratorsQuery_dec, _getViewportPageBounds_dec, _getViewportScreenCenter_dec, _getViewportScreenBounds_dec, _getEfficientZoomLevel_dec, __getAboveDebouncedZoomThreshold_dec, _getDebouncedZoomLevel_dec, _getZoomLevel_dec, _getCameraForFollowing_dec, _getViewportPageBoundsForFollowing_dec, _getCamera_dec, __unsafe_getCameraId_dec, _getErasingShapes_dec, _getErasingShapeIds_dec, _getHintingShape_dec, _getHintingShapeIds_dec, _getHoveredShape_dec, _getHoveredShapeId_dec, _getRichTextEditor_dec, _getEditingShape_dec, _getEditingShapeId_dec, _getFocusedGroup_dec, _getFocusedGroupId_dec, _getSelectionRotatedScreenBounds_dec, _getSelectionRotatedPageBounds_dec, _getSelectionRotation_dec, _getSelectionPageBounds_dec, _getOnlySelectedShape_dec, _getOnlySelectedShapeId_dec, _getCurrentPageShapesInReadingOrder_dec, _getSelectedShapes_dec, _getSelectedShapeIds_dec, __getCurrentPageStateId_dec, _getCurrentPageState_dec, __getPageStatesQuery_dec, _getPageStates_dec, _getInstanceState_dec, _getDocumentSettings_dec, _getCurrentToolId_dec, _getCurrentTool_dec, _getPath_dec, _canRedo_dec, _canUndo_dec, _getIsShapeHiddenCache_dec, _a, _init;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class Editor extends (_a = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$node_modules$2f$eventemitter3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], _getIsShapeHiddenCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _canUndo_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _canRedo_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getPath_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentTool_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentToolId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getDocumentSettings_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getInstanceState_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getPageStates_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getPageStatesQuery_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageState_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getCurrentPageStateId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectedShapeIds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectedShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageShapesInReadingOrder_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getOnlySelectedShapeId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getOnlySelectedShape_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectionPageBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectionRotation_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectionRotatedPageBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSelectionRotatedScreenBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getFocusedGroupId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getFocusedGroup_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getEditingShapeId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getEditingShape_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getRichTextEditor_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getHoveredShapeId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getHoveredShape_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getHintingShapeIds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getHintingShape_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getErasingShapeIds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getErasingShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __unsafe_getCameraId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCamera_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getViewportPageBoundsForFollowing_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCameraForFollowing_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getZoomLevel_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getDebouncedZoomLevel_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getAboveDebouncedZoomThreshold_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getEfficientZoomLevel_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getViewportScreenBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getViewportScreenCenter_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getViewportPageBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getCollaboratorsQuery_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCollaborators_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCollaboratorsOnCurrentPage_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getRenderingShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getAllPagesQuery_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getPages_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageId_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageShapeIdsSorted_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getAllAssetsQuery_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapeHandlesCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapePageTransformCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapePageBoundsCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapeClipPathCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapeMaskCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getShapeMaskedPageBoundsCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getNotVisibleShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCulledShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageBounds_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageShapes_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageShapesSorted_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getCurrentPageRenderingShapesSorted_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getBindingsIndexCache_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __getSelectionSharedStyles_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getSharedStyles_dec = [
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])({
        isEqual: (a, b)=>a.equals(b)
    })
], _getSharedOpacity_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsFocused_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], _getIsReadonly_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"]
], __setShiftKeyTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], __setAltKeyTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], __setCtrlKeyTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], __setMetaKeyTimeout_dec = [
    __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$bind$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bind"]
], _a) {
    constructor({ store, user, shapeUtils, bindingUtils, tools, getContainer, // needs to be here for backwards compatibility with TldrawEditor
    // eslint-disable-next-line @typescript-eslint/no-deprecated
    cameraOptions, initialState, autoFocus, inferDarkMode, options: _options, // needs to be here for backwards compatibility with TldrawEditor
    // eslint-disable-next-line @typescript-eslint/no-deprecated
    textOptions: _textOptions, getShapeVisibility, fontAssetUrls }){
        super();
        __runInitializers(_init, 5, this);
        __publicField(this, "id", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])());
        __publicField(this, "_getShapeVisibility");
        __publicField(this, "options");
        __publicField(this, "contextId", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])());
        /**
     * The editor's store
     *
     * @public
     */ __publicField(this, "store");
        /**
     * The root state of the statechart.
     *
     * @public
     */ __publicField(this, "root");
        /**
     * A set of functions to call when the editor is disposed.
     *
     * @public
     */ __publicField(this, "disposables", /* @__PURE__ */ new Set());
        /**
     * Whether the editor is disposed.
     *
     * @public
     */ __publicField(this, "isDisposed", false);
        /**
     * A manager for the editor's tick events.
     *
     * @internal */ __publicField(this, "_tickManager");
        /**
     * A manager for the editor's input state.
     *
     * @public
     */ __publicField(this, "inputs");
        /**
     * A manager for the editor's snapping feature.
     *
     * @public
     */ __publicField(this, "snaps");
        __publicField(this, "_spatialIndex");
        /**
     * A manager for the any asynchronous events and making sure they're
     * cleaned up upon disposal.
     *
     * @public
     */ __publicField(this, "timers", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$time$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tltime"].forContext(this.contextId));
        /**
     * A manager for the user and their preferences.
     *
     * @public
     */ __publicField(this, "user");
        /**
     * A helper for measuring text.
     *
     * @public
     */ __publicField(this, "textMeasure");
        /**
     * A utility for managing the set of fonts that should be rendered in the document.
     *
     * @public
     */ __publicField(this, "fonts");
        /**
     * A manager for the editor's scribbles.
     *
     * @public
     */ __publicField(this, "scribbles");
        /**
     * A manager for side effects and correct state enforcement. See {@link @tldraw/store#StoreSideEffects} for details.
     *
     * @public
     */ __publicField(this, "sideEffects");
        /**
     * A manager for moving the camera when the mouse is at the edge of the screen.
     *
     * @public
     */ __publicField(this, "edgeScrollManager");
        /**
     * A manager for ensuring correct focus. See FocusManager for details.
     *
     * @internal
     */ __publicField(this, "focusManager");
        /**
     * The current HTML element containing the editor.
     *
     * @example
     * ```ts
     * const container = editor.getContainer()
     * ```
     *
     * @public
     */ __publicField(this, "getContainer");
        /* ------------------- Shape Utils ------------------ */ /**
     * A map of shape utility classes (TLShapeUtils) by shape type.
     *
     * @public
     */ __publicField(this, "shapeUtils");
        __publicField(this, "styleProps");
        /* ------------------- Binding Utils ------------------ */ /**
     * A map of shape utility classes (TLShapeUtils) by shape type.
     *
     * @public
     */ __publicField(this, "bindingUtils");
        /* --------------------- History -------------------- */ /**
     * A manager for the editor's history.
     *
     * @readonly
     */ __publicField(this, "history");
        __publicField(this, "_shouldIgnoreShapeLock", false);
        /** @internal */ __publicField(this, "_crashingError", null);
        /** @internal */ __publicField(this, "_isChangingStyleTimeout", -1);
        // Menus
        __publicField(this, "menus", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$globals$2f$menus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tlmenus"].forContext(this.contextId));
        // Rich text editor
        __publicField(this, "_currentRichTextEditor", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("rich text editor", null));
        __publicField(this, "_textOptions");
        __publicField(this, "_debouncedZoomLevel", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("debounced zoom level", 1));
        __publicField(this, "_cameraOptions", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("camera options", __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CAMERA_OPTIONS"]));
        /** @internal */ __publicField(this, "_viewportAnimation", null);
        // Viewport
        /** @internal */ __publicField(this, "_willSetInitialBounds", true);
        // Following
        // When we are 'locked on' to a user, our camera is derived from their camera.
        __publicField(this, "_isLockedOnFollowingUser", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("isLockedOnFollowingUser", false));
        // Camera state
        // Camera state does two things: first, it allows us to subscribe to whether
        // the camera is moving or not; and second, it allows us to update the rendering
        // shapes on the canvas. Changing the rendering shapes may cause shapes to
        // unmount / remount in the DOM, which is expensive; and computing visibility is
        // also expensive in large projects. For this reason, we use a second bounding
        // box just for rendering, and we only update after the camera stops moving.
        __publicField(this, "_cameraStateTimeoutRemaining", 0);
        /* @internal */ __publicField(this, "_currentPageShapeIds");
        /* --------------------- Shapes --------------------- */ __publicField(this, "_shapeGeometryCaches", {});
        __publicField(this, "_notVisibleShapes", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$notVisibleShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notVisibleShapes"])(this));
        __publicField(this, "_culledShapesCache", null);
        // Parents and children
        /**
     * A cache of parents to children.
     *
     * @internal
     */ __publicField(this, "_parentIdsToChildIds");
        __publicField(this, "animatingShapes", /* @__PURE__ */ new Map());
        /* --------------------- Content -------------------- */ /** @internal */ __publicField(this, "externalAssetContentHandlers", {
            file: null,
            url: null
        });
        /** @internal */ __publicField(this, "temporaryAssetPreview", /* @__PURE__ */ new Map());
        /** @internal */ __publicField(this, "externalContentHandlers", {
            text: null,
            files: null,
            "file-replace": null,
            embed: null,
            "svg-text": null,
            url: null,
            tldraw: null,
            excalidraw: null
        });
        /**
     * A manager for recording multiple click events.
     *
     * @internal
     */ __publicField(this, "_clickManager", new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$ClickManager$2f$ClickManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClickManager"](this));
        /**
     * The previous cursor. Used for restoring the cursor after pan events.
     *
     * @internal
     */ __publicField(this, "_prevCursor", "default");
        /** @internal */ __publicField(this, "_shiftKeyTimeout", -1);
        /** @internal */ __publicField(this, "_altKeyTimeout", -1);
        /** @internal */ __publicField(this, "_ctrlKeyTimeout", -1);
        /** @internal */ __publicField(this, "_metaKeyTimeout", -1);
        /** @internal */ __publicField(this, "_restoreToolId", "select");
        /** @internal */ __publicField(this, "_didPinch", false);
        /** @internal */ __publicField(this, "_selectedShapeIdsAtPointerDown", []);
        /** @internal */ __publicField(this, "_longPressTimeout", -1);
        /** @internal */ __publicField(this, "capturedPointerId", null);
        /** @internal */ __publicField(this, "performanceTracker");
        /** @internal */ __publicField(this, "performanceTrackerTimeout", -1);
        /** @internal */ __publicField(this, "handledEvents", /* @__PURE__ */ new WeakSet());
        __publicField(this, "_pendingEventsForNextTick", []);
        this._getShapeVisibility = getShapeVisibility;
        const options = _textOptions ? {
            ..._options,
            text: _options?.text ?? _textOptions
        } : _options;
        this.options = {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$options$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultTldrawOptions"],
            ...options
        };
        this.store = store;
        this.history = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$HistoryManager$2f$HistoryManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoryManager"]({
            store,
            annotateError: (error)=>{
                this.annotateError(error, {
                    origin: "history.batch",
                    willCrashApp: true
                });
                this.crash(error);
            }
        });
        this.snaps = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SnapManager$2f$SnapManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnapManager"](this);
        this._spatialIndex = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$SpatialIndexManager$2f$SpatialIndexManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpatialIndexManager"](this);
        this.disposables.add(()=>this._spatialIndex.dispose());
        this.disposables.add(this.timers.dispose);
        this._cameraOptions.set({
            ...__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CAMERA_OPTIONS"],
            ...cameraOptions,
            ...options?.camera
        });
        this._textOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Atom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])("text options", options?.text ?? null);
        this.user = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$UserPreferencesManager$2f$UserPreferencesManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserPreferencesManager"](user ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$createTLUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTLUser"])(), inferDarkMode ?? false);
        this.disposables.add(()=>this.user.dispose());
        this.getContainer = getContainer;
        this.textMeasure = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$TextManager$2f$TextManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextManager"](this);
        this.disposables.add(()=>this.textMeasure.dispose());
        this.fonts = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$FontManager$2f$FontManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontManager"](this, fontAssetUrls);
        this._tickManager = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$TickManager$2f$TickManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TickManager"](this);
        this.inputs = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$InputsManager$2f$InputsManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputsManager"](this);
        class NewRoot extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$RootState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RootState"] {
            static initial = initialState ?? "";
        }
        this.root = new NewRoot(this);
        this.root.children = {};
        this.markEventAsHandled = this.markEventAsHandled.bind(this);
        const allShapeUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkShapesAndAddCore"])(shapeUtils);
        const _shapeUtils = {};
        const _styleProps = {};
        const allStylesById = /* @__PURE__ */ new Map();
        for (const Util of allShapeUtils){
            const util = new Util(this);
            _shapeUtils[Util.type] = util;
            const propKeysByStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShapePropKeysByStyle"])(Util.props ?? {});
            _styleProps[Util.type] = propKeysByStyle;
            for (const style of propKeysByStyle.keys()){
                if (!allStylesById.has(style.id)) {
                    allStylesById.set(style.id, style);
                } else if (allStylesById.get(style.id) !== style) {
                    throw Error(`Multiple style props with id "${style.id}" in use. Style prop IDs must be unique.`);
                }
            }
        }
        this.shapeUtils = _shapeUtils;
        this.styleProps = _styleProps;
        const allBindingUtils = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$defaultBindings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkBindings"])(bindingUtils);
        const _bindingUtils = {};
        for (const Util of allBindingUtils){
            const util = new Util(this);
            _bindingUtils[Util.type] = util;
        }
        this.bindingUtils = _bindingUtils;
        for (const Tool of [
            ...tools
        ]){
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"])(this.root.children, Tool.id)) {
                throw Error(`Can't override tool with id "${Tool.id}"`);
            }
            this.root.children[Tool.id] = new Tool(this, this.root);
        }
        this.scribbles = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$ScribbleManager$2f$ScribbleManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScribbleManager"](this);
        const cleanupInstancePageState = (prevPageState, shapesNoLongerInPage)=>{
            let nextPageState = null;
            const selectedShapeIds = prevPageState.selectedShapeIds.filter((id)=>!shapesNoLongerInPage.has(id));
            if (selectedShapeIds.length !== prevPageState.selectedShapeIds.length) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.selectedShapeIds = selectedShapeIds;
            }
            const erasingShapeIds = prevPageState.erasingShapeIds.filter((id)=>!shapesNoLongerInPage.has(id));
            if (erasingShapeIds.length !== prevPageState.erasingShapeIds.length) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.erasingShapeIds = erasingShapeIds;
            }
            if (prevPageState.hoveredShapeId && shapesNoLongerInPage.has(prevPageState.hoveredShapeId)) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.hoveredShapeId = null;
            }
            if (prevPageState.editingShapeId && shapesNoLongerInPage.has(prevPageState.editingShapeId)) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.editingShapeId = null;
            }
            const hintingShapeIds = prevPageState.hintingShapeIds.filter((id)=>!shapesNoLongerInPage.has(id));
            if (hintingShapeIds.length !== prevPageState.hintingShapeIds.length) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.hintingShapeIds = hintingShapeIds;
            }
            if (prevPageState.focusedGroupId && shapesNoLongerInPage.has(prevPageState.focusedGroupId)) {
                if (!nextPageState) nextPageState = {
                    ...prevPageState
                };
                nextPageState.focusedGroupId = null;
            }
            return nextPageState;
        };
        this.sideEffects = this.store.sideEffects;
        let deletedBindings = /* @__PURE__ */ new Map();
        const deletedShapeIds = /* @__PURE__ */ new Set();
        const invalidParents = /* @__PURE__ */ new Set();
        let invalidBindingTypes = /* @__PURE__ */ new Set();
        this.disposables.add(this.sideEffects.registerOperationCompleteHandler(()=>{
            deletedShapeIds.clear();
            for (const parentId of invalidParents){
                invalidParents.delete(parentId);
                const parent = this.getShape(parentId);
                if (!parent) continue;
                const util = this.getShapeUtil(parent);
                const changes = util.onChildrenChange?.(parent);
                if (changes?.length) {
                    this.updateShapes(changes);
                }
            }
            if (invalidBindingTypes.size) {
                const t = invalidBindingTypes;
                invalidBindingTypes = /* @__PURE__ */ new Set();
                for (const type of t){
                    const util = this.getBindingUtil(type);
                    util.onOperationComplete?.();
                }
            }
            if (deletedBindings.size) {
                const t = deletedBindings;
                deletedBindings = /* @__PURE__ */ new Map();
                for (const opts of t.values()){
                    this.getBindingUtil(opts.binding).onAfterDelete?.(opts);
                }
            }
            this.emit("update");
        }));
        this.disposables.add(this.sideEffects.register({
            shape: {
                afterChange: (shapeBefore, shapeAfter)=>{
                    for (const binding of this.getBindingsInvolvingShape(shapeAfter)){
                        invalidBindingTypes.add(binding.type);
                        if (binding.fromId === shapeAfter.id) {
                            this.getBindingUtil(binding).onAfterChangeFromShape?.({
                                binding,
                                shapeBefore,
                                shapeAfter,
                                reason: "self"
                            });
                        }
                        if (binding.toId === shapeAfter.id) {
                            this.getBindingUtil(binding).onAfterChangeToShape?.({
                                binding,
                                shapeBefore,
                                shapeAfter,
                                reason: "self"
                            });
                        }
                    }
                    if (shapeBefore.parentId !== shapeAfter.parentId) {
                        const notifyBindingAncestryChange = (id)=>{
                            const descendantShape = this.getShape(id);
                            if (!descendantShape) return;
                            for (const binding of this.getBindingsInvolvingShape(descendantShape)){
                                invalidBindingTypes.add(binding.type);
                                if (binding.fromId === descendantShape.id) {
                                    this.getBindingUtil(binding).onAfterChangeFromShape?.({
                                        binding,
                                        shapeBefore: descendantShape,
                                        shapeAfter: descendantShape,
                                        reason: "ancestry"
                                    });
                                }
                                if (binding.toId === descendantShape.id) {
                                    this.getBindingUtil(binding).onAfterChangeToShape?.({
                                        binding,
                                        shapeBefore: descendantShape,
                                        shapeAfter: descendantShape,
                                        reason: "ancestry"
                                    });
                                }
                            }
                        };
                        notifyBindingAncestryChange(shapeAfter.id);
                        this.visitDescendants(shapeAfter.id, notifyBindingAncestryChange);
                    }
                    if (shapeBefore.parentId !== shapeAfter.parentId && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shapeAfter.parentId)) {
                        const allMovingIds = /* @__PURE__ */ new Set([
                            shapeBefore.id
                        ]);
                        this.visitDescendants(shapeBefore.id, (id)=>{
                            allMovingIds.add(id);
                        });
                        for (const instancePageState of this.getPageStates()){
                            if (instancePageState.pageId === shapeAfter.parentId) continue;
                            const nextPageState = cleanupInstancePageState(instancePageState, allMovingIds);
                            if (nextPageState) {
                                this.store.put([
                                    nextPageState
                                ]);
                            }
                        }
                    }
                    if (shapeBefore.parentId && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(shapeBefore.parentId)) {
                        invalidParents.add(shapeBefore.parentId);
                    }
                    if (shapeAfter.parentId !== shapeBefore.parentId && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(shapeAfter.parentId)) {
                        invalidParents.add(shapeAfter.parentId);
                    }
                },
                beforeDelete: (shape)=>{
                    if (deletedShapeIds.has(shape.id)) return;
                    if (shape.parentId && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(shape.parentId)) {
                        invalidParents.add(shape.parentId);
                    }
                    deletedShapeIds.add(shape.id);
                    const deleteBindingIds = [];
                    for (const binding of this.getBindingsInvolvingShape(shape)){
                        invalidBindingTypes.add(binding.type);
                        deleteBindingIds.push(binding.id);
                        const util = this.getBindingUtil(binding);
                        if (binding.fromId === shape.id) {
                            util.onBeforeIsolateToShape?.({
                                binding,
                                removedShape: shape
                            });
                            util.onBeforeDeleteFromShape?.({
                                binding,
                                shape
                            });
                        } else {
                            util.onBeforeIsolateFromShape?.({
                                binding,
                                removedShape: shape
                            });
                            util.onBeforeDeleteToShape?.({
                                binding,
                                shape
                            });
                        }
                    }
                    if (deleteBindingIds.length) {
                        this.deleteBindings(deleteBindingIds);
                    }
                    const deletedIds = /* @__PURE__ */ new Set([
                        shape.id
                    ]);
                    const updates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.getPageStates().map((pageState)=>{
                        return cleanupInstancePageState(pageState, deletedIds);
                    }));
                    if (updates.length) {
                        this.store.put(updates);
                    }
                }
            },
            binding: {
                beforeCreate: (binding)=>{
                    const next = this.getBindingUtil(binding).onBeforeCreate?.({
                        binding
                    });
                    if (next) return next;
                    return binding;
                },
                afterCreate: (binding)=>{
                    invalidBindingTypes.add(binding.type);
                    this.getBindingUtil(binding).onAfterCreate?.({
                        binding
                    });
                },
                beforeChange: (bindingBefore, bindingAfter)=>{
                    const updated = this.getBindingUtil(bindingAfter).onBeforeChange?.({
                        bindingBefore,
                        bindingAfter
                    });
                    if (updated) return updated;
                    return bindingAfter;
                },
                afterChange: (bindingBefore, bindingAfter)=>{
                    invalidBindingTypes.add(bindingAfter.type);
                    this.getBindingUtil(bindingAfter).onAfterChange?.({
                        bindingBefore,
                        bindingAfter
                    });
                },
                beforeDelete: (binding)=>{
                    this.getBindingUtil(binding).onBeforeDelete?.({
                        binding
                    });
                },
                afterDelete: (binding)=>{
                    this.getBindingUtil(binding).onAfterDelete?.({
                        binding
                    });
                    invalidBindingTypes.add(binding.type);
                }
            },
            page: {
                afterCreate: (record)=>{
                    const cameraId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(record.id);
                    const _pageStateId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(record.id);
                    if (!this.store.has(cameraId)) {
                        this.store.put([
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].create({
                                id: cameraId
                            })
                        ]);
                    }
                    if (!this.store.has(_pageStateId)) {
                        this.store.put([
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].create({
                                id: _pageStateId,
                                pageId: record.id
                            })
                        ]);
                    }
                },
                afterDelete: (record, source)=>{
                    if (this.getInstanceState()?.currentPageId === record.id) {
                        const backupPageId = this.getPages().find((p)=>p.id !== record.id)?.id;
                        if (backupPageId) {
                            this.store.put([
                                {
                                    ...this.getInstanceState(),
                                    currentPageId: backupPageId
                                }
                            ]);
                        } else if (source === "user") {
                            this.store.ensureStoreIsUsable();
                        }
                    }
                    const cameraId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(record.id);
                    const instance_PageStateId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(record.id);
                    this.store.remove([
                        cameraId,
                        instance_PageStateId
                    ]);
                }
            },
            instance: {
                afterChange: (prev, next, source)=>{
                    if (!this.store.has(next.currentPageId)) {
                        const backupPageId = this.store.has(prev.currentPageId) ? prev.currentPageId : this.getPages()[0]?.id;
                        if (backupPageId) {
                            this.store.update(next.id, (instance)=>({
                                    ...instance,
                                    currentPageId: backupPageId
                                }));
                        } else if (source === "user") {
                            this.store.ensureStoreIsUsable();
                        }
                    }
                }
            },
            instance_page_state: {
                afterChange: (prev, next)=>{
                    if (prev?.selectedShapeIds !== next?.selectedShapeIds) {
                        const filtered = next.selectedShapeIds.filter((id)=>{
                            let parentId = this.getShape(id)?.parentId;
                            while((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(parentId)){
                                if (next.selectedShapeIds.includes(parentId)) {
                                    return false;
                                }
                                parentId = this.getShape(parentId)?.parentId;
                            }
                            return true;
                        });
                        let nextFocusedGroupId = null;
                        if (filtered.length > 0) {
                            const commonGroupAncestor = this.findCommonAncestor((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(filtered.map((id)=>this.getShape(id))), (shape)=>this.isShapeOfType(shape, "group"));
                            if (commonGroupAncestor) {
                                nextFocusedGroupId = commonGroupAncestor;
                            }
                        } else {
                            if (next?.focusedGroupId) {
                                nextFocusedGroupId = next.focusedGroupId;
                            }
                        }
                        if (filtered.length !== next.selectedShapeIds.length || nextFocusedGroupId !== next.focusedGroupId) {
                            this.store.put([
                                {
                                    ...next,
                                    selectedShapeIds: filtered,
                                    focusedGroupId: nextFocusedGroupId ?? null
                                }
                            ]);
                        }
                    }
                }
            }
        }));
        this._currentPageShapeIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$shapeIdsInCurrentPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deriveShapeIdsInCurrentPage"])(this.store, ()=>this.getCurrentPageId());
        this._parentIdsToChildIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$parentsToChildren$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parentsToChildren"])(this.store);
        this.disposables.add(this.store.listen((changes)=>{
            this.emit("change", changes);
        }));
        this.disposables.add(this.history.dispose);
        this.run(()=>{
            this.store.ensureStoreIsUsable();
            this._updateCurrentPageState({
                editingShapeId: null,
                hoveredShapeId: null,
                erasingShapeIds: []
            });
        }, {
            history: "ignore"
        });
        if (initialState && this.root.children[initialState] === void 0) {
            throw Error(`No state found for initialState "${initialState}".`);
        }
        this.root.enter(void 0, "initial");
        this.edgeScrollManager = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$EdgeScrollManager$2f$EdgeScrollManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EdgeScrollManager"](this);
        this.focusManager = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$managers$2f$FocusManager$2f$FocusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusManager"](this, autoFocus);
        this.disposables.add(this.focusManager.dispose.bind(this.focusManager));
        if (this.getInstanceState().followingUserId) {
            this.stopFollowingUser();
        }
        this.on("tick", this._flushEventsForTick);
        this.timers.requestAnimationFrame(()=>{
            this._tickManager.start();
        });
        this.performanceTracker = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$PerformanceTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PerformanceTracker"]();
        if (this.store.props.collaboration?.mode) {
            const mode = this.store.props.collaboration.mode;
            this.disposables.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("update collaboration mode", ()=>{
                this.store.put([
                    {
                        ...this.getInstanceState(),
                        isReadonly: mode.get() === "readonly"
                    }
                ]);
            }));
        }
    }
    getIsShapeHiddenCache() {
        if (!this._getShapeVisibility) return null;
        return this.store.createComputedCache("isShapeHidden", (shape)=>{
            const visibility = this._getShapeVisibility(shape, this);
            const isParentHidden = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].isId(shape.parentId) ? false : this.isShapeHidden(shape.parentId);
            if (isParentHidden) return visibility !== "visible";
            return visibility === "hidden";
        });
    }
    isShapeHidden(shapeOrId) {
        if (!this._getShapeVisibility) return false;
        return !!this.getIsShapeHiddenCache().get(typeof shapeOrId === "string" ? shapeOrId : shapeOrId.id);
    }
    /**
   * Set a tool. Useful if you need to add a tool to the state chart on demand,
   * after the editor has already been initialized.
   *
   * @param Tool - The tool to set.
   * @param parent - The parent state node to set the tool on.
   *
   * @public
   */ setTool(Tool, parent) {
        parent ??= this.root;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"])(parent.children, Tool.id)) {
            throw Error(`Can't override tool with id "${Tool.id}"`);
        }
        parent.children[Tool.id] = new Tool(this, parent);
    }
    /**
   * Remove a tool. Useful if you need to remove a tool from the state chart on demand,
   * after the editor has already been initialized.
   *
   * @param Tool - The tool to delete.
   * @param parent - The parent state node to remove the tool from.
   *
   * @public
   */ removeTool(Tool, parent) {
        parent ??= this.root;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"])(parent.children, Tool.id)) {
            delete parent.children[Tool.id];
        }
    }
    /**
   * Dispose the editor.
   *
   * @public
   */ dispose() {
        this.disposables.forEach((dispose)=>dispose());
        this.disposables.clear();
        this.store.dispose();
        this.isDisposed = true;
        this.emit("dispose");
    }
    getShapeUtil(arg) {
        const type = typeof arg === "string" ? arg : arg.type;
        const shapeUtil = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(this.shapeUtils, type);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(shapeUtil, `No shape util found for type "${type}"`);
        return shapeUtil;
    }
    hasShapeUtil(arg) {
        const type = typeof arg === "string" ? arg : arg.type;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"])(this.shapeUtils, type);
    }
    getBindingUtil(arg) {
        const type = typeof arg === "string" ? arg : arg.type;
        const bindingUtil = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(this.bindingUtils, type);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(bindingUtil, `No binding util found for type "${type}"`);
        return bindingUtil;
    }
    /**
   * Undo to the last mark.
   *
   * @example
   * ```ts
   * editor.undo()
   * ```
   *
   * @public
   */ undo() {
        this._flushEventsForTick(0);
        this.complete();
        this.history.undo();
        return this;
    }
    canUndo() {
        return this.history.getNumUndos() > 0;
    }
    getCanUndo() {
        return this.canUndo();
    }
    /**
   * Redo to the next mark.
   *
   * @example
   * ```ts
   * editor.redo()
   * ```
   *
   * @public
   */ redo() {
        this._flushEventsForTick(0);
        this.complete();
        this.history.redo();
        return this;
    }
    canRedo() {
        return this.history.getNumRedos() > 0;
    }
    getCanRedo() {
        return this.canRedo();
    }
    clearHistory() {
        this.history.clear();
        return this;
    }
    /**
   * Create a new "mark", or stopping point, in the undo redo history. Creating a mark will clear
   * any redos. You typically want to do this just before a user interaction begins or is handled.
   *
   * @example
   * ```ts
   * editor.markHistoryStoppingPoint()
   * editor.flipShapes(editor.getSelectedShapes())
   * ```
   * @example
   * ```ts
   * const beginRotateMark = editor.markHistoryStoppingPoint()
   * // if the use cancels the rotation, you can bail back to this mark
   * editor.bailToMark(beginRotateMark)
   * ```
   *
   * @public
   * @param name - The name of the mark, useful for debugging the undo/redo stacks
   * @returns a unique id for the mark that can be used with `squashToMark` or `bailToMark`.
   */ markHistoryStoppingPoint(name) {
        const id = `[${name ?? "stop"}]_${(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])()}`;
        this.history._mark(id);
        return id;
    }
    /**
   * @internal this is only used to implement some backwards-compatibility logic. Should be fine to delete after 6 months or whatever.
   */ getMarkIdMatching(idSubstring) {
        return this.history.getMarkIdMatching(idSubstring);
    }
    /**
   * Coalesces all changes since the given mark into a single change, removing any intermediate marks.
   *
   * This is useful if you need to 'compress' the recent history to simplify the undo/redo experience of a complex interaction.
   *
   * @example
   * ```ts
   * const bumpShapesMark = editor.markHistoryStoppingPoint()
   * // ... some changes
   * editor.squashToMark(bumpShapesMark)
   * ```
   *
   * @param markId - The mark id to squash to.
   */ squashToMark(markId) {
        this.history.squashToMark(markId);
        return this;
    }
    /**
   * Undo to the closest mark, discarding the changes so they cannot be redone.
   *
   * @example
   * ```ts
   * editor.bail()
   * ```
   *
   * @public
   */ bail() {
        this.history.bail();
        return this;
    }
    /**
   * Undo to the given mark, discarding the changes so they cannot be redone.
   *
   * @example
   * ```ts
   * const beginDrag = editor.markHistoryStoppingPoint()
   * // ... some changes
   * editor.bailToMark(beginDrag)
   * ```
   *
   * @public
   */ bailToMark(id) {
        this.history.bailToMark(id);
        return this;
    }
    /**
   * Run a function in a transaction with optional options for context.
   * You can use the options to change the way that history is treated
   * or allow changes to locked shapes.
   *
   * @example
   * ```ts
   * // updating with
   * editor.run(() => {
   * 	editor.updateShape({ ...myShape, x: 100 })
   * }, { history: "ignore" })
   *
   * // forcing changes / deletions for locked shapes
   * editor.toggleLock([myShape])
   * editor.run(() => {
   * 	editor.updateShape({ ...myShape, x: 100 })
   * 	editor.deleteShape(myShape)
   * }, { ignoreShapeLock: true }, )
   * ```
   *
   * @param fn - The callback function to run.
   * @param opts - The options for the batch.
   *
   *
   * @public
   */ run(fn, opts) {
        const previousIgnoreShapeLock = this._shouldIgnoreShapeLock;
        this._shouldIgnoreShapeLock = opts?.ignoreShapeLock ?? previousIgnoreShapeLock;
        try {
            this.history.batch(fn, opts);
        } finally{
            this._shouldIgnoreShapeLock = previousIgnoreShapeLock;
        }
        return this;
    }
    /* --------------------- Errors --------------------- */ /** @internal */ annotateError(error, { origin, willCrashApp, tags, extras }) {
        const defaultAnnotations = this.createErrorAnnotations(origin, willCrashApp);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$error$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["annotateError"])(error, {
            tags: {
                ...defaultAnnotations.tags,
                ...tags
            },
            extras: {
                ...defaultAnnotations.extras,
                ...extras
            }
        });
        if (willCrashApp) {
            this.store.markAsPossiblyCorrupted();
        }
        return this;
    }
    /** @internal */ createErrorAnnotations(origin, willCrashApp) {
        try {
            const editingShapeId = this.getEditingShapeId();
            return {
                tags: {
                    origin,
                    willCrashApp
                },
                extras: {
                    activeStateNode: this.root.getPath(),
                    selectedShapes: this.getSelectedShapes().map((s)=>{
                        const { props, ...rest } = s;
                        const { text: _text, richText: _richText, ...restProps } = props;
                        return {
                            ...rest,
                            props: restProps
                        };
                    }),
                    selectionCount: this.getSelectedShapes().length,
                    editingShape: editingShapeId ? this.getShape(editingShapeId) : void 0,
                    inputs: this.inputs.toJson(),
                    pageState: this.getCurrentPageState(),
                    instanceState: this.getInstanceState(),
                    collaboratorCount: this.getCollaboratorsOnCurrentPage().length
                }
            };
        } catch  {
            return {
                tags: {
                    origin,
                    willCrashApp
                },
                extras: {}
            };
        }
    }
    /**
   * We can't use an `atom` here because there's a chance that when `crashAndReportError` is called,
   * we're in a transaction that's about to be rolled back due to the same error we're currently
   * reporting.
   *
   * Instead, to listen to changes to this value, you need to listen to editor's `crash` event.
   *
   * @internal
   */ getCrashingError() {
        return this._crashingError;
    }
    /** @internal */ crash(error) {
        this._crashingError = error;
        this.store.markAsPossiblyCorrupted();
        this.emit("crash", {
            error
        });
        return this;
    }
    getPath() {
        return this.root.getPath().split("root.")[1];
    }
    /**
   * Get whether a certain tool (or other state node) is currently active.
   *
   * @example
   * ```ts
   * editor.isIn('select')
   * editor.isIn('select.brushing')
   * ```
   *
   * @param path - The path of active states, separated by periods.
   *
   * @public
   */ isIn(path) {
        const ids = path.split(".").reverse();
        let state = this.root;
        while(ids.length > 0){
            const id = ids.pop();
            if (!id) return true;
            const current = state.getCurrent();
            if (current?.id === id) {
                if (ids.length === 0) return true;
                state = current;
                continue;
            } else return false;
        }
        return false;
    }
    /**
   * Get whether the state node is in any of the given active paths.
   *
   * @example
   * ```ts
   * state.isInAny('select', 'erase')
   * state.isInAny('select.brushing', 'erase.idle')
   * ```
   *
   * @public
   */ isInAny(...paths) {
        return paths.some((path)=>this.isIn(path));
    }
    /**
   * Set the selected tool.
   *
   * @example
   * ```ts
   * editor.setCurrentTool('hand')
   * editor.setCurrentTool('hand', { date: Date.now() })
   * ```
   *
   * @param id - The id of the tool to select.
   * @param info - Arbitrary data to pass along into the transition.
   *
   * @public
   */ setCurrentTool(id, info = {}) {
        this.root.transition(id, info);
        return this;
    }
    getCurrentTool() {
        return this.root.getCurrent();
    }
    getCurrentToolId() {
        const currentTool = this.getCurrentTool();
        if (!currentTool) return "";
        return currentTool.getCurrentToolIdMask() ?? currentTool.id;
    }
    /**
   * Get a descendant by its path.
   *
   * @example
   * ```ts
   * editor.getStateDescendant('select')
   * editor.getStateDescendant('select.brushing')
   * ```
   *
   * @param path - The descendant's path of state ids, separated by periods.
   *
   * @public
   */ getStateDescendant(path) {
        const ids = path.split(".").reverse();
        let state = this.root;
        while(ids.length > 0){
            const id = ids.pop();
            if (!id) return state;
            const childState = state.children?.[id];
            if (!childState) return void 0;
            state = childState;
        }
        return state;
    }
    getDocumentSettings() {
        return this.store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLDocument$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLDOCUMENT_ID"]);
    }
    /**
   * Update the global document settings that apply to all users.
   *
   * @public
   **/ updateDocumentSettings(settings) {
        this.run(()=>{
            this.store.put([
                {
                    ...this.getDocumentSettings(),
                    ...settings
                }
            ]);
        }, {
            history: "ignore"
        });
        return this;
    }
    getInstanceState() {
        return this.store.get(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
    }
    /**
   * Update the instance's state.
   *
   * @param partial - A partial object to update the instance state with.
   * @param historyOptions - History batch options.
   *
   * @public
   */ updateInstanceState(partial, historyOptions) {
        this._updateInstanceState(partial, {
            history: "ignore",
            ...historyOptions
        });
        if (partial.isChangingStyle !== void 0) {
            clearTimeout(this._isChangingStyleTimeout);
            if (partial.isChangingStyle === true) {
                this._isChangingStyleTimeout = this.timers.setTimeout(()=>{
                    this._updateInstanceState({
                        isChangingStyle: false
                    }, {
                        history: "ignore"
                    });
                }, 1e3);
            }
        }
        return this;
    }
    /** @internal */ _updateInstanceState(partial, opts) {
        this.run(()=>{
            this.store.put([
                {
                    ...this.getInstanceState(),
                    ...partial
                }
            ]);
        }, opts);
    }
    /* --------------------- Cursor --------------------- */ /**
   * Set the cursor.
   *
   * @param cursor - The cursor to set.
   * @public
   */ setCursor(cursor) {
        this.updateInstanceState({
            cursor: {
                ...this.getInstanceState().cursor,
                ...cursor
            }
        });
        return this;
    }
    getPageStates() {
        return this._getPageStatesQuery().get();
    }
    _getPageStatesQuery() {
        return this.store.query.records("instance_page_state");
    }
    getCurrentPageState() {
        return this.store.get(this._getCurrentPageStateId());
    }
    _getCurrentPageStateId() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPageState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstancePageStateRecordType"].createId(this.getCurrentPageId());
    }
    /**
   * Update this instance's page state.
   *
   * @example
   * ```ts
   * editor.updateCurrentPageState({ id: 'page1', editingShapeId: 'shape:123' })
   * ```
   *
   * @param partial - The partial of the page state object containing the changes.
   *
   * @public
   */ updateCurrentPageState(partial) {
        this._updateCurrentPageState(partial);
        return this;
    }
    _updateCurrentPageState(partial) {
        this.store.update(partial.id ?? this.getCurrentPageState().id, (state)=>({
                ...state,
                ...partial
            }));
    }
    getSelectedShapeIds() {
        return this.getCurrentPageState().selectedShapeIds;
    }
    getSelectedShapes() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.getSelectedShapeIds().map((id)=>this.store.get(id)));
    }
    /**
   * Select one or more shapes.
   *
   * @example
   * ```ts
   * editor.setSelectedShapes(['id1'])
   * editor.setSelectedShapes(['id1', 'id2'])
   * ```
   *
   * @param shapes - The shape (or shape ids) to select.
   *
   * @public
   */ setSelectedShapes(shapes) {
        return this.run(()=>{
            const ids = shapes.map((shape)=>typeof shape === "string" ? shape : shape.id);
            const { selectedShapeIds: prevSelectedShapeIds } = this.getCurrentPageState();
            const prevSet = new Set(prevSelectedShapeIds);
            if (ids.length === prevSet.size && ids.every((id)=>prevSet.has(id))) return null;
            this.store.put([
                {
                    ...this.getCurrentPageState(),
                    selectedShapeIds: ids
                }
            ]);
        }, {
            history: "record-preserveRedoStack"
        });
    }
    /**
   * Determine whether or not any of a shape's ancestors are selected.
   *
   * @param shape - The shape (or shape id) of the shape to check.
   *
   * @public
   */ isAncestorSelected(shape) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        const _shape = this.getShape(id);
        if (!_shape) return false;
        const selectedShapeIds = this.getSelectedShapeIds();
        return !!this.findShapeAncestor(_shape, (parent)=>selectedShapeIds.includes(parent.id));
    }
    /**
   * Select one or more shapes.
   *
   * @example
   * ```ts
   * editor.select('id1')
   * editor.select('id1', 'id2')
   * ```
   *
   * @param shapes - The shape (or the shape ids) to select.
   *
   * @public
   */ select(...shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((shape)=>shape.id);
        this.setSelectedShapes(ids);
        return this;
    }
    /**
   * Remove a shape from the existing set of selected shapes.
   *
   * @example
   * ```ts
   * editor.deselect(shape.id)
   * ```
   *
   * @public
   */ deselect(...shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((shape)=>shape.id);
        const selectedShapeIds = this.getSelectedShapeIds();
        if (selectedShapeIds.length > 0 && ids.length > 0) {
            this.setSelectedShapes(selectedShapeIds.filter((id)=>!ids.includes(id)));
        }
        return this;
    }
    /**
   * Select all shapes. If the user has selected shapes that share a parent,
   * select all shapes within that parent. If the user has not selected any shapes,
   * or if the shapes shapes are only on select all shapes on the current page.
   *
   * @example
   * ```ts
   * editor.selectAll()
   * ```
   *
   * @public
   */ selectAll() {
        let parentToSelectWithinId = null;
        const selectedShapeIds = this.getSelectedShapeIds();
        if (selectedShapeIds.length > 0) {
            for (const id of selectedShapeIds){
                const shape = this.getShape(id);
                if (!shape) continue;
                if (parentToSelectWithinId === null) {
                    parentToSelectWithinId = shape.parentId;
                } else if (parentToSelectWithinId !== shape.parentId) {
                    return this;
                }
            }
        }
        if (!parentToSelectWithinId) {
            parentToSelectWithinId = this.getCurrentPageId();
        }
        const ids = this.getSortedChildIdsForParent(parentToSelectWithinId);
        if (ids.length <= 0) return this;
        this.setSelectedShapes(this._getUnlockedShapeIds(ids));
        return this;
    }
    /**
   * Select the next shape in the reading order or in cardinal order.
   *
   * @example
   * ```ts
   * editor.selectAdjacentShape('next')
   * ```
   *
   * @public
   */ selectAdjacentShape(direction) {
        const selectedShapeIds = this.getSelectedShapeIds();
        const firstParentId = selectedShapeIds[0] ? this.getShape(selectedShapeIds[0])?.parentId : null;
        const isSelectedWithinContainer = firstParentId && selectedShapeIds.every((shapeId)=>this.getShape(shapeId)?.parentId === firstParentId) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(firstParentId);
        const filteredShapes = isSelectedWithinContainer ? this.getCurrentPageShapes().filter((shape2)=>shape2.parentId === firstParentId) : this.getCurrentPageShapes().filter((shape2)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape2.parentId));
        const readingOrderShapes = isSelectedWithinContainer ? this._getShapesInReadingOrder(filteredShapes) : this.getCurrentPageShapesInReadingOrder();
        const currentShapeId = selectedShapeIds.length === 1 ? selectedShapeIds[0] : readingOrderShapes.find((shape2)=>selectedShapeIds.includes(shape2.id))?.id;
        let adjacentShapeId;
        if (direction === "next" || direction === "prev") {
            const shapeIds = readingOrderShapes.map((shape2)=>shape2.id);
            const currentIndex = currentShapeId ? shapeIds.indexOf(currentShapeId) : -1;
            const adjacentIndex = (currentIndex + (direction === "next" ? 1 : -1) + shapeIds.length) % shapeIds.length;
            adjacentShapeId = shapeIds[adjacentIndex];
        } else {
            if (!currentShapeId) return;
            adjacentShapeId = this.getNearestAdjacentShape(filteredShapes, currentShapeId, direction);
        }
        const shape = this.getShape(adjacentShapeId);
        if (!shape) return;
        this._selectShapesAndZoom([
            shape.id
        ]);
    }
    getCurrentPageShapesInReadingOrder() {
        const shapes = this.getCurrentPageShapes().filter((shape)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape.parentId));
        return this._getShapesInReadingOrder(shapes);
    }
    _getShapesInReadingOrder(shapes) {
        const SHALLOW_ANGLE = 20;
        const ROW_THRESHOLD = 100;
        const tabbableShapes = shapes.filter((shape)=>this.getShapeUtil(shape).canTabTo(shape));
        if (tabbableShapes.length <= 1) return tabbableShapes;
        const shapesWithCenters = tabbableShapes.map((shape)=>({
                shape,
                center: this.getShapePageBounds(shape).center
            }));
        shapesWithCenters.sort((a, b)=>a.center.y - b.center.y);
        const rows = [];
        for (const shapeWithCenter of shapesWithCenters){
            let rowIndex = -1;
            for(let i = rows.length - 1; i >= 0; i--){
                const row = rows[i];
                const lastShapeInRow = row[row.length - 1];
                if (Math.abs(shapeWithCenter.center.y - lastShapeInRow.center.y) < ROW_THRESHOLD) {
                    rowIndex = i;
                    break;
                }
            }
            if (rowIndex === -1) {
                rows.push([
                    shapeWithCenter
                ]);
            } else {
                rows[rowIndex].push(shapeWithCenter);
            }
        }
        for (const row of rows){
            row.sort((a, b)=>a.center.x - b.center.x);
        }
        for (const row of rows){
            if (row.length <= 2) continue;
            for(let i = 0; i < row.length - 2; i++){
                const currentShape = row[i];
                const nextShape = row[i + 1];
                const nextNextShape = row[i + 2];
                const dist1 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(currentShape.center, nextShape.center);
                const dist2 = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(currentShape.center, nextNextShape.center);
                if (dist2 < dist1 * 0.9) {
                    const angle = Math.abs(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(currentShape.center, nextNextShape.center) * (180 / Math.PI));
                    if (angle <= SHALLOW_ANGLE) {
                        ;
                        [row[i + 1], row[i + 2]] = [
                            row[i + 2],
                            row[i + 1]
                        ];
                    }
                }
            }
        }
        return rows.flat().map((item)=>item.shape);
    }
    /**
   * Find the nearest adjacent shape in a specific direction.
   *
   * @public
   */ getNearestAdjacentShape(shapes, currentShapeId, direction) {
        const directionToAngle = {
            right: 0,
            left: 180,
            down: 90,
            up: 270
        };
        const currentShape = this.getShape(currentShapeId);
        if (!currentShape) return currentShapeId;
        const tabbableShapes = shapes.filter((shape)=>this.getShapeUtil(shape).canTabTo(shape) && shape.id !== currentShapeId);
        if (!tabbableShapes.length) return currentShapeId;
        const currentCenter = this.getShapePageBounds(currentShape).center;
        const shapesWithCenters = tabbableShapes.map((shape)=>({
                shape,
                center: this.getShapePageBounds(shape).center
            }));
        const shapesInDirection = shapesWithCenters.filter(({ center })=>{
            const isRight = center.x > currentCenter.x;
            const isDown = center.y > currentCenter.y;
            const xDist = center.x - currentCenter.x;
            const yDist = center.y - currentCenter.y;
            const isInXDirection = Math.abs(yDist) < Math.abs(xDist) * 2;
            const isInYDirection = Math.abs(xDist) < Math.abs(yDist) * 2;
            if (direction === "left" || direction === "right") {
                return isInXDirection && (direction === "right" ? isRight : !isRight);
            }
            if (direction === "up" || direction === "down") {
                return isInYDirection && (direction === "down" ? isDown : !isDown);
            }
        });
        if (shapesInDirection.length === 0) return currentShapeId;
        const lowestScoringShape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["minBy"])(shapesInDirection, ({ center })=>{
            const distance = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(currentCenter, center);
            const dirProp = [
                "left",
                "right"
            ].includes(direction) ? "x" : "y";
            const directionalDistance = Math.abs(center[dirProp] - currentCenter[dirProp]);
            const offProp = [
                "left",
                "right"
            ].includes(direction) ? "y" : "x";
            const offAxisDeviation = Math.abs(center[offProp] - currentCenter[offProp]);
            const angle = Math.abs(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Angle(currentCenter, center) * (180 / Math.PI));
            const angleDeviation = Math.abs(angle - directionToAngle[direction]);
            return distance * 1 + // Base distance
            offAxisDeviation * 2 + // Heavy penalty for off-axis deviation
            (distance - directionalDistance) * 1.5 + // Penalty for diagonal distance
            angleDeviation * 0.5;
        });
        return lowestScoringShape.shape.id;
    }
    selectParentShape() {
        const selectedShape = this.getOnlySelectedShape();
        if (!selectedShape) return;
        const parentShape = this.getShape(selectedShape.parentId);
        if (!parentShape) return;
        this._selectShapesAndZoom([
            parentShape.id
        ]);
    }
    selectFirstChildShape() {
        const selectedShapes = this.getSelectedShapes();
        if (!selectedShapes.length) return;
        const selectedShape = selectedShapes[0];
        const children = this.getSortedChildIdsForParent(selectedShape.id).map((id)=>this.getShape(id)).filter((i)=>i);
        const sortedChildren = this._getShapesInReadingOrder(children);
        if (sortedChildren.length === 0) return;
        this._selectShapesAndZoom([
            sortedChildren[0].id
        ]);
    }
    _selectShapesAndZoom(ids) {
        this.setSelectedShapes(ids);
        this.zoomToSelectionIfOffscreen(256, {
            animation: {
                duration: this.options.animationMediumMs
            },
            inset: 0
        });
    }
    /**
   * Clear the selection.
   *
   * @example
   * ```ts
   * editor.selectNone()
   * ```
   *
   * @public
   */ selectNone() {
        if (this.getSelectedShapeIds().length > 0) {
            this.setSelectedShapes([]);
        }
        return this;
    }
    getOnlySelectedShapeId() {
        return this.getOnlySelectedShape()?.id ?? null;
    }
    getOnlySelectedShape() {
        const selectedShapes = this.getSelectedShapes();
        return selectedShapes.length === 1 ? selectedShapes[0] : null;
    }
    /**
   * Get the page bounds of all the provided shapes.
   *
   * @public
   */ getShapesPageBounds(shapeIds) {
        const bounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(shapeIds.map((id)=>this.getShapePageBounds(id)));
        if (bounds.length === 0) return null;
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(bounds);
    }
    getSelectionPageBounds() {
        return this.getShapesPageBounds(this.getSelectedShapeIds());
    }
    /**
   * The bounds of the selection bounding box in the current page space.
   *
   * @readonly
   * @public
   */ getSelectionScreenBounds() {
        const bounds = this.getSelectionPageBounds();
        if (!bounds) return void 0;
        const { x: x1, y } = this.pageToScreen(bounds.point);
        const zoom = this.getZoomLevel();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](x1, y, bounds.width * zoom, bounds.height * zoom);
    }
    /**
   * @internal
   */ getShapesSharedRotation(shapeIds) {
        let foundFirst = false;
        let rotation = 0;
        for(let i = 0, n = shapeIds.length; i < n; i++){
            const pageTransform = this.getShapePageTransform(shapeIds[i]);
            if (!pageTransform) continue;
            if (foundFirst) {
                if (pageTransform.rotation() !== rotation) {
                    return 0;
                }
            } else {
                foundFirst = true;
                rotation = pageTransform.rotation();
            }
        }
        return rotation;
    }
    getSelectionRotation() {
        return this.getShapesSharedRotation(this.getSelectedShapeIds());
    }
    /**
   * @internal
   */ getShapesRotatedPageBounds(shapeIds) {
        if (shapeIds.length === 0) {
            return void 0;
        }
        const selectionRotation = this.getShapesSharedRotation(shapeIds);
        if (selectionRotation === 0) {
            return this.getShapesPageBounds(shapeIds) ?? void 0;
        }
        if (shapeIds.length === 1) {
            const bounds = this.getShapeGeometry(shapeIds[0]).bounds.clone();
            const pageTransform = this.getShapePageTransform(shapeIds[0]);
            bounds.point = pageTransform.applyToPoint(bounds.point);
            return bounds;
        }
        const boxFromRotatedVertices = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(shapeIds.flatMap((id)=>{
            const pageTransform = this.getShapePageTransform(id);
            if (!pageTransform) return [];
            return pageTransform.applyToPoints(this.getShapeGeometry(id).bounds.corners);
        }).map((p)=>p.rot(-selectionRotation)));
        boxFromRotatedVertices.point = boxFromRotatedVertices.point.rot(selectionRotation);
        return boxFromRotatedVertices;
    }
    getSelectionRotatedPageBounds() {
        return this.getShapesRotatedPageBounds(this.getSelectedShapeIds());
    }
    getSelectionRotatedScreenBounds() {
        const bounds = this.getSelectionRotatedPageBounds();
        if (!bounds) return void 0;
        const { x: x1, y } = this.pageToScreen(bounds.point);
        const zoom = this.getZoomLevel();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](x1, y, bounds.width * zoom, bounds.height * zoom);
    }
    getFocusedGroupId() {
        return this.getCurrentPageState().focusedGroupId ?? this.getCurrentPageId();
    }
    getFocusedGroup() {
        const focusedGroupId = this.getFocusedGroupId();
        return focusedGroupId ? this.getShape(focusedGroupId) : void 0;
    }
    /**
   * Set the current focused group shape.
   *
   * @param shape - The group shape id (or group shape's id) to set as the focused group shape.
   *
   * @public
   */ setFocusedGroup(shape) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (id !== null) {
            const shape2 = this.getShape(id);
            if (!shape2) {
                throw Error(`Editor.setFocusedGroup: Shape with id ${id} does not exist`);
            }
            if (!this.isShapeOfType(shape2, "group")) {
                throw Error(`Editor.setFocusedGroup: Cannot set focused group to shape of type ${shape2.type}`);
            }
        }
        if (id === this.getFocusedGroupId()) return this;
        return this.run(()=>{
            this.store.update(this.getCurrentPageState().id, (s)=>({
                    ...s,
                    focusedGroupId: id
                }));
        }, {
            history: "record-preserveRedoStack"
        });
    }
    /**
   * Exit the current focused group, moving up to the next parent group if there is one.
   *
   * @public
   */ popFocusedGroupId() {
        const focusedGroup = this.getFocusedGroup();
        if (focusedGroup) {
            const match = this.findShapeAncestor(focusedGroup, (shape)=>this.isShapeOfType(shape, "group"));
            this.setFocusedGroup(match?.id ?? null);
            this.select(focusedGroup.id);
        } else {
            this.setFocusedGroup(null);
            this.selectNone();
        }
        return this;
    }
    getEditingShapeId() {
        return this.getCurrentPageState().editingShapeId;
    }
    getEditingShape() {
        const editingShapeId = this.getEditingShapeId();
        return editingShapeId ? this.getShape(editingShapeId) : void 0;
    }
    /**
   * Whether the shape can be edited.
   *
   * @param shape - The shape (or shape id) to check if it can be edited.
   * @param info - The info about the edit start.
   *
   * @public
   * @returns true if the shape can be edited, false otherwise.
   */ canEditShape(shape, info) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (!id) return false;
        if (id === this.getEditingShapeId()) return false;
        const _shape = this.getShape(id);
        if (!_shape) return false;
        const util = this.getShapeUtil(_shape);
        const _info = info ?? {
            type: "unknown"
        };
        if (!util.canEdit(_shape, _info)) return false;
        if (this.getIsReadonly() && !util.canEditInReadonly(_shape)) return false;
        if (this.isShapeOrAncestorLocked(_shape) && !util.canEditWhileLocked(_shape)) return false;
        return true;
    }
    /**
   * Set the current editing shape.
   *
   * @example
   * ```ts
   * editor.setEditingShape(myShape)
   * editor.setEditingShape(myShape.id)
   * ```
   *
   * @param shape - The shape (or shape id) to set as editing.
   *
   * @public
   */ setEditingShape(shape) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (!id) {
            this.run(()=>{
                const prevEditingShapeId = this.getEditingShapeId();
                if (prevEditingShapeId) {
                    const prevEditingShape = this.getShape(prevEditingShapeId);
                    if (prevEditingShape) {
                        this.getShapeUtil(prevEditingShape).onEditEnd?.(prevEditingShape);
                    }
                }
                this._updateCurrentPageState({
                    editingShapeId: null
                });
                this._currentRichTextEditor.set(null);
            }, {
                history: "ignore"
            });
            return this;
        }
        if (!this.canEditShape(id)) return this;
        this.run(()=>{
            const prevEditingShapeId = this.getEditingShapeId();
            if (prevEditingShapeId) {
                const prevEditingShape = this.getShape(prevEditingShapeId);
                if (prevEditingShape) {
                    this.getShapeUtil(prevEditingShape).onEditEnd?.(prevEditingShape);
                }
            }
            this._updateCurrentPageState({
                editingShapeId: null
            });
            this._currentRichTextEditor.set(null);
            this.select(id);
            this._updateCurrentPageState({
                editingShapeId: id
            });
            const nextEditingShape = this.getShape(id);
            this.getShapeUtil(nextEditingShape).onEditStart?.(nextEditingShape);
        }, {
            history: "ignore"
        });
        return this;
    }
    getRichTextEditor() {
        return this._currentRichTextEditor.get();
    }
    /**
   * Set the current editing shape's rich text editor.
   *
   * @example
   * ```ts
   * editor.setRichTextEditor(richTextEditorView)
   * ```
   *
   * @param textEditor - The text editor to set as the current editing shape's text editor.
   *
   * @public
   */ setRichTextEditor(textEditor) {
        this._currentRichTextEditor.set(textEditor);
        return this;
    }
    getHoveredShapeId() {
        return this.getCurrentPageState().hoveredShapeId;
    }
    getHoveredShape() {
        const hoveredShapeId = this.getHoveredShapeId();
        return hoveredShapeId ? this.getShape(hoveredShapeId) : void 0;
    }
    /**
   * Set the editor's current hovered shape.
   *
   * @example
   * ```ts
   * editor.setHoveredShape(myShape)
   * editor.setHoveredShape(myShape.id)
   * ```
   *
   * @param shape - The shape (or shape id) to set as hovered.
   *
   * @public
   */ setHoveredShape(shape) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (id === this.getHoveredShapeId()) return this;
        this.run(()=>{
            this.updateCurrentPageState({
                hoveredShapeId: id
            });
        }, {
            history: "ignore"
        });
        return this;
    }
    getHintingShapeIds() {
        return this.getCurrentPageState().hintingShapeIds;
    }
    getHintingShape() {
        const hintingShapeIds = this.getHintingShapeIds();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(hintingShapeIds.map((id)=>this.getShape(id)));
    }
    /**
   * Set the editor's current hinting shapes.
   *
   * @example
   * ```ts
   * editor.setHintingShapes([myShape])
   * editor.setHintingShapes([myShape.id])
   * ```
   *
   * @param shapes - The shapes (or shape ids) to set as hinting.
   *
   * @public
   */ setHintingShapes(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((shape)=>shape.id);
        this.run(()=>{
            this._updateCurrentPageState({
                hintingShapeIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dedupe"])(ids)
            });
        }, {
            history: "ignore"
        });
        return this;
    }
    getErasingShapeIds() {
        return this.getCurrentPageState().erasingShapeIds;
    }
    getErasingShapes() {
        const erasingShapeIds = this.getErasingShapeIds();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(erasingShapeIds.map((id)=>this.getShape(id)));
    }
    /**
   * Set the editor's current erasing shapes.
   *
   * @example
   * ```ts
   * editor.setErasingShapes([myShape])
   * editor.setErasingShapes([myShape.id])
   * ```
   *
   * @param shapes - The shapes (or shape ids) to set as hinting.
   *
   * @public
   */ setErasingShapes(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((shape)=>shape.id);
        ids.sort();
        const erasingShapeIds = this.getErasingShapeIds();
        this.run(()=>{
            if (ids.length === erasingShapeIds.length) {
                for(let i = 0; i < ids.length; i++){
                    if (ids[i] !== erasingShapeIds[i]) {
                        this._updateCurrentPageState({
                            erasingShapeIds: ids
                        });
                        break;
                    }
                }
            } else {
                this._updateCurrentPageState({
                    erasingShapeIds: ids
                });
            }
        }, {
            history: "ignore"
        });
        return this;
    }
    // Cropping
    /**
   * The current cropping shape's id.
   *
   * @public
   */ getCroppingShapeId() {
        return this.getCurrentPageState().croppingShapeId;
    }
    /**
   * Whether the shape can be cropped.
   *
   * @param shape - The shape (or shape id) to check if it can be cropped.
   *
   * @public
   * @returns true if the shape can be cropped, false otherwise.
   */ canCropShape(shape) {
        if (!shape) return false;
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (!id) return false;
        const _shape = this.getShape(id);
        if (!_shape) return false;
        const util = this.getShapeUtil(_shape);
        if (!util.canCrop(_shape)) return false;
        if (this.isShapeOrAncestorLocked(_shape)) return false;
        return true;
    }
    /**
   * Set the current cropping shape.
   *
   * @example
   * ```ts
   * editor.setCroppingShape(myShape)
   * editor.setCroppingShape(myShape.id)
   * ```
   *
   *
   * @param shape - The shape (or shape id) to set as cropping.
   *
   * @public
   */ setCroppingShape(shape) {
        const id = typeof shape === "string" ? shape : shape?.id ?? null;
        if (id !== this.getCroppingShapeId()) {
            this.run(()=>{
                if (!id) {
                    this.updateCurrentPageState({
                        croppingShapeId: null
                    });
                } else if (this.canCropShape(id)) {
                    this.updateCurrentPageState({
                        croppingShapeId: id
                    });
                }
            }, {
                history: "ignore"
            });
        }
        return this;
    }
    /**
   * Get the current text options.
   *
   * @example
   * ```ts
   * editor.getTextOptions()
   * ```
   *
   *  @public */ getTextOptions() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(this._textOptions.get(), "Cannot use text without setting textOptions");
    }
    _unsafe_getCameraId() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLCamera$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CameraRecordType"].createId(this.getCurrentPageId());
    }
    getCamera() {
        const baseCamera = this.store.get(this._unsafe_getCameraId());
        if (this._isLockedOnFollowingUser.get()) {
            const followingCamera = this.getCameraForFollowing();
            if (followingCamera) {
                return {
                    ...baseCamera,
                    ...followingCamera
                };
            }
        }
        return baseCamera;
    }
    _getFollowingPresence(targetUserId) {
        const visited = [
            this.user.getId()
        ];
        const collaborators = this.getCollaborators();
        let leaderPresence = null;
        while(targetUserId && !visited.includes(targetUserId)){
            leaderPresence = collaborators.find((c)=>c.userId === targetUserId) ?? null;
            targetUserId = leaderPresence?.followingUserId ?? null;
            if (leaderPresence) {
                visited.push(leaderPresence.userId);
            }
        }
        return leaderPresence;
    }
    getViewportPageBoundsForFollowing() {
        const leaderPresence = this._getFollowingPresence(this.getInstanceState().followingUserId);
        if (!leaderPresence?.camera || !leaderPresence?.screenBounds) return null;
        const { w: lw, h: lh } = leaderPresence.screenBounds;
        const { x: lx, y: ly, z: lz } = leaderPresence.camera;
        const theirViewport = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](-lx, -ly, lw / lz, lh / lz);
        const ourViewport = this.getViewportScreenBounds().clone();
        const ourAspectRatio = ourViewport.width / ourViewport.height;
        ourViewport.width = theirViewport.width;
        ourViewport.height = ourViewport.width / ourAspectRatio;
        if (ourViewport.height < theirViewport.height) {
            ourViewport.height = theirViewport.height;
            ourViewport.width = ourViewport.height * ourAspectRatio;
        }
        ourViewport.center = theirViewport.center;
        return ourViewport;
    }
    getCameraForFollowing() {
        const viewport = this.getViewportPageBoundsForFollowing();
        if (!viewport) return null;
        return {
            x: -viewport.x,
            y: -viewport.y,
            z: this.getViewportScreenBounds().w / viewport.width
        };
    }
    getZoomLevel() {
        return this.getCamera().z;
    }
    getDebouncedZoomLevel() {
        if (this.options.debouncedZoom) {
            if (this.getCameraState() === "idle") {
                return this.getZoomLevel();
            } else {
                return this._debouncedZoomLevel.get();
            }
        }
        return this.getZoomLevel();
    }
    _getAboveDebouncedZoomThreshold() {
        return this.getCurrentPageShapeIds().size > this.options.debouncedZoomThreshold;
    }
    getEfficientZoomLevel() {
        return this._getAboveDebouncedZoomThreshold() ? this.getDebouncedZoomLevel() : this.getZoomLevel();
    }
    /**
   * Get the camera's initial or reset zoom level.
   *
   * @example
   * ```ts
   * editor.getInitialZoom()
   * ```
   *
   * @public */ getInitialZoom() {
        const cameraOptions = this.getCameraOptions();
        if (!cameraOptions.constraints) return 1;
        if (cameraOptions.constraints.initialZoom === "default") return 1;
        const { zx, zy } = getCameraFitXFitY(this, cameraOptions);
        switch(cameraOptions.constraints.initialZoom){
            case "fit-min":
                {
                    return Math.max(zx, zy);
                }
            case "fit-max":
                {
                    return Math.min(zx, zy);
                }
            case "fit-x":
                {
                    return zx;
                }
            case "fit-y":
                {
                    return zy;
                }
            case "fit-min-100":
                {
                    return Math.min(1, Math.max(zx, zy));
                }
            case "fit-max-100":
                {
                    return Math.min(1, Math.min(zx, zy));
                }
            case "fit-x-100":
                {
                    return Math.min(1, zx);
                }
            case "fit-y-100":
                {
                    return Math.min(1, zy);
                }
            default:
                {
                    throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(cameraOptions.constraints.initialZoom);
                }
        }
    }
    /**
   * Get the camera's base level for calculating actual zoom levels based on the zoom steps.
   *
   * @example
   * ```ts
   * editor.getBaseZoom()
   * ```
   *
   * @public */ getBaseZoom() {
        const cameraOptions = this.getCameraOptions();
        if (!cameraOptions.constraints) return 1;
        if (cameraOptions.constraints.baseZoom === "default") return 1;
        const { zx, zy } = getCameraFitXFitY(this, cameraOptions);
        switch(cameraOptions.constraints.baseZoom){
            case "fit-min":
                {
                    return Math.max(zx, zy);
                }
            case "fit-max":
                {
                    return Math.min(zx, zy);
                }
            case "fit-x":
                {
                    return zx;
                }
            case "fit-y":
                {
                    return zy;
                }
            case "fit-min-100":
                {
                    return Math.min(1, Math.max(zx, zy));
                }
            case "fit-max-100":
                {
                    return Math.min(1, Math.min(zx, zy));
                }
            case "fit-x-100":
                {
                    return Math.min(1, zx);
                }
            case "fit-y-100":
                {
                    return Math.min(1, zy);
                }
            default:
                {
                    throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(cameraOptions.constraints.baseZoom);
                }
        }
    }
    /**
   * Get the current camera options.
   *
   * @example
   * ```ts
   * editor.getCameraOptions()
   * ```
   *
   *  @public */ getCameraOptions() {
        return this._cameraOptions.get();
    }
    /**
   * Set the camera options. Changing the options won't immediately change the camera itself, so you may want to call `setCamera` after changing the options.
   *
   * @example
   * ```ts
   * editor.setCameraOptions(myCameraOptions)
   * editor.setCamera(editor.getCamera())
   * ```
   *
   * @param opts - The camera options to set.
   *
   * @public */ setCameraOptions(opts) {
        const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])({
            ...this._cameraOptions.__unsafe__getWithoutCapture(),
            ...opts
        });
        if (next.zoomSteps?.length < 1) next.zoomSteps = [
            1
        ];
        this._cameraOptions.set(next);
        this.setCamera(this.getCamera());
        return this;
    }
    /** @internal */ getConstrainedCamera(point, opts) {
        const currentCamera = this.getCamera();
        let { x: x1, y, z = currentCamera.z } = point;
        if (!opts?.force) {
            const cameraOptions = this.getCameraOptions();
            const zoomMin = cameraOptions.zoomSteps[0];
            const zoomMax = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(cameraOptions.zoomSteps);
            const vsb = this.getViewportScreenBounds();
            if (cameraOptions.constraints) {
                const { constraints } = cameraOptions;
                const py = Math.min(constraints.padding.y, vsb.w / 2);
                const px = Math.min(constraints.padding.x, vsb.h / 2);
                const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].From(cameraOptions.constraints.bounds);
                const zx = (vsb.w - px * 2) / bounds.w;
                const zy = (vsb.h - py * 2) / bounds.h;
                const baseZoom = this.getBaseZoom();
                const maxZ = zoomMax * baseZoom;
                const minZ = zoomMin * baseZoom;
                if (opts?.reset) {
                    z = this.getInitialZoom();
                }
                if (z < minZ || z > maxZ) {
                    const { x: cx, y: cy, z: cz } = currentCamera;
                    const cxA = -cx + vsb.w / cz / 2;
                    const cyA = -cy + vsb.h / cz / 2;
                    z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(z, minZ, maxZ);
                    const cxB = -cx + vsb.w / z / 2;
                    const cyB = -cy + vsb.h / z / 2;
                    x1 = cx + cxB - cxA;
                    y = cy + cyB - cyA;
                }
                const minX = px / z - bounds.x;
                const minY = py / z - bounds.y;
                const freeW = (vsb.w - px * 2) / z - bounds.w;
                const freeH = (vsb.h - py * 2) / z - bounds.h;
                const originX = minX + freeW * constraints.origin.x;
                const originY = minY + freeH * constraints.origin.y;
                const behaviorX = typeof constraints.behavior === "string" ? constraints.behavior : constraints.behavior.x;
                const behaviorY = typeof constraints.behavior === "string" ? constraints.behavior : constraints.behavior.y;
                if (opts?.reset) {
                    x1 = originX;
                    y = originY;
                } else {
                    switch(behaviorX){
                        case "fixed":
                            {
                                x1 = originX;
                                break;
                            }
                        case "contain":
                            {
                                if (z < zx) x1 = originX;
                                else x1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(x1, minX + freeW, minX);
                                break;
                            }
                        case "inside":
                            {
                                if (z < zx) x1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(x1, minX, (vsb.w - px) / z - bounds.w);
                                else x1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(x1, minX + freeW, minX);
                                break;
                            }
                        case "outside":
                            {
                                x1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(x1, px / z - bounds.w, (vsb.w - px) / z);
                                break;
                            }
                        case "free":
                            {
                                break;
                            }
                        default:
                            {
                                throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(behaviorX);
                            }
                    }
                    switch(behaviorY){
                        case "fixed":
                            {
                                y = originY;
                                break;
                            }
                        case "contain":
                            {
                                if (z < zy) y = originY;
                                else y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(y, minY + freeH, minY);
                                break;
                            }
                        case "inside":
                            {
                                if (z < zy) y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(y, minY, (vsb.h - py) / z - bounds.h);
                                else y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(y, minY + freeH, minY);
                                break;
                            }
                        case "outside":
                            {
                                y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(y, py / z - bounds.h, (vsb.h - py) / z);
                                break;
                            }
                        case "free":
                            {
                                break;
                            }
                        default:
                            {
                                throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(behaviorY);
                            }
                    }
                }
            } else {
                if (z > zoomMax || z < zoomMin) {
                    const { x: cx, y: cy, z: cz } = currentCamera;
                    z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(z, zoomMin, zoomMax);
                    x1 = cx + (-cx + vsb.w / z / 2) - (-cx + vsb.w / cz / 2);
                    y = cy + (-cy + vsb.h / z / 2) - (-cy + vsb.h / cz / 2);
                }
            }
        }
        return {
            x: x1,
            y,
            z
        };
    }
    /** @internal */ _setCamera(point, opts) {
        const currentCamera = this.getCamera();
        const { x: x1, y, z } = this.getConstrainedCamera(point, opts);
        if (currentCamera.x === x1 && currentCamera.y === y && currentCamera.z === z) {
            return this;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            const camera = {
                ...currentCamera,
                x: x1,
                y,
                z
            };
            this.run(()=>{
                this.store.put([
                    camera
                ]);
            }, {
                history: "ignore"
            });
            const currentScreenPoint = this.inputs.getCurrentScreenPoint();
            const currentPagePoint = this.inputs.getCurrentPagePoint();
            if (currentScreenPoint.x / z - x1 !== currentPagePoint.x || currentScreenPoint.y / z - y !== currentPagePoint.y) {
                this.updatePointer({
                    immediate: opts?.immediate,
                    pointerId: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INTERNAL_POINTER_IDS"].CAMERA_MOVE
                });
            }
            this._tickCameraState();
        });
        return this;
    }
    /**
   * Set the current camera.
   *
   * @example
   * ```ts
   * editor.setCamera({ x: 0, y: 0})
   * editor.setCamera({ x: 0, y: 0, z: 1.5})
   * editor.setCamera({ x: 0, y: 0, z: 1.5}, { animation: { duration: 1000, easing: (t) => t * t } })
   * ```
   *
   * @param point - The new camera position.
   * @param opts - The camera move options.
   *
   * @public
   */ setCamera(point, opts) {
        const { isLocked } = this._cameraOptions.__unsafe__getWithoutCapture();
        if (isLocked && !opts?.force) return this;
        this.stopCameraAnimation();
        if (this.getInstanceState().followingUserId) {
            this.stopFollowingUser();
        }
        const _point = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Cast(point);
        if (!Number.isFinite(_point.x)) _point.x = 0;
        if (!Number.isFinite(_point.y)) _point.y = 0;
        if (_point.z === void 0 || !Number.isFinite(_point.z)) point.z = this.getZoomLevel();
        const camera = this.getConstrainedCamera(_point, opts);
        if (opts?.animation) {
            const { width, height } = this.getViewportScreenBounds();
            this._animateToViewport(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](-camera.x, -camera.y, width / camera.z, height / camera.z), opts);
        } else {
            this._setCamera(camera, {
                ...opts,
                // we already did the constraining, so we don't need to do it again
                force: true
            });
        }
        return this;
    }
    /**
   * Center the camera on a point (in the current page space).
   *
   * @example
   * ```ts
   * editor.centerOnPoint({ x: 100, y: 100 })
   * editor.centerOnPoint({ x: 100, y: 100 }, { animation: { duration: 200 } })
   * ```
   *
   * @param point - The point in the current page space to center on.
   * @param opts - The camera move options.
   *
   * @public
   */ centerOnPoint(point, opts) {
        const { isLocked } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const { width: pw, height: ph } = this.getViewportPageBounds();
        this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-(point.x - pw / 2), -(point.y - ph / 2), this.getCamera().z), opts);
        return this;
    }
    /**
   * Zoom the camera to fit the current page's content in the viewport.
   *
   * @example
   * ```ts
   * editor.zoomToFit()
   * editor.zoomToFit({ animation: { duration: 200 } })
   * ```
   *
   * @param opts - The camera move options.
   *
   * @public
   */ zoomToFit(opts) {
        const ids = [
            ...this.getCurrentPageShapeIds()
        ].filter((id)=>!this.isShapeHidden(id));
        if (ids.length <= 0) return this;
        const pageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShapePageBounds(id))));
        this.zoomToBounds(pageBounds, opts);
        return this;
    }
    /**
   * Set the zoom back to 100%.
   *
   * @example
   * ```ts
   * editor.resetZoom()
   * editor.resetZoom(editor.getViewportScreenCenter(), { animation: { duration: 200 } })
   * editor.resetZoom(editor.getViewportScreenCenter(), { animation: { duration: 200 } })
   * ```
   *
   * @param point - The screen point to zoom out on. Defaults to the viewport screen center.
   * @param opts - The camera move options.
   *
   * @public
   */ resetZoom(point = this.getViewportScreenCenter(), opts) {
        const { isLocked, constraints } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const currentCamera = this.getCamera();
        const { x: cx, y: cy, z: cz } = currentCamera;
        const { x: x1, y } = point;
        let z = 1;
        if (constraints) {
            const initialZoom = this.getInitialZoom();
            if (cz !== initialZoom) {
                z = initialZoom;
            }
        }
        this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + (x1 / z - x1) - (x1 / cz - x1), cy + (y / z - y) - (y / cz - y), z), opts);
        return this;
    }
    /**
   * Zoom the camera in.
   *
   * @example
   * ```ts
   * editor.zoomIn()
   * editor.zoomIn(editor.getViewportScreenCenter(), { animation: { duration: 200 } })
   * editor.zoomIn(editor.inputs.getCurrentScreenPoint(), { animation: { duration: 200 } })
   * ```
   *
   * @param point - The screen point to zoom in on. Defaults to the screen center
   * @param opts - The camera move options.
   *
   * @public
   */ zoomIn(point = this.getViewportScreenCenter(), opts) {
        const { isLocked } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const { x: cx, y: cy, z: cz } = this.getCamera();
        const { zoomSteps } = this.getCameraOptions();
        if (zoomSteps !== null && zoomSteps.length > 1) {
            const baseZoom = this.getBaseZoom();
            let zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(zoomSteps) * baseZoom;
            for(let i = 1; i < zoomSteps.length; i++){
                const z1 = zoomSteps[i - 1] * baseZoom;
                const z2 = zoomSteps[i] * baseZoom;
                if (z2 - cz <= (z2 - z1) / 2) continue;
                zoom = z2;
                break;
            }
            this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + (point.x / zoom - point.x) - (point.x / cz - point.x), cy + (point.y / zoom - point.y) - (point.y / cz - point.y), zoom), opts);
        }
        return this;
    }
    /**
   * Zoom the camera out.
   *
   * @example
   * ```ts
   * editor.zoomOut()
   * editor.zoomOut(editor.getViewportScreenCenter(), { animation: { duration: 120 } })
   * editor.zoomOut(editor.inputs.getCurrentScreenPoint(), { animation: { duration: 120 } })
   * ```
   *
   * @param point - The point to zoom out on. Defaults to the viewport screen center.
   * @param opts - The camera move options.
   *
   * @public
   */ zoomOut(point = this.getViewportScreenCenter(), opts) {
        const { isLocked } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const { zoomSteps } = this.getCameraOptions();
        if (zoomSteps !== null && zoomSteps.length > 1) {
            const baseZoom = this.getBaseZoom();
            const { x: cx, y: cy, z: cz } = this.getCamera();
            let zoom = zoomSteps[0] * baseZoom;
            for(let i = zoomSteps.length - 1; i > 0; i--){
                const z1 = zoomSteps[i - 1] * baseZoom;
                const z2 = zoomSteps[i] * baseZoom;
                if (z2 - cz >= (z2 - z1) / 2) continue;
                zoom = z1;
                break;
            }
            this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + (point.x / zoom - point.x) - (point.x / cz - point.x), cy + (point.y / zoom - point.y) - (point.y / cz - point.y), zoom), opts);
        }
        return this;
    }
    /**
   * Zoom the camera to fit the current selection in the viewport.
   *
   * @example
   * ```ts
   * editor.zoomToSelection()
   * editor.zoomToSelection({ animation: { duration: 200 } })
   * ```
   *
   * @param opts - The camera move options.
   *
   * @public
   */ zoomToSelection(opts) {
        const { isLocked } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const selectionPageBounds = this.getSelectionPageBounds();
        if (selectionPageBounds) {
            const currentZoom = this.getZoomLevel();
            if (Math.abs(currentZoom - 1) < 0.01) {
                this.zoomToBounds(selectionPageBounds, opts);
            } else {
                this.zoomToBounds(selectionPageBounds, {
                    targetZoom: 1,
                    ...opts
                });
            }
        }
        return this;
    }
    /**
   * Zoom the camera to the current selection if offscreen.
   *
   * @public
   */ zoomToSelectionIfOffscreen(padding = 16, opts) {
        const selectionPageBounds = this.getSelectionPageBounds();
        const viewportPageBounds = this.getViewportPageBounds();
        if (selectionPageBounds && !viewportPageBounds.contains(selectionPageBounds)) {
            const eb = selectionPageBounds.clone().expandBy(padding / this.getZoomLevel()).expand(viewportPageBounds);
            const nextBounds = viewportPageBounds.clone().translate({
                x: (eb.center.x - viewportPageBounds.center.x) * 2,
                y: (eb.center.y - viewportPageBounds.center.y) * 2
            });
            this.zoomToBounds(nextBounds, opts);
        }
    }
    /**
   * Zoom the camera to fit a bounding box (in the current page space).
   *
   * @example
   * ```ts
   * editor.zoomToBounds(myBounds)
   * editor.zoomToBounds(myBounds, { animation: { duration: 200 } })
   * editor.zoomToBounds(myBounds, { animation: { duration: 200 }, inset: 0, targetZoom: 1 })
   * ```
   *
   * @param bounds - The bounding box.
   * @param opts - The camera move options, target zoom, or custom inset amount.
   *
   * @public
   */ zoomToBounds(bounds, opts) {
        const cameraOptions = this._cameraOptions.__unsafe__getWithoutCapture();
        if (cameraOptions.isLocked && !opts?.force) return this;
        const viewportScreenBounds = this.getViewportScreenBounds();
        const inset = opts?.inset ?? Math.min(this.options.zoomToFitPadding, viewportScreenBounds.width * 0.28);
        const baseZoom = this.getBaseZoom();
        const zoomMin = cameraOptions.zoomSteps[0];
        const zoomMax = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(cameraOptions.zoomSteps);
        let zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(Math.min((viewportScreenBounds.width - inset) / bounds.w, (viewportScreenBounds.height - inset) / bounds.h), zoomMin * baseZoom, zoomMax * baseZoom);
        if (opts?.targetZoom !== void 0) {
            zoom = Math.min(opts.targetZoom, zoom);
        }
        this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-bounds.x + (viewportScreenBounds.width - bounds.w * zoom) / 2 / zoom, -bounds.y + (viewportScreenBounds.height - bounds.h * zoom) / 2 / zoom, zoom), opts);
        return this;
    }
    /**
   * Stop the current camera animation, if any.
   *
   * @example
   * ```ts
   * editor.stopCameraAnimation()
   * ```
   *
   * @public
   */ stopCameraAnimation() {
        this.emit("stop-camera-animation");
        return this;
    }
    /** @internal */ _animateViewport(ms) {
        if (!this._viewportAnimation) return;
        this._viewportAnimation.elapsed += ms;
        const { elapsed, easing, duration, start, end } = this._viewportAnimation;
        if (elapsed > duration) {
            this.off("tick", this._animateViewport);
            this._viewportAnimation = null;
            this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-end.x, -end.y, this.getViewportScreenBounds().width / end.width));
            return;
        }
        const remaining = duration - elapsed;
        const t = easing(1 - remaining / duration);
        const left = start.minX + (end.minX - start.minX) * t;
        const top = start.minY + (end.minY - start.minY) * t;
        const right = start.maxX + (end.maxX - start.maxX) * t;
        this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-left, -top, this.getViewportScreenBounds().width / (right - left)), {
            force: true
        });
    }
    /** @internal */ _animateToViewport(targetViewportPage, opts = {
        animation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ANIMATION_OPTIONS"]
    }) {
        const { animation, ...rest } = opts;
        if (!animation) return;
        const { duration = 0, easing = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].easeInOutCubic } = animation;
        const animationSpeed = this.user.getAnimationSpeed();
        const viewportPageBounds = this.getViewportPageBounds();
        this.stopCameraAnimation();
        if (this.getInstanceState().followingUserId) {
            this.stopFollowingUser();
        }
        if (duration === 0 || animationSpeed === 0) {
            return this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-targetViewportPage.x, -targetViewportPage.y, this.getViewportScreenBounds().width / targetViewportPage.width), {
                ...rest
            });
        }
        this._viewportAnimation = {
            elapsed: 0,
            duration: duration / animationSpeed,
            easing,
            start: viewportPageBounds.clone(),
            end: targetViewportPage.clone()
        };
        this.once("stop-camera-animation", ()=>{
            this.off("tick", this._animateViewport);
            this._viewportAnimation = null;
        });
        this.on("tick", this._animateViewport);
        return this;
    }
    /**
   * Slide the camera in a certain direction.
   *
   * @example
   * ```ts
   * editor.slideCamera({ speed: 1, direction: { x: 1, y: 0 }, friction: 0.1 })
   * ```
   *
   * @param opts - Options for the slide
   * @public
   */ slideCamera(opts = {}) {
        const { isLocked } = this.getCameraOptions();
        if (isLocked && !opts?.force) return this;
        const animationSpeed = this.user.getAnimationSpeed();
        if (animationSpeed === 0) return this;
        this.stopCameraAnimation();
        const { speed, friction = this.options.cameraSlideFriction, direction, speedThreshold = 0.01 } = opts;
        let currentSpeed = Math.min(speed, 1);
        const cancel = ()=>{
            this.off("tick", moveCamera);
            this.off("stop-camera-animation", cancel);
        };
        this.once("stop-camera-animation", cancel);
        const moveCamera = (elapsed)=>{
            const { x: cx, y: cy, z: cz } = this.getCamera();
            const movementVec = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Mul(direction, currentSpeed * elapsed / cz);
            currentSpeed *= 1 - friction;
            if (currentSpeed < speedThreshold) {
                cancel();
            } else {
                this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + movementVec.x, cy + movementVec.y, cz));
            }
        };
        this.on("tick", moveCamera);
        return this;
    }
    /**
   * Animate the camera to a user's cursor position. This also briefly show the user's cursor if it's not currently visible.
   *
   * @example
   * ```ts
   * editor.zoomToUser(myUserId)
   * editor.zoomToUser(myUserId, { animation: { duration: 200 } })
   * ```
   *
   * @param userId - The id of the user to animate to.
   * @param opts - The camera move options.
   * @public
   */ zoomToUser(userId, opts = {
        animation: {
            duration: 500
        }
    }) {
        const presence = this.getCollaborators().find((c)=>c.userId === userId);
        if (!presence) return this;
        const cursor = presence.cursor;
        if (!cursor) return this;
        this.run(()=>{
            if (this.getInstanceState().followingUserId !== null) {
                this.stopFollowingUser();
            }
            const isOnSamePage = presence.currentPageId === this.getCurrentPageId();
            if (!isOnSamePage) {
                this.setCurrentPage(presence.currentPageId);
            }
            if (opts && opts.animation && !isOnSamePage) {
                opts.animation = void 0;
            }
            this.centerOnPoint(cursor, opts);
            const { highlightedUserIds } = this.getInstanceState();
            this.updateInstanceState({
                highlightedUserIds: [
                    ...highlightedUserIds,
                    userId
                ]
            });
            this.timers.setTimeout(()=>{
                const highlightedUserIds2 = [
                    ...this.getInstanceState().highlightedUserIds
                ];
                const index = highlightedUserIds2.indexOf(userId);
                if (index < 0) return;
                highlightedUserIds2.splice(index, 1);
                this.updateInstanceState({
                    highlightedUserIds: highlightedUserIds2
                });
            }, this.options.collaboratorIdleTimeoutMs);
        });
        return this;
    }
    /**
   * Update the viewport. The viewport will measure the size and screen position of its container
   * element. This should be done whenever the container's position on the screen changes.
   *
   * @example
   * ```ts
   * editor.updateViewportScreenBounds(new Box(0, 0, 1280, 1024))
   * editor.updateViewportScreenBounds(new Box(0, 0, 1280, 1024), true)
   * ```
   *
   * @param screenBounds - The new screen bounds of the viewport.
   * @param center - Whether to preserve the viewport page center as the viewport changes.
   *
   * @public
   */ updateViewportScreenBounds(screenBounds, center = false) {
        if (!(screenBounds instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"])) {
            const rect = screenBounds.getBoundingClientRect();
            screenBounds = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](rect.left || rect.x, rect.top || rect.y, Math.max(rect.width, 1), Math.max(rect.height, 1));
        } else {
            screenBounds.width = Math.max(screenBounds.width, 1);
            screenBounds.height = Math.max(screenBounds.height, 1);
        }
        const insets = [
            // top
            screenBounds.minY !== 0,
            // right
            !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(document.body.scrollWidth, screenBounds.maxX, 1),
            // bottom
            !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])(document.body.scrollHeight, screenBounds.maxY, 1),
            // left
            screenBounds.minX !== 0
        ];
        const { _willSetInitialBounds } = this;
        this._willSetInitialBounds = false;
        const { screenBounds: prevScreenBounds, insets: prevInsets } = this.getInstanceState();
        if (screenBounds.equals(prevScreenBounds) && insets.every((v, i)=>v === prevInsets[i])) {
            return this;
        }
        if (_willSetInitialBounds) {
            this.updateInstanceState({
                screenBounds: screenBounds.toJson(),
                insets
            });
            this.emit("resize", screenBounds.toJson());
            this.setCamera(this.getCamera());
        } else {
            if (center && !this.getInstanceState().followingUserId) {
                const before = this.getViewportPageBounds().center;
                this.updateInstanceState({
                    screenBounds: screenBounds.toJson(),
                    insets
                });
                this.emit("resize", screenBounds.toJson());
                this.centerOnPoint(before);
            } else {
                this.updateInstanceState({
                    screenBounds: screenBounds.toJson(),
                    insets
                });
                this.emit("resize", screenBounds.toJson());
                this._setCamera(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From({
                    ...this.getCamera()
                }));
            }
        }
        return this;
    }
    getViewportScreenBounds() {
        const { x: x1, y, w, h } = this.getInstanceState().screenBounds;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](x1, y, w, h);
    }
    getViewportScreenCenter() {
        const viewportScreenBounds = this.getViewportScreenBounds();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](viewportScreenBounds.w / 2, viewportScreenBounds.h / 2);
    }
    getViewportPageBounds() {
        const { w, h } = this.getViewportScreenBounds();
        const { x: cx, y: cy, z: cz } = this.getCamera();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](-cx, -cy, w / cz, h / cz);
    }
    /**
   * Convert a point in screen space to a point in the current page space.
   *
   * @example
   * ```ts
   * editor.screenToPage({ x: 100, y: 100 })
   * ```
   *
   * @param point - The point in screen space.
   *
   * @public
   */ screenToPage(point) {
        const { screenBounds } = this.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        const { x: cx, y: cy, z: cz = 1 } = this.getCamera();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((point.x - screenBounds.x) / cz - cx, (point.y - screenBounds.y) / cz - cy, point.z ?? 0.5);
    }
    /**
   * Convert a point in the current page space to a point in current screen space.
   *
   * @example
   * ```ts
   * editor.pageToScreen({ x: 100, y: 100 })
   * ```
   *
   * @param point - The point in page space.
   *
   * @public
   */ pageToScreen(point) {
        const { screenBounds } = this.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        const { x: cx, y: cy, z: cz = 1 } = this.getCamera();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((point.x + cx) * cz + screenBounds.x, (point.y + cy) * cz + screenBounds.y, point.z ?? 0.5);
    }
    /**
   * Convert a point in the current page space to a point in current viewport space.
   *
   * @example
   * ```ts
   * editor.pageToViewport({ x: 100, y: 100 })
   * ```
   *
   * @param point - The point in page space.
   *
   * @public
   */ pageToViewport(point) {
        const { x: cx, y: cy, z: cz = 1 } = this.getCamera();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]((point.x + cx) * cz, (point.y + cy) * cz, point.z ?? 0.5);
    }
    _getCollaboratorsQuery() {
        return this.store.query.records("instance_presence", ()=>({
                userId: {
                    neq: this.user.getId()
                }
            }));
    }
    getCollaborators() {
        const allPresenceRecords = this._getCollaboratorsQuery().get();
        if (!allPresenceRecords.length) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
        const userIds = [
            ...new Set(allPresenceRecords.map((c)=>c.userId))
        ].sort();
        return userIds.map((id)=>{
            const latestPresence = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maxBy"])(allPresenceRecords.filter((c)=>c.userId === id), (p)=>p.lastActivityTimestamp ?? 0);
            return latestPresence;
        });
    }
    getCollaboratorsOnCurrentPage() {
        const currentPageId = this.getCurrentPageId();
        return this.getCollaborators().filter((c)=>c.currentPageId === currentPageId);
    }
    /**
   * Start viewport-following a user.
   *
   * @example
   * ```ts
   * editor.startFollowingUser(myUserId)
   * ```
   *
   * @param userId - The id of the user to follow.
   *
   * @public
   */ startFollowingUser(userId) {
        this.stopFollowingUser();
        const thisUserId = this.user.getId();
        if (!thisUserId) {
            console.warn("You should set the userId for the current instance before following a user");
        }
        const leaderPresence = this._getFollowingPresence(userId);
        if (!leaderPresence) {
            return this;
        }
        const latestLeaderPresence = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("latestLeaderPresence", ()=>{
            return this._getFollowingPresence(userId);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$transactions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"])(()=>{
            this.updateInstanceState({
                followingUserId: userId
            }, {
                history: "ignore"
            });
            const dispose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("update current page", ()=>{
                const leaderPresence2 = latestLeaderPresence.get();
                if (!leaderPresence2) {
                    this.stopFollowingUser();
                    return;
                }
                if (leaderPresence2.currentPageId !== this.getCurrentPageId() && this.getPage(leaderPresence2.currentPageId)) {
                    this.run(()=>{
                        this.store.put([
                            {
                                ...this.getInstanceState(),
                                currentPageId: leaderPresence2.currentPageId
                            }
                        ]);
                        this._isLockedOnFollowingUser.set(true);
                    }, {
                        history: "ignore"
                    });
                }
            });
            const cancel = ()=>{
                dispose();
                this._isLockedOnFollowingUser.set(false);
                this.off("frame", moveTowardsUser);
                this.off("stop-following", cancel);
            };
            const moveTowardsUser = ()=>{
                const leaderPresence2 = latestLeaderPresence.get();
                if (!leaderPresence2) {
                    this.stopFollowingUser();
                    return;
                }
                if (this._isLockedOnFollowingUser.get()) return;
                const animationSpeed = this.user.getAnimationSpeed();
                if (animationSpeed === 0) {
                    this._isLockedOnFollowingUser.set(true);
                    return;
                }
                const targetViewport = this.getViewportPageBoundsForFollowing();
                if (!targetViewport) {
                    this.stopFollowingUser();
                    return;
                }
                const currentViewport = this.getViewportPageBounds();
                const diffX = Math.abs(targetViewport.minX - currentViewport.minX) + Math.abs(targetViewport.maxX - currentViewport.maxX);
                const diffY = Math.abs(targetViewport.minY - currentViewport.minY) + Math.abs(targetViewport.maxY - currentViewport.maxY);
                if (diffX < this.options.followChaseViewportSnap && diffY < this.options.followChaseViewportSnap) {
                    this._isLockedOnFollowingUser.set(true);
                    return;
                }
                const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(animationSpeed * 0.5, 0.1, 0.8);
                const nextViewport = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(currentViewport.minX, targetViewport.minX, t), (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(currentViewport.minY, targetViewport.minY, t), (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(currentViewport.width, targetViewport.width, t), (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(currentViewport.height, targetViewport.height, t));
                const nextCamera = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-nextViewport.x, -nextViewport.y, this.getViewportScreenBounds().width / nextViewport.width);
                this.stopCameraAnimation();
                this._setCamera(nextCamera);
            };
            this.once("stop-following", cancel);
            this.addListener("frame", moveTowardsUser);
            moveTowardsUser();
        });
        return this;
    }
    /**
   * Stop viewport-following a user.
   *
   * @example
   * ```ts
   * editor.stopFollowingUser()
   * ```
   * @public
   */ stopFollowingUser() {
        this.run(()=>{
            this.store.put([
                this.getCamera()
            ]);
            this._isLockedOnFollowingUser.set(false);
            this.updateInstanceState({
                followingUserId: null
            });
            this.emit("stop-following");
        }, {
            history: "ignore"
        });
        return this;
    }
    /** @internal */ getUnorderedRenderingShapes(useEditorState) {
        const renderingShapes = [];
        let nextIndex = this.options.maxShapesPerPage * 2;
        let nextBackgroundIndex = this.options.maxShapesPerPage;
        const erasingShapeIds = this.getErasingShapeIds();
        const addShapeById = (id, opacity, isAncestorErasing)=>{
            const shape = this.getShape(id);
            if (!shape) return;
            if (this.isShapeHidden(shape)) {
                const isErasing = isAncestorErasing || erasingShapeIds.includes(id);
                for (const childId of this.getSortedChildIdsForParent(id)){
                    addShapeById(childId, opacity, isErasing);
                }
                return;
            }
            opacity *= shape.opacity;
            let isShapeErasing = false;
            const util = this.getShapeUtil(shape);
            if (useEditorState) {
                isShapeErasing = !isAncestorErasing && erasingShapeIds.includes(id);
                if (isShapeErasing) {
                    opacity *= 0.32;
                }
            }
            renderingShapes.push({
                id,
                shape,
                util,
                index: nextIndex,
                backgroundIndex: nextBackgroundIndex,
                opacity
            });
            nextIndex += 1;
            nextBackgroundIndex += 1;
            const childIds = this.getSortedChildIdsForParent(id);
            if (!childIds.length) return;
            let backgroundIndexToRestore = null;
            if (util.providesBackgroundForChildren(shape)) {
                backgroundIndexToRestore = nextBackgroundIndex;
                nextBackgroundIndex = nextIndex;
                nextIndex += this.options.maxShapesPerPage;
            }
            for (const childId of childIds){
                addShapeById(childId, opacity, isAncestorErasing || isShapeErasing);
            }
            if (backgroundIndexToRestore !== null) {
                nextBackgroundIndex = backgroundIndexToRestore;
            }
        };
        const pages = useEditorState ? [
            this.getCurrentPage()
        ] : this.getPages();
        for (const page of pages){
            for (const childId of this.getSortedChildIdsForParent(page.id)){
                addShapeById(childId, 1, false);
            }
        }
        return renderingShapes;
    }
    _decayCameraStateTimeout(elapsed) {
        this._cameraStateTimeoutRemaining -= elapsed;
        if (this._cameraStateTimeoutRemaining > 0) return;
        this.off("tick", this._decayCameraStateTimeout);
        this._setCameraState("idle");
    }
    _tickCameraState() {
        this._cameraStateTimeoutRemaining = this.options.cameraMovingTimeoutMs;
        if (this.getInstanceState().cameraState !== "idle") return;
        this._setCameraState("moving");
        this._debouncedZoomLevel.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafe__withoutCapture"])(()=>this.getCamera().z));
        this.on("tick", this._decayCameraStateTimeout);
    }
    _setCameraState(cameraState) {
        this.updateInstanceState({
            cameraState
        }, {
            history: "ignore"
        });
    }
    /**
   * Whether the camera is moving or idle.
   *
   * @example
   * ```ts
   * editor.getCameraState()
   * ```
   *
   * @public
   */ getCameraState() {
        return this.getInstanceState().cameraState;
    }
    getRenderingShapes() {
        const renderingShapes = this.getUnorderedRenderingShapes(true);
        return renderingShapes.sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$sort$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortById"]);
    }
    _getAllPagesQuery() {
        return this.store.query.records("page");
    }
    getPages() {
        return Array.from(this._getAllPagesQuery().get()).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
    }
    /**
   * The current page.
   *
   * @example
   * ```ts
   * editor.getCurrentPage()
   * ```
   *
   * @public
   */ getCurrentPage() {
        return this.getPage(this.getCurrentPageId());
    }
    getCurrentPageId() {
        return this.getInstanceState().currentPageId;
    }
    /**
   * Get a page.
   *
   * @example
   * ```ts
   * editor.getPage(myPage.id)
   * editor.getPage(myPage)
   * ```
   *
   * @param page - The page (or the page id) to get.
   *
   * @public
   */ getPage(page) {
        return this.store.get(typeof page === "string" ? page : page.id);
    }
    /**
   * An array of all of the shapes on the current page.
   *
   * @example
   * ```ts
   * editor.getCurrentPageIds()
   * ```
   *
   * @public
   */ getCurrentPageShapeIds() {
        return this._currentPageShapeIds.get();
    }
    getCurrentPageShapeIdsSorted() {
        return Array.from(this.getCurrentPageShapeIds()).sort();
    }
    /**
   * Get the ids of shapes on a page.
   *
   * @example
   * ```ts
   * const idsOnPage1 = editor.getPageShapeIds('page1')
   * const idsOnPage2 = editor.getPageShapeIds(myPage2)
   * ```
   *
   * @param page - The page (or the page id) to get the shape ids for.
   *
   * @public
   **/ getPageShapeIds(page) {
        const pageId = typeof page === "string" ? page : page.id;
        const result = this.store.query.exec("shape", {
            parentId: {
                eq: pageId
            }
        });
        return this.getShapeAndDescendantIds(result.map((s)=>s.id));
    }
    /**
   * Set the current page.
   *
   * @example
   * ```ts
   * editor.setCurrentPage('page1')
   * editor.setCurrentPage(myPage1)
   * ```
   *
   * @param page - The page (or the page id) to set as the current page.
   *
   * @public
   */ setCurrentPage(page) {
        const pageId = typeof page === "string" ? page : page.id;
        if (!this.store.has(pageId)) {
            console.error("Tried to set the current page id to a page that doesn't exist.");
            return this;
        }
        this.stopFollowingUser();
        this.complete();
        return this.run(()=>{
            this.store.put([
                {
                    ...this.getInstanceState(),
                    currentPageId: pageId
                }
            ]);
            this.setCamera(this.getCamera());
        }, {
            history: "record-preserveRedoStack"
        });
    }
    /**
   * Update a page.
   *
   * @example
   * ```ts
   * editor.updatePage({ id: 'page2', name: 'Page 2' })
   * ```
   *
   * @param partial - The partial of the shape to update.
   *
   * @public
   */ updatePage(partial) {
        if (this.getIsReadonly()) return this;
        const prev = this.getPage(partial.id);
        if (!prev) return this;
        return this.run(()=>this.store.update(partial.id, (page)=>({
                    ...page,
                    ...partial
                })));
    }
    /**
   * Create a page whilst ensuring that the page name is unique.
   *
   * @example
   * ```ts
   * editor.createPage(myPage)
   * editor.createPage({ name: 'Page 2' })
   * ```
   *
   * @param page - The page (or page partial) to create.
   *
   * @public
   */ createPage(page) {
        this.run(()=>{
            if (this.getIsReadonly()) return;
            if (this.getPages().length >= this.options.maxPages) return;
            const pages = this.getPages();
            const name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$getIncrementedName$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIncrementedName"])(page.name ?? "Page 1", pages.map((p)=>p.name));
            let index = page.index;
            if (!index || pages.some((p)=>p.index === index)) {
                index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(pages[pages.length - 1].index);
            }
            const newPage = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].create({
                meta: {},
                ...page,
                name,
                index
            });
            this.store.put([
                newPage
            ]);
        });
        return this;
    }
    /**
   * Delete a page.
   *
   * @example
   * ```ts
   * editor.deletePage('page1')
   * ```
   *
   * @param page - The page (or the page id) to delete.
   *
   * @public
   */ deletePage(page) {
        const id = typeof page === "string" ? page : page.id;
        this.run(()=>{
            if (this.getIsReadonly()) return;
            const pages = this.getPages();
            if (pages.length === 1) return;
            const deletedPage = this.getPage(id);
            if (!deletedPage) return;
            if (id === this.getCurrentPageId()) {
                const index = pages.findIndex((page2)=>page2.id === id);
                const next = pages[index - 1] ?? pages[index + 1];
                this.setCurrentPage(next.id);
            }
            const shapes = this.getSortedChildIdsForParent(deletedPage.id);
            this.deleteShapes(shapes);
            this.store.remove([
                deletedPage.id
            ]);
        }, {
            ignoreShapeLock: true
        });
        return this;
    }
    /**
   * Duplicate a page.
   *
   * @param page - The page (or the page id) to duplicate. Defaults to the current page.
   * @param createId - The id of the new page. Defaults to a new id.
   *
   * @public
   */ duplicatePage(page, createId = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRecordType"].createId()) {
        if (this.getPages().length >= this.options.maxPages) return this;
        const id = typeof page === "string" ? page : page.id;
        const freshPage = this.getPage(id);
        if (!freshPage) return this;
        const prevCamera = {
            ...this.getCamera()
        };
        const content = this.getContentFromCurrentPage(this.getSortedChildIdsForParent(freshPage.id));
        this.run(()=>{
            const pages = this.getPages();
            const index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexBetween"])(freshPage.index, pages[pages.indexOf(freshPage) + 1]?.index);
            this.createPage({
                name: freshPage.name + " Copy",
                id: createId,
                index
            });
            this.setCurrentPage(createId);
            this.setCamera(prevCamera);
            if (content) {
                return this.putContentOntoCurrentPage(content);
            }
        });
        return this;
    }
    /**
   * Rename a page.
   *
   * @example
   * ```ts
   * editor.renamePage('page1', 'My Page')
   * ```
   *
   * @param page - The page (or the page id) to rename.
   * @param name - The new name.
   *
   * @public
   */ renamePage(page, name) {
        const id = typeof page === "string" ? page : page.id;
        if (this.getIsReadonly()) return this;
        this.updatePage({
            id,
            name
        });
        return this;
    }
    _getAllAssetsQuery() {
        return this.store.query.records("asset");
    }
    /**
   * Get all assets in the editor.
   *
   * @public
   */ getAssets() {
        return this._getAllAssetsQuery().get();
    }
    /**
   * Create one or more assets.
   *
   * @example
   * ```ts
   * editor.createAssets([...myAssets])
   * ```
   *
   * @param assets - The assets to create.
   *
   * @public
   */ createAssets(assets) {
        if (this.getIsReadonly()) return this;
        if (assets.length <= 0) return this;
        this.run(()=>this.store.put(assets), {
            history: "ignore"
        });
        return this;
    }
    /**
   * Update one or more assets.
   *
   * @example
   * ```ts
   * editor.updateAssets([{ id: 'asset1', name: 'New name' }])
   * ```
   *
   * @param assets - The assets to update.
   *
   * @public
   */ updateAssets(assets) {
        if (this.getIsReadonly()) return this;
        if (assets.length <= 0) return this;
        this.run(()=>{
            this.store.put(assets.map((partial)=>({
                    ...this.store.get(partial.id),
                    ...partial
                })));
        }, {
            history: "ignore"
        });
        return this;
    }
    /**
   * Delete one or more assets.
   *
   * @example
   * ```ts
   * editor.deleteAssets(['asset1', 'asset2'])
   * ```
   *
   * @param assets - The assets (or asset ids) to delete.
   *
   * @public
   */ deleteAssets(assets) {
        if (this.getIsReadonly()) return this;
        const ids = typeof assets[0] === "string" ? assets : assets.map((a)=>a.id);
        if (ids.length <= 0) return this;
        this.run(()=>{
            this.store.props.assets.remove?.(ids);
            this.store.remove(ids);
        }, {
            history: "ignore"
        });
        return this;
    }
    /**
   * Get an asset by its id.
   *
   * @example
   * ```ts
   * editor.getAsset('asset1')
   * ```
   *
   * @param asset - The asset (or asset id) to get.
   *
   * @public
   */ getAsset(asset) {
        return this.store.get(typeof asset === "string" ? asset : asset.id);
    }
    async resolveAssetUrl(assetId, context) {
        if (!assetId) return null;
        const asset = this.getAsset(assetId);
        if (!asset) return null;
        const { screenScale = 1, shouldResolveToOriginal = false, dpr = this.getInstanceState().devicePixelRatio } = context;
        const zoomStepFunction = (zoom)=>Math.pow(2, Math.ceil(Math.log2(zoom)));
        const steppedScreenScale = zoomStepFunction(screenScale);
        const networkEffectiveType = "connection" in navigator ? navigator.connection.effectiveType : null;
        return await this.store.props.assets.resolve(asset, {
            screenScale: screenScale || 1,
            steppedScreenScale,
            dpr,
            networkEffectiveType,
            shouldResolveToOriginal
        });
    }
    /**
   * Upload an asset to the store's asset service, returning a URL that can be used to resolve the
   * asset.
   */ async uploadAsset(asset, file, abortSignal) {
        return await this.store.props.assets.upload(asset, file, abortSignal);
    }
    /**
   * Get the geometry of a shape in shape-space.
   *
   * @example
   * ```ts
   * editor.getShapeGeometry(myShape)
   * editor.getShapeGeometry(myShapeId)
   * editor.getShapeGeometry(myShapeId, { context: "arrow" })
   * ```
   *
   * @param shape - The shape (or shape id) to get the geometry for.
   * @param opts - Additional options about the request for geometry. Passed to {@link ShapeUtil.getGeometry}.
   *
   * @public
   */ getShapeGeometry(shape, opts) {
        const context = opts?.context ?? "none";
        if (!this._shapeGeometryCaches[context]) {
            this._shapeGeometryCaches[context] = this.store.createComputedCache("bounds", (shape2)=>{
                this.fonts.trackFontsForShape(shape2);
                return this.getShapeUtil(shape2).getGeometry(shape2, opts);
            }, {
                areRecordsEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$areShapesContentEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areShapesContentEqual"]
            });
        }
        return this._shapeGeometryCaches[context].get(typeof shape === "string" ? shape : shape.id);
    }
    _getShapeHandlesCache() {
        return this.store.createComputedCache("handles", (shape)=>{
            return this.getShapeUtil(shape).getHandles?.(shape);
        }, {
            areRecordsEqual: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$areShapesContentEqual$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areShapesContentEqual"]
        });
    }
    /**
   * Get the handles (if any) for a shape.
   *
   * @example
   * ```ts
   * editor.getShapeHandles(myShape)
   * editor.getShapeHandles(myShapeId)
   * ```
   *
   * @param shape - The shape (or shape id) to get the handles for.
   * @public
   */ getShapeHandles(shape) {
        return this._getShapeHandlesCache().get(typeof shape === "string" ? shape : shape.id);
    }
    /**
   * Get the local transform for a shape as a matrix model. This transform reflects both its
   * translation (x, y) from from either its parent's top left corner, if the shape's parent is
   * another shape, or else from the 0,0 of the page, if the shape's parent is the page; and the
   * shape's rotation.
   *
   * @example
   * ```ts
   * editor.getShapeLocalTransform(myShape)
   * ```
   *
   * @param shape - The shape to get the local transform for.
   *
   * @public
   */ getShapeLocalTransform(shape) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        if (!freshShape) throw Error("Editor.getTransform: shape not found");
        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity().translate(freshShape.x, freshShape.y).rotate(freshShape.rotation);
    }
    _getShapePageTransformCache() {
        return this.store.createComputedCache("pageTransformCache", (shape)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape.parentId)) {
                return this.getShapeLocalTransform(shape);
            }
            const parentTransform = this._getShapePageTransformCache().get(shape.parentId) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity();
            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Compose(parentTransform, this.getShapeLocalTransform(shape));
        });
    }
    /**
   * Get the local transform of a shape's parent as a matrix model.
   *
   * @example
   * ```ts
   * editor.getShapeParentTransform(myShape)
   * ```
   *
   * @param shape - The shape (or shape id) to get the parent transform for.
   *
   * @public
   */ getShapeParentTransform(shape) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        if (!freshShape || (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(freshShape.parentId)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity();
        return this._getShapePageTransformCache().get(freshShape.parentId) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity();
    }
    /**
   * Get the transform of a shape in the current page space.
   *
   * @example
   * ```ts
   * editor.getShapePageTransform(myShape)
   * editor.getShapePageTransform(myShapeId)
   * ```
   *
   * @param shape - The shape (or shape id) to get the page transform for.
   *
   * @public
   */ getShapePageTransform(shape) {
        const id = typeof shape === "string" ? shape : shape.id;
        return this._getShapePageTransformCache().get(id) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity();
    }
    _getShapePageBoundsCache() {
        return this.store.createComputedCache("pageBoundsCache", (shape)=>{
            const pageTransform = this.getShapePageTransform(shape);
            if (!pageTransform) return void 0;
            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(pageTransform.applyToPoints(this.getShapeGeometry(shape).boundsVertices));
        });
    }
    /**
   * Get the bounds of a shape in the current page space.
   *
   * @example
   * ```ts
   * editor.getShapePageBounds(myShape)
   * editor.getShapePageBounds(myShapeId)
   * ```
   *
   * @param shape - The shape (or shape id) to get the bounds for.
   *
   * @public
   */ getShapePageBounds(shape) {
        return this._getShapePageBoundsCache().get(typeof shape === "string" ? shape : shape.id);
    }
    _getShapeClipPathCache() {
        return this.store.createComputedCache("clipPathCache", (shape)=>{
            const pageMask = this._getShapeMaskCache().get(shape.id);
            if (!pageMask) return void 0;
            if (pageMask.length === 0) {
                return `polygon(0px 0px, 0px 0px, 0px 0px)`;
            }
            const pageTransform = this._getShapePageTransformCache().get(shape.id);
            if (!pageTransform) return void 0;
            const localMask = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoints(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Inverse(pageTransform), pageMask);
            return `polygon(${localMask.map((p)=>`${p.x}px ${p.y}px`).join(",")})`;
        });
    }
    /**
   * Get the clip path for a shape.
   *
   * @example
   * ```ts
   * const clipPath = editor.getShapeClipPath(shape)
   * const clipPath = editor.getShapeClipPath(shape.id)
   * ```
   *
   * @param shape - The shape (or shape id) to get the clip path for.
   *
   * @returns The clip path or undefined.
   *
   * @public
   */ getShapeClipPath(shape) {
        return this._getShapeClipPathCache().get(typeof shape === "string" ? shape : shape.id);
    }
    _getShapeMaskCache() {
        return this.store.createComputedCache("pageMaskCache", (shape)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(shape.parentId)) return void 0;
            const clipPaths = [];
            for (const ancestor of this.getShapeAncestors(shape.id)){
                const util = this.getShapeUtil(ancestor);
                const clipPath = util.getClipPath?.(ancestor);
                if (!clipPath) continue;
                if (util.shouldClipChild?.(shape) === false) continue;
                const pageTransform = this.getShapePageTransform(ancestor.id);
                clipPaths.push(pageTransform.applyToPoints(clipPath));
            }
            if (clipPaths.length === 0) return void 0;
            const pageMask = clipPaths.reduce((acc, b)=>{
                const intersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectPolygonPolygon"])(acc, b);
                if (intersection) {
                    return intersection.map(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Cast);
                }
                return [];
            });
            return pageMask;
        });
    }
    /**
   * Get the mask (in the current page space) for a shape.
   *
   * @example
   * ```ts
   * const pageMask = editor.getShapeMask(shape.id)
   * ```
   *
   * @param shape - The shape (or the shape id) of the shape to get the mask for.
   *
   * @returns The mask for the shape.
   *
   * @public
   */ getShapeMask(shape) {
        return this._getShapeMaskCache().get(typeof shape === "string" ? shape : shape.id);
    }
    /**
   * Get the bounds of a shape in the current page space, incorporating any masks. For example, if the
   * shape were the child of a frame and was half way out of the frame, the bounds would be the half
   * of the shape that was in the frame.
   *
   * @example
   * ```ts
   * editor.getShapeMaskedPageBounds(myShape)
   * editor.getShapeMaskedPageBounds(myShapeId)
   * ```
   *
   * @param shape - The shape to get the masked bounds for.
   *
   * @public
   */ getShapeMaskedPageBounds(shape) {
        if (typeof shape !== "string") shape = shape.id;
        return this._getShapeMaskedPageBoundsCache().get(shape);
    }
    _getShapeMaskedPageBoundsCache() {
        return this.store.createComputedCache("shapeMaskedPageBoundsCache", (shape)=>{
            const pageBounds = this._getShapePageBoundsCache().get(shape.id);
            if (!pageBounds) return;
            const pageMask = this._getShapeMaskCache().get(shape.id);
            if (pageMask) {
                if (pageMask.length === 0) return void 0;
                const { corners } = pageBounds;
                if (corners.every((p, i)=>p && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Equals(p, pageMask[i]))) return pageBounds.clone();
                const intersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$intersect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersectPolygonPolygon"])(pageMask, corners);
                if (!intersection) return;
                return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].FromPoints(intersection);
            }
            return pageBounds;
        });
    }
    /**
   * Get the ancestors of a shape.
   *
   * @example
   * ```ts
   * const ancestors = editor.getShapeAncestors(myShape)
   * const ancestors = editor.getShapeAncestors(myShapeId)
   * ```
   *
   * @param shape - The shape (or shape id) to get the ancestors for.
   * @param acc - The accumulator.
   *
   * @public
   */ getShapeAncestors(shape, acc = []) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        if (!freshShape) return acc;
        const parentId = freshShape.parentId;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(parentId)) {
            acc.reverse();
            return acc;
        }
        const parent = this.store.get(parentId);
        if (!parent) return acc;
        acc.push(parent);
        return this.getShapeAncestors(parent, acc);
    }
    /**
   * Find the first ancestor matching the given predicate
   *
   * @example
   * ```ts
   * const ancestor = editor.findShapeAncestor(myShape)
   * const ancestor = editor.findShapeAncestor(myShape.id)
   * const ancestor = editor.findShapeAncestor(myShape.id, (shape) => shape.type === 'frame')
   * ```
   *
   * @param shape - The shape to check the ancestors for.
   * @param predicate - The predicate to match.
   *
   * @public
   */ findShapeAncestor(shape, predicate) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        if (!freshShape) return;
        const parentId = freshShape.parentId;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(parentId)) return;
        const parent = this.getShape(parentId);
        if (!parent) return;
        return predicate(parent) ? parent : this.findShapeAncestor(parent, predicate);
    }
    /**
   * Returns true if the the given shape has the given ancestor.
   *
   * @param shape - The shape.
   * @param ancestorId - The id of the ancestor.
   *
   * @public
   */ hasAncestor(shape, ancestorId) {
        const id = typeof shape === "string" ? shape : shape?.id;
        const freshShape = id && this.getShape(id);
        if (!freshShape) return false;
        if (freshShape.parentId === ancestorId) return true;
        return this.hasAncestor(this.getShapeParent(freshShape), ancestorId);
    }
    /**
   * Get the common ancestor of two or more shapes that matches a predicate.
   *
   * @param shapes - The shapes (or shape ids) to check.
   * @param predicate - The predicate to match.
   */ findCommonAncestor(shapes, predicate) {
        if (shapes.length === 0) {
            return;
        }
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const freshShapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        if (freshShapes.length === 1) {
            const parentId = freshShapes[0].parentId;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(parentId)) {
                return;
            }
            return predicate ? this.findShapeAncestor(freshShapes[0], predicate)?.id : parentId;
        }
        const [nodeA, ...others] = freshShapes;
        let ancestor = this.getShapeParent(nodeA);
        while(ancestor){
            if (predicate && !predicate(ancestor)) {
                ancestor = this.getShapeParent(ancestor);
                continue;
            }
            if (others.every((shape)=>this.hasAncestor(shape, ancestor.id))) {
                return ancestor.id;
            }
            ancestor = this.getShapeParent(ancestor);
        }
        return void 0;
    }
    /**
   * Check whether a shape or its parent is locked.
   *
   * @param shape - The shape (or shape id) to check.
   *
   * @public
   */ isShapeOrAncestorLocked(shape) {
        const _shape = shape && this.getShape(shape);
        if (_shape === void 0) return false;
        if (_shape.isLocked) return true;
        return this.isShapeOrAncestorLocked(this.getShapeParent(_shape));
    }
    getNotVisibleShapes() {
        return this._notVisibleShapes.get();
    }
    getCulledShapes() {
        const notVisibleShapes2 = this.getNotVisibleShapes();
        const selectedShapeIds = this.getSelectedShapeIds();
        const editingId = this.getEditingShapeId();
        const nextValue = new Set(notVisibleShapes2);
        if (editingId) {
            nextValue.delete(editingId);
        }
        selectedShapeIds.forEach((id)=>{
            nextValue.delete(id);
        });
        const prevValue = this._culledShapesCache;
        if (prevValue) {
            if (prevValue.size !== nextValue.size) {
                this._culledShapesCache = nextValue;
                return nextValue;
            }
            for (const id of prevValue){
                if (!nextValue.has(id)) {
                    this._culledShapesCache = nextValue;
                    return nextValue;
                }
            }
            return prevValue;
        }
        this._culledShapesCache = nextValue;
        return nextValue;
    }
    getCurrentPageBounds() {
        let commonBounds;
        this.getCurrentPageShapeIdsSorted().forEach((shapeId)=>{
            if (this.isShapeHidden(shapeId)) return;
            const bounds = this.getShapeMaskedPageBounds(shapeId);
            if (!bounds) return;
            if (!commonBounds) {
                commonBounds = bounds.clone();
            } else {
                commonBounds = commonBounds.expand(bounds);
            }
        });
        return commonBounds;
    }
    /**
   * Get the top-most selected shape at the given point, ignoring groups.
   *
   * @param point - The point to check.
   *
   * @returns The top-most selected shape at the given point, or undefined if there is no shape at the point.
   */ getSelectedShapeAtPoint(point) {
        const selectedShapeIds = this.getSelectedShapeIds();
        return this.getCurrentPageShapesSorted().filter((shape)=>shape.type !== "group" && selectedShapeIds.includes(shape.id)).reverse().find((shape)=>this.isPointInShape(shape, point, {
                hitInside: true,
                margin: 0
            }));
    }
    /**
   * Get the shape at the current point.
   *
   * @param point - The point to check.
   * @param opts - Options for the check: `hitInside` to check if the point is inside the shape, `margin` to check if the point is within a margin of the shape, `hitFrameInside` to check if the point is inside the frame, and `filter` to filter the shapes to check.
   *
   * @returns The shape at the given point, or undefined if there is no shape at the point.
   */ getShapeAtPoint(point, opts = {}) {
        const zoomLevel = this.getZoomLevel();
        const viewportPageBounds = this.getViewportPageBounds();
        const { filter, margin = 0, hitLocked = false, hitLabels = false, hitInside = false, hitFrameInside = false } = opts;
        const [innerMargin, outerMargin] = Array.isArray(margin) ? margin : [
            margin,
            margin
        ];
        let inHollowSmallestArea = Infinity;
        let inHollowSmallestAreaHit = null;
        let inMarginClosestToEdgeDistance = Infinity;
        let inMarginClosestToEdgeHit = null;
        const searchMargin = Math.max(innerMargin, outerMargin, this.options.hitTestMargin / zoomLevel);
        const candidateIds = this._spatialIndex.getShapeIdsAtPoint(point, searchMargin);
        const shapesToCheck = (opts.renderingOnly ? this.getCurrentPageRenderingShapesSorted() : this.getCurrentPageShapesSorted()).filter((shape)=>{
            if (!candidateIds.has(shape.id) && !this.isShapeOfType(shape, "frame")) return false;
            if (shape.isLocked && !hitLocked || this.isShapeHidden(shape) || this.isShapeOfType(shape, "group")) return false;
            const pageMask = this.getShapeMask(shape);
            if (pageMask && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(point, pageMask)) return false;
            if (filter && !filter(shape)) return false;
            return true;
        });
        for(let i = shapesToCheck.length - 1; i >= 0; i--){
            const shape = shapesToCheck[i];
            const geometry = this.getShapeGeometry(shape);
            const isGroup = geometry instanceof __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Group2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group2d"];
            const pointInShapeSpace = this.getPointInShapeSpace(shape, point);
            if (this.isShapeOfType(shape, "frame") || (this.isShapeOfType(shape, "note") || this.isShapeOfType(shape, "arrow") || this.isShapeOfType(shape, "geo") && shape.props.fill === "none") && this.getShapeUtil(shape).getText(shape)?.trim()) {
                for (const childGeometry of geometry.children){
                    if (childGeometry.isLabel && childGeometry.isPointInBounds(pointInShapeSpace)) {
                        return shape;
                    }
                }
            }
            if (this.isShapeOfType(shape, "frame")) {
                const distance2 = geometry.distanceToPoint(pointInShapeSpace, hitFrameInside);
                if (hitFrameInside ? distance2 > 0 && distance2 <= outerMargin || distance2 <= 0 && distance2 > -innerMargin : distance2 > 0 && distance2 <= outerMargin) {
                    return inMarginClosestToEdgeHit || shape;
                }
                if (geometry.hitTestPoint(pointInShapeSpace, 0, true)) {
                    return inMarginClosestToEdgeHit || inHollowSmallestAreaHit || (hitFrameInside ? shape : void 0);
                }
                continue;
            }
            let distance;
            if (isGroup) {
                let minDistance = Infinity;
                for (const childGeometry of geometry.children){
                    if (childGeometry.isLabel && !hitLabels) continue;
                    const tDistance = childGeometry.distanceToPoint(pointInShapeSpace, hitInside);
                    if (tDistance < minDistance) {
                        minDistance = tDistance;
                    }
                }
                distance = minDistance;
            } else {
                if (outerMargin === 0 && (geometry.bounds.w < 1 || geometry.bounds.h < 1)) {
                    distance = geometry.distanceToPoint(pointInShapeSpace, hitInside);
                } else {
                    if (geometry.bounds.containsPoint(pointInShapeSpace, outerMargin)) {
                        distance = geometry.distanceToPoint(pointInShapeSpace, hitInside);
                    } else {
                        distance = Infinity;
                    }
                }
            }
            if (geometry.isClosed) {
                if (distance <= outerMargin || hitInside && distance <= 0 && distance > -innerMargin) {
                    if (geometry.isFilled || isGroup && geometry.children[0].isFilled) {
                        return inMarginClosestToEdgeHit || shape;
                    } else {
                        if (this.getShapePageBounds(shape).contains(viewportPageBounds)) continue;
                        if (hitInside ? distance > 0 && distance <= outerMargin || distance <= 0 && distance > -innerMargin : Math.abs(distance) <= Math.max(innerMargin, outerMargin)) {
                            if (Math.abs(distance) < inMarginClosestToEdgeDistance) {
                                inMarginClosestToEdgeDistance = Math.abs(distance);
                                inMarginClosestToEdgeHit = shape;
                            }
                        } else if (!inMarginClosestToEdgeHit) {
                            const { area } = geometry;
                            if (area < inHollowSmallestArea) {
                                inHollowSmallestArea = area;
                                inHollowSmallestAreaHit = shape;
                            }
                        }
                    }
                }
            } else {
                if (distance < this.options.hitTestMargin / zoomLevel) {
                    return shape;
                }
            }
        }
        return inMarginClosestToEdgeHit || inHollowSmallestAreaHit || void 0;
    }
    /**
   * Get the shapes, if any, at a given page point.
   *
   * @example
   * ```ts
   * editor.getShapesAtPoint({ x: 100, y: 100 })
   * editor.getShapesAtPoint({ x: 100, y: 100 }, { hitInside: true, margin: 8 })
   * ```
   *
   * @param point - The page point to test.
   * @param opts - The options for the hit point testing.
   *
   * @returns An array of shapes at the given point, sorted in reverse order of their absolute z-index (top-most shape first).
   *
   * @public
   */ getShapesAtPoint(point, opts = {}) {
        const margin = opts.margin ?? 0;
        const candidateIds = this._spatialIndex.getShapeIdsAtPoint(point, margin);
        return this.getCurrentPageShapesSorted().filter((shape)=>{
            if (this.isShapeHidden(shape)) return false;
            if (!candidateIds.has(shape.id) && !this.isShapeOfType(shape, "frame")) return false;
            return this.isPointInShape(shape, point, opts);
        }).reverse();
    }
    /**
   * Get shape IDs within the given bounds.
   *
   * Note: Uses shape page bounds only. Frames with labels outside their bounds
   * may not be included even if the label is within the search bounds.
   *
   * Note: Results are unordered. If you need z-order, combine with sorted shapes:
   * ```ts
   * const candidates = editor.getShapeIdsInsideBounds(bounds)
   * const sorted = editor.getCurrentPageShapesSorted().filter(s => candidates.has(s.id))
   * ```
   *
   * @param bounds - The bounds to search within.
   * @returns Unordered set of shape IDs within the given bounds.
   *
   * @public
   */ getShapeIdsInsideBounds(bounds) {
        return this._spatialIndex.getShapeIdsInsideBounds(bounds);
    }
    /**
   * Test whether a point (in the current page space) will will a shape. This method takes into account masks,
   * such as when a shape is the child of a frame and is partially clipped by the frame.
   *
   * @example
   * ```ts
   * editor.isPointInShape({ x: 100, y: 100 }, myShape)
   * ```
   *
   * @param shape - The shape to test against.
   * @param point - The page point to test (in the current page space).
   * @param opts - The options for the hit point testing.
   *
   * @public
   */ isPointInShape(shape, point, opts = {}) {
        const { hitInside = false, margin = 0 } = opts;
        const id = typeof shape === "string" ? shape : shape.id;
        const pageMask = this.getShapeMask(id);
        if (pageMask && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pointInPolygon"])(point, pageMask)) return false;
        return this.getShapeGeometry(id).hitTestPoint(this.getPointInShapeSpace(shape, point), margin, hitInside);
    }
    /**
   * Convert a point in the current page space to a point in the local space of a shape. For example, if a
   * shape's page point were `{ x: 100, y: 100 }`, a page point at `{ x: 110, y: 110 }` would be at
   * `{ x: 10, y: 10 }` in the shape's local space.
   *
   * @example
   * ```ts
   * editor.getPointInShapeSpace(myShape, { x: 100, y: 100 })
   * ```
   *
   * @param shape - The shape to get the point in the local space of.
   * @param point - The page point to get in the local space of the shape.
   *
   * @public
   */ getPointInShapeSpace(shape, point) {
        const id = typeof shape === "string" ? shape : shape.id;
        return this._getShapePageTransformCache().get(id).clone().invert().applyToPoint(point);
    }
    /**
   * Convert a delta in the current page space to a point in the local space of a shape's parent.
   *
   * @example
   * ```ts
   * editor.getPointInParentSpace(myShape.id, { x: 100, y: 100 })
   * ```
   *
   * @param shape - The shape to get the point in the local space of.
   * @param point - The page point to get in the local space of the shape.
   *
   * @public
   */ getPointInParentSpace(shape, point) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        if (!freshShape) return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(freshShape.parentId)) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(point);
        const parentTransform = this.getShapePageTransform(freshShape.parentId);
        if (!parentTransform) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(point);
        return parentTransform.clone().invert().applyToPoint(point);
    }
    getCurrentPageShapes() {
        return Array.from(this.getCurrentPageShapeIds(), (id)=>this.store.get(id));
    }
    getCurrentPageShapesSorted() {
        const result = [];
        const topLevelShapes = this.getSortedChildIdsForParent(this.getCurrentPageId());
        for(let i = 0, n = topLevelShapes.length; i < n; i++){
            pushShapeWithDescendants(this, topLevelShapes[i], result);
        }
        return result;
    }
    getCurrentPageRenderingShapesSorted() {
        const culledShapes = this.getCulledShapes();
        return this.getCurrentPageShapesSorted().filter(({ id })=>!culledShapes.has(id) && !this.isShapeHidden(id));
    }
    isShapeOfType(arg, type) {
        const shape = typeof arg === "string" ? this.getShape(arg) : arg;
        if (!shape) return false;
        return shape.type === type;
    }
    /**
   * Get a shape by its id.
   *
   * @example
   * ```ts
   * editor.getShape('box1')
   * ```
   *
   * @param shape - The shape (or the id of the shape) to get.
   *
   * @public
   */ getShape(shape) {
        const id = typeof shape === "string" ? shape : shape.id;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(id)) return void 0;
        return this.store.get(id);
    }
    /**
   * Get the parent shape for a given shape. Returns undefined if the shape is the direct child of
   * the page.
   *
   * @example
   * ```ts
   * editor.getShapeParent(myShape)
   * ```
   *
   * @public
   */ getShapeParent(shape) {
        const id = typeof shape === "string" ? shape : shape?.id;
        if (!id) return void 0;
        const freshShape = this.getShape(id);
        if (freshShape === void 0 || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(freshShape.parentId)) return void 0;
        return this.getShape(freshShape.parentId);
    }
    /**
   * If siblingShape and targetShape are siblings, this returns targetShape. If targetShape has an
   * ancestor who is a sibling of siblingShape, this returns that ancestor. Otherwise, this returns
   * undefined.
   *
   * @internal
   */ getShapeNearestSibling(siblingShape, targetShape) {
        if (!targetShape) {
            return void 0;
        }
        if (targetShape.parentId === siblingShape.parentId) {
            return targetShape;
        }
        const ancestor = this.findShapeAncestor(targetShape, (ancestor2)=>ancestor2.parentId === siblingShape.parentId);
        return ancestor;
    }
    /**
   * Get whether the given shape is the descendant of the given page.
   *
   * @example
   * ```ts
   * editor.isShapeInPage(myShape)
   * editor.isShapeInPage(myShape, 'page1')
   * ```
   *
   * @param shape - The shape to check.
   * @param pageId - The id of the page to check against. Defaults to the current page.
   *
   * @public
   */ isShapeInPage(shape, pageId = this.getCurrentPageId()) {
        const id = typeof shape === "string" ? shape : shape.id;
        const shapeToCheck = this.getShape(id);
        if (!shapeToCheck) return false;
        let shapeIsInPage = false;
        if (shapeToCheck.parentId === pageId) {
            shapeIsInPage = true;
        } else {
            let parent = this.getShape(shapeToCheck.parentId);
            isInPageSearch: while(parent){
                if (parent.parentId === pageId) {
                    shapeIsInPage = true;
                    break isInPageSearch;
                }
                parent = this.getShape(parent.parentId);
            }
        }
        return shapeIsInPage;
    }
    /**
   * Get the id of the containing page for a given shape.
   *
   * @param shape - The shape to get the page id for.
   *
   * @returns The id of the page that contains the shape, or undefined if the shape is undefined.
   *
   * @public
   */ getAncestorPageId(shape) {
        const id = typeof shape === "string" ? shape : shape?.id;
        const _shape = id && this.getShape(id);
        if (!_shape) return void 0;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(_shape.parentId)) {
            return _shape.parentId;
        } else {
            return this.getAncestorPageId(this.getShape(_shape.parentId));
        }
    }
    /**
   * Reparent shapes to a new parent. This operation preserves the shape's current page positions /
   * rotations.
   *
   * @example
   * ```ts
   * editor.reparentShapes([box1, box2], 'frame1')
   * editor.reparentShapes([box1.id, box2.id], 'frame1')
   * editor.reparentShapes([box1.id, box2.id], 'frame1', 4)
   * ```
   *
   * @param shapes - The shapes (or shape ids) of the shapes to reparent.
   * @param parentId - The id of the new parent shape.
   * @param insertIndex - The index to insert the children.
   *
   * @public
   */ reparentShapes(shapes, parentId, insertIndex) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length === 0) return this;
        const changes = [];
        const parentTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(parentId) ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Identity() : this.getShapePageTransform(parentId);
        const parentPageRotation = parentTransform.rotation();
        let indices = [];
        const sibs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.getSortedChildIdsForParent(parentId).map((id)=>this.getShape(id)));
        if (insertIndex) {
            const sibWithInsertIndex = sibs.find((s)=>s.index === insertIndex);
            if (sibWithInsertIndex) {
                const sibAbove = sibs[sibs.indexOf(sibWithInsertIndex) + 1];
                if (sibAbove) {
                    indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesBetween"])(insertIndex, sibAbove.index, ids.length);
                } else {
                    indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesAbove"])(insertIndex, ids.length);
                }
            } else {
                const sibAbove = sibs.sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]).find((s)=>s.index > insertIndex);
                if (sibAbove) {
                    indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesBetween"])(insertIndex, sibAbove.index, ids.length);
                } else {
                    indices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesAbove"])(insertIndex, ids.length);
                }
            }
        } else {
            const sib = sibs.length && sibs[sibs.length - 1];
            indices = sib ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndicesAbove"])(sib.index, ids.length) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndices"])(ids.length);
        }
        const invertedParentTransform = parentTransform.clone().invert();
        const shapesToReparent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id))).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
        this.run(()=>{
            for(let i = 0; i < shapesToReparent.length; i++){
                const shape = shapesToReparent[i];
                const pageTransform = this.getShapePageTransform(shape);
                if (!pageTransform) continue;
                const pagePoint = pageTransform.point();
                if (!pagePoint) continue;
                const newPoint = invertedParentTransform.applyToPoint(pagePoint);
                const newRotation = pageTransform.rotation() - parentPageRotation;
                if (shape.id === parentId) {
                    throw Error("Attempted to reparent a shape to itself!");
                }
                changes.push({
                    id: shape.id,
                    type: shape.type,
                    parentId,
                    x: newPoint.x,
                    y: newPoint.y,
                    rotation: newRotation,
                    index: indices[i]
                });
            }
            this.updateShapes(changes);
        }, {
            ignoreShapeLock: true
        });
        return this;
    }
    /**
   * Get the index above the highest child of a given parent.
   *
   * @param parent - The parent (or the id) of the parent.
   *
   * @returns The index.
   *
   * @public
   */ getHighestIndexForParent(parent) {
        const parentId = typeof parent === "string" ? parent : parent.id;
        const children = this._parentIdsToChildIds.get()[parentId];
        if (!children || children.length === 0) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZERO_INDEX_KEY"]);
        }
        const shape = this.getShape(children[children.length - 1]);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(shape.index);
    }
    /**
   * Get an array of all the children of a shape.
   *
   * @example
   * ```ts
   * editor.getSortedChildIdsForParent('frame1')
   * ```
   *
   * @param parent - The parent (or the id) of the parent shape.
   *
   * @public
   */ getSortedChildIdsForParent(parent) {
        const parentId = typeof parent === "string" ? parent : parent.id;
        const ids = this._parentIdsToChildIds.get()[parentId];
        if (!ids) return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
        return ids;
    }
    /**
   * Run a visitor function for all descendants of a shape.
   *
   * @example
   * ```ts
   * editor.visitDescendants('frame1', myCallback)
   * ```
   *
   * @param parent - The parent (or the id) of the parent shape.
   * @param visitor - The visitor function.
   *
   * @public
   */ visitDescendants(parent, visitor) {
        const children = this.getSortedChildIdsForParent(parent);
        for (const id of children){
            if (visitor(id) === false) continue;
            this.visitDescendants(id, visitor);
        }
        return this;
    }
    /**
   * Get the shape ids of all descendants of the given shapes (including the shapes themselves). IDs are returned in z-index order.
   *
   * @param ids - The ids of the shapes to get descendants of.
   *
   * @returns The descendant ids.
   *
   * @public
   */ getShapeAndDescendantIds(ids) {
        const shapeIds = /* @__PURE__ */ new Set();
        for (const shape of ids.map((id)=>this.getShape(id)).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"])){
            shapeIds.add(shape.id);
            this.visitDescendants(shape, (descendantId)=>{
                shapeIds.add(descendantId);
            });
        }
        return shapeIds;
    }
    /**
   * Get the shape that some shapes should be dropped on at a given point.
   *
   * @param point - The point to find the parent for.
   * @param droppingShapes - The shapes that are being dropped.
   *
   * @returns The shape to drop on.
   *
   * @public
   */ getDraggingOverShape(point, droppingShapes) {
        const draggingShapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(droppingShapes.map((s)=>this.getShape(s))).filter((s)=>!s.isLocked && !this.isShapeHidden(s));
        const maybeDraggingOverShapes = this.getShapesAtPoint(point, {
            hitInside: true,
            margin: 0
        }).filter((s)=>!droppingShapes.includes(s) && !s.isLocked && !this.isShapeHidden(s) && !draggingShapes.includes(s));
        for (const maybeDraggingOverShape of maybeDraggingOverShapes){
            const shapeUtil = this.getShapeUtil(maybeDraggingOverShape);
            if (shapeUtil.onDragShapesOver || shapeUtil.onDragShapesIn || shapeUtil.onDragShapesOut || shapeUtil.onDropShapesOver) {
                return maybeDraggingOverShape;
            }
        }
    }
    /**
   * Get the shape that should be selected when you click on a given shape, assuming there is
   * nothing already selected. It will not return anything higher than or including the current
   * focus layer.
   *
   * @param shape - The shape to get the outermost selectable shape for.
   * @param filter - A function to filter the selectable shapes.
   *
   * @returns The outermost selectable shape.
   *
   * @public
   */ getOutermostSelectableShape(shape, filter) {
        const id = typeof shape === "string" ? shape : shape.id;
        const freshShape = this.getShape(id);
        let match = freshShape;
        let node = freshShape;
        const focusedGroup = this.getFocusedGroup();
        while(node){
            if (this.isShapeOfType(node, "group") && focusedGroup?.id !== node.id && !this.hasAncestor(focusedGroup, node.id) && (filter?.(node) ?? true)) {
                match = node;
            } else if (focusedGroup?.id === node.id) {
                break;
            }
            node = this.getShapeParent(node);
        }
        return match;
    }
    _getBindingsIndexCache() {
        const index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$derivations$2f$bindingsIndex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bindingsIndex"])(this);
        return this.store.createComputedCache("bindingsIndex", (shape)=>{
            return index.get().get(shape.id);
        }, // we can ignore the shape equality check here because the index is
        // computed incrementally based on what bindings are in the store
        {
            areRecordsEqual: ()=>true
        });
    }
    /**
   * Get a binding from the store by its ID if it exists.
   */ getBinding(id) {
        return this.store.get(id);
    }
    getBindingsFromShape(shape, type) {
        const id = typeof shape === "string" ? shape : shape.id;
        return this.getBindingsInvolvingShape(id).filter((b)=>b.fromId === id && b.type === type);
    }
    getBindingsToShape(shape, type) {
        const id = typeof shape === "string" ? shape : shape.id;
        return this.getBindingsInvolvingShape(id).filter((b)=>b.toId === id && b.type === type);
    }
    getBindingsInvolvingShape(shape, type) {
        const id = typeof shape === "string" ? shape : shape.id;
        const result = this._getBindingsIndexCache().get(id) ?? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
        if (!type) return result;
        return result.filter((b)=>b.type === type);
    }
    /**
   * Create bindings from a list of partial bindings. You can omit the ID and most props of a
   * binding, but the `type`, `toId`, and `fromId` must all be provided.
   */ createBindings(partials) {
        const bindings = [];
        for (const partial of partials){
            const fromShape = this.getShape(partial.fromId);
            const toShape = this.getShape(partial.toId);
            if (!fromShape || !toShape) continue;
            if (!this.canBindShapes({
                fromShape,
                toShape,
                binding: partial
            })) continue;
            const util = this.getBindingUtil(partial.type);
            const defaultProps = util.getDefaultProps();
            const binding = this.store.schema.types.binding.create({
                ...partial,
                id: partial.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])(),
                props: {
                    ...defaultProps,
                    ...partial.props
                }
            });
            bindings.push(binding);
        }
        this.store.put(bindings);
        return this;
    }
    /**
   * Create a single binding from a partial. You can omit the ID and most props of a binding, but
   * the `type`, `toId`, and `fromId` must all be provided.
   */ createBinding(partial) {
        return this.createBindings([
            partial
        ]);
    }
    /**
   * Update bindings from a list of partial bindings. Each partial must include an ID, which will
   * be used to match the binding to it's existing record. If there is no existing record, that
   * binding is skipped. The changes from the partial are merged into the existing record.
   */ updateBindings(partials) {
        const updated = [];
        for (const partial of partials){
            if (!partial) continue;
            const current = this.getBinding(partial.id);
            if (!current) continue;
            const updatedBinding = applyPartialToRecordWithProps(current, partial);
            if (updatedBinding === current) continue;
            const fromShape = this.getShape(updatedBinding.fromId);
            const toShape = this.getShape(updatedBinding.toId);
            if (!fromShape || !toShape) continue;
            if (!this.canBindShapes({
                fromShape,
                toShape,
                binding: updatedBinding
            })) continue;
            updated.push(updatedBinding);
        }
        this.store.put(updated);
        return this;
    }
    /**
   * Update a binding from a partial binding. Each partial must include an ID, which will be used
   * to match the binding to it's existing record. If there is no existing record, that binding is
   * skipped. The changes from the partial are merged into the existing record.
   */ updateBinding(partial) {
        return this.updateBindings([
            partial
        ]);
    }
    /**
   * Delete several bindings by their IDs. If a binding ID doesn't exist, it's ignored.
   */ deleteBindings(bindings, { isolateShapes = false } = {}) {
        const ids = bindings.map((binding)=>typeof binding === "string" ? binding : binding.id);
        if (isolateShapes) {
            this.store.atomic(()=>{
                for (const id of ids){
                    const binding = this.getBinding(id);
                    if (!binding) continue;
                    const util = this.getBindingUtil(binding);
                    util.onBeforeIsolateFromShape?.({
                        binding,
                        removedShape: this.getShape(binding.toId)
                    });
                    util.onBeforeIsolateToShape?.({
                        binding,
                        removedShape: this.getShape(binding.fromId)
                    });
                    this.store.remove([
                        id
                    ]);
                }
            });
        } else {
            this.store.remove(ids);
        }
        return this;
    }
    /**
   * Delete a binding by its ID. If the binding doesn't exist, it's ignored.
   */ deleteBinding(binding, opts) {
        return this.deleteBindings([
            binding
        ], opts);
    }
    canBindShapes({ fromShape, toShape, binding }) {
        const fromShapeType = typeof fromShape === "string" ? fromShape : fromShape.type;
        const toShapeType = typeof toShape === "string" ? toShape : toShape.type;
        const bindingType = typeof binding === "string" ? binding : binding.type;
        const canBindOpts = {
            fromShape: typeof fromShape === "string" ? {
                type: fromShape
            } : fromShape,
            toShape: typeof toShape === "string" ? {
                type: toShape
            } : toShape,
            bindingType,
            fromShapeType,
            toShapeType
        };
        if (fromShapeType === toShapeType) {
            return this.getShapeUtil(fromShapeType).canBind(canBindOpts);
        }
        return this.getShapeUtil(fromShapeType).canBind(canBindOpts) && this.getShapeUtil(toShapeType).canBind(canBindOpts);
    }
    /* -------------------- Commands -------------------- */ /**
   * Rotate shapes by a delta in radians.
   *
   * @example
   * ```ts
   * editor.rotateShapesBy(editor.getSelectedShapeIds(), Math.PI)
   * editor.rotateShapesBy(editor.getSelectedShapeIds(), Math.PI / 2)
   * ```
   *
   * @param shapes - The shapes (or shape ids) of the shapes to move.
   * @param delta - The delta in radians to apply to the selection rotation.
   * @param opts - The options for the rotation.
   */ rotateShapesBy(shapes, delta, opts) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length <= 0) return this;
        const snapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRotationSnapshot"])({
            editor: this,
            ids
        });
        if (!snapshot) return this;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$rotation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyRotationToSnapshotShapes"])({
            delta,
            snapshot,
            editor: this,
            stage: "one-off",
            centerOverride: opts?.center
        });
        return this;
    }
    // Gets a shape partial that includes life cycle changes: on translate start, on translate, on translate end
    getChangesToTranslateShape(initialShape, newShapeCoords) {
        let workingShape = initialShape;
        const util = this.getShapeUtil(initialShape);
        const afterTranslateStart = util.onTranslateStart?.(workingShape);
        if (afterTranslateStart) {
            workingShape = applyPartialToRecordWithProps(workingShape, afterTranslateStart);
        }
        workingShape = applyPartialToRecordWithProps(workingShape, {
            id: initialShape.id,
            type: initialShape.type,
            x: newShapeCoords.x,
            y: newShapeCoords.y
        });
        const afterTranslate = util.onTranslate?.(initialShape, workingShape);
        if (afterTranslate) {
            workingShape = applyPartialToRecordWithProps(workingShape, afterTranslate);
        }
        const afterTranslateEnd = util.onTranslateEnd?.(initialShape, workingShape);
        if (afterTranslateEnd) {
            workingShape = applyPartialToRecordWithProps(workingShape, afterTranslateEnd);
        }
        return workingShape;
    }
    /**
   * Move shapes by a delta.
   *
   * @example
   * ```ts
   * editor.nudgeShapes(['box1', 'box2'], { x: 8, y: 8 })
   * ```
   *
   * @param shapes - The shapes (or shape ids) to move.
   * @param offset - The offset to apply to the shapes.
   */ nudgeShapes(shapes, offset) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length <= 0) return this;
        const changes = [];
        for (const id of ids){
            const shape = this.getShape(id);
            const localDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].From(offset);
            const parentTransform = this.getShapeParentTransform(shape);
            if (parentTransform) localDelta.rot(-parentTransform.rotation());
            changes.push(this.getChangesToTranslateShape(shape, localDelta.add(shape)));
        }
        this.updateShapes(changes);
        return this;
    }
    /**
   * Duplicate shapes.
   *
   * @example
   * ```ts
   * editor.duplicateShapes(['box1', 'box2'], { x: 8, y: 8 })
   * editor.duplicateShapes(editor.getSelectedShapes(), { x: 8, y: 8 })
   * ```
   *
   * @param shapes - The shapes (or shape ids) to duplicate.
   * @param offset - The offset (in pixels) to apply to the duplicated shapes.
   *
   * @public
   */ duplicateShapes(shapes, offset) {
        this.run(()=>{
            const _ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
            const ids = this._shouldIgnoreShapeLock ? _ids : this._getUnlockedShapeIds(_ids);
            if (ids.length <= 0) return this;
            const initialIds = new Set(ids);
            const shapeIdSet = this.getShapeAndDescendantIds(ids);
            const orderedShapeIds = [
                ...shapeIdSet
            ].reverse();
            const shapeIds = /* @__PURE__ */ new Map();
            for (const shapeId of shapeIdSet){
                shapeIds.set(shapeId, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])());
            }
            const { shapesToCreateWithOriginals, bindingsToCreate } = withIsolatedShapes(this, shapeIdSet, (bindingIdsToMaintain)=>{
                const bindingsToCreate2 = [];
                for (const originalId of bindingIdsToMaintain){
                    const originalBinding = this.getBinding(originalId);
                    if (!originalBinding) continue;
                    const duplicatedId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])();
                    bindingsToCreate2.push({
                        ...originalBinding,
                        id: duplicatedId,
                        fromId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(shapeIds.get(originalBinding.fromId)),
                        toId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(shapeIds.get(originalBinding.toId))
                    });
                }
                const shapesToCreateWithOriginals2 = [];
                for (const originalId of orderedShapeIds){
                    const duplicatedId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(shapeIds.get(originalId));
                    const originalShape = this.getShape(originalId);
                    if (!originalShape) continue;
                    let ox = 0;
                    let oy = 0;
                    if (offset && initialIds.has(originalId)) {
                        const parentTransform = this.getShapeParentTransform(originalShape);
                        const vec = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](offset.x, offset.y).rot(-parentTransform.rotation());
                        ox = vec.x;
                        oy = vec.y;
                    }
                    shapesToCreateWithOriginals2.push({
                        shape: {
                            ...originalShape,
                            id: duplicatedId,
                            x: originalShape.x + ox,
                            y: originalShape.y + oy,
                            // Use a dummy index for now, it will get updated outside of the `withIsolatedShapes`
                            index: "a1",
                            parentId: shapeIds.get(originalShape.parentId) ?? originalShape.parentId
                        },
                        originalShape
                    });
                }
                return {
                    shapesToCreateWithOriginals: shapesToCreateWithOriginals2,
                    bindingsToCreate: bindingsToCreate2
                };
            });
            shapesToCreateWithOriginals.forEach(({ shape, originalShape })=>{
                const parentId = originalShape.parentId;
                const siblings = this.getSortedChildIdsForParent(parentId);
                const currentIndex = siblings.indexOf(originalShape.id);
                const siblingAboveId = siblings[currentIndex + 1];
                const siblingAbove = siblingAboveId ? this.getShape(siblingAboveId) : void 0;
                const index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexBetween"])(originalShape.index, siblingAbove?.index);
                shape.index = index;
            });
            const shapesToCreate = shapesToCreateWithOriginals.map(({ shape })=>shape);
            if (!this.canCreateShapes(shapesToCreate)) {
                alertMaxShapes(this);
                return;
            }
            this.createShapes(shapesToCreate);
            this.createBindings(bindingsToCreate);
            this.setSelectedShapes((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((oldId)=>{
                const newId = shapeIds.get(oldId);
                if (!newId) return null;
                if (!this.getShape(newId)) return null;
                return newId;
            })));
            if (offset !== void 0) {
                const selectionPageBounds = this.getSelectionPageBounds();
                const viewportPageBounds = this.getViewportPageBounds();
                if (selectionPageBounds && !viewportPageBounds.contains(selectionPageBounds)) {
                    this.centerOnPoint(selectionPageBounds.center, {
                        animation: {
                            duration: this.options.animationMediumMs
                        }
                    });
                }
            }
        });
        return this;
    }
    /**
   * Move shapes to page.
   *
   * @example
   * ```ts
   * editor.moveShapesToPage(['box1', 'box2'], 'page1')
   * ```
   *
   * @param shapes - The shapes (or shape ids) of the shapes to move.
   * @param pageId - The id of the page where the shapes will be moved.
   *
   * @public
   */ moveShapesToPage(shapes, pageId) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length === 0) return this;
        if (this.getIsReadonly()) return this;
        const currentPageId = this.getCurrentPageId();
        if (pageId === currentPageId) return this;
        if (!this.store.has(pageId)) return this;
        const content = this.getContentFromCurrentPage(ids);
        if (!content) return this;
        if (this.getPageShapeIds(pageId).size + content.shapes.length > this.options.maxShapesPerPage) {
            alertMaxShapes(this, pageId);
            return this;
        }
        const fromPageZ = this.getCamera().z;
        this.run(()=>{
            this.deleteShapes(ids);
            this.setCurrentPage(pageId);
            this.setFocusedGroup(null);
            this.selectNone();
            this.putContentOntoCurrentPage(content, {
                select: true,
                preserveIds: true,
                preservePosition: true
            });
            this.setCamera({
                ...this.getCamera(),
                z: fromPageZ
            });
            this.centerOnPoint(this.getSelectionRotatedPageBounds().center);
        });
        return this;
    }
    /**
   * Toggle the lock state of one or more shapes. If there is a mix of locked and unlocked shapes, all shapes will be locked.
   *
   * @param shapes - The shapes (or shape ids) to toggle.
   *
   * @public
   */ toggleLock(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (this.getIsReadonly() || ids.length === 0) return this;
        let allLocked = true, allUnlocked = true;
        const shapesToToggle = [];
        for (const id of ids){
            const shape = this.getShape(id);
            if (shape) {
                shapesToToggle.push(shape);
                if (shape.isLocked) {
                    allUnlocked = false;
                } else {
                    allLocked = false;
                }
            }
        }
        this.run(()=>{
            if (allUnlocked) {
                this.updateShapes(shapesToToggle.map((shape)=>({
                        id: shape.id,
                        type: shape.type,
                        isLocked: true
                    })));
                this.setSelectedShapes([]);
            } else if (allLocked) {
                this.updateShapes(shapesToToggle.map((shape)=>({
                        id: shape.id,
                        type: shape.type,
                        isLocked: false
                    })));
            } else {
                this.updateShapes(shapesToToggle.map((shape)=>({
                        id: shape.id,
                        type: shape.type,
                        isLocked: true
                    })));
            }
        });
        return this;
    }
    /**
   * Send shapes to the back of the page's object list.
   *
   * @example
   * ```ts
   * editor.sendToBack(['id1', 'id2'])
   * editor.sendToBack(box1, box2)
   * ```
   *
   * @param shapes - The shapes (or shape ids) to move.
   *
   * @public
   */ sendToBack(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const changes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reorderShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReorderingShapesChanges"])(this, "toBack", ids, {
            considerAllShapes: true
        });
        if (changes) this.updateShapes(changes);
        return this;
    }
    /**
   * Send shapes backward in the page's object list.
   *
   * @example
   * ```ts
   * editor.sendBackward(['id1', 'id2'])
   * editor.sendBackward([box1, box2])
   * ```
   *
   * By default, the operation will only consider overlapping shapes.
   * To consider all shapes, pass `{ considerAllShapes: true }` in the options.
   *
   * @example
   * ```ts
   * editor.sendBackward(['id1', 'id2'], { considerAllShapes: true })
   * ```
   *
   * @param shapes - The shapes (or shape ids) to move.
   * @param opts - The options for the backward operation.
   *
   * @public
   */ sendBackward(shapes, opts = {}) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const changes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reorderShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReorderingShapesChanges"])(this, "backward", ids, opts);
        if (changes) this.updateShapes(changes);
        return this;
    }
    /**
   * Bring shapes forward in the page's object list.
   *
   * @example
   * ```ts
   * editor.bringForward(['id1', 'id2'])
   * editor.bringForward(box1,  box2)
   * ```
   *
   * By default, the operation will only consider overlapping shapes.
   * To consider all shapes, pass `{ considerAllShapes: true }` in the options.
   *
   * @example
   * ```ts
   * editor.bringForward(['id1', 'id2'], { considerAllShapes: true })
   * ```
   *
   * @param shapes - The shapes (or shape ids) to move.
   * @param opts - The options for the forward operation.
   *
   * @public
   */ bringForward(shapes, opts = {}) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const changes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reorderShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReorderingShapesChanges"])(this, "forward", ids, opts);
        if (changes) this.updateShapes(changes);
        return this;
    }
    /**
   * Bring shapes to the front of the page's object list.
   *
   * @example
   * ```ts
   * editor.bringToFront(['id1', 'id2'])
   * editor.bringToFront([box1, box2])
   * ```
   *
   * @param shapes - The shapes (or shape ids) to move.
   *
   * @public
   */ bringToFront(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const changes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$reorderShapes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReorderingShapesChanges"])(this, "toFront", ids);
        if (changes) this.updateShapes(changes);
        return this;
    }
    /**
   * @internal
   */ collectShapesViaArrowBindings(info) {
        const { initialShapes, resultShapes, resultBounds, bindings, visited } = info;
        for (const binding of bindings){
            for (const id of [
                binding.fromId,
                binding.toId
            ]){
                if (!visited.has(id)) {
                    const aligningShape = initialShapes.find((s)=>s.id === id);
                    if (aligningShape && !visited.has(aligningShape.id)) {
                        visited.add(aligningShape.id);
                        const shapePageBounds = this.getShapePageBounds(aligningShape);
                        if (!shapePageBounds) continue;
                        resultShapes.push(aligningShape);
                        resultBounds.push(shapePageBounds);
                        this.collectShapesViaArrowBindings({
                            ...info,
                            bindings: this.getBindingsInvolvingShape(aligningShape, "arrow")
                        });
                    }
                }
            }
        }
    }
    /**
   * Flip shape positions.
   *
   * @example
   * ```ts
   * editor.flipShapes([box1, box2], 'horizontal', 32)
   * editor.flipShapes(editor.getSelectedShapeIds(), 'horizontal', 32)
   * ```
   *
   * @param shapes - The ids of the shapes to flip.
   * @param operation - Whether to flip horizontally or vertically.
   *
   * @public
   */ flipShapes(shapes, operation) {
        if (this.getIsReadonly()) return this;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const shapesToFlipFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        for (const shape of shapesToFlipFirstPass){
            if (this.isShapeOfType(shape, "group")) {
                const childrenOfGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(this.getSortedChildIdsForParent(shape.id).map((id)=>this.getShape(id)));
                shapesToFlipFirstPass.push(...childrenOfGroups);
            }
        }
        const shapesToFlip = [];
        const allBounds = [];
        for (const shape of shapesToFlipFirstPass){
            const util = this.getShapeUtil(shape);
            if (!util.canBeLaidOut(shape, {
                type: "flip",
                shapes: shapesToFlipFirstPass
            })) {
                continue;
            }
            const pageBounds = this.getShapePageBounds(shape);
            const localBounds = this.getShapeGeometry(shape).bounds;
            const pageTransform = this.getShapePageTransform(shape.id);
            if (!(pageBounds && localBounds && pageTransform)) continue;
            shapesToFlip.push({
                shape,
                localBounds,
                pageTransform,
                isAspectRatioLocked: util.isAspectRatioLocked(shape)
            });
            allBounds.push(pageBounds);
        }
        if (!shapesToFlip.length) return this;
        const scaleOriginPage = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(allBounds).center;
        this.run(()=>{
            for (const { shape, localBounds, pageTransform, isAspectRatioLocked } of shapesToFlip){
                this.resizeShape(shape.id, {
                    x: operation === "horizontal" ? -1 : 1,
                    y: operation === "vertical" ? -1 : 1
                }, {
                    initialBounds: localBounds,
                    initialPageTransform: pageTransform,
                    initialShape: shape,
                    isAspectRatioLocked,
                    mode: "scale_shape",
                    scaleOrigin: scaleOriginPage,
                    scaleAxisRotation: 0
                });
            }
        });
        return this;
    }
    /**
   * Stack shape.
   *
   * @example
   * ```ts
   * editor.stackShapes([box1, box2], 'horizontal')
   * editor.stackShapes(editor.getSelectedShapeIds(), 'horizontal')
   * ```
   *
   * @param shapes - The shapes (or shape ids) to stack.
   * @param operation - Whether to stack horizontally or vertically.
   * @param gap - The gap to leave between shapes. By default, uses the editor's `adjacentShapeMargin` option.
   *
   * @public
   */ stackShapes(shapes, operation, gap) {
        const _gap = gap ?? this.options.adjacentShapeMargin;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (this.getIsReadonly()) return this;
        const shapesToStackFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        const shapeClustersToStack = [];
        const allBounds = [];
        const visited = /* @__PURE__ */ new Set();
        for (const shape of shapesToStackFirstPass){
            if (visited.has(shape.id)) continue;
            visited.add(shape.id);
            const shapePageBounds = this.getShapePageBounds(shape);
            if (!shapePageBounds) continue;
            if (!this.getShapeUtil(shape).canBeLaidOut?.(shape, {
                type: "stack",
                shapes: shapesToStackFirstPass
            })) {
                continue;
            }
            const shapesMovingTogether = [
                shape
            ];
            const boundsOfShapesMovingTogether = [
                shapePageBounds
            ];
            this.collectShapesViaArrowBindings({
                bindings: this.getBindingsToShape(shape.id, "arrow"),
                initialShapes: shapesToStackFirstPass,
                resultShapes: shapesMovingTogether,
                resultBounds: boundsOfShapesMovingTogether,
                visited
            });
            const commonPageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(boundsOfShapesMovingTogether);
            if (!commonPageBounds) continue;
            shapeClustersToStack.push({
                shapes: shapesMovingTogether,
                pageBounds: commonPageBounds
            });
            allBounds.push(commonPageBounds);
        }
        const len = shapeClustersToStack.length;
        if (_gap === 0 && len < 3 || len < 2) return this;
        let val;
        let min;
        let max;
        let dim;
        if (operation === "horizontal") {
            val = "x";
            min = "minX";
            max = "maxX";
            dim = "width";
        } else {
            val = "y";
            min = "minY";
            max = "maxY";
            dim = "height";
        }
        let shapeGap = 0;
        if (_gap === 0) {
            const gaps = {};
            shapeClustersToStack.sort((a, b)=>a.pageBounds[min] - b.pageBounds[min]);
            for(let i = 0; i < len - 1; i++){
                const currCluster = shapeClustersToStack[i];
                const nextCluster = shapeClustersToStack[i + 1];
                const gap2 = nextCluster.pageBounds[min] - currCluster.pageBounds[max];
                if (!gaps[gap2]) {
                    gaps[gap2] = 0;
                }
                gaps[gap2]++;
            }
            let maxCount = 1;
            for (const [gap2, count] of Object.entries(gaps)){
                if (count > maxCount) {
                    maxCount = count;
                    shapeGap = parseFloat(gap2);
                }
            }
            if (maxCount === 1) {
                let totalCount = 0;
                for (const [gap2, count] of Object.entries(gaps)){
                    shapeGap += parseFloat(gap2) * count;
                    totalCount += count;
                }
                shapeGap /= totalCount;
            }
        } else {
            shapeGap = _gap;
        }
        const changes = [];
        let v = shapeClustersToStack[0].pageBounds[max];
        for(let i = 1; i < shapeClustersToStack.length; i++){
            const { shapes: shapes2, pageBounds } = shapeClustersToStack[i];
            const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
            delta[val] = v + shapeGap - pageBounds[val];
            for (const shape of shapes2){
                const shapeDelta = delta.clone();
                const parent = this.getShapeParent(shape);
                if (parent) {
                    const parentTransform = this.getShapePageTransform(parent);
                    if (parentTransform) shapeDelta.rot(-parentTransform.rotation());
                }
                shapeDelta.add(shape);
                changes.push(this.getChangesToTranslateShape(shape, shapeDelta));
            }
            v += pageBounds[dim] + shapeGap;
        }
        this.updateShapes(changes);
        return this;
    }
    /**
   * Pack shapes into a grid centered on their current position. Based on potpack (https://github.com/mapbox/potpack).
   *
   * @example
   * ```ts
   * editor.packShapes([box1, box2])
   * editor.packShapes(editor.getSelectedShapeIds(), 32)
   * ```
   *
   *
   * @param shapes - The shapes (or shape ids) to pack.
   * @param gap - The padding to apply to the packed shapes. Defaults to the editor's `adjacentShapeMargin` option.
   */ packShapes(shapes, _gap) {
        if (this.getIsReadonly()) return this;
        const gap = _gap ?? this.options.adjacentShapeMargin;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const shapesToPackFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        const shapeClustersToPack = [];
        const allBounds = [];
        const visited = /* @__PURE__ */ new Set();
        for (const shape of shapesToPackFirstPass){
            if (visited.has(shape.id)) continue;
            visited.add(shape.id);
            const shapePageBounds = this.getShapePageBounds(shape);
            if (!shapePageBounds) continue;
            if (!this.getShapeUtil(shape).canBeLaidOut?.(shape, {
                type: "pack",
                shapes: shapesToPackFirstPass
            })) {
                continue;
            }
            const shapesMovingTogether = [
                shape
            ];
            const boundsOfShapesMovingTogether = [
                shapePageBounds
            ];
            this.collectShapesViaArrowBindings({
                bindings: this.getBindingsToShape(shape.id, "arrow"),
                initialShapes: shapesToPackFirstPass,
                resultShapes: shapesMovingTogether,
                resultBounds: boundsOfShapesMovingTogether,
                visited
            });
            const commonPageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(boundsOfShapesMovingTogether);
            if (!commonPageBounds) continue;
            shapeClustersToPack.push({
                shapes: shapesMovingTogether,
                pageBounds: commonPageBounds,
                nextPageBounds: commonPageBounds.clone()
            });
            allBounds.push(commonPageBounds);
        }
        if (shapeClustersToPack.length < 2) return this;
        let area = 0;
        for (const { pageBounds } of shapeClustersToPack){
            area += pageBounds.width * pageBounds.height;
        }
        const commonBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(allBounds);
        const maxWidth = commonBounds.width;
        shapeClustersToPack.sort((a, b)=>a.pageBounds.width - b.pageBounds.width).sort((a, b)=>a.pageBounds.height - b.pageBounds.height);
        const startWidth = Math.max(Math.ceil(Math.sqrt(area / 0.95)), maxWidth);
        const spaces = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](commonBounds.x, commonBounds.y, startWidth, Infinity)
        ];
        let width = 0;
        let height = 0;
        let space;
        let last2;
        for (const { nextPageBounds } of shapeClustersToPack){
            for(let i = spaces.length - 1; i >= 0; i--){
                space = spaces[i];
                if (nextPageBounds.width > space.width || nextPageBounds.height > space.height) continue;
                nextPageBounds.x = space.x;
                nextPageBounds.y = space.y;
                height = Math.max(height, nextPageBounds.maxY);
                width = Math.max(width, nextPageBounds.maxX);
                if (nextPageBounds.width === space.width && nextPageBounds.height === space.height) {
                    last2 = spaces.pop();
                    if (i < spaces.length) spaces[i] = last2;
                } else if (nextPageBounds.height === space.height) {
                    space.x += nextPageBounds.width + gap;
                    space.width -= nextPageBounds.width + gap;
                } else if (nextPageBounds.width === space.width) {
                    space.y += nextPageBounds.height + gap;
                    space.height -= nextPageBounds.height + gap;
                } else {
                    spaces.push(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"](space.x + (nextPageBounds.width + gap), space.y, space.width - (nextPageBounds.width + gap), nextPageBounds.height));
                    space.y += nextPageBounds.height + gap;
                    space.height -= nextPageBounds.height + gap;
                }
                break;
            }
        }
        const commonAfter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(shapeClustersToPack.map((s)=>s.nextPageBounds));
        const centerDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(commonBounds.center, commonAfter.center);
        const changes = [];
        for (const { shapes: shapes2, pageBounds, nextPageBounds } of shapeClustersToPack){
            const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(nextPageBounds.point, pageBounds.point).add(centerDelta);
            for (const shape of shapes2){
                const shapeDelta = delta.clone();
                const parent = this.getShapeParent(shape);
                if (parent) {
                    const parentTransform = this.getShapeParentTransform(shape);
                    if (parentTransform) shapeDelta.rot(-parentTransform.rotation());
                }
                shapeDelta.add(shape);
                changes.push(this.getChangesToTranslateShape(shape, shapeDelta));
            }
        }
        if (changes.length) {
            this.updateShapes(changes);
        }
        return this;
    }
    /**
   * Align shape positions.
   *
   * @example
   * ```ts
   * editor.alignShapes([box1, box2], 'left')
   * editor.alignShapes(editor.getSelectedShapeIds(), 'left')
   * ```
   *
   * @param shapes - The shapes (or shape ids) to align.
   * @param operation - The align operation to apply.
   *
   * @public
   */ alignShapes(shapes, operation) {
        if (this.getIsReadonly()) return this;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const shapesToAlignFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        const shapeClustersToAlign = [];
        const allBounds = [];
        const visited = /* @__PURE__ */ new Set();
        for (const shape of shapesToAlignFirstPass){
            if (visited.has(shape.id)) continue;
            visited.add(shape.id);
            const shapePageBounds = this.getShapePageBounds(shape);
            if (!shapePageBounds) continue;
            if (!this.getShapeUtil(shape).canBeLaidOut?.(shape, {
                type: "align",
                shapes: shapesToAlignFirstPass
            })) {
                continue;
            }
            const shapesMovingTogether = [
                shape
            ];
            const boundsOfShapesMovingTogether = [
                shapePageBounds
            ];
            this.collectShapesViaArrowBindings({
                bindings: this.getBindingsToShape(shape.id, "arrow"),
                initialShapes: shapesToAlignFirstPass,
                resultShapes: shapesMovingTogether,
                resultBounds: boundsOfShapesMovingTogether,
                visited
            });
            const commonPageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(boundsOfShapesMovingTogether);
            if (!commonPageBounds) continue;
            shapeClustersToAlign.push({
                shapes: shapesMovingTogether,
                pageBounds: commonPageBounds
            });
            allBounds.push(commonPageBounds);
        }
        if (shapeClustersToAlign.length < 2) return this;
        const commonBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(allBounds);
        const changes = [];
        shapeClustersToAlign.forEach(({ shapes: shapes2, pageBounds })=>{
            const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
            switch(operation){
                case "top":
                    {
                        delta.y = commonBounds.minY - pageBounds.minY;
                        break;
                    }
                case "center-vertical":
                    {
                        delta.y = commonBounds.midY - pageBounds.minY - pageBounds.height / 2;
                        break;
                    }
                case "bottom":
                    {
                        delta.y = commonBounds.maxY - pageBounds.minY - pageBounds.height;
                        break;
                    }
                case "left":
                    {
                        delta.x = commonBounds.minX - pageBounds.minX;
                        break;
                    }
                case "center-horizontal":
                    {
                        delta.x = commonBounds.midX - pageBounds.minX - pageBounds.width / 2;
                        break;
                    }
                case "right":
                    {
                        delta.x = commonBounds.maxX - pageBounds.minX - pageBounds.width;
                        break;
                    }
            }
            for (const shape of shapes2){
                const shapeDelta = delta.clone();
                const parent = this.getShapeParent(shape);
                if (parent) {
                    const parentTransform = this.getShapePageTransform(parent);
                    if (parentTransform) shapeDelta.rot(-parentTransform.rotation());
                }
                shapeDelta.add(shape);
                changes.push(this.getChangesToTranslateShape(shape, shapeDelta));
            }
        });
        this.updateShapes(changes);
        return this;
    }
    /**
   * Distribute shape positions.
   *
   * @example
   * ```ts
   * editor.distributeShapes([box1, box2], 'horizontal')
   * editor.distributeShapes(editor.getSelectedShapeIds(), 'horizontal')
   * ```
   *
   * @param shapes - The shapes (or shape ids) to distribute.
   * @param operation - Whether to distribute shapes horizontally or vertically.
   *
   * @public
   */ distributeShapes(shapes, operation) {
        if (this.getIsReadonly()) return this;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const shapesToDistributeFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id)));
        const shapeClustersToDistribute = [];
        const allBounds = [];
        const visited = /* @__PURE__ */ new Set();
        for (const shape of shapesToDistributeFirstPass){
            if (visited.has(shape.id)) continue;
            visited.add(shape.id);
            const shapePageBounds = this.getShapePageBounds(shape);
            if (!shapePageBounds) continue;
            if (!this.getShapeUtil(shape).canBeLaidOut?.(shape, {
                type: "distribute",
                shapes: shapesToDistributeFirstPass
            })) {
                continue;
            }
            const shapesMovingTogether = [
                shape
            ];
            const boundsOfShapesMovingTogether = [
                shapePageBounds
            ];
            this.collectShapesViaArrowBindings({
                bindings: this.getBindingsToShape(shape.id, "arrow"),
                initialShapes: shapesToDistributeFirstPass,
                resultShapes: shapesMovingTogether,
                resultBounds: boundsOfShapesMovingTogether,
                visited
            });
            const commonPageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(boundsOfShapesMovingTogether);
            if (!commonPageBounds) continue;
            shapeClustersToDistribute.push({
                shapes: shapesMovingTogether,
                pageBounds: commonPageBounds
            });
            allBounds.push(commonPageBounds);
        }
        if (shapeClustersToDistribute.length < 3) return this;
        let val;
        let min;
        let max;
        let dim;
        if (operation === "horizontal") {
            val = "x";
            min = "minX";
            max = "maxX";
            dim = "width";
        } else {
            val = "y";
            min = "minY";
            max = "maxY";
            dim = "height";
        }
        const changes = [];
        const first = shapeClustersToDistribute.sort((a, b)=>a.pageBounds[min] - b.pageBounds[min])[0];
        const last2 = shapeClustersToDistribute.sort((a, b)=>b.pageBounds[max] - a.pageBounds[max])[0];
        if (first === last2) {
            const excludedShapeIds = new Set(first.shapes.map((s)=>s.id));
            return this.distributeShapes(ids.filter((id)=>!excludedShapeIds.has(id)), operation);
        }
        const shapeClustersToMove = shapeClustersToDistribute.filter((shape)=>shape !== first && shape !== last2).sort((a, b)=>{
            if (a.pageBounds[min] === b.pageBounds[min]) {
                return a.shapes[0].id < b.shapes[0].id ? -1 : 1;
            }
            return a.pageBounds[min] - b.pageBounds[min];
        });
        const maxFirst = first.pageBounds[max];
        const range = last2.pageBounds[min] - maxFirst;
        const summedShapeDimensions = shapeClustersToMove.reduce((acc, s)=>acc + s.pageBounds[dim], 0);
        const gap = (range - summedShapeDimensions) / (shapeClustersToMove.length + 1);
        for(let v = maxFirst + gap, i = 0; i < shapeClustersToMove.length; i++){
            const { shapes: shapes2, pageBounds } = shapeClustersToMove[i];
            const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
            delta[val] = v - pageBounds[val];
            if (v + pageBounds[dim] > last2.pageBounds[max] - 1) {
                delta[val] = last2.pageBounds[max] - pageBounds[max] - 1;
            }
            for (const shape of shapes2){
                const shapeDelta = delta.clone();
                const parent = this.getShapeParent(shape);
                if (parent) {
                    const parentTransform = this.getShapePageTransform(parent);
                    if (parentTransform) shapeDelta.rot(-parentTransform.rotation());
                }
                shapeDelta.add(shape);
                changes.push(this.getChangesToTranslateShape(shape, shapeDelta));
            }
            v += pageBounds[dim] + gap;
        }
        this.updateShapes(changes);
        return this;
    }
    /**
   * Stretch shape sizes and positions to fill their common bounding box.
   *
   * @example
   * ```ts
   * editor.stretchShapes([box1, box2], 'horizontal')
   * editor.stretchShapes(editor.getSelectedShapeIds(), 'horizontal')
   * ```
   *
   * @param shapes - The shapes (or shape ids) to stretch.
   * @param operation - Whether to stretch shapes horizontally or vertically.
   *
   * @public
   */ stretchShapes(shapes, operation) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (this.getIsReadonly()) return this;
        const shapesToStretchFirstPass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(ids.map((id)=>this.getShape(id))).filter((s)=>this.getShapePageTransform(s)?.rotation() % (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PI"] / 2) === 0);
        const shapeClustersToStretch = [];
        const allBounds = [];
        const visited = /* @__PURE__ */ new Set();
        for (const shape of shapesToStretchFirstPass){
            if (visited.has(shape.id)) continue;
            visited.add(shape.id);
            const shapePageBounds = this.getShapePageBounds(shape);
            if (!shapePageBounds) continue;
            const shapesMovingTogether = [
                shape
            ];
            const boundsOfShapesMovingTogether = [
                shapePageBounds
            ];
            if (!this.getShapeUtil(shape).canBeLaidOut?.(shape, {
                type: "stretch"
            })) {
                continue;
            }
            this.collectShapesViaArrowBindings({
                bindings: this.getBindingsToShape(shape.id, "arrow"),
                initialShapes: shapesToStretchFirstPass,
                resultShapes: shapesMovingTogether,
                resultBounds: boundsOfShapesMovingTogether,
                visited
            });
            const commonPageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(boundsOfShapesMovingTogether);
            if (!commonPageBounds) continue;
            shapeClustersToStretch.push({
                shapes: shapesMovingTogether,
                pageBounds: commonPageBounds
            });
            allBounds.push(commonPageBounds);
        }
        if (shapeClustersToStretch.length < 2) return this;
        const commonBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(allBounds);
        let val;
        let min;
        let dim;
        if (operation === "horizontal") {
            val = "x";
            min = "minX";
            dim = "width";
        } else {
            val = "y";
            min = "minY";
            dim = "height";
        }
        this.run(()=>{
            shapeClustersToStretch.forEach(({ shapes: shapes2, pageBounds })=>{
                const localOffset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]();
                localOffset[val] = commonBounds[min] - pageBounds[min];
                const scaleOrigin = pageBounds.center.clone();
                scaleOrigin[val] = commonBounds[min];
                const scale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](1, 1);
                scale[val] = commonBounds[dim] / pageBounds[dim];
                for (const shape of shapes2){
                    const shapeLocalOffset = localOffset.clone();
                    const parentTransform = this.getShapeParentTransform(shape);
                    if (parentTransform) localOffset.rot(-parentTransform.rotation());
                    shapeLocalOffset.add(shape);
                    const changes = this.getChangesToTranslateShape(shape, shapeLocalOffset);
                    this.updateShape(changes);
                    this.resizeShape(shape.id, scale, {
                        initialBounds: this.getShapeGeometry(shape).bounds,
                        scaleOrigin,
                        isAspectRatioLocked: this.getShapeUtil(shape).isAspectRatioLocked(shape),
                        scaleAxisRotation: 0
                    });
                }
            });
        });
        return this;
    }
    /**
   * Resize a shape.
   *
   * @param shape - The shape (or the shape id of the shape) to resize.
   * @param scale - The scale factor to apply to the shape.
   * @param opts - Additional options.
   *
   * @public
   */ resizeShape(shape, scale, opts = {}) {
        const id = typeof shape === "string" ? shape : shape.id;
        if (this.getIsReadonly()) return this;
        if (!Number.isFinite(scale.x)) scale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](1, scale.y);
        if (!Number.isFinite(scale.y)) scale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](scale.x, 1);
        const initialShape = opts.initialShape ?? this.getShape(id);
        if (!initialShape) return this;
        const scaleOrigin = opts.scaleOrigin ?? this.getShapePageBounds(id)?.center;
        if (!scaleOrigin) return this;
        const pageTransform = opts.initialPageTransform ? __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].Cast(opts.initialPageTransform) : this.getShapePageTransform(id);
        if (!pageTransform) return this;
        const pageRotation = pageTransform.rotation();
        if (pageRotation == null) return this;
        const scaleAxisRotation = opts.scaleAxisRotation ?? pageRotation;
        const initialBounds = opts.initialBounds ?? this.getShapeGeometry(id).bounds;
        if (!initialBounds) return this;
        const isAspectRatioLocked = opts.isAspectRatioLocked ?? this.getShapeUtil(initialShape).isAspectRatioLocked(initialShape);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areAnglesCompatible"])(pageRotation, scaleAxisRotation)) {
            return this._resizeUnalignedShape(id, scale, {
                ...opts,
                initialBounds,
                scaleOrigin,
                scaleAxisRotation,
                initialPageTransform: pageTransform,
                isAspectRatioLocked,
                initialShape
            });
        }
        const util = this.getShapeUtil(initialShape);
        if (isAspectRatioLocked) {
            if (Math.abs(scale.x) > Math.abs(scale.y)) {
                scale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](scale.x, Math.sign(scale.y) * Math.abs(scale.x));
            } else {
                scale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](Math.sign(scale.x) * Math.abs(scale.y), scale.y);
            }
        }
        let didResize = false;
        if (util.onResize && util.canResize(initialShape)) {
            const newPagePoint = this._scalePagePoint(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(pageTransform, new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0)), scaleOrigin, scale, scaleAxisRotation);
            const newLocalPoint = this.getPointInParentSpace(initialShape.id, newPagePoint);
            const myScale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](scale.x, scale.y);
            const areWidthAndHeightAlignedWithCorrectAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approximately"])((pageRotation - scaleAxisRotation) % Math.PI, 0);
            myScale.x = areWidthAndHeightAlignedWithCorrectAxis ? scale.x : scale.y;
            myScale.y = areWidthAndHeightAlignedWithCorrectAxis ? scale.y : scale.x;
            const initialPagePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(pageTransform, new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"]());
            const { x: x1, y } = this.getPointInParentSpace(initialShape.id, initialPagePoint);
            let workingShape = initialShape;
            if (!opts.skipStartAndEndCallbacks) {
                workingShape = applyPartialToRecordWithProps(initialShape, util.onResizeStart?.(initialShape) ?? void 0);
            }
            const resizedShape = util.onResize({
                ...initialShape,
                x: x1,
                y
            }, {
                newPoint: newLocalPoint,
                handle: opts.dragHandle ?? "bottom_right",
                // don't set isSingle to true for children
                mode: opts.mode ?? "scale_shape",
                scaleX: myScale.x,
                scaleY: myScale.y,
                initialBounds,
                initialShape
            });
            if (resizedShape) {
                didResize = true;
            }
            workingShape = applyPartialToRecordWithProps(workingShape, {
                id,
                type: initialShape.type,
                x: newLocalPoint.x,
                y: newLocalPoint.y,
                ...resizedShape
            });
            if (!opts.skipStartAndEndCallbacks) {
                workingShape = applyPartialToRecordWithProps(workingShape, util.onResizeEnd?.(initialShape, workingShape) ?? void 0);
            }
            this.updateShapes([
                workingShape
            ]);
        }
        if (!didResize) {
            const initialPageCenter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(pageTransform, initialBounds.center);
            const newPageCenter = this._scalePagePoint(initialPageCenter, scaleOrigin, scale, scaleAxisRotation);
            const initialPageCenterInParentSpace = this.getPointInParentSpace(initialShape.id, initialPageCenter);
            const newPageCenterInParentSpace = this.getPointInParentSpace(initialShape.id, newPageCenter);
            const delta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(newPageCenterInParentSpace, initialPageCenterInParentSpace);
            this.updateShapes([
                {
                    id,
                    type: initialShape.type,
                    x: initialShape.x + delta.x,
                    y: initialShape.y + delta.y
                }
            ]);
        }
        return this;
    }
    /** @internal */ _scalePagePoint(point, scaleOrigin, scale, scaleAxisRotation) {
        const relativePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].RotWith(point, scaleOrigin, -scaleAxisRotation).sub(scaleOrigin);
        const newRelativePagePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].MulV(relativePoint, scale);
        const destination = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(newRelativePagePoint, scaleOrigin).rotWith(scaleOrigin, scaleAxisRotation);
        return destination;
    }
    /** @internal */ _resizeUnalignedShape(id, scale, options) {
        const { type } = options.initialShape;
        const shapeScale = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](scale.x, scale.y);
        if (Math.abs(scale.x) > Math.abs(scale.y)) {
            shapeScale.x = Math.sign(scale.x) * Math.abs(scale.y);
        } else {
            shapeScale.y = Math.sign(scale.y) * Math.abs(scale.x);
        }
        this.resizeShape(id, shapeScale, {
            initialShape: options.initialShape,
            initialBounds: options.initialBounds,
            isAspectRatioLocked: options.isAspectRatioLocked,
            initialPageTransform: options.initialPageTransform
        });
        if (Math.sign(scale.x) * Math.sign(scale.y) < 0) {
            const parentRotation = this.getShapeParentTransform(id).rotation();
            const rotation = -options.initialShape.rotation - 2 * parentRotation;
            this.updateShapes([
                {
                    id,
                    type,
                    rotation
                }
            ]);
        }
        const preScaleShapePageCenter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(options.initialPageTransform, options.initialBounds.center);
        const postScaleShapePageCenter = this._scalePagePoint(preScaleShapePageCenter, options.scaleOrigin, scale, options.scaleAxisRotation);
        const pageTransform = this.getShapePageTransform(id);
        const currentLocalBounds = this.getShapeGeometry(id).bounds;
        const currentPageCenter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(pageTransform, currentLocalBounds.center);
        const shapePageTransformOrigin = pageTransform.point();
        if (!currentPageCenter || !shapePageTransformOrigin) return this;
        const pageDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(postScaleShapePageCenter, currentPageCenter);
        const postScaleShapePagePoint = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(shapePageTransformOrigin, pageDelta);
        const { x: x1, y } = this.getPointInParentSpace(id, postScaleShapePagePoint);
        this.updateShapes([
            {
                id,
                type,
                x: x1,
                y
            }
        ]);
        return this;
    }
    /**
   * Get the initial meta value for a shape.
   *
   * @example
   * ```ts
   * editor.getInitialMetaForShape = (shape) => {
   *   if (shape.type === 'note') {
   *     return { createdBy: myCurrentUser.id }
   *   }
   * }
   * ```
   *
   * @param shape - The shape to get the initial meta for.
   *
   * @public
   */ getInitialMetaForShape(_shape) {
        return {};
    }
    /**
   * Get whether the provided shape can be created.
   *
   * @param shape - The shape or shape IDs to check.
   *
   * @public
   */ canCreateShape(shape) {
        return this.canCreateShapes([
            shape
        ]);
    }
    /**
   * Get whether the provided shapes can be created.
   *
   * @param shapes - The shapes or shape IDs to create.
   *
   * @public
   */ canCreateShapes(shapes) {
        return shapes.length + this.getCurrentPageShapeIds().size <= this.options.maxShapesPerPage;
    }
    /**
   * Create a single shape.
   *
   * @example
   * ```ts
   * editor.createShape(myShape)
   * editor.createShape({ id: 'box1', type: 'text', props: { richText: toRichText("ok") } })
   * ```
   *
   * @param shape - The shape (or shape partial) to create.
   *
   * @public
   */ createShape(shape) {
        this.createShapes([
            shape
        ]);
        return this;
    }
    /**
   * Create shapes.
   *
   * @example
   * ```ts
   * editor.createShapes([myShape])
   * editor.createShapes([{ id: 'box1', type: 'text', props: { richText: toRichText("ok") } }])
   * ```
   *
   * @param shapes - The shapes (or shape partials) to create.
   *
   * @public
   */ createShapes(shapes) {
        if (!Array.isArray(shapes)) {
            throw Error("Editor.createShapes: must provide an array of shapes or shape partials");
        }
        if (this.getIsReadonly()) return this;
        if (shapes.length <= 0) return this;
        const currentPageShapeIds = this.getCurrentPageShapeIds();
        const maxShapesReached = shapes.length + currentPageShapeIds.size > this.options.maxShapesPerPage;
        if (maxShapesReached) {
            alertMaxShapes(this);
            return this;
        }
        const focusedGroupId = this.getFocusedGroupId();
        this.run(()=>{
            const currentPageShapesSorted = this.getCurrentPageShapesSorted();
            const partials = shapes.map((partial)=>{
                if (!partial.id) {
                    partial = {
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(),
                        ...partial
                    };
                }
                if (!partial.parentId || !(this.store.has(partial.parentId) || shapes.some((p)=>p.id === partial.parentId))) {
                    let parentId = this.getFocusedGroupId();
                    const isPositioned = partial.x !== void 0 && partial.y !== void 0;
                    if (isPositioned) {
                        for(let i = currentPageShapesSorted.length - 1; i >= 0; i--){
                            const parent = currentPageShapesSorted[i];
                            const util = this.getShapeUtil(parent);
                            if (util.canReceiveNewChildrenOfType(parent, partial.type) && !this.isShapeHidden(parent) && this.isPointInShape(parent, // If no parent is provided, then we can treat the
                            // shape's provided x/y as being in the page's space.
                            {
                                x: partial.x ?? 0,
                                y: partial.y ?? 0
                            }, {
                                margin: 0,
                                hitInside: true
                            })) {
                                parentId = parent.id;
                                break;
                            }
                        }
                    }
                    const prevParentId = partial.parentId;
                    if (parentId === partial.id) {
                        parentId = focusedGroupId;
                    }
                    if (parentId !== prevParentId) {
                        partial = {
                            ...partial
                        };
                        partial.parentId = parentId;
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShapeId"])(parentId)) {
                            const point = this.getPointInShapeSpace(this.getShape(parentId), {
                                x: partial.x ?? 0,
                                y: partial.y ?? 0
                            });
                            partial.x = point.x;
                            partial.y = point.y;
                            partial.rotation = -this.getShapePageTransform(parentId).rotation() + (partial.rotation ?? 0);
                        }
                    }
                }
                return partial;
            });
            const parentIndices = /* @__PURE__ */ new Map();
            const shapeRecordsToCreate = [];
            const { opacityForNextShape } = this.getInstanceState();
            for (const partial of partials){
                const util = this.getShapeUtil(partial);
                let index = partial.index;
                if (!index) {
                    const parentId = partial.parentId ?? focusedGroupId;
                    if (!parentIndices.has(parentId)) {
                        parentIndices.set(parentId, this.getHighestIndexForParent(parentId));
                    }
                    index = parentIndices.get(parentId);
                    parentIndices.set(parentId, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(index));
                }
                const initialProps = util.getDefaultProps();
                for (const [style, propKey] of this.styleProps[partial.type]){
                    ;
                    initialProps[propKey] = this.getStyleForNextShape(style);
                }
                let shapeRecordToCreate = this.store.schema.types.shape.create({
                    ...partial,
                    index,
                    opacity: partial.opacity ?? opacityForNextShape,
                    parentId: partial.parentId ?? focusedGroupId,
                    props: "props" in partial ? {
                        ...initialProps,
                        ...partial.props
                    } : initialProps
                });
                if (shapeRecordToCreate.index === void 0) {
                    throw Error("no index!");
                }
                const next = this.getShapeUtil(shapeRecordToCreate).onBeforeCreate?.(shapeRecordToCreate);
                if (next) {
                    shapeRecordToCreate = next;
                }
                shapeRecordsToCreate.push(shapeRecordToCreate);
            }
            shapeRecordsToCreate.forEach((shape)=>{
                shape.meta = {
                    ...this.getInitialMetaForShape(shape),
                    ...shape.meta
                };
            });
            this.emit("created-shapes", shapeRecordsToCreate);
            this.emit("edit");
            this.store.put(shapeRecordsToCreate);
        });
        return this;
    }
    /**
   * Animate a shape.
   *
   * @example
   * ```ts
   * editor.animateShape({ id: 'box1', type: 'box', x: 100, y: 100 })
   * editor.animateShape({ id: 'box1', type: 'box', x: 100, y: 100 }, { animation: { duration: 100, ease: t => t*t } })
   * ```
   *
   * @param partial - The shape partial to update.
   * @param opts - The animation's options.
   *
   * @public
   */ animateShape(partial, opts = {
        animation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ANIMATION_OPTIONS"]
    }) {
        return this.animateShapes([
            partial
        ], opts);
    }
    /**
   * Animate shapes.
   *
   * @example
   * ```ts
   * editor.animateShapes([{ id: 'box1', type: 'box', x: 100, y: 100 }])
   * editor.animateShapes([{ id: 'box1', type: 'box', x: 100, y: 100 }], { animation: { duration: 100, ease: t => t*t } })
   * ```
   *
   * @param partials - The shape partials to update.
   * @param opts - The animation's options.
   *
   * @public
   */ animateShapes(partials, opts = {
        animation: __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ANIMATION_OPTIONS"]
    }) {
        if (!opts.animation) return this;
        const { duration = 500, easing = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$easings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASINGS"].linear } = opts.animation;
        const animationId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$id$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniqueId"])();
        let remaining = duration;
        let t;
        const animations = [];
        let partial, result;
        for(let i = 0, n = partials.length; i < n; i++){
            partial = partials[i];
            if (!partial) continue;
            const shape = this.getShape(partial.id);
            if (!shape) continue;
            result = {
                start: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(shape),
                end: applyPartialToRecordWithProps((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(shape), partial)
            };
            animations.push(result);
            this.animatingShapes.set(shape.id, animationId);
        }
        const handleTick = (elapsed)=>{
            remaining -= elapsed;
            if (remaining < 0) {
                const { animatingShapes: animatingShapes2 } = this;
                const partialsToUpdate = partials.filter((p)=>p && animatingShapes2.get(p.id) === animationId);
                if (partialsToUpdate.length) {
                    this.updateShapes(partialsToUpdate);
                }
                this.off("tick", handleTick);
                return;
            }
            t = easing(1 - remaining / duration);
            const { animatingShapes } = this;
            const updates = [];
            let animationIdForShape;
            for(let i = 0, n = animations.length; i < n; i++){
                const { start, end } = animations[i];
                animationIdForShape = animatingShapes.get(start.id);
                if (animationIdForShape !== animationId) continue;
                updates.push({
                    ...end,
                    x: start.x + (end.x - start.x) * t,
                    y: start.y + (end.y - start.y) * t,
                    opacity: start.opacity + (end.opacity - start.opacity) * t,
                    rotation: start.rotation + (end.rotation - start.rotation) * t,
                    props: this.getShapeUtil(end).getInterpolatedProps?.(start, end, t) ?? end.props
                });
            }
            this._updateShapes(updates);
        };
        this.on("tick", handleTick);
        return this;
    }
    groupShapes(shapes, opts = {}) {
        const { groupId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])(), select = true } = opts;
        if (!Array.isArray(shapes)) {
            throw Error("Editor.groupShapes: must provide an array of shapes or shape ids");
        }
        if (this.getIsReadonly()) return this;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length <= 1) return this;
        const shapesToGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])((this._shouldIgnoreShapeLock ? ids : this._getUnlockedShapeIds(ids)).map((id)=>this.getShape(id)));
        const sortedShapeIds = shapesToGroup.sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]).map((s)=>s.id);
        const childBounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(shapesToGroup.map((shape)=>this.getShapePageBounds(shape)));
        const pageBounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(childBounds);
        if (!pageBounds.isValid()) {
            throw Error(`Editor.groupShapes: group bounds are invalid (NaN).`);
        }
        const { x: x1, y } = pageBounds.point;
        const parentId = this.findCommonAncestor(shapesToGroup) ?? this.getCurrentPageId();
        if (this.getCurrentToolId() !== "select") return this;
        if (!this.isIn("select.idle")) {
            this.cancel();
        }
        const shapesWithRootParent = shapesToGroup.filter((shape)=>shape.parentId === parentId).sort(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByIndex"]);
        const highestIndex = shapesWithRootParent[shapesWithRootParent.length - 1]?.index;
        this.run(()=>{
            this.createShapes([
                {
                    id: groupId,
                    type: "group",
                    parentId,
                    index: highestIndex,
                    x: x1,
                    y,
                    opacity: 1,
                    props: {}
                }
            ]);
            this.reparentShapes(sortedShapeIds, groupId);
            if (select) {
                this.select(groupId);
            }
        });
        return this;
    }
    ungroupShapes(shapes, opts = {}) {
        if (this.getIsReadonly()) return this;
        const { select = true } = opts;
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        const shapesToUngroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])((this._shouldIgnoreShapeLock ? ids : this._getUnlockedShapeIds(ids)).map((id)=>this.getShape(id)));
        if (shapesToUngroup.length === 0) return this;
        if (this.getCurrentToolId() !== "select") return this;
        if (!this.isIn("select.idle")) {
            this.cancel();
        }
        const idsToSelect = /* @__PURE__ */ new Set();
        const groups = [];
        shapesToUngroup.forEach((shape)=>{
            if (this.isShapeOfType(shape, "group")) {
                groups.push(shape);
            } else {
                idsToSelect.add(shape.id);
            }
        });
        if (groups.length === 0) return this;
        this.run(()=>{
            let group;
            for(let i = 0, n = groups.length; i < n; i++){
                group = groups[i];
                const childIds = this.getSortedChildIdsForParent(group.id);
                for(let j = 0, n2 = childIds.length; j < n2; j++){
                    idsToSelect.add(childIds[j]);
                }
                this.reparentShapes(childIds, group.parentId, group.index);
            }
            this.deleteShapes(groups.map((group2)=>group2.id));
            if (select) {
                this.select(...idsToSelect);
            }
        });
        return this;
    }
    /**
   * Update a shape using a partial of the shape.
   *
   * @example
   * ```ts
   * editor.updateShape({ id: 'box1', type: 'geo', props: { w: 100, h: 100 } })
   * ```
   *
   * @param partial - The shape partial to update.
   *
   * @public
   */ updateShape(partial) {
        this.updateShapes([
            partial
        ]);
        return this;
    }
    /**
   * Update shapes using partials of each shape.
   *
   * @example
   * ```ts
   * editor.updateShapes([{ id: 'box1', type: 'geo', props: { w: 100, h: 100 } }])
   * ```
   *
   * @param partials - The shape partials to update.
   *
   * @public
   */ updateShapes(partials) {
        const compactedPartials = Array(partials.length);
        for(let i = 0, n = partials.length; i < n; i++){
            const partial = partials[i];
            if (!partial) continue;
            const shape = this.getShape(partial.id);
            if (!shape) continue;
            if (!this._shouldIgnoreShapeLock) {
                if (shape.isLocked) {
                    if (!(Object.hasOwn(partial, "isLocked") && !partial.isLocked)) {
                        continue;
                    }
                } else if (this.isShapeOrAncestorLocked(shape)) {
                    continue;
                }
            }
            this.animatingShapes.delete(partial.id);
            compactedPartials.push(partial);
        }
        this._updateShapes(compactedPartials);
        return this;
    }
    /** @internal */ _updateShapes(_partials) {
        if (this.getIsReadonly()) return;
        this.run(()=>{
            const updates = [];
            let shape;
            let updated;
            for(let i = 0, n = _partials.length; i < n; i++){
                const partial = _partials[i];
                if (!partial) continue;
                shape = this.getShape(partial.id);
                if (!shape) continue;
                updated = applyPartialToRecordWithProps(shape, partial);
                if (updated === shape) continue;
                updated = this.getShapeUtil(shape).onBeforeUpdate?.(shape, updated) ?? updated;
                updates.push(updated);
            }
            this.emit("edited-shapes", updates);
            this.emit("edit");
            this.store.put(updates);
        });
    }
    /** @internal */ _getUnlockedShapeIds(ids) {
        return ids.filter((id)=>!this.getShape(id)?.isLocked);
    }
    deleteShapes(_ids) {
        if (this.getIsReadonly()) return this;
        if (!Array.isArray(_ids)) {
            throw Error("Editor.deleteShapes: must provide an array of shapes or shapeIds");
        }
        const shapeIds = typeof _ids[0] === "string" ? _ids : _ids.map((s)=>s.id);
        const shapeIdsToDelete = this._shouldIgnoreShapeLock ? shapeIds : this._getUnlockedShapeIds(shapeIds);
        if (shapeIdsToDelete.length === 0) return this;
        const allShapeIdsToDelete = new Set(shapeIdsToDelete);
        for (const id of shapeIdsToDelete){
            this.visitDescendants(id, (childId)=>{
                allShapeIdsToDelete.add(childId);
            });
        }
        this.emit("deleted-shapes", [
            ...allShapeIdsToDelete
        ]);
        this.emit("edit");
        return this.run(()=>this.store.remove([
                ...allShapeIdsToDelete
            ]));
    }
    deleteShape(_id) {
        this.deleteShapes([
            typeof _id === "string" ? _id : _id.id
        ]);
        return this;
    }
    /* --------------------- Styles --------------------- */ /**
   * Get all the current styles among the users selected shapes
   *
   * @internal
   */ _extractSharedStyles(shape, sharedStyleMap) {
        if (this.isShapeOfType(shape, "group")) {
            const childIds = this._parentIdsToChildIds.get()[shape.id];
            if (!childIds) return;
            for(let i = 0, n = childIds.length; i < n; i++){
                this._extractSharedStyles(this.getShape(childIds[i]), sharedStyleMap);
            }
        } else {
            for (const [style, propKey] of this.styleProps[shape.type]){
                sharedStyleMap.applyValue(style, (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(shape.props, propKey));
            }
        }
    }
    _getSelectionSharedStyles() {
        const selectedShapes = this.getSelectedShapes();
        const sharedStyles = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$SharedStylesMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SharedStyleMap"]();
        for (const selectedShape of selectedShapes){
            this._extractSharedStyles(selectedShape, sharedStyles);
        }
        return sharedStyles;
    }
    /**
   * Get the style for the next shape.
   *
   * @example
   * ```ts
   * const color = editor.getStyleForNextShape(DefaultColorStyle)
   * ```
   *
   * @param style - The style to get.
   *
   * @public */ getStyleForNextShape(style) {
        const value = this.getInstanceState().stylesForNextShape[style.id];
        return value === void 0 ? style.defaultValue : value;
    }
    getShapeStyleIfExists(shape, style) {
        const styleKey = this.styleProps[shape.type].get(style);
        if (styleKey === void 0) return void 0;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$object$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnProperty"])(shape.props, styleKey);
    }
    getSharedStyles() {
        if (this.isIn("select") && this.getSelectedShapeIds().length > 0) {
            return this._getSelectionSharedStyles();
        }
        const currentTool = this.root.getCurrent();
        const styles = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$SharedStylesMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SharedStyleMap"]();
        if (!currentTool) return styles;
        if (currentTool.shapeType) {
            if (currentTool.shapeType === "frame" && !this.getShapeUtil("frame").options.showColors) {
                for (const style of this.styleProps[currentTool.shapeType].keys()){
                    if (style.id === "tldraw:color") continue;
                    styles.applyValue(style, this.getStyleForNextShape(style));
                }
            } else {
                for (const style of this.styleProps[currentTool.shapeType].keys()){
                    styles.applyValue(style, this.getStyleForNextShape(style));
                }
            }
        }
        return styles;
    }
    getSharedOpacity() {
        if (this.isIn("select") && this.getSelectedShapeIds().length > 0) {
            const shapesToCheck = [];
            const addShape = (shapeId)=>{
                const shape = this.getShape(shapeId);
                if (!shape) return;
                if (this.isShapeOfType(shape, "group")) {
                    for (const childId of this.getSortedChildIdsForParent(shape.id)){
                        addShape(childId);
                    }
                } else {
                    shapesToCheck.push(shape);
                }
            };
            for (const shapeId of this.getSelectedShapeIds()){
                addShape(shapeId);
            }
            let opacity = null;
            for (const shape of shapesToCheck){
                if (opacity === null) {
                    opacity = shape.opacity;
                } else if (opacity !== shape.opacity) {
                    return {
                        type: "mixed"
                    };
                }
            }
            if (opacity !== null) return {
                type: "shared",
                value: opacity
            };
        }
        return {
            type: "shared",
            value: this.getInstanceState().opacityForNextShape
        };
    }
    /**
   * Set the opacity for the next shapes. This will effect subsequently created shapes.
   *
   * @example
   * ```ts
   * editor.setOpacityForNextShapes(0.5)
   * ```
   *
   * @param opacity - The opacity to set. Must be a number between 0 and 1 inclusive.
   * @param historyOptions - The history options for the change.
   */ setOpacityForNextShapes(opacity, historyOptions) {
        this.updateInstanceState({
            opacityForNextShape: opacity
        }, historyOptions);
        return this;
    }
    /**
   * Set the current opacity. This will effect any selected shapes.
   *
   * @example
   * ```ts
   * editor.setOpacityForSelectedShapes(0.5)
   * ```
   *
   * @param opacity - The opacity to set. Must be a number between 0 and 1 inclusive.
   */ setOpacityForSelectedShapes(opacity) {
        const selectedShapes = this.getSelectedShapes();
        if (selectedShapes.length > 0) {
            const shapesToUpdate = [];
            const addShapeById = (shape)=>{
                if (this.isShapeOfType(shape, "group")) {
                    const childIds = this.getSortedChildIdsForParent(shape);
                    for (const childId of childIds){
                        addShapeById(this.getShape(childId));
                    }
                } else {
                    shapesToUpdate.push(shape);
                }
            };
            for (const id of selectedShapes){
                addShapeById(id);
            }
            this.updateShapes(shapesToUpdate.map((shape)=>{
                return {
                    id: shape.id,
                    type: shape.type,
                    opacity
                };
            }));
        }
        return this;
    }
    /**
   * Set the value of a {@link @tldraw/tlschema#StyleProp} for the next shapes. This change will be applied to subsequently created shapes.
   *
   * @example
   * ```ts
   * editor.setStyleForNextShapes(DefaultColorStyle, 'red')
   * editor.setStyleForNextShapes(DefaultColorStyle, 'red', { ephemeral: true })
   * ```
   *
   * @param style - The style to set.
   * @param value - The value to set.
   * @param historyOptions - The history options for the change.
   *
   * @public
   */ setStyleForNextShapes(style, value, historyOptions) {
        const stylesForNextShape = this.getInstanceState().stylesForNextShape;
        this.updateInstanceState({
            stylesForNextShape: {
                ...stylesForNextShape,
                [style.id]: value
            }
        }, historyOptions);
        return this;
    }
    /**
   * Set the value of a {@link @tldraw/tlschema#StyleProp}. This change will be applied to the currently selected shapes.
   *
   * @example
   * ```ts
   * editor.setStyleForSelectedShapes(DefaultColorStyle, 'red')
   * ```
   *
   * @param style - The style to set.
   * @param value - The value to set.
   *
   * @public
   */ setStyleForSelectedShapes(style, value) {
        const selectedShapes = this.getSelectedShapes();
        if (selectedShapes.length > 0) {
            const updates = [];
            const addShapeById = (shape)=>{
                if (this.isShapeOfType(shape, "group")) {
                    const childIds = this.getSortedChildIdsForParent(shape.id);
                    for (const childId of childIds){
                        addShapeById(this.getShape(childId));
                    }
                } else {
                    const util = this.getShapeUtil(shape);
                    const stylePropKey = this.styleProps[shape.type].get(style);
                    if (stylePropKey) {
                        const shapePartial = {
                            id: shape.id,
                            type: shape.type,
                            props: {
                                [stylePropKey]: value
                            }
                        };
                        updates.push({
                            util,
                            originalShape: shape,
                            updatePartial: shapePartial
                        });
                    }
                }
            };
            for (const shape of selectedShapes){
                addShapeById(shape);
            }
            this.updateShapes(updates.map(({ updatePartial })=>updatePartial));
        }
        return this;
    }
    /**
   * Register an external asset handler. This handler will be called when the editor needs to
   * create an asset for some external content, like an image/video file or a bookmark URL. For
   * example, the 'file' type handler will be called when a user drops an image onto the canvas.
   *
   * The handler should extract any relevant metadata for the asset, upload it to blob storage
   * using {@link Editor.uploadAsset} if needed, and return the asset with the metadata & uploaded
   * URL.
   *
   * @example
   * ```ts
   * editor.registerExternalAssetHandler('file', myHandler)
   * ```
   *
   * @param type - The type of external content.
   * @param handler - The handler to use for this content type.
   *
   * @public
   */ registerExternalAssetHandler(type, handler) {
        this.externalAssetContentHandlers[type] = handler;
        return this;
    }
    /**
   * Register a temporary preview of an asset. This is useful for showing a ghost image of
   * something that is being uploaded. Retrieve the placeholder with
   * {@link Editor.getTemporaryAssetPreview}. Placeholders last for 3 minutes by default, but this
   * can be configured using
   *
   * @example
   * ```ts
   * editor.createTemporaryAssetPreview(assetId, file)
   * ```
   *
   * @param assetId - The asset's id.
   * @param file - The raw file.
   *
   * @public
   */ createTemporaryAssetPreview(assetId, file) {
        if (this.temporaryAssetPreview.has(assetId)) {
            return this.temporaryAssetPreview.get(assetId);
        }
        const objectUrl = URL.createObjectURL(file);
        this.temporaryAssetPreview.set(assetId, objectUrl);
        setTimeout(()=>{
            this.temporaryAssetPreview.delete(assetId);
            URL.revokeObjectURL(objectUrl);
        }, this.options.temporaryAssetPreviewLifetimeMs);
        return objectUrl;
    }
    /**
   * Get temporary preview of an asset. This is useful for showing a ghost
   * image of something that is being uploaded.
   *
   * @example
   * ```ts
   * editor.getTemporaryAssetPreview('someId')
   * ```
   *
   * @param assetId - The asset's id.
   *
   * @public
   */ getTemporaryAssetPreview(assetId) {
        return this.temporaryAssetPreview.get(assetId);
    }
    /**
   * Get an asset for an external asset content type.
   *
   * @example
   * ```ts
   * const asset = await editor.getAssetForExternalContent({ type: 'file', file: myFile })
   * const asset = await editor.getAssetForExternalContent({ type: 'url', url: myUrl })
   * ```
   *
   * @param info - Info about the external content.
   * @returns The asset.
   */ async getAssetForExternalContent(info) {
        return await this.externalAssetContentHandlers[info.type]?.(info);
    }
    hasExternalAssetHandler(type) {
        return !!this.externalAssetContentHandlers[type];
    }
    /**
   * Register an external content handler. This handler will be called when the editor receives
   * external content of the provided type. For example, the 'image' type handler will be called
   * when a user drops an image onto the canvas.
   *
   * @example
   * ```ts
   * editor.registerExternalContentHandler('text', myHandler)
   * ```
   * @example
   * ```ts
   * editor.registerExternalContentHandler<'embed', MyEmbedType>('embed', myHandler)
   * ```
   *
   * @param type - The type of external content.
   * @param handler - The handler to use for this content type.
   *
   * @public
   */ registerExternalContentHandler(type, handler) {
        this.externalContentHandlers[type] = handler;
        return this;
    }
    /**
   * Handle external content, such as files, urls, embeds, or plain text which has been put into the app, for example by pasting external text or dropping external images onto canvas.
   *
   * @param info - Info about the external content.
   * @param opts - Options for handling external content, including force flag to bypass readonly checks.
   */ async putExternalContent(info, opts = {}) {
        if (!opts.force && this.getIsReadonly()) return;
        return this.externalContentHandlers[info.type]?.(info);
    }
    /**
   * Handle replacing external content.
   *
   * @param info - Info about the external content.
   * @param opts - Options for handling external content, including force flag to bypass readonly checks.
   */ async replaceExternalContent(info, opts = {}) {
        if (!opts.force && this.getIsReadonly()) return;
        return this.externalContentHandlers[info.type]?.(info);
    }
    /**
   * Get content that can be exported for the given shape ids.
   *
   * @param shapes - The shapes (or shape ids) to get content for.
   *
   * @returns The exported content.
   *
   * @public
   */ getContentFromCurrentPage(shapes) {
        const ids = typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (!ids) return;
        if (ids.length === 0) return;
        const shapeIds = this.getShapeAndDescendantIds(ids);
        return withIsolatedShapes(this, shapeIds, (bindingIdsToKeep)=>{
            const bindings = [];
            for (const id of bindingIdsToKeep){
                const binding = this.getBinding(id);
                if (!binding) continue;
                bindings.push(binding);
            }
            const rootShapeIds = [];
            const shapes2 = [];
            for (const shapeId of shapeIds){
                const shape = this.getShape(shapeId);
                if (!shape) continue;
                const isRootShape = !shapeIds.has(shape.parentId);
                if (isRootShape) {
                    const pageTransform = this.getShapePageTransform(shape.id);
                    const pagePoint = pageTransform.point();
                    shapes2.push({
                        ...shape,
                        x: pagePoint.x,
                        y: pagePoint.y,
                        rotation: pageTransform.rotation(),
                        parentId: this.getCurrentPageId()
                    });
                    rootShapeIds.push(shape.id);
                } else {
                    shapes2.push(shape);
                }
            }
            const assets = [];
            const seenAssetIds = /* @__PURE__ */ new Set();
            for (const shape of shapes2){
                if (!("assetId" in shape.props)) continue;
                const assetId = shape.props.assetId;
                if (!assetId || seenAssetIds.has(assetId)) continue;
                seenAssetIds.add(assetId);
                const asset = this.getAsset(assetId);
                if (!asset) continue;
                assets.push(asset);
            }
            return {
                schema: this.store.schema.serialize(),
                shapes: shapes2,
                rootShapeIds,
                bindings,
                assets
            };
        });
    }
    async resolveAssetsInContent(content) {
        if (!content) return void 0;
        const assets = [];
        await Promise.allSettled(content.assets.map(async (asset)=>{
            if ((asset.type === "image" || asset.type === "video") && !asset.props.src?.startsWith("data:image") && !asset.props.src?.startsWith("data:video") && !asset.props.src?.startsWith("http")) {
                const assetWithDataUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(asset);
                const objectUrl = await this.store.props.assets.resolve(asset, {
                    screenScale: 1,
                    steppedScreenScale: 1,
                    dpr: 1,
                    networkEffectiveType: null,
                    shouldResolveToOriginal: true
                });
                assetWithDataUrl.props.src = await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$network$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch"])(objectUrl).then((r)=>r.blob()));
                assets.push(assetWithDataUrl);
            } else {
                assets.push(asset);
            }
        }));
        content.assets = assets;
        return content;
    }
    /**
   * Place content into the editor.
   *
   * @param content - The content.
   * @param opts - Options for placing the content.
   *
   * @public
   */ putContentOntoCurrentPage(content, opts = {}) {
        if (this.getIsReadonly()) return this;
        if (!content.schema) {
            throw Error("Could not put content:\ncontent is missing a schema.");
        }
        const { select = false, preserveIds = false, preservePosition = false } = opts;
        let { point = void 0 } = opts;
        const currentPageId = this.getCurrentPageId();
        const { rootShapeIds } = content;
        const assets = [];
        const shapes = [];
        const bindings = [];
        const store = {
            store: {
                ...Object.fromEntries(content.assets.map((asset)=>[
                        asset.id,
                        asset
                    ])),
                ...Object.fromEntries(content.shapes.map((shape)=>[
                        shape.id,
                        shape
                    ])),
                ...Object.fromEntries(content.bindings?.map((bindings2)=>[
                        bindings2.id,
                        bindings2
                    ]) ?? [])
            },
            schema: content.schema
        };
        const result = this.store.schema.migrateStoreSnapshot(store);
        if (result.type === "error") {
            throw Error("Could not put content: could not migrate content");
        }
        for (const record of Object.values(result.value)){
            switch(record.typeName){
                case "asset":
                    {
                        assets.push(record);
                        break;
                    }
                case "shape":
                    {
                        shapes.push(record);
                        break;
                    }
                case "binding":
                    {
                        bindings.push(record);
                        break;
                    }
            }
        }
        const shapeIdMap = new Map(preserveIds ? shapes.map((shape)=>[
                shape.id,
                shape.id
            ]) : shapes.map((shape)=>[
                shape.id,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])()
            ]));
        const bindingIdMap = new Map(preserveIds ? bindings.map((binding)=>[
                binding.id,
                binding.id
            ]) : bindings.map((binding)=>[
                binding.id,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLBinding$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingId"])()
            ]));
        let pasteParentId = this.getCurrentPageId();
        let lowestDepth = Infinity;
        let lowestAncestors = [];
        for (const shape of this.getSelectedShapes()){
            if (lowestDepth === 0) break;
            const isFrame = this.isShapeOfType(shape, "frame");
            const ancestors = this.getShapeAncestors(shape);
            if (isFrame) ancestors.push(shape);
            const depth = isFrame ? ancestors.length + 1 : ancestors.length;
            if (depth < lowestDepth) {
                lowestDepth = depth;
                lowestAncestors = ancestors;
                pasteParentId = isFrame ? shape.id : shape.parentId;
            } else if (depth === lowestDepth) {
                if (lowestAncestors.length !== ancestors.length) {
                    throw Error(`Ancestors: ${lowestAncestors.length} !== ${ancestors.length}`);
                }
                if (lowestAncestors.length === 0) {
                    pasteParentId = currentPageId;
                    break;
                } else {
                    pasteParentId = currentPageId;
                    for(let i = 0; i < lowestAncestors.length; i++){
                        if (ancestors[i] !== lowestAncestors[i]) break;
                        pasteParentId = ancestors[i].id;
                    }
                }
            }
        }
        if (point) {
            const shapesById = new Map(shapes.map((shape)=>[
                    shape.id,
                    shape
                ]));
            const rootShapesFromContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(rootShapeIds.map((id)=>shapesById.get(id)));
            if (rootShapesFromContent.length > 0) {
                const targetParent = this.getShapeAtPoint(point, {
                    hitInside: true,
                    hitFrameInside: true,
                    hitLocked: true,
                    filter: (shape)=>{
                        const util = this.getShapeUtil(shape);
                        if (!util.canReceiveNewChildrenOfType) return false;
                        return rootShapesFromContent.every((rootShape)=>util.canReceiveNewChildrenOfType(shape, rootShape.type));
                    }
                });
                pasteParentId = targetParent ? targetParent.id : currentPageId;
            }
        }
        let isDuplicating = false;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(pasteParentId)) {
            const parent = this.getShape(pasteParentId);
            if (parent) {
                if (!this.getViewportPageBounds().includes(this.getShapePageBounds(parent))) {
                    pasteParentId = currentPageId;
                } else {
                    if (rootShapeIds.length === 1) {
                        const rootShape = shapes.find((s)=>s.id === rootShapeIds[0]);
                        if (this.isShapeOfType(parent, "frame") && this.isShapeOfType(rootShape, "frame") && rootShape.props.w === parent?.props.w && rootShape.props.h === parent?.props.h) {
                            isDuplicating = true;
                        }
                    }
                }
            } else {
                pasteParentId = currentPageId;
            }
        }
        if (!isDuplicating) {
            isDuplicating = shapeIdMap.has(pasteParentId);
        }
        if (isDuplicating) {
            pasteParentId = this.getShape(pasteParentId).parentId;
        }
        let index = this.getHighestIndexForParent(pasteParentId);
        const rootShapes = [];
        const newShapes = shapes.map((oldShape)=>{
            const newId = shapeIdMap.get(oldShape.id);
            const newShape = {
                ...oldShape,
                id: newId
            };
            if (rootShapeIds.includes(oldShape.id)) {
                newShape.parentId = currentPageId;
                rootShapes.push(newShape);
            }
            if (shapeIdMap.has(newShape.parentId)) {
                newShape.parentId = shapeIdMap.get(oldShape.parentId);
            } else {
                rootShapeIds.push(newShape.id);
                newShape.index = index;
                index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$reordering$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndexAbove"])(index);
            }
            return newShape;
        });
        if (newShapes.length + this.getCurrentPageShapeIds().size > this.options.maxShapesPerPage) {
            alertMaxShapes(this);
            return this;
        }
        const newBindings = bindings.map((oldBinding)=>({
                ...oldBinding,
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(bindingIdMap.get(oldBinding.id)),
                fromId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(shapeIdMap.get(oldBinding.fromId)),
                toId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertExists"])(shapeIdMap.get(oldBinding.toId))
            }));
        const assetsToCreate = [];
        const assetsToUpdate = [];
        for (const asset of assets){
            if (this.store.has(asset.id)) {
                continue;
            }
            if (asset.type === "image" && asset.props.src?.startsWith("data:image") || asset.type === "video" && asset.props.src?.startsWith("data:video")) {
                assetsToUpdate.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(asset));
                asset.props.src = null;
            }
            assetsToCreate.push(asset);
        }
        Promise.allSettled(assetsToUpdate.map(async (asset)=>{
            const file = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$assets$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataUrlToFile"])(asset.props.src, asset.props.name, asset.props.mimeType ?? "image/png");
            const newAsset = await this.getAssetForExternalContent({
                type: "file",
                file,
                assetId: asset.id
            });
            if (!newAsset) {
                this.deleteAssets([
                    asset.id
                ]);
                return;
            }
            this.updateAssets([
                {
                    ...newAsset,
                    id: asset.id
                }
            ]);
        }));
        this.run(()=>{
            if (assetsToCreate.length > 0) {
                this.createAssets(assetsToCreate);
            }
            this.createShapes(newShapes);
            this.createBindings(newBindings);
            if (select) {
                this.select(...rootShapes.map((s)=>s.id));
            }
            if (pasteParentId !== currentPageId) {
                this.reparentShapes(rootShapes.map((s)=>s.id), pasteParentId);
            }
            const newCreatedShapes = newShapes.map((s)=>this.getShape(s.id));
            const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(newCreatedShapes.map((s)=>this.getShapePageBounds(s)));
            if (point === void 0) {
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLPage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageId"])(pasteParentId)) {
                    const shape = this.getShape(pasteParentId);
                    point = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Mat$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mat"].applyToPoint(this.getShapePageTransform(shape), this.getShapeGeometry(shape).bounds.center);
                } else {
                    const viewportPageBounds = this.getViewportPageBounds();
                    if (preservePosition || viewportPageBounds.includes(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].From(bounds))) {
                        point = bounds.center;
                    } else {
                        point = viewportPageBounds.center;
                    }
                }
            }
            if (rootShapes.length === 1) {
                const onlyRoot = rootShapes[0];
                if (this.isShapeOfType(onlyRoot, "frame")) {
                    while(this.getShapesAtPoint(point).some((shape)=>this.isShapeOfType(shape, "frame") && shape.props.w === onlyRoot.props.w && shape.props.h === onlyRoot.props.h)){
                        point.x += bounds.w + 16;
                    }
                }
            }
            const pageCenter = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(rootShapes.map(({ id })=>this.getShapePageBounds(id)))).center;
            const offset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(point, pageCenter);
            this.updateShapes(rootShapes.map(({ id })=>{
                const s = this.getShape(id);
                const localRotation = this.getShapeParentTransform(id).decompose().rotation;
                const localDelta = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Rot(offset, -localRotation);
                return {
                    id: s.id,
                    type: s.type,
                    x: s.x + localDelta.x,
                    y: s.y + localDelta.y
                };
            }));
        });
        return this;
    }
    /**
   * Get an exported SVG element of the given shapes.
   *
   * @param shapes - The shapes (or shape ids) to export.
   * @param opts - Options for the export.
   *
   * @returns The SVG element.
   *
   * @public
   */ async getSvgElement(shapes, opts = {}) {
        const ids = shapes.length === 0 ? this.getCurrentPageShapeIdsSorted() : typeof shapes[0] === "string" ? shapes : shapes.map((s)=>s.id);
        if (ids.length === 0) return void 0;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$exportToSvg$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportToSvg"])(this, ids, opts);
    }
    /**
   * Get an exported SVG string of the given shapes.
   *
   * @param shapes - The shapes (or shape ids) to export.
   * @param opts - Options for the export.
   *
   * @returns The SVG element.
   *
   * @public
   */ async getSvgString(shapes, opts = {}) {
        const result = await this.getSvgElement(shapes, opts);
        if (!result) return void 0;
        const serializer = new XMLSerializer();
        return {
            svg: serializer.serializeToString(result.svg),
            width: result.width,
            height: result.height
        };
    }
    /**
   * Get an exported image of the given shapes.
   *
   * @param shapes - The shapes (or shape ids) to export.
   * @param opts - Options for the export.
   *
   * @returns A blob of the image.
   * @public
   */ async toImage(shapes, opts = {}) {
        const withDefaults = {
            format: "png",
            scale: 1,
            pixelRatio: opts.format === "svg" ? void 0 : 2,
            ...opts
        };
        const result = await this.getSvgString(shapes, withDefaults);
        if (!result) throw new Error("Could not create SVG");
        switch(withDefaults.format){
            case "svg":
                return {
                    blob: new Blob([
                        result.svg
                    ], {
                        type: "image/svg+xml"
                    }),
                    width: result.width,
                    height: result.height
                };
            case "jpeg":
            case "png":
            case "webp":
                {
                    const blob = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$exports$2f$getSvgAsImage$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSvgAsImage"])(result.svg, {
                        type: withDefaults.format,
                        quality: withDefaults.quality,
                        pixelRatio: withDefaults.pixelRatio,
                        width: result.width,
                        height: result.height
                    });
                    if (!blob) {
                        throw new Error("Could not construct image.");
                    }
                    return {
                        blob,
                        width: result.width,
                        height: result.height
                    };
                }
            default:
                {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(withDefaults.format);
                }
        }
    }
    /**
   * Get an exported image of the given shapes as a data URL.
   *
   * @param shapes - The shapes (or shape ids) to export.
   * @param opts - Options for the export.
   *
   * @returns A data URL of the image.
   * @public
   */ async toImageDataUrl(shapes, opts = {}) {
        const { blob, width, height } = await this.toImage(shapes, opts);
        return {
            url: await __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$file$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileHelpers"].blobToDataUrl(blob),
            width,
            height
        };
    }
    /* --------------------- Events --------------------- */ /**
   * Dispatch a cancel event.
   *
   * @example
   * ```ts
   * editor.cancel()
   * ```
   *
   * @public
   */ cancel() {
        this.dispatch({
            type: "misc",
            name: "cancel"
        });
        return this;
    }
    /**
   * Dispatch an interrupt event.
   *
   * @example
   * ```ts
   * editor.interrupt()
   * ```
   *
   * @public
   */ interrupt() {
        this.dispatch({
            type: "misc",
            name: "interrupt"
        });
        return this;
    }
    /**
   * Dispatch a complete event.
   *
   * @example
   * ```ts
   * editor.complete()
   * ```
   *
   * @public
   */ complete() {
        this.dispatch({
            type: "misc",
            name: "complete"
        });
        return this;
    }
    /**
   * Dispatch a pointer move event in the current position of the pointer. This is useful when
   * external circumstances have changed (e.g. the camera moved or a shape was moved) and you want
   * the current interaction to respond to that change.
   *
   * @example
   * ```ts
   * editor.updatePointer()
   * ```
   *
   * @param options - The options for updating the pointer.
   * @returns The editor instance.
   * @public
   */ updatePointer(options) {
        const event = {
            type: "pointer",
            target: "canvas",
            name: "pointer_move",
            point: options?.point ?? // weird but true: what `inputs` calls screen-space is actually viewport space. so
            // we need to convert back into true screen space first. we should fix this...
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(this.inputs.getCurrentScreenPoint(), this.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]).screenBounds),
            pointerId: options?.pointerId ?? 0,
            button: options?.button ?? 0,
            isPen: options?.isPen ?? this.inputs.getIsPen(),
            shiftKey: options?.shiftKey ?? this.inputs.getShiftKey(),
            altKey: options?.altKey ?? this.inputs.getAltKey(),
            ctrlKey: options?.ctrlKey ?? this.inputs.getCtrlKey(),
            metaKey: options?.metaKey ?? this.inputs.getMetaKey(),
            accelKey: false
        };
        event.accelKey = options?.accelKey ?? this.inputs.getAccelKey();
        if (options?.immediate) {
            this._flushEventForTick(event);
        } else {
            this.dispatch(event);
        }
        return this;
    }
    /**
   * Puts the editor into focused mode.
   *
   * This makes the editor eligible to receive keyboard events and some pointer events (move, wheel).
   *
   * @example
   * ```ts
   * editor.focus()
   * ```
   *
   * By default this also dispatches a 'focus' event to the container element. To prevent this, pass `focusContainer: false`.
   *
   * @example
   * ```ts
   * editor.focus({ focusContainer: false })
   * ```
   *
   * @public
   */ focus({ focusContainer = true } = {}) {
        if (this.getIsFocused()) return this;
        if (focusContainer) this.focusManager.focus();
        this.updateInstanceState({
            isFocused: true
        });
        return this;
    }
    /**
   * Switches off the editor's focused mode.
   *
   * This makes the editor ignore keyboard events and some pointer events (move, wheel).
   *
   * @example
   * ```ts
   * editor.blur()
   * ```
   * By default this also dispatches a 'blur' event to the container element. To prevent this, pass `blurContainer: false`.
   *
   * @example
   * ```ts
   * editor.blur({ blurContainer: false })
   * ```
   *
   * @public
   */ blur({ blurContainer = true } = {}) {
        if (!this.getIsFocused()) return this;
        if (blurContainer) {
            this.focusManager.blur();
        } else {
            this.complete();
        }
        this.updateInstanceState({
            isFocused: false
        });
        return this;
    }
    getIsFocused() {
        return this.getInstanceState().isFocused;
    }
    getIsReadonly() {
        return this.getInstanceState().isReadonly;
    }
    /**
   * @public
   * @returns a snapshot of the store's UI and document state
   */ getSnapshot() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLEditorSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSnapshot"])(this.store);
    }
    /**
   * Loads a snapshot into the editor.
   * @param snapshot - The snapshot to load.
   * @param opts - The options for loading the snapshot.
   * @returns
   */ loadSnapshot(snapshot, opts) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$config$2f$TLEditorSnapshot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadSnapshot"])(this.store, snapshot, opts);
        return this;
    }
    _zoomToFitPageContentAt100Percent() {
        const bounds = this.getCurrentPageBounds();
        if (bounds) {
            this.zoomToBounds(bounds, {
                immediate: true,
                targetZoom: this.getBaseZoom()
            });
        }
    }
    _navigateToDeepLink(deepLink) {
        this.run(()=>{
            switch(deepLink.type){
                case "page":
                    {
                        const page = this.getPage(deepLink.pageId);
                        if (page) {
                            this.setCurrentPage(page);
                        }
                        this._zoomToFitPageContentAt100Percent();
                        return;
                    }
                case "shapes":
                    {
                        const allShapes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(deepLink.shapeIds.map((id)=>this.getShape(id)));
                        const byPage = {};
                        for (const shape of allShapes){
                            const pageId2 = this.getAncestorPageId(shape);
                            if (!pageId2) continue;
                            byPage[pageId2] ??= [];
                            byPage[pageId2].push(shape);
                        }
                        const [pageId, shapes] = Object.entries(byPage).sort(([_, a], [__, b])=>b.length - a.length)[0] ?? [
                            "",
                            []
                        ];
                        if (!pageId || !shapes.length) {
                            this._zoomToFitPageContentAt100Percent();
                        } else {
                            this.setCurrentPage(pageId);
                            const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].Common(shapes.map((s)=>this.getShapePageBounds(s)));
                            this.zoomToBounds(bounds, {
                                immediate: true,
                                targetZoom: this.getBaseZoom()
                            });
                        }
                        return;
                    }
                case "viewport":
                    {
                        if (deepLink.pageId) {
                            if (!this.getPage(deepLink.pageId)) {
                                this._zoomToFitPageContentAt100Percent();
                                return;
                            }
                            this.setCurrentPage(deepLink.pageId);
                        }
                        this.zoomToBounds(deepLink.bounds, {
                            immediate: true,
                            inset: 0
                        });
                        return;
                    }
                default:
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(deepLink);
            }
        });
    }
    /**
   * Handles navigating to the content specified by the query param in the given URL.
   *
   * Use {@link Editor.createDeepLink} to create a URL with a deep link query param.
   *
   * If no URL is provided, it will look for the param in the current `window.location.href`.
   *
   * @example
   * ```ts
   * editor.navigateToDeepLink()
   * ```
   *
   * The default parameter name is 'd'. You can override this by providing the `param` option.
   *
   * @example
   * ```ts
   * // disable page parameter and change viewport parameter to 'c'
   * editor.navigateToDeepLink({
   *   param: 'x',
   *   url: 'https://my-app.com/my-document?x=200.12.454.23.xyz123',
   * })
   * ```
   *
   * @param opts - Options for loading the state from the URL.
   */ navigateToDeepLink(opts) {
        if (opts && "type" in opts) {
            this._navigateToDeepLink(opts);
            return this;
        }
        const url = new URL(opts?.url ?? window.location.href);
        const deepLinkString = url.searchParams.get(opts?.param ?? "d");
        if (!deepLinkString) {
            this._zoomToFitPageContentAt100Percent();
            return this;
        }
        try {
            this._navigateToDeepLink((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$deepLinks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseDeepLinkString"])(deepLinkString));
        } catch (e) {
            console.warn(e);
            this._zoomToFitPageContentAt100Percent();
        }
        return this;
    }
    /**
   * Turns the given URL into a deep link by adding a query parameter.
   *
   * e.g. `https://my-app.com/my-document?d=100.100.200.200.xyz123`
   *
   * If no URL is provided, it will use the current `window.location.href`.
   *
   * @example
   * ```ts
   * // create a deep link to the current page + viewport
   * navigator.clipboard.writeText(editor.createDeepLink())
   * ```
   *
   * You can link to a particular set of shapes by providing a `to` parameter.
   *
   * @example
   * ```ts
   * // create a deep link to the set of currently selected shapes
   * navigator.clipboard.writeText(editor.createDeepLink({
   *   to: { type: 'selection', shapeIds: editor.getSelectedShapeIds() }
   * }))
   * ```
   *
   * The default query param is 'd'. You can override this by providing a `param` parameter.
   *
   * @example
   * ```ts
   * // Use `x` as the param name instead
   * editor.createDeepLink({ param: 'x' })
   * ```
   *
   * @param opts - Options for adding the state to the URL.
   * @returns the updated URL
   */ createDeepLink(opts) {
        const url = new URL(opts?.url ?? window.location.href);
        url.searchParams.set(opts?.param ?? "d", (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$deepLinks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDeepLinkString"])(opts?.to ?? {
            type: "viewport",
            pageId: this.options.maxPages === 1 ? void 0 : this.getCurrentPageId(),
            bounds: this.getViewportPageBounds()
        }));
        return url;
    }
    /**
   * Register a listener for changes to a deep link for the current document.
   *
   * You'll typically want to use this indirectly via the {@link TldrawEditorBaseProps.deepLinks} prop on the `<Tldraw />` component.
   *
   * By default this will update `window.location` in place, but you can provide a custom callback
   * to handle state changes on your own.
   *
   * @example
   * ```ts
   * editor.registerDeepLinkListener({
   *   onChange(url) {
   *     window.history.replaceState({}, document.title, url.toString())
   *   }
   * })
   * ```
   *
   * You can also provide a custom URL to update, in which case you must also provide `onChange`.
   *
   * @example
   * ```ts
   * editor.registerDeepLinkListener({
   *   getUrl: () => `https://my-app.com/my-document`,
   *   onChange(url) {
   *     setShareUrl(url.toString())
   *   }
   * })
   * ```
   *
   * By default this will update with a debounce interval of 500ms, but you can provide a custom interval.
   *
   * @example
   * ```ts
   * editor.registerDeepLinkListener({ debounceMs: 1000 })
   * ```
   * The default parameter name is `d`. You can override this by providing a `param` option.
   *
   * @example
   * ```ts
   * editor.registerDeepLinkListener({ param: 'x' })
   * ```
   * @param opts - Options for setting up the listener.
   * @returns a function that will stop the listener.
   */ registerDeepLinkListener(opts) {
        if (opts?.getUrl && !opts?.onChange) {
            throw Error("[tldraw:urlStateSync] If you specify getUrl, you must also specify the onChange callback.");
        }
        const url$ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$Computed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computed"])("url with state", ()=>{
            const url = opts?.getUrl?.(this) ?? window.location.href;
            const urlWithState = this.createDeepLink({
                param: opts?.param,
                url,
                to: opts?.getTarget?.(this)
            });
            return urlWithState.toString();
        });
        const announceChange = opts?.onChange ?? (()=>{
            const url = this.createDeepLink({
                param: opts?.param,
                to: opts?.getTarget?.(this)
            });
            window.history.replaceState({}, document.title, url.toString());
        });
        const scheduleEffect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$debounce$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debounce"])((execute)=>execute(), opts?.debounceMs ?? 500);
        const unlisten = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$EffectScheduler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["react"])("update url on state change", ()=>announceChange(new URL(url$.get()), this), {
            scheduleEffect
        });
        return ()=>{
            unlisten();
            scheduleEffect.cancel();
        };
    }
    /**
   * Prevent a double click event from firing the next time the user clicks
   *
   * @public
   */ cancelDoubleClick() {
        this._clickManager.cancelDoubleClickTimeout();
    }
    _setShiftKeyTimeout() {
        this.inputs.setShiftKey(false);
        this.dispatch({
            type: "keyboard",
            name: "key_up",
            key: "Shift",
            shiftKey: this.inputs.getShiftKey(),
            ctrlKey: this.inputs.getCtrlKey(),
            altKey: this.inputs.getAltKey(),
            metaKey: this.inputs.getMetaKey(),
            accelKey: this.inputs.getAccelKey(),
            code: "ShiftLeft"
        });
    }
    _setAltKeyTimeout() {
        this.inputs.setAltKey(false);
        this.dispatch({
            type: "keyboard",
            name: "key_up",
            key: "Alt",
            shiftKey: this.inputs.getShiftKey(),
            ctrlKey: this.inputs.getCtrlKey(),
            altKey: this.inputs.getAltKey(),
            metaKey: this.inputs.getMetaKey(),
            accelKey: this.inputs.getAccelKey(),
            code: "AltLeft"
        });
    }
    _setCtrlKeyTimeout() {
        this.inputs.setCtrlKey(false);
        this.dispatch({
            type: "keyboard",
            name: "key_up",
            key: "Ctrl",
            shiftKey: this.inputs.getShiftKey(),
            ctrlKey: this.inputs.getCtrlKey(),
            altKey: this.inputs.getAltKey(),
            metaKey: this.inputs.getMetaKey(),
            accelKey: this.inputs.getAccelKey(),
            code: "ControlLeft"
        });
    }
    _setMetaKeyTimeout() {
        this.inputs.setMetaKey(false);
        this.dispatch({
            type: "keyboard",
            name: "key_up",
            key: "Meta",
            shiftKey: this.inputs.getShiftKey(),
            ctrlKey: this.inputs.getCtrlKey(),
            altKey: this.inputs.getAltKey(),
            metaKey: this.inputs.getMetaKey(),
            accelKey: this.inputs.getAccelKey(),
            code: "MetaLeft"
        });
    }
    /**
   * In tldraw, events are sometimes handled by multiple components. For example, the shapes might
   * have events, but the canvas handles events too. The way that the canvas handles events can
   * interfere with the with the shapes event handlers - for example, it calls `.preventDefault()`
   * on `pointerDown`, which also prevents `click` events from firing on the shapes.
   *
   * You can use `.stopPropagation()` to prevent the event from propagating to the rest of the
   * DOM, but that can impact non-tldraw event handlers set up elsewhere. By using
   * `markEventAsHandled`, you'll stop other parts of tldraw from handling the event without
   * impacting other, non-tldraw event handlers. See also {@link Editor.wasEventAlreadyHandled}.
   *
   * @public
   */ markEventAsHandled(e) {
        const nativeEvent = "nativeEvent" in e ? e.nativeEvent : e;
        this.handledEvents.add(nativeEvent);
    }
    /**
   * Checks if an event has already been handled. See {@link Editor.markEventAsHandled}.
   *
   * @public
   */ wasEventAlreadyHandled(e) {
        const nativeEvent = "nativeEvent" in e ? e.nativeEvent : e;
        return this.handledEvents.has(nativeEvent);
    }
    /**
   * Dispatch an event to the editor.
   *
   * @example
   * ```ts
   * editor.dispatch(myPointerEvent)
   * ```
   *
   * @param info - The event info.
   *
   * @public
   */ dispatch(info) {
        this._pendingEventsForNextTick.push(info);
        if (!(info.type === "pointer" && info.name === "pointer_move" || info.type === "wheel" || info.type === "pinch")) {
            this._flushEventsForTick(0);
        }
        return this;
    }
    _flushEventsForTick(elapsed) {
        this.run(()=>{
            if (this._pendingEventsForNextTick.length > 0) {
                const events = [
                    ...this._pendingEventsForNextTick
                ];
                this._pendingEventsForNextTick.length = 0;
                for (const info of events){
                    this._flushEventForTick(info);
                }
            }
            if (elapsed > 0) {
                this.root.handleEvent({
                    type: "misc",
                    name: "tick",
                    elapsed
                });
            }
            this.scribbles.tick(elapsed);
        });
    }
    _flushEventForTick(info) {
        if (this.getCrashingError()) return this;
        this.emit("before-event", info);
        const { inputs } = this;
        const { type } = info;
        if (info.type === "misc") {
            if (info.name === "cancel" || info.name === "complete") {
                this.inputs.setIsDragging(false);
                if (this.inputs.getIsPanning()) {
                    this.inputs.setIsPanning(false);
                    this.inputs.setIsSpacebarPanning(false);
                    this.setCursor({
                        type: this._prevCursor,
                        rotation: 0
                    });
                }
            }
            this.root.handleEvent(info);
            this.emit("event", info);
            return;
        }
        if (info.shiftKey) {
            clearTimeout(this._shiftKeyTimeout);
            this._shiftKeyTimeout = -1;
            inputs.setShiftKey(true);
        } else if (!info.shiftKey && inputs.getShiftKey() && this._shiftKeyTimeout === -1) {
            this._shiftKeyTimeout = this.timers.setTimeout(this._setShiftKeyTimeout, 150);
        }
        if (info.altKey) {
            clearTimeout(this._altKeyTimeout);
            this._altKeyTimeout = -1;
            inputs.setAltKey(true);
        } else if (!info.altKey && inputs.getAltKey() && this._altKeyTimeout === -1) {
            this._altKeyTimeout = this.timers.setTimeout(this._setAltKeyTimeout, 150);
        }
        if (info.ctrlKey) {
            clearTimeout(this._ctrlKeyTimeout);
            this._ctrlKeyTimeout = -1;
            inputs.setCtrlKey(true);
        } else if (!info.ctrlKey && inputs.getCtrlKey() && this._ctrlKeyTimeout === -1) {
            this._ctrlKeyTimeout = this.timers.setTimeout(this._setCtrlKeyTimeout, 150);
        }
        if (info.metaKey) {
            clearTimeout(this._metaKeyTimeout);
            this._metaKeyTimeout = -1;
            inputs.setMetaKey(true);
        } else if (!info.metaKey && inputs.getMetaKey() && this._metaKeyTimeout === -1) {
            this._metaKeyTimeout = this.timers.setTimeout(this._setMetaKeyTimeout, 150);
        }
        if (!inputs.getIsPointing()) {
            inputs.setIsDragging(false);
        }
        const instanceState = this.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
        const pageState = this.store.get(this._getCurrentPageStateId());
        const cameraOptions = this._cameraOptions.__unsafe__getWithoutCapture();
        switch(type){
            case "pinch":
                {
                    if (cameraOptions.isLocked) return;
                    clearTimeout(this._longPressTimeout);
                    this.inputs.updateFromEvent(info);
                    switch(info.name){
                        case "pinch_start":
                            {
                                if (inputs.getIsPinching()) return;
                                if (!inputs.getIsEditing()) {
                                    this._selectedShapeIdsAtPointerDown = [
                                        ...pageState.selectedShapeIds
                                    ];
                                    this._didPinch = true;
                                    inputs.setIsPinching(true);
                                    this.interrupt();
                                }
                                this.emit("event", info);
                                return;
                            }
                        case "pinch":
                            {
                                if (!inputs.getIsPinching()) return;
                                const { point: { z = 1 }, delta: { x: dx, y: dy } } = info;
                                const { x: x1, y } = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].SubXY(info.point, instanceState.screenBounds.x, instanceState.screenBounds.y);
                                this.stopCameraAnimation();
                                if (instanceState.followingUserId) {
                                    this.stopFollowingUser();
                                }
                                const { x: cx, y: cy, z: cz } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafe__withoutCapture"])(()=>this.getCamera());
                                const { panSpeed } = cameraOptions;
                                this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + dx * panSpeed / cz - x1 / cz + x1 / z, cy + dy * panSpeed / cz - y / cz + y / z, z), {
                                    immediate: true
                                });
                                this.emit("event", info);
                                return;
                            }
                        case "pinch_end":
                            {
                                if (!inputs.getIsPinching()) return this;
                                inputs.setIsPinching(false);
                                const { _selectedShapeIdsAtPointerDown: shapesToReselect } = this;
                                this.setSelectedShapes(this._selectedShapeIdsAtPointerDown);
                                this._selectedShapeIdsAtPointerDown = [];
                                if (this._didPinch) {
                                    this._didPinch = false;
                                    if (shapesToReselect.length > 0) {
                                        this.once("tick", ()=>{
                                            if (!this._didPinch) {
                                                this.setSelectedShapes(shapesToReselect);
                                            }
                                        });
                                    }
                                }
                                this.emit("event", info);
                                return;
                            }
                    }
                }
            case "wheel":
                {
                    if (cameraOptions.isLocked) return;
                    this.inputs.updateFromEvent(info);
                    const { panSpeed, zoomSpeed } = cameraOptions;
                    let wheelBehavior = cameraOptions.wheelBehavior;
                    const inputMode = this.user.getUserPreferences().inputMode;
                    if (inputMode !== null) {
                        wheelBehavior = inputMode === "trackpad" ? "pan" : "zoom";
                    }
                    if (wheelBehavior !== "none") {
                        this.stopCameraAnimation();
                        if (instanceState.followingUserId) {
                            this.stopFollowingUser();
                        }
                        const { x: cx, y: cy, z: cz } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafe__withoutCapture"])(()=>this.getCamera());
                        const { x: dx, y: dy, z: dz = 0 } = info.delta;
                        let behavior = wheelBehavior;
                        if (info.ctrlKey) behavior = wheelBehavior === "pan" ? "zoom" : "pan";
                        switch(behavior){
                            case "zoom":
                                {
                                    const { x: x1, y } = this.inputs.getCurrentScreenPoint();
                                    let delta = dz;
                                    if (wheelBehavior === "zoom") {
                                        if (Math.abs(dy) > 10) {
                                            delta = 10 * Math.sign(dy) / 100;
                                        } else {
                                            delta = dy / 100;
                                        }
                                    }
                                    const isZoomDirectionInverted = (this.user.getUserPreferences().isZoomDirectionInverted && inputMode === "mouse") ?? false;
                                    const deltaValue = delta ?? 0;
                                    const finalDelta = isZoomDirectionInverted ? -deltaValue : deltaValue;
                                    const zoom = cz + finalDelta * zoomSpeed * cz;
                                    this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + x1 / zoom - x1 / cz, cy + y / zoom - y / cz, zoom), {
                                        immediate: true
                                    });
                                    this.maybeTrackPerformance("Zooming");
                                    this.root.handleEvent(info);
                                    this.emit("event", info);
                                    return;
                                }
                            case "pan":
                                {
                                    this._setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + dx * panSpeed / cz, cy + dy * panSpeed / cz, cz), {
                                        immediate: true
                                    });
                                    this.maybeTrackPerformance("Panning");
                                    this.root.handleEvent(info);
                                    this.emit("event", info);
                                    return;
                                }
                        }
                    }
                    break;
                }
            case "pointer":
                {
                    if (inputs.getIsPinching()) return;
                    this.inputs.updateFromEvent(info);
                    const { isPen } = info;
                    const { isPenMode } = instanceState;
                    switch(info.name){
                        case "pointer_down":
                            {
                                if (isPenMode && !isPen) return;
                                if (!this.inputs.getIsPanning()) {
                                    this._longPressTimeout = this.timers.setTimeout(()=>{
                                        const vsb = this.getViewportScreenBounds();
                                        this.dispatch({
                                            ...info,
                                            // important! non-obvious!! the screenpoint was adjusted using the
                                            // viewport bounds, and will be again when this event is handled...
                                            // so we need to counter-adjust from the stored value so that the
                                            // new value is set correctly.
                                            point: this.inputs.getOriginScreenPoint().clone().addXY(vsb.x, vsb.y),
                                            name: "long_press"
                                        });
                                    }, this.options.longPressDurationMs);
                                }
                                this._selectedShapeIdsAtPointerDown = this.getSelectedShapeIds();
                                if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEFT_MOUSE_BUTTON"]) this.capturedPointerId = info.pointerId;
                                inputs.buttons.add(info.button);
                                inputs.setIsPointing(true);
                                inputs.setIsDragging(false);
                                if (!isPenMode && isPen) this.updateInstanceState({
                                    isPenMode: true
                                });
                                if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STYLUS_ERASER_BUTTON"]) {
                                    this._restoreToolId = this.getCurrentToolId();
                                    this.complete();
                                    this.setCurrentTool("eraser");
                                } else if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIDDLE_MOUSE_BUTTON"]) {
                                    if (!this.inputs.getIsPanning()) {
                                        this._prevCursor = this.getInstanceState().cursor.type;
                                    }
                                    this.inputs.setIsPanning(true);
                                    clearTimeout(this._longPressTimeout);
                                }
                                if (this.inputs.getIsPanning()) {
                                    this.stopCameraAnimation();
                                    this.setCursor({
                                        type: "grabbing",
                                        rotation: 0
                                    });
                                    return this;
                                }
                                break;
                            }
                        case "pointer_move":
                            {
                                if (!isPen && isPenMode) return;
                                const { x: cx, y: cy, z: cz } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$state$2f$dist$2d$esm$2f$lib$2f$capture$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafe__withoutCapture"])(()=>this.getCamera());
                                if (this.inputs.getIsPanning() && this.inputs.getIsPointing()) {
                                    const currentScreenPoint = this.inputs.getCurrentScreenPoint();
                                    const previousScreenPoint = this.inputs.getPreviousScreenPoint();
                                    const offset = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Sub(currentScreenPoint, previousScreenPoint);
                                    this.setCamera(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](cx + offset.x / cz, cy + offset.y / cz, cz), {
                                        immediate: true
                                    });
                                    this.maybeTrackPerformance("Panning");
                                    return;
                                }
                                if (inputs.getIsPointing() && !inputs.getIsDragging() && __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Dist2(inputs.getOriginPagePoint(), inputs.getCurrentPagePoint()) * this.getZoomLevel() > (instanceState.isCoarsePointer ? this.options.coarseDragDistanceSquared : this.options.dragDistanceSquared) / cz) {
                                    inputs.setIsDragging(true);
                                    clearTimeout(this._longPressTimeout);
                                }
                                break;
                            }
                        case "pointer_up":
                            {
                                inputs.setIsDragging(false);
                                inputs.setIsPointing(false);
                                clearTimeout(this._longPressTimeout);
                                inputs.buttons.delete(info.button);
                                if (instanceState.isPenMode && !isPen) return;
                                if (this.capturedPointerId === info.pointerId) {
                                    this.capturedPointerId = null;
                                    info.button = 0;
                                }
                                if (inputs.getIsPanning()) {
                                    if (!inputs.keys.has("Space")) {
                                        inputs.setIsPanning(false);
                                        inputs.setIsSpacebarPanning(false);
                                    }
                                    const slideDirection = this.inputs.getPointerVelocity();
                                    const slideSpeed = Math.min(2, slideDirection.len());
                                    switch(info.button){
                                        case __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEFT_MOUSE_BUTTON"]:
                                            {
                                                this.setCursor({
                                                    type: "grab",
                                                    rotation: 0
                                                });
                                                break;
                                            }
                                        case __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIDDLE_MOUSE_BUTTON"]:
                                            {
                                                if (this.inputs.keys.has(" ")) {
                                                    this.setCursor({
                                                        type: "grab",
                                                        rotation: 0
                                                    });
                                                } else {
                                                    this.setCursor({
                                                        type: this._prevCursor,
                                                        rotation: 0
                                                    });
                                                }
                                            }
                                    }
                                    if (slideSpeed > 0) {
                                        this.slideCamera({
                                            speed: slideSpeed,
                                            direction: slideDirection
                                        });
                                    }
                                } else {
                                    if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STYLUS_ERASER_BUTTON"]) {
                                        this.complete();
                                        this.setCurrentTool(this._restoreToolId);
                                    }
                                }
                                this._selectedShapeIdsAtPointerDown = [];
                                break;
                            }
                    }
                    break;
                }
            case "keyboard":
                {
                    if (info.key === "ShiftRight") info.key = "ShiftLeft";
                    if (info.key === "AltRight") info.key = "AltLeft";
                    if (info.code === "ControlRight") info.code = "ControlLeft";
                    if (info.code === "MetaRight") info.code = "MetaLeft";
                    switch(info.name){
                        case "key_down":
                            {
                                inputs.keys.add(info.code);
                                if (this.options.spacebarPanning) {
                                    if (info.code === "Space" && !info.ctrlKey) {
                                        if (!this.inputs.getIsPanning()) {
                                            this._prevCursor = instanceState.cursor.type;
                                        }
                                        this.inputs.setIsPanning(true);
                                        this.inputs.setIsSpacebarPanning(true);
                                        clearTimeout(this._longPressTimeout);
                                        this.setCursor({
                                            type: this.inputs.getIsPointing() ? "grabbing" : "grab",
                                            rotation: 0
                                        });
                                    }
                                    if (this.inputs.getIsSpacebarPanning()) {
                                        let offset;
                                        switch(info.code){
                                            case "ArrowUp":
                                                {
                                                    offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, -1);
                                                    break;
                                                }
                                            case "ArrowRight":
                                                {
                                                    offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](1, 0);
                                                    break;
                                                }
                                            case "ArrowDown":
                                                {
                                                    offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 1);
                                                    break;
                                                }
                                            case "ArrowLeft":
                                                {
                                                    offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](-1, 0);
                                                    break;
                                                }
                                        }
                                        if (offset) {
                                            const bounds = this.getViewportPageBounds();
                                            const next = bounds.clone().translate(offset.mulV({
                                                x: bounds.w,
                                                y: bounds.h
                                            }));
                                            this._animateToViewport(next, {
                                                animation: {
                                                    duration: 320
                                                }
                                            });
                                        }
                                    }
                                }
                                break;
                            }
                        case "key_up":
                            {
                                inputs.keys.delete(info.code);
                                if (this.options.spacebarPanning) {
                                    if (info.code === "Space") {
                                        if (this.inputs.buttons.has(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIDDLE_MOUSE_BUTTON"])) {} else {
                                            this.inputs.setIsPanning(false);
                                            this.inputs.setIsSpacebarPanning(false);
                                            this.setCursor({
                                                type: this._prevCursor,
                                                rotation: 0
                                            });
                                        }
                                    }
                                }
                                break;
                            }
                        case "key_repeat":
                            {
                                break;
                            }
                    }
                    break;
                }
        }
        if (info.type === "pointer") {
            if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIDDLE_MOUSE_BUTTON"]) {
                info.name = "middle_click";
            } else if (info.button === __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RIGHT_MOUSE_BUTTON"]) {
                info.name = "right_click";
            }
            const { isPenMode } = this.store.unsafeGetWithoutCapture(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLInstance$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TLINSTANCE_ID"]);
            if (info.isPen === isPenMode) {
                const clickInfo = this._clickManager.handlePointerEvent(info);
                if (info.name !== clickInfo.name) {
                    this.root.handleEvent(info);
                    this.emit("event", info);
                    this.root.handleEvent(clickInfo);
                    this.emit("event", clickInfo);
                    return;
                }
            }
        }
        this.root.handleEvent(info);
        this.emit("event", info);
        if (info.type === "pointer" && info.name === "pointer_down") {
            this.menus.clearOpenMenus();
        }
        return this;
    }
    /** @internal */ maybeTrackPerformance(name) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$utils$2f$debug$2d$flags$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugFlags"].measurePerformance.get()) {
            if (this.performanceTracker.isStarted()) {
                clearTimeout(this.performanceTrackerTimeout);
            } else {
                this.performanceTracker.start(name);
            }
            this.performanceTrackerTimeout = this.timers.setTimeout(()=>{
                this.performanceTracker.stop();
            }, 50);
        }
    }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 1, "getIsShapeHiddenCache", _getIsShapeHiddenCache_dec, Editor);
__decorateElement(_init, 1, "canUndo", _canUndo_dec, Editor);
__decorateElement(_init, 1, "canRedo", _canRedo_dec, Editor);
__decorateElement(_init, 1, "getPath", _getPath_dec, Editor);
__decorateElement(_init, 1, "getCurrentTool", _getCurrentTool_dec, Editor);
__decorateElement(_init, 1, "getCurrentToolId", _getCurrentToolId_dec, Editor);
__decorateElement(_init, 1, "getDocumentSettings", _getDocumentSettings_dec, Editor);
__decorateElement(_init, 1, "getInstanceState", _getInstanceState_dec, Editor);
__decorateElement(_init, 1, "getPageStates", _getPageStates_dec, Editor);
__decorateElement(_init, 1, "_getPageStatesQuery", __getPageStatesQuery_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageState", _getCurrentPageState_dec, Editor);
__decorateElement(_init, 1, "_getCurrentPageStateId", __getCurrentPageStateId_dec, Editor);
__decorateElement(_init, 1, "getSelectedShapeIds", _getSelectedShapeIds_dec, Editor);
__decorateElement(_init, 1, "getSelectedShapes", _getSelectedShapes_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageShapesInReadingOrder", _getCurrentPageShapesInReadingOrder_dec, Editor);
__decorateElement(_init, 1, "getOnlySelectedShapeId", _getOnlySelectedShapeId_dec, Editor);
__decorateElement(_init, 1, "getOnlySelectedShape", _getOnlySelectedShape_dec, Editor);
__decorateElement(_init, 1, "getSelectionPageBounds", _getSelectionPageBounds_dec, Editor);
__decorateElement(_init, 1, "getSelectionRotation", _getSelectionRotation_dec, Editor);
__decorateElement(_init, 1, "getSelectionRotatedPageBounds", _getSelectionRotatedPageBounds_dec, Editor);
__decorateElement(_init, 1, "getSelectionRotatedScreenBounds", _getSelectionRotatedScreenBounds_dec, Editor);
__decorateElement(_init, 1, "getFocusedGroupId", _getFocusedGroupId_dec, Editor);
__decorateElement(_init, 1, "getFocusedGroup", _getFocusedGroup_dec, Editor);
__decorateElement(_init, 1, "getEditingShapeId", _getEditingShapeId_dec, Editor);
__decorateElement(_init, 1, "getEditingShape", _getEditingShape_dec, Editor);
__decorateElement(_init, 1, "getRichTextEditor", _getRichTextEditor_dec, Editor);
__decorateElement(_init, 1, "getHoveredShapeId", _getHoveredShapeId_dec, Editor);
__decorateElement(_init, 1, "getHoveredShape", _getHoveredShape_dec, Editor);
__decorateElement(_init, 1, "getHintingShapeIds", _getHintingShapeIds_dec, Editor);
__decorateElement(_init, 1, "getHintingShape", _getHintingShape_dec, Editor);
__decorateElement(_init, 1, "getErasingShapeIds", _getErasingShapeIds_dec, Editor);
__decorateElement(_init, 1, "getErasingShapes", _getErasingShapes_dec, Editor);
__decorateElement(_init, 1, "_unsafe_getCameraId", __unsafe_getCameraId_dec, Editor);
__decorateElement(_init, 1, "getCamera", _getCamera_dec, Editor);
__decorateElement(_init, 1, "getViewportPageBoundsForFollowing", _getViewportPageBoundsForFollowing_dec, Editor);
__decorateElement(_init, 1, "getCameraForFollowing", _getCameraForFollowing_dec, Editor);
__decorateElement(_init, 1, "getZoomLevel", _getZoomLevel_dec, Editor);
__decorateElement(_init, 1, "getDebouncedZoomLevel", _getDebouncedZoomLevel_dec, Editor);
__decorateElement(_init, 1, "_getAboveDebouncedZoomThreshold", __getAboveDebouncedZoomThreshold_dec, Editor);
__decorateElement(_init, 1, "getEfficientZoomLevel", _getEfficientZoomLevel_dec, Editor);
__decorateElement(_init, 1, "getViewportScreenBounds", _getViewportScreenBounds_dec, Editor);
__decorateElement(_init, 1, "getViewportScreenCenter", _getViewportScreenCenter_dec, Editor);
__decorateElement(_init, 1, "getViewportPageBounds", _getViewportPageBounds_dec, Editor);
__decorateElement(_init, 1, "_getCollaboratorsQuery", __getCollaboratorsQuery_dec, Editor);
__decorateElement(_init, 1, "getCollaborators", _getCollaborators_dec, Editor);
__decorateElement(_init, 1, "getCollaboratorsOnCurrentPage", _getCollaboratorsOnCurrentPage_dec, Editor);
__decorateElement(_init, 1, "getRenderingShapes", _getRenderingShapes_dec, Editor);
__decorateElement(_init, 1, "_getAllPagesQuery", __getAllPagesQuery_dec, Editor);
__decorateElement(_init, 1, "getPages", _getPages_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageId", _getCurrentPageId_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageShapeIdsSorted", _getCurrentPageShapeIdsSorted_dec, Editor);
__decorateElement(_init, 1, "_getAllAssetsQuery", __getAllAssetsQuery_dec, Editor);
__decorateElement(_init, 1, "_getShapeHandlesCache", __getShapeHandlesCache_dec, Editor);
__decorateElement(_init, 1, "_getShapePageTransformCache", __getShapePageTransformCache_dec, Editor);
__decorateElement(_init, 1, "_getShapePageBoundsCache", __getShapePageBoundsCache_dec, Editor);
__decorateElement(_init, 1, "_getShapeClipPathCache", __getShapeClipPathCache_dec, Editor);
__decorateElement(_init, 1, "_getShapeMaskCache", __getShapeMaskCache_dec, Editor);
__decorateElement(_init, 1, "_getShapeMaskedPageBoundsCache", __getShapeMaskedPageBoundsCache_dec, Editor);
__decorateElement(_init, 1, "getNotVisibleShapes", _getNotVisibleShapes_dec, Editor);
__decorateElement(_init, 1, "getCulledShapes", _getCulledShapes_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageBounds", _getCurrentPageBounds_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageShapes", _getCurrentPageShapes_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageShapesSorted", _getCurrentPageShapesSorted_dec, Editor);
__decorateElement(_init, 1, "getCurrentPageRenderingShapesSorted", _getCurrentPageRenderingShapesSorted_dec, Editor);
__decorateElement(_init, 1, "_getBindingsIndexCache", __getBindingsIndexCache_dec, Editor);
__decorateElement(_init, 1, "_getSelectionSharedStyles", __getSelectionSharedStyles_dec, Editor);
__decorateElement(_init, 1, "getSharedStyles", _getSharedStyles_dec, Editor);
__decorateElement(_init, 1, "getSharedOpacity", _getSharedOpacity_dec, Editor);
__decorateElement(_init, 1, "getIsFocused", _getIsFocused_dec, Editor);
__decorateElement(_init, 1, "getIsReadonly", _getIsReadonly_dec, Editor);
__decorateElement(_init, 1, "_setShiftKeyTimeout", __setShiftKeyTimeout_dec, Editor);
__decorateElement(_init, 1, "_setAltKeyTimeout", __setAltKeyTimeout_dec, Editor);
__decorateElement(_init, 1, "_setCtrlKeyTimeout", __setCtrlKeyTimeout_dec, Editor);
__decorateElement(_init, 1, "_setMetaKeyTimeout", __setMetaKeyTimeout_dec, Editor);
__decoratorMetadata(_init, Editor);
function alertMaxShapes(editor, pageId = editor.getCurrentPageId()) {
    const name = editor.getPage(pageId).name;
    editor.emit("max-shapes", {
        name,
        pageId,
        count: editor.options.maxShapesPerPage
    });
}
function applyPartialToRecordWithProps(prev, partial) {
    if (!partial) return prev;
    let next = null;
    const entries = Object.entries(partial);
    for(let i = 0, n = entries.length; i < n; i++){
        const [k, v] = entries[i];
        if (v === void 0) continue;
        if (k === "id" || k === "type" || k === "typeName") continue;
        if (v === prev[k]) continue;
        if (!next) next = {
            ...prev
        };
        if (k === "props" || k === "meta") {
            next[k] = {
                ...prev[k]
            };
            for (const [nextKey, nextValue] of Object.entries(v)){
                ;
                next[k][nextKey] = nextValue;
            }
            continue;
        }
        ;
        next[k] = v;
    }
    if (!next) return prev;
    return next;
}
function pushShapeWithDescendants(editor, id, result) {
    const shape = editor.getShape(id);
    if (!shape) return;
    result.push(shape);
    const childIds = editor.getSortedChildIdsForParent(id);
    for(let i = 0, n = childIds.length; i < n; i++){
        pushShapeWithDescendants(editor, childIds[i], result);
    }
}
function withIsolatedShapes(editor, shapeIds, callback) {
    let result;
    editor.run(()=>{
        const changes = editor.store.extractingChanges(()=>{
            const bindingsWithBoth = /* @__PURE__ */ new Set();
            const bindingsToRemove = /* @__PURE__ */ new Set();
            for (const shapeId of shapeIds){
                const shape = editor.getShape(shapeId);
                if (!shape) continue;
                for (const binding of editor.getBindingsInvolvingShape(shapeId)){
                    const hasFrom = shapeIds.has(binding.fromId);
                    const hasTo = shapeIds.has(binding.toId);
                    if (hasFrom && hasTo) {
                        bindingsWithBoth.add(binding.id);
                        continue;
                    }
                    if (!hasFrom || !hasTo) {
                        bindingsToRemove.add(binding.id);
                    }
                }
            }
            editor.deleteBindings([
                ...bindingsToRemove
            ], {
                isolateShapes: true
            });
            try {
                result = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].ok(callback(bindingsWithBoth));
            } catch (error) {
                result = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Result"].err(error);
            }
        });
        editor.store.applyDiff((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$store$2f$dist$2d$esm$2f$lib$2f$RecordsDiff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseRecordsDiff"])(changes), {
            runCallbacks: false
        });
    }, {
        history: "ignore"
    });
    if (result.ok) {
        return result.value;
    } else {
        throw result.error;
    }
}
function getCameraFitXFitY(editor, cameraOptions) {
    if (!cameraOptions.constraints) throw Error("Should have constraints here");
    const { padding: { x: px, y: py } } = cameraOptions.constraints;
    const vsb = editor.getViewportScreenBounds();
    const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"].From(cameraOptions.constraints.bounds);
    const zx = (vsb.w - px * 2) / bounds.w;
    const zy = (vsb.h - py * 2) / bounds.h;
    return {
        zx,
        zy
    };
}
;
 //# sourceMappingURL=Editor.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/bindings/BindingUtil.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BindingUtil",
    ()=>BindingUtil
]);
class BindingUtil {
    constructor(editor){
        this.editor = editor;
    }
    static props;
    static migrations;
    /**
   * The type of the binding util, which should match the binding's type.
   *
   * @public
   */ static type;
}
;
 //# sourceMappingURL=BindingUtil.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/shared/resizeBox.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resizeBox",
    ()=>resizeBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
function resizeBox(shape, info, opts = {}) {
    const { newPoint, handle, scaleX, scaleY } = info;
    const { minWidth = 1, maxWidth = Infinity, minHeight = 1, maxHeight = Infinity } = opts;
    let w = shape.props.w * scaleX;
    let h = shape.props.h * scaleY;
    const offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
    if (w > 0) {
        if (w < minWidth) {
            switch(handle){
                case "top_left":
                case "left":
                case "bottom_left":
                    {
                        offset.x = w - minWidth;
                        break;
                    }
                case "top":
                case "bottom":
                    {
                        offset.x = (w - minWidth) / 2;
                        break;
                    }
                default:
                    {
                        offset.x = 0;
                    }
            }
            w = minWidth;
        }
    } else {
        offset.x = w;
        w = -w;
        if (w < minWidth) {
            switch(handle){
                case "top_left":
                case "left":
                case "bottom_left":
                    {
                        offset.x = -w;
                        break;
                    }
                default:
                    {
                        offset.x = -minWidth;
                    }
            }
            w = minWidth;
        }
    }
    if (h > 0) {
        if (h < minHeight) {
            switch(handle){
                case "top_left":
                case "top":
                case "top_right":
                    {
                        offset.y = h - minHeight;
                        break;
                    }
                case "right":
                case "left":
                    {
                        offset.y = (h - minHeight) / 2;
                        break;
                    }
                default:
                    {
                        offset.y = 0;
                    }
            }
            h = minHeight;
        }
    } else {
        offset.y = h;
        h = -h;
        if (h < minHeight) {
            switch(handle){
                case "top_left":
                case "top":
                case "top_right":
                    {
                        offset.y = -h;
                        break;
                    }
                default:
                    {
                        offset.y = -minHeight;
                    }
            }
            h = minHeight;
        }
    }
    const { x, y } = offset.rot(shape.rotation).add(newPoint);
    return {
        ...shape,
        x,
        y,
        props: {
            w: Math.min(maxWidth, w),
            h: Math.min(maxHeight, h)
        }
    };
}
;
 //# sourceMappingURL=resizeBox.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/BaseBoxShapeUtil.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseBoxShapeUtil",
    ()=>BaseBoxShapeUtil
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/number.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Rectangle2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/geometry/Rectangle2d.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$ShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/ShapeUtil.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$shared$2f$resizeBox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/shared/resizeBox.mjs [app-client] (ecmascript)");
;
;
;
;
class BaseBoxShapeUtil extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$ShapeUtil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShapeUtil"] {
    getGeometry(shape) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$geometry$2f$Rectangle2d$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Rectangle2d"]({
            width: shape.props.w,
            height: shape.props.h,
            isFilled: true
        });
    }
    onResize(shape, info) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$shapes$2f$shared$2f$resizeBox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeBox"])(shape, info);
    }
    getHandleSnapGeometry(shape) {
        return {
            points: this.getGeometry(shape).bounds.cornersAndCenter
        };
    }
    getInterpolatedProps(startShape, endShape, t) {
        return {
            ...endShape.props,
            w: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(startShape.props.w, endShape.props.w, t),
            h: (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$number$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lerp"])(startShape.props.h, endShape.props.h, t)
        };
    }
}
;
 //# sourceMappingURL=BaseBoxShapeUtil.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/shapes/shared/resizeScaled.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resizeScaled",
    ()=>resizeScaled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/control.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
;
;
function resizeScaled(shape, { initialBounds, scaleX, scaleY, newPoint, handle }) {
    let scaleDelta;
    switch(handle){
        case "bottom_left":
        case "bottom_right":
        case "top_left":
        case "top_right":
            {
                scaleDelta = Math.max(0.01, Math.max(Math.abs(scaleX), Math.abs(scaleY)));
                break;
            }
        case "left":
        case "right":
            {
                scaleDelta = Math.max(0.01, Math.abs(scaleX));
                break;
            }
        case "bottom":
        case "top":
            {
                scaleDelta = Math.max(0.01, Math.abs(scaleY));
                break;
            }
        default:
            {
                throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$control$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exhaustiveSwitchError"])(handle);
            }
    }
    const offset = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](0, 0);
    if (scaleX < 0) {
        offset.x = -(initialBounds.width * scaleDelta);
    }
    if (scaleY < 0) {
        offset.y = -(initialBounds.height * scaleDelta);
    }
    const { x, y } = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"].Add(newPoint, offset.rot(shape.rotation));
    return {
        x,
        y,
        props: {
            scale: scaleDelta * shape.props.scale
        }
    };
}
;
 //# sourceMappingURL=resizeScaled.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/children/Idle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Idle",
    ()=>Idle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
class Idle extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "idle";
    onPointerDown(info) {
        this.parent.transition("pointing", info);
    }
    onEnter() {
        this.editor.setCursor({
            type: "cross",
            rotation: 0
        });
    }
    onCancel() {
        this.editor.setCurrentTool("select");
    }
}
;
 //# sourceMappingURL=Idle.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/children/Pointing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pointing",
    ()=>Pointing,
    "maybeSnapToGrid",
    ()=>maybeSnapToGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/tlschema/dist-esm/records/TLShape.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/utils/dist-esm/lib/value.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/primitives/Vec.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
;
;
;
;
class Pointing extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "pointing";
    onPointerMove(info) {
        const { editor } = this;
        if (editor.inputs.getIsDragging()) {
            const originPagePoint = editor.inputs.getOriginPagePoint();
            const shapeType = this.parent.shapeType;
            const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
            const creatingMarkId = editor.markHistoryStoppingPoint(`creating_box:${id}`);
            const newPoint = maybeSnapToGrid(originPagePoint, editor);
            this.editor.createShapes([
                {
                    id,
                    type: shapeType,
                    x: newPoint.x,
                    y: newPoint.y,
                    props: {
                        w: 1,
                        h: 1
                    }
                }
            ]);
            const shape = editor.getShape(id);
            if (!shape) {
                this.cancel();
                return;
            }
            editor.select(id);
            const parent = this.parent;
            this.editor.setCurrentTool("select.resizing", {
                ...info,
                target: "selection",
                handle: "bottom_right",
                isCreating: true,
                creatingMarkId,
                creationCursorOffset: {
                    x: 1,
                    y: 1
                },
                onInteractionEnd: this.parent.id,
                onCreate: parent.onCreate ? (shape2)=>parent.onCreate?.(shape2) : void 0
            });
        }
    }
    onPointerUp() {
        this.complete();
    }
    onCancel() {
        this.cancel();
    }
    onComplete() {
        this.complete();
    }
    onInterrupt() {
        this.cancel();
    }
    complete() {
        const originPagePoint = this.editor.inputs.getOriginPagePoint();
        const shapeType = this.parent.shapeType;
        const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$tlschema$2f$dist$2d$esm$2f$records$2f$TLShape$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShapeId"])();
        this.editor.markHistoryStoppingPoint(`creating_box:${id}`);
        this.editor.createShapes([
            {
                id,
                type: shapeType,
                x: originPagePoint.x,
                y: originPagePoint.y
            }
        ]);
        const shape = this.editor.getShape(id);
        if (!shape) {
            this.cancel();
            return;
        }
        let { w, h } = shape.props;
        const delta = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](w / 2, h / 2);
        const parentTransform = this.editor.getShapeParentTransform(shape);
        if (parentTransform) delta.rot(-parentTransform.rotation());
        let scale = 1;
        if (this.editor.user.getIsDynamicResizeMode()) {
            scale = 1 / this.editor.getZoomLevel();
            w *= scale;
            h *= scale;
            delta.mul(scale);
        }
        const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$utils$2f$dist$2d$esm$2f$lib$2f$value$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["structuredClone"])(shape);
        const newPoint = maybeSnapToGrid(new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$primitives$2f$Vec$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vec"](shape.x - delta.x, shape.y - delta.y), this.editor);
        next.x = newPoint.x;
        next.y = newPoint.y;
        next.props.w = w;
        next.props.h = h;
        if ("scale" in shape.props) {
            ;
            next.props.scale = scale;
        }
        this.editor.updateShape(next);
        this.editor.setSelectedShapes([
            id
        ]);
        if (this.editor.getInstanceState().isToolLocked) {
            this.parent.transition("idle");
        } else {
            this.editor.setCurrentTool("select.idle");
        }
    }
    cancel() {
        this.parent.transition("idle");
    }
}
function maybeSnapToGrid(point, editor) {
    const isGridMode = editor.getInstanceState().isGridMode;
    const gridSize = editor.getDocumentSettings().gridSize;
    if (isGridMode) return point.clone().snapToGrid(gridSize);
    return point.clone();
}
;
 //# sourceMappingURL=Pointing.mjs.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/BaseBoxShapeTool.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseBoxShapeTool",
    ()=>BaseBoxShapeTool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/StateNode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/children/Idle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tldraw/editor/dist-esm/lib/editor/tools/BaseBoxShapeTool/children/Pointing.mjs [app-client] (ecmascript)");
;
;
;
class BaseBoxShapeTool extends __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$StateNode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateNode"] {
    static id = "box";
    static initial = "idle";
    static children() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Idle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Idle"],
            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tldraw$2f$editor$2f$dist$2d$esm$2f$lib$2f$editor$2f$tools$2f$BaseBoxShapeTool$2f$children$2f$Pointing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pointing"]
        ];
    }
}
;
 //# sourceMappingURL=BaseBoxShapeTool.mjs.map
}),
]);

//# debugId=1d8516f6-3439-f858-45c1-9d801461f56a
//# sourceMappingURL=c427b_%40tldraw_editor_dist-esm_lib_editor_d94f5607._.js.map