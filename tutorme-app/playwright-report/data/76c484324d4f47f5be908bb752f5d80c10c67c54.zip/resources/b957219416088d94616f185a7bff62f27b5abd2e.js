;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="87c0a5ab-254f-37b4-a1b0-cbf9f112e3cc")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/transform/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// transform/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/commands/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// commands/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/state/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// state/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/model/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// model/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/schema-list/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// schema-list/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/view/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// view/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/keymap/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// keymap/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/dropcursor/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// dropcursor/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/gapcursor/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// gapcursor/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/history/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// history/index.ts
__turbopack_context__.s([]);
;
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-code/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Code",
    ()=>Code,
    "default",
    ()=>index_default,
    "inputRegex",
    ()=>inputRegex,
    "pasteRegex",
    ()=>pasteRegex
]);
// src/code.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var inputRegex = /(^|[^`])`([^`]+)`(?!`)$/;
var pasteRegex = /(^|[^`])`([^`]+)`(?!`)/g;
var Code = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "code",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    excludes: "_",
    code: true,
    exitable: true,
    parseHTML () {
        return [
            {
                tag: "code"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "code",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "codespan",
    parseMarkdown: (token, helpers)=>{
        return helpers.applyMark("code", [
            {
                type: "text",
                text: token.text || ""
            }
        ]);
    },
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        return `\`${h.renderChildren(node.content)}\``;
    },
    addCommands () {
        return {
            setCode: ()=>({ commands })=>{
                    return commands.setMark(this.name);
                },
            toggleCode: ()=>({ commands })=>{
                    return commands.toggleMark(this.name);
                },
            unsetCode: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-e": ()=>this.editor.commands.toggleCode()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: inputRegex,
                type: this.type
            })
        ];
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: pasteRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Code;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-highlight/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Highlight",
    ()=>Highlight,
    "default",
    ()=>index_default,
    "inputRegex",
    ()=>inputRegex,
    "pasteRegex",
    ()=>pasteRegex
]);
// src/highlight.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var inputRegex = /(?:^|\s)(==(?!\s+==)((?:[^=]+))==(?!\s+==))$/;
var pasteRegex = /(?:^|\s)(==(?!\s+==)((?:[^=]+))==(?!\s+==))/g;
var Highlight = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "highlight",
    addOptions () {
        return {
            multicolor: false,
            HTMLAttributes: {}
        };
    },
    addAttributes () {
        if (!this.options.multicolor) {
            return {};
        }
        return {
            color: {
                default: null,
                parseHTML: (element)=>element.getAttribute("data-color") || element.style.backgroundColor,
                renderHTML: (attributes)=>{
                    if (!attributes.color) {
                        return {};
                    }
                    return {
                        "data-color": attributes.color,
                        style: `background-color: ${attributes.color}; color: inherit`
                    };
                }
            }
        };
    },
    parseHTML () {
        return [
            {
                tag: "mark"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "mark",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    renderMarkdown: (node, h)=>{
        return `==${h.renderChildren(node)}==`;
    },
    parseMarkdown: (token, h)=>{
        return h.applyMark("highlight", h.parseInline(token.tokens || []));
    },
    markdownTokenizer: {
        name: "highlight",
        level: "inline",
        start: (src)=>src.indexOf("=="),
        tokenize (src, _, h) {
            const rule = /^(==)([^=]+)(==)/;
            const match = rule.exec(src);
            if (match) {
                const innerContent = match[2].trim();
                const children = h.inlineTokens(innerContent);
                return {
                    type: "highlight",
                    raw: match[0],
                    text: innerContent,
                    tokens: children
                };
            }
        }
    },
    addCommands () {
        return {
            setHighlight: (attributes)=>({ commands })=>{
                    return commands.setMark(this.name, attributes);
                },
            toggleHighlight: (attributes)=>({ commands })=>{
                    return commands.toggleMark(this.name, attributes);
                },
            unsetHighlight: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-h": ()=>this.editor.commands.toggleHighlight()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: inputRegex,
                type: this.type
            })
        ];
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: pasteRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Highlight;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-blockquote/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Blockquote",
    ()=>Blockquote,
    "default",
    ()=>index_default,
    "inputRegex",
    ()=>inputRegex
]);
// src/blockquote.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/jsx-runtime/jsx-runtime.js [app-client] (ecmascript)");
;
;
var inputRegex = /^\s*>\s$/;
var Blockquote = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "blockquote",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    content: "block+",
    group: "block",
    defining: true,
    parseHTML () {
        return [
            {
                tag: "blockquote"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("blockquote", {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("slot", {})
        });
    },
    parseMarkdown: (token, helpers)=>{
        return helpers.createNode("blockquote", void 0, helpers.parseChildren(token.tokens || []));
    },
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        const prefix = ">";
        const result = [];
        node.content.forEach((child)=>{
            const childContent = h.renderChildren([
                child
            ]);
            const lines = childContent.split("\n");
            const linesWithPrefix = lines.map((line)=>{
                if (line.trim() === "") {
                    return prefix;
                }
                return `${prefix} ${line}`;
            });
            result.push(linesWithPrefix.join("\n"));
        });
        return result.join(`
${prefix}
`);
    },
    addCommands () {
        return {
            setBlockquote: ()=>({ commands })=>{
                    return commands.wrapIn(this.name);
                },
            toggleBlockquote: ()=>({ commands })=>{
                    return commands.toggleWrap(this.name);
                },
            unsetBlockquote: ()=>({ commands })=>{
                    return commands.lift(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-b": ()=>this.editor.commands.toggleBlockquote()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
                find: inputRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Blockquote;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-bold/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bold",
    ()=>Bold,
    "default",
    ()=>index_default,
    "starInputRegex",
    ()=>starInputRegex,
    "starPasteRegex",
    ()=>starPasteRegex,
    "underscoreInputRegex",
    ()=>underscoreInputRegex,
    "underscorePasteRegex",
    ()=>underscorePasteRegex
]);
// src/bold.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/jsx-runtime/jsx-runtime.js [app-client] (ecmascript)");
;
;
var starInputRegex = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))$/;
var starPasteRegex = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))/g;
var underscoreInputRegex = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))$/;
var underscorePasteRegex = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))/g;
var Bold = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "bold",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    parseHTML () {
        return [
            {
                tag: "strong"
            },
            {
                tag: "b",
                getAttrs: (node)=>node.style.fontWeight !== "normal" && null
            },
            {
                style: "font-weight=400",
                clearMark: (mark)=>mark.type.name === this.name
            },
            {
                style: "font-weight",
                getAttrs: (value)=>/^(bold(er)?|[5-9]\d{2,})$/.test(value) && null
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("strong", {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$jsx$2d$runtime$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("slot", {})
        });
    },
    markdownTokenName: "strong",
    parseMarkdown: (token, helpers)=>{
        return helpers.applyMark("bold", helpers.parseInline(token.tokens || []));
    },
    renderMarkdown: (node, h)=>{
        return `**${h.renderChildren(node)}**`;
    },
    addCommands () {
        return {
            setBold: ()=>({ commands })=>{
                    return commands.setMark(this.name);
                },
            toggleBold: ()=>({ commands })=>{
                    return commands.toggleMark(this.name);
                },
            unsetBold: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-b": ()=>this.editor.commands.toggleBold(),
            "Mod-B": ()=>this.editor.commands.toggleBold()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: starInputRegex,
                type: this.type
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: underscoreInputRegex,
                type: this.type
            })
        ];
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: starPasteRegex,
                type: this.type
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: underscorePasteRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Bold;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-code-block/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CodeBlock",
    ()=>CodeBlock,
    "backtickInputRegex",
    ()=>backtickInputRegex,
    "default",
    ()=>index_default,
    "tildeInputRegex",
    ()=>tildeInputRegex
]);
// src/code-block.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$state$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/state/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-state/dist/index.js [app-client] (ecmascript)");
;
;
var DEFAULT_TAB_SIZE = 4;
var backtickInputRegex = /^```([a-z]+)?[\s\n]$/;
var tildeInputRegex = /^~~~([a-z]+)?[\s\n]$/;
var CodeBlock = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "codeBlock",
    addOptions () {
        return {
            languageClassPrefix: "language-",
            exitOnTripleEnter: true,
            exitOnArrowDown: true,
            defaultLanguage: null,
            enableTabIndentation: false,
            tabSize: DEFAULT_TAB_SIZE,
            HTMLAttributes: {}
        };
    },
    content: "text*",
    marks: "",
    group: "block",
    code: true,
    defining: true,
    addAttributes () {
        return {
            language: {
                default: this.options.defaultLanguage,
                parseHTML: (element)=>{
                    var _a;
                    const { languageClassPrefix } = this.options;
                    if (!languageClassPrefix) {
                        return null;
                    }
                    const classNames = [
                        ...((_a = element.firstElementChild) == null ? void 0 : _a.classList) || []
                    ];
                    const languages = classNames.filter((className)=>className.startsWith(languageClassPrefix)).map((className)=>className.replace(languageClassPrefix, ""));
                    const language = languages[0];
                    if (!language) {
                        return null;
                    }
                    return language;
                },
                rendered: false
            }
        };
    },
    parseHTML () {
        return [
            {
                tag: "pre",
                preserveWhitespace: "full"
            }
        ];
    },
    renderHTML ({ node, HTMLAttributes }) {
        return [
            "pre",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            [
                "code",
                {
                    class: node.attrs.language ? this.options.languageClassPrefix + node.attrs.language : null
                },
                0
            ]
        ];
    },
    markdownTokenName: "code",
    parseMarkdown: (token, helpers)=>{
        var _a;
        if (((_a = token.raw) == null ? void 0 : _a.startsWith("```")) === false && token.codeBlockStyle !== "indented") {
            return [];
        }
        return helpers.createNode("codeBlock", {
            language: token.lang || null
        }, token.text ? [
            helpers.createTextNode(token.text)
        ] : []);
    },
    renderMarkdown: (node, h)=>{
        var _a;
        let output = "";
        const language = ((_a = node.attrs) == null ? void 0 : _a.language) || "";
        if (!node.content) {
            output = `\`\`\`${language}

\`\`\``;
        } else {
            const lines = [
                `\`\`\`${language}`,
                h.renderChildren(node.content),
                "```"
            ];
            output = lines.join("\n");
        }
        return output;
    },
    addCommands () {
        return {
            setCodeBlock: (attributes)=>({ commands })=>{
                    return commands.setNode(this.name, attributes);
                },
            toggleCodeBlock: (attributes)=>({ commands })=>{
                    return commands.toggleNode(this.name, "paragraph", attributes);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Alt-c": ()=>this.editor.commands.toggleCodeBlock(),
            // remove code block when at start of document or code block is empty
            Backspace: ()=>{
                const { empty, $anchor } = this.editor.state.selection;
                const isAtStart = $anchor.pos === 1;
                if (!empty || $anchor.parent.type.name !== this.name) {
                    return false;
                }
                if (isAtStart || !$anchor.parent.textContent.length) {
                    return this.editor.commands.clearNodes();
                }
                return false;
            },
            // handle tab indentation
            Tab: ({ editor })=>{
                var _a;
                if (!this.options.enableTabIndentation) {
                    return false;
                }
                const tabSize = (_a = this.options.tabSize) != null ? _a : DEFAULT_TAB_SIZE;
                const { state } = editor;
                const { selection } = state;
                const { $from, empty } = selection;
                if ($from.parent.type !== this.type) {
                    return false;
                }
                const indent = " ".repeat(tabSize);
                if (empty) {
                    return editor.commands.insertContent(indent);
                }
                return editor.commands.command(({ tr })=>{
                    const { from, to } = selection;
                    const text = state.doc.textBetween(from, to, "\n", "\n");
                    const lines = text.split("\n");
                    const indentedText = lines.map((line)=>indent + line).join("\n");
                    tr.replaceWith(from, to, state.schema.text(indentedText));
                    return true;
                });
            },
            // handle shift+tab reverse indentation
            "Shift-Tab": ({ editor })=>{
                var _a;
                if (!this.options.enableTabIndentation) {
                    return false;
                }
                const tabSize = (_a = this.options.tabSize) != null ? _a : DEFAULT_TAB_SIZE;
                const { state } = editor;
                const { selection } = state;
                const { $from, empty } = selection;
                if ($from.parent.type !== this.type) {
                    return false;
                }
                if (empty) {
                    return editor.commands.command(({ tr })=>{
                        var _a2;
                        const { pos } = $from;
                        const codeBlockStart = $from.start();
                        const codeBlockEnd = $from.end();
                        const allText = state.doc.textBetween(codeBlockStart, codeBlockEnd, "\n", "\n");
                        const lines = allText.split("\n");
                        let currentLineIndex = 0;
                        let charCount = 0;
                        const relativeCursorPos = pos - codeBlockStart;
                        for(let i = 0; i < lines.length; i += 1){
                            if (charCount + lines[i].length >= relativeCursorPos) {
                                currentLineIndex = i;
                                break;
                            }
                            charCount += lines[i].length + 1;
                        }
                        const currentLine = lines[currentLineIndex];
                        const leadingSpaces = ((_a2 = currentLine.match(/^ */)) == null ? void 0 : _a2[0]) || "";
                        const spacesToRemove = Math.min(leadingSpaces.length, tabSize);
                        if (spacesToRemove === 0) {
                            return true;
                        }
                        let lineStartPos = codeBlockStart;
                        for(let i = 0; i < currentLineIndex; i += 1){
                            lineStartPos += lines[i].length + 1;
                        }
                        tr.delete(lineStartPos, lineStartPos + spacesToRemove);
                        const cursorPosInLine = pos - lineStartPos;
                        if (cursorPosInLine <= spacesToRemove) {
                            tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextSelection"].create(tr.doc, lineStartPos));
                        }
                        return true;
                    });
                }
                return editor.commands.command(({ tr })=>{
                    const { from, to } = selection;
                    const text = state.doc.textBetween(from, to, "\n", "\n");
                    const lines = text.split("\n");
                    const reverseIndentText = lines.map((line)=>{
                        var _a2;
                        const leadingSpaces = ((_a2 = line.match(/^ */)) == null ? void 0 : _a2[0]) || "";
                        const spacesToRemove = Math.min(leadingSpaces.length, tabSize);
                        return line.slice(spacesToRemove);
                    }).join("\n");
                    tr.replaceWith(from, to, state.schema.text(reverseIndentText));
                    return true;
                });
            },
            // exit node on triple enter
            Enter: ({ editor })=>{
                if (!this.options.exitOnTripleEnter) {
                    return false;
                }
                const { state } = editor;
                const { selection } = state;
                const { $from, empty } = selection;
                if (!empty || $from.parent.type !== this.type) {
                    return false;
                }
                const isAtEnd = $from.parentOffset === $from.parent.nodeSize - 2;
                const endsWithDoubleNewline = $from.parent.textContent.endsWith("\n\n");
                if (!isAtEnd || !endsWithDoubleNewline) {
                    return false;
                }
                return editor.chain().command(({ tr })=>{
                    tr.delete($from.pos - 2, $from.pos);
                    return true;
                }).exitCode().run();
            },
            // exit node on arrow down
            ArrowDown: ({ editor })=>{
                if (!this.options.exitOnArrowDown) {
                    return false;
                }
                const { state } = editor;
                const { selection, doc } = state;
                const { $from, empty } = selection;
                if (!empty || $from.parent.type !== this.type) {
                    return false;
                }
                const isAtEnd = $from.parentOffset === $from.parent.nodeSize - 2;
                if (!isAtEnd) {
                    return false;
                }
                const after = $from.after();
                if (after === void 0) {
                    return false;
                }
                const nodeAfter = doc.nodeAt(after);
                if (nodeAfter) {
                    return editor.commands.command(({ tr })=>{
                        tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Selection"].near(doc.resolve(after)));
                        return true;
                    });
                }
                return editor.commands.exitCode();
            }
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textblockTypeInputRule"])({
                find: backtickInputRegex,
                type: this.type,
                getAttributes: (match)=>({
                        language: match[1]
                    })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textblockTypeInputRule"])({
                find: tildeInputRegex,
                type: this.type,
                getAttributes: (match)=>({
                        language: match[1]
                    })
            })
        ];
    },
    addProseMirrorPlugins () {
        return [
            // this plugin creates a code block for pasted content from VS Code
            // we can also detect the copied code language
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("codeBlockVSCodeHandler"),
                props: {
                    handlePaste: (view, event)=>{
                        if (!event.clipboardData) {
                            return false;
                        }
                        if (this.editor.isActive(this.type.name)) {
                            return false;
                        }
                        const text = event.clipboardData.getData("text/plain");
                        const vscode = event.clipboardData.getData("vscode-editor-data");
                        const vscodeData = vscode ? JSON.parse(vscode) : void 0;
                        const language = vscodeData == null ? void 0 : vscodeData.mode;
                        if (!text || !language) {
                            return false;
                        }
                        const { tr, schema } = view.state;
                        const textNode = schema.text(text.replace(/\r\n?/g, "\n"));
                        tr.replaceSelectionWith(this.type.create({
                            language
                        }, textNode));
                        if (tr.selection.$from.parent.type !== this.type) {
                            tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextSelection"].near(tr.doc.resolve(Math.max(0, tr.selection.from - 2))));
                        }
                        tr.setMeta("paste", true);
                        view.dispatch(tr);
                        return true;
                    }
                }
            })
        ];
    }
});
// src/index.ts
var index_default = CodeBlock;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-document/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Document",
    ()=>Document,
    "default",
    ()=>index_default
]);
// src/document.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var Document = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "doc",
    topNode: true,
    content: "block+",
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        return h.renderChildren(node.content, "\n\n");
    }
});
// src/index.ts
var index_default = Document;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-hard-break/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HardBreak",
    ()=>HardBreak,
    "default",
    ()=>index_default
]);
// src/hard-break.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var HardBreak = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "hardBreak",
    markdownTokenName: "br",
    addOptions () {
        return {
            keepMarks: true,
            HTMLAttributes: {}
        };
    },
    inline: true,
    group: "inline",
    selectable: false,
    linebreakReplacement: true,
    parseHTML () {
        return [
            {
                tag: "br"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "br",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes)
        ];
    },
    renderText () {
        return "\n";
    },
    renderMarkdown: ()=>`  
`,
    parseMarkdown: ()=>{
        return {
            type: "hardBreak"
        };
    },
    addCommands () {
        return {
            setHardBreak: ()=>({ commands, chain, state, editor })=>{
                    return commands.first([
                        ()=>commands.exitCode(),
                        ()=>commands.command(()=>{
                                const { selection, storedMarks } = state;
                                if (selection.$from.parent.type.spec.isolating) {
                                    return false;
                                }
                                const { keepMarks } = this.options;
                                const { splittableMarks } = editor.extensionManager;
                                const marks = storedMarks || selection.$to.parentOffset && selection.$from.marks();
                                return chain().insertContent({
                                    type: this.name
                                }).command(({ tr, dispatch })=>{
                                    if (dispatch && marks && keepMarks) {
                                        const filteredMarks = marks.filter((mark)=>splittableMarks.includes(mark.type.name));
                                        tr.ensureMarks(filteredMarks);
                                    }
                                    return true;
                                }).run();
                            })
                    ]);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Enter": ()=>this.editor.commands.setHardBreak(),
            "Shift-Enter": ()=>this.editor.commands.setHardBreak()
        };
    }
});
// src/index.ts
var index_default = HardBreak;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-heading/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Heading",
    ()=>Heading,
    "default",
    ()=>index_default
]);
// src/heading.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var Heading = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "heading",
    addOptions () {
        return {
            levels: [
                1,
                2,
                3,
                4,
                5,
                6
            ],
            HTMLAttributes: {}
        };
    },
    content: "inline*",
    group: "block",
    defining: true,
    addAttributes () {
        return {
            level: {
                default: 1,
                rendered: false
            }
        };
    },
    parseHTML () {
        return this.options.levels.map((level)=>({
                tag: `h${level}`,
                attrs: {
                    level
                }
            }));
    },
    renderHTML ({ node, HTMLAttributes }) {
        const hasLevel = this.options.levels.includes(node.attrs.level);
        const level = hasLevel ? node.attrs.level : this.options.levels[0];
        return [
            `h${level}`,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    parseMarkdown: (token, helpers)=>{
        return helpers.createNode("heading", {
            level: token.depth || 1
        }, helpers.parseInline(token.tokens || []));
    },
    renderMarkdown: (node, h)=>{
        var _a;
        const level = ((_a = node.attrs) == null ? void 0 : _a.level) ? parseInt(node.attrs.level, 10) : 1;
        const headingChars = "#".repeat(level);
        if (!node.content) {
            return "";
        }
        return `${headingChars} ${h.renderChildren(node.content)}`;
    },
    addCommands () {
        return {
            setHeading: (attributes)=>({ commands })=>{
                    if (!this.options.levels.includes(attributes.level)) {
                        return false;
                    }
                    return commands.setNode(this.name, attributes);
                },
            toggleHeading: (attributes)=>({ commands })=>{
                    if (!this.options.levels.includes(attributes.level)) {
                        return false;
                    }
                    return commands.toggleNode(this.name, "paragraph", attributes);
                }
        };
    },
    addKeyboardShortcuts () {
        return this.options.levels.reduce((items, level)=>({
                ...items,
                ...{
                    [`Mod-Alt-${level}`]: ()=>this.editor.commands.toggleHeading({
                            level
                        })
                }
            }), {});
    },
    addInputRules () {
        return this.options.levels.map((level)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textblockTypeInputRule"])({
                find: new RegExp(`^(#{${Math.min(...this.options.levels)},${level}})\\s$`),
                type: this.type,
                getAttributes: {
                    level
                }
            });
        });
    }
});
// src/index.ts
var index_default = Heading;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-horizontal-rule/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HorizontalRule",
    ()=>HorizontalRule,
    "default",
    ()=>index_default
]);
// src/horizontal-rule.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$state$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/state/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-state/dist/index.js [app-client] (ecmascript)");
;
;
var HorizontalRule = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "horizontalRule",
    addOptions () {
        return {
            HTMLAttributes: {},
            nextNodeType: "paragraph"
        };
    },
    group: "block",
    parseHTML () {
        return [
            {
                tag: "hr"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "hr",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes)
        ];
    },
    markdownTokenName: "hr",
    parseMarkdown: (token, helpers)=>{
        return helpers.createNode("horizontalRule");
    },
    renderMarkdown: ()=>{
        return "---";
    },
    addCommands () {
        return {
            setHorizontalRule: ()=>({ chain, state })=>{
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canInsertNode"])(state, state.schema.nodes[this.name])) {
                        return false;
                    }
                    const { selection } = state;
                    const { $to: $originTo } = selection;
                    const currentChain = chain();
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeSelection"])(selection)) {
                        currentChain.insertContentAt($originTo.pos, {
                            type: this.name
                        });
                    } else {
                        currentChain.insertContent({
                            type: this.name
                        });
                    }
                    return currentChain.command(({ state: chainState, tr, dispatch })=>{
                        if (dispatch) {
                            const { $to } = tr.selection;
                            const posAfter = $to.end();
                            if ($to.nodeAfter) {
                                if ($to.nodeAfter.isTextblock) {
                                    tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextSelection"].create(tr.doc, $to.pos + 1));
                                } else if ($to.nodeAfter.isBlock) {
                                    tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NodeSelection"].create(tr.doc, $to.pos));
                                } else {
                                    tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextSelection"].create(tr.doc, $to.pos));
                                }
                            } else {
                                const nodeType = chainState.schema.nodes[this.options.nextNodeType] || $to.parent.type.contentMatch.defaultType;
                                const node = nodeType == null ? void 0 : nodeType.create();
                                if (node) {
                                    tr.insert(posAfter, node);
                                    tr.setSelection(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextSelection"].create(tr.doc, posAfter + 1));
                                }
                            }
                            tr.scrollIntoView();
                        }
                        return true;
                    }).run();
                }
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nodeInputRule"])({
                find: /^(?:---|—-|___\s|\*\*\*\s)$/,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = HorizontalRule;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-italic/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Italic",
    ()=>Italic,
    "default",
    ()=>index_default,
    "starInputRegex",
    ()=>starInputRegex,
    "starPasteRegex",
    ()=>starPasteRegex,
    "underscoreInputRegex",
    ()=>underscoreInputRegex,
    "underscorePasteRegex",
    ()=>underscorePasteRegex
]);
// src/italic.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var starInputRegex = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))$/;
var starPasteRegex = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))/g;
var underscoreInputRegex = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))$/;
var underscorePasteRegex = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))/g;
var Italic = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "italic",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    parseHTML () {
        return [
            {
                tag: "em"
            },
            {
                tag: "i",
                getAttrs: (node)=>node.style.fontStyle !== "normal" && null
            },
            {
                style: "font-style=normal",
                clearMark: (mark)=>mark.type.name === this.name
            },
            {
                style: "font-style=italic"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "em",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    addCommands () {
        return {
            setItalic: ()=>({ commands })=>{
                    return commands.setMark(this.name);
                },
            toggleItalic: ()=>({ commands })=>{
                    return commands.toggleMark(this.name);
                },
            unsetItalic: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    markdownTokenName: "em",
    parseMarkdown: (token, helpers)=>{
        return helpers.applyMark("italic", helpers.parseInline(token.tokens || []));
    },
    renderMarkdown: (node, h)=>{
        return `*${h.renderChildren(node)}*`;
    },
    addKeyboardShortcuts () {
        return {
            "Mod-i": ()=>this.editor.commands.toggleItalic(),
            "Mod-I": ()=>this.editor.commands.toggleItalic()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: starInputRegex,
                type: this.type
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: underscoreInputRegex,
                type: this.type
            })
        ];
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: starPasteRegex,
                type: this.type
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: underscorePasteRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Italic;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-link/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Link",
    ()=>Link,
    "default",
    ()=>index_default,
    "isAllowedUri",
    ()=>isAllowedUri,
    "pasteRegex",
    ()=>pasteRegex
]);
// src/link.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/linkifyjs/dist/linkify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$state$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/state/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-state/dist/index.js [app-client] (ecmascript)");
;
;
;
;
;
// src/helpers/whitespace.ts
var UNICODE_WHITESPACE_PATTERN = "[\0- \xA0\u1680\u180E\u2000-\u2029\u205F\u3000]";
var UNICODE_WHITESPACE_REGEX = new RegExp(UNICODE_WHITESPACE_PATTERN);
var UNICODE_WHITESPACE_REGEX_END = new RegExp(`${UNICODE_WHITESPACE_PATTERN}$`);
var UNICODE_WHITESPACE_REGEX_GLOBAL = new RegExp(UNICODE_WHITESPACE_PATTERN, "g");
// src/helpers/autolink.ts
function isValidLinkStructure(tokens) {
    if (tokens.length === 1) {
        return tokens[0].isLink;
    }
    if (tokens.length === 3 && tokens[1].isLink) {
        return [
            "()",
            "[]"
        ].includes(tokens[0].value + tokens[2].value);
    }
    return false;
}
function autolink(options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
        key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("autolink"),
        appendTransaction: (transactions, oldState, newState)=>{
            const docChanges = transactions.some((transaction)=>transaction.docChanged) && !oldState.doc.eq(newState.doc);
            const preventAutolink = transactions.some((transaction)=>transaction.getMeta("preventAutolink"));
            if (!docChanges || preventAutolink) {
                return;
            }
            const { tr } = newState;
            const transform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTransactionSteps"])(oldState.doc, [
                ...transactions
            ]);
            const changes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChangedRanges"])(transform);
            changes.forEach(({ newRange })=>{
                const nodesInChangedRanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findChildrenInRange"])(newState.doc, newRange, (node)=>node.isTextblock);
                let textBlock;
                let textBeforeWhitespace;
                if (nodesInChangedRanges.length > 1) {
                    textBlock = nodesInChangedRanges[0];
                    textBeforeWhitespace = newState.doc.textBetween(textBlock.pos, textBlock.pos + textBlock.node.nodeSize, void 0, " ");
                } else if (nodesInChangedRanges.length) {
                    const endText = newState.doc.textBetween(newRange.from, newRange.to, " ", " ");
                    if (!UNICODE_WHITESPACE_REGEX_END.test(endText)) {
                        return;
                    }
                    textBlock = nodesInChangedRanges[0];
                    textBeforeWhitespace = newState.doc.textBetween(textBlock.pos, newRange.to, void 0, " ");
                }
                if (textBlock && textBeforeWhitespace) {
                    const wordsBeforeWhitespace = textBeforeWhitespace.split(UNICODE_WHITESPACE_REGEX).filter(Boolean);
                    if (wordsBeforeWhitespace.length <= 0) {
                        return false;
                    }
                    const lastWordBeforeSpace = wordsBeforeWhitespace[wordsBeforeWhitespace.length - 1];
                    const lastWordAndBlockOffset = textBlock.pos + textBeforeWhitespace.lastIndexOf(lastWordBeforeSpace);
                    if (!lastWordBeforeSpace) {
                        return false;
                    }
                    const linksBeforeSpace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokenize"])(lastWordBeforeSpace).map((t)=>t.toObject(options.defaultProtocol));
                    if (!isValidLinkStructure(linksBeforeSpace)) {
                        return false;
                    }
                    linksBeforeSpace.filter((link)=>link.isLink).map((link)=>({
                            ...link,
                            from: lastWordAndBlockOffset + link.start + 1,
                            to: lastWordAndBlockOffset + link.end + 1
                        })).filter((link)=>{
                        if (!newState.schema.marks.code) {
                            return true;
                        }
                        return !newState.doc.rangeHasMark(link.from, link.to, newState.schema.marks.code);
                    }).filter((link)=>options.validate(link.value)).filter((link)=>options.shouldAutoLink(link.value)).forEach((link)=>{
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMarksBetween"])(link.from, link.to, newState.doc).some((item)=>item.mark.type === options.type)) {
                            return;
                        }
                        tr.addMark(link.from, link.to, options.type.create({
                            href: link.href
                        }));
                    });
                }
            });
            if (!tr.steps.length) {
                return;
            }
            return tr;
        }
    });
}
;
;
function clickHandler(options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
        key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("handleClickLink"),
        props: {
            handleClick: (view, pos, event)=>{
                var _a, _b;
                if (event.button !== 0) {
                    return false;
                }
                if (!view.editable) {
                    return false;
                }
                let link = null;
                if (event.target instanceof HTMLAnchorElement) {
                    link = event.target;
                } else {
                    const target = event.target;
                    if (!target) {
                        return false;
                    }
                    const root = options.editor.view.dom;
                    link = target.closest("a");
                    if (link && !root.contains(link)) {
                        link = null;
                    }
                }
                if (!link) {
                    return false;
                }
                let handled = false;
                if (options.enableClickSelection) {
                    const commandResult = options.editor.commands.extendMarkRange(options.type.name);
                    handled = commandResult;
                }
                if (options.openOnClick) {
                    const attrs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAttributes"])(view.state, options.type.name);
                    const href = (_a = link.href) != null ? _a : attrs.href;
                    const target = (_b = link.target) != null ? _b : attrs.target;
                    if (href) {
                        window.open(href, target);
                        handled = true;
                    }
                }
                return handled;
            }
        }
    });
}
;
;
function pasteHandler(options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
        key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("handlePasteLink"),
        props: {
            handlePaste: (view, _event, slice)=>{
                const { shouldAutoLink } = options;
                const { state } = view;
                const { selection } = state;
                const { empty } = selection;
                if (empty) {
                    return false;
                }
                let textContent = "";
                slice.content.forEach((node)=>{
                    textContent += node.textContent;
                });
                const link = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["find"])(textContent, {
                    defaultProtocol: options.defaultProtocol
                }).find((item)=>item.isLink && item.value === textContent);
                if (!textContent || !link || shouldAutoLink !== void 0 && !shouldAutoLink(link.value)) {
                    return false;
                }
                return options.editor.commands.setMark(options.type, {
                    href: link.href
                });
            }
        }
    });
}
// src/link.ts
var pasteRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z]{2,}\b(?:[-a-zA-Z0-9@:%._+~#=?!&/]*)(?:[-a-zA-Z0-9@:%._+~#=?!&/]*)/gi;
function isAllowedUri(uri, protocols) {
    const allowedProtocols = [
        "http",
        "https",
        "ftp",
        "ftps",
        "mailto",
        "tel",
        "callto",
        "sms",
        "cid",
        "xmpp"
    ];
    if (protocols) {
        protocols.forEach((protocol)=>{
            const nextProtocol = typeof protocol === "string" ? protocol : protocol.scheme;
            if (nextProtocol) {
                allowedProtocols.push(nextProtocol);
            }
        });
    }
    return !uri || uri.replace(UNICODE_WHITESPACE_REGEX_GLOBAL, "").match(new RegExp(// eslint-disable-next-line no-useless-escape
    `^(?:(?:${allowedProtocols.join("|")}):|[^a-z]|[a-z0-9+.-]+(?:[^a-z+.-:]|$))`, "i"));
}
var Link = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "link",
    priority: 1e3,
    keepOnSplit: false,
    exitable: true,
    onCreate () {
        if (this.options.validate && !this.options.shouldAutoLink) {
            this.options.shouldAutoLink = this.options.validate;
            console.warn("The `validate` option is deprecated. Rename to the `shouldAutoLink` option instead.");
        }
        this.options.protocols.forEach((protocol)=>{
            if (typeof protocol === "string") {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerCustomProtocol"])(protocol);
                return;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerCustomProtocol"])(protocol.scheme, protocol.optionalSlashes);
        });
    },
    onDestroy () {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reset"])();
    },
    inclusive () {
        return this.options.autolink;
    },
    addOptions () {
        return {
            openOnClick: true,
            enableClickSelection: false,
            linkOnPaste: true,
            autolink: true,
            protocols: [],
            defaultProtocol: "http",
            HTMLAttributes: {
                target: "_blank",
                rel: "noopener noreferrer nofollow",
                class: null
            },
            isAllowedUri: (url, ctx)=>!!isAllowedUri(url, ctx.protocols),
            validate: (url)=>!!url,
            shouldAutoLink: (url)=>{
                const hasProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(url);
                const hasMaybeProtocol = /^[a-z][a-z0-9+.-]*:/i.test(url);
                if (hasProtocol || hasMaybeProtocol && !url.includes("@")) {
                    return true;
                }
                const urlWithoutUserinfo = url.includes("@") ? url.split("@").pop() : url;
                const hostname = urlWithoutUserinfo.split(/[/?#:]/)[0];
                if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) {
                    return false;
                }
                if (!/\./.test(hostname)) {
                    return false;
                }
                return true;
            }
        };
    },
    addAttributes () {
        return {
            href: {
                default: null,
                parseHTML (element) {
                    return element.getAttribute("href");
                }
            },
            target: {
                default: this.options.HTMLAttributes.target
            },
            rel: {
                default: this.options.HTMLAttributes.rel
            },
            class: {
                default: this.options.HTMLAttributes.class
            },
            title: {
                default: null
            }
        };
    },
    parseHTML () {
        return [
            {
                tag: "a[href]",
                getAttrs: (dom)=>{
                    const href = dom.getAttribute("href");
                    if (!href || !this.options.isAllowedUri(href, {
                        defaultValidate: (url)=>!!isAllowedUri(url, this.options.protocols),
                        protocols: this.options.protocols,
                        defaultProtocol: this.options.defaultProtocol
                    })) {
                        return false;
                    }
                    return null;
                }
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        if (!this.options.isAllowedUri(HTMLAttributes.href, {
            defaultValidate: (href)=>!!isAllowedUri(href, this.options.protocols),
            protocols: this.options.protocols,
            defaultProtocol: this.options.defaultProtocol
        })) {
            return [
                "a",
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, {
                    ...HTMLAttributes,
                    href: ""
                }),
                0
            ];
        }
        return [
            "a",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "link",
    parseMarkdown: (token, helpers)=>{
        return helpers.applyMark("link", helpers.parseInline(token.tokens || []), {
            href: token.href,
            title: token.title || null
        });
    },
    renderMarkdown: (node, h)=>{
        var _a, _b, _c, _d;
        const href = (_b = (_a = node.attrs) == null ? void 0 : _a.href) != null ? _b : "";
        const title = (_d = (_c = node.attrs) == null ? void 0 : _c.title) != null ? _d : "";
        const text = h.renderChildren(node);
        return title ? `[${text}](${href} "${title}")` : `[${text}](${href})`;
    },
    addCommands () {
        return {
            setLink: (attributes)=>({ chain })=>{
                    const { href } = attributes;
                    if (!this.options.isAllowedUri(href, {
                        defaultValidate: (url)=>!!isAllowedUri(url, this.options.protocols),
                        protocols: this.options.protocols,
                        defaultProtocol: this.options.defaultProtocol
                    })) {
                        return false;
                    }
                    return chain().setMark(this.name, attributes).setMeta("preventAutolink", true).run();
                },
            toggleLink: (attributes)=>({ chain })=>{
                    const { href } = attributes || {};
                    if (href && !this.options.isAllowedUri(href, {
                        defaultValidate: (url)=>!!isAllowedUri(url, this.options.protocols),
                        protocols: this.options.protocols,
                        defaultProtocol: this.options.defaultProtocol
                    })) {
                        return false;
                    }
                    return chain().toggleMark(this.name, attributes, {
                        extendEmptyMarkRange: true
                    }).setMeta("preventAutolink", true).run();
                },
            unsetLink: ()=>({ chain })=>{
                    return chain().unsetMark(this.name, {
                        extendEmptyMarkRange: true
                    }).setMeta("preventAutolink", true).run();
                }
        };
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: (text)=>{
                    const foundLinks = [];
                    if (text) {
                        const { protocols, defaultProtocol } = this.options;
                        const links = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$linkifyjs$2f$dist$2f$linkify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["find"])(text).filter((item)=>item.isLink && this.options.isAllowedUri(item.value, {
                                defaultValidate: (href)=>!!isAllowedUri(href, protocols),
                                protocols,
                                defaultProtocol
                            }));
                        if (links.length) {
                            links.forEach((link)=>{
                                if (!this.options.shouldAutoLink(link.value)) {
                                    return;
                                }
                                foundLinks.push({
                                    text: link.value,
                                    data: {
                                        href: link.href
                                    },
                                    index: link.start
                                });
                            });
                        }
                    }
                    return foundLinks;
                },
                type: this.type,
                getAttributes: (match)=>{
                    var _a;
                    return {
                        href: (_a = match.data) == null ? void 0 : _a.href
                    };
                }
            })
        ];
    },
    addProseMirrorPlugins () {
        const plugins = [];
        const { protocols, defaultProtocol } = this.options;
        if (this.options.autolink) {
            plugins.push(autolink({
                type: this.type,
                defaultProtocol: this.options.defaultProtocol,
                validate: (url)=>this.options.isAllowedUri(url, {
                        defaultValidate: (href)=>!!isAllowedUri(href, protocols),
                        protocols,
                        defaultProtocol
                    }),
                shouldAutoLink: this.options.shouldAutoLink
            }));
        }
        plugins.push(clickHandler({
            type: this.type,
            editor: this.editor,
            openOnClick: this.options.openOnClick === "whenNotEditable" ? true : this.options.openOnClick,
            enableClickSelection: this.options.enableClickSelection
        }));
        if (this.options.linkOnPaste) {
            plugins.push(pasteHandler({
                editor: this.editor,
                defaultProtocol: this.options.defaultProtocol,
                type: this.type,
                shouldAutoLink: this.options.shouldAutoLink
            }));
        }
        return plugins;
    }
});
// src/index.ts
var index_default = Link;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-list/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BulletList",
    ()=>BulletList,
    "ListItem",
    ()=>ListItem,
    "ListKeymap",
    ()=>ListKeymap,
    "ListKit",
    ()=>ListKit,
    "OrderedList",
    ()=>OrderedList,
    "TaskItem",
    ()=>TaskItem,
    "TaskList",
    ()=>TaskList,
    "bulletListInputRegex",
    ()=>bulletListInputRegex,
    "inputRegex",
    ()=>inputRegex,
    "listHelpers",
    ()=>listHelpers_exports,
    "orderedListInputRegex",
    ()=>orderedListInputRegex
]);
// src/bullet-list/bullet-list.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __defProp = Object.defineProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
;
var ListItemName = "listItem";
var TextStyleName = "textStyle";
var bulletListInputRegex = /^\s*([-+*])\s$/;
var BulletList = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "bulletList",
    addOptions () {
        return {
            itemTypeName: "listItem",
            HTMLAttributes: {},
            keepMarks: false,
            keepAttributes: false
        };
    },
    group: "block list",
    content () {
        return `${this.options.itemTypeName}+`;
    },
    parseHTML () {
        return [
            {
                tag: "ul"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "ul",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "list",
    parseMarkdown: (token, helpers)=>{
        if (token.type !== "list" || token.ordered) {
            return [];
        }
        return {
            type: "bulletList",
            content: token.items ? helpers.parseChildren(token.items) : []
        };
    },
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        return h.renderChildren(node.content, "\n");
    },
    markdownOptions: {
        indentsContent: true
    },
    addCommands () {
        return {
            toggleBulletList: ()=>({ commands, chain })=>{
                    if (this.options.keepAttributes) {
                        return chain().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(ListItemName, this.editor.getAttributes(TextStyleName)).run();
                    }
                    return commands.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-8": ()=>this.editor.commands.toggleBulletList()
        };
    },
    addInputRules () {
        let inputRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
            find: bulletListInputRegex,
            type: this.type
        });
        if (this.options.keepMarks || this.options.keepAttributes) {
            inputRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
                find: bulletListInputRegex,
                type: this.type,
                keepMarks: this.options.keepMarks,
                keepAttributes: this.options.keepAttributes,
                getAttributes: ()=>{
                    return this.editor.getAttributes(TextStyleName);
                },
                editor: this.editor
            });
        }
        return [
            inputRule
        ];
    }
});
;
var ListItem = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "listItem",
    addOptions () {
        return {
            HTMLAttributes: {},
            bulletListTypeName: "bulletList",
            orderedListTypeName: "orderedList"
        };
    },
    content: "paragraph block*",
    defining: true,
    parseHTML () {
        return [
            {
                tag: "li"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "li",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "list_item",
    parseMarkdown: (token, helpers)=>{
        if (token.type !== "list_item") {
            return [];
        }
        let content = [];
        if (token.tokens && token.tokens.length > 0) {
            const hasParagraphTokens = token.tokens.some((t)=>t.type === "paragraph");
            if (hasParagraphTokens) {
                content = helpers.parseChildren(token.tokens);
            } else {
                const firstToken = token.tokens[0];
                if (firstToken && firstToken.type === "text" && firstToken.tokens && firstToken.tokens.length > 0) {
                    const inlineContent = helpers.parseInline(firstToken.tokens);
                    content = [
                        {
                            type: "paragraph",
                            content: inlineContent
                        }
                    ];
                    if (token.tokens.length > 1) {
                        const remainingTokens = token.tokens.slice(1);
                        const additionalContent = helpers.parseChildren(remainingTokens);
                        content.push(...additionalContent);
                    }
                } else {
                    content = helpers.parseChildren(token.tokens);
                }
            }
        }
        if (content.length === 0) {
            content = [
                {
                    type: "paragraph",
                    content: []
                }
            ];
        }
        return {
            type: "listItem",
            content
        };
    },
    renderMarkdown: (node, h, ctx)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderNestedMarkdownContent"])(node, h, (context)=>{
            var _a, _b;
            if (context.parentType === "bulletList") {
                return "- ";
            }
            if (context.parentType === "orderedList") {
                const start = ((_b = (_a = context.meta) == null ? void 0 : _a.parentAttrs) == null ? void 0 : _b.start) || 1;
                return `${start + context.index}. `;
            }
            return "- ";
        }, ctx);
    },
    addKeyboardShortcuts () {
        return {
            Enter: ()=>this.editor.commands.splitListItem(this.name),
            Tab: ()=>this.editor.commands.sinkListItem(this.name),
            "Shift-Tab": ()=>this.editor.commands.liftListItem(this.name)
        };
    }
});
;
// src/keymap/listHelpers/index.ts
var listHelpers_exports = {};
__export(listHelpers_exports, {
    findListItemPos: ()=>findListItemPos,
    getNextListDepth: ()=>getNextListDepth,
    handleBackspace: ()=>handleBackspace,
    handleDelete: ()=>handleDelete,
    hasListBefore: ()=>hasListBefore,
    hasListItemAfter: ()=>hasListItemAfter,
    hasListItemBefore: ()=>hasListItemBefore,
    listItemHasSubList: ()=>listItemHasSubList,
    nextListIsDeeper: ()=>nextListIsDeeper,
    nextListIsHigher: ()=>nextListIsHigher
});
;
var findListItemPos = (typeOrName, state)=>{
    const { $from } = state.selection;
    const nodeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeType"])(typeOrName, state.schema);
    let currentNode = null;
    let currentDepth = $from.depth;
    let currentPos = $from.pos;
    let targetDepth = null;
    while(currentDepth > 0 && targetDepth === null){
        currentNode = $from.node(currentDepth);
        if (currentNode.type === nodeType) {
            targetDepth = currentDepth;
        } else {
            currentDepth -= 1;
            currentPos -= 1;
        }
    }
    if (targetDepth === null) {
        return null;
    }
    return {
        $pos: state.doc.resolve(currentPos),
        depth: targetDepth
    };
};
;
var getNextListDepth = (typeOrName, state)=>{
    const listItemPos = findListItemPos(typeOrName, state);
    if (!listItemPos) {
        return false;
    }
    const [, depth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeAtPosition"])(state, typeOrName, listItemPos.$pos.pos + 4);
    return depth;
};
;
// src/keymap/listHelpers/hasListBefore.ts
var hasListBefore = (editorState, name, parentListTypes)=>{
    const { $anchor } = editorState.selection;
    const previousNodePos = Math.max(0, $anchor.pos - 2);
    const previousNode = editorState.doc.resolve(previousNodePos).node();
    if (!previousNode || !parentListTypes.includes(previousNode.type.name)) {
        return false;
    }
    return true;
};
// src/keymap/listHelpers/hasListItemBefore.ts
var hasListItemBefore = (typeOrName, state)=>{
    var _a;
    const { $anchor } = state.selection;
    const $targetPos = state.doc.resolve($anchor.pos - 2);
    if ($targetPos.index() === 0) {
        return false;
    }
    if (((_a = $targetPos.nodeBefore) == null ? void 0 : _a.type.name) !== typeOrName) {
        return false;
    }
    return true;
};
;
var listItemHasSubList = (typeOrName, state, node)=>{
    if (!node) {
        return false;
    }
    const nodeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeType"])(typeOrName, state.schema);
    let hasSubList = false;
    node.descendants((child)=>{
        if (child.type === nodeType) {
            hasSubList = true;
        }
    });
    return hasSubList;
};
// src/keymap/listHelpers/handleBackspace.ts
var handleBackspace = (editor, name, parentListTypes)=>{
    if (editor.commands.undoInputRule()) {
        return true;
    }
    if (editor.state.selection.from !== editor.state.selection.to) {
        return false;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeActive"])(editor.state, name) && hasListBefore(editor.state, name, parentListTypes)) {
        const { $anchor } = editor.state.selection;
        const $listPos = editor.state.doc.resolve($anchor.before() - 1);
        const listDescendants = [];
        $listPos.node().descendants((node, pos)=>{
            if (node.type.name === name) {
                listDescendants.push({
                    node,
                    pos
                });
            }
        });
        const lastItem = listDescendants.at(-1);
        if (!lastItem) {
            return false;
        }
        const $lastItemPos = editor.state.doc.resolve($listPos.start() + lastItem.pos + 1);
        return editor.chain().cut({
            from: $anchor.start() - 1,
            to: $anchor.end() + 1
        }, $lastItemPos.end()).joinForward().run();
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeActive"])(editor.state, name)) {
        return false;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAtStartOfNode"])(editor.state)) {
        return false;
    }
    const listItemPos = findListItemPos(name, editor.state);
    if (!listItemPos) {
        return false;
    }
    const $prev = editor.state.doc.resolve(listItemPos.$pos.pos - 2);
    const prevNode = $prev.node(listItemPos.depth);
    const previousListItemHasSubList = listItemHasSubList(name, editor.state, prevNode);
    if (hasListItemBefore(name, editor.state) && !previousListItemHasSubList) {
        return editor.commands.joinItemBackward();
    }
    return editor.chain().liftListItem(name).run();
};
;
// src/keymap/listHelpers/nextListIsDeeper.ts
var nextListIsDeeper = (typeOrName, state)=>{
    const listDepth = getNextListDepth(typeOrName, state);
    const listItemPos = findListItemPos(typeOrName, state);
    if (!listItemPos || !listDepth) {
        return false;
    }
    if (listDepth > listItemPos.depth) {
        return true;
    }
    return false;
};
// src/keymap/listHelpers/nextListIsHigher.ts
var nextListIsHigher = (typeOrName, state)=>{
    const listDepth = getNextListDepth(typeOrName, state);
    const listItemPos = findListItemPos(typeOrName, state);
    if (!listItemPos || !listDepth) {
        return false;
    }
    if (listDepth < listItemPos.depth) {
        return true;
    }
    return false;
};
// src/keymap/listHelpers/handleDelete.ts
var handleDelete = (editor, name)=>{
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeActive"])(editor.state, name)) {
        return false;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAtEndOfNode"])(editor.state, name)) {
        return false;
    }
    const { selection } = editor.state;
    const { $from, $to } = selection;
    if (!selection.empty && $from.sameParent($to)) {
        return false;
    }
    if (nextListIsDeeper(name, editor.state)) {
        return editor.chain().focus(editor.state.selection.from + 4).lift(name).joinBackward().run();
    }
    if (nextListIsHigher(name, editor.state)) {
        return editor.chain().joinForward().joinBackward().run();
    }
    return editor.commands.joinItemForward();
};
// src/keymap/listHelpers/hasListItemAfter.ts
var hasListItemAfter = (typeOrName, state)=>{
    var _a;
    const { $anchor } = state.selection;
    const $targetPos = state.doc.resolve($anchor.pos - $anchor.parentOffset - 2);
    if ($targetPos.index() === $targetPos.parent.childCount - 1) {
        return false;
    }
    if (((_a = $targetPos.nodeAfter) == null ? void 0 : _a.type.name) !== typeOrName) {
        return false;
    }
    return true;
};
// src/keymap/list-keymap.ts
var ListKeymap = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "listKeymap",
    addOptions () {
        return {
            listTypes: [
                {
                    itemName: "listItem",
                    wrapperNames: [
                        "bulletList",
                        "orderedList"
                    ]
                },
                {
                    itemName: "taskItem",
                    wrapperNames: [
                        "taskList"
                    ]
                }
            ]
        };
    },
    addKeyboardShortcuts () {
        return {
            Delete: ({ editor })=>{
                let handled = false;
                this.options.listTypes.forEach(({ itemName })=>{
                    if (editor.state.schema.nodes[itemName] === void 0) {
                        return;
                    }
                    if (handleDelete(editor, itemName)) {
                        handled = true;
                    }
                });
                return handled;
            },
            "Mod-Delete": ({ editor })=>{
                let handled = false;
                this.options.listTypes.forEach(({ itemName })=>{
                    if (editor.state.schema.nodes[itemName] === void 0) {
                        return;
                    }
                    if (handleDelete(editor, itemName)) {
                        handled = true;
                    }
                });
                return handled;
            },
            Backspace: ({ editor })=>{
                let handled = false;
                this.options.listTypes.forEach(({ itemName, wrapperNames })=>{
                    if (editor.state.schema.nodes[itemName] === void 0) {
                        return;
                    }
                    if (handleBackspace(editor, itemName, wrapperNames)) {
                        handled = true;
                    }
                });
                return handled;
            },
            "Mod-Backspace": ({ editor })=>{
                let handled = false;
                this.options.listTypes.forEach(({ itemName, wrapperNames })=>{
                    if (editor.state.schema.nodes[itemName] === void 0) {
                        return;
                    }
                    if (handleBackspace(editor, itemName, wrapperNames)) {
                        handled = true;
                    }
                });
                return handled;
            }
        };
    }
});
;
;
// src/ordered-list/utils.ts
var ORDERED_LIST_ITEM_REGEX = /^(\s*)(\d+)\.\s+(.*)$/;
var INDENTED_LINE_REGEX = /^\s/;
function collectOrderedListItems(lines) {
    const listItems = [];
    let currentLineIndex = 0;
    let consumed = 0;
    while(currentLineIndex < lines.length){
        const line = lines[currentLineIndex];
        const match = line.match(ORDERED_LIST_ITEM_REGEX);
        if (!match) {
            break;
        }
        const [, indent, number, content] = match;
        const indentLevel = indent.length;
        let itemContent = content;
        let nextLineIndex = currentLineIndex + 1;
        const itemLines = [
            line
        ];
        while(nextLineIndex < lines.length){
            const nextLine = lines[nextLineIndex];
            const nextMatch = nextLine.match(ORDERED_LIST_ITEM_REGEX);
            if (nextMatch) {
                break;
            }
            if (nextLine.trim() === "") {
                itemLines.push(nextLine);
                itemContent += "\n";
                nextLineIndex += 1;
            } else if (nextLine.match(INDENTED_LINE_REGEX)) {
                itemLines.push(nextLine);
                itemContent += `
${nextLine.slice(indentLevel + 2)}`;
                nextLineIndex += 1;
            } else {
                break;
            }
        }
        listItems.push({
            indent: indentLevel,
            number: parseInt(number, 10),
            content: itemContent.trim(),
            raw: itemLines.join("\n")
        });
        consumed = nextLineIndex;
        currentLineIndex = nextLineIndex;
    }
    return [
        listItems,
        consumed
    ];
}
function buildNestedStructure(items, baseIndent, lexer) {
    var _a;
    const result = [];
    let currentIndex = 0;
    while(currentIndex < items.length){
        const item = items[currentIndex];
        if (item.indent === baseIndent) {
            const contentLines = item.content.split("\n");
            const mainText = ((_a = contentLines[0]) == null ? void 0 : _a.trim()) || "";
            const tokens = [];
            if (mainText) {
                tokens.push({
                    type: "paragraph",
                    raw: mainText,
                    tokens: lexer.inlineTokens(mainText)
                });
            }
            const additionalContent = contentLines.slice(1).join("\n").trim();
            if (additionalContent) {
                const blockTokens = lexer.blockTokens(additionalContent);
                tokens.push(...blockTokens);
            }
            let lookAheadIndex = currentIndex + 1;
            const nestedItems = [];
            while(lookAheadIndex < items.length && items[lookAheadIndex].indent > baseIndent){
                nestedItems.push(items[lookAheadIndex]);
                lookAheadIndex += 1;
            }
            if (nestedItems.length > 0) {
                const nextIndent = Math.min(...nestedItems.map((nestedItem)=>nestedItem.indent));
                const nestedListItems = buildNestedStructure(nestedItems, nextIndent, lexer);
                tokens.push({
                    type: "list",
                    ordered: true,
                    start: nestedItems[0].number,
                    items: nestedListItems,
                    raw: nestedItems.map((nestedItem)=>nestedItem.raw).join("\n")
                });
            }
            result.push({
                type: "list_item",
                raw: item.raw,
                tokens
            });
            currentIndex = lookAheadIndex;
        } else {
            currentIndex += 1;
        }
    }
    return result;
}
function parseListItems(items, helpers) {
    return items.map((item)=>{
        if (item.type !== "list_item") {
            return helpers.parseChildren([
                item
            ])[0];
        }
        const content = [];
        if (item.tokens && item.tokens.length > 0) {
            item.tokens.forEach((itemToken)=>{
                if (itemToken.type === "paragraph" || itemToken.type === "list" || itemToken.type === "blockquote" || itemToken.type === "code") {
                    content.push(...helpers.parseChildren([
                        itemToken
                    ]));
                } else if (itemToken.type === "text" && itemToken.tokens) {
                    const inlineContent = helpers.parseChildren([
                        itemToken
                    ]);
                    content.push({
                        type: "paragraph",
                        content: inlineContent
                    });
                } else {
                    const parsed = helpers.parseChildren([
                        itemToken
                    ]);
                    if (parsed.length > 0) {
                        content.push(...parsed);
                    }
                }
            });
        }
        return {
            type: "listItem",
            content
        };
    });
}
// src/ordered-list/ordered-list.ts
var ListItemName2 = "listItem";
var TextStyleName2 = "textStyle";
var orderedListInputRegex = /^(\d+)\.\s$/;
var OrderedList = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "orderedList",
    addOptions () {
        return {
            itemTypeName: "listItem",
            HTMLAttributes: {},
            keepMarks: false,
            keepAttributes: false
        };
    },
    group: "block list",
    content () {
        return `${this.options.itemTypeName}+`;
    },
    addAttributes () {
        return {
            start: {
                default: 1,
                parseHTML: (element)=>{
                    return element.hasAttribute("start") ? parseInt(element.getAttribute("start") || "", 10) : 1;
                }
            },
            type: {
                default: null,
                parseHTML: (element)=>element.getAttribute("type")
            }
        };
    },
    parseHTML () {
        return [
            {
                tag: "ol"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        const { start, ...attributesWithoutStart } = HTMLAttributes;
        return start === 1 ? [
            "ol",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, attributesWithoutStart),
            0
        ] : [
            "ol",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "list",
    parseMarkdown: (token, helpers)=>{
        if (token.type !== "list" || !token.ordered) {
            return [];
        }
        const startValue = token.start || 1;
        const content = token.items ? parseListItems(token.items, helpers) : [];
        if (startValue !== 1) {
            return {
                type: "orderedList",
                attrs: {
                    start: startValue
                },
                content
            };
        }
        return {
            type: "orderedList",
            content
        };
    },
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        return h.renderChildren(node.content, "\n");
    },
    markdownTokenizer: {
        name: "orderedList",
        level: "block",
        start: (src)=>{
            const match = src.match(/^(\s*)(\d+)\.\s+/);
            const index = match == null ? void 0 : match.index;
            return index !== void 0 ? index : -1;
        },
        tokenize: (src, _tokens, lexer)=>{
            var _a;
            const lines = src.split("\n");
            const [listItems, consumed] = collectOrderedListItems(lines);
            if (listItems.length === 0) {
                return void 0;
            }
            const items = buildNestedStructure(listItems, 0, lexer);
            if (items.length === 0) {
                return void 0;
            }
            const startValue = ((_a = listItems[0]) == null ? void 0 : _a.number) || 1;
            return {
                type: "list",
                ordered: true,
                start: startValue,
                items,
                raw: lines.slice(0, consumed).join("\n")
            };
        }
    },
    markdownOptions: {
        indentsContent: true
    },
    addCommands () {
        return {
            toggleOrderedList: ()=>({ commands, chain })=>{
                    if (this.options.keepAttributes) {
                        return chain().toggleList(this.name, this.options.itemTypeName, this.options.keepMarks).updateAttributes(ListItemName2, this.editor.getAttributes(TextStyleName2)).run();
                    }
                    return commands.toggleList(this.name, this.options.itemTypeName, this.options.keepMarks);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-7": ()=>this.editor.commands.toggleOrderedList()
        };
    },
    addInputRules () {
        let inputRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
            find: orderedListInputRegex,
            type: this.type,
            getAttributes: (match)=>({
                    start: +match[1]
                }),
            joinPredicate: (match, node)=>node.childCount + node.attrs.start === +match[1]
        });
        if (this.options.keepMarks || this.options.keepAttributes) {
            inputRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
                find: orderedListInputRegex,
                type: this.type,
                keepMarks: this.options.keepMarks,
                keepAttributes: this.options.keepAttributes,
                getAttributes: (match)=>({
                        start: +match[1],
                        ...this.editor.getAttributes(TextStyleName2)
                    }),
                joinPredicate: (match, node)=>node.childCount + node.attrs.start === +match[1],
                editor: this.editor
            });
        }
        return [
            inputRule
        ];
    }
});
;
var inputRegex = /^\s*(\[([( |x])?\])\s$/;
var TaskItem = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "taskItem",
    addOptions () {
        return {
            nested: false,
            HTMLAttributes: {},
            taskListTypeName: "taskList",
            a11y: void 0
        };
    },
    content () {
        return this.options.nested ? "paragraph block*" : "paragraph+";
    },
    defining: true,
    addAttributes () {
        return {
            checked: {
                default: false,
                keepOnSplit: false,
                parseHTML: (element)=>{
                    const dataChecked = element.getAttribute("data-checked");
                    return dataChecked === "" || dataChecked === "true";
                },
                renderHTML: (attributes)=>({
                        "data-checked": attributes.checked
                    })
            }
        };
    },
    parseHTML () {
        return [
            {
                tag: `li[data-type="${this.name}"]`,
                priority: 51
            }
        ];
    },
    renderHTML ({ node, HTMLAttributes }) {
        return [
            "li",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes, {
                "data-type": this.name
            }),
            [
                "label",
                [
                    "input",
                    {
                        type: "checkbox",
                        checked: node.attrs.checked ? "checked" : null
                    }
                ],
                [
                    "span"
                ]
            ],
            [
                "div",
                0
            ]
        ];
    },
    parseMarkdown: (token, h)=>{
        const content = [];
        if (token.tokens && token.tokens.length > 0) {
            content.push(h.createNode("paragraph", {}, h.parseInline(token.tokens)));
        } else if (token.text) {
            content.push(h.createNode("paragraph", {}, [
                h.createNode("text", {
                    text: token.text
                })
            ]));
        } else {
            content.push(h.createNode("paragraph", {}, []));
        }
        if (token.nestedTokens && token.nestedTokens.length > 0) {
            const nestedContent = h.parseChildren(token.nestedTokens);
            content.push(...nestedContent);
        }
        return h.createNode("taskItem", {
            checked: token.checked || false
        }, content);
    },
    renderMarkdown: (node, h)=>{
        var _a;
        const checkedChar = ((_a = node.attrs) == null ? void 0 : _a.checked) ? "x" : " ";
        const prefix = `- [${checkedChar}] `;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderNestedMarkdownContent"])(node, h, prefix);
    },
    addKeyboardShortcuts () {
        const shortcuts = {
            Enter: ()=>this.editor.commands.splitListItem(this.name),
            "Shift-Tab": ()=>this.editor.commands.liftListItem(this.name)
        };
        if (!this.options.nested) {
            return shortcuts;
        }
        return {
            ...shortcuts,
            Tab: ()=>this.editor.commands.sinkListItem(this.name)
        };
    },
    addNodeView () {
        return ({ node, HTMLAttributes, getPos, editor })=>{
            const listItem = document.createElement("li");
            const checkboxWrapper = document.createElement("label");
            const checkboxStyler = document.createElement("span");
            const checkbox = document.createElement("input");
            const content = document.createElement("div");
            const updateA11Y = (currentNode)=>{
                var _a, _b;
                checkbox.ariaLabel = ((_b = (_a = this.options.a11y) == null ? void 0 : _a.checkboxLabel) == null ? void 0 : _b.call(_a, currentNode, checkbox.checked)) || `Task item checkbox for ${currentNode.textContent || "empty task item"}`;
            };
            updateA11Y(node);
            checkboxWrapper.contentEditable = "false";
            checkbox.type = "checkbox";
            checkbox.addEventListener("mousedown", (event)=>event.preventDefault());
            checkbox.addEventListener("change", (event)=>{
                if (!editor.isEditable && !this.options.onReadOnlyChecked) {
                    checkbox.checked = !checkbox.checked;
                    return;
                }
                const { checked } = event.target;
                if (editor.isEditable && typeof getPos === "function") {
                    editor.chain().focus(void 0, {
                        scrollIntoView: false
                    }).command(({ tr })=>{
                        const position = getPos();
                        if (typeof position !== "number") {
                            return false;
                        }
                        const currentNode = tr.doc.nodeAt(position);
                        tr.setNodeMarkup(position, void 0, {
                            ...currentNode == null ? void 0 : currentNode.attrs,
                            checked
                        });
                        return true;
                    }).run();
                }
                if (!editor.isEditable && this.options.onReadOnlyChecked) {
                    if (!this.options.onReadOnlyChecked(node, checked)) {
                        checkbox.checked = !checkbox.checked;
                    }
                }
            });
            Object.entries(this.options.HTMLAttributes).forEach(([key, value])=>{
                listItem.setAttribute(key, value);
            });
            listItem.dataset.checked = node.attrs.checked;
            checkbox.checked = node.attrs.checked;
            checkboxWrapper.append(checkbox, checkboxStyler);
            listItem.append(checkboxWrapper, content);
            Object.entries(HTMLAttributes).forEach(([key, value])=>{
                listItem.setAttribute(key, value);
            });
            let prevRenderedAttributeKeys = new Set(Object.keys(HTMLAttributes));
            return {
                dom: listItem,
                contentDOM: content,
                update: (updatedNode)=>{
                    if (updatedNode.type !== this.type) {
                        return false;
                    }
                    listItem.dataset.checked = updatedNode.attrs.checked;
                    checkbox.checked = updatedNode.attrs.checked;
                    updateA11Y(updatedNode);
                    const extensionAttributes = editor.extensionManager.attributes;
                    const newHTMLAttributes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRenderedAttributes"])(updatedNode, extensionAttributes);
                    const newKeys = new Set(Object.keys(newHTMLAttributes));
                    const staticAttrs = this.options.HTMLAttributes;
                    prevRenderedAttributeKeys.forEach((key)=>{
                        if (!newKeys.has(key)) {
                            if (key in staticAttrs) {
                                listItem.setAttribute(key, staticAttrs[key]);
                            } else {
                                listItem.removeAttribute(key);
                            }
                        }
                    });
                    Object.entries(newHTMLAttributes).forEach(([key, value])=>{
                        if (value === null || value === void 0) {
                            if (key in staticAttrs) {
                                listItem.setAttribute(key, staticAttrs[key]);
                            } else {
                                listItem.removeAttribute(key);
                            }
                        } else {
                            listItem.setAttribute(key, value);
                        }
                    });
                    prevRenderedAttributeKeys = newKeys;
                    return true;
                }
            };
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrappingInputRule"])({
                find: inputRegex,
                type: this.type,
                getAttributes: (match)=>({
                        checked: match[match.length - 1] === "x"
                    })
            })
        ];
    }
});
;
var TaskList = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "taskList",
    addOptions () {
        return {
            itemTypeName: "taskItem",
            HTMLAttributes: {}
        };
    },
    group: "block list",
    content () {
        return `${this.options.itemTypeName}+`;
    },
    parseHTML () {
        return [
            {
                tag: `ul[data-type="${this.name}"]`,
                priority: 51
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "ul",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes, {
                "data-type": this.name
            }),
            0
        ];
    },
    parseMarkdown: (token, h)=>{
        return h.createNode("taskList", {}, h.parseChildren(token.items || []));
    },
    renderMarkdown: (node, h)=>{
        if (!node.content) {
            return "";
        }
        return h.renderChildren(node.content, "\n");
    },
    markdownTokenizer: {
        name: "taskList",
        level: "block",
        start (src) {
            var _a;
            const index = (_a = src.match(/^\s*[-+*]\s+\[([ xX])\]\s+/)) == null ? void 0 : _a.index;
            return index !== void 0 ? index : -1;
        },
        tokenize (src, tokens, lexer) {
            const parseTaskListContent = (content)=>{
                const nestedResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseIndentedBlocks"])(content, {
                    itemPattern: /^(\s*)([-+*])\s+\[([ xX])\]\s+(.*)$/,
                    extractItemData: (match)=>({
                            indentLevel: match[1].length,
                            mainContent: match[4],
                            checked: match[3].toLowerCase() === "x"
                        }),
                    createToken: (data, nestedTokens)=>({
                            type: "taskItem",
                            raw: "",
                            mainContent: data.mainContent,
                            indentLevel: data.indentLevel,
                            checked: data.checked,
                            text: data.mainContent,
                            tokens: lexer.inlineTokens(data.mainContent),
                            nestedTokens
                        }),
                    // Allow recursive nesting
                    customNestedParser: parseTaskListContent
                }, lexer);
                if (nestedResult) {
                    return [
                        {
                            type: "taskList",
                            raw: nestedResult.raw,
                            items: nestedResult.items
                        }
                    ];
                }
                return lexer.blockTokens(content);
            };
            const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseIndentedBlocks"])(src, {
                itemPattern: /^(\s*)([-+*])\s+\[([ xX])\]\s+(.*)$/,
                extractItemData: (match)=>({
                        indentLevel: match[1].length,
                        mainContent: match[4],
                        checked: match[3].toLowerCase() === "x"
                    }),
                createToken: (data, nestedTokens)=>({
                        type: "taskItem",
                        raw: "",
                        mainContent: data.mainContent,
                        indentLevel: data.indentLevel,
                        checked: data.checked,
                        text: data.mainContent,
                        tokens: lexer.inlineTokens(data.mainContent),
                        nestedTokens
                    }),
                // Use the recursive parser for nested content
                customNestedParser: parseTaskListContent
            }, lexer);
            if (!result) {
                return void 0;
            }
            return {
                type: "taskList",
                raw: result.raw,
                items: result.items
            };
        }
    },
    markdownOptions: {
        indentsContent: true
    },
    addCommands () {
        return {
            toggleTaskList: ()=>({ commands })=>{
                    return commands.toggleList(this.name, this.options.itemTypeName);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-9": ()=>this.editor.commands.toggleTaskList()
        };
    }
});
// src/kit/index.ts
var ListKit = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "listKit",
    addExtensions () {
        const extensions = [];
        if (this.options.bulletList !== false) {
            extensions.push(BulletList.configure(this.options.bulletList));
        }
        if (this.options.listItem !== false) {
            extensions.push(ListItem.configure(this.options.listItem));
        }
        if (this.options.listKeymap !== false) {
            extensions.push(ListKeymap.configure(this.options.listKeymap));
        }
        if (this.options.orderedList !== false) {
            extensions.push(OrderedList.configure(this.options.orderedList));
        }
        if (this.options.taskItem !== false) {
            extensions.push(TaskItem.configure(this.options.taskItem));
        }
        if (this.options.taskList !== false) {
            extensions.push(TaskList.configure(this.options.taskList));
        }
        return extensions;
    }
});
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-paragraph/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Paragraph",
    ()=>Paragraph,
    "default",
    ()=>index_default
]);
// src/paragraph.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var EMPTY_PARAGRAPH_MARKDOWN = "&nbsp;";
var NBSP_CHAR = "\xA0";
var Paragraph = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "paragraph",
    priority: 1e3,
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    group: "block",
    content: "inline*",
    parseHTML () {
        return [
            {
                tag: "p"
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "p",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    parseMarkdown: (token, helpers)=>{
        const tokens = token.tokens || [];
        if (tokens.length === 1 && tokens[0].type === "image") {
            return helpers.parseChildren([
                tokens[0]
            ]);
        }
        const content = helpers.parseInline(tokens);
        if (content.length === 1 && content[0].type === "text" && (content[0].text === EMPTY_PARAGRAPH_MARKDOWN || content[0].text === NBSP_CHAR)) {
            return helpers.createNode("paragraph", void 0, []);
        }
        return helpers.createNode("paragraph", void 0, content);
    },
    renderMarkdown: (node, h)=>{
        if (!node) {
            return "";
        }
        const content = Array.isArray(node.content) ? node.content : [];
        if (content.length === 0) {
            return EMPTY_PARAGRAPH_MARKDOWN;
        }
        return h.renderChildren(content);
    },
    addCommands () {
        return {
            setParagraph: ()=>({ commands })=>{
                    return commands.setNode(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Alt-0": ()=>this.editor.commands.setParagraph()
        };
    }
});
// src/index.ts
var index_default = Paragraph;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-strike/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Strike",
    ()=>Strike,
    "default",
    ()=>index_default,
    "inputRegex",
    ()=>inputRegex,
    "pasteRegex",
    ()=>pasteRegex
]);
// src/strike.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var inputRegex = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))$/;
var pasteRegex = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))/g;
var Strike = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "strike",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    parseHTML () {
        return [
            {
                tag: "s"
            },
            {
                tag: "del"
            },
            {
                tag: "strike"
            },
            {
                style: "text-decoration",
                consuming: false,
                getAttrs: (style)=>style.includes("line-through") ? {} : false
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "s",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    markdownTokenName: "del",
    parseMarkdown: (token, helpers)=>{
        return helpers.applyMark("strike", helpers.parseInline(token.tokens || []));
    },
    renderMarkdown: (node, h)=>{
        return `~~${h.renderChildren(node)}~~`;
    },
    addCommands () {
        return {
            setStrike: ()=>({ commands })=>{
                    return commands.setMark(this.name);
                },
            toggleStrike: ()=>({ commands })=>{
                    return commands.toggleMark(this.name);
                },
            unsetStrike: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-Shift-s": ()=>this.editor.commands.toggleStrike()
        };
    },
    addInputRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markInputRule"])({
                find: inputRegex,
                type: this.type
            })
        ];
    },
    addPasteRules () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markPasteRule"])({
                find: pasteRegex,
                type: this.type
            })
        ];
    }
});
// src/index.ts
var index_default = Strike;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-text/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Text",
    ()=>Text,
    "default",
    ()=>index_default
]);
// src/text.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var Text = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Node"].create({
    name: "text",
    group: "inline",
    parseMarkdown: (token)=>{
        return {
            type: "text",
            text: token.text || ""
        };
    },
    renderMarkdown: (node)=>node.text || ""
});
// src/index.ts
var index_default = Text;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-underline/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Underline",
    ()=>Underline,
    "default",
    ()=>index_default
]);
// src/underline.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
;
var Underline = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mark"].create({
    name: "underline",
    addOptions () {
        return {
            HTMLAttributes: {}
        };
    },
    parseHTML () {
        return [
            {
                tag: "u"
            },
            {
                style: "text-decoration",
                consuming: false,
                getAttrs: (style)=>style.includes("underline") ? {} : false
            }
        ];
    },
    renderHTML ({ HTMLAttributes }) {
        return [
            "u",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeAttributes"])(this.options.HTMLAttributes, HTMLAttributes),
            0
        ];
    },
    parseMarkdown (token, helpers) {
        return helpers.applyMark(this.name || "underline", helpers.parseInline(token.tokens || []));
    },
    renderMarkdown (node, helpers) {
        return `++${helpers.renderChildren(node)}++`;
    },
    markdownTokenizer: {
        name: "underline",
        level: "inline",
        start (src) {
            return src.indexOf("++");
        },
        tokenize (src, _tokens, lexer) {
            const rule = /^(\+\+)([\s\S]+?)(\+\+)/;
            const match = rule.exec(src);
            if (!match) {
                return void 0;
            }
            const innerContent = match[2].trim();
            return {
                type: "underline",
                raw: match[0],
                text: innerContent,
                tokens: lexer.inlineTokens(innerContent)
            };
        }
    },
    addCommands () {
        return {
            setUnderline: ()=>({ commands })=>{
                    return commands.setMark(this.name);
                },
            toggleUnderline: ()=>({ commands })=>{
                    return commands.toggleMark(this.name);
                },
            unsetUnderline: ()=>({ commands })=>{
                    return commands.unsetMark(this.name);
                }
        };
    },
    addKeyboardShortcuts () {
        return {
            "Mod-u": ()=>this.editor.commands.toggleUnderline(),
            "Mod-U": ()=>this.editor.commands.toggleUnderline()
        };
    }
});
// src/index.ts
var index_default = Underline;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extensions/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CharacterCount",
    ()=>CharacterCount,
    "Dropcursor",
    ()=>Dropcursor,
    "Focus",
    ()=>Focus,
    "Gapcursor",
    ()=>Gapcursor,
    "Placeholder",
    ()=>Placeholder,
    "Selection",
    ()=>Selection,
    "TrailingNode",
    ()=>TrailingNode,
    "UndoRedo",
    ()=>UndoRedo,
    "preparePlaceholderAttribute",
    ()=>preparePlaceholderAttribute
]);
// src/character-count/character-count.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$state$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/state/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-state/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$dropcursor$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/dropcursor/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$dropcursor$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-dropcursor/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$view$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/view/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-view/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$gapcursor$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/gapcursor/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$gapcursor$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-gapcursor/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$pm$2f$dist$2f$history$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/pm/dist/history/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$history$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/prosemirror-history/dist/index.js [app-client] (ecmascript)");
;
;
var CharacterCount = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "characterCount",
    addOptions () {
        return {
            limit: null,
            mode: "textSize",
            textCounter: (text)=>text.length,
            wordCounter: (text)=>text.split(" ").filter((word)=>word !== "").length
        };
    },
    addStorage () {
        return {
            characters: ()=>0,
            words: ()=>0
        };
    },
    onBeforeCreate () {
        this.storage.characters = (options)=>{
            const node = (options == null ? void 0 : options.node) || this.editor.state.doc;
            const mode = (options == null ? void 0 : options.mode) || this.options.mode;
            if (mode === "textSize") {
                const text = node.textBetween(0, node.content.size, void 0, " ");
                return this.options.textCounter(text);
            }
            return node.nodeSize;
        };
        this.storage.words = (options)=>{
            const node = (options == null ? void 0 : options.node) || this.editor.state.doc;
            const text = node.textBetween(0, node.content.size, " ", " ");
            return this.options.wordCounter(text);
        };
    },
    addProseMirrorPlugins () {
        let initialEvaluationDone = false;
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("characterCount"),
                appendTransaction: (transactions, oldState, newState)=>{
                    if (initialEvaluationDone) {
                        return;
                    }
                    const limit = this.options.limit;
                    if (limit === null || limit === void 0 || limit === 0) {
                        initialEvaluationDone = true;
                        return;
                    }
                    const initialContentSize = this.storage.characters({
                        node: newState.doc
                    });
                    if (initialContentSize > limit) {
                        const over = initialContentSize - limit;
                        const from = 0;
                        const to = over;
                        console.warn(`[CharacterCount] Initial content exceeded limit of ${limit} characters. Content was automatically trimmed.`);
                        const tr = newState.tr.deleteRange(from, to);
                        initialEvaluationDone = true;
                        return tr;
                    }
                    initialEvaluationDone = true;
                },
                filterTransaction: (transaction, state)=>{
                    const limit = this.options.limit;
                    if (!transaction.docChanged || limit === 0 || limit === null || limit === void 0) {
                        return true;
                    }
                    const oldSize = this.storage.characters({
                        node: state.doc
                    });
                    const newSize = this.storage.characters({
                        node: transaction.doc
                    });
                    if (newSize <= limit) {
                        return true;
                    }
                    if (oldSize > limit && newSize > limit && newSize <= oldSize) {
                        return true;
                    }
                    if (oldSize > limit && newSize > limit && newSize > oldSize) {
                        return false;
                    }
                    const isPaste = transaction.getMeta("paste");
                    if (!isPaste) {
                        return false;
                    }
                    const pos = transaction.selection.$head.pos;
                    const over = newSize - limit;
                    const from = pos - over;
                    const to = pos;
                    transaction.deleteRange(from, to);
                    const updatedSize = this.storage.characters({
                        node: transaction.doc
                    });
                    if (updatedSize > limit) {
                        return false;
                    }
                    return true;
                }
            })
        ];
    }
});
;
;
var Dropcursor = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "dropCursor",
    addOptions () {
        return {
            color: "currentColor",
            width: 1,
            class: void 0
        };
    },
    addProseMirrorPlugins () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$dropcursor$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dropCursor"])(this.options)
        ];
    }
});
;
;
;
var Focus = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "focus",
    addOptions () {
        return {
            className: "has-focus",
            mode: "all"
        };
    },
    addProseMirrorPlugins () {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("focus"),
                props: {
                    decorations: ({ doc, selection })=>{
                        const { isEditable, isFocused } = this.editor;
                        const { anchor } = selection;
                        const decorations = [];
                        if (!isEditable || !isFocused) {
                            return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecorationSet"].create(doc, []);
                        }
                        let maxLevels = 0;
                        if (this.options.mode === "deepest") {
                            doc.descendants((node, pos)=>{
                                if (node.isText) {
                                    return;
                                }
                                const isCurrent = anchor >= pos && anchor <= pos + node.nodeSize - 1;
                                if (!isCurrent) {
                                    return false;
                                }
                                maxLevels += 1;
                            });
                        }
                        let currentLevel = 0;
                        doc.descendants((node, pos)=>{
                            if (node.isText) {
                                return false;
                            }
                            const isCurrent = anchor >= pos && anchor <= pos + node.nodeSize - 1;
                            if (!isCurrent) {
                                return false;
                            }
                            currentLevel += 1;
                            const outOfScope = this.options.mode === "deepest" && maxLevels - currentLevel > 0 || this.options.mode === "shallowest" && currentLevel > 1;
                            if (outOfScope) {
                                return this.options.mode === "deepest";
                            }
                            decorations.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decoration"].node(pos, pos + node.nodeSize, {
                                class: this.options.className
                            }));
                        });
                        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecorationSet"].create(doc, decorations);
                    }
                }
            })
        ];
    }
});
;
;
var Gapcursor = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "gapCursor",
    addProseMirrorPlugins () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$gapcursor$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gapCursor"])()
        ];
    },
    extendNodeSchema (extension) {
        var _a;
        const context = {
            name: extension.name,
            options: extension.options,
            storage: extension.storage
        };
        return {
            allowGapCursor: (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callOrReturn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExtensionField"])(extension, "allowGapCursor", context))) != null ? _a : null
        };
    }
});
;
;
;
var DEFAULT_DATA_ATTRIBUTE = "placeholder";
function preparePlaceholderAttribute(attr) {
    return attr.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-]/g, "").replace(/^[0-9-]+/, "").replace(/^-+/, "").toLowerCase();
}
var Placeholder = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "placeholder",
    addOptions () {
        return {
            emptyEditorClass: "is-editor-empty",
            emptyNodeClass: "is-empty",
            dataAttribute: DEFAULT_DATA_ATTRIBUTE,
            placeholder: "Write something \u2026",
            showOnlyWhenEditable: true,
            showOnlyCurrent: true,
            includeChildren: false
        };
    },
    addProseMirrorPlugins () {
        const dataAttribute = this.options.dataAttribute ? `data-${preparePlaceholderAttribute(this.options.dataAttribute)}` : `data-${DEFAULT_DATA_ATTRIBUTE}`;
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("placeholder"),
                props: {
                    decorations: ({ doc, selection })=>{
                        const active = this.editor.isEditable || !this.options.showOnlyWhenEditable;
                        const { anchor } = selection;
                        const decorations = [];
                        if (!active) {
                            return null;
                        }
                        const isEmptyDoc = this.editor.isEmpty;
                        doc.descendants((node, pos)=>{
                            const hasAnchor = anchor >= pos && anchor <= pos + node.nodeSize;
                            const isEmpty = !node.isLeaf && (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeEmpty"])(node);
                            if ((hasAnchor || !this.options.showOnlyCurrent) && isEmpty) {
                                const classes = [
                                    this.options.emptyNodeClass
                                ];
                                if (isEmptyDoc) {
                                    classes.push(this.options.emptyEditorClass);
                                }
                                const decoration = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decoration"].node(pos, pos + node.nodeSize, {
                                    class: classes.join(" "),
                                    [dataAttribute]: typeof this.options.placeholder === "function" ? this.options.placeholder({
                                        editor: this.editor,
                                        node,
                                        pos,
                                        hasAnchor
                                    }) : this.options.placeholder
                                });
                                decorations.push(decoration);
                            }
                            return this.options.includeChildren;
                        });
                        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecorationSet"].create(doc, decorations);
                    }
                }
            })
        ];
    }
});
;
;
;
var Selection = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "selection",
    addOptions () {
        return {
            className: "selection"
        };
    },
    addProseMirrorPlugins () {
        const { editor, options } = this;
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"]("selection"),
                props: {
                    decorations (state) {
                        if (state.selection.empty || editor.isFocused || !editor.isEditable || (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNodeSelection"])(state.selection) || editor.view.dragging) {
                            return null;
                        }
                        return __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecorationSet"].create(state.doc, [
                            __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decoration"].inline(state.selection.from, state.selection.to, {
                                class: options.className
                            })
                        ]);
                    }
                }
            })
        ];
    }
});
;
;
function nodeEqualsType({ types, node }) {
    return node && Array.isArray(types) && types.includes(node.type) || (node == null ? void 0 : node.type) === types;
}
var TrailingNode = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "trailingNode",
    addOptions () {
        return {
            node: void 0,
            notAfter: []
        };
    },
    addProseMirrorPlugins () {
        var _a;
        const plugin = new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PluginKey"](this.name);
        const defaultNode = this.options.node || ((_a = this.editor.schema.topNodeType.contentMatch.defaultType) == null ? void 0 : _a.name) || "paragraph";
        const disabledNodes = Object.entries(this.editor.schema.nodes).map(([, value])=>value).filter((node)=>(this.options.notAfter || []).concat(defaultNode).includes(node.name));
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$state$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Plugin"]({
                key: plugin,
                appendTransaction: (_, __, state)=>{
                    const { doc, tr, schema } = state;
                    const shouldInsertNodeAtEnd = plugin.getState(state);
                    const endPosition = doc.content.size;
                    const type = schema.nodes[defaultNode];
                    if (!shouldInsertNodeAtEnd) {
                        return;
                    }
                    return tr.insert(endPosition, type.create());
                },
                state: {
                    init: (_, state)=>{
                        const lastNode = state.tr.doc.lastChild;
                        return !nodeEqualsType({
                            node: lastNode,
                            types: disabledNodes
                        });
                    },
                    apply: (tr, value)=>{
                        if (!tr.docChanged) {
                            return value;
                        }
                        if (tr.getMeta("__uniqueIDTransaction")) {
                            return value;
                        }
                        const lastNode = tr.doc.lastChild;
                        return !nodeEqualsType({
                            node: lastNode,
                            types: disabledNodes
                        });
                    }
                }
            })
        ];
    }
});
;
;
var UndoRedo = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "undoRedo",
    addOptions () {
        return {
            depth: 100,
            newGroupDelay: 500
        };
    },
    addCommands () {
        return {
            undo: ()=>({ state, dispatch })=>{
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$history$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["undo"])(state, dispatch);
                },
            redo: ()=>({ state, dispatch })=>{
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$history$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["redo"])(state, dispatch);
                }
        };
    },
    addProseMirrorPlugins () {
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f$prosemirror$2d$history$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["history"])(this.options)
        ];
    },
    addKeyboardShortcuts () {
        return {
            "Mod-z": ()=>this.editor.commands.undo(),
            "Shift-Mod-z": ()=>this.editor.commands.redo(),
            "Mod-y": ()=>this.editor.commands.redo(),
            // Russian keyboard layouts
            "Mod-\u044F": ()=>this.editor.commands.undo(),
            "Shift-Mod-\u044F": ()=>this.editor.commands.redo()
        };
    }
});
;
 //# sourceMappingURL=index.js.map
}),
"[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/starter-kit/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StarterKit",
    ()=>StarterKit,
    "default",
    ()=>index_default
]);
// src/starter-kit.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/core/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$blockquote$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-blockquote/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$bold$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-bold/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-code/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2d$block$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-code-block/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$document$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-document/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$hard$2d$break$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-hard-break/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$heading$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-heading/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$horizontal$2d$rule$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-horizontal-rule/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$italic$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-italic/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$link$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-link/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$list$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-list/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$paragraph$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-paragraph/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$strike$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-strike/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$text$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-text/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$underline$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extension-underline/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extensions$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ADK_WORKSPACE/TutorMekimi/tutorme-app/node_modules/@tiptap/extensions/dist/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var StarterKit = __TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extension"].create({
    name: "starterKit",
    addExtensions () {
        var _a, _b, _c, _d;
        const extensions = [];
        if (this.options.bold !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$bold$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bold"].configure(this.options.bold));
        }
        if (this.options.blockquote !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$blockquote$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Blockquote"].configure(this.options.blockquote));
        }
        if (this.options.bulletList !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$list$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BulletList"].configure(this.options.bulletList));
        }
        if (this.options.code !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Code"].configure(this.options.code));
        }
        if (this.options.codeBlock !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2d$block$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CodeBlock"].configure(this.options.codeBlock));
        }
        if (this.options.document !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$document$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Document"].configure(this.options.document));
        }
        if (this.options.dropcursor !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extensions$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dropcursor"].configure(this.options.dropcursor));
        }
        if (this.options.gapcursor !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extensions$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Gapcursor"].configure(this.options.gapcursor));
        }
        if (this.options.hardBreak !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$hard$2d$break$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HardBreak"].configure(this.options.hardBreak));
        }
        if (this.options.heading !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$heading$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"].configure(this.options.heading));
        }
        if (this.options.undoRedo !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extensions$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UndoRedo"].configure(this.options.undoRedo));
        }
        if (this.options.horizontalRule !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$horizontal$2d$rule$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HorizontalRule"].configure(this.options.horizontalRule));
        }
        if (this.options.italic !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$italic$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Italic"].configure(this.options.italic));
        }
        if (this.options.listItem !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$list$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItem"].configure(this.options.listItem));
        }
        if (this.options.listKeymap !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$list$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListKeymap"].configure((_a = this.options) == null ? void 0 : _a.listKeymap));
        }
        if (this.options.link !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$link$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Link"].configure((_b = this.options) == null ? void 0 : _b.link));
        }
        if (this.options.orderedList !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$list$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OrderedList"].configure(this.options.orderedList));
        }
        if (this.options.paragraph !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$paragraph$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Paragraph"].configure(this.options.paragraph));
        }
        if (this.options.strike !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$strike$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Strike"].configure(this.options.strike));
        }
        if (this.options.text !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$text$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"].configure(this.options.text));
        }
        if (this.options.underline !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extension$2d$underline$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Underline"].configure((_c = this.options) == null ? void 0 : _c.underline));
        }
        if (this.options.trailingNode !== false) {
            extensions.push(__TURBOPACK__imported__module__$5b$project$5d2f$ADK_WORKSPACE$2f$TutorMekimi$2f$tutorme$2d$app$2f$node_modules$2f40$tiptap$2f$extensions$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TrailingNode"].configure((_d = this.options) == null ? void 0 : _d.trailingNode));
        }
        return extensions;
    }
});
// src/index.ts
var index_default = StarterKit;
;
 //# sourceMappingURL=index.js.map
}),
]);

//# debugId=87c0a5ab-254f-37b4-a1b0-cbf9f112e3cc
//# sourceMappingURL=c427b_%40tiptap_19031843._.js.map